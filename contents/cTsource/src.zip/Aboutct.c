/*
A component of the cT (TM) programming environment.
(c) Copyright 1999 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* *************************************************************** */

char *aboutStr = "cT version 3.0 (07/25/00)";

/* *************************************************************** */

#ifdef X11
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#endif

#include "baseenv.h"

#ifdef WINPC
#define STRICT
#include <windows.h>
#endif

#ifdef MAC
#include <Windows.h>
#include <Dialogs.h>
#include <Events.h>
#include <Resources.h>
#include <Memory.h>
#endif

#include "kdefs.h"
#include "editmenu.h"
#include "tutor.h"
#include "editor.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "edglobal.h"
#include "txt.h"
#include "txtv.h"
#include "ct_ctype.h"

/* *************************************************************** */

#ifdef ctproto    
extern int About(void);
extern int DrawAbout(void);  
extern int  TUTORabs_restore_region(long  id,int  x1,int  y1);
extern int TUTORfree_region(long id);
extern char *TUTORgetenv(char *ss);
int  TUTORmessage(struct  tutorview FAR *vp,int  eKind,int  eVal);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,
 int ebsref,struct  _trect *theR,int  relInfo,int  mintw,int  wrap,
 unsigned int  doc,long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),
 int  ro,int  corner,int  erase,int  frame,int tabsz,int lm,int rm,int inhss,int type);
int  TUTORclose_doc(unsigned int  doc);
int  TUTORset_event_mask(int  eventc,int  value);
int  TUTORset_menubar(unsigned int  barh,struct  tutorview FAR *newMenuView);
unsigned int  TUTORinit_menubar(int  nItems);
int  TUTORadd_menu(unsigned int  barh,char  *card,int  cp,char  *item,int  ip,int  keyBind,int  type,int  unit,double  unitArg,int  eType);
int  RestartPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  selStart,long  selLen);
extern  int TUTORpost_event(struct tutorevent *event);
int  TUTORforward_window(int  wix);
extern int TUTORclose_window(int wid);
int  TUTORclose_view(struct  tutorview FAR *vp);
int  TUTORclose_panel(unsigned int  theV);
extern  int TUTORset_abs_clip_rect(TRect FAR *cr);
extern int TUTORarrow_cursor(int isTemp);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
extern int TUTORclip_window(int wix);
int  TUTORinq_abs_clip_rect(struct  _trect *cr);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,int ebsref,
 struct  _trect *theR,int  relInfo,int  mintw,int  wrap,unsigned int  doc,long  pos,
 long  len,int  wantV,int  wantH,int  (*KeyF)(),int  ro,int  corner,int  erase,
 int  frame,int tabsz,int lm,int rm,int inhss,int type);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
int  EditorDefaultStyles(unsigned int  doc);
int  TUTORclear_doc(unsigned int  doc);
extern int TUTORalert(int wn, char *msg);
extern  struct tutorview FAR *TUTORinit_view(int sW,unsigned int vDat,int (*vProc)());
int  procmsgstub(unsigned int  viewH,struct  tutorevent *event);
int procmsg(Memh editH, struct tutorevent *cev);
int  TUTORcreate_window(int  top,int  left,int  xSize,int  ySize,int  type);
unsigned int  TUTORnew_doc(int  string,int  honorP);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORdealloc(char  FAR *ptr);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
extern TUTORfree_region(long regid);
long TUTORabs_save_region(int x1, int y1, int x2, int y2);
extern char *TUTORget_user(void);
int  TUTORset_comb_rule(int  rule);
extern int fuzzyeq(double x,double y);
extern double lcitof(long lv);
extern double floor(double dv);
extern int TUTOR68030_cache(void);
extern long qroundp(double dv);
extern long lcftoi(double dv);
int  lclocy(long  q);
int  lclocx(long  q);
int  killptr(char  FAR * FAR *ptr);
extern int SetupCTDir(void);
extern FileRef *TUTORct_path(void);
extern int ReleasePtr(Memh mm);
extern int setexectitle(char *sn);
extern int TMessage(char FAR *s);
extern int TMessage(char FAR *s);
extern int TUTORrescale_message(void);
extern int TUTORshowt(double value,int nBefore,int nAfter, int showperiod, char *ss);
extern int TUTORshow(int type,double value, int sigfig, char *ss);
extern int SetFlushState(int arg);
extern int flush(void);
/* extern int signgam(void); */
extern int TUTORzero(char SHUGE *zp, long len);
extern  int TUTORset_file_type(FileRef FAR *fName,int findx,int type,int xx,int yy);
extern int CTset_foreground_color(int color);
extern int CTset_background_color(int color);
extern char *strf2n(char FAR *x);
extern char *strnf2n(char FAR *x,int n);
extern char *strcpyf(char FAR *a,char FAR *b);
extern char *strncpyf(char FAR *a,char FAR *b,int n);
extern char *strcatf(char FAR *a,char FAR *b);
extern int strcmpf(char FAR *a,char FAR *b);
extern int strncmpf(char FAR *a,char FAR *b,int n);
extern int strlenf(char FAR *ss);
extern  int TUTORunset_clip_rectangle(void );
extern int TUTORdump(char *ss);
extern int TUTORset_textfont(int jj);
extern  int TUTORset_view(struct tutorview FAR *vp);
extern  struct tutorview FAR *TUTORinq_view(void );
extern double log(double xx);
extern char FAR *GetPtr(Memh mm);
extern double lcfcoord(double dv);  /* float to float, rounding to nearest integer */
extern int  TUTORnormal_cursor(void);
extern long TUTORload_region_ppm(FileRef FAR *fRef);
#endif /* ctproto */

#ifdef WINPC
extern void cTReleaseDC(HWND hWnd,HDC hDC);
extern HDC cTGetDC(HWND hWnd);
extern HANDLE hcTInst; /* current instance of cT */
#endif  

#ifdef MAC
extern int CenterAbout(Rect *, Rect *,int);
#endif

extern int procabout();
extern struct tutorview *TUTORinq_view();
extern struct tutorview *TUTORinit_view();

static Memh AboutMenu = HNULL; /* about window menu bar */

/* *************************************************************** */

About()
	
{	int wix;
	struct tutorview FAR *cv; /* current view */
	
	/* focus on window if already exists */
	
	if (AboutWn >= 0) {
		TUTORforward_window(AboutWn);
		return;
	}
		
	cv = TUTORinq_view();	/* get current view */
	
	/* initialize window, menus, and view */

    AboutWn = TUTORcreate_window(-1,-1,0,0,ABOUTW);
    if (AboutWn < 0) goto nomem;
	windowsP[AboutWn].wproc = (int(*)())(procabout); 
    AboutVp = TUTORinit_view(AboutWn,0,procabout);
	if (!AboutVp) goto nomem;
    TUTORset_view(AboutVp);
    if (!AboutMenu) {
    	AboutMenu = TUTORinit_menubar(3);
    	if (!AboutMenu) goto nomem;
    	TUTORadd_menu(AboutMenu,NIL,10,"Edit Program",60,0,exec_toedit,1,0.0,EVENT_MENU); 
    }
    TUTORset_event_mask(EVENT_LEFTDOWN,TRUE);
    TUTORset_event_mask(EVENT_LEFTUP,TRUE);
    TUTORset_event_mask(EVENT_RIGHTDOWN,TRUE);
    TUTORset_event_mask(EVENT_RIGHTUP,TRUE);
    TUTORset_event_mask(EVENT_DOWNMOVE,TRUE);
    TUTORset_event_mask(EVENT_MENU,TRUE);
    TUTORset_event_mask(EVENT_MSG,TRUE);
    TUTORset_event_mask(EVENT_FWD,TRUE);
    TUTORset_event_mask(EVENT_VFOCUS,TRUE);
    TUTORset_event_mask(EVENT_WFOCUS,TRUE);
    TUTORset_event_mask(EVENT_SCROLL,TRUE);
	TUTORset_event_mask(EVENT_KEY,TRUE);
	TUTORset_event_mask(EVENT_DESTROY,TRUE);
    
    TUTORset_menubar(AboutMenu,AboutVp);
       
    /* focus on About window */        
    
    TUTORforward_window(AboutWn); /* focus on message window */
	TUTORarrow_cursor(TRUE);
       	
	TUTORset_view(cv); /* restore view */
	return;
	
nomem:
	if (EditWn[0] >= 0) wix = EditWn[0];
	else wix = ExecWn;
	TUTORalert(wix,"No memory for About message");
	return;
	
} /* About */
	
/* *************************************************************** */

procabout(docH,event)   /* event processor for about window */
Memh docH;
struct tutorevent *event; /* event to process */

{   TRect clipR; /* saved clip rectangle */
	TRect eraseR; /* rectangle to erase */
	struct tutorview FAR *viewp; 

    if (AboutWn < 0) return(0); /* nothing to do */

    /* process message window events */

    switch (event->type) {

    case EVENT_REDRAW:
    	TUTORset_view(AboutVp);
        TUTORinq_abs_clip_rect(&clipR); /* save clip */
		TUTORclip_window(AboutWn); /* clip to entire window */
		eraseR.top = eraseR.left = 0;
		eraseR.bottom = windowsP[AboutWn].wysize;
		eraseR.right = windowsP[AboutWn].wxsize;
        TUTORdraw_abs_solid_rect((TRect FAR *)&eraseR,PAT_BACKGROUND);
		DrawAbout(); /* draw the image */
        TUTORset_abs_clip_rect((TRect FAR *) &clipR); /* restore clip */
        viewp = windowsP[AboutWn].firstView; /* update everybody else */
        while (viewp) {
        	if (viewp != AboutVp) {
        		TUTORset_view(viewp);
        		(*viewp->vproc) (viewp->vh,event);
        	}
        	viewp = viewp->nextView;
        } /* while */
        event->type = -1;
        break;

    case EVENT_WMKILL: /* window closed by window manager */    
    	event->type = -1;       
    	if (AboutVp)
    		TUTORclose_view(AboutVp);    
    	break;		


    case EVENT_DESTROY: /* view destroyed */
		viewp = AboutVp;
		AboutVp = FARNULL; /* recursive call won't hurt */
		if (viewp) {
			if (AboutWn >= 0)
        		TUTORclose_window(AboutWn);
			AboutWn = -1;
		}
        event->type = -1;
        break;
       
    case EVENT_KEY:
        event->type = -1;
    	if (EditWn[0] >= 0) { /* switch to editor */
            TUTORset_view(EditVp[0]); /* set to editor view */
            TUTORforward_window(EditWn[0]);
            TUTORmessage(EditVp[0],EVENT_VFOCUS,TRUE);
            TUTORnormal_cursor();
		}
    	break;
    	
    case EVENT_MENU:
        event->type = -1;
    	if ((EditWn[0] >= 0) && (event->a1 == exec_toedit)) { /* message->editor transition */
            TUTORset_view(EditVp[0]); /* set to editor view */
            TUTORforward_window(EditWn[0]);
            TUTORmessage(EditVp[0],EVENT_VFOCUS,TRUE);
            TUTORnormal_cursor();
		}
    	break;
        
    } /* event switch */
    
    /* pass event on to other views if still valid */
    
    if ((AboutWn >= 0) && AboutVp && (event->type > 0)) {
        viewp = windowsP[AboutWn].firstView; /* update everybody else */
        while (viewp) {
        	if (viewp != AboutVp) {
        		TUTORset_view(viewp);
        		(*viewp->vproc) (viewp->vh,event);
        	}
        	viewp = viewp->nextView;
        } /* while */
    }
    return(0);
    
} /* procabout */

/* *************************************************************** */

#ifdef WINPC

static int DrawAbout()

{	HWND hWnd; /* parent window for bitmap */
	RECT rcBitmap; /* rectangle for bitmap */
	HDC hdc; /* device context */
    HDC memDC; /* memory device context */
    HBITMAP origBmp; /* original bitmap */
    HBITMAP Logo1; /* cT about bitmap */
    BITMAP bm; /* bitmap description */
    int xx; /* x position */

	if (AboutWn < 0)
		return(0); /* nothing to do */

	hWnd = windowsP[AboutWn].wp;
	rcBitmap.top = 8;
	rcBitmap.left = 12;
	rcBitmap.bottom = rcBitmap.top+420-1;
	rcBitmap.right = rcBitmap.left+418-1;
   
    hdc = cTGetDC(hWnd);
    memDC = CreateCompatibleDC(hdc);
    Logo1 = LoadBitmap(hcTInst,"Logo1");
	if (!Logo1)
		return(0);

    /* draw cT about logo */

    origBmp = SelectObject(memDC,Logo1);
    GetObject(Logo1,sizeof(BITMAP),&bm);
    BitBlt(hdc,rcBitmap.left,rcBitmap.top,bm.bmWidth,bm.bmHeight,memDC,0,0,SRCCOPY);

    SelectObject(memDC,origBmp); /* restore original bitmap */
    DeleteObject(Logo1); /* delete logo bitmap */
    DeleteDC(memDC);
    cTReleaseDC(hWnd,hdc);
    return(1);

} /* DrawAbout */

#endif

/* *************************************************************** */

#ifdef MAC

static int DrawAbout()

{	PicHandle aboutPic;	/* PICT we want to display */
	Rect wRect,pRect;	/* rectangle for window used to display PICT */
	WindowPtr aboutW;	/* window used to display PICT */
	WindowPtr curPort;	/* to save & restore grafport */
	
	if (AboutWn < 0)
		return(0);
		
	aboutPic = (PicHandle) GetResource('PICT',6002);
	if (!aboutPic)
		return(0); /* no pict! */
	pRect = (*aboutPic)->picFrame;
	
	CenterAbout(&pRect,&wRect,1);
	aboutW = (WindowPtr)windowsP[AboutWn].wp;
	GetPort(&curPort);
	SetPort(aboutW);
	ValidRect(&aboutW->portRect); /* avoid update */
	DrawPicture(aboutPic,&pRect);
	
	return(1);
		
} /* DrawAbout */

#endif

/* *************************************************************** */

#ifdef X11

char *aboutTxt = "cT is a copyright (c) Carnegie Mellon University, 1989, 1992, 1995, 1999.\n\nPermission to reproduce and use cT for internal use is granted provided the\ncopyright and \"No Warranty\" statements are included with all reproductions.\ncT may also be redistributed without charge provided that the copyright and\n\"No Warranty\" statements are included in all redistributions.\n\nNO WARRANTY. cT IS FURNISHED ON AN \"AS IS\" BASIS. CARNEGIE MELLON\nUNIVERSITY MAKES NO WARRANTIES OF ANY KIND, EITHER EXPRESSED OR IMPLIED AS\nTO ANY MATTER INCLUDING, BUT NOT LIMITED TO, WARRANTY OF FITNESS FOR\nPURPOSE OR MERCHANTABILITY, EXCLUSIVITY OF RESULTS OR RESULTS OBTAINED FROM\nUSE OF cT. CARNEGIE MELLON UNIVERSITY DOES NOT MAKE ANY WARRANTY OF ANY\nKIND WITH RESPECT TO FREEDOM FROM PATENT, TRADEMARK OR COPYRIGHT\nINFRINGEMENT.";

int DrawAbout() 

{	char *envP; /* pointer to font path env variable */
	FileRef fRef; /* about image file */
	long regionID; /* about image */

#ifdef EXECUTE
	return(0);
#endif
	return(0);

	/* read *.ppm file containing cT "About" image */
#ifdef NOSUCH				
	envP = TUTORgetenv("CT_FONTS");	
	if (envP) strcpy(fRef.path,envP);
	else fRef.path[0] = 0;
	strcat(fRef.path,"about.");
	strcat(fRef.path,machinename());
	strcat(fRef.path,".ppm");
	regionID = TUTORload_region_ppm((FileRef FAR *)&fRef);
	if (!regionID) 
		return(0); /* can't find the image */
	TUTORabs_restore_region(regionID,0,0);
	TUTORfree_region(regionID);
	return(0);
#endif	
} /* DrawAbout */

#endif /* X11 */

/* *************************************************************** */
