
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
 Routines auxiliary to the cT lexical analyzer.
*/

#include "ctutor.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "exprdefs.h"
#include "yacc.h"

#ifdef ctproto
extern int set_wk_defset(Memh setH);
extern int strcmpf(char FAR *aa,char FAR *bb);
int chop_def_sym(struct defset FAR *setP,char *str);
int find_def_sym(Memh topSetH,char *s,Memh *retSet,int *retIndex);
int  lexname(int  partial,char  *yytext,int  yyleng);
int  seekvar(int  partial,char  *yytext,int  yyleng);
extern int  mystrcmp(char  *suser,char  *svar);
int  deflook(char  *s,int  glf,int  symi);
extern int  retfunct(int  fct,int  type,char  *yytext,int  yyleng);
extern int  mretsys(int  svar,char  *yytext,int  yyleng);
extern int  tretsys(int  svar,char  *yytext,int  yyleng);
extern int  retsys(int  svar,char  *yytext,int  yyleng);
extern int  iretsys(int  svar,char  *yytext,int  yyleng);
extern int  ifretsys(int  svar,char  *yytext,int  yyleng,int  floatf);
extern int  retnum(char  *yytext);
char  FAR *GetPtr(unsigned int  mm);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  n_myunput(int  nc);
char  *strf2n(char  FAR *strp);
int  n_restart(void);
extern int TUTORzero(char SHUGE *ptr,long lth);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
long  TUTORget_len_doc(unsigned int  doc);
#endif /* ctproto */

extern long TUTORget_len_doc();
extern double lcitof();

/* ******************************************************************* */

int find_def_sym(topSetH,s,retSet,retIndex) /* search for defined name */
/* returns TRUE if found, FALSE if not */
Memh topSetH; /* handle on top define set for search */
char *s; /* pointer to defined symbol name */
Memh *retSet; /* handle on set symbol found in */
int *retIndex; /* +n = position of name if found */
               /* -n = -(insert position+1) if not found */

{	int wkfound; /* index of name in current working define set */
	int mgfound; /* index of name in merged define set */
	int mii; /* index in merged define sets */
	struct defset FAR *topSetP; /* ptr to top level set for search */
	long FAR *mtabP; /* pointer to table of merged sets */
	Memh msetH; /* handle on next merged define set */
	struct defset FAR *msetP; /* pointer to next merged define set */

	/* first search symbols in current define set */
	
	wkfound = -1; /* not found in current set yet */
	mgfound = -1; /* not found in merged set yet */
	topSetP = (struct defset FAR *)GetPtr(topSetH);
	if (topSetP->defvarN) {
		wkfound = chop_def_sym(topSetP,s); /* search in current set */
		if (wkfound >= 0) {
			*retIndex = wkfound; /* index in set */
			*retSet = topSetH; /* handle on set */
			ReleasePtr(topSetH);
			return(TRUE); /* found in current set */
		} /* wkfound if */
	} /* defvarN if */
	
	/* search merged sets if not in current set */

	if (topSetP->mergeN) {
		mtabP = (long FAR *)GetPtr(topSetP->mergeH);
		for(mii=0; mii<topSetP->mergeN; mii++) {
		
			/* search next merged define set */
			
			msetH = mtabP[mii];
			msetP = (struct defset FAR *)GetPtr(msetH);
			mgfound = chop_def_sym(msetP,s); 
			ReleasePtr(msetH); /* release define set */
			KillPtr(msetP);
			if (mgfound >= 0) /* found in merged set */
				break; /* exit for */
		} /* for */
		ReleasePtr(topSetP->mergeH);
		KillPtr(mtabP);
	} /* wkfound if */
	
	ReleasePtr(topSetH); /* release top level define set */
	KillPtr(topSetP);
	
	if (mgfound >= 0) {
		*retIndex = mgfound; /* index in set */
		*retSet = msetH; /* handle on merged set */
		return(TRUE); /* found in merged set */
	} /* mgfound if */
		
	*retIndex = wkfound; /* index where name should go */
	*retSet = topSetH; /* handle on set */
	return(FALSE); /* not found */

} /* find_def_sym */

/* ******************************************************************* */

int chop_def_sym(setP,str) /* binary chop search for defined symbol */
			/* returns +n = position of name if found */
			/*         -n = -(insert position+1) if not found */
struct defset FAR *setP; /* pointer to define set */
char *str; /* defined name to search for */

{	int low,mid,high; /* binary chop */
	int result; /* location of find */
	int compare; /* result of string compare */
	struct defvar FAR *dP; /* pointer to defined name table */

	if (!setP->defvarN || (setP->defvarH == HNULL))
		return(-1); /* no symbols to search */
		
	dP = (struct defvar FAR *)GetPtr(setP->defvarH); /* ptr to names */
	low = mid = 0;
	high = setP->defvarN-1;
	result = -1;

	/* binary chop search for defined name */

	while (low <= high) {
		mid = (low + high) / 2;
		compare = strcmpf((char FAR *)str,dP[mid].name);
		if (compare < 0)
			high = mid - 1;
		else if (compare > 0)
			low = mid + 1;
		else {
			result = mid;
			break;
		}
	} /* while */
	
	ReleasePtr(setP->defvarH); /* release defined names */
	if (result >= 0) return(result);
	if (compare < 0) return (-(mid + 1));
	else return (-(mid + 2));

} /* chop_def_sym */
	
/* ******************************************************************* */

set_wk_defset(setH) /* set define set being compiled or used */
Memh setH; /* hande on set to compile */

{
	/* check if setting to current set */
	
	if (setH && (wkSetH == setH))
		return(0);
	
	/* close currently compiling define set */
	
	if (wkSetP) {
		ReleasePtr(wkSetH);
		wkSetP = FARNULL;
	} /* wkSetP if */
	
	/* set new define set */
	
	wkSetH = setH; 
	if (wkSetH)		
		wkSetP = (struct defset FAR *)GetPtr(wkSetH);
	
} /* set_wk_defset */

/* ******************************************************************* */
