
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989,1992 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/
/* ******************************************************************* */

#define STRICT
#include <windows.h>
#include <commdlg.h>
#include <stdlib.h>
#include <string.h>
#include <direct.h>
#include "baseenv.h"
#include "ctmsw.h"
#include "kdefs.h"
#include "tglobals.h"
#include "kglobals.h"
#include "editor.h"
#include "execdefs.h"
#include "editmenu.h"
#include "prefs.h"

/* ******************************************************************* */

extern void cTReleaseDC(HWND hWnd,HDC hDC);
extern HDC cTGetDC(HWND hWnd);
extern void RestoreUnderDialog(void);
int  TUTORinq_abs_clip_rect(struct  _trect *cr);
int  TUTORclip_window(int  wid);
extern  int TUTORset_abs_clip_rect(TRect FAR *cr);
int  TUTORset_comb_rule(int  rule);      
extern int CTset_background_color(int cc);
extern int TUTORdraw_abs_solid_rect(TRect FAR *tr,int color);
extern int TUTORforward_window(int ww); 
extern int PrefFont(void);         
int EditNewPrefs(int wix);  
extern int TUTORflush(void);
extern int sscanf(char *ss,char *form, ...); 
extern int TUTORinq_background_color(struct tutorColor *bc);
extern int TUTORset_color_rgb(int select,int sp,double rr,double gg,double bb);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);  
int WritePrefs(struct PrefRec FAR *prefPtr); 
int strcmpf(char FAR *ss,char FAR *jj);
extern int sprintf(char *ss,char *ff, ...);   
extern int TUTORget_AE_win(void);       
int ReleasePtr(unsigned int nn);
extern int TUTORdraw_char(unsigned char FAR *str,int count);  
extern int TUTORforce_redraw(int wix);
int strlenf(char FAR *ss);  
extern int TUTORset_textfont(int xx);
extern int TUTORdraw_text(char FAR *cc,int count);         
extern int PrefFaceN(char *sr);
static void path_to_fRef(char FAR *fpath,FileRef FAR *fRef);
long  TUTORabs_save_region(int	x1,int	y1,int	x2,int	y2);
int  TUTORfree_region(long  id);      
int  TUTORinset_rect(struct  _trect FAR *rr,int  xx,int  yy);
int  TUTORframe_abs_rect(struct  _trect FAR *tr);
int  TUTORabs_restore_region(long  id,int  x1,int  y1);    
int  TUTORset_rect(struct  _trect *r,int  left,int  top,int  right,int  bottom);
extern int PostEditQuit(void);   
int  TUTORget_zfont(char  *famS,int  size);    
int  TUTORabs_move_to(int  x,int  y);
extern char *PrefFaceStr(int index);
extern int TUTORprefs_dialog(int wn);
extern int TUTORinput_dialog(int wn,char *msg,char *input);
extern int TUTORync_dialog(int wn, char *msg);
extern int TUTORok_dialog(int wn,char *msg);
extern char FAR *TUTORalloc(long size,int abort,char *label);
extern int TUTORdealloc(char FAR *ptr);
extern int cTRegisterWindow(HWND hWnd,int cTtype,int cTindex,int cmdN,Memh infH);
extern struct tutorview FAR *TUTORinq_view(void);
extern struct tutorview FAR *TUTORinit_view(int  sW,unsigned int  vDat,
       int  (*vProc)());
extern char FAR *strncpyf(char FAR *aa,char FAR *bb,int nn);
extern int procbuttonstub(unsigned int hv,struct tutorevent *event);
extern int TUTORset_abs_view_rect(int  x1,int  y1,int  w,int  h);
extern char FAR *strcpyf(char  FAR *aa,char  FAR *bb);
extern int TUTORzero(char FAR *ptr,long lth);
extern int TUTORreadfile_dialog(int wn,char *msghdr,struct _fref *filename,
    char *sname,int maxRet,int type,int msgb,int doRedraw);
extern BOOL FAR CALLBACK StdInpDlg(HWND hDlg,unsigned message,WPARAM wParam,
    LONG lParam);
extern BOOL FAR CALLBACK MulMsgDlg(HWND hDlg,unsigned message,WPARAM wParam,
    LONG lParam);
extern BOOL FAR CALLBACK PrefDlg(HWND hDlg,unsigned message,WPARAM wParam,
    LONG lParam);
extern BOOL FAR CALLBACK PrefQDlg(HWND hDlg,unsigned message,WPARAM wParam,
    LONG lParam);
extern unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
unsigned int TUTORnew_button(int wn,unsigned int owner,unsigned int objH,
	     int objR,struct _trect *tr,int kind,int thick,int bFont,
	     char *title,unsigned int titleDoc,unsigned int destH,int (*DestProc)(),int destMsg,
	     int destMsg1,double destMsg2,int erase);
static int editdialog(char *ds,char *is,char *ds2,char *is2);

/* ******************************************************************* */

extern HWND CurrentWinH; /* handle on current window */
extern HANDLE hcTInst; /* current instance of cT */
extern Memh cTwinInfH; /* handle on cT window (cTwinInf) table */
extern int cTwinInfN; /* number entries in cT window table */
extern HDC CurrentDC; /* current window's device context */
extern int HaveDC; /* TRUE if have device context */
extern char *kPrefID;

/* ******************************************************************* */

extern int wColorSet; /* window colors set for */

static OPENFILENAME ofn; /* open-file / save-file dialog info */
static int altDialog; /* TRUE if using alternate (2-message/input) dialog */
static char dlgmsg1[82]; /* dialog box message, reply */
static char dlginp1[82]; /* initial input line */
static char dlgmsg2[82]; /* optional second message, reply */
static char dlginp2[82]; /* optional second initial input */

static char FAR *DlgTxtBufP; /* 8x80 array for multi-line dialog */
/* default font height (in pixel size) for editor */
/* (newFontSize TRUE for edit & dict windows) */
#define DIALOGFONT "zsans"
#define DIALOGFSIZE 16

/* ******************************************************************* */

#ifdef CTEDIT
static char ofnFilter[] = {
		 "Source Files (*.c)\0*.c\0" \
		 "Include Files (*.h)\0*.h\0" \
		 "Text Files (*.txt)\0*.txt\0" \
         "All Files (*.*)\0*.*\0\0"} ;
#else
static char ofnFilter[] = {
		 "cT Files (*.T)\0*.t\0" \
		 "Text Files (*.TXT)\0*.txt\0" \
         "All Files (*.*)\0*.*\0\0"} ;
#endif
static char insFilter[] = {
		 "cT Files (*.T)\0*.t\0" \
		 "Text Files (*.TXT)\0*.txt\0" \
		 "Bitmap Files (*.BMP)\0*.bmp\0" \
         "All Files (*.*)\0*.*\0\0"} ;
static char allFilter[] = {
                 "All Files (*.*)\0*.*\0\0" } ;

#define DS_3DLOOK 0x0004L

/* ******************************************************************* */

static long regionID = 0;
static TRect diagClipR; /* saved clip rectangle during dialog */
static int peekPre = 0; /* non-zero if paint pending before dialog */

extern int qtSuppressPaint; /* use QuickTime redraw machinery */	
	
/* ******************************************************************* */

int PreDialog() /* processing before system dialog box */

{   int wxx,wyy;
	MSG pMsg;
	
	peekPre = PeekMessage(&pMsg,(HWND)NULL,WM_PAINT,WM_PAINT,PM_NOREMOVE);

	TUTORinq_abs_clip_rect(&diagClipR); /* save clip */
	TUTORclip_window(CurrentWindow); /* clip to entire window */
    wxx = windowsP[CurrentWindow].wxsize;
    wyy = windowsP[CurrentWindow].wysize;
    regionID = TUTORabs_save_region(0,0,wxx,wyy);
	modalW = CurrentWindow;
    if (HaveDC) { /* release device context */
		cTReleaseDC(CurrentWinH,CurrentDC);
    }         
    return(regionID > 0);

} /* PreDialog */

/* ******************************************************************* */

PostDialog() /* processing after system dialog box */

{   int saveMode;
	int peekF;
	MSG pMsg;
    
	/* restore window and graphics context */

	TUTORset_window(modalW); /* be sure we have the right window */
    if (!HaveDC) {
		CurrentDC = cTGetDC(CurrentWinH);
		if (windowsP[CurrentWindow].winPalH) {
			/* select into device context */
			SelectPalette(CurrentDC,(HPALETTE)windowsP[CurrentWindow].winPalH,0);
			RealizePalette(CurrentDC);
		}
    } /* HaveDC if */
	modalW = -1;

	/* restore screen contents */

    if (regionID) {
		RestoreUnderDialog(); /* repaint under dialog */
		TUTORfree_region(regionID);
		regionID = HNULL;
    }
	TUTORset_abs_clip_rect((TRect FAR *)&diagClipR); /* restore clip */
    saveMode = CurrentMode; /* save current setting */
    CurrentMode = wColorSet = -1; /* mode unknown */
    TUTORset_comb_rule(saveMode); /* drives pen_fix(); */  
	
	peekF = PeekMessage(&pMsg,(HWND)NULL,WM_PAINT,WM_PAINT,PM_NOREMOVE);
	if (!peekPre && peekF) /* check for redraw */
		qtSuppressPaint++; /* ignore the next PAINT signal */

    return(0);

} /* PostDialog */

/* ******************************************************************* */

void RestoreUnderDialog() /* repaint area under dialog box */
{   RECT wrect; /* window client area rectangle */

    if (regionID) 
		TUTORabs_restore_region(regionID,0,0);
	GetClientRect(CurrentWinH,(LPRECT)&wrect);
	ValidateRect(CurrentWinH,&wrect);

} /* RestoreUnderDialog */

/* ******************************************************************* */

int TUTORsavefile_dialog(wn,msg,filename,maxRet)
int wn; /* window dialog should appear in */
char *msg; /* unused */
FileRef *filename;
int maxRet; /* unused */

{   HWND hWnd; /* window handle */
    int ofRet; /* return from OpenFile */
    char fpath[FILEL+2]; /* local copy of file path+name */
    hWnd = (HWND)windowsP[wn].wp; /* get window handle */
    TUTORzero((char FAR *)filename,(long)sizeof(FileRef)); /* pre-zero fileref */
    TUTORzero((char FAR *)fpath,(long)FILEL); /* pre-clear file name */
    if (hWnd != GetActiveWindow())
	return(FALSE);
    /* set up GetSaveFileName data structure */
    TUTORzero((char FAR *)&ofn,(long)sizeof(OPENFILENAME));
    ofn.lStructSize	  = sizeof(OPENFILENAME);
    ofn.hwndOwner	  = hWnd;
	if (wn == ExecWn) {
    	ofn.lpstrFilter	  = allFilter;	
	} else {
    	ofn.lpstrFilter	  = ofnFilter;
	}
    ofn.lpstrFile	  = (LPSTR)fpath;
    ofn.nMaxFile	  = FILEL;
    ofn.nMaxFileTitle = FILEL;
    ofn.Flags		  = OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT;
    ofn.lpstrDefExt	  = "t";
    PreDialog();
    ofRet = GetSaveFileName(&ofn);
    PostDialog();
	PostFileDialog(wn);
    if (ofRet) { /* worked */
		path_to_fRef((char FAR *)fpath,(FileRef FAR *)filename);
		return(TRUE); /* everything worked */
    } /* ofRet if */
    return(FALSE);

} /* TUTORsavefile_dialog */

/* ******************************************************************* */

int TUTORreadfile_dialog(wn, msghdr, filename, filedef,maxRet, type, msgb, doRedraw)
int wn; /* window number */
char *msghdr; /* dialog box header message */
FileRef *filename; /* returned set to file selected */    
char *filedef; /* default file name */
int maxRet; /* unused */
int type; /* 1: source, 2: binary, 3: (not used), 4: insert */
int msgb; /* button message: 1 = open, 2 = create, 3 = open(swtich) */
int doRedraw; /* if TRUE must force redraw after dialog */
              /* if FALSE attempt to save screen behind dialog */
/* returns = 1 if all ok */
/*           2 if dialog canceled */
/*           3 if not enough screen space for dialog */
/*           4 if not enough memory for dialog */
/*           5 if focus not on window */
{   HWND hWnd; /* window handle */
    int ofRet; /* return from OpenFile */
    char fpath[FILEL+2]; /* local copy of file path+name */
    hWnd = (HWND)windowsP[wn].wp; /* get window handle */
    TUTORzero((char FAR *)filename,(long)sizeof(FileRef)); /* pre-zero fileref */
    TUTORzero((char FAR *)fpath,(long)FILEL); /* pre-clear file name */
    if (hWnd != GetActiveWindow())
		return(5);
     
	/* get default file name if any */
	
	if (filedef) {
		strcpy(fpath,filedef);
	}
	
    /* set up GetOpenFileName data structure */
    TUTORzero((char FAR *)&ofn,(long)sizeof(OPENFILENAME));
    ofn.lStructSize	  = sizeof(OPENFILENAME);
    ofn.hwndOwner	  = hWnd;
	if (wn == ExecWn) {
    	ofn.lpstrFilter	  = allFilter;	
	} else {
		if (type == 4) ofn.lpstrFilter = insFilter;
    	else ofn.lpstrFilter = ofnFilter;
	}
    ofn.lpstrFile	  = (LPSTR)fpath;
    ofn.nMaxFile	  = FILEL;
    ofn.nMaxFileTitle	  = FILEL;
    ofn.Flags		  = OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT;   
    if (type == 1)
    	ofn.lpstrDefExt	  = "t";  
    else ofn.lpstrDefExt = "";
    PreDialog();
    if (msgb == 2)
		ofRet = GetSaveFileName(&ofn);
    else
		ofRet = GetOpenFileName(&ofn);
    PostDialog();
	PostFileDialog(wn);
    if (ofRet) { /* worked */
		path_to_fRef((char FAR *)fpath,(FileRef FAR *)filename);
		return(1); /* everything worked */
    } /* ofRet if */
    return(2);

} /* TUTORreadfile_dialog */

/* ******************************************************************* */

static int PostFileDialog(wn) /* redraw other windows after file dialog */
int wn; /* window driving dialog */

{	int wii; /* index in windows */

	if (wn < 0) return(0);
	for(wii=0; wii<WINDOWLIMIT; wii++) {
		if (windowsP[wii].wp && (wii != wn))
			windowsP[wii].winRedraw = TRUE;
	} /* for */
	return(0);

} /* PostFileDialog */

/* ******************************************************************* */

static void path_to_fRef(fpath,fRef) /* make file ref from full path */
char FAR *fpath; /* pointer to full path */
FileRef FAR *fRef; /* file ref to fill in */
{   int drivec;
    int nii;
    drivec = fpath[0];
    if ((drivec >= 'A') && (drivec <= 'Z'))
	drivec = (drivec-'A')+'a';	/* convert to lower case */
    fRef->drive = (drivec-'a')+1; /* get drive number */
    strcpyf(fRef->path,&fpath[2]); /* copy path+file */
    nii = strlenf(fRef->path);
    while (nii) {
	if (fRef->path[nii-1] == '\\') /* search for begin of name */
	    break;
	nii--; /* back up thru string */
    } /* while */
    fRef->nameInd = nii; /* index of file name */
} /* path_to_fRef */
/* ******************************************************************* */
TUTORfiletype_dialog() { return(-1); }
/* ******************************************************************* */
TUTORedit_dialog(wn,msg,retS1,msg2,retS2,maxRet)
int wn; /* window dialog should appear in */
char *msg; /* message to display */
char FAR *retS1; /* editable reply (may have something in it to start) */
char *msg2; /* second message line */
char FAR *retS2; /* second editable reply */
int maxRet; /* maximum size of return string (in both replies) */
/* returns TRUE for ok, FALSE for cancel */
{   int retVal; /* dialog return */
    if (maxRet >= 79) maxRet = 79;
    dlginp1[0] = dlginp2[0] = '\0'; /* no pre-set input string */
    if (retS1)
	    strncpyf((char FAR *)dlginp1,retS1,79); /* pre-load input string */
    if (msg2 && retS2)
        strncpyf((char FAR *)dlginp2,retS2,79); /* pre-load input string */
    if (msg2) 
        retVal = editdialog(msg,dlginp1,msg2,dlginp2);
    else
        retVal = editdialog(msg,dlginp1,NEARNULL,NEARNULL);
    if (retVal == IDOK) {
	    if (retS1)
	        strcpyf(retS1,(char FAR *)dlgmsg1);
        if (altDialog && retS2)
            strcpyf(retS2,(char FAR *)dlgmsg2);
	    return(TRUE);
    } /* IDOK if */
    return(FALSE);
} /* TUTORedit_dialog */
/* ******************************************************************* */
static int editdialog(ds,is,ds2,is2) /* simple editor dialog */
char *ds; /* display string */
char *is; /* initial input string */
char *ds2; /* optional second display string */
char *is2; /* optional second input string */
{   FARPROC dlgproc; /* pointer to dialog routine */
	int msg; /* dialog reply */
    char *boxName; /* dialog box type name */
	strncpy(dlgmsg1,ds,79); /* set display string */
	if (is == NIL) 
        dlginp1[0] = '\0';
	else 
        strncpy(dlginp1,is,79); /* set initial input */
    if (ds2) {
        altDialog = TRUE;
        boxName = "ALTINPBOX";
        strncpy(dlgmsg2,ds2,79); /* set display string */
        if (is2) 
            strncpy(dlginp2,is2,79); /* set initial input */
        else
            dlginp2[0] = 0;
    } else {
        altDialog = FALSE;
        boxName = "STDINPBOX";
        dlgmsg2[0] = dlginp2[0] = 0;
    }
    PreDialog();
    dlgproc = MakeProcInstance((FARPROC)StdInpDlg,(HINSTANCE)hcTInst);
    msg = DialogBox((HINSTANCE)hcTInst,boxName,CurrentWinH,
			(DLGPROC)dlgproc);
    FreeProcInstance(dlgproc);
    PostDialog();
    return(msg);
} /* editdialog */
/* ******************************************************************* */
int TUTORync_dialog(wn,msgtxt) /* yes, no, cancel dialog */
int wn; /* window where dialog will  appear */
char *msgtxt; /* message to display */
/* returns 0: yes, 1: no, 2: cancel, -3: not front window */
{   int msg; /* reply from message box */
    if (wn == ExecWn) {
	if ((HWND)(windowsP[wn].wp) != GetActiveWindow())
	    return(-3);
    }
    PreDialog();
    msg = MessageBox(CurrentWinH,msgtxt,"ctedit",
		     MB_ICONQUESTION | MB_YESNOCANCEL);
    PostDialog();
    if (msg == IDYES) return(0);
    else if (msg == IDNO) return(1);
    else return(2);
} /* TUTORync_dialog */
/* ******************************************************************* */
int TUTORok_dialog(wn,msgtxt) /* simple ok dialog */
int wn; /* window where dialog will  appear */
char *msgtxt; /* message to display */
/* returns 0: ok */
{   int msg; /* reply from message box */
    if (wn == ExecWn) {
	if ((HWND)(windowsP[wn].wp) != GetActiveWindow())
	    return(-3);
    }
    PreDialog();
    msg = MessageBox(CurrentWinH,msgtxt,"ctedit",
		     MB_ICONQUESTION | MB_OK);
    PostDialog();
    return(0);
} /* TUTORok_dialog */
/* ******************************************************************* */
TUTORinput_dialog(wn,msgStr,input)
int wn; /* window dialog should appear in */
char *msgStr; /* message to display */
char *input; /* editable reply (may have something in it to start) */
/* returns 0: ok  1: cancel */
{   int retVal; /* dialog return */
	FARPROC dlgproc; /* pointer to dialog routine */
    if (wn == ExecWn) {
	if ((HWND)(windowsP[wn].wp) != GetActiveWindow())
	    return(-3);
    }
	dlgmsg1[0] = dlgmsg1[80] = 0;
	strncpy(dlgmsg1,msgStr,80); /* set display string */
	dlginp1[0] = dlginp1[80] = 0;
	strncpy(dlginp1,input,80); /* set initial input string */
	PreDialog();
	dlgproc = MakeProcInstance((FARPROC)StdInpDlg,(HINSTANCE)hcTInst);
	retVal = DialogBox((HINSTANCE)hcTInst,"STDINPBOX",CurrentWinH,
			(DLGPROC)dlgproc);
	FreeProcInstance(dlgproc);
	PostDialog();
 
    if (retVal == IDOK) {
	    strcpy(input,dlgmsg1);
	    return(0);
    } /* IDOK if */
    return(1);
} /* TUTORinput_dialog */
/* ******************************************************************* */
BOOL FAR  CALLBACK StdInpDlg(hDlg,message,wParam,lParam)
HWND hDlg;
unsigned message;
WPARAM wParam;
LONG lParam;
{
    switch (message) {
    case WM_INITDIALOG:  /* initialize dialog box */
	    SetDlgItemText(hDlg,ID_STDINPTXT,(LPSTR)dlgmsg1);
        if (altDialog && dlgmsg2[0])
            SetDlgItemText(hDlg,ID_ALTINPTXT,(LPSTR)dlgmsg2);
	    if (dlginp1[0])
	        SetDlgItemText(hDlg,ID_STDINP,(LPSTR)dlginp1);
        if (altDialog && dlginp2[0])
            SetDlgItemText(hDlg,ID_ALTINP,(LPSTR)dlginp2);
	    dlginp1[0] = dlgmsg1[0] = '\0';
	    dlginp2[0] = dlgmsg2[0] = '\0';
	    break;
    case WM_COMMAND: /* received a command */
	    if (LOWORD(wParam) == IDOK) {
	        GetDlgItemText(hDlg,ID_STDINP,(LPSTR)dlgmsg1,79);
            if (altDialog)
                GetDlgItemText(hDlg,ID_ALTINP,(LPSTR)dlgmsg2,79);
            dlgmsg1[79] = dlgmsg2[79] = '\0'; /* insure terminated */
	        EndDialog(hDlg,LOWORD(wParam));
	    } else if (LOWORD(wParam) == IDCANCEL)
	        EndDialog(hDlg,LOWORD(wParam));
	    break;
    default:
	    return(FALSE); /* unrecognized message */
    } /* switch */
    return(TRUE);
} /* StdInpDlg */

/* ******************************************************************* */

int TUTORalert(wn,msgtxt) /* alert dialog (ok button) */
int wn; /* index of window for dialog box (not used) */
char *msgtxt; /* message to display */
{   int msg;
    PreDialog();
    msg = MessageBox(CurrentWinH,msgtxt,"cT",MB_ICONQUESTION | MB_OK);
    PostDialog();
    return(0);
} /* TUTORalert */

/* ******************************************************************* */

TUTORmulti_line_dialog(wn,msg,nmsg) /* multi-line dialog */
int wn; /* window */
char FAR *msg[8]; /* message lines */
int nmsg; /* number of message lines */

{   int mii; /* index in dialog text lines */
    char FAR *mpp; /* pointer in dialog text */
    FARPROC dlgproc; /* pointer to dialog routine */
    int ret; /* dialog reply */
  
    /* allocate buffer for message lines, copy text */

    if (nmsg > 8) 
        nmsg = 8; /* limit number of lines */

    DlgTxtBufP = TUTORalloc(640L,FALSE,"execerr");
    if (DlgTxtBufP == FARNULL)
        return(0); /* can't do dialog */

    TUTORzero(DlgTxtBufP,640L);
    mpp = DlgTxtBufP;
    for(mii=0; mii<nmsg; mii++) { /* loop thru message lines */
        strncpyf(mpp,msg[mii],78); /* copy next line to buffer */
        mpp += 80; /* advance pointer */
    } /* mii for */
    PreDialog();
	dlgproc = MakeProcInstance((FARPROC)MulMsgDlg,(HINSTANCE)hcTInst);
	ret = DialogBox((HINSTANCE)hcTInst,"MULMSGBOX",CurrentWinH,
			(DLGPROC)dlgproc);
	FreeProcInstance(dlgproc);
    PostDialog();
	return(ret);

} /* TUTORmulti_line_dialog */

/* ******************************************************************* */
BOOL FAR CALLBACK MulMsgDlg(hDlg,message,wParam,lParam)
HWND hDlg;
unsigned message;
WPARAM wParam;
LONG lParam;
{   int mii; /* index in messages */
    char FAR *mpp; /* pointer in messages */
    switch (message) {
    case WM_INITDIALOG:  /* initialize dialog box */
	if (DlgTxtBufP) {
	    mpp = DlgTxtBufP;
            for(mii=0; mii<8; mii++) {
                SetDlgItemText(hDlg,ID_MULMSGTXT1+mii,(LPSTR)mpp);
                mpp += 80;
            } /* mii for */
	    TUTORdealloc(DlgTxtBufP); /* deallocate message buffer */
	    DlgTxtBufP = FARNULL;
	} /* DlgTxtBufP if */
	    break;
    case WM_COMMAND: /* received a command */
	    if (LOWORD(wParam) == IDOK) {
	        EndDialog(hDlg,LOWORD(wParam));
	    }
	    break;
    default:
	    return(FALSE); /* unrecognized message */
    } /* switch */
    return(TRUE);
} /* MulMsgDlg */
/* ******************************************************************* */
#ifndef EXECUTE
int TUTORprefs_dialog(wn) /* preferences dialog */
int wn;
{   FARPROC dlgproc; /* pointer to dialog routine */
    int msg; /* dialog reply */
    char FAR *toP; /* to pointer for copys */
    struct PrefRec FAR *prefPtr; /* pointer to preferences data */
    int needRedraw; /* TRUE if need to redraw editor(s) */      
    int wii; /* index in edit windows */
    /* allocate buffer for dialog parameters */
    DlgTxtBufP = TUTORalloc(1024L,FALSE,"prefs");
    if (DlgTxtBufP == FARNULL)
        return(0); /* can't do dialog */
    TUTORzero(DlgTxtBufP,1024L);
    toP = DlgTxtBufP;
    /* assemble dialog parameters in buffer */
    strcpyf(toP,pffamilynP); /* font family */
    toP += strlenf(pffamilynP)+1;
    sprintf(dlgmsg1,"%d",pfsize); /* font size */
    strcpyf(toP,(char FAR *)dlgmsg1);
    toP += strlen(dlgmsg1)+1;
    strcpyf(toP,(char FAR *)PrefFaceStr(pfface)); /* font face */
    toP += strlen(PrefFaceStr(pfface))+1;
    sprintf(dlgmsg1,"%d",prfP->nTabs); /* spaces/tab */
    strcpyf(toP,(char FAR *)dlgmsg1);
    toP += strlen(dlgmsg1)+1;
    sprintf(dlgmsg1,"%ld",(long)prfP->checkTime); /* checkpoint frequency */
    strcpyf(toP,(char FAR *)dlgmsg1);
    toP += strlen(dlgmsg1)+1;
    dlgmsg1[0] = (prfP->snapShot ? 'y': 'n'); /* exec window snapshot */
    dlgmsg1[1] = 0;
    strcpyf(toP,(char FAR *)dlgmsg1);
    toP += strlen(dlgmsg1)+1;
    dlgmsg1[0] = (prfP->winSaveOnExit ? 'y': 'n'); /* window positions */
    dlgmsg1[1] = 0;
    strcpyf(toP,(char FAR *)dlgmsg1);
    toP += strlen(dlgmsg1)+1;
    dlgmsg1[0] = (prfP->debugMarkWin ? 'y': 'n'); /* debugger marker window */
    dlgmsg1[1] = 0;
    strcpyf(toP,(char FAR *)dlgmsg1);
    toP += strlen(dlgmsg1)+1;      
    dlgmsg1[0] = (prfP->wordWrap ? 'y': 'n'); /* editor word wrap */
    dlgmsg1[1] = 0;
    strcpyf(toP,(char FAR *)dlgmsg1);
    toP += strlen(dlgmsg1)+1;    
     
    /* run preferences dialog */
    PreDialog();
    dlgproc = MakeProcInstance((FARPROC)PrefDlg,(HINSTANCE)hcTInst);
    msg = DialogBox((HINSTANCE)hcTInst,"PREFBOX",CurrentWinH,
		    (DLGPROC)dlgproc);
    FreeProcInstance(dlgproc);
    PostDialog();
              
    /* check if need to redisplay edit windows */
    
    needRedraw = FALSE;     
    prefPtr = (struct PrefRec FAR *)DlgTxtBufP;
    if (msg == IDOK) {
    	if ((prefPtr->fontSize != prfP->fontSize) ||
    	    (prefPtr->fontFace != prfP->fontFace) ||
    	    (prefPtr->nTabs != prfP->nTabs) ||       
    	    (prefPtr->wordWrap != prfP->wordWrap) ||
    	    strcmpf(prefPtr->fontFamily,prfP->fontFamily)) {   
    	    needRedraw = TRUE;
    	}
    }
 	    
    /* write preferences data */
    
    if (msg == IDOK) {
	prefPtr = (struct PrefRec FAR *)DlgTxtBufP;
	msg = WritePrefs(prefPtr); /* write preferences file */
	TUTORblock_move((char FAR *)prefPtr,(char FAR *)prfP,(long)sizeof(struct PrefRec));
	PrefFont(); /* update editor font */
    }
    TUTORdealloc((char FAR *)DlgTxtBufP); /* release memory */
    DlgTxtBufP = FARNULL;
    if (!msg) {
	TUTORalert(wn,"Can't write preferences file");
    }
    
    if (needRedraw) {
    	for(wii=0; wii<EDITWINDOWLIMIT; wii++) {  
	    if (EditWn[wii] >= 0) {
		EditNewPrefs(EditWn[wii]); /* redisplay editor */
	    }
    	} /* for */
    }
    return(0);
}  /* TUTORprefs_dialog */
/* ******************************************************************* */
static int snapState = 0;
static int posState = 0;
static int wrapState = 0;
static int auxwinState = 0;
BOOL FAR CALLBACK PrefDlg(hDlg,message,wParam,lParam)
HWND hDlg;
unsigned message;
WPARAM wParam;
LONG lParam;
{   char FAR *fromP; /* from pointer for copys */
    HWND checkButton; /* handle on snapshot button */
    struct PrefRec FAR *prefPtr; /* pointer to preferences data */
    int wii; /* near int */
    long wll; /* near long */
    switch (message) {
    case WM_INITDIALOG:  /* initialize dialog box */
	fromP = DlgTxtBufP;
	SetDlgItemText(hDlg,ID_MULMSGTXT1,fromP); /* font family */
	fromP += strlenf(fromP)+1;
	SetDlgItemText(hDlg,ID_MULMSGTXT2,fromP); /* font size */
	fromP += strlenf(fromP)+1;
	SetDlgItemText(hDlg,ID_MULMSGTXT3,fromP); /* font face */
	fromP += strlenf(fromP)+1;
	SetDlgItemText(hDlg,ID_MULMSGTXT4,fromP); /* spaces/tab */
	fromP += strlenf(fromP)+1;
	SetDlgItemText(hDlg,ID_MULMSGTXT5,fromP); /* checkpoint */
	fromP += strlenf(fromP)+1;
	checkButton = GetDlgItem(hDlg,ID_SNAPSHOT);
	snapState = *fromP == 'y';
	SendMessage(checkButton,BM_SETCHECK,(int)(snapState),0L);
	fromP += strlenf(fromP)+1;
	checkButton = GetDlgItem(hDlg,ID_WINPOS);
	posState = *fromP == 'y';
	SendMessage(checkButton,BM_SETCHECK,(int)(posState),0L);
	fromP += strlenf(fromP)+1;
	checkButton = GetDlgItem(hDlg,ID_WRAP);
	wrapState = *fromP == 'y';
	SendMessage(checkButton,BM_SETCHECK,(int)(wrapState),0L);
	fromP += strlenf(fromP)+1;
	checkButton = GetDlgItem(hDlg,ID_MARKER);
	auxwinState = *fromP == 'y';
	SendMessage(checkButton,BM_SETCHECK,(int)(auxwinState),0L);
	break;
    case WM_COMMAND: /* received a command */
	if (LOWORD(wParam) == IDOK) {
	    /* extract preferences data from dialog */
	    TUTORzero(DlgTxtBufP,1024L);
	    prefPtr = (struct PrefRec FAR *)DlgTxtBufP;
	    dlgmsg1[79] = 0;
	    strcpyf(prefPtr->prefID,(char FAR *)kPrefID);      
	    prefPtr->recLen = sizeof(struct PrefRec);
	    GetDlgItemText(hDlg,ID_MULMSGTXT1,prefPtr->fontFamily,64); /* font family */
	    GetDlgItemText(hDlg,ID_MULMSGTXT2,(LPSTR)dlgmsg1,79); /* font size */
	    sscanf(dlgmsg1,"%d",&wii);
	    prefPtr->fontSize = wii;
	    GetDlgItemText(hDlg,ID_MULMSGTXT3,(LPSTR)dlgmsg1,79); /* font face */
	    prefPtr->fontFace = PrefFaceN(dlgmsg1);
	    GetDlgItemText(hDlg,ID_MULMSGTXT4,(LPSTR)dlgmsg1,79); /* spaces/tab */
	    sscanf(dlgmsg1,"%d",&wii);
	    prefPtr->nTabs = wii;
	    GetDlgItemText(hDlg,ID_MULMSGTXT5,(LPSTR)dlgmsg1,79); /* checkpoint */
	    sscanf(dlgmsg1,"%ld",&wll);
	    prefPtr->checkTime = wll;
	    prefPtr->snapShot = snapState;
	    prefPtr->winSaveOnExit = posState;    
	    prefPtr->debugMarkWin = auxwinState;
	    prefPtr->wordWrap = wrapState;     
	    prefPtr->fcolor = color_black;
	    prefPtr->bcolor = color_white; 
	    if (prfP->winSaveOnExit) {
			TUTORget_AE_win();  
			prefPtr->editWp = prfP->editWp; /* main edit window */
			prefPtr->execWp = prfP->execWp; /* executor window */
			prefPtr->msgWp = prfP->msgWp; /* message window */
			prefPtr->debugWp = prfP->debugWp; /* debug window */
			prefPtr->stackWp = prfP->stackWp; /* debug stack window */
	    }
	    /* finish this dialog */
	    EndDialog(hDlg,LOWORD(wParam));
	} else if (LOWORD(wParam) == IDCANCEL) {
	    EndDialog(hDlg,LOWORD(wParam));
	} else if (LOWORD(wParam) == ID_SNAPSHOT) {
	    snapState = !snapState;
	} else if (LOWORD(wParam) == ID_WINPOS) {
	    posState = !posState;
	} else if (LOWORD(wParam) == ID_WRAP) {
	    wrapState = !wrapState;
	} else if (LOWORD(wParam) == ID_MARKER) {
	    auxwinState = !auxwinState;
	}
	break;
    default:
		return(FALSE); /* unrecognized message */
    } /* switch */
    return(TRUE);
} /* PrefDlg */
/* ******************************************************************* */
BOOL FAR CALLBACK PrefQDlg(hDlg,message,wParam,lParam)
HWND hDlg;
unsigned message;
WPARAM wParam;
LONG lParam;
{
    switch (message) {
    case WM_INITDIALOG:  /* initialize dialog box */
	break;
    case WM_COMMAND: /* received a command */
	if ((LOWORD(wParam) == IDOK) || (LOWORD(wParam) == IDCANCEL)) {
	    EndDialog(hDlg,LOWORD(wParam));
	}
	break;
    default:
	return(FALSE); /* unrecognized message */
    } /* switch */
    return(TRUE);
} /* PrefQDlg */
#endif /* EXECUTE */
/* ******************************************************************* */
int ClosecTChildWindow(winH,mainW,eraseF,eraseC,eraseR) /* close cT button/slider window */
HWND winH; /* handle on child window */
int mainW; /* index of main (edit/execute) window */
int eraseF; /* TRUE if should erase child window area */
struct tutorColor *eraseC; /* color to erase with */
TRect FAR *eraseR; /* pointer to window region area */
{   struct tutorColor saveColor; /* saved current color */
    HWND parentW; /* handle on parent window */
    RECT wRect; /* window rectangle */
    int cwi; /* index in ct table */
    struct cTwinInf FAR *cTwinInfP; /* pointer to window data */
	
    /* destroy child window */
    DestroyWindow(winH); /* destroy child window */
    /* remove from cT table */
    cTwinInfP = (struct cTwinInf FAR *)GetPtr(cTwinInfH);
    for(cwi=0; cwi<cTwinInfN; cwi++) {
	if (cTwinInfP->hWnd == winH) {
	    cTwinInfP->type = 0; /* invalidate table entry */
	    cTwinInfP->hWnd = (HWND)FARNULL;
	    cTwinInfP->index = -1;
	    break; /* exit for */
	}
	cTwinInfP++;
    } /* cwi for */
    ReleasePtr(cTwinInfH);
	if (mainW >= 0) {
	
		/* validate button rect to suppress paint */
		
		parentW = (HWND)windowsP[mainW].wp;
		wRect.top = eraseR->top;
		wRect.left = eraseR->left;
		wRect.bottom = eraseR->bottom+1;
		wRect.right = eraseR->right+1;
		ValidateRect(parentW,&wRect);
	}
    
    /* erase child region */
    if (eraseF) {
		TUTORinq_background_color(&saveColor);
	if (eraseC->palette == color_rgb)
			TUTORset_color_rgb(1,0,eraseC->red,eraseC->green,eraseC->blue);
		else
		CTset_background_color(eraseC->palette);
        TUTORdraw_abs_solid_rect(eraseR,PAT_WHITE);
		if (saveColor.palette == color_rgb)
			TUTORset_color_rgb(1,0,saveColor.red,saveColor.green,saveColor.blue);
		else
        	CTset_background_color(saveColor.palette);
    } /* eraseF */
 
    if (mainW >= 0) {
        TUTORforward_window(mainW); /* return focus */
    }
    return(0);
} /* ClosecTChildWindow */
/* ******************************************************************* */
static int haveCMessg = 0;
StartCompileMsg(wn)
int wn;
    
{   int ii;
    int bTop,bRight;
    TRect tr;
    int tFont;
    /* draw dialog box */
    if (haveCMessg) return(0);
    bTop = windowsP[wn].wysize - 60;
    bRight = windowsP[wn].wxsize - 60;
    TUTORset_rect(&tr,30,bTop,bRight,bTop+30);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr, PAT_WHITE);
    for (ii=0; ii<3; ii++) {
        TUTORframe_abs_rect((TRect FAR *) &tr);
        TUTORinset_rect((TRect FAR *) &tr,-1, -1);
    }
    TUTORabs_move_to(35,bTop+14);
    tFont = TUTORget_zfont(DIALOGFONT,DIALOGFSIZE);
    TUTORset_textfont(tFont);
    TUTORdraw_text((unsigned char FAR *) "Compiling:",10);
    haveCMessg = 1;
    TUTORflush();
} /* StartCompileMsg */
            
/* ******************************************************************* */
EditCompileMsg(wn,ms)
int wn;
char *ms;
    
{   int bTop,bRight;
    TRect tr;
    int tFont;
    if (!haveCMessg) return(0);
    bTop = windowsP[wn].wysize - 60;
    bRight = windowsP[wn].wxsize - 60;
    TUTORset_rect(&tr,115,bTop+1,bRight-1,bTop+28);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr, PAT_WHITE);
    TUTORabs_move_to(117,bTop+14);
    tFont = TUTORget_zfont(DIALOGFONT,DIALOGFSIZE);
    TUTORset_textfont(tFont);
    TUTORdraw_text((unsigned char FAR *) ms,strlen(ms));
    TUTORflush();
} /* EditCompileMsg */
                
/* ******************************************************************* */
EndCompileMsg(wn)
int wn;
    
{
    if (!haveCMessg) return(0);
    if (wn == EditWn[0]) /* executor erases screen */
        TUTORforce_redraw(wn);
    haveCMessg = 0;
} /* EndCompileMsg */
                
/* ******************************************************************* */
