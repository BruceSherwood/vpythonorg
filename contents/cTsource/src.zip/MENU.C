
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* menu.c:  machine-independent menu routines */
/* for environments that don't have menu routines built-in. */
/* Pull-down menu support is in pulldown.c */

#include "baseenv.h"
#include "kglobals.h"
#include "tglobals.h"
#include "ecglobal.h"

#ifdef WM
#include "wmclient.h"
#endif


#ifdef ctproto
int  TutorFindCard(unsigned int  barh,char  *card);
int  TutorFindItem(unsigned int  barh,char  *item,int  cardI);
int  TutorNewCard(unsigned int  barh,char  *card,int  cp,short  *cardNN,int  cardInd);
int  TutorNewItem(unsigned int  barh,int  cardI,char  *item,int  ip,int  keyBind,int  itemI);
int  TutorDeleteCard(unsigned int  barh,int  cardI);
int  TutorDeleteItem(unsigned int  barh,int  cardI,int  itemI);
int  TutorModifyItem(unsigned int  barh,int  cardI,int  itemI,int  enableFlag,int  checkFlag,int  style);
int  TutorChangeMenuBar(unsigned int  oldBarh,unsigned int  newBarh);
int  TutorShowCard(unsigned int  barh,int  cardI);
int  MenuNames(unsigned int  mbar,int  item,char  *cardName,char  *itemName);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
char  FAR *strncatf(char  FAR *aa,char  FAR *bb,int  nn);
extern char *strcat(char *aa, char *bb);
char  FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
extern char *strcpy(char *aa, char *bb);
extern int strlen(char *str);
extern char *strncat(char *aa, char *bb, int nn);
int  strlenf(char  FAR *aa);
int  strncmpf(char  FAR *aa,char  FAR *bb,int  nn);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
char  *strf2n(char  FAR *strp);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */


extern int pd_menualt[]; /* menus altered table */

/* ******************************************************************* */

TutorFindCard(barh,card)
Memh barh;
char *card; /* card name to look for */

{       register short ii;
	TutorMenuBar FAR *bar;
	TutorMenuItem FAR *mp;
	int rVal; /* return value */

	bar = (TutorMenuBar FAR *) GetPtr(barh);
	rVal = -1; /* set for didn't find */
	for (ii=0, mp=bar->items; ii<bar->nItems; ii++, mp++) {
		if ((mp->itemKind == MENUCARD) && !strncmpf((char FAR *)card,mp->name,MENUNAMEL)) {
			rVal = ii;
			break;
		}
	} /* for */
	ReleasePtr(barh);
	return(rVal);

} /* TUTORfindCard */

/* ******************************************************************* */

TutorFindItem(barh,item,cardI)
Memh barh;
char *item; /* item name to look for */
int cardI; /* index of card info in menu list */

{       register short ii;
	TutorMenuItem FAR *mp;
	TutorMenuBar FAR *bar;
	int rVal; /* return value */

	rVal = -1; /* preset for not found */
	bar = (TutorMenuBar FAR *) GetPtr(barh);
	for (ii=0, mp=bar->items; ii<bar->nItems; ii++, mp++) {
		if ((mp->itemKind == MENUITEM) && (mp->cardI == cardI) &&
				!strncmpf((char FAR *)item,mp->name,MENUNAMEL)) {
			rVal = ii;
			break;
		}
	} /* for */
	ReleasePtr(barh);
	return(rVal);

} /* TutorFindItem */

/* ******************************************************************* */

TutorNewCard(barh,card,cp,cardNN, cardInd)
Memh barh;
char *card; /* card name */
int cp; /* unused */
short *cardNN; /* unused */
int cardInd; /* index where card info will be stored */
/* returns new card id number */

{	TutorMenuBar FAR *bar;

	bar = (TutorMenuBar FAR *) GetPtr(barh);
	bar->items[cardInd].nitems = 0; /* no items yet */
	bar->items[cardInd].width = 0; /* no items, no width */
	bar->items[cardInd].altered = TRUE; /* altered */
	ReleasePtr(barh);
	pd_menualt[CurrentWindow] = TRUE;
	return(0);

} /* TutorNewCard */

/* ******************************************************************* */

TutorNewItem(barh,cardI,item,ip,keyBind,itemI)
Memh barh;
int cardI; /* index of card information for this item */
char *item;
int ip;
int keyBind; /* if non-zero, the Mac keyBinding character -- unused */
int itemI; /* index where item info will be stored (info not there yet) */

{	TutorMenuItem FAR *mp; /* pointer to menu table entry */
	char wmstr[2*MENUNAMEL+32]; /* buffer for wm menu str */
	char bind[4]; /* buffer for key binding assembly */
	TutorMenuBar FAR *bar;

	bar = (TutorMenuBar FAR *) GetPtr(barh);
	if (!bar->theBar) {
		/* this bar isn't showing, don't tell wm anything */
		ReleasePtr(barh);
		return 0;
	} /* theBar if */

	mp = &bar->items[cardI];
	mp->altered = TRUE; /* this card altered */
	wmstr[0] = '\0';
	if (strlenf(mp->name)) {
		strncpyf((char FAR *)wmstr,mp->name,MENUNAMEL);
		sprintf(wmstr+strlen(wmstr),"~%d",mp->priority);
		strcat(wmstr,",");
	} /* card if */
	ReleasePtr(barh);
	strncat(wmstr,item,MENUNAMEL);
	sprintf(wmstr+strlen(wmstr),"~%d",ip);
	strcpy(bind,":\037x\0");
	bind[2] = itemI+32; /* set key binding for menu */
	strcat(wmstr,bind);
#ifdef WM
	if (!isx11) wm_AddMenu(wmstr); /* activate menu item */
#endif
	return 0;

} /* TutorNewItem */

/* ******************************************************************* */

TutorDeleteCard(barh,cardI)
Memh barh;
int cardI; /* index of card to delete */

{	TutorMenuBar FAR *bar;

	bar = (TutorMenuBar FAR *) GetPtr(barh);
	if (!bar->theBar) {
		/* this bar isn't showing, don't tell wm anything */
		ReleasePtr(barh);
		return 0;
	}
	if (bar->items[cardI].state == ITEMVISIBLE) {
		/* non-visible items are already deleted so far as wm is concerned */
#ifdef WM
		if (!isx11) wm_AddMenu(bar->items[cardI].name);
#endif

	}

	ReleasePtr(barh);
	pd_menualt[CurrentWindow] = TRUE;
	return 0;

} /* TutorDeleteCard */

/* ******************************************************************* */

TutorDeleteItem(barh,cardI,itemI)
Memh barh;
int cardI; /* index of card of item */
int itemI; /* index of item to be deleted */

{       char wmstr[2*MENUNAMEL+32]; /* buffer for wm menu str */
	TutorMenuBar FAR *bar;

	bar = (TutorMenuBar FAR *) GetPtr(barh);
	if (!bar->theBar) {
		/* this bar isn't showing, don't tell wm anything */
		ReleasePtr(barh);
		return 0;
	}
	bar->items[cardI].altered = TRUE;
	if (bar->items[itemI].state == ITEMVISIBLE) {
		/* non-visible items are already deleted so far as wm is concerned */
		strncpyf((char FAR *)wmstr,bar->items[cardI].name,MENUNAMEL);
		if (*wmstr) strcat(wmstr,","); /* add "," only if card has name */
		strncatf((char FAR *)wmstr,bar->items[itemI].name,MENUNAMEL);
#ifdef WM
		if (!isx11) wm_AddMenu(wmstr);
#endif

	}
	ReleasePtr(barh);
	return 0;

} /* TutorDeleteItem */

/* ******************************************************************* */

TutorModifyItem(barh,cardI,itemI,enableFlag,checkFlag,style)
Memh barh;
int cardI, itemI; /* indices into bar for card and item info */
int enableFlag; /* 1: enable, 0: disable, -1: do nothing */
int checkFlag; /* 1: check, 0: uncheck, -1: do nothing -- unused */
int style; /* 0 and up: face style for item, -1: do nothing -- unused */

{	TutorMenuBar FAR *bar;

	if (enableFlag == -1) return 0; /* only enable/disable supported by wm */

	bar = (TutorMenuBar FAR *) GetPtr(barh);
	if (!bar->theBar) {
		/* this bar isn't showing, don't tell wm anything */
		ReleasePtr(barh);
		return 0;
	} /* theBar */

	bar->items[cardI].altered = TRUE;
	if (itemI >= 0 && bar->items[cardI].state != ITEMVISIBLE) {
		/* item's card currently not showing, don't tell wm anything */
		ReleasePtr(barh);
		return 0;
	} /* itemI if */

	if (itemI < 0) {
		/* we're working on a card */
		if (!enableFlag)
			TutorDeleteCard(barh,cardI); /* disable by deleting */
		else
			TutorShowCard(barh,cardI); /* enable by recreating all the visible items on the card */
		return 0;
	} /* itemI */

	if (!enableFlag)
		TutorDeleteItem(barh,cardI,itemI); /* disable by deleting */
	else
		TutorNewItem(barh,cardI,strf2n(bar->items[itemI].name),
				bar->items[itemI].priority,0,itemI); /* enable by creating */

	ReleasePtr(barh);
	return 0;

} /* TutorModifyItem */

/* ******************************************************************* */

TutorChangeMenuBar(oldBarh,newBarh) /* switch the menus of current window */
Memh oldBarh, newBarh;

{       register short ii;
	TutorMenuItem FAR *mp;
	TutorMenuBar FAR *oldBar, FAR *newBar;

	if (newBarh == 0) return 0; /* nothing to change to */

	/* delete all the old menus */
	if (oldBarh != 0) {
		oldBar = (TutorMenuBar FAR *) GetPtr(oldBarh);
		for (ii=0, mp=oldBar->items; ii<oldBar->nItems; ii++, mp++)
			if (mp->itemKind == MENUCARD && mp->state == ITEMVISIBLE)
				TutorDeleteCard(oldBarh,ii);
		oldBar->theBar = 0; /* not showing anymore */
		ReleasePtr(oldBarh);
	} /* oldBarh if */

	newBar = (TutorMenuBar FAR *) GetPtr(newBarh);
	newBar->theBar = 1; /* now showing */

	/* add all the new menus */
	for (ii=0, mp=newBar->items; ii<newBar->nItems;ii++,mp++)
		if (mp->itemKind == MENUITEM && mp->state == ITEMVISIBLE)
			TutorNewItem(newBarh,mp->cardI,strf2n(mp->name),mp->priority,0,ii);

	ReleasePtr(newBarh);
	pd_menualt[CurrentWindow] = TRUE;

	return 0;

} /* TutorChangeMenuBar */

/* ******************************************************************* */

TutorShowCard(barh,cardI) /* recreate all visible items on a card */
Memh barh;
int cardI; /* index of card to show */

{       register short ii;
	TutorMenuItem FAR *mp;
	TutorMenuBar FAR *bar;

	bar = (TutorMenuBar FAR *) GetPtr(barh);
	if (!bar->theBar) {
		/* this bar isn't showing, don't tell wm anything */
		ReleasePtr(barh);
		return 0;
	}
	for (ii=0, mp=bar->items; ii<bar->nItems; ii++, mp++)
		if (mp->itemKind == MENUITEM && mp->cardI == cardI && mp->state == ITEMVISIBLE)
			TutorNewItem(barh,cardI,strf2n(mp->name),mp->priority,0,ii);

	ReleasePtr(barh);
	return 0;

} /* TutorShowCard */

/* ******************************************************************* */

MenuNames(mbar,item,cardName,itemName)
Memh mbar;
int item;
char *cardName, *itemName;
	
{	TutorMenuBar FAR *bp;
	TutorMenuItem FAR *ip;

	bp = (TutorMenuBar FAR *) GetPtr(mbar);
	ip = bp->items + item;

	strcpyf((char FAR *) itemName,ip->name);
	strcpyf((char FAR *) cardName,bp->items[ip->cardI].name);

	ReleasePtr(mbar);
	return 0;

} /* MenuNames */

/* ******************************************************************* */

TUTORupdate_menu_bar() /* force update of current windows menu bar */

{
    pd_menualt[CurrentWindow] = TRUE;

} /* TUTORupdate_menu_bar */

/* ******************************************************************* */
