
/*
A component of the cT (TM) programming environment.
(c) Copyright 1992 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* unit marker functions */

#include "baseenv.h"
#include "txt.h"
#include "tglobals.h"

#ifdef ctproto
int  _TUTORinternal_marker(struct  markvar FAR *mp,unsigned int  stackH,long  rloc);
int  _TUTORset_state_internal_marker(int  ind,long  pos,long  len,int  altered);
int  _TUTORinq_state_internal_marker(int  ind,long  *pos,long  *len,int  *altered);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
long  TUTORsearch_string_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sLen,long  pos,long  posEnd);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORinsert_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nIns);
long  TUTORget_len_doc(unsigned int  doc);
extern int set_unit_markers_doc(Memh sdoc);
static int find_unit_doc(Memh sdoc,long *loc); 
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
extern int sprintf(char *ss, char *form,...);
#endif

extern unsigned int TUTORnew_doc();
extern char FAR *GetPtr();
long TUTORget_len_doc();

/* ******************************************************************* */

int set_unit_markers_doc(sdoc) /* update document array of markers on units */
Memh sdoc; /* handle on source document */

{	long lastFind; /* position of previous unit/use */
	long newFind; /* position of new unit/use */
	int findT; /* type found */
	struct markvar unitMark; /* marker on unit/use */

	lastFind = newFind = 0; /* start search at begin of document */
	do {
		findT = find_unit_doc(sdoc,&newFind); /* search for next unit/use */
		if (findT == 1) { /* found a -unit- command */
			unitMark.pos = lastFind;
			unitMark.len = newFind-lastFind;
			unitMark.alteredF = 0;
			unitMark.doc = sdoc;
_TUTORinternal_marker((struct markvar SHUGE *) &unitMark,0,0L);
  
		} else if (findT == 2) { /* found a -use- command */
		
		}
	} while (findT); /* loop thru entire document */

} /* set_unit_markers_doc */

/* ******************************************************************* */

static int find_unit_doc(sdoc,loc) /* find a -unit- / -use-  command */
			/* return = 0 = no match */
			/*          1 = unit */
			/*          2 = use */
Memh sdoc; /* handle on source document */
long *loc; /* starting location for search */
           /* returned = -1 if no match, +n = position of command found */

{	int fndcmd; /* type of match found */
	long docLen; /* length of source document */
	long curLoc; /* current search location */
	long fstart; /* start of found target */
	long flen;	/* length of found target */
	char ts[3];	/* target string */
	char fs[18]; /* found string */
	char *fsp;	/* pointer in found string */
	char ns[18]; /* normalized string */
	char *nsp; /* pointer in normalized string */
	char cc; /* current character code */
	DocP dp;

	ts[0] = NEWLINE; /* search for newline, u(nit) or u(se) */
	ts[1] = 'u';
	ts[2] = 0;
	fndcmd = 0; /* nothing yet - not unit, use */

	docLen = TUTORget_len_doc(sdoc);
	curLoc = *loc; /* get starting position for search */
	
	while (curLoc < docLen) {

		/* search for next newline, u(nit) or u(se) */

		dp = (DocP) GetPtr(sdoc);
		fstart = TUTORsearch_string_doc(dp,(unsigned char FAR *) ts,2L,curLoc,docLen);
		ReleasePtr(sdoc);
		KillPtr(dp);
		if (fstart < 0)
			break; /* not found */

		/* extract and normalize possible command string */

		fstart++; /* advance past newline */
		TUTORget_string_doc(sdoc,fstart,16L,(unsigned char FAR *) fs);
		fsp = fs;	/* initialize pointers */
		nsp = ns;
		do {
			if ((cc = *fsp++) != ' ')
				*nsp++ = cc;
		} while (cc && (cc != '\t'));

		/* check for unit or use command */
		
		curLoc = fstart; /* advance for next search */
		if (strncmp(ns,"unit\t",5) == 0) {
			fndcmd = 1;
		} else if (strncmp(ns,"use\t",4) == 0) {
			fndcmd = 2;
		} /* use else if */
		if (fndcmd) {
			*loc = curLoc; /* position of "u" */
			return(fndcmd);
		} /* seekcmd if */
	} /* while */

	*loc = -1;	/* search failed */
	return(0);

} /* find_unit_doc */

/* ******************************************************************* */
