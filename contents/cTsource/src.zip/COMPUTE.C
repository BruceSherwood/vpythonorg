/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/


#include "execdefs.h"
#include "eglobals.h"
#include "ecglobal.h"
#include "tglobals.h"
#include "exprdefs.h"
#include "yacc.h"
#include "ct_ctype.h"
#include "commands.h"

#ifdef ctproto
extern int set_wk_defset(Memh setH);
double  evalduser(struct  markvar FAR *mx);
extern int  compute_expr_inf(struct  expra *uexp);
int  clear_compute_cache(void);
long  get_exec_pt(void);
int  TUTORdealloc(char  FAR *ptr);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  compile(struct  expra *exap);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  strcmpf(char  FAR *aa,char  FAR *bb);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
extern int TUTORzero(char SHUGE *ptr,long lth);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
long  TUTORget_hsize(unsigned int  mm);
int  TUTORfree_handle(unsigned int  mm);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
int  set_exec_pt(unsigned int  uloc);
int  exec_compute(short  FAR *codep);
#endif /* ctproto */

#ifdef macproto
extern int setjmp(jmp_buf env);
#endif

extern double usereval();
extern double lcitof();
extern long get_exec_pt();

/* number entries in -compute- compiled code cache */

static Memh compute_cache = 0; /* handle on -compute- cache */

/* ******************************************************************* */

/* conversion table for zreturn */
static int zerror[] = { -1, 1, 2, 6, 9, 5, 5, 7, 0, 8, 10, 11, 12};

double evalduser(mx) /* evaluate user expression */
struct markvar SHUGE *mx; /* pointer to document status block */

{	double ret; /* returned value */
	int si; /* index in sourcetable */
	int srcalloc; /* TRUE if separate source buffer allocated */
	unsigned char FAR *srcp; /* pointer to input source */
	long srcl; /* length of input source */
	int srci; /* index in input source */
	unsigned char srcbuf[304]; /* short buffer for short expressions */
	unsigned int pcodei; /* index in pcodes */
	unsigned char FAR *pcptr; /* pointer to pcodes */
	long xloc; /* current execution point */
	struct expra uexp; /* expr analyzer params */
	unsigned char FAR *cacheP; /* pointer to compute cache */
	int stringl; /* length of expression string */
	int pcodeXL; /* length of expression pcode */
	int cached; /* TRUE if this expression cached */
	long cachel; /* current size of cache */
	long cacheinc; /* cache size increase */
	int cacheLock; /* TRUE if cache locked */
	int setr; /* setjmp return */

	userExp = -1;	/* flag compile phase of -compute- type operation */
	uexp.errnum = 0; /* no error yet */
	exS.zreturn = -1; /* no error yet */
	cached = FALSE; /* assume this expression not cached */
	cacheLock = FALSE; /* cache not locked yet */
	pcptr = NULL; /* no compiled code yet */
	
	/* dump compute cache if too large */
	
	if (compute_cache) {
		if (TUTORget_hsize(compute_cache) > 2000)
			clear_compute_cache(); /* dump cache */
	} /* cache if */
	
	/* set up compute cache if not already set up */
	
	if (!compute_cache) {
		cachel = 2*sizeof(int);
		compute_cache = TUTORhandle("cmpcache",cachel,FALSE);
		cacheP = (unsigned char FAR *)GetPtr(compute_cache);
		TUTORzero((char SHUGE *)cacheP,cachel); /* pre-zero cache */
		ReleasePtr(compute_cache);
		KillPtr(cacheP);
	} /* compute_cache if */
	
	/* get expression string from marker */
	
	srcl = mx->len; /* get length of input */
	if (srcl <= 300) {
		srcp = &srcbuf[0]; /* use short local buffer */
		srcalloc = FALSE; /* no need to allocate buffer */
	} else {
		srcp = (unsigned char FAR *) TUTORalloc(srcl+4L,TRUE,"comput");
		srcalloc = TRUE;
	}
	*srcp = '\0';
	TUTORget_string_doc(mx->doc,mx->pos,srcl,srcp);
	srcp[srcl++] = NEWLINE;
	srcp[srcl++] = '\0';
	srcl = (srcl & 0x7ffc)+4; /* 32 bit boundary */
	
	/* check if compiled p-code already available */
	/* compute_cache locked here */
		
	cacheP = (unsigned char FAR *)GetPtr(compute_cache);
	cacheLock = TRUE;
	while (*((int FAR *)cacheP) && (pcptr == NULL)) {
		stringl = *((int FAR *)cacheP);
		cacheP += sizeof(int);
		pcodeXL = *(int FAR *)(cacheP);
		cacheP += sizeof(int);
		if (strcmpf((char FAR *) srcp,(char FAR *) cacheP) == 0) {
			pcptr = cacheP+stringl; /* set addr of p-code */
			cached = TRUE; /* already in cache */
		}
		cacheP += stringl+pcodeXL; /* advance to next item */
	} /* while */

	/* compile expression if not already compiled */

	if (!cached) { 
		if (cacheLock) {
			ReleasePtr(compute_cache);
			KillPtr(cacheP);
		}
		cacheLock = FALSE;
		exS.loopcounter += 10; /* crude accounting for expensive operation */

		/* set up source and pcode buffers */

		pcptr = (unsigned char FAR *)(TUTORalloc(2000L,TRUE,"comput"));
		pcodei = srci = 0; /* initialize index in soruce, pcodes */

		/* set up user -define- variables */

		compunit = exS.execunit;
		si = unittab[exS.execunit].beginfile; /* get current source file */
		userSetH = sourcetable[si].userdefsetH;
		set_wk_defset(userSetH);

		/* set up expression analyzer params */

		uexp.teol = TRUE;      /* eol is legal terminator */
		uexp.tcomma = FALSE;   	
		uexp.tsemic = FALSE;
		uexp.tassign = FALSE;
		uexp.tcolon = FALSE;
		uexp.tparen = FALSE;
		uexp.tembed = FALSE;
		uexp.tcond = FALSE;
		uexp.tpercent = FALSE;
		uexp.userc = TRUE;      /* -compute- */
		uexp.userd = FALSE;		/* not debug */
		uexp.reqstore = FALSE;  /* storability info not required */
		uexp.arrayok = FALSE;   /* whole array not allowed */
		uexp.allowsk = FALSE;   /* SKIP not allowed */
		uexp.allowf = FALSE;    /* file variable not allowed */
		uexp.allowm = FALSE;    /* marker result not allowed */
		uexp.mfunctst = TRUE;   /* marker functions are store-able */
		uexp.calc = FALSE;      /* not -calc- command */
		uexp.nogen = FALSE;		/* do generate pcode */
		uexp.rtype = TFLOAT;    /* numeric (float) result required */
		uexp.text = HNULL;       /* no styled string literals */
		uexp.src = srcp;        /* source input from srcp, srci */
		uexp.srcpos = &srci;
		uexp.pcode = pcptr; /* pcode output to buffer */
		uexp.pcodepos = &pcodei;

		/* set up to handle error and compile expression */

		if (setr = setjmp(uenv)) {
			uexp.errnum = setr;
			if (uexp.errnum == USERERR) uexp.errnum = 0;
		} else 
			compile(&uexp); /* compile expression */

		pcptr[pcodei++] = 0; /* insert zero code at end */
		pcptr[pcodei++] = 0;
		pcodei = (pcodei & 0x7ffc)+4; /* 32-bit boundary */

		compute_expr_inf(&uexp); /* set up reserved words */

		if (xtP) { /* free expression analyzer table */
			ReleasePtr(xtH);
			xtP = NULL;
		}
		
		/* check if error in compile phase */

		if (exS.zreturn != -1) {
			if (cacheLock) {
				ReleasePtr(compute_cache); /* release lock on cache */
				KillPtr(cacheP);
			}
			if (srcalloc) 
				TUTORdealloc((char FAR *) srcp); /* release source buffer */
			TUTORdealloc((char FAR *) pcptr); /* release p-code buffer */
			userExp = 0; /* clear user expression flag */
			return(0.0);
		} /* error if */
	} /* not cached if */

	/* set up to handle error and execute expression */

	xloc = get_exec_pt(); /* get current execution loc */
	userExp = 1; /* execution phase */
	if (uexp.errnum = setjmp(uenv)) { 
		ret = 0.0; /* no result if error */
		exS.zreturn = ((uexp.errnum <= 12) ? zerror[uexp.errnum]: 1);
	} else {
		exec_compute((short FAR *)pcptr); /* execute expression */
		ret = fstack[0];
	} /* errnum else */
	userExp = 0; /* clear user expression flag */

	fresP = fstack; /* void stacks */
	iresP = istack;
	markP = markstack;
	set_exec_pt((unsigned int)xloc); /* restore execution addr */

	/* add expression and p-code to cache */
	
	if (!cached) {
	
		/* enlarge cache for new source and p-code */
		
		cachel = TUTORget_hsize(compute_cache);
		cacheinc = srcl+pcodei+2*sizeof(int);
		if (cacheLock) {
			ReleasePtr(compute_cache); /* release lock on cache */
			KillPtr(cacheP);
		}
		cacheLock = FALSE;
		TUTORset_hsize(compute_cache,cachel+cacheinc,TRUE);
		
		/* shove current contents of cache down */
	
		cacheP = (unsigned char FAR *)GetPtr(compute_cache);
		cacheLock = TRUE;
		TUTORblock_move((char SHUGE *) cacheP,(char SHUGE *) (cacheP+cacheinc),cachel);
		
		*(int FAR *)(cacheP) = srcl; /* length of source string */
		cacheP += sizeof(int);
		*(int FAR *)(cacheP) = pcodei; /* length of p-code */
		cacheP += sizeof(int);
		strcpyf((char FAR *) cacheP,(char FAR *) srcp); /* add expression source string */
		cacheP += srcl;
		TUTORblock_move((char SHUGE *) pcptr,(char SHUGE *) cacheP,(long)pcodei); /* add p-code */
		TUTORdealloc((char FAR *)pcptr); /* release p-code buffer */
	}
	if (cacheLock) {
		ReleasePtr(compute_cache); /* release lock on cache */
		KillPtr(cacheP);
	}
	if (srcalloc) 
		TUTORdealloc((char FAR *) srcp); /* release source buffer */

	return(ret);

} /* evalduser */

/* ******************************************************************* */

static compute_expr_inf(uexp) 
/* set up reserved words for compute command compile/execute */
struct expra *uexp; /* expr analyzer params */

{
	exS.arr.zopcnt = uexp->opcnt;
	exS.arr.zvarcnt = uexp->varcnt;
	exS.zreturn = ((uexp->errnum <= 12) ? zerror[uexp->errnum]: 1);
	if (uexp->errnum != 0) return(0);
	if (checkbit(exS.arr.specsbits,NOOPS) && (exS.arr.zopcnt != 0) ) {
		exS.zreturn = 0; 
		return(0); 
	}
	if (checkbit(exS.arr.specsbits,NOVARS) && (exS.arr.zvarcnt != 0) ) {
		exS.zreturn = VARCNTERR; 
		return(0); 
	}
	if (!checkbit(exS.arr.specsbits,OKASSIGN) && (uexp->assigned) ) {
		exS.zreturn = NOTOKASSIGN; 
		return(0); 
	}

} /* compute_expr_inf */

/* ******************************************************************* */

clear_compute_cache() /* release -compute- command cache */

{
	if (compute_cache)
		TUTORfree_handle(compute_cache);
	compute_cache = HNULL;

} /* clear_compute_cache */

/* ******************************************************************* */
