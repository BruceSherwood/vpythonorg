/* A component of the cT (TM) programming environment. (c) Copyright 1989
 * Carnegie Mellon University. cT is a trademark of Carnegie Mellon
 * University. All rights reserved. May not be copied without the written
 * consent of Carnegie Mellon University. */

/* Control execution of cT. */

#include <stdio.h>
#include "execdefs.h"
#include "tfiledef.h"
#include "tglobals.h"
#include "eglobals.h"
#include "editmenu.h" 
#include "editor.h"
#include "fkeys.h"
#include "exprdefs.h"
#include "kglobals.h"
#include "commands.h"
#include "ecglobal.h"

#ifdef ctproto
extern int TUTORsize_exec_window(int wx,int wy);
extern int DebugHalt(void);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
int  GetUnitName(int  unitn,unsigned char  *name);
int  TUTORforce_redraw(int  wix);
extern int TUTORupdate_button_value(Memh objH);
extern int TUTORis_foreground(int wix);
extern int TUTORok_dialog(int wn,char *msg);
extern int checkRadians(void);
extern int get_dde_ref(Memh dH);
extern int set_last_dde(Memh objH,int ref);
extern int dde_event(struct tutorevent *event);
extern int TUTORset_sub_new(int sub,int new);
extern int setedittouch(struct tutorevent FAR *event);
extern int ExecJumpout(struct tutorevent FAR *ev);
extern int MovieClose(int type);
extern int TUTORzero(char SHUGE *ptr,long length);
extern int TUTORdeferred_free(Memh hh);
extern int post_event_unit(void);
extern int filter_control_keys(struct tutorevent *event);
static int DoEventUnit(int inexec,struct tutorevent *event,int unitN,int unitF,double unitA);
extern int procxtxtevent(struct tutorevent *event);
int  TUTORdelete_menu(unsigned int  barh,char  *card,char  *item);
int  TUTORadd_menu(unsigned int  barh,char  *card,int  cp,char  *item,int  ip,int  keyBind,int  type,int  unit,double  unitArg,int  eType);
extern int display_snapShot(void);
int  lclocy(long  q);
int  lclocx(long  q);
long  TUTORabs_save_region(int  x1,int  y1,int  x2,int  y2);
int  TUTORfree_region(long  id);
int  TUTORabs_restore_region(long  id,int  x1,int  y1);
extern int post_toedit(void);
extern int get_button_ref(Memh bH);
extern int get_slider_ref(Memh sH);
int  TUTORclose_button(unsigned int  bH);
int  TUTORclose_sbar(unsigned int  theSBar);
int  TUTORclose_panel(unsigned int  theV);
int object_close(unsigned int  objH);
extern int TUTORlog(char *str);
extern int StartPicture(int type,int fileid,TRect FAR *pRect,int dpi);
extern int FinishPicture(void);
extern int set_array_addresses(void);
extern int release_dyn_arrays(void);
int TUTORinq_slider_busy(void);
int FullScreenErase(void);
int  procexecw(unsigned int  execH,struct  tutorevent *event);
extern int  procarrow(struct  tutorevent *event);
extern int  mycheckenable(int  enablebits,struct  tutorevent FAR *event);
extern int free_snapShot(void);
int  procexec(unsigned int  viewH,struct  tutorevent *event);
int  FullHalt(void);
int  Halt(void);
int  Run(void);
int  RunFromUnit(int  unitn);
int  RunOneUnit(int  unitn);
extern int  RunUnits(int  current,int  unitn);
int  MakeMenus(void);
extern int  Rerun(void);
int  shouldint(void);
int  preexec(void);
int  TimedPauseOvl(void);
int  afterpause(void);
extern int  convertkey(int  c);
extern int  processevent(struct  tutorevent *event);
int  RunOnEvent(struct  tutorevent FAR *event);
int  clearkeys(void);
int  setkey(int  cc);
int seteditkey(int cc);
int  settouchkey(struct  tutorevent FAR *event);
int  GraphScale(long  fnx,long  fny,double  *cx,double  *cy);
int  RelativeScale(long  fnx,long  fny,double  *cx,double  *cy);
int  checkkey(int  key);
int  enable(int  bits);
int  LockExec(void);
int  UnlockExec(void);
unsigned char  SHUGE *LockStack(void);
int  ReleaseStack(void);
int  TUTORset_view(struct  tutorview FAR *vp);
int  DoMenuUnit(int inexec,int  unitn,int  paramf,double  param);
int  set_last_slider(unsigned int  objH,int refc);
int  set_last_button(unsigned int  objH,int refc);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  set_last_edit(unsigned int  objH,int ref);
int  TUTORfree_event_memory(struct  tutorevent FAR *event);
int  TUTORclear_window(int  wid);
int  TUTORforward_window(int  wix);
int  TUTORpost_event(struct  tutorevent *event);
int  TUTORpoll_events(int  block);
int  ReMsg(void);
int  TUTORclip_window(int  wid);
int  TUTORset_abs_view_rect(int  x1,int  y1,int  w,int  h);
int  ReshowArrow(int  clearF,int  wclear);
struct  tutorview FAR *findview(int  ww,int  xx,int  yy);
int  ResizeArrowView(int  nc);
struct  tutorview FAR *TUTORinq_view(void);
int  CTpalette(int  wn,unsigned int  newPal,int  newFlag,unsigned int  defPal);
int  ExecMenus(void);
int  DeleteAllAuthorMenus(void);
int  TUTORfree_handle(unsigned int  mm);
int  SetFlushState(int  flag);
int  TUTORset_fill(int  fInd,int  fChar);
int  TUTORnormal_cursor(void);
int  unclip(void);
int  mvar_temp_cleanup(void);
int  mvar_assign(struct markvar SHUGE *vaddr,struct  markvar SHUGE *mx);
int  items_close(int  unitn,long  stacki,int  vars,int  graphics);
int  unstack_all_units(void);
int  CloseAllFiles(void);
int  clear_compute_cache(void);
int  TUTORtrace(char  *s);
int  flush(void);
int  grafedit(struct  tutorevent *evp);
int  InitExecution(void);
int  DeleteExecMenus(void);
int  myexit(void);
int  TUTORclear_screen(void);
long  IntToCoord(int  xx);
int  TUTORinq_abs_screen_size(int  *x,int  *y,int  *dx,int  *dy);
int  TUTORset_menubar(unsigned int  barh,struct  tutorview FAR *newMenuView);
int  CTset_window_color(int  cn);
int  CTset_background_color(int  color);
int  CTset_foreground_color(int  color);
int  ChangeEditMenus(int  onOff);
int  LocateUnit(Memh doc,long  pos);
int  GetSelect(unsigned int  theV,long  *pos,long  *len);
int  CompileProgram(int  wix,int  binf,int  mFlag);
int  CountNeedsCompiled(void);
int  StartCompileMsg(int  wn);
int  EditConvert(void);
int  TUTORdealloc(char  FAR *ptr);
int  FindUnits(void);
int  TUTORdelete_author_menus(unsigned int  barh);
int  TUTORstop_sound(void);
int  CancelTrigger(int  id);
int  TUTORcancel_all_events(void);
int  executor(void);
int  InsureUnit(int  unitn);
int  InitMainUnit(int  reshape,int  ieu);
int  TutorCountMenuItems(void);
int  TUTORdump(char  *s);
int  TUTORinq_wmg_busy(int  window);
int  TUTORshould_interrupt(void);
int  mvar_cache_ovr(void);
int  setclip(void);
int  ResetFine(void);
int  TUTORpush_event(struct  tutorevent *event);
int  set_exec_pt(unsigned int  uloc);
double  CoordToFloat(long  xx);
extern double atan2(double x, double y);
extern double sqrt(double x);
extern double pow(double x,double y);
long  DivCoord(long  xx,long  yy);
int  assign_pfun(long  addr,long  pfunct);
#endif /* ctproto */


#ifdef macproto
extern int  DeactivateColor(void);
extern int  WindowFocus(long theW);
extern void TUTOR68030_cache(void);
#endif

extern struct tutorview FAR *TUTORinq_view();
extern Memh darrowv();
extern Memh arrowv();
extern int  Run();
extern int  procexecstub();
extern Memh TUTORinit_menubar();
extern unsigned char SHUGE *LockStack();
struct tutorview FAR *findview();
extern int object_close();
extern long  TUTORabs_save_region();

extern int  logcmd;

/* ******************************************************************* */

procexecw(execH, event)
Memh execH;
struct tutorevent *event;

{   struct tutorview FAR *viewp;
    struct tutorevent sevent; /* single-key event */
    int wid;    /* window index of this executor window */
    Memh objH; /* handle on object header */
    struct ebshdr FAR *objP; /* pointer to object header */
    int objUsers; /* number users of object */
    int ii,jj;
    unsigned char cc;
    struct tutorview FAR *txtvp; /* pointer to editable text view */
    TextVDat FAR *tpp; /* pointer to text panel */
    int unitF; /* unit arguments flag */
    int unitN; /* unit number */
    double unitA; /* unit pass-by-value argument */
    int objtype; /* type of (button, slider) object */
    int objref; /* reference count of object */
    int refcnt; /* reference count of object */
    int doBeforeEventUnit; /* TRUE if should execute unit for event */
    int isKey; /* TRUE if KEY/FKEY event */
    int key; /* current key value */

    doBeforeEventUnit = FALSE;
    if (event->window < 0) {
        /* window field isn't set, figure it out */
        wid = ExecWn;
        if (wid < 0)
        	return(0);
    } else
        wid = event->window;

    /* all events for arrow go to base view */
    if (event->view == exS.arr.aView)
        event->view = exS.baseView;

    switch (event->type) {

    case EVENT_REDRAW:
        if (runflag == halt) {
            TUTORset_view(ExecVp);
            TUTORclear_window(wid);
        	display_snapShot(); /* restore window if neccessary */
        }
        viewp = windowsP[wid].lastView;
        while (viewp) {
            TUTORset_view(viewp);
            (*viewp->vproc) (viewp->vh, event);
            if (runflag == halt)
                break; /* just redraw executor base view */
            viewp = viewp->prevView;
        }
        event->type = -1;   /* we handled it already */
        break;

    case EVENT_FWD:
#ifdef MAC
        viewp = windowsP[wid].firstView;
        while (viewp) {
            TUTORset_view(viewp);
            (*viewp->vproc) (viewp->vh, event);
            viewp = viewp->nextView;
        }
#endif
        event->type = -1;
        break;

    case EVENT_HOT:
        TUTORfree_event_memory((struct tutorevent FAR *)event);
        event->type = -1; /* event processed here */
        if (!event->a5) /* exit if no view */
            break;
        txtvp = (struct tutorview FAR *)(event->a5);
        if (txtvp->refc != event->a2) /* exit if not correct view */ 
            break;
        if (!txtvp->vh) /* exit if no text panel */
            break;
            
        /* block events if already processing */
        
        if (exS.proc_obj_unit) {
            if (nevents < (EVENTLIMIT-2)) {
                event->timestamp = 0;
                event->type = EVENT_HOT; /* re-set type */
                TUTORpush_event(event); /* re-post event */
            }
            event->type = -1; /* no-op this time */
            break;
        }
        
        /* detach from last "zedit" panel */

        exS.last_edit = HNULL;

        /* execute "hot" unit */

        tpp = (TextVDat FAR *)GetPtr(txtvp->vh);
        set_last_edit(tpp->ebshdrH,tpp->ebsref); 
        unitF = tpp->hotunitF; /* unit/argument flag */
        unitN = tpp->hotunitN; /* get unit number */
        unitA = tpp->hotunitA;
        if (tpp->ebshdrH) {
            objP = (struct ebshdr FAR *)GetPtr(tpp->ebshdrH);
            if (objP->refcnt != tpp->ebsref)
                unitF = 0; /* edit object no longer valid */
            ReleasePtr(tpp->ebshdrH);
            KillPtr(objP);
        }
        ReleasePtr(txtvp->vh);
        KillPtr(tpp);
        if (!unitF)
            break; /* no unit to do */
        unitF = (unitF == 2); /* TRUE if argument */
        TUTORset_view(ExecVp);
        if (unitN != UNITX)
            exS.proc_obj_unit = unitN;
        DoMenuUnit(FALSE,unitN,unitF,unitA);
        break;
    
    case EVENT_SIGNAL:
        if (runflag == halt) {
            event->type = -1;
            if (event->eDataP)
            	TUTORdealloc(event->eDataP);
			event->eDataP = FARNULL;
            break; /* don't do anything if halted */
        }

        /* determine type and validity of ct object */

        objtype = 0; /* type unknown */
        objH = event->a2; /* get handle on header */
        if (objH) {
            objP = (struct ebshdr FAR *)GetPtr(objH);
            if (event->a6 == objP->refcnt) 
            	objtype = objP->type;
            else event->type = -1; /* kill event */
            ReleasePtr(objH);
            KillPtr(objP);
        }

        /* block button/slider/touch events if already processing */
        
        if (exS.proc_obj_unit && 
           ((objtype == TXBUTTON) || (objtype == TXSLIDER) ||
	   		(objtype == TXTOUCH) || (objtype == TXDDE))) {
            if (nevents < (EVENTLIMIT-2)) {
                event->timestamp = 0;
                TUTORpush_event(event); /* re-post event */
            }
            event->type = -1; /* no-op this time */
            break;
        }
        
        /* detach from last "zbutton" or "zslider" */

        if (objtype == TXBUTTON) {
            exS.last_button = HNULL;
        } else if (objtype == TXSLIDER) {
            exS.last_slider = HNULL;
        } else if (objtype == TXTOUCH) {
	    	exS.last_touch = HNULL;
		} else if (objtype == TXDDE) {
	    	exS.last_dde = HNULL;
		}


        /* execute button, touch or slider unit */

		if (event->type == EVENT_SIGNAL) { /* event not canceled */
			        
			/* set new "zbutton" or "zslider" */
	
	        objH = 0; /* no new handle yet */
			if ((objtype == TXBUTTON) || (objtype == TXSLIDER) || (objtype == TXDDE) || 
			    (objtype == TXTOUCH)) {
	            objH = event->a2;
	        }
	    
	        if (objH) {
	            if (objtype == TXBUTTON) {
	                refcnt = get_button_ref(objH);
	                set_last_button(objH,refcnt);
	                TUTORupdate_button_value(objH);
	            } else if (objtype == TXSLIDER) {
	                refcnt = get_slider_ref(objH);
	                set_last_slider(objH,refcnt);
		    	} else if (objtype == TXDDE) {
					refcnt = get_dde_ref(objH);
					set_last_dde(objH,refcnt);
		    	}
	        }

	        if (event->a1 == BUTTONSIGNAL) {
	            exS.proc_obj_unit = event->value;
	            TUTORset_view(ExecVp);
		    	if ((objtype == TXTOUCH) && event->eDataP)
					settouchkey((struct tutorevent FAR *) event->eDataP);
		    	else if ((objtype == TXDDE) && event->eDataP)
					dde_event(event);
	            DoMenuUnit(FALSE,event->value,FALSE,0.0);
	            event->type = -1; /* nothing further to do */
	        } else if (event->a1 == BUTTONSIGNALA) {
	            exS.proc_obj_unit = event->value;
	            TUTORset_view(ExecVp);
		    	if ((objtype == TXTOUCH) && event->eDataP)
					settouchkey((struct tutorevent FAR *) event->eDataP);
		    	else if ((objtype == TXDDE) && event->eDataP)
					dde_event(event);
	            DoMenuUnit(FALSE,event->value,TRUE,event->a3);
	            event->type = -1; /* nothing further to do */
	        } else { 
	            event->type = -1; /* ignore non-button signals */
	        }
	    }
        if (event->eDataP)
        	TUTORdealloc(event->eDataP); /* release storage for saved event */
		event->eDataP = FARNULL;
        break;
    
    case EVENT_FKEY:
    case EVENT_KEY:
    case EVENT_LEFTDOWN:
    case EVENT_LEFTUP:
    case EVENT_RIGHTDOWN:
    case EVENT_RIGHTUP:
    case EVENT_DOWNMOVE:
    case EVENT_UPMOVE: 
    	if ((event->type == EVENT_KEY) || (event->type == EVENT_FKEY))
    		isKey = TRUE;
    	else isKey = FALSE;
                
        /* pass key to arrow if waiting at arrow */
        
        if (waitflag == atarrow && event->view == exS.baseView) {
            /* special handling for arrow events */
            if (isKey)
            	filter_control_keys(event);
            procarrow(event);
            event->type = -1;
            break;
        } /* else they go where they would normally */
            
        /* block object events if already processing */
        
        if ((event->type >= 0) && event->view && 
             event->view->objectH) { /* object of some sort */
            if (exS.proc_obj_unit) {
                if (nevents < (EVENTLIMIT-2)) {
                    event->timestamp = 0;
                    TUTORpush_event(event); /* re-post event */
                }
                event->type = -1; /* no-op this time */
                break;
            } 
		}
		
		/* process text panel */
		
		if ((event->type >= 0) && event->view && 
             event->view->objectH && (event->view->objectT == TXEDIT)) {
             
            /* process editor text-panel key(s), mouse events */
            
            if ((event->type == EVENT_KEY) && (event->nkeys > 1)) {
            
                /* break-up multi-key event */
                
                sevent = *event; /* take copy of event */
                sevent.nkeys = 1; /* process first key only */
                for(ii=1; ii<event->nkeys; ii++) /* shove keys down */
                    event->keys[ii-1] = event->keys[ii];
                event->nkeys--;
                TUTORpush_event(event); /* re-post event */
                doBeforeEventUnit = procxtxtevent(&sevent); 
            } else {
                doBeforeEventUnit = procxtxtevent(event);
            }
            if (!doBeforeEventUnit) { /* no before-event unit */
                unitF = exS.post_unitF;
                exS.post_unitF = 0;
                /* pass event to text panel */
                if (event->type > 0 && event->view) {
                    TUTORset_view(event->view);
                    (*event->view->vproc) (event->view->vh, event);
                }
                /* execute after-event unit */
                exS.hold_event.type = -1; /* no pending event */
                if (unitF)
                    DoEventUnit(FALSE,event,exS.post_unitN,unitF,
                      exS.post_unitA); /* execute key processing unit */
            } /* doBeforeEventUnit else */
            event->type = -1; /* event handled */
        } /* event->view if */

        break;
    
    case EVENT_MENU:
        if (waitflag == atarrow && event->view == exS.baseView)
            { /* special handling for arrow events */
            procarrow(event);
            event->type = -1;
            }
        else
            event->view = exS.baseView; /* send to executor view first */
        break;
    
    default:
        if (waitflag == atarrow && event->view == exS.baseView)
            { /* special handling for arrow events */
            procarrow(event);
            event->type = -1;
            }
        /* otherwise send event to view (button, slider, etc.) */
        break;
    }

    if ((exS.proc_obj_unit < 0) || (exS.proc_obj_unit == UNITX))
        exS.proc_obj_unit = 0; /* forget it if didn't really execute */
        
    /* pass on events we didn't handle */
    if (event->type > 0 && event->view) {
        TUTORset_view(event->view);
        (*event->view->vproc) (event->view->vh, event);
    }
    
    return(0);
    
} /* procexecw */
                
/* ******************************************************************* */

static int filter_control_keys(event)
struct tutorevent *event; /* key/fkey event */

{   int ii,jj,cc;
    
    /* swallow control keys */
        
    if (event->type == EVENT_KEY) {
        jj = 0;
        for (ii = 0; ii<event->nkeys; ii++) {
            cc = event->keys[ii];
            if (cc >= 32 || cc == NEWLINE || cc == '\b' || cc == '\t')
                 event->keys[jj++] = cc;
        } /* for */
        event->nkeys = jj;
    } /* key if */
    return(0);

} /* filter_control_keys */
                
/* ******************************************************************* */

static int procxtxtevent(event) /* process executor text-panel event */
struct tutorevent *event; /* key/mouse event */

{   struct tutorview FAR *txtvp; /* pointer to editable text view */
    TextVDat FAR *tpp; /* pointer to text panel */
    int unitF; /* unit/argument flag */
    int unitN; /* unit number */
    double unitA; /* unit argument */
    int key; /* current key value */
    int doUnit; /* TRUE if will do a "before event" unit */
    int euI; /* index in event units */
    
    doUnit = FALSE;
    if (exS.proc_obj_unit || (event->type < 0)) 
    	return(0);
    txtvp = event->view;
    if (txtvp->objectH == HNULL) /* no text object */
        return(0);
        
    /* determine type of event */
    
    euI = -1;
    if ((event->type == EVENT_KEY) || (event->type == EVENT_FKEY))
    	euI = 0; /* 0 = before event key, 1 = after event key */
    else if (event->type == EVENT_LEFTDOWN)
    	euI = 2; /* 2 = before event left-down, 3 = after event left-down */
    else if (event->type == EVENT_LEFTUP)
    	euI = 4; /* 4 = before event left-up, 5 = after event left-up */
    else if (event->type == EVENT_RIGHTDOWN)
    	euI = 6; /* 6 = before event right-down, 7 = after event right-down */
    else if (event->type == EVENT_RIGHTUP)
    	euI = 8; /* 8 = before event right-up, 9 = after event right-up */
    else if (event->type == EVENT_DOWNMOVE)
    	euI = 10; /* 10 = before event down-move, 11 = after event down-move */
    if (euI < 0)
    	return(0); /* didn't recognize event */
        
    /* look for before+after event unit */
    
    unitF = exS.post_unitF = FALSE;
    exS.hold_objectH = txtvp->objectH;
    exS.hold_event = *event; /* save copy of event */
    exS.hold_event.origin = 5;
    tpp = (TextVDat FAR *)GetPtr(txtvp->objectH);
    if (tpp->eventunitF[euI]) {
    
        /* set up before-event unit */
        
        unitF = tpp->eventunitF[euI]; /* unit/argument flag */
        unitN = tpp->eventunitN[euI]; /* get unit number */
        unitA = tpp->eventunitA[euI];         
    } /* bkeyunitF if */
    
    if (tpp->eventunitF[euI+1]) {

        /* set up after-event unit */
                
        exS.post_unitF = tpp->eventunitF[euI+1]; /* unit/argument flag */
        exS.post_unitN = tpp->eventunitN[euI+1]; /* get unit number */
        exS.post_unitA = tpp->eventunitA[euI+1];         
    } /* akeyunitF if */
    ReleasePtr(txtvp->objectH); /* let go of pointer */
    KillPtr(tpp);
    
    /* execute before-event unit */
    
    if (unitF) {
        DoEventUnit(FALSE,event,unitN,unitF,unitA);
        doUnit = TRUE;
    }
    
    return(doUnit);
    
} /* procxtxtevent */

/* ******************************************************************* */

static int DoEventUnit(inexec,event,unitN,unitF,unitA)
int inexec; /* TRUE if in executor (executing commands) */
struct tutorevent *event; /* key/mouse event */
int unitF; /* 0 = no unit, 1 = unit, no arg, 2 = unit+arg */
int unitN; /* unit number */
double unitA; /* unit argument */

{   struct tutorview FAR *txtvp; /* pointer to editable text view */
    TextVDat FAR *tpp; /* pointer to text panel */
    int key; /* current key value */

    if (!unitF) 
    	return(0); /* nothing to do */
    txtvp = event->view;
    if (txtvp->objectH == HNULL)
    	return(0); /* nothing to do */
    	
    TUTORset_view(ExecVp); /* set to executor view */
    exS.last_edit = HNULL;
    tpp = (TextVDat FAR *)GetPtr(txtvp->objectH);
    set_last_edit(tpp->ebshdrH,tpp->ebsref); 
    ReleasePtr(txtvp->objectH);
    KillPtr(tpp);
    exS.proc_obj_unit = unitN;
    unitF = (unitF == 2); /* TRUE if argument */
    if (event->type == EVENT_KEY) {
        key = event->keys[0];
        if (!event->pressed)
            key = convertkey(key); /* we convert unpressed keys */
        seteditkey(key);
        DoMenuUnit(inexec,unitN,unitF,unitA);
    } else if (event->type == EVENT_FKEY) { 
        key = event->value;
        seteditkey(key);
        DoMenuUnit(inexec,unitN,unitF,unitA);
    } else { /* mouse event */
    	setedittouch(event);
    	DoMenuUnit(inexec,unitN,unitF,unitA);
    } /* type else-if */

} /* DoEventUnit */

/* ******************************************************************* */
    
int post_event_unit() /*  finish processing after before-event unit */
/* pass event on to text panel, execute after-event unit */

{   int unitF; /* post-event unit argument flag */

    if (!exS.proc_obj_unit)
        return(0); /* nothing to do */      
    exS.proc_obj_unit = 0; /* done with button/edit/etc unit */
    
    if ((exS.hold_event.type < 0) || (!exS.hold_objectH))
        return(0); /* nothing to do */
    exS.hold_objectH = HNULL; /* don't do this event again */
        
    /* pass on events that weren't canceled */

    if (exS.hold_event.view) {
        if (exS.hold_event.type == EVENT_KEY) {
            filter_control_keys(&exS.hold_event);
            if (exS.hold_event.nkeys == 0) /* nothing left */
                exS.hold_event.type = -1;
        } /* type if */
        if (exS.hold_event.type >= 0) {
            TUTORset_view(exS.hold_event.view);
            (*exS.hold_event.view->vproc) (exS.hold_event.view->vh, 
              &exS.hold_event);
        } /* type if */
    } /* type/view if */

    /* do post-event processing if neccessary */
    
    if (exS.post_unitF) {
        unitF = exS.post_unitF;
        exS.post_unitF = 0;
        if (exS.hold_event.type > 0)
            DoEventUnit(TRUE,&exS.hold_event,exS.post_unitN,unitF,
                   exS.post_unitA); /* execute key processing unit */
    } /* post_unitF if */
    
    return(0);

} /* post_event_unit */

/* ******************************************************************* */

display_snapShot() /* restore executor window if neccessary */

{   struct tutorview FAR *cv;

    if (exS.snapShotH && (runflag == halt)) {
        if ((exS.sswx == windowsP[ExecWn].wxsize) &&
            (exS.sswy == windowsP[ExecWn].wysize)) {
            cv = TUTORinq_view(); /* get current view */
            if (cv != ExecVp) 
                return; /* do nothing unless in execute view */
            TUTORabs_restore_region((long)exS.snapShotH,
                    exS.ssx1,exS.ssy1);
        } else { /* destroy image if window size changed */
            free_snapShot();
        }
    }
        
} /* display_snapShot() */

/* ******************************************************************* */

static procarrow(event) /* handle events when arrow is present */
struct tutorevent *event;

{   int restartExec;    /* TRUE if user has finished */
    int ii;
    
    restartExec = FALSE;
    TUTORset_view(exS.baseView);

    switch (event->type) {
    
    case EVENT_KEY:
    case EVENT_FKEY:
        if (event->type == EVENT_KEY)
        { /* check for NEWLINE (next) that wasn't pressed */
            for (ii = 0; ii < event->nkeys; ii++)
                if ((event->keys[ii] == '\n' || event->keys[ii] == '\r') &&
                        !event->pressed)
                    break;
        }
        
        if (event->type == EVENT_KEY && ii < event->nkeys)
        { /* found a newline, handle it */
            if (ii > 0)
            {
                event->nkeys = ii;  /* so we get keys before NEWLINE */
                /* these keys will be going into the arrow */
            }
            else
                event->type = -1;   /* cancel event (no keys left) */
            setkey(KNEXT); /* so zkey is set properly */
            restartExec = TRUE;
            /* note that all keys (of a burst) after the newline are lost! */
        }
        else if (event->type == EVENT_FKEY && event->value == KNEXT) {
            /* this is also a next */
            event->type = -1; /* we're handling it here */
            setkey(KNEXT);
            restartExec = TRUE;
        } else if (exS.arr.arrowState == 1)
        { /* just gathering user input */
            if (exS.arr.resizing && event->type == EVENT_KEY)
                ResizeArrowView(event->nkeys); /* change size of arrow view appropriately */
        }
        else
            restartExec = TRUE;

        if (exS.arr.arrowState == 3) /* key when we are showing ok/no */
            {
            ReshowArrow(ii == 0,TRUE);  /* erase previous user input on bare NEWLINE */
            }

        event->view = exS.arr.aView;    /* all remaining keys go to arrow */
        break;

    case EVENT_PASTE:
        /* paste goes to arrow.  Note that we have already had an FKEY due
            to the paste */
        event->view = exS.arr.aView;
        break;
    
    case EVENT_LEFTDOWN:
    case EVENT_RIGHTDOWN:
    case EVENT_LEFTUP:
    case EVENT_RIGHTUP:
    case EVENT_DOWNMOVE:
    case EVENT_UPMOVE:
        /* figure out which view click was really in (since all events were sent
            to exS.baseView) */
        event->view = findview(event->window,event->x,event->y);
        if (event->view != exS.arr.aView)
        {       /* click outside arrow */
            if (!mycheckenable(exS.enabled,(struct tutorevent FAR *) event))
            {   /* just ignore this */
                event->type = -1;   /* cancel event */
                break;
            }
            /* otherwise, execution will restart */
            /* Note that this event will go to procexec, then processevent, and
                will then be rechecked by RunOnEvents.  processevent will
                then do a settouchkey and trigger execution.
                So we leave restartExec FALSE here */
            if (exS.arr.arrowState == 3)
                { /* in ok/no state.  Restore user's typing */
                ReshowArrow(FALSE,TRUE);
                /* and make arrow machinery go straight from
                    cmd_arrow2 to cmd_arrow3 */
                exS.arr.doNormalInput = FALSE;
                }
        }
        else
        {
            if (exS.arr.arrowState == 3)
            {
                ReshowArrow(FALSE,TRUE); /* click when in ok/no state */
                restartExec = TRUE;
            }
        }
        break;

    case EVENT_MENU:
        switch (event->a1) {

        case exec_response:
            event->type = -1;
            restartExec = TRUE;
            break;

        case exec_print:
            StartPicture(0,0,FARNULL,0);
            event->type = -1;
            break;
   
        default:
            event->view = exS.baseView;
            break;

        } /* switch */
        break;

    case EVENT_TIME:
        /* time events (caret blink) go to arrow */
        event->view = exS.arr.aView;
        break;

    default:
        if (exS.arr.arrowState == 3)
            ReshowArrow(FALSE,TRUE); /* in ok/no state */
        break;
    }

    /* pass on events we didn't handle */
    if (event->type > 0 && event->view)
    {
        TUTORset_view(event->view);
        (*event->view->vproc) (event->view->vh, event);
    }

    if (restartExec)
    { /* restart execution */
        waitflag = runflag;
        preexec();
    }

    return(0);
    
} /* procarrow */

/* ******************************************************************* */

static mycheckenable(enablebits, event) 
/* returns TRUE if mouse event is enabled */
int enablebits; /* enable list to check against */
struct tutorevent FAR *event;

{
    switch (event->type) {
    case EVENT_LEFTDOWN:
        return (enablebits & 2);
    case EVENT_RIGHTDOWN:
        return (enablebits & 16);
    case EVENT_LEFTUP:
        return (enablebits & 4);
    case EVENT_RIGHTUP:
        return (enablebits & 32);
    case EVENT_DOWNMOVE:
        return (enablebits & (event->rightdown ? 64 : 8));
    case EVENT_UPMOVE:
    	return (enablebits & 128);
    }
    return (FALSE);
}

/* ******************************************************************* */

procexec(viewH, event) /* event processor for executor */
Memh viewH; /* handle to view data */
struct tutorevent *event; /* event to process */
{   
    TPoint pnt; /* point for mouse clicks */
    struct tutorevent xev; /* run event */
    int ii;
	
    switch (event->type) {

    case EVENT_REDRAW:
#ifdef IBMPC
        TUTORupdate_menu_bar(); /* insure menu bar will be updated */
#endif
        /* initialize view+clip region */

        TUTORset_abs_view_rect(0, 0, event->x, event->y);
        TUTORclip_window(event->window); /* set clip to entire window */

        exS.modal_dialog_redraw = FALSE; /* forget pending redraw */
        if (exS.ExecInit < 2) { /* havent started running yet */
            FullScreenErase();
        } else if (modalW != -1) {
            exS.modal_dialog_redraw = TRUE;
            exS.dialog_redraw_x = event->x;
            exS.dialog_redraw_y = event->y;
        } else if (runflag != halt) {
			if (exS.inieu || ((exS.execunit == 0) && exS.mainunit)) {
				/* don't process redraw in IEU - hold */
				/* till later */
				exS.needredraw = TRUE;
			} else {
                Rerun(); /* restart execution from main unit */
         	}
        }
        break;

    case EVENT_FWD:
        break;

    case EVENT_MSG:
    case EVENT_MENU:
        switch (event->a1) {

        case edit_toexec: /* editor->executor transition */
            TUTORpoll_events(FALSE); /* update queue before execution */
            TUTORset_view(ExecVp); /* set to executor view */
            TUTORforward_window(ExecWn); /* show exec window */
#ifndef EXECUTE
			/* $window may have changed */
			TUTORsize_exec_window(ExecWinX,ExecWinY);
#endif

            /* generate run event */

			TUTORzero((char FAR *)&xev,(long)sizeof(struct tutorevent));
            xev.window = ExecWn;
            xev.type = EVENT_MSG;
            xev.timestamp = 100; /* wait for redraw from forward / size */
            xev.a1 = event->a2; /* type of run */
            xev.a4 = event->a4; /* unit number */
            TUTORpost_event(&xev); /* send event to executor */

            /* drop snapshot if not needed */
            
            if ((xev.a1 != edit_execfwd) && exS.snapShotH) {
                free_snapShot();
            }
            break;
        
        case edit_execfwd:
            TUTORforward_window(ExecWn); /* bring executor window fwd */
#ifdef MAC
            /* on mac, forward_window cancels redraws, so need */
            /* to display snapshot here */
            TUTORset_view(ExecVp); /* insure set to executor view */
            display_snapShot();
#endif
            break;

        case exec_run:
            Run();
            break;
            
        case exec_runfrom:
            RunFromUnit((int)event->a4);
            break;
            
        case exec_rununit:
            RunOneUnit((int)event->a4);
            break;
            
        case exec_runsel: /* run selected unit */
        case exec_execsel: /* execute selected unit */
        case exec_execcur: /* execute current unit */

            /* pass to editor to figure out which unit */

			if (CurEditWi <0 ) CurEditWi = 0;
            TUTORforward_window(EditWn[CurEditWi]); /* show editor window */
            xev.window = EditWn[CurEditWi];
            xev.view = FARNULL;
            xev.type = EVENT_MSG;
            xev.timestamp = 100; /* wait for redraw from forward */
            xev.eDataP = FARNULL;
            if (event->a1 == exec_runsel)
                xev.a1 = edit_runfrom;
            else if (event->a1 == exec_execsel)
                xev.a1 = edit_rununit;
            else xev.a1 = edit_execcur;
            TUTORpost_event(&xev); /* send event to editor */
            break;

        case exec_toedit:   /* executor->editor transition */
            CTpalette(ExecWn, HNULL,TRUE,HNULL); /* set executor's palette to default */
            if ((runflag == halt) && ctedit)
                post_toedit(); /* post event to editor */
            else {
                FullHalt();
            }
            break;

        case exec_switch:   /* switch file */
            TUTORclear_screen();
            exS.desX = ExecWinX; /* current desired window size */
    		exS.desY = ExecWinY;
#ifdef EXECUTE
			Run(); /* tail end of -jumpout- process */
#endif
            break;

		case exec_jumpout:
			ii = ExecJumpout((struct tutorevent FAR *)event);
			if (!ii) {
				FullHalt();
				if (nosourcelayout) {
					TUTORok_dialog(ExecWn,"Can't execute program binary");
					myexit();
				}
			}
			event->type = -1;
			break;
			
        case exec_print: /* build picture */
            StartPicture(0,0,FARNULL,0);
            event->type = -1; 
            break;
            
        case exec_quit:/* stop execution */
	    	FullHalt();
            DeleteExecMenus();
            DeleteAllAuthorMenus();
            if (nosourcelayout)
                myexit();
            return(0);

        case exec_unit:/* execute unit (no arguments) */
            if (runflag == halt)
                break;
            TUTORset_view(ExecVp);
            DoMenuUnit(FALSE,event->a2, FALSE, 0.0);
            break;

        case exec_unita: /* execute unit (with argument) */
            if (runflag == halt)
                break;
            TUTORset_view(ExecVp);
            DoMenuUnit(FALSE,event->a2, TRUE, event->a3);
            break;

        case exec_next:/* execute next unit */
            if (runflag == halt)
                break;
            setkey(KNEXT);
            /* turn this into an fkey event to check for execution start */
            event->type = EVENT_FKEY;
            event->value = KNEXT;
            event->nkeys = 1;
            event->view = exS.baseView;
            if (RunOnEvent((struct tutorevent FAR *) event))
                preexec();
            break;

        case exec_back:/* execute previous unit */
            if (runflag == halt)
                break;
            setkey(KBACK);
            /* turn this into an fkey event to check for execution start */
            event->type = EVENT_FKEY;
            event->value = KBACK;
            event->nkeys = 1;
            event->view = exS.baseView;
            if (RunOnEvent((struct tutorevent FAR *) event))
                preexec();
            break;


        } /* switch */
        break;

    case EVENT_KEY:
    case EVENT_FKEY:
        if (runflag == halt)
            break;
        processevent(event);
        break;
    
#ifdef MAC
    case EVENT_WFOCUS:
        WindowFocus(windowsP[ExecWn].wp);
        break;
#endif

    case EVENT_LEFTDOWN:
    case EVENT_RIGHTDOWN:
    case EVENT_LEFTUP:
    case EVENT_RIGHTUP:
    case EVENT_DOWNMOVE:
    case EVENT_UPMOVE:
        if (!exS.ExecInit)
            { /* not initialized yet.  Initialize so that graphic edit works */
            exS.execunit = exS.startunit; /* InitExecution expects execunit to be set */
            if (exS.execunit < 0)
            	exS.execunit = exS.startunit = sourcetable[0].firstunit;
            InitExecution();
            }

        /* process normal execution mouse event */

        if (exS.ExecInit) { /* rescale, etc. set up */
            if (runflag == halt) {
                if (grafedit(event)) {
                
                    /* send event to compile+execute unit */
            
                    xev.window = EditWn[CurEditWi];
                    xev.view = FARNULL;
                    xev.type = EVENT_MSG;
                    xev.a1 = edit_rununit;
                    xev.timestamp = 0;
                    xev.eDataP = FARNULL;
                    TUTORpost_event(&xev); /* send event to editor */
                } /* grafedit if */
            } else {
                processevent(event);
            } /* runflag else */
        } /* ExecInit if */

    } /* event switch */

    flush();

} /* procexec */

/* ******************************************************************* */

FullHalt() /* halt execution and prevent rerun upon reshape */

{
    Halt();
    rerunflag = halt;

} /* FullHalt */

/* ******************************************************************* */

Halt()

{   struct tutorview FAR *cv; /* current view pointer */
    int stackc; /* current run-time stack code */
    int sloop;
    Memh arrdoc; /* handle on arrow-related document */
    struct markvar SHUGE *madr; /* address of marker variable */
    int evi; /* index in event queue */
    Memh objH,fH,basicH; /* handle on edit, button, slider */
    int objT; /* object type */
    struct ebshdr FAR *objP; /* pointer to next object header */

    if (runflag == halt) {
        return(0); /* already halted */
    } /* runflag if */

	DebugHalt(); /* halt debugger */
	exS.stepMode = 0;

    /* close files/markers, clean up nested arrows */

    LockStack(); /* stack must be pinned during shut-down */
    TUTORset_sub_new(-1,0);
    DeleteExecMenus(); /* kill arrow/exec menus */
    FinishPicture(); /* complete building picture file */
    clear_compute_cache(); /* release -compute- cmd cache */
    MovieClose(0); /* close any QuickTime/VFW movie */
    CloseAllFiles(); /* close all active author files */
    unstack_all_units(); /* void -do-/-arrow- stack */

    /* close global markers, buttons, etc */
    items_close(0, 0L, TRUE,TRUE);
    madr = (struct markvar SHUGE *) exS.stackP;
    mvar_assign(madr, FARNULL); /* close jbuffer marker */
    mvar_temp_cleanup(); /* release temporary documents */
    exS.last_edit = exS.last_button = exS.last_slider = HNULL;
    if (exS.iconStextH) {
        TUTORfree_handle(exS.iconStextH); /* left over from -style- command */
        exS.iconStextH = HNULL;
    }
    if (exS.imageStextH) {
    	TUTORfree_region(exS.imageStextH); /* left over from -style- command */
    	exS.imageStextH = HNULL;
    }
    if (exS.JinfoH)
		TUTORfree_handle(exS.JinfoH); /* get rid of jumpout arguments */
	exS.JinfoH = HNULL;
	exS.JargN = 0;
	exS.fromRef.path[0] = 0;

    /* take snapshot of execute window */

    free_snapShot(); /* close current snapshot */
    if (prfP->snapShot) { /* snapshot preference active */
        exS.sswx = windowsP[ExecWn].wxsize;
        exS.sswy = windowsP[ExecWn].wysize;
        exS.ssx1 = exS.OffsetX+lclocx(exS.RegionXmin)-1;
        exS.ssy1 = exS.OffsetY+lclocy(exS.RegionYmin)-1;
        exS.ssx2 = exS.OffsetX+lclocx(exS.RegionXmax)+1;
        exS.ssy2 = exS.OffsetY+lclocy(exS.RegionYmax)+1;
        if (TUTORis_foreground(ExecWn))
        	exS.snapShotH = TUTORabs_save_region(exS.ssx1,exS.ssy1,
        	    exS.ssx2,exS.ssy2);
    } /* psnapshot if */
    
    /* send event to editor */
    
    if (ctedit) {
        post_toedit();  /* post exec->edit event */
    } /* ctedit if */

	exS.unClip = TRUE;
    unclip();
    TUTORnormal_cursor();
    TUTORset_fill(patternFont0, patternChar0);
    SetFlushState(1);   /* flush pending output */
    if (pcodeh) {
        ReleasePtr(pcodeh); /* allow memory move */
        KillPtr(pcodep);
    }
    pcodeh = 0;     /* no unit binary */
    ReleaseStack();
    if (descP) { /* release array descriptors */
        ReleasePtr(descH);
        KillPtr(descP);
        descP = FARNULL;
    }
    if (exS.sortTable) { /* free the user's sort table */
        TUTORfree_handle(exS.sortTable);
        exS.sortTable = HNULL;
    }

    /* set to wait for a key after seeing error message */
    if (nosourcelayout) {
        /* socketfin();  *//* close active socket */
        runflag = runall;
        waitflag = atendunit;
        exS.nextunit = -1;
        DeleteAllAuthorMenus();
        ExecMenus();
        return(0);
    } /* nosourcelayout if */
    
    if (exS.didPalette) {
        CTpalette(ExecWn,HNULL,TRUE,HNULL); /* set palette to default colors */
        for(evi=0; evi<WINDOWLIMIT; evi++) {
        	if ((windowsP[evi].type != EXECW) && (windowsP[evi].wp))
        		TUTORforce_redraw(evi);
        } /* for */
    }
    cv = TUTORinq_view();
    TUTORset_view(EditVp[0]);  /* set to editor view */
    ChangeEditMenus(TRUE);
    TUTORset_view(ExecVp);  /* set to executor view */
    exS.enablebits = 0; /* touch/ext not enabled */
    enable(0);
    TUTORcancel_all_events();   /* make sure nothing pending */
    clearkeys();
    if (exS.pausetimer != 0) {
        CancelTrigger(exS.pausetimer);  /* cancel timed pause */
        exS.pausetimer = 0;
    }
    TUTORstop_sound();  /* stop pending sound */
    TUTORdelete_author_menus(exS.execmenus);
    TUTORset_menubar(grapheditmenus, ExecVp);
    TUTORset_view(cv);  /* restore to current view */
    runflag = waitflag = halt;
    exS.execunit = -1;

    /* destroy button, edit, slider objects and headers */

    objH = exS.next_objH; /* handle on next object header */
    while (objH) {
        fH = objH; /* handle to free */
        objP = (struct ebshdr FAR *)GetPtr(fH);
        objH = objP->nextebsH;
        ReleasePtr(fH);
        object_close(fH); /* close underlying object */
        TUTORdeferred_free(fH); /* free next header */
    } /* objH while */
    exS.nobjects = 0;
    exS.next_objH = 0;
    
    /* shrink stack */
    
    if (exS.stackmalloc > 1000L) {
    	exS.stackmalloc = 1000L;
    	TUTORset_hsize(exS.stackH,exS.stackmalloc,FALSE);
    }
    gvarzero = TRUE; /* zero global vars on execute */
    flush();

} /* Halt */

/* ******************************************************************* */

post_toedit()  /* generate event to focus on editor */

{   struct tutorevent ev;

    TUTORzero((char SHUGE *)&ev,(long)sizeof(struct tutorevent));
    if (CurEditWi < 0) CurEditWi = 0;
    ev.window = EditWn[CurEditWi];
    ev.view = FARNULL;
    ev.type = EVENT_MSG;
    ev.timestamp = 20;
    ev.a1 = exec_toedit;
    windowsP[EditWn[CurEditWi]].MenuFocus = EditVp[CurEditWi];
    TUTORpost_event(&ev); /* send event to editor */

    /* handle compile+exit option */

    if (CompileAndExit == 1) {
	CompileAndExit = 2; /* do only once */
	TUTORzero((char FAR *)&ev,(long)sizeof(struct tutorevent));
	ev.window = EditWn[0];
	ev.view = EditVp[0];
	ev.type = EVENT_MENU;
	ev.a1 = edit_compile;
	ev.timestamp = 750; /* .75 second from now */
	TUTORpost_event(&ev);
    }
    return(0);

} /* post_toedit */

/*********************************************/
Run() /* menu run from beginning */

{
    if ((ctedit || ctcomp) && (!binaryOnly))
        FindUnits();    /* insure unit table set up */
    rerunflag = waitflag = runall;
    gvarzero = TRUE; /* zero global variables */
    RunUnits(FALSE,-1);
}

/*********************************************/

RunFromUnit(unitn) /* menu run from current unit */
int unitn; /* unit number or -1 */

{       
    rerunflag = waitflag = runall;
    RunUnits(TRUE,unitn);
}

/* ******************************************************************* */

RunOneUnit(unitn) /* menu execute current unit */
int unitn; /* unit number or -1 */

{   
    rerunflag = waitflag = runone;
    RunUnits(TRUE,unitn);
}

/* ******************************************************************* */

static RunUnits(current,unitn)
int current; /* TRUE if should run from "current" unit */
int unitn; /* -1 or "current" unit */

{   int i;
    long sLoc, sLen;
    int savrun; /* saved run/halt status */
    struct tutorview FAR *cv;   /* current view number */
    int sii; /* index in sourcetable of source file */
    Memh docH; /* handle on source document */
    Memh editH; /* handle on editor */
    EditDat FAR *ep;
    TextVDat FAR *vp; /* pointer to text panel */
    Memh textV; /* handle on text view */

    runflag = rerunflag; 
    logcmd = FALSE; /* turn off debug log */
    exS.proc_obj_unit = 0; /* allow button/slider/hot interrupt */
    if (exec_err_msg) {
        TUTORdealloc(exec_err_msg); /* release error message buffer */
        exec_err_msg = NULL;
    }
    exS.errexit = FALSE; /* no error exit yet */
    free_snapShot(); /* release executor snapshot */
    
    cv = TUTORinq_view();
    exS.startunit = -1;

    /* convert + compile program if -x option */

    if (!allcompiled && nosourcelayout) {
        TUTORset_view(ExecVp);  /* set to executor view */
        unclip();
        if (ctutv != CURRENTV) {
            EditConvert(); /* convert source */
        }
        StartCompileMsg(ExecWn);
        CountNeedsCompiled();
        CompileProgram(ExecWn,FALSE,TRUE); /* compile all units */
        TUTORclear_window(ExecWn);
    } /* nunits if */
    
    if (ctedit || ctcomp) {
        savrun = rerunflag;
        if (nunits <= 0) { /* cant execute if no unit setup */
            Halt();
            return(0);
        } /* nunits if */
        /* restore in case FindUnits forced halt */
        rerunflag = waitflag = savrun;
        if (CurEditWi < 0) CurEditWi = 0; /* get a valid editor index */
        if (EditWn[CurEditWi] >= 0) {
        
        	/* get editor, handle on text view */
        	
        	editH = windowsP[EditWn[CurEditWi]].wH; /* handle on editor */
        	ep = (EditDat FAR *) GetPtr(editH);
        	vp = (TextVDat FAR *) GetPtr(ep->textPanel);
        	textV = vp->textv; /* handle on text view */
        	ReleasePtr(ep->textPanel);
        	KillPtr(vp);
        	ReleasePtr(editH);
        	KillPtr(ep);
        	
        	/* look up editor in source table */
        	
        	for(sii=0; sii<sourcemalloc; sii++)
        		if (sourcetable[sii].editI == CurEditWi)
        			break; /* found sourcetable entry */
        	if (sii >= sourcemalloc) sii = 0;
        	docH = sourcetable[sii].doc; /* handle on source document */
            TUTORset_view(EditVp[CurEditWi]);  /* set to editor view */
            
            /* get selection, look up unit */
            
            GetSelect(textV, &sLoc, &sLen);
            if (current) { 
                if ((unitn < 0) || (unitn >= nunits)) {
                    i = LocateUnit(docH,sLoc);
                    if (i != 0)
                        exS.startunit = i;
                } else {
                    exS.startunit = unitn; /* execute selected unit */
                } /* unitn else */
            } /* current if */
            ChangeEditMenus(FALSE);
        } /* EditWn if */
    } /* config if */

#ifdef MAC
    /* after compile flush data/instruction caches on 68030+ */
    TUTOR68030_cache();
#ifdef __MC68K__
	exS.useCompiled = TRUE; /* use compiled code on 68K Macintosh */
#endif
#endif
	if (DebugWn >= 0)
		exS.useCompiled = FALSE; /* don't use compiled code if debugging */

    if (exS.startunit < 0)
        exS.startunit = sourcetable[0].firstunit;   /* ist unit in base file */
    if (runflag == halt)
        return(0);
    exS.execunit = exS.startunit;   /* set current+main unit */
    TUTORset_view(ExecVp);  /* set to executor view */
    CTset_foreground_color(color_defaultf);
    CTset_background_color(color_defaultb);
    CTset_window_color(color_defaultb);
    TUTORforward_window(ExecWn);    /* bring executor window forward */
    InitExecution();
    compunit = 0;
    enable(exS.enablebits);
    exS.menusmade = (rerunflag != runone);
    if (exS.menusmade) {
        TUTORset_menubar(exS.execmenus, ExecVp);
        
        /* rebuild menus if have edit window - previous run may have destroyed them */
        
        if (exS.execmenu) { /* have executed a menu command */
            exS.execmenu = FALSE;
            TUTORdelete_menu(exS.execmenus,NEARNULL,"Quit running");
            TUTORdelete_menu(exS.execmenus,NEARNULL,"Quit");
#ifdef AUTHOR
#ifdef MAC
            TUTORdelete_menu(exS.execmenus,NEARNULL,"Make PICT");
            TUTORadd_menu(exS.execmenus,NEARNULL,0,"Make PICT",98,0,exec_print,0,0.0,EVENT_MENU);
#endif /* mac */
#ifdef DOSPC
            TUTORdelete_menu(exS.execmenus,NEARNULL,"Make PCX");
            TUTORadd_menu(exS.execmenus,NEARNULL,0,"Make PCX",98,0,exec_print,0,0.0,EVENT_MENU);
#endif /* dospc */
#ifdef WINPC
	    TUTORdelete_menu(exS.execmenus,NEARNULL,"Make BMP");
	    TUTORadd_menu(exS.execmenus,NEARNULL,0,"Make BMP",98,0,exec_print,0,0.0,EVENT_MENU);
#endif /* winpc */

#endif /* AUTHOR */
			if (nosourcelayout)
				TUTORadd_menu(exS.execmenus,NEARNULL,0,"Quit",99,0,exec_quit,0,0.0,EVENT_MENU);
			else
            	TUTORadd_menu(exS.execmenus,NEARNULL,0,"Quit running",99,0,exec_quit,0,0.0,EVENT_MENU);
        }
    
        ExecMenus();
    }
    TUTORset_view(cv);  /* restore view */
    clearkeys();
    exS.ExecInit = 2; /* executing */
    preexec();

} /* RunUnits */

/*********************************************/
MakeMenus()
{
    /* We avoid on Execute Current Unit the setup of exec menus until needed. */
    /* This is called by -menu- and by any interrupt. */
    struct tutorview FAR *cv;   /* current view number */

    if (exS.menusmade)
        return(0);      /* exec menus already up */
    exS.menusmade = TRUE;
    cv = TUTORinq_view();
    TUTORset_view(ExecVp);  /* set to execute view */
    TUTORset_menubar(exS.execmenus, ExecVp);
    ExecMenus();
    TUTORset_view(cv);  /* restore view */
}               /* MakeMenus */

/*********************************************/
extern long TUTORinq_msec_clock(void);

static Rerun()              /* driven by reshape events */
{
    int savecnt, sw, sh;

    savecnt = exS.outcnt;
    SetFlushState(-1);  /* get rid of pending update */
    if (savecnt < 0)
        exS.outcnt = savecnt;
    TUTORinq_abs_screen_size(&exS.ScreenX0, &exS.ScreenY0, &sw, &sh);
    exS.ScreenW = IntToCoord(sw);
    exS.ScreenH = IntToCoord(sh);

    CancelTrigger(exS.pausetimer);  /* cancel timed pause */
    exS.pausetimer = 0;
    switch (rerunflag)
    {
    case halt:
        /* we shouldn't be here */
        return(0);
    case compileit:
        return(0);
    case runone:
    case runall:
    	if (rerunflag == runone)
    	    runflag = waitflag = runone;
    	else
        	rerunflag = runflag = waitflag = runall;
        LockStack(); /* insure stack pinned, ptrs set up */
        exS.execunit = exS.mainunit;
        unstack_all_units();    /* void -do-/-arrow- stack */
        InitMainUnit(TRUE, FALSE);  /* reshape, dont execute ieu */

        /* On reshape, must restore base font for rescaling purposes */
        if (NewFontSize && exS.rescaleFont != -1)
        {
            exS.baseFont = exS.rescaleFont;
            exS.CharHeight = exS.rescaleCharHeight;
        }
        ResetFine();
        if (exS.unClip) { /* unclipped, set to whole drawable region */
            exS.ClipX = exS.RegionXmin;
        	exS.ClipY = exS.RegionYmin;
        	exS.ClipX2 = exS.RegionXmax;
        	exS.ClipY2 = exS.RegionYmax; 
        }
        setclip();
        ExecMenus();
        clearkeys();
        preexec();
        return(0);

    }           /* end of rerunflag switch */

    return(0);
}               /* Rerun */


/* ******************************************************************* */

#ifdef WINPC
extern long TopTime; /* last time back in WinMain */
extern long polltime;
#endif

shouldint() /* Return TRUE if time to return to interact loop */

{   int doint; /* non-zero if should interrupt */

    if (exS.shouldint) 
        return(TRUE); /* already know we need to interrupt */

    doint = mvar_cache_ovr();
    if (!exS.menusmade)
	MakeMenus();

#ifdef WINPC
    if ((TopTime+750L) < polltime)
	doint = TRUE;
#endif

    if (!doint && TUTORshould_interrupt() && (exS.stepMode != 1)) {
        TUTORpoll_events(FALSE); /* look for new input */
        if (nevents || TUTORinq_wmg_busy(-1))
            doint = TRUE;
#ifdef MAC
        if (TUTORinq_slider_busy())
            doint = TRUE;
#endif
    }

   if (doint)
        exS.shouldint = TRUE;

   return (doint);

} /* shouldint */

/* ******************************************************************* */


preexec()
{               /* this routine starts the executor */
                /* it is the only place where executor() is called,
                    with the exception of DoMenuUnit, which should
                    only be called for interrupts */
    
    int startExecution; /* TRUE if we will really start execution */
    int minmenu; /* minimum number of menu items always present */
    
    /* by the time we have gotten to preexec we know that we want to start,
        the user has chose a "Run" menu, or we have broken the pause (and set zkey)
        already.  Only a waitflag or runflag of halt can stop us */
    
    startExecution = FALSE;
    
    switch (waitflag)
    {
    case halt:
        return(0);
    case runone:
    case runall:
    case atinterrupt:
    case atgetkey:
        exS.pausetype = -1;
        waitflag = rerunflag;
        if (!exS.stackLocked)
        {       /* start of execution, lock the stack
                 * (unlocked in Halt) */
            LockStack();    /* lock down stack */
        }
        startExecution = TRUE;
        break;

    case atarrow:
        startExecution = TRUE;
        waitflag = rerunflag;
        if (!exS.stackLocked)
            LockStack(); /* lock down stack */
        if ((exS.zkey == KBACK) && exS.backunit) {
            unstack_all_units(); /* void -do-/-arrow- stack */
            exS.execunit = exS.backunit; /* set new unit */
            InitMainUnit(FALSE,FALSE); /* no reshape, no ieu */
        }
        break;

    case atendunit:
        /* make sure we have a valid stack */
        if (!exS.stackLocked)
            LockStack();

        if ((exS.zkey == KNEXT) && exS.nextunit) {
            items_close(exS.execunit,exS.lvars,TRUE,TRUE); 
            if (exS.nextunit < 0) {
                myexit();
            } else if (exS.nextunit > 0) {
                exS.execunit = exS.nextunit;
                unstack_all_units(); /* void do/arrow stack */
                InitMainUnit(FALSE, FALSE);
                if (afterpause())
                    startExecution = TRUE; /* run */
            }
        } else if (exS.zkey == KBACK && exS.backunit != 0) {
            items_close(exS.execunit,exS.lvars,TRUE,TRUE); 
            exS.execunit = exS.backunit;
            unstack_all_units();
            InitMainUnit(FALSE,FALSE);
            if (afterpause())
                startExecution = TRUE; /* run */
        } else if ((exS.nobjects == 0) && (exS.nextunit == 0) &&
                   (exS.backunit == 0)) {
            /* no place to go, no objects active */
            /* check options, quit only menu */
            minmenu = 2; /* "Option" card, plus "Quit" */
#ifdef ANDREW
			minmenu++; /* Make PPM */
#else
#ifdef X11
			minmenu++; /* Make PPM */
#endif
#endif
#ifdef MAC
            minmenu++; /* Make PICT */
#endif
#ifdef IBMPC
            minmenu++; /* Make PCX */
#endif
            if (TutorCountMenuItems() <= minmenu) 
                Halt();
        }
        break;

    case atpause:
        if (exS.zkey == KBACK && exS.backunit != 0) {
            /* jump to back unit */
            exS.execunit = exS.backunit;
            unstack_all_units();
            InitMainUnit(FALSE,FALSE);
            if (pcodeh) {
                ReleasePtr(pcodeh);
                KillPtr(pcodep);
            }
            pcodeh = 0;
            InsureUnit(exS.execunit);
        } /* zkey if */
        if (afterpause())
            startExecution = TRUE;

        break;

	case atdebug:
		break;

    }           /* end of waitflag switch */

    if (startExecution)
        executor();

}               /* preexec */

/*********************************************/
TimedPauseOvl()
{               /* come here after timed pause */
    timeflag = FALSE;
    if (runflag == halt)
        return(0);
    if (exS.pausetype < 0)
        return(0);      /* already broke the pause */
	if (modalW != -1)
		return(0);
    setkey(KTIMEUP);
    preexec();
}

/*********************************************/
afterpause()
{
    if (runflag == halt)
        return(FALSE);
    exS.pausetype = -1;
    waitflag = runflag;
    ExecMenus();
    enable(exS.enablebits);/* restore pre-pause enable condition */
    return(TRUE);
}

/*********************************************/
static convertkey(c)
    register int    c;
{               /* keyset conversion */
    switch (c)
    {
    case 10:        /* treate line feed like return */
    case '\r':
        return (KNEXT);
    case 8:     /* BACKSPACE */
    case 127:       /* DELETE */
        return (KERASE);
    }
    return (c);
}

/*********************************************/

static processevent(event)  /* process key, fkey or touch event for executor */
struct tutorevent *event;
    {
    int key;
    int jj;
    
    if (!RunOnEvent((struct tutorevent FAR *) event))
        return(0); /* event didn't restart execution, so forget it */
    
	if (modalW != -1)
		return(0); /* processing dialog, forget it */

    /* we are restarting execution */
    
    /* set zkey, etc. */
    switch (event->type)
        {
    case EVENT_LEFTDOWN:
    case EVENT_LEFTUP:
    case EVENT_RIGHTDOWN:
    case EVENT_RIGHTUP:
    case EVENT_DOWNMOVE:
        if (waitflag == atendunit) /* I guess touch must be enabled */
            setkey(KNEXT); /* treat touch like NEXT */
        else
            settouchkey((struct tutorevent FAR *) event);
        break;
    case EVENT_UPMOVE:
    	/* not a touch key */
    	break;
    case EVENT_FKEY:
        setkey(event->value);
        break;
    case EVENT_KEY:
        key = event->keys[0];
        if (!event->pressed)
            key = convertkey(key); /* we convert unpressed keys */
        setkey(key);
        if (event->nkeys > 1)
            { /* we need to push burst keys back into event queue */
            /* first shift keys down to account for the one we are using */
            event->nkeys--;
            for (jj=0; jj<event->nkeys; jj++)
                event->keys[jj] = event->keys[jj+1];
            TUTORpush_event(event);
            }
        break;
    default:
        TUTORdump("Unexpected event in processevent");
        }
    
    if (waitflag == atpause)
        { /* fix up execution location */
        exS.uloc = exS.pauseuloca;
        if ((exS.pausetype == 3 || exS.pausetype == 2) && exS.pausetimer)
            { /* cancel time event trigger because we are already restarting */
            CancelTrigger(exS.pausetimer);
            exS.pausetimer = 0;
            timeflag = FALSE;
            }
        }

    /* restart execution */
    preexec();
    
    return(0);
    }

/*********************************************/

RunOnEvent(event)   /* check if event restarts execution */
register struct tutorevent FAR *event;
/* returns TRUE if this event should restart execution */
    {
    int startRun;
    int isTouch;    /* set to TRUE if this is some kind of touch event */
    int ii, jj;
    int key;
    
    /* this routine leaves event unmodified except for EVENT_KEY events.  In that
        case it will throw out burst keys in front of the key which restarts the
        execution */

    if (event->view != ExecVp)
        return(FALSE); /* not known to be for executor view */
        
    if (waitflag == atgetkey)
        return(TRUE); /* any key or touch restarts execution for getkey */
    
    if (event->type == EVENT_UPMOVE)
    	return(FALSE); /* -touch- handled elsewhere */
    	
    /* set isTouch */
    if (event->type == EVENT_LEFTDOWN || event->type == EVENT_LEFTUP ||
            event->type == EVENT_RIGHTDOWN || event->type == EVENT_RIGHTUP ||
            event->type == EVENT_DOWNMOVE)
        isTouch = TRUE;
    else
        isTouch = FALSE;
    
    startRun = FALSE;
    
    switch(waitflag)
        {
    case atpause:
        if (exS.pausetype == 0)
            { /* blank pause */
            if (event->type == EVENT_KEY || event->type == EVENT_FKEY
                    || (isTouch && mycheckenable(exS.enabled,event)))
                startRun = TRUE;
            }
        else
            { /* check event against pause list */
            if (isTouch && exS.pausetype != 2)
                { /* see if touch event breaks pause (never breaks time-only pause) */
                if (mycheckenable(exS.enabled,event))
                    startRun = TRUE;
                }
            else if (event->type == EVENT_KEY || event->type == EVENT_FKEY)
                { /* check against key list */
                for (ii=0; ii<event->nkeys && !startRun; ii++)
                    { /* check every key in the event */
                    key = (event->type == EVENT_FKEY) ? event->value : event->keys[ii];
                    if (key == NEWLINE)
                        key = KNEXT; /* newlines are really NEXTs */
                    if (checkkey(key))
                        { /* we found a key that breaks the pause */
                        startRun = TRUE;
                        if (ii > 0)
                            { /* get rid of keys before the one that breaks the pause */
                            for (jj=ii; jj<event->nkeys; jj++)
                                event->keys[jj-ii] = event->keys[jj];
                            event->nkeys -= ii;
                            }
                        }
                    }
                }
            }
        break;
    case atendunit:
        if (event->type == EVENT_KEY)
            { /* look for newline in keys */
            for (ii=0; ii<event->nkeys; ii++)
                if (event->keys[ii] == NEWLINE)
                    {
                    startRun = TRUE;
                    if (ii > 0)
                        { /* get rid of keys before the one that breaks the pause */
                        for (jj=ii; jj<event->nkeys; jj++)
                            event->keys[jj-ii] = event->keys[jj];
                        event->nkeys -= ii;
                        }
                    }
            }
        else if (event->type == EVENT_FKEY)
            {
            if (event->value == KNEXT || event->value == KBACK)
                startRun = TRUE;
            }
        else if (isTouch)
            {
            if (mycheckenable(exS.enabled,event))
                startRun = TRUE;
            }
        break;
    case atarrow:
        /* click in executor outside arrow bounds */
        if (isTouch && mycheckenable(exS.enabled,event))
            startRun = TRUE; /* some clicks were enabled */
        if ((event->type == EVENT_FKEY) &&
            (event->value == KBACK) && exS.backunit)
            startRun = TRUE;
        break;
    case runone:
    case runall:
    case atinterrupt:
    default:
        break;
        }
    
    return(startRun);
    }

/*********************************************/
clearkeys()
{ /* clear out key buffer */
    int ii, ew;
    
    /* clear all key, fkey & touch events for executor window */
    ew = exS.baseView->window;
    for (ii=0; ii<nevents; ii++)
        if (eventque[ii].window == ew)
            {
            switch (eventque[ii].type)
                {
            case EVENT_KEY:
            case EVENT_FKEY:
            case EVENT_PASTE:
            case EVENT_LEFTDOWN:
            case EVENT_LEFTUP:
            case EVENT_RIGHTDOWN:
            case EVENT_RIGHTUP:
            case EVENT_DOWNMOVE:
            case EVENT_UPMOVE:
                TUTORfree_event_memory(eventque+ii);
                eventque[ii].type = -1; /* cancel event */
                break;
                }
            }
}

/*********************************************/

setkey(cc)
int cc;
{               /* set status for keyset input */
    /* zkey format for keyset is 1/pressed, 6/0, 9/key data */
    exS.zkey = cc;
    exS.zdevice = 0;
    exS.ztouchx = exS.ztouchy = coordZero;
    exS.zgtouchx = exS.zgtouchy = 0.;
    exS.zrtouchx = exS.zrtouchy = 0.;
}

/*********************************************/

seteditkey(cc)
int cc;
{               /* set status for keyset input */
    /* zeditkey format for keyset is 1/pressed, 6/0, 9/key data */
    exS.zeditkey = cc;
   
} /* seteditkey */

/*********************************************/

int setedittouch(event) /* set status for touch input */
struct tutorevent FAR *event;

{	int mx,my,key;

	key = -1;
	switch(event->type) {
	case EVENT_LEFTDOWN:
		key = KTOUCH; break;
	case EVENT_LEFTUP:
		key = KTOUCH+1; break;
	case EVENT_RIGHTDOWN:
		key = KTOUCH+3; break;
	case EVENT_RIGHTUP:
		key = KTOUCH+4; break;
	case EVENT_DOWNMOVE:
		if (event->leftdown)
			key = KTOUCH+2;
		else
			key = KTOUCH+5;
		break;
	}
	if (key < 0) return(0); /* didn't recognize event */
	exS.zeditkey = key;
    mx = event->x;
    my = event->y;
	exS.zeditx = DivCoord(IntToCoord(mx - exS.OffsetX), exS.ScaleX) + exS.RegionXmin;
	exS.zedity = DivCoord(IntToCoord(my - exS.OffsetY), exS.ScaleY) + exS.RegionYmin;
 	return(0);
 	
} /* setedittouch */

/*********************************************/

settouchkey(event)  /* set zkey etc. for touch event */
struct tutorevent FAR *event;
    {
    int key, mx, my;
    
    switch(event->type)
        {
        case EVENT_UPMOVE:
        	return(TRUE); /* do nothing */
        case EVENT_LEFTDOWN:
            key = KTOUCH; break;
        case EVENT_LEFTUP:
            key = KTOUCH+1; break;
        case EVENT_RIGHTDOWN:
            key = KTOUCH+3; break;
        case EVENT_RIGHTUP:
            key = KTOUCH+4; break;
        case EVENT_DOWNMOVE:
            if (event->leftdown)
                key = KTOUCH+2;
            else
                key = KTOUCH+5;
            break;
        }
    mx = event->x;
    my = event->y;

    exS.zkey = key;
    exS.zdevice = 1;

    if (event->pressed)
        { /* pressed touch */
        exS.ztouchx = IntToCoord(mx);
        exS.ztouchy = IntToCoord(my);
        }
    else
        {
        exS.ztouchx = DivCoord(IntToCoord(mx - exS.OffsetX), exS.ScaleX) + exS.RegionXmin;
        exS.ztouchy = DivCoord(IntToCoord(my - exS.OffsetY), exS.ScaleY) + exS.RegionYmin;
        }

    GraphScale(exS.ztouchx, exS.ztouchy, &exS.zgtouchx, &exS.zgtouchy);
    RelativeScale(exS.ztouchx, exS.ztouchy, &exS.zrtouchx, &exS.zrtouchy);
    
    return(TRUE);
    }

/**************************************************/

GraphScale(fnx, fny, cx, cy)    /* inverse of graph_to_fine */
Coord fnx, fny; /* fine coords in */
double *cx, *cy;/* graph coords out */
{
    double tx;
    double fx, fy;

    fx = CoordToFloat(fnx);
    fy = CoordToFloat(fny);
    fx = (fx - CoordToFloat(exS.GXorigin)) / exS.GXscale + exS.GXoffset;
    fy = -(fy - CoordToFloat(exS.GYorigin)) / exS.GYscale + exS.GYoffset;
    if (exS.GLogXflag)
        fx = pow(10.0, fx);
    if (exS.GLogYflag)
        fy = pow(10.0, fy);

    if (exS.GPolar) {
        tx = sqrt(fx * fx + fy * fy);
        if (fx == 0.0 && fy == 0.0) {
            fy = 0.0;   /* define out 0/0 trouble */
        } else {
        	if (checkRadians()) 
        		fy = atan2(fy,fx);
        	else
            	fy = atan2(fy, fx) / RDN;
        }
        fx = tx;
    }
    *cx = fx;
    *cy = fy;

    return(0);
}

/**************************************************/
RelativeScale(fnx, fny, cx, cy) /* inverse of relative_to_fine */
Coord fnx, fny; /* fine coords in */
double *cx, *cy;/* relative coords out */
{
    double fx, fy;

    fx = CoordToFloat(fnx - exS.RXorigin);
    fy = CoordToFloat(fny - exS.RYorigin);
    *cx = (fx * exS.RcosAngle + fy * exS.RsinAngle) / exS.RXsize;
    *cy = (-fx * exS.RsinAngle + fy * exS.RcosAngle) / exS.RYsize;
}

/*********************************************/
checkkey(key)               /* match key against pausekey list */
int key;
    {
    int ok;
    int kbyte, kbit;
    
    if (key < 0)
        return(FALSE); /* out of bounds */
    
    ok = FALSE;
    kbyte = key >> 3;
    if (kbyte > 38)
        return(FALSE); /* out of bounds */
    kbit = key - (kbyte << 3);
    kbit = 0x80 >> kbit;
    if (exS.pausekeys[kbyte] & kbit)
        ok = TRUE;
    
    return(ok);
    }

/* ******************************************************************* */

enable(bits) /* enable touch options */
int bits;

{
    exS.enabled = bits; /* save desired enable bits */

} /* enable */

/* ******************************************************************* */

LockExec() /* lock items used by executor */

{
    if (!unittab) /* unit table locked in memory */
        unittab = (struct unitinfo FAR *)GetPtr(unittabH);
    InsureUnit(exS.execunit); /* insure unit in memory */
    set_exec_pt(exS.uloc);
    LockStack(); /* lock user variables stack */
    if (!descP)
        descP = GetPtr(descH); /* descriptors locked in memory */

} /* LockExec */

/* ******************************************************************* */

UnlockExec() /* unlock items used by executor */

{
    exS.uloc = ((unsigned char FAR *)(ex_binP))-pcodep;
    ReleaseStack(); /* allow stack to move */
    if (pcodeh) {
        ReleasePtr(pcodeh);
        KillPtr(pcodep);
    }
    pcodeh = 0;
    if (descP) { /* release array descriptors */
        ReleasePtr(descH);
        descP = FARNULL;
    }
    if (unittab) { /* allow unit table to move */
        ReleasePtr(unittabH);
        unittab = FARNULL;
    }

} /* UnlockExec */

/* ******************************************************************* */

unsigned char SHUGE *LockStack() /* get pointer to stack */

{   struct markvar SHUGE *mvp;

    if (exS.stackLocked) {
        if (exS.stackP == FARNULL)
            TUTORdump("? stack locked but no pointer");
        return (exS.stackP);
    } /* locked if */
    exS.stackP = (unsigned char SHUGE *) GetPtr(exS.stackH);
    exS.stackLocked++; /* stack locked in memory */
    exS.stackpntr = exS.stackP+exS.LockStackRel;
    exS.lvarP = exS.stackP+exS.lvars;
    assign_pfun((long)&exs_addr[EXS_LOCALP],(long)exS.lvarP);
    assign_pfun((long)&exs_addr[EXS_GLOBALP],(long)exS.stackP);
    if (exS.arr.jbuffer) {
        mvp = (struct markvar SHUGE *)(exS.stackP);
        exS.arr.jbuffer = mvp;  
    }
    set_array_addresses(); /* set addresses of global/local arrays */
    return (exS.stackP);

} /* LockStack */

/* ******************************************************************* */

ReleaseStack() /* release stack - allow realloc/memory move */

{
    if (exS.stackLocked == 0)
        return(0); /* not locked, dont unlock */
    release_dyn_arrays(); /* allow dynamic arrays to move */
    exS.LockStackRel = exS.stackpntr-exS.stackP; /* save relative value */
    ReleasePtr(exS.stackH);
    KillPtr(exS.stackP);
    exS.stackLocked--;
    /* pointers are no longer valid */
    exS.stackP = exS.stackpntr = exS.lvarP = NULL; 

} /* ReleaseStack */

/* ******************************************************************* */

free_snapShot() /* release current executor snapshot */

{
    if (exS.snapShotH == HNULL)
        return;
        
    TUTORfree_region(exS.snapShotH);
    exS.snapShotH = HNULL;

} /* free_snapShot */

/* ******************************************************************* */
