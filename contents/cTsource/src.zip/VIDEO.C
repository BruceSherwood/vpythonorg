#include "stdio.h"

#include "baseenv.h"
#include "ctstring.h"
#include "compute.h"
#include "tglobals.h"
#include "kglobals.h"
#include "eglobals.h"
#include "video.h"

#ifdef ctproto
int MovieInfo(int *width,int *height,double *length,int *isplay);
int  TUTORset_textfont(int  jj);
extern int TUTORline_thick(int thickV);
int  TUTORset_comb_rule(int  rule);
int  TUTORintersect_rect(struct  _trect FAR *r1,struct  _trect FAR *r2,struct  _trect FAR *rdest);
int  TUTORinq_abs_clip_rect(struct  _trect *cr);
extern  int TUTORset_abs_clip_rect(TRect FAR *cr);
extern TUTORfree_region(long regid);
long TUTORabs_save_region(int x1, int y1, int x2, int y2);
int TUTORabs_restore_region(long regid, int x1, int y1);
void dragThumb(Memh cH,TPoint *ww);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORclose_view(struct  tutorview FAR *vp);
extern int TUTORclose_controller(Memh ctrlH);
extern  int TUTORpost_event(struct tutorevent *event);
extern int TUTORupdate_controller(Memh ctrlH,double curPos,int isPlaying);
extern  int TUTORset_abs_clip_rect(TRect FAR *cr);
extern int TUTORtrace_n(char *s,long nn);
int TUTORtrace_n_n(char *s,long nn, long n2);
int  TUTORpoint_in_rect(struct  _tpoint pt,struct  _trect *r);
static void drawThumb(struct controlDat FAR *ctrlP);
static void drawFwd(struct controlDat FAR *ctrlP);
static void drawBack(struct controlDat FAR *ctrlP);
static void drawPlay(struct controlDat FAR *ctrlP);
extern int TUTORabs_fill_polygon(int npoints,Coord *fx,Coord *fy);
int  TUTORabs_line_to(int  x,int  y);
int  TUTORabs_move_to(int  x,int  y);
int  TUTORframe_abs_rect(struct  _trect FAR *tr);
int CTset_foreground_color(int cn);
int CTset_background_color(int cn);
extern int CloseMMotionVideo(void);
extern int CloseExternalVideo(void);
int  lclocy(long  q);
int  lclocx(long  q);
extern int cmd_dma(void);
extern int TUTORdraw_abs_solid_rect(TRect FAR *rr, int pat);
extern int TUTORdraw_controller(Memh ccH);
extern void TUTORset_color(int select,struct tutorColor FAR *newColor);
extern  int TUTORset_abs_view_rect(int x1,int y1,int w,int h);
extern  int TUTORset_view(struct tutorview FAR *vp);
extern  struct tutorview FAR *TUTORinq_view(void );
extern  struct tutorview FAR *TUTORinit_view(int sW,unsigned int vDat,int (*vProc)());
extern int TUTORzero(char SHUGE *ptr,long length);
extern Memh TUTORhandle(char *name,long size, int purge);
extern int vd_enter(void);
extern int vd_restore(void);
int  TUTORclose(int  findx);
long  TUTORinq_msec_clock(void);
long  TUTORwrite(char  FAR *ptr,int  pSize,long  count,int  findx);
extern int procctrlr(Memh cH,struct tutorevent *event);
extern Memh TUTORnew_controller(TRect *tR,double start,double end,
              int (*playProc)(Memh cH),int (*stopProc)(Memh cH),
              int (*fwdProc)(Memh cH),int (*backProc)(Memh cH),int (*thumbP)(Memh cH));
extern char FAR *GetPtr(Memh mm);
extern int ReleasePtr(Memh mm);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef DOSPC
extern char *strcat(char *aa, char *bb);
extern char *strcpy(char *aa, char *bb);
#endif

#ifdef macproto
#ifndef THINKC5
extern char *strcat(char *aa, char *bb);
extern char *strcpy(char *aa, char *bb);
extern int sprintf(char *ss, char *form, ...);
#endif
#endif

extern long TUTORwrite();
extern int procctrlr();
extern  struct tutorview FAR *TUTORinit_view();
extern  struct tutorview FAR *TUTORinq_view();
extern void drawPlay();
extern void drawBack();
extern void drawFwd();
extern void dragThumb();
extern void drawThumb();

int vid_kind = -1;
int movieCtrlH = 15;

static long vd_mode;  /* saved mode */
static struct tutorColor vd_fc, vd_bc; /* saved foreground, background colors */
static int vd_thick; /* saved line thickness */
static int vd_fontid; /* save/restore current font index */
static TRect vd_clipR; /* clip rectangle */

/* ******************************************************************* */

Memh TUTORnew_controller(ctrlRect,startTime,endTime,playProc,stopProc,
			fwdProc,backProc,thumbProc)
TRect *ctrlRect; /* rectangle for movie */
double startTime; /* time in media to start */
double endTime; /* time in media to end */
#ifdef sparc
int (*playProc)();
int (*stopProc)();
int (*fwdProc)();
int (*backProc)();
int (*thumbProc)();
#else
int (*playProc)(Memh cH);
int (*stopProc)(Memh cH);
int (*fwdProc)(Memh cH);
int (*backProc)(Memh cH);
int (*thumbProc)(Memh cH);
#endif

{	Memh ctrlH; /* handle on controller data */
	struct controlDat FAR *ctrlP; /* pointer to controller data */
	int wix; /* index of current window */
    struct tutorview FAR *cv; /* current (parent) view */
	TRect lrr; /* local copy of outer rectangle */
	TRect clipR; /* clip rectangle */
	TRect intrR; /* intersection rectangle */
	double movieLen; /* length of movie (from file) */
	
	/* clean up range */
	
	MovieInfo(NEARNULL,NEARNULL,&movieLen); 
	if (startTime < 0) startTime = 0;
	if (startTime > movieLen) startTime = movieLen;
	if (endTime < 0) endTime = 0;
	if (endTime > movieLen) endTime = movieLen;
	if (startTime > endTime) {
		movieLen = endTime;
		endTime = startTime;
		startTime = movieLen;
	}

	/* apply clip rectangle, see if enough left */
	
	TUTORinq_abs_clip_rect(&clipR); /* get parent clip rectangle */	  
	TUTORintersect_rect(ctrlRect,&clipR,(TRect FAR *)&intrR);
	*ctrlRect = intrR;
	if (((ctrlRect->right-ctrlRect->left) < 60) || 
	    ((1+ctrlRect->bottom-ctrlRect->top) < movieCtrlH))
		return(0); /* too small */	
	ctrlRect->bottom = ctrlRect->top+movieCtrlH; /* fixed height */
	
	ctrlH = TUTORhandle("ctrldat",(long) sizeof(struct controlDat),TRUE);
    if (!ctrlH)
        return(0);
    
    wix = CurrentWindow; /* index of current window */
    ctrlP = (struct controlDat FAR *) GetPtr(ctrlH);
    TUTORzero((char FAR *)ctrlP,(long)sizeof(struct controlDat));

    /* set up view */
    
    ctrlP->view = TUTORinit_view(wix,ctrlH,procctrlr);
    cv = TUTORinq_view();
    ctrlP->ownerView = cv;
    TUTORset_view(ctrlP->view);
    TUTORset_abs_view_rect(ctrlRect->left,ctrlRect->top,
         ctrlRect->right-ctrlRect->left+1,ctrlRect->bottom-ctrlRect->top+1);

    ctrlP->cRect = ctrlP->view->rr;
    lrr = ctrlP->cRect;
#ifdef MAC
    ctrlP->cGrey.palette = color_rgb;    
    ctrlP->cGrey.red = ctrlP->cGrey.green = ctrlP->cGrey.blue = 80.7;
    ctrlP->cDkGrey.palette = color_rgb;    
    ctrlP->cDkGrey.red = ctrlP->cDkGrey.green = ctrlP->cDkGrey.blue = 67.8;
#endif
#ifdef WINPC
    ctrlP->cGrey.palette = color_rgb;    
    ctrlP->cGrey.red = ctrlP->cGrey.green = ctrlP->cGrey.blue = 75.29;
    ctrlP->cDkGrey.palette = color_rgb;    
    ctrlP->cDkGrey.red = ctrlP->cDkGrey.green = 62.74;
    ctrlP->cDkGrey.blue = 64.31;
#endif
    TUTORset_color(1,&ctrlP->cGrey); 
    ctrlP->clipR = clipR;
    TUTORset_abs_clip_rect((TRect FAR *)&clipR);
    ctrlP->drawTrack = TRUE;
    
    ctrlP->playProc = playProc;
    ctrlP->stopProc = stopProc;
    ctrlP->fwdProc = fwdProc;
    ctrlP->backProc = backProc;
    ctrlP->thumbProc = thumbProc;
    
     /* set up track background rectangle */
    
	ctrlP->trackBack.left = lrr.left+16;
	ctrlP->trackBack.top = lrr.top+1;
	ctrlP->trackBack.right = lrr.right-31;
	ctrlP->trackBack.bottom = lrr.bottom-1;
        
    /* set up track foreground region */
    
	ctrlP->trackFore.left = lrr.left+20+1;
	ctrlP->trackFore.top = lrr.top+4;
	ctrlP->trackFore.right = lrr.right-35-1;
	ctrlP->trackFore.bottom = lrr.bottom-4;
    ctrlP->trackWidth = ctrlP->trackFore.right-ctrlP->trackFore.left+1;   
    
    /* play button region */
    
    ctrlP->playB.left = lrr.left;
    ctrlP->playB.right = lrr.left+15;
    ctrlP->playB.top = lrr.top;
    ctrlP->playB.bottom = lrr.bottom;   
    ctrlP->playStop = TRUE;   

	/* back button region */
	
   	ctrlP->backB.left = lrr.right-30;
   	ctrlP->backB.right = lrr.right-15;
   	ctrlP->backB.top = lrr.top;
   	ctrlP->backB.bottom = lrr.bottom;    
    
    /* forward button region */
    
    ctrlP->fwdB.left = lrr.right-15;
    ctrlP->fwdB.right = lrr.right;
    ctrlP->fwdB.top = lrr.top;
    ctrlP->fwdB.bottom = lrr.bottom;
    
    ctrlP->playVis = TUTORintersect_rect(&ctrlP->playB,&ctrlP->clipR,(TRect FAR *)&intrR);
    ctrlP->fwdVis = TUTORintersect_rect(&ctrlP->fwdB,&ctrlP->clipR,(TRect FAR *)&intrR);
    ctrlP->backVis = TUTORintersect_rect(&ctrlP->backB,&ctrlP->clipR,(TRect FAR *)&intrR);
    
	ctrlP->startTime = startTime;
	ctrlP->endTime = endTime;
	ctrlP->duration = endTime-startTime; 
	
    ReleasePtr(ctrlH);
    TUTORdraw_controller(ctrlH); /* draw the controller */
    TUTORset_view(cv); /* restore the view */
    
    return(ctrlH);
    
} /* TUTORnew_controller */

/* ******************************************************************* */

TUTORclose_controller(ctrlH) /* close controller */
Memh ctrlH;
    
{	struct controlDat FAR *ctrlP;
    struct tutorview FAR *ctrlV;
    struct tutorview FAR *ownerV;

    ctrlP = (struct controlDat FAR *) GetPtr(ctrlH);
    ctrlV = ctrlP->view;
    ownerV = ctrlP->ownerView;
    ReleasePtr(ctrlH);

    TUTORclose_view(ctrlV); /* this will call procctrlr with destroy message */
    TUTORset_view(ownerV); /* restore owner's view */
    return(0);
    
} /* TUTORclose_controller */

/* ******************************************************************* */

static int procctrlr(ctrlH,event)    /* event processor for controller */
Memh ctrlH;
struct tutorevent *event; /* event to process */

{	struct controlDat FAR *ctrlP; /* pointer to controller info */
	TPoint where; /* current click */
	TRect testR; /* rectangle to check against */
	int updatePlay; /* TRUE if need to redraw play/stop button */
	int updateBack; /* TRUE if need to redraw backwards step button */
	int updateFwd; /* TRUE if need to redraw forwards step button */
	int startTimer; /* TRUE if need to start generating timing events */
	struct tutorevent timeEv; /* timing event */
	
    ctrlP = (struct controlDat FAR *) GetPtr(ctrlH);
   	where.vv = event->y;
	where.hh = event->x;
	updatePlay = updateBack = updateFwd = startTimer = FALSE;
	
	switch (event->type) {
	
	case EVENT_REDRAW:
		ReleasePtr(ctrlH);
		return(0); /* we do nothing */
            
	case EVENT_DESTROY:
		event->type = -1;
		if (ctrlP->trackRegion)
			TUTORfree_region(ctrlP->trackRegion);
		ReleasePtr(ctrlH);
    	TUTORfree_handle(ctrlH);	    
    	return(0);
    		
	case EVENT_LEFTDOWN:
		ctrlP->mouseAction = 0; /* haven't identified action yet */
		ctrlP->numMouseDown++; /* identifies this down event */
		
		/* check if click in thumb */
		
		TUTORintersect_rect(&ctrlP->thumbRect,&ctrlP->clipR,(TRect FAR *)&testR);
		if (TUTORpoint_in_rect(where,&testR)) {
			ctrlP->mouseAction = 1;
			ctrlP->thumbXAdj = 2+event->x-(ctrlP->thumbRect.left);
			ctrlP->prevThumb = -1;
			dragThumb(ctrlH,&where);
			break;
		}
		
		/* check if click in play / stop button */
				
		TUTORintersect_rect(&ctrlP->playB,&ctrlP->clipR,(TRect FAR *)&testR);
		if (ctrlP->playVis && TUTORpoint_in_rect(where,&testR)) {
			ctrlP->mouseAction = 2;
			ctrlP->playLit = updatePlay = TRUE; /* highlight button */
			vd_enter();
			TUTORset_abs_clip_rect(&ctrlP->clipR);
			if (ctrlP->playStop) {
				if (ctrlP->playProc)
					(ctrlP->playProc)(ctrlH);
			} else {
				if (ctrlP->stopProc)
					(ctrlP->stopProc)(ctrlH);
			}
			vd_restore();
			break;
		}
		
		/* check if click in backwards button */
				
		TUTORintersect_rect(&ctrlP->backB,&ctrlP->clipR,(TRect FAR *)&testR);
		if (ctrlP->backVis && TUTORpoint_in_rect(where,&testR)) {
			ctrlP->mouseAction = 3;
			ctrlP->backLit = updateBack = TRUE; /* highlight button */
			startTimer = 1;
			if (ctrlP->backProc) {
				vd_enter();
				TUTORset_abs_clip_rect(&ctrlP->clipR);
				(ctrlP->backProc)(ctrlH);
				vd_restore();
			}
			break;
		} else {
		
			/* check if click in forwards button */
			
			TUTORintersect_rect(&ctrlP->fwdB,&ctrlP->clipR,(TRect FAR *)&testR);
			if (ctrlP->fwdVis && TUTORpoint_in_rect(where,&testR)) {
				ctrlP->mouseAction = 4;
				ctrlP->fwdLit = updateFwd = TRUE; /* highlight button */
				startTimer = 1;
				if (ctrlP->fwdProc) {
					vd_enter();
					TUTORset_abs_clip_rect(&ctrlP->clipR);
					(ctrlP->fwdProc)(ctrlH);
					vd_restore();
				}
				break;
			} /* forwards point_in_rect if */
		} /* backwards point_in_rect else */
		
		/* check if click outside of thumb */
		
		TUTORintersect_rect(&ctrlP->trackBack,&ctrlP->clipR,(TRect FAR *)&testR);
		if (TUTORpoint_in_rect(where,&testR)) {
			ctrlP->thumbXAdj = 3;
			ctrlP->mouseAction = 1;
			dragThumb(ctrlH,&where);
		}
		break;
	
	case EVENT_DOWNMOVE:
	
		/* handle thumb drag */
		
		switch (ctrlP->mouseAction) {
		
		case 0: /* nothing to do */
			break;
			
		case 1: /* dragging thumb */
			dragThumb(ctrlH,&where);
			break;
			
		case 2: /* play/stop button down */
			testR = ctrlP->playB;
			if (TUTORpoint_in_rect(where,&testR)) {
				if (!ctrlP->playLit) 
					ctrlP->playLit = updatePlay = TRUE;
			} else {
				if (ctrlP->playLit) {
					ctrlP->playLit = FALSE; /* turn off highlight */
					updatePlay = TRUE;
				}
			}
			break;
		
		case 3: /* backwards button down */
			testR = ctrlP->backB;
			if (TUTORpoint_in_rect(where,&testR)) {
				if (!ctrlP->backLit) 
					ctrlP->backLit = updateBack = TRUE;
			} else {
				if (ctrlP->backLit) {
					ctrlP->backLit = FALSE; /* turn off highlight */
					updateBack = TRUE;
				}
			}
			break;
			
		case 4: /* forewards button down */
			testR = ctrlP->fwdB;
			if (TUTORpoint_in_rect(where,&testR)) {
				if (!ctrlP->fwdLit) 
					ctrlP->fwdLit = updateFwd = TRUE;
			} else {
				if (ctrlP->fwdLit) {
					ctrlP->fwdLit = FALSE; /* turn off highlight */
					updateFwd = TRUE;
				}
			}
			break;
		
		} /* switch */
		break;
		
	case EVENT_LEFTUP:
		switch (ctrlP->mouseAction) {
		
		case 0:
			break; /* nothing to do */
		
		case 1: /* dragging thumb */
			ctrlP->mouseAction = 0;
			ctrlP->prevThumb = -1;
			dragThumb(ctrlH,&where);
			break;
			
		case 2: /* play/stop button */
			/* TUTORupdate_controller will be called to set start/stop state */
			testR = ctrlP->playB;
			ctrlP->playLit = FALSE;
			updatePlay = TRUE;
			break;
			
		case 3: /* backwards button */
			ctrlP->backLit = FALSE;
			updateBack = TRUE;
			break;
			
		case 4: /* forewards button */
			ctrlP->fwdLit = FALSE;
			updateFwd = TRUE;
			break;
			
		} /* mouseAction switch */
		ctrlP->mouseAction = 0;
		break;
		
	case EVENT_TIME:
		if ((event->value == ctrlP->mouseAction) && (event->a1 == ctrlP->numMouseDown)) {
			ctrlP->timerCount++;
			startTimer = 2; /* continue timing */
			if ((ctrlP->mouseAction == 3) && (ctrlP->backLit)) {
				if (ctrlP->backProc) {
					vd_enter();
					TUTORset_abs_clip_rect(&ctrlP->clipR);
					(ctrlP->backProc)(ctrlH);
					vd_restore();
				}
			} else if ((ctrlP->mouseAction == 4) && (ctrlP->fwdLit)) {
				if (ctrlP->fwdProc) {
					vd_enter();
					TUTORset_abs_clip_rect(&ctrlP->clipR);
					(ctrlP->fwdProc)(ctrlH);
					vd_restore();
				}
			}
		}
		break;
			
	default:
		break;
		
	} /* switch */
	
	if (updatePlay || updateFwd || updateBack) {
		vd_enter();
		TUTORset_abs_clip_rect(&ctrlP->clipR);
		if (updatePlay) /* redraw play / stop button */
			drawPlay(ctrlP);
		if (updateFwd) 
			drawFwd(ctrlP);
		if (updateBack)
			drawBack(ctrlP);
		vd_restore();
	}
	
	if (startTimer) {
		if (startTimer == 1)
			ctrlP->timerCount = 0; /* reset count */
		TUTORzero((char FAR *)&timeEv,(long)sizeof(struct tutorevent));
		timeEv.type = EVENT_TIME;
		timeEv.window = ctrlP->window; /* our window */
		timeEv.view = ctrlP->view; /* our view */
		timeEv.value = ctrlP->mouseAction;
		timeEv.a1 = ctrlP->numMouseDown; /* unique to this down event */
		if (ctrlP->timerCount == 0)
			timeEv.timestamp = 700L;
		else if (ctrlP->timerCount < 2)
			timeEv.timestamp = 500L;
		else timeEv.timestamp = 5L;
    	TUTORpost_event(&timeEv);
    }
	
	event->type = -1; /* event was processed here */
	ReleasePtr(ctrlH);
	return(0);
	
} /* procctrlr */

/* ******************************************************************* */

int TUTORupdate_controller(ctrlH,curPos,isPlaying) /* update active controller */
Memh ctrlH; /* handle on controller info */
double curPos; /* current position in media */
int isPlaying; /* TRUE if movie playing */

{   struct controlDat FAR *ctrlP; /* pointer to controller info */
    struct tutorview FAR *cv;
    long curMsec;
	
    if (!ctrlH) return(0); /* nothing to do */

    cv = TUTORinq_view();
    ctrlP = (struct controlDat FAR *) GetPtr(ctrlH);
    if (curPos < ctrlP->startTime) curPos = ctrlP->startTime;
    if (curPos > ctrlP->endTime) curPos = ctrlP->endTime;
    if ((curPos != ctrlP->prevThumb) || (isPlaying != (!ctrlP->playStop))) {
    	ctrlP->thumbPos = curPos;
		vd_enter();
    	TUTORset_view(ctrlP->view); /* set to controller view */
    	drawThumb(ctrlP);
    	if (isPlaying != (!ctrlP->playStop)) {
    		ctrlP->playStop = !isPlaying;
    		drawPlay(ctrlP);
    	}
		vd_restore();
    	TUTORset_view(cv); /* restore view */
    }
    ReleasePtr(ctrlH);
    
} /* TUTORupdate_controller */

/* ******************************************************************* */

int dma_debug = 0;

TUTORdraw_controller(ctrlH)
Memh ctrlH; /* handle on controller info */

{	struct controlDat FAR *ctrlP; /* pointer to controller info */
	TRect lrr; /* local copy of outer rectangle */
	TRect Widget; /* button part */
	long fX[5],fY[5]; /* arrays for polygon fill */
	
	vd_enter(); /* save status */
    ctrlP = (struct controlDat FAR *) GetPtr(ctrlH);
    
    lrr = ctrlP->cRect;
    ctrlP->prevThumb = -1; /* force redraw */
    TUTORset_abs_clip_rect(&ctrlP->clipR);
dma_debug = 1;
    TUTORset_color(1,&ctrlP->cGrey);
    TUTORdraw_abs_solid_rect(&lrr,PAT_WHITE); /* fill whole region */
    CTset_foreground_color(color_black);
    TUTORframe_abs_rect(&ctrlP->cRect); /* frame in black */
    	
    /* draw button partitions */
  
    TUTORabs_move_to(ctrlP->playB.right,ctrlP->playB.top); 
    TUTORabs_line_to(ctrlP->playB.right,ctrlP->playB.bottom);
    TUTORabs_move_to(ctrlP->backB.left,ctrlP->backB.top);
    TUTORabs_line_to(ctrlP->backB.left,ctrlP->backB.bottom);
    TUTORabs_move_to(ctrlP->fwdB.left,ctrlP->fwdB.top);
    TUTORabs_line_to(ctrlP->fwdB.left,ctrlP->fwdB.bottom);
 	  	
   	/* back button */
   	
	drawBack(ctrlP);
   	
   	/* fwd button */
   	
   	drawFwd(ctrlP);
   	
   	/* play / stop button */
   	 	
	drawPlay(ctrlP);
   	
   	/* inner track and thumb */
   	
	drawThumb(ctrlP);
dma_debug = 0;
    ReleasePtr(ctrlH);
	vd_restore(); /* restore status */

} /* TUTORdraw_controller */

/* ******************************************************************* */

static void drawPlay(ctrlP) /* draw play/stop button */
struct controlDat FAR *ctrlP; /* pointer to controller info */

{	TRect Widget; /* button part */
	long fX[5],fY[5]; /* arrays for polygon fill */
	int Hxy; /* offset for highlight */

	if (!ctrlP->playVis)
		return;
	if (ctrlP->playLit) {
		Hxy = 1;
		TUTORset_color(1,&ctrlP->cDkGrey);
	} else {
		Hxy = 0;
   		TUTORset_color(1,&ctrlP->cGrey);
   	}
	Widget.top = ctrlP->playB.top+1;
	Widget.bottom = ctrlP->playB.bottom-1;
	Widget.left = ctrlP->playB.left+1;
	Widget.right = ctrlP->playB.right-1;
   	TUTORdraw_abs_solid_rect((TRect FAR *)&Widget,PAT_WHITE);	
   	
   	/* 3d highlight */
   	
   	CTset_foreground_color(color_black);
   	if (ctrlP->playLit) {
   		TUTORabs_move_to(ctrlP->playB.left+1,ctrlP->playB.bottom-1);
   		TUTORabs_line_to(ctrlP->playB.left+1,ctrlP->playB.top+1);
   		TUTORabs_line_to(ctrlP->playB.right-1,ctrlP->playB.top+1);
   	}
   	
	if (ctrlP->playStop) { /* play button */
   		fX[4] = fX[1] = ctrlP->playB.left+6+Hxy; fY[4] = fY[1] = ctrlP->playB.top+4+Hxy;
   		fX[2] = ctrlP->playB.left+10+Hxy; fY[2] = ctrlP->playB.top+8+Hxy;
   		fX[3] = ctrlP->playB.left+6+Hxy; fY[3] = ctrlP->playB.top+12+Hxy;
   		TUTORabs_fill_polygon(4,fX,fY); 
   	} else { /* stop button */
		CTset_background_color(color_black);
   		Widget.left = ctrlP->playB.left+5+Hxy;
   		Widget.right = ctrlP->playB.left+6+Hxy;
   		Widget.top = ctrlP->playB.top+4+Hxy;
   		Widget.bottom = ctrlP->playB.top+11+Hxy;
   		TUTORdraw_abs_solid_rect((TRect FAR *)&Widget,PAT_WHITE);
   		Widget.left = ctrlP->playB.left+8+Hxy;
   		Widget.right = ctrlP->playB.left+9+Hxy;
   		TUTORdraw_abs_solid_rect((TRect FAR *)&Widget,PAT_WHITE);
   	}
   	
} /* drawPlay */

/* ******************************************************************* */

static void drawBack(ctrlP) /* draw backwards step button */
struct controlDat FAR *ctrlP; /* pointer to controller info */

{	TRect Widget; /* button part */
	long fX[5],fY[5]; /* arrays for polygon fill */
	int Hxy; /* offset for highlight */
  		
  	if (!ctrlP->backVis)
  		return;
  		
   	/* background of back button */
   	
	if (ctrlP->backLit) {
		Hxy = 1;
		TUTORset_color(1,&ctrlP->cDkGrey);
	} else {
		Hxy = 0;
   		TUTORset_color(1,&ctrlP->cGrey);
   	}
	Widget.top = ctrlP->backB.top+1;
	Widget.bottom = ctrlP->backB.bottom-1;
	Widget.left = ctrlP->backB.left+1;
	Widget.right = ctrlP->backB.right-1;
   	TUTORdraw_abs_solid_rect((TRect FAR *)&Widget,PAT_WHITE);   	
   		
   	/* 3d highlight */
   	
   	CTset_foreground_color(color_black);
   	if (ctrlP->backLit) {
   		TUTORabs_move_to(ctrlP->backB.left+1,ctrlP->backB.bottom-1);
   		TUTORabs_line_to(ctrlP->backB.left+1,ctrlP->backB.top+1);
   		TUTORabs_line_to(ctrlP->backB.right-1,ctrlP->backB.top+1);
   	}
   	
    /* triangle part of back button */
    
    CTset_foreground_color(color_black);
    fX[0] = fY[0] = 0; /* array starts with fX[1], fY[1] */
    fX[4] = fX[1] = ctrlP->backB.left+7+Hxy; fY[4] = fY[1] = ctrlP->backB.top+3+Hxy;
    fX[2] = ctrlP->backB.left+2+Hxy; fY[2] = ctrlP->backB.top+8+Hxy;
    fX[3] = ctrlP->backB.left+7+Hxy; fY[3] = ctrlP->backB.top+12+Hxy;
   	TUTORabs_fill_polygon(4,fX,fY);   
   		
   	/* rectangle part of back button */
   	
   	Widget.left = ctrlP->backB.left+9+Hxy;
   	Widget.top = ctrlP->backB.top+4+Hxy;
   	Widget.right = ctrlP->backB.left+10+Hxy;
   	Widget.bottom = ctrlP->backB.top+11+Hxy;
  	CTset_background_color(color_black);
   	TUTORdraw_abs_solid_rect((TRect FAR *)&Widget,PAT_WHITE);    
   		
} /* drawBack */

/* ******************************************************************* */

static void drawFwd(ctrlP) /* draw forewards step button */
struct controlDat FAR *ctrlP; /* pointer to controller info */

{	TRect Widget; /* button part */
	long fX[5],fY[5]; /* arrays for polygon fill */
	int Hxy; /* offset for highlight */
	
	if (!ctrlP->fwdVis)
		return;
		
	/* background of forwards button */
	
	if (ctrlP->fwdLit) {
		Hxy = 1;
		TUTORset_color(1,&ctrlP->cDkGrey);
	} else {
		Hxy = 0;
   		TUTORset_color(1,&ctrlP->cGrey);
   	}
	Widget.top = ctrlP->fwdB.top+1;
	Widget.bottom = ctrlP->fwdB.bottom-1;
	Widget.left = ctrlP->fwdB.left+1;
	Widget.right = ctrlP->fwdB.right-1;
   	TUTORdraw_abs_solid_rect((TRect FAR *)&Widget,PAT_WHITE);   
   	
   	/* 3d highlight */
   	
   	CTset_foreground_color(color_black);
   	if (ctrlP->fwdLit) {
   		TUTORabs_move_to(ctrlP->fwdB.left+1,ctrlP->fwdB.bottom-1);
   		TUTORabs_line_to(ctrlP->fwdB.left+1,ctrlP->fwdB.top+1);
   		TUTORabs_line_to(ctrlP->fwdB.right-1,ctrlP->fwdB.top+1);
   	}
   	   	   		
   	/* triangle part of forward button */
   		
   	fX[4] = fX[1] = ctrlP->fwdB.left+8+Hxy; fY[4] = fY[1] = ctrlP->fwdB.top+4+Hxy;
   	fX[2] = ctrlP->fwdB.left+12+Hxy; fY[2] = ctrlP->fwdB.top+8+Hxy;
   	fX[3] = ctrlP->fwdB.left+8+Hxy; fY[3] = ctrlP->fwdB.top+12+Hxy;
   	TUTORabs_fill_polygon(4,fX,fY);   
   	 	
   	/* rectangle part of fwd button */
   	
   	Widget.left = ctrlP->fwdB.left+4+Hxy;
   	Widget.top = ctrlP->fwdB.top+4+Hxy;
   	Widget.right = ctrlP->fwdB.left+5+Hxy;
   	Widget.bottom = ctrlP->fwdB.top+11+Hxy;
   	CTset_background_color(color_black);
   	TUTORdraw_abs_solid_rect((TRect FAR *)&Widget,PAT_WHITE);   
   	    	
} /* drawFwd */

/* ******************************************************************* */

static void dragThumb(ctrlH,where) /* drag thumb to position */
Memh ctrlH; /* handle on controller info */
TPoint *where; /* current click */	

{	struct controlDat FAR *ctrlP; /* pointer to controller info */
	double curTime; /* current media position */
	double frPos; /* position within media range */
	
	ctrlP = (struct controlDat FAR *)GetPtr(ctrlH);
	frPos = (double)(where->hh-ctrlP->thumbXAdj-ctrlP->trackBack.left)/ctrlP->trackWidth;
	curTime = ctrlP->startTime+(frPos*ctrlP->duration);
	if (curTime < ctrlP->startTime)
		curTime = ctrlP->startTime;
	else if (curTime > ctrlP->endTime)
		curTime = ctrlP->endTime;
	ctrlP->thumbPos = curTime;
	ReleasePtr(ctrlH);
	vd_enter();
	TUTORset_abs_clip_rect(&ctrlP->clipR);
	if (ctrlP->thumbProc)
		(ctrlP->thumbProc)(ctrlH);
	vd_restore();
			
} /* dragThumb */

/* ******************************************************************* */

static void drawThumb(ctrlP) /* draw thumb at current position */
struct controlDat FAR *ctrlP; /* pointer to controller info */

{	TRect lrr; /* local copy of outer rectangle */
	TRect Widget; /* controller part */
	int thumbPos; /* thumb position */
	
    if (ctrlP->thumbPos < ctrlP->startTime) {
    	ctrlP->thumbPos = ctrlP->startTime;
    	ctrlP->prevThumb = -1;
    } else if (ctrlP->thumbPos > ctrlP->endTime) {
    	ctrlP->thumbPos = ctrlP->endTime;
    	ctrlP->prevThumb = -1;
    }
    
	if (ctrlP->thumbPos == ctrlP->prevThumb)
		return; /* nothing to do */
		
	TUTORset_abs_clip_rect(&ctrlP->clipR);	
	lrr = ctrlP->cRect;
	
	if ((!ctrlP->trackRegion) || ctrlP->drawTrack) {
    
	    /* draw track region background */
    
	    Widget = ctrlP->trackBack;
	    TUTORset_color(1,&ctrlP->cGrey);
	    TUTORdraw_abs_solid_rect(&Widget,PAT_WHITE); /* fill track region */
    
		/* draw track foreground */
     
	    TUTORframe_abs_rect(&ctrlP->trackFore); /* draw track outline */
	    CTset_foreground_color(color_black);
	    TUTORabs_move_to(ctrlP->trackFore.left,ctrlP->trackFore.bottom);
	    TUTORabs_line_to(ctrlP->trackFore.left,ctrlP->trackFore.top);
	    TUTORabs_line_to(ctrlP->trackFore.right,ctrlP->trackFore.top);
	    CTset_foreground_color(color_white);
	    TUTORabs_line_to(ctrlP->trackFore.right,ctrlP->trackFore.bottom);
	    TUTORabs_line_to(ctrlP->trackFore.left,ctrlP->trackFore.bottom);
    
	    Widget = ctrlP->trackFore;
	    Widget.left += 1;
	    Widget.right -= 1;
	    Widget.top += 1;
	    Widget.bottom -= 1;
	    TUTORset_color(1,&ctrlP->cDkGrey);
	    TUTORdraw_abs_solid_rect(&Widget,PAT_WHITE); /* fill inside of track */
	    ctrlP->drawTrack = FALSE;
	    if (!ctrlP->trackRegion)
    		ctrlP->trackRegion = TUTORabs_save_region(ctrlP->trackFore.left+1,
    							ctrlP->trackBack.top,ctrlP->trackFore.left+7,ctrlP->trackBack.bottom);
	} else {
		TUTORabs_restore_region(ctrlP->trackRegion,ctrlP->thumbRect.left,ctrlP->trackBack.top);
		if ((ctrlP->thumbRect.left <= ctrlP->trackFore.left) || 
			(ctrlP->thumbRect.right >= ctrlP->trackFore.right)) {
		   	CTset_foreground_color(color_black);
		   	TUTORabs_move_to(ctrlP->trackFore.left,ctrlP->trackFore.bottom);
	    	TUTORabs_line_to(ctrlP->trackFore.left,ctrlP->trackFore.top);
	    	TUTORabs_line_to(ctrlP->trackFore.right,ctrlP->trackFore.top);
	    	CTset_foreground_color(color_white);
	    	TUTORabs_line_to(ctrlP->trackFore.right,ctrlP->trackFore.bottom);
	    	TUTORabs_line_to(ctrlP->trackFore.left,ctrlP->trackFore.bottom);
		}
	}
	
	/* draw thumb */
    
	thumbPos = (double)(ctrlP->trackWidth-6)*(ctrlP->thumbPos-ctrlP->startTime) / (ctrlP->duration);
   	thumbPos += (ctrlP->trackFore.left);
   	if (thumbPos < (ctrlP->trackFore.left))
   		thumbPos = ctrlP->trackFore.left;
   	if (thumbPos > (ctrlP->trackFore.right-6))
   		thumbPos = ctrlP->trackFore.right-6;
   	Widget.left = thumbPos;
   	Widget.top = lrr.top+1;
   	Widget.right = Widget.left+6;
   	Widget.bottom = lrr.bottom-1;
   	ctrlP->thumbRect = Widget; /* current thumb rectangle */
   	CTset_foreground_color(color_black);
   	TUTORframe_abs_rect((struct _trect FAR *)&Widget);
   	Widget.left++;
   	Widget.top++;
   	Widget.right--;
   	Widget.bottom--;
   	TUTORset_color(1,&ctrlP->cGrey);
   	TUTORdraw_abs_solid_rect(&Widget,PAT_WHITE); /* fill inside of thumb */
   	if (ctrlP->mouseAction == 1)
   		CTset_foreground_color(color_black);
   	else {
   	   	TUTORset_color(0,&ctrlP->cDkGrey);
   	   	TUTORabs_move_to(Widget.right,Widget.top);
   		TUTORabs_line_to(Widget.right,Widget.bottom);
   		CTset_foreground_color(color_white);
   	}
   	TUTORabs_move_to(Widget.left,Widget.bottom);
   	TUTORabs_line_to(Widget.left,Widget.top);
   	TUTORabs_line_to(Widget.right,Widget.top);
   	
   	ctrlP->prevThumb = ctrlP->thumbPos; /* remember position */
 
} /* drawThumb */

/* ******************************************************************* */

vd_enter() /* save/initialize status for graphics operation */

{   int ascent, descent, maxwidth, leading;
    TRect tr;

    vd_fontid = textFont; /* save current font */
    vd_fc = fgndColor; /* save foreground, background colors */
    vd_bc = bgndColor;
    vd_mode = CurrentMode;
	vd_thick = lineThick;
	vd_clipR = tgclipR; /* save clip rectangle */
	
    tr.left = tr.top = 0;
    tr.right = tr.bottom = 10000;
    TUTORset_abs_clip_rect((TRect FAR *) &tr); /* unclip */
    TUTORset_comb_rule(SRC_OR);  /* mode write */
	lineThick = 0;

} /* vd_enter */

/* ******************************************************************* */

vd_restore() /* restore status after graphics */

{
    if (vd_mode >= 0)
	TUTORset_comb_rule((int)vd_mode); /* restore mode */
    else TUTORset_comb_rule(SRC_OR);
	TUTORset_abs_clip_rect(&vd_clipR); /* restore clip region */
    if (vd_fontid >= 0)
	TUTORset_textfont(vd_fontid);
    TUTORset_color(0,&vd_fc);
    TUTORset_color(1,&vd_bc);
	TUTORline_thick(vd_thick);
 
} /* vd_restore */

/* ******************************************************************* */

int CloseMMotionVideo() { return(0); }
int CloseExternalVideo() { return(0); }

/* ******************************************************************* */
