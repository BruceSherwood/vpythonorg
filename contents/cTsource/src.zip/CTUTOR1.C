
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
part of the command compiler
*/

#include "ctutor.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "exprdefs.h"
#include "yacc.h"
#include "ct_ctype.h"

#ifdef ctproto
int  pbscan(unsigned char  FAR *str,int  indx,char *target);
int compile_touch_cmd(int code,int contF);
int compile_buffer_len(int allow_mark);
extern int TUTORtrace_n(char *str,long val);
extern int comp_unit_args(void);
extern int init_unit_defines(void);
extern int set_wk_defset(Memh setH);
extern int end_global_defines(void);
extern int end_local_defines(void);
extern int TUTORzero(char SHUGE *ptr,long len);
extern int comp_define_line(void);
int  compile1(void);
int  compile_case_table(struct  caseopt *casep);
int  sort_case_table(struct  caseopt *casep);
int  cerror(int  errnumber,char  *execstr);
int  MatchUnitName(unsigned char  *name);
int  _TUTORinq_state_internal_marker(int  ind,long  *pos,long  *len,int  *altered);
int  extract_unit(char  *unitn,int  *term,int  iFlag);
int  cmpbuf_plant_word(unsigned int  addr,int  n);
int  add_dest(int  type,int  label,unsigned int  pos);
int  plant_xref(int  iref,unsigned int  adest);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  cmpbuf_word(int  n);
int  add_xref(int  kind,int  label,unsigned int  aref,unsigned int  adest);
char  FAR *GetPtr(unsigned int  mm);
int  StartCondTable(void);
int  compile_simple_numeric(int  nmask,int  fmask,int  stopl);
int  compile_short_value(int  vv);
int  cmpbuf_xref(int  kind,int  label);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
int  CTisascii(int  cc);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
int  deflook(char  *s,int  glf,int  symi);
int  extract_keyword_cB(char  *kname,int  maxl,int  spaces,int  *term);
long  TUTORget_hsize(unsigned int  mm);
int  skip_white_cB(void);
int  FillBuffer(unsigned int  readDoc,long  readPos,long  maxRead);
int  next_cB(void);
int  StripTrailingComment(int  cIndex,int  cmdN);
int  getdefines(long  currentkind);
int  satisfy_xref(int  index,int  kind,int  label,unsigned int  adest);
int  compile_ubranch(int  kind,int  label);
int  compile(struct  expra *exap);
int  compile_points(int  min,int  limit,int  type,int  stopl,int  cont,int  czxy,int  blank,int  coarse,int  skip);
int  TUTORdealloc(char  FAR *ptr);
char  FAR *TUTORrealloc(char  FAR *ptr,long  oldsize,long  newsize,int  abort);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  compile_file(int  storef);
int  compile_keyword_and_args(struct  keywdinf *klist,int  *term);
int  compile_marker(int  storef,int  semic);
int  pbscan(unsigned char  FAR *str,int  indx,char  *target);
int  compile_txtype(int  type,int storef);
int  compile_float(void);
int  compile2(void);
int  compile_single_keyword(struct  keywdinf *klist,int  *term);
int  extract_touch_keywords(int  *ttrm,int  stopC,int  simpleF);
#endif /* ctproto */

extern long TUTORget_hsize();
extern int oldCmnd;

static unsigned short writePos=0L; /* position of last compiled write command */

static struct keywdinf rwlist[5] = { {"rw",KW_READWRITE}, {"ro",KW_READONLY},
                {"wo",KW_WRITEONLY}, {"styled",KW_STYLED}, {NULL,0} };

static struct keywdinf addflist[3] = { {"styled",KW_STYLED}, {"name",KW_FNAME}, {NULL,0} };

static struct keywdinf resetfilelist[4] = { {"start",0}, {"end",1}, {"empty",2}, 
                {NULL,0} };

/* added threed style button 6/3/91 BJM */
static struct keywdinf buttonlist[7] = { 
                {"check",KW_CHECK},{"radio",KW_RADIO},{"3d",KW_THREED}, {"value",KW_VALUE}, 
                {"active",KW_ACTIVE}, {"erase",KW_ERASE}, {NULL,0} };

/* {"roundbox",KW_ROUNDBOX}, "threed",KW_THREED}, */

static struct keywdinf buttonlistr[2] = { {"value",KW_VALUE},{NULL,0} };

static struct keywdinf sliderlist[9] = { {"numeric",KW_NUMERIC}, 
                {"horizontal", KW_HSCROLL}, {"horiz", KW_HSCROLL}, 
                {"erase",KW_ERASE}, {"value",KW_VALUE},
                {"page",KW_PAGE}, {"line",KW_LINE}, {"range",KW_RANGE},
                {NULL,0}  };

static struct keywdinf sliderlistr[2] = { {"value",KW_VALUE},
                {NULL,0}  };

static struct keywdinf editlist[21] = { {"editable",KW_EDITABLE}, 
                {"erase",KW_ERASE}, {"leftmar",KW_LEFTMAR}, {"rightmar",KW_RIGHTMAR},
                {"hscroll",KW_HSCROLL}, {"vscroll",KW_VSCROLL},
                {"frame",KW_FRAME}, {"select",KW_SELECT}, 
                {"visible",KW_VISIBLE}, {"tab",KW_TAB}, 
                {"before event",KW_BEFORE},
                {"after event",KW_AFTER}, {"single select",KW_SINGLESEL}, 
                {"focus click",KW_FOCUSCLK}, {"highlight",KW_HIGHLIGHT}, 
                {"newline",KW_NEWLINEH}, {"supsub",KW_SUPSUB}, 
                {"up hot",KW_UPHOT}, {"supsubadjust",KW_SUPSUBADJ}, {NULL,0} };

/* {"corner",KW_CORNER}{"default menus",KW_DEFMENU},
{"face menus",KW_FACEMENU}, 
                {"font menus",KW_FONTMENU},{"size menus",KW_SIZEMENU}, 
                {"color menus",KW_COLORMENU},
{"justify menus",KW_JUSTMENU},  */

static struct keywdinf editlistr[11] = { {"select",KW_SELECT}, 
                {"visible",KW_VISIBLE}, {"single select",KW_SINGLESEL}, 
                {"focus click",KW_FOCUSCLK}, {"highlight",KW_HIGHLIGHT}, 
                {"before event",KW_BEFORE},
                {"after event",KW_AFTER},
                {"hot",KW_HOTUNIT},
                {"editable",KW_EDITABLE}, {"up hot",KW_UPHOT}, {NULL,0} };


static struct keywdinf fplist[2] = { {"native",KW_NATIVE}, {NULL,0} };

static int touchOpts = 0; /* accumulated -touch- options */

/**********************************************/
compile1() {
int i, j;
long loc;
char c, ws[NAMEL+1];
Memh specialDat;
struct defvar FAR *lvarptr;
struct condctab FAR *condPos; /* pointer in conditional command table */
int thislabel; /* internal branch label to satisfy */
struct defvar FAR *dvarp; /* pointer to global/local defs */
struct defvar dvar; /* global or local variable definition */
long FAR *dorderp; /* pointer to gvarorder/lvarorder */
struct arg_desc FAR *adp; /* pointer to argument descriptor */
int valuef; /* TRUE if processing value args, false if address args */
long svst; /* saved start of line */
int term; /* terminating character */
int tindx; /* index of terminating character */
struct expra wkexa; /* scratch analyzer params */
struct caseopt *casep; /* -case- optimization table */
int clauselabel; /* internal label for current case clause */
int casei; /* index in -case- optimization table */
int nclause; /* number -case- clauses for single case */
struct indenter *idP; /* pointer to indent table entry */
int indentlv; /* command indent level */
int markf; /* xin/xout/datain/dataout marker expression flag */
int unitn; /* unit number */
int argt; /* 0 = absolute, 1 = relative, 2 = graphing type */
int coarsef; /* TRUE if coarse grid allowed */
long tempPos;
int unn; /* unit number */

chkeol = TRUE; /* assume real command, do end-of-line checks */

switch (newcmd) {

case UNITSTART:
case UNITEND:
    addcmd = -1; /* dont add to binary */
    chkeol = FALSE;
    break;

case ENVIC: /* $syntaxlevel type statement */
    if (compunit)
        cerror(SPECIFICERR,"$ statements must be at begin of file.");
    addcmd = -1; /* dont add to binary */
    chkeol = FALSE;
    break;

case BLANK: cerror(BLANKCOMMAND,NEARNULL);
    break;

case CMDERR:
    srcPos = startgetcmd;
    j = 0;
    while ((CTisascii(i = TUTORcharat_doc(source,srcPos))) &&
           CTisalnum(i) && (j < 8)) {
        srcPos++; /* position the caret */
        j++;
    } /* while */
    loc = srcPos;
    while (((i = TUTORcharat_doc(source,loc)) == ' ') || (i == '\t'))
        loc++;
    if (indentlevel && (i == ':') && (TUTORcharat_doc(source,(loc+1)) == '='))
        cerror(SPECIFICERR,"Illegal command: should be calc?");
    i = TUTORcharat_doc(source,srcPos);
    if (i==' ') cerror(SPECIFICERR, "Use TAB to separate commands from arguments.");
    else cerror(BADCOMMAND,NEARNULL);
    break;

case C_COND: /* begin of conditional */
    chkeol = FALSE;
    cstartcommand = cmpl; /* remember begin of conditional command */
    condref1 = cmpbuf_xref(R_COND,labelID++); /* address of end of statement */
    condref2 = cmpbuf_xref(R_COND,labelID++); /* address of conditional table */
    condref3 = cmpl; /* address of maximum index */
    compile_short_value(0); /* maximum index (condcount-2) */
    compile_simple_numeric(0x80,0x00,TRUE); /* condition expression */
    StartCondTable(); /* initialize conditional commands table */
    /* following this will be the commands, each of which ends in C_CONDOUT */
    /* following all the commands is a table of ptrs to the individual commands */
    cmpbuf_word(C_COND); /* add conditional command */
    addcmd = -1;
    break;

case C_CONDEND: /* end of a command */
    chkeol = FALSE;
    cmpbuf_word(C_CONDOUT); /* terminate this command */
    addcmd = -1;
    break;

case C_CONDDONE: /* completely done with conditional command */
    chkeol = FALSE;
    cmpbuf_word(C_CONDOUT); /* to terminate previous command */
    if (condcount < 2)
        cerror(SPECIFICERR,"Conditional command with only one clause.");

    thislabel = xrefP[condref2].label;
    add_dest(RD_COND2,thislabel,cmpl); /* mark this point in binary */
    plant_xref(condref2,(unsigned int)cmpl); /* location of table */
    cmpbuf_word(ULOCTABL); /* table of relative addrs within unit */
    cmpbuf_word(nCondTag); /* number entries in table */
    
    /* insert conditional command table entries */

    condPos = (struct condctab FAR *) GetPtr(condTh);
    for (i=0; i<nCondTag; i++) {
        /* add to cross-reference table */
        add_xref(R_COND+0x80,condPos[i].label,cmpl,condPos[i].pos); 
        cmpbuf_word(condPos[i].pos);
    }
    ReleasePtr(condTh);
    KillPtr(condPos);
    plant_xref(condref1,(unsigned int)cmpl); /* end of conditional */
    thislabel = xrefP[condref1].label;
    add_dest(RD_COND1,thislabel,cmpl); /* mark this point in binary */
    cmpbuf_plant_word(condref3+2,condcount-2); /* max index */
    addcmd = -1;
    break;

case C_UNIT:
    addcmd = -1; /* no command code in binary */

    /* get unit name */

    unn = extract_unit(ws,&term,FALSE);
    if (strcmp(ws, "x") == 0 || strcmp(ws, "q") == 0) {
    	nunits = -1;
        cerror(SPECIFICERR,"A unit cannot be named x or q.");
    }
    if (unn < 0) {
		nunits = -1;
        cerror(SPECIFICERR,"Badly formed -unit- command.");
    }
    
    /* check to avoid infinite loop when unit table does not */
    /* match source code */

    loc = (csourcen << 24)+srcPos;
    _TUTORinq_state_internal_marker(unittab[compunit].marki,&tempPos,NEARNULL,NEARNULL);
    if ((startofline != tempPos) || (compunit != MatchUnitName((unsigned char *)ws))) {
    	nunits = -1;
        cerror(SPECIFICERR,"Badly formed -unit- command.");
    }

    /* initialize defines and unit arguments table */
    
    init_unit_defines(); /* initialize define set */
    if (uargP == NULL) 
        uargP = (struct argdef FAR *)GetPtr(uargH);
    TUTORzero((char SHUGE *)uargP,TUTORget_hsize(uargH));
    npass_by_value = npass_by_addr = 0; /* no arguments yet */
    ReleasePtr(uargH); /* release arguments table */
    uargP = NULL;
    
    /* extract unit arguments for processing at end of */
    /* local defines */
    
    if (term != NEWLINE) { /* has arguments */
    if (term == '{')
    	cerror(WRONGSEP,NEARNULL);
	if ((term != '(') && (term != '['))
	     cerror(BADNAME, NEARNULL);
        comp_unit_args(); /* extract unit arguments */
        if ((compunit == 1) && npass_by_addr)
            cerror(SPECIFICERR,"First unit cannot have address arguments."); 
    }
    break;

case C_DEFINEEND:
    addcmd = -1; /* no command code in binary */
    chkeol = FALSE;
    if (compunit == 0) {
        /* set to use symbols from default global set */
        set_wk_defset(globalSetH);
    } else {
        end_local_defines();
    }
    break;

case C_DEFINE:
    addcmd = -1; /* no command code in binary */
    chkeol = FALSE;
    if (local_def_fin || ((compunit == 0) && global_def_fin))
    	cerror(SPECIFICERR,"Can't use -define- here"); 
    comp_define_line(); /* compile line of defines */
    break;

case USE:
    chkeol = FALSE; /* syntax checked by FindUnits */
    if (compunit) 
        cerror(SPECIFICERR,"Improperly placed -use- command.");
    addcmd = -1; /* dont add to binary */
    break;

case C_CASE: 
    wkexa = defexp;
    wkexa.allowm = TRUE; /* allow marker expression */
    compile(&wkexa); 
    if (wkexa.exprtype == TMARK)
        addcmd = C_CASEM; /* change command code for string */
    else if (wkexa.exprtype == TFLOAT)
        compile_short_value(0); /* dummy result on int stack */
    compile_short_value((int)wkexa.exprtype); 
    idP = &indent[indentlevel];
    idP->exprtype = wkexa.exprtype;
    /* forward ref to else  */
    idP->headref = cmpbuf_xref(R_CASE1,labelID++); 
    idP->endlabel = labelID++; /* reserve label for endcase */
    idP->nextlabel = labelID++; /* reserve label for next clause */

    /* set for possible optimization if all-integer-constants */

    cmpbuf_xref(R_CASE2,labelID++); /* fwd ref to table (headref+1) */
    /* command code immediately follows table */
    idP->constf = (wkexa.exprtype == TINT);
    idP->lastif = C_CASE;
    caseod[indentlevel].nitems = 0; /* reset -case- optimization table */
    caseod[indentlevel].head = cmpl; /* pointer to C_CASE command */
    break;

case C_CLAUSE:
    indentlv = indentlevel-1; /* indentlevel-1 since clause pushed */
    idP = &indent[indentlv];
    if (idP->lastif == C_ELSE)
        cerror(SPECIFICERR,"Expected -endcase- here");
    if (idP->lastif != C_CASE) {

        /* add branch at end of previous clause */
        compile_ubranch(R_CASE3,idP->endlabel);

        /* resolve forward reference from begin of previous clause */
        satisfy_xref(idP->headref,R_CLAUSE,idP->nextlabel,(unsigned int)cmpl); 
    }
    
    /* label this clause command */
    add_dest(RD_CLAUSE,idP->nextlabel,cmpl); /* mark this point in binary */
    
    /* set up forward reference to next clause */
    thislabel = labelID++;
    cmpbuf_xref(R_CLAUSE,thislabel); /* forward ref to next clause */
    idP->lastif = C_CLAUSE;
    idP->nextlabel = thislabel; /* fwd to next clause */

    /* compile list of expressions */

    casep = &caseod[indentlv]; /* ptr to -case- table entry */
    casei = casep->nitems; /* starting index in optimization table */
    nclause = 0; /* number clauses */
    do {

        /* compile next expression */

        wkexa = defexp; /* expression must have same type as selector */
        wkexa.rtype = idP->exprtype;
        compile(&wkexa); /* compile clause expression */
        if (!wkexa.isconst) 
            idP->constf = FALSE; /* not all constants */

        /* build table for possible optimization if all integer constants so far */

        if (idP->constf) {
            if (!casep->cv) { /* allocate table if neccessary */
                casep->cv = 
                    (struct caseoptv FAR *)TUTORalloc((long)(32*sizeof(struct caseoptv)),
                                                  TRUE,"case");
                casep->nalloc = 32;
            }
            if (casep->nitems >= casep->nalloc) { /* expand value table */
                casep->cv = 
                    (struct caseoptv FAR *)TUTORrealloc((char FAR *)casep->cv,
                                (long)(casep->nalloc*sizeof(struct caseoptv)),
                                (long)((casep->nalloc+16)*sizeof(struct caseoptv)),
                                TRUE);
                casep->nalloc += 16;
            } /* nitems if */
            casep->cv[casep->nitems].value = wkexa.iconst; /* save value */
            casep->cv[casep->nitems++].address = -1; /* location unknown */
        } /* constf if */
        j = ((idP->exprtype == TMARK) ? EX_MSTACKL : EX_STACKL);
        if ((nclause++) >= j)
            cerror(SPECIFICERR,"Too many values for this -case- clause");
    } while (wkexa.lastchar != NEWLINE);

    clauselabel = labelID++;
    if (idP->constf) { /* all const so far */
        for(i=casei; i<casep->nitems; i++) { /* fill in table */ 
            casep->cv[i].address = cmpl+sizeof(short); /* point to clause */
            casep->cv[i].label = clauselabel;
        }
    } /* constf if */
    cmpbuf_word(C_CLAUSE); /* add -clause- command */
    /* mark beginning of clause body */
    add_dest(RD_CLAUSEB,clauselabel,cmpl); 
    addcmd = -1;
    break;

case C_ENDCLAUSE:
    chkeol = FALSE;
    addcmd = -1; /* no command code in binary */
    break;

case C_ENDCASE:
    /* indent info is at indentlevel+1 because already popped */
    indentlv = indentlevel+1;
    idP = &indent[indentlv];
    
    /* handle all integer constants -case- */

    casep = &caseod[indentlv];
    thislabel = xrefP[idP->headref+1].label; /* table label*/
    if (idP->constf) {

        /* add branch at end of previous clause/else */

        if (idP->lastif != C_CASE)
            compile_ubranch(R_CASE3,idP->endlabel);

        /* generate table for optimized -case- */

        loc = cmpl; /* save location of table */
        if (compile_case_table(casep)) {
            add_dest(RD_CASET,thislabel,(unsigned int)loc);
            thislabel = 0; /* table label satisfied */
            plant_xref(idP->headref+1,(unsigned int)loc); 
            
            /* change command code to optimized form */
        
            *(short FAR *)(&cmpbuf[caseod[indentlv].head]) = C_CASET;
        } /* compile_case_table if */
    } /* constf if */

    /* assign dummy label to case table if no case table */

    if (thislabel) {
        add_dest(RD_CASET,thislabel,cmpl);
        plant_xref(idP->headref+1,(unsigned int)cmpl); 
    }

    /* clean up optimization table */

    if (casep->cv) {
        TUTORdealloc((char FAR *)casep->cv);
        casep->cv = NULL;
    }
    casep->nitems = casep->nalloc = 0;

    add_dest(RD_ENDCASE,idP->endlabel,cmpl);
    /* resolve forward reference from begin of previous clause */
    if (idP->nextlabel) {
        satisfy_xref(idP->headref,R_CLAUSE,idP->nextlabel,(unsigned int)cmpl); 
        add_dest(RD_ENDCASE,idP->nextlabel,cmpl);
    }
    /* resolve forward reference to else if not already resolved */
    if (idP->lastif != C_ELSE) {
        thislabel = xrefP[idP->headref].label;
        satisfy_xref(idP->headref,R_CASE1,thislabel,(unsigned int)cmpl);
        add_dest(RD_CASEELSE,thislabel,cmpl); /* mark this point in binary */
    }
    /* resolve forward references from ends of clauses */
    satisfy_xref(idP->headref,R_CASE3,idP->endlabel,(unsigned int)cmpl);
    break;

case C_AT:
    compile_points(1,2,0,FALSE,FALSE,FALSE,0,TRUE,FALSE);
    break;

case C_ATNM:
    compile_points(1,1,0,FALSE,FALSE,FALSE,0,TRUE,FALSE);
    break;

case C_FILL:
    skip_white_cB();
    if (cB[cI] == NEWLINE)
	break; /* blank tag form */
    if (continFlag) cmpl -= 2; /* remove previous command code */
    compile_points(1,FILLPOINTS,0,FALSE,continFlag,FALSE,0,TRUE,FALSE);
    break;

case C_DOT: 
    compile_points(1,-20,0,FALSE,FALSE,FALSE,1,TRUE,FALSE);
    break;

case C_DRAW:
    compile_points(1,-20,0,FALSE,continFlag,TRUE,0,TRUE,TRUE);
    break;

case C_RAT:
    compile_points(1,2,1,FALSE,FALSE,FALSE,0,FALSE,FALSE);
    break;

case C_RATNM:
    compile_points(1,1,1,FALSE,FALSE,FALSE,0,FALSE,FALSE);
    break;

case C_RDOT:
    compile_points(1,-20,1,FALSE,FALSE,FALSE,1,FALSE,FALSE);
    break;

case C_RDRAW:
    compile_points(1,-20,1,FALSE,continFlag,TRUE,0,FALSE,TRUE);
    break;

case C_RFILL:
case C_RERASE:
    if (continFlag) cmpl -= 2; /* remove previous command code */
    compile_points(1,FILLPOINTS,1,FALSE,continFlag,FALSE,0,FALSE,FALSE);
    break;

case C_GAT:
    compile_points(1,2,2,FALSE,FALSE,FALSE,0,FALSE,FALSE);
    break;


case C_GATNM:
    compile_points(1,1,2,FALSE,FALSE,FALSE,0,FALSE,FALSE);
    break;  

case C_GDOT:
    compile_points(1,-20,2,FALSE,FALSE,FALSE,1,FALSE,FALSE);
    break;

case C_GDRAW:
    compile_points(1,-20,2,FALSE,continFlag,TRUE,0,FALSE,TRUE);
    break;

case C_GFILL:
case C_GERASE:
    if (continFlag) cmpl -= 2; /* remove previous command code */
    compile_points(1,FILLPOINTS,2,FALSE,continFlag,FALSE,0,FALSE,FALSE);
    break;

case C_HBAR:
case C_VBAR:
    compile_points(1,FILLPOINTS,2,FALSE,FALSE,FALSE,0,FALSE,FALSE);
    break;
   
case C_POLAR:
    compile_simple_numeric(0x180,0x00,FALSE);
    break;

case C_RORIGIN:
case C_GORIGIN:
    compile_points(1,1,0,FALSE,FALSE,FALSE,1,FALSE,FALSE);
    break;
  
case C_SCALEX:
case C_SCALEY:
case C_LSCALEX:
case C_LSCALEY:
    compile_simple_numeric(0xc0,0xc0,FALSE);
    break;

case C_MARKX:
case C_MARKY:
    compile_simple_numeric(0xf0,0xc0,FALSE);
    break;

case C_LABELX:
case C_LABELY:
    compile_simple_numeric(0xfc,0xc0,FALSE);
    break;
 
case C_SIZE:
    compile_simple_numeric(0x1c0,0xc0,FALSE);
    break;

case C_ROTATE:
    compile_simple_numeric(0x180,0x80,FALSE);
    break;

case C_CIRCLE:
case C_RCIRCLE:
case C_GCIRCLE:
case C_CIRCLEB:
case C_RCIRCLEB:
case C_GCIRCLEB:
    i = pbscan((unsigned char FAR *)cB,cI,";"); /* check if circle point; point */
	if (i < 0) {
		compile_short_value(0); /* mark radius form */
    	compile_simple_numeric(0xa0,0xe0,FALSE);
    } else {
    	compile_short_value(1); /* mark rectangle form */
		if ((newcmd == C_CIRCLE) || (newcmd == C_CIRCLEB))
    		compile_points(2,2,0,TRUE,FALSE,FALSE,0,TRUE,FALSE);
    	else if ((newcmd == C_RCIRCLE) || (newcmd == C_RCIRCLEB))
    		compile_points(2,2,1,TRUE,FALSE,FALSE,0,FALSE,FALSE); 
		else /* gcircle or gcircleb */
    		compile_points(2,2,2,TRUE,FALSE,FALSE,0,FALSE,FALSE); 
    }
    break;

case C_BOX:
    if (cB[cI] == NEWLINE) /* check for blank tag form */
        break; /* done */
    compile_points(2,2,0,TRUE,FALSE,FALSE,0,TRUE,FALSE); /* process two points */
    compile_simple_numeric(0x180,0x00,FALSE); /* optional thickness */
    break;

case C_RBOX:
    compile_points(2,2,1,TRUE,FALSE,FALSE,0,FALSE,FALSE); /* process two points */
    compile_simple_numeric(0x180,0x80,FALSE); /* optional thickness */
    break;

case C_GBOX:
    if (cB[cI] == NEWLINE) /* check for blank tag form */
        break; /* done */
    compile_points(2,2,2,TRUE,FALSE,FALSE,0,FALSE,FALSE); /* process two points */
    compile_simple_numeric(0x180,0x80,FALSE); /* optional thickness */
    break;

case C_VECTOR:
    compile_points(2,2,0,TRUE,FALSE,FALSE,0,TRUE,FALSE); /* process two points */
    compile_simple_numeric(0x180,0x80,FALSE); /* optional head size */
    break;

case C_RVECTOR:
    compile_points(2,2,1,TRUE,FALSE,FALSE,0,FALSE,FALSE); /* process two points */
    compile_simple_numeric(0x180,0x80,FALSE); /* optional head size */
    break;

case C_GVECTOR:
    compile_points(2,2,2,TRUE,FALSE,FALSE,0,FALSE,FALSE); /* process two points */
    compile_simple_numeric(0x180,0x80,FALSE); /* optional head size */
    break;

case C_ERASE:
    i = pbscan((unsigned char FAR *)cB,cI,";"); /* check if erase point; point..point */
    if (i < 0) {
        compile_simple_numeric(0x1c0,0x00,FALSE);
    } else {
        if (continFlag) cmpl -= 2; /* remove previous command code */
        addcmd = C_ERASEP; /* change command code if points */
        compile_points(1,FILLPOINTS,0,FALSE,continFlag,FALSE,0,TRUE,FALSE);
    }
    break;

case C_AXES:
    compile_points(1,2,3,FALSE,FALSE,FALSE,2,FALSE,FALSE);
    break;

case C_BOUNDS:
    compile_points(1,2,3,FALSE,FALSE,FALSE,0,FALSE,FALSE);
    break;

case C_CLIP:
    compile_points(2,2,0,FALSE,FALSE,FALSE,2,TRUE,FALSE);
    break;

case C_RCLIP:
    compile_points(2,2,1,FALSE,FALSE,FALSE,2,FALSE,FALSE);
    break;

case C_GCLIP:
    compile_points(2,2,2,FALSE,FALSE,FALSE,2,FALSE,FALSE);
    break;
    
case C_VSTEP:
    compile_simple_numeric(0x80,0x00,FALSE);
    cmpbuf_word(addcmd);
    addcmd = C_VWAIT; /* add command to wait after video */
    break;
    
case C_VSHOW:
    compile_simple_numeric(0x80,0x80,FALSE);
    cmpbuf_word(addcmd);
    addcmd = C_VWAIT; /* add command to wait after video */
    break;

case C_DISK:
case C_RDISK:
case C_GDISK:
    i = pbscan((unsigned char FAR *)cB,cI,";"); /* check if circle point; point */
	if (i < 0) {
		compile_short_value(0); /* mark radius form */
    	if (newcmd == C_DISK)
    		compile_simple_numeric(0x80,0x00,FALSE);
    	else
    		compile_simple_numeric(0x80,0x80,FALSE);
    } else {
    	compile_short_value(1); /* mark rectangle form */
		if (newcmd == C_DISK)
    		compile_points(2,2,0,TRUE,FALSE,FALSE,0,TRUE,FALSE);
    	else if (newcmd == C_RDISK)
    		compile_points(2,2,1,TRUE,FALSE,FALSE,0,FALSE,FALSE); 
		else /* gdisk */
    		compile_points(2,2,2,TRUE,FALSE,FALSE,0,FALSE,FALSE); 
    }
    break;
    
case C_DELTA:
    compile_simple_numeric(0x80,0x80,FALSE);
    break;
    
case C_NEWLINE:
case C_SUPSUB:
	skip_white_cB();
	if (cB[cI] == NEWLINE) {
		break; /* nothing to do */
	} else
    	compile_float();
    break;

case C_FONT:
case C_FONTP:
case C_PATTERN:
case C_CURSOR:
    if (cB[cI] == NEWLINE) break; /* blank tag form */
    term = compile_marker(FALSE,FALSE); /* evaluate marker expr */
    if (term != ',')
        if ((newcmd == C_FONT) || (newcmd == C_FONTP))
            cerror(SPECIFICERR,"Format is  font  name, size"); 
        else cerror(SPECIFICERR,"Format is font name, character number");
    compile_simple_numeric(0x80,0x00,FALSE);
    skip_white_cB();
/*	if ((cB[cI] == NEWLINE) && (newcmd == C_FONTP))
        compile_keyword_and_args(fplist,&term); */
    break;

case C_ICONS:
case C_EXEC:
case C_SETDIR:
    compile_marker(FALSE,FALSE); 
    break;
	
case C_ADDFILE:
    unittab[compunit].hasfile = TRUE;
    compile_file(TRUE); 
    term = compile_marker(FALSE,TRUE);
    while (term != NEWLINE)
        compile_keyword_and_args(addflist,&term);
    break;

case C_SETFILE:
    unittab[compunit].hasfile = TRUE;
    term = compile_file(TRUE);
    if (term == NEWLINE) break;
    term = compile_marker(FALSE,TRUE); /* file name argument */
    if (term == NEWLINE)
        cerror(SPECIFICERR,"ro/rw argument missing.");
    compile_keyword_and_args(rwlist,&term);
    break;

case C_DELFILE:
    compile_file(TRUE);
    break;

case C_XIN:
case C_XOUT:
case C_DATAOUT:
case C_DATAIN:
    cmpbuf_word(C_MARKPT); /* add command to remember start of command */
    compile_file(FALSE); /* compile file argument */
    if ((newcmd == C_DATAOUT) || (newcmd == C_DATAIN))
        markf = TRUE;
    else markf = FALSE; /* don't allow marker expression */
    compile_buffer_len(markf); /* compile buffer and optional length */
    break;

case C_NUMOUT:
    cmpbuf_word(C_MARKPT); /* add command to remember start of command */
    compile_file(FALSE); /* compile file argument */
    compile_simple_numeric(0x80,0x80,FALSE); /* compile value argument */
    break;

case C_READLN:
    cmpbuf_word(C_MARKPT); /* add command to remember start of command */
    compile_file(FALSE); /* compile file argument */
    wkexa = defexp; 
    wkexa.rtype = TMARK; /* require marker result */
    wkexa.mfunctst = FALSE; /* marker functions not store-able */
    wkexa.reqstore = TRUE;
    compile(&wkexa); /* compile buffer expression */
    if (wkexa.lastchar != NEWLINE) { /* compile terminator */
        wkexa = defexp;
        wkexa.rtype = TMARK; /* require marker result */    
        compile(&wkexa); /* compile terminator expression */
    } /* lastchar if */
    break;

case C_EDITR:
case C_REDITR:
case C_GEDITR:
    if (!continFlag) /* should only get here if continued */
        cerror(BADCOMMAND,NEARNULL);
case C_EDIT:
case C_REDIT:
case C_GEDIT:

    /* edit  edit variable;region;marker;keyword/args;... */
    /* edit  reset,edit variable;keyword/args */
    
    coarsef = FALSE; /* r/g forms do not allow coarse */
    if (newcmd == C_EDIT) {
        coarsef = TRUE;
        argt = 0; /* absolute */
    } else if (newcmd == C_REDIT) argt = 1; /* relative */
    else if (newcmd == C_GEDIT) argt = 2; /* graphing */
		
    /* check for "edit reset," form */

    if (!continFlag) {
        keyword_counter = 0; /* count keywords over continued command */
        i = pbscan(cB,cI,","); /* position of comma */
        if ((i >= 0) && (i < pbscan(cB,cI,";"))) { /* comma before semicolon */

            /* compile "edit reset" form */

            if (newcmd == C_EDIT) addcmd = C_EDITR;
            else if (newcmd == C_REDIT) addcmd = C_REDITR;
            else if (newcmd == C_GEDIT) addcmd = C_GEDITR;
            extract_keyword_cB(ws,NAMEL,FALSE,&term); /* get name */
            if (strcmp(ws,"reset")) {
                cI = i; /* position after first argument */
                cerror(NEEDSEMI,NEARNULL);
            }
            term = compile_txtype(TXEDIT,FALSE);
            if (term == NEWLINE)
                 cerror(MISSINGARG,NEARNULL);
            compile_keyword_and_args(editlistr,&term);
            oldCmnd = oldcmd = newcmd = addcmd; /* for continuation */
            break; /* done with this command */
        } /* "edit reset" if */

        /* compile "edit   edit variable" form */

        term = compile_txtype(TXEDIT,TRUE);
        if (term != NEWLINE) {
            compile_points(2,2,argt,TRUE,FALSE,FALSE,0,coarsef,FALSE);
            unitn = extract_unit(ws,&term,TRUE);
            if (unitn == -2) {
                if (strcmp(ws,"x") == 0) {
                    if (term == '(')
						cerror(UXARG,NEARNULL);
                    unitn = UNITX;
                    compile_short_value(unitn);
                } else cerror(MISSINGUNIT,NEARNULL);
            } else if (unitn == -1) /* indirect unit reference */
                cmpbuf_word(MUNIT);
            else compile_short_value(unitn); /* normal unit reference */
            if (term == '(') {
                compile_short_value(TRUE); /* mark argument present */
                cI--; /* back up to balance parens */
                term = compile_float();
            } else {
                compile_short_value(FALSE); /* no argument */
            } /* term else */
            if (term != ';')
                cerror(NEEDSEMI,NEARNULL);
            term = compile_marker(FALSE,TRUE); /* marker expression */
            if (term == NEWLINE) break;
            if (term != ';')
                cerror(NEEDSEMI,NEARNULL);
            skip_white_cB();
            if (cB[cI] == NEWLINE)
            	break; /* ok to end with semicolon */
            compile_keyword_and_args(editlist,&term);
        } /* term if */
    } else { /* continued */
        cmpl -= 2; /* remove previous command code */
        skip_white_cB();
        term = cB[cI]; /* get next character */
        if (term != NEWLINE) {
            if ((newcmd == C_EDITR) || (newcmd == C_GEDITR) || (newcmd == C_REDITR))
                compile_keyword_and_args(editlistr,&term);
            else    
                compile_keyword_and_args(editlist,&term);
        } /* term if */
    }
    if (keyword_counter > 15)
        cerror(TOOMANY,NEARNULL); /* too many keywords */
    break;

case C_CANCEL:
    break;
    
case C_BUTTON:
case C_RBUTTON:
case C_GBUTTON:

    /* button  button variable;region,text,unit,keyword/args;... */
    
    coarsef = FALSE; /* r/g forms do not allow coarse */
    if (newcmd == C_BUTTON) {
        argt = 0; /* absolute */
        coarsef = TRUE;
    } else if (newcmd == C_RBUTTON) argt = 1; /* relative */
    else if (newcmd == C_GBUTTON) argt = 2; /* graphing */
	
    /* check for "button reset," form */

    i = pbscan(cB,cI,","); /* position of comma */
    if ((i >= 0) && (i < pbscan(cB,cI,";"))) { /* comma before semicolon */

        /* compile "button reset" form */

        if (newcmd == C_BUTTON) addcmd = C_BUTTONR;
        else if (newcmd == C_RBUTTON) addcmd = C_RBUTTONR;
        else if (newcmd == C_GBUTTON) addcmd = C_GBUTTONR;
    extract_keyword_cB(ws,NAMEL,FALSE,&term); /* get name */
    if (strcmp(ws,"reset")) {
            cI = i; /* position after first argument */
            cerror(NEEDSEMI,NEARNULL);
        }
        term = compile_txtype(TXBUTTON,FALSE);
        if (term == NEWLINE)
            cerror(MISSINGARG,NEARNULL);
        compile_keyword_and_args(buttonlistr,&term);
        break; /* done with this command */
    } /* "button reset" if */

    /* compile "button   button variable" form */

    term = compile_txtype(TXBUTTON,TRUE);
    if (term != NEWLINE) {
        compile_points(2,2,argt,TRUE,FALSE,FALSE,0,coarsef,FALSE);
        unitn = extract_unit(ws,&term,TRUE);
        if (unitn == -2) {
            if (strcmp(ws,"x") == 0) {
                if (term == '(')
		    cerror(UXARG,NEARNULL);
                unitn = UNITX;
                compile_short_value(unitn);
            } else cerror(MISSINGUNIT,NEARNULL);
        } else if (unitn == -1) /* indirect unit reference */
            cmpbuf_word(MUNIT);
        else compile_short_value(unitn); /* normal unit reference */
        if (term == '(') {
            compile_short_value(TRUE); /* mark argument present */
            cI--; /* back up to balance parens */
            term = compile_float();
        } else {
            compile_short_value(FALSE); /* no argument */
        } /* term else */
    if (term != ';')
            cerror(NEEDSEMI,NEARNULL);
        term = compile_marker(FALSE,TRUE); /* marker expression */
    if (term == NEWLINE) 
            break;
    if (term != ';')
            cerror(NEEDSEMI,NEARNULL);
        compile_keyword_and_args(buttonlist,&term);
    }
    break;

case C_SLIDER:
case C_RSLIDER:
case C_GSLIDER:

    /* slider slider variable;unit,keyword, args;... */
    
    coarsef = FALSE; /* r/g forms do not allow coarse */
    if (newcmd == C_SLIDER) {
        argt = 0; /* absolute */
        coarsef = TRUE;
    } else if (newcmd == C_RSLIDER) argt = 1; /* relative */
    else if (newcmd == C_GSLIDER) argt = 2; /* graphing */
		
    /* check for "slider reset," form */

    i = pbscan(cB,cI,","); /* position of comma */
    if ((i >= 0) && (i < pbscan(cB,cI,";"))) { /* comma before semicolon */

        /* compile "slider reset" form */

        if (newcmd == C_SLIDER) addcmd = C_SLIDERR;
        else if (newcmd == C_RSLIDER) addcmd = C_RSLIDERR;
        else if (newcmd == C_GSLIDER) addcmd = C_GSLIDERR;
    	extract_keyword_cB(ws,NAMEL,FALSE,&term); /* get name */
    	if (strcmp(ws,"reset")) {
            cI = i; /* position after first argument */
            cerror(NEEDSEMI,NEARNULL);
        }
        term = compile_txtype(TXSLIDER,FALSE);
        if (term == NEWLINE)
            cerror(MISSINGARG,NEARNULL);
        compile_keyword_and_args(sliderlistr,&term);
        break; /* done with this command */
    } /* "slider reset" if */

    /* compile "slider   slider variable" form */
    
    cmpbuf_word(C_OBJW); /* possible interrupt before destroy slider */
    term = compile_txtype(TXSLIDER,TRUE);
    if (term == NEWLINE)
        break;
    compile_points(2,2,argt,TRUE,FALSE,FALSE,0,coarsef,FALSE);
    unitn = extract_unit(ws,&term,TRUE);
    if (unitn == -2) {
        if (strcmp(ws,"x") == 0) {
            if (term == '(')
		cerror(UXARG,NEARNULL);
            unitn = UNITX;
            compile_short_value(unitn);
        } else cerror(MISSINGUNIT,NEARNULL);
    } else if (unitn == -1) /* indirect unit reference */
        cmpbuf_word(MUNIT);
    else compile_short_value(unitn); /* normal unit reference */
    if (term == '(') {
        compile_short_value(TRUE); /* mark argument present */
        cI--; /* back up to balance parens */
        term = compile_float();
    } else {
        compile_short_value(FALSE); /* no argument */
    } /* term else */
    if (term == NEWLINE) break;
    if (term != ';')
        cerror(NEEDSEMI,NEARNULL);
    compile_keyword_and_args(sliderlist,&term);
    break;

case C_TOUCH:
case C_RTOUCH:
case C_GTOUCH:
 	compile_touch_cmd(newcmd,continFlag);
 	break;
 	
case C_RESET:
    compile_file(FALSE);
    compile_single_keyword(resetfilelist,&term);
    break;

default:
    compile2(); /* the rest of the commands */

} /* end of switch(newcmd) */

    if (chkeol && (!refillBuff) &&
       (cB[cI] != NEWLINE) && (!cI || cB[cI-1] != NEWLINE)) {
        cerror(TOOMANY,NEARNULL);
    }

} /* end of compile1() */

/* ******************************************************************* */
    
int compile_case_table(casep) /* add -case- table to binary */
/* returns TRUE if table built, FALSE if not */
struct caseopt *casep; /* pointer to -case- table entry */

{   long min,max; /* range of -case- values */
    struct caseoptv FAR *vp; /* pointer in value/address table */
    long value; /* value being added to table */
    int ii; /* index in value/address table */

    if (casep->nitems < 2) return(FALSE); /* exit if no need for table */

    /* determine if sufficient population density */

    sort_case_table(casep); /* sort by value */
    max = casep->cv[casep->nitems-1].value;
    min = casep->cv[0].value;
    if ((max-min) > (2*casep->nitems)) 
        return(FALSE); /* table must be at least 50% populated */
    if ((min < -32767) || (max > 32767))
        return(FALSE);

    /* build table in pcodes */

    cmpbuf_word(CASETAB); 
    cmpbuf_word((int)min); /* add minimum and maximum */
    cmpbuf_word((int)max);
    ii = 0; /* index in table */
    for(value=min; value<=max; value++) {
        if (ii && (value < casep->cv[ii].value)) {
            cmpbuf_word(0); /* no address */
        } else {
            /* add to reloc atable */
            add_xref(R_CLAUSEB,casep->cv[ii].label,cmpl,casep->cv[ii].address);
            cmpbuf_word(casep->cv[ii++].address); /* add destination */
        } /* else */
    } /* for */
    return(TRUE);

} /* compile_case_table */

/* ******************************************************************* */

sort_case_table(casep) /* bubble sort -case- optimization table */
struct caseopt *casep; /* pointer to -case- table entry */

{   int ii; /* index in value/address table */
    int lth; /* number items to sort */
    struct caseoptv swap;
    int sortf; /* continue sort flag */
    struct caseoptv FAR *vp; /* pointer in value/address table */

    lth = casep->nitems; /* length of value/address lists */
    do {
        sortf = FALSE; /* pre-set to terminate bubble sort */
        for(ii=1; ii<lth; ii++) {
            vp = &casep->cv[ii];
            if ((vp-1)->value > vp->value) {
                swap = *(vp-1);
                *(vp-1) = *vp;
                *vp = swap;
                sortf = TRUE; /* continue sort */
            } /* values if */
        } /* for */
    } while (sortf);

} /* sort_case_tables */

/* ******************************************************************* */

compile_touch_cmd(cmdCode,contF) /* touch, rtouch, gtouch compilation */
int cmdCode; /* touch, rtouch, gtouch command code */
int contF; /* TRUE if continued command */

{	int coarsef; /* TRUE if coarse-grid form allowed */
	int argt; /* 0 = touch, 1 = rtouch, 2 = gtouch */
	int term; /* current expression terminator */
	int unitn; /* unit number */
	int opts; /* current touch option bits */
	int startcI; /* character index at start of expression */
	char ws[NAMEL+1]; /* keyword string */
	
	opts = 0; /* no touch options yet */
	
    /* command type */
    
    coarsef = FALSE; /* r/g forms do not allow coarse */
    if (newcmd == C_TOUCH) {
        argt = 0; /* absolute */
        coarsef = TRUE; 
    } else if (newcmd == C_RTOUCH) 
        argt = 1; /* relative */
    else if (newcmd == C_GTOUCH) 
        argt = 2; /* graphing */

	if (contF) { /* continued command */
	    cmpl -= 2; /* remove previous command code */
	} else {
	
		/* compile touch variable */
		
	    term = compile_txtype(TXTOUCH,TRUE);
    	if (term == NEWLINE)
        	return(0);
        	
    	/* compile region */
    	
    	compile_points(2,2,argt,TRUE,FALSE,FALSE,FALSE,coarsef,FALSE);
    	keyword_counter = 0; /* initialize - extends over continued commands */
    }
 	
 	/* check if at end of command */
 	
	skip_white_cB();
    term = cB[cI]; /* get next character */
    if (term == NEWLINE) 
    	return(0);
           
 	/* process options */
 	
 	do {

 		/* extract and recognize next keyword */

		startcI = cI; /* index at start of keyword */
    	extract_keyword_cB(ws,20,FALSE,&term);
    	keyword_counter++;
    	if ((strcmp(ws,"upmove") == 0) || ((term == ':') && ((strcmp(ws,"left") == 0) || (strcmp(ws,"right") == 0)))) {
    	    cI = startcI; /* process left, right or upmove again */
        	opts |= extract_touch_keywords(&term,';',FALSE);
        	
        	/* look ahead for another left/right */
        	
        	startcI = cI; /* index at start of keyword */
        	extract_keyword_cB(ws,20,FALSE,&term);
        	cI = startcI; /* process this tag again */
        	if ((term == ':') && 
    	        ((strcmp(ws,"left") == 0) || (strcmp(ws,"right") == 0))) {
        	   ; /* do nothing - back to top of loop */
        	} else {
        	
        		/* add accumulated touch options */
        		
        		compile_short_value(KW_TOUCH);
        		compile_short_value(opts);
        		opts = 0; /* reset touch options */
        	
        		/* process unit + argument */
        	
        		compile_short_value(KW_TUNIT);
        		unitn = extract_unit(ws,&term,TRUE);
    			if (unitn == -2) {
        			if (strcmp(ws,"x") == 0) {
            			if (term == '(')
					cerror(UXARG,NEARNULL);
            			unitn = UNITX;
            			compile_short_value(unitn);
        			} else cerror(MISSINGUNIT,NEARNULL);
    			} else if (unitn == -1) /* indirect unit reference */
        			cmpbuf_word(MUNIT);
    			else compile_short_value(unitn); /* normal unit reference */
    			if (term == '(') {
        			compile_short_value(TRUE); /* mark argument present */
        			cI--; /* back up to balance parens */
        			term = compile_float();
    			} else {
        			compile_short_value(FALSE); /* no argument */
    			} /* term else */  
        	} /* look-ahead term else */
    	} else if (strcmp(ws,"priority") == 0) {
    		compile_short_value(KW_TPRIORITY);
    		term = compile_simple_numeric(0x80,0x00,TRUE); /* priority expression */
    	} else if ((strcmp(ws,"left") == 0) || (strcmp(ws,"right") == 0)) {
    		cerror(SPECIFICERR,"Use : after left or right.");
    	} else {
    		cerror(BADTAG,NEARNULL);
    	}
    	
    	if (keyword_counter > 15)
        	cerror(TOOMANY,NEARNULL); /* too many keywords */
    	if (term != NEWLINE) {
    		skip_white_cB(); /* skip over any white space */
    		if (cB[cI] == NEWLINE)
    			term = NEWLINE; /* have reached end */
    	} /* term if */
	} while (term != NEWLINE);

    return(0);
    
} /* compile_touch_cmd */
    
/* ******************************************************************* */

  
