
/* QuickTime For Windows support */

#include <windows.h>

#include <TextUtils.h>
#include <movies.h>
#include <qtml.h>

#define Ptr_Def 1

#include "execdefs.h"
#include "eglobals.h"
#include "tglobals.h"
#include "tfiledef.h"
#include "exprdefs.h"
#include "kglobals.h"
#include "video.h"

extern int qtLoad(void);
extern long qtProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam);
extern int qtMovieOpen(char *moviePath);
extern int qtMovieClose(int type);
extern int qtMovieSound(double value);
extern int qtMovieInfo(int *width,int *height,double *length,int *isplay); 
extern int qtMovieRectangle(int modeF,int x1,int y1,int x2,int y2,int cx1,int cy1,int cx2,int cy2,int cVis);
extern int qtMovieLoop(int doLoop);
extern int qtMoviePaletteUse(int useIt);
extern int qtMovieHalt(void);
extern int qtMovieShow(double showTime);
extern int qtMoviePlay(double fromTime,double toTime);
extern int qtMovieStep(long nSteps);
extern double qtMovieGetTime(void);

extern int TUTORset_dir(FileRef FAR *path);
extern int  TUTORcvt_path(char *ssx,struct _fref FAR *fRef,struct _fref FAR *baseRef,int isFile);
extern int TUTORlog(char *msg);
extern int RealizeCTPalette(Memh newH,int allNew);
extern long TUTORinq_msec_clock(void);
extern unsigned int TUTORhandle(char  *name,long  size,int  purgewmrm);
extern int ReleasePtr(unsigned int  mm);
extern char FAR *GetPtr(unsigned int  mm);
extern int TUTORfree_handle(Memh mm);
extern int TUTORzero(char FAR *ptr,long lth);
extern char FAR *strcpyf(char FAR *s1,char FAR *s2);
extern int  marker_file_name(struct  markvar FAR *mx,struct  _fref FAR *fullRef,int  symbolic);
extern int  ReleasePtr(unsigned int  mm);
extern char  FAR *GetPtr(unsigned int  mm);
extern int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
extern int  TUTORfile_exists(struct  _fref FAR *fRef);
extern char *CtoPstr(char *ss);
extern char *PtoCstr(char *ss);
extern int TUTORclose(int findx);
extern int  lclocy(long  q);
extern int  lclocx(long  q);
extern Memh TUTORnew_controller(TRect *tR,double start,double end,
            int (*playProc)(Memh cH),int (*stopProc)(Memh cH),
	    int (*fwdProc)(Memh cH),int (*backProc)(Memh cH),
	    int (*thumbP)(Memh cH));
extern int TUTORupdate_controller(Memh ctrlH,double curPos,int isPlaying);
extern HPALETTE cvtLogPal(Memh paletteH);
extern int qtMovieRectangle(int modeF,int x1,int y1,int x2,int y2,
		int cx1,int cy1,int cx2,int cy2,int cVis);

/* ******************************************************************* */

extern HDC CurrentDC; /* current window's device context */
extern HWND FirstWinH; /* handle on first window created */
extern HANDLE hcTInst; /* current instance of cT */
extern Memh thePaletteH; /* logical palette */
extern LPLOGPALETTE thePaletteP; /* pointer to logical palette */
extern int movieCtrlH;
extern int MillionsColor;
extern int wColorSet;
extern double movieSoundV; /* current volume setting (also for VfW) */
extern int fMovieOpen; /* 1 = movie open, 2 = sound open */

/* ******************************************************************* */

int qtInit = 0; /* 1 = QuickTime initialized */
                /* 2 = EnterMovies called */
int qtMovieOpenF = FALSE; /* TRUE if QuickTime movie open */
int qtMovieControllerF = FALSE; /* TRUE if have movie controller */
int qtMoviePaletteUseF; /* TRUE if should use palette from movie */
int qtControllerHasPalette = 0;
int qtSuppressPaint = 0;

static int qtMovieLoopF; /* TRUE if movie looping */
static short movieRef = 0; /* Mac style file reference */
static HWND movieHWND = 0; /* Windows handle for movie window */
static Rect rcMovie;
static Movie mMovie;
static MovieController mcController;
static Rect movieNativeRect;
static TimeScale movieTimeScale; /* movie's time scale (units/second) */
static double movieDuration; /* duration of movie (seconds) */
static double movieFromTime;
static double movieToTime;
static double lastTime;

/* ******************************************************************* */

extern int DoQuickTime(void);

int cmd_dma()

{
	exS.zreturn = DoQuickTime();
    return(0);

} /* cmd_dma */

/* ------------------------------------------------------------------- */

extern int MovieClose(int type);

static int DoQuickTime() 

{   FSSpec fileSpec; /* Mac style file spec */
	Rect movieRect; /* Mac style movie rectangle */
	char moviePath[CTPATHLEN]; /* movie file name */

	MovieClose(1);

    /* initialize QuickTime */

    if (qtInit < 2) {
		if (qtInit == 0) {
			if (!qtLoad()) {
				return(FILENOTSUP);
			}
		}
		if (EnterMovies() != noErr) {
			TerminateQTML();
			return(FILEMEM);
		}
		movieHWND = (HWND)windowsP[ExecWn].wp;
		CreatePortAssociation(movieHWND,NULL,0L);
		SetGWorld((CGrafPtr)GetNativeWindowPort((void *)movieHWND), nil);
		qtInit = 2;
    }

    /* instantiate the movie */

	strcpy(moviePath,"c:\\windows\\sample.mov");
	c2pstr(moviePath); /* convert to pascal string */
	FSMakeFSSpec(0,0L,moviePath,&fileSpec); /* build Mac style spec */
	p2cstr(moviePath);
    if (OpenMovieFile(&fileSpec, &movieRef, OF_READ) != noErr) {
		return(FILEMISSING);
    }
    NewMovieFromFile(&mMovie, movieRef, NULL, NULL, 0, NULL);
    CloseMovieFile(movieRef);

	/* attach movie controller */

	GetMovieBox(mMovie,&movieRect);
	movieNativeRect.left = movieRect.left;
	movieNativeRect.top = movieRect.top;
	movieNativeRect.right = movieRect.right;
	movieNativeRect.bottom = movieRect.bottom;
	MacOffsetRect(&movieRect,(short)(-movieRect.left),(short)(-movieRect.top));
	mcController = NewMovieController(mMovie,&movieRect,mcTopLeftMovie);
	lastTime = 0;
    movieCtrlH = 25; /* height for QT controller */

    /* position movie and (as yet) invisible controller */

    rcMovie.left = 16;
    rcMovie.top = 16;
    rcMovie.right = 128;
    rcMovie.bottom = 128+movieCtrlH;
    MCPositionController(mcController,&rcMovie,NULL,
	    (long)mcTopLeftMovie);

	SetMovieActive(mMovie,TRUE); /* activate controller */

	qtSuppressPaint = 1; /* ValidateRect() doesn't work here */
	qtMovieOpenF = qtMovieControllerF = TRUE;
	fMovieOpen = 1;
	return(-1);

} /* DoQuickTime */

/* ******************************************************************* */

int qtLoad() /* load QuickTime */

{
	if (qtInit == 0) {
		if (InitializeQTML(0) == noErr) {
			qtInit = 1;
			return(TRUE); /* TRUE = QuickTime loaded */
		}
	}
	return(TRUE);

} /* qtLoad */

/* ------------------------------------------------------------------- */

long qtProc(hWnd,msg,wParam,lParam)
HWND hWnd;
UINT msg;
WPARAM wParam;
LPARAM lParam;

{	MSG winMsg; /* Windows style event */
	EventRecord macEvent; /* Mac style event */
	long pxy; /* x,y associated with event */

    if (!qtMovieControllerF)
		return(FALSE);

	/* build Mac style event from Windows info */

	if (GetNativeWindowPort(hWnd)) {
		winMsg.hwnd = hWnd;
		winMsg.message = msg;
		winMsg.wParam = wParam;
		winMsg.lParam = lParam;
		winMsg.time = GetMessageTime();
		pxy = GetMessagePos();
		winMsg.pt.x = LOWORD(pxy);
		winMsg.pt.y = HIWORD(pxy);
		WinEventToMacEvent(&winMsg,&macEvent);

		/* pass event to controller */

		if (MCIsPlayerEvent(mcController,&macEvent))
			return(TRUE);
	} /* GetNativeWindowPort */
    return(FALSE);

} /* qtProc */

/* ------------------------------------------------------------------- */

qtMovieOpen(moviePath)
char *moviePath; /* some combination of path + file (altered) */

{   FSSpec fileSpec; /* Mac style file spec */
	long tmpl;
	Rect movieRect; /* Mac style movie rectangle */
	RECT wRect; /* Windows style movie rectangle */
	int ret;
	FileRef fullRef; /* cT file reference */
	int haveSaveDir; /* TRUE if have saved directory */
	FileRef saveRef; /* saved directory */
	char *cp;
	MSG pMsg;
	int peekF1,peekF2;

    qtMovieClose(1); /* close any current movie */

	peekF1 = PeekMessage(&pMsg,(HWND)NULL,WM_PAINT,WM_PAINT,PM_REMOVE);

    /* initialize QuickTime */

    if (qtInit < 2) {
		if (qtInit == 0) {
			if (!qtLoad()) {
				return(FILENOTSUP);
			}
		}
		qtInit = 1;
		if (EnterMovies() != noErr) {
			TerminateQTML();
			return(FILEMEM);
		}
		movieHWND = (HWND)windowsP[ExecWn].wp;
		CreatePortAssociation(movieHWND,NULL,0L);
		SetGWorld((CGrafPtr)GetNativeWindowPort((void *)movieHWND), nil);
		qtInit = 2;
    }
    lastTime = 0;
    movieCtrlH = 25; /* height for QT controller */

	/* build full cT file reference, set working directory */
	
	haveSaveDir = FALSE; /* don't have saved directory yet */
	if (currentDirP) {
		haveSaveDir = TRUE;
		saveRef = *currentDirP; /* save directory */
	}
	TUTORcvt_path(moviePath,&fullRef,currentDirP,TRUE);
	moviePath[0] = 0; /* recycle path */
	if (fullRef.path[1] == ':') { /* full path */
		strcpy(moviePath,fullRef.path);
	} else if ((fullRef.path[0] == '\\') || (fullRef.path[0] == '/')) { 
		/* full path without drive (normal case) */
		if (fullRef.drive > 0) {
			moviePath[0] = fullRef.drive+'a'-1;
			moviePath[1] = ':';
			moviePath[2] = 0;
		}
		strcat(moviePath,fullRef.path);
		cp = moviePath;
		while (*cp) {
			if (*cp == '/')
				*cp = '\\'; /* convert slash to backslash */
			cp++;
		} /* while */
	} else (strcpy(moviePath,fullRef.path)); /* simply pray */

    /* instantiate the movie */

	c2pstr(moviePath); /* convert to pascal string */
	FSMakeFSSpec(0,0L,moviePath,&fileSpec); /* build Mac style spec */
	p2cstr(moviePath);
	ret = OpenMovieFile(&fileSpec, &movieRef, OF_READ);
	if (haveSaveDir)
		TUTORset_dir(&saveRef); /* restore working directory */
    if (ret != noErr) {
		return(FILEMISSING);
    }

    NewMovieFromFile(&mMovie, movieRef, NULL, NULL, 0, NULL);
    CloseMovieFile(movieRef);

    movieTimeScale = GetMovieTimeScale(mMovie);
    tmpl = GetMovieDuration(mMovie);
    movieDuration = (double)(tmpl)/movieTimeScale;

	SetGWorld((CGrafPtr)GetNativeWindowPort(movieHWND),nil);

    qtMovieSound(movieSoundV); /* apply current volume */

    GetMovieBox (mMovie,&movieRect);
	movieNativeRect.left = movieRect.left; /* convert to Windows rectangle */
	movieNativeRect.top = movieRect.top;
	movieNativeRect.right = movieRect.right;
	movieNativeRect.bottom = movieRect.bottom;

	wRect.left = wRect.top = 0; /* kludge - validate everything */
	wRect.right = windowsP[ExecWn].wxsize;
	wRect.bottom = windowsP[ExecWn].wysize;
    ValidateRect(movieHWND,(RECT FAR *)&wRect); 
	
	peekF2 = PeekMessage(&pMsg,(HWND)NULL,WM_PAINT,WM_PAINT,PM_NOREMOVE);
	if (!peekF1 && peekF2) /* check for redraw */
		qtSuppressPaint++; /* ignore the next PAINT signal */

    qtMovieOpenF = TRUE;
	fMovieOpen = 1;
    return(-1);

} /* qtMovieOpen */

/* ------------------------------------------------------------------- */

int qtMovieClose(type)
int type; /* 0 = close movie */
          /* 1 = close movie */
          /* 2 = close QuickTime */

{	int peekF1,peekF2;
	MSG pMsg;

	peekF1 = PeekMessage(&pMsg,(HWND)NULL,WM_PAINT,WM_PAINT,PM_NOREMOVE);

    if (qtMovieOpenF) {
		SetTimer(FirstWinH,1,55,(TIMERPROC)FARNULL); /* restore timer */
		if (qtMovieControllerF) {
			DisposeMovieController(mcController);
			qtMovieControllerF = FALSE;
			if (qtControllerHasPalette)
				RealizeCTPalette((Memh)windowsP[ExecWn].paletteH,TRUE);
			qtControllerHasPalette = 0;
		} /* qtMovieControllerF */
		DisposeMovie(mMovie);
		if (movieHWND)
			DestroyPortAssociation((CGrafPtr)GetNativeWindowPort(movieHWND));
		ExitMovies();
		qtInit = 1; /* QuickTime still open */
		movieHWND = 0;
		fMovieOpen = 0;
		qtMovieOpenF = FALSE;
    }
    if (qtInit && (type == 2)) {
		TerminateQTML();
		qtInit = 0;
    }

	peekF2 = PeekMessage(&pMsg,(HWND)NULL,WM_PAINT,WM_PAINT,PM_NOREMOVE);
	if (!peekF1 && peekF2) /* check for redraw */
		qtSuppressPaint++; /* ignore the next PAINT signal */

    return(0);

} /* qtMovieClose */

/* ------------------------------------------------------------------- */

int qtMovieInfo(width,height,length,isplay) /* return info on current movie */
int *width; /* width (pixels) of movie */
int *height; /* height (pixels) of movie */
double *length; /* length (seconds) of movie */
int *isplay; /* TRUE if movie playing */

{   long cFlags;

    if (length)
	*length = movieDuration;
    if (width)
	*width = movieNativeRect.right-movieNativeRect.left;
    if (height)
	*height = movieNativeRect.bottom-movieNativeRect.top;
    if (isplay) {
	*isplay = 0;
	if (qtMovieOpenF) {
	    MCGetControllerInfo(mcController,&cFlags);
	    if (cFlags & mcInfoIsPlaying)
		*isplay = TRUE;
	}
    }
    return(0);
	
} /* qtMovieInfo */

/* ------------------------------------------------------------------- */

int qtMovieRectangle(modeF,x1,y1,x2,y2,cx1,cy1,cx2,cy2,cVis) /* set up rectangle(s) for movie play */
int modeF; /* 0 = no scale (clip), 1 = scale, 2 = center */
int x1; /* movie upper left */
int y1;
int x2; /* movie lower right */
int y2;
int cx1; /* controller upper left */
int cy1;
int cx2; /* controller lower right */
int cy2;
int cVis; /* controller visible flag */

{   HWND hWnd; /* executor window */
    long cFlags; /* controller flags */
    TimeRecord timRec;
    ComponentResult mRet;
    int cDetached; /* TRUE if controller detached from movie */
	RECT rcKludge;
	MSG pMsg;
	int peekF1,peekF2;

    if (!qtMovieOpenF)
		return(FILENOTOPEN);

	peekF1 = PeekMessage(&pMsg,(HWND)NULL,WM_PAINT,WM_PAINT,PM_NOREMOVE);

    cDetached = FALSE;
    if ((cx1 != x1) || (cx2 != x2) || (cy1 != (y2+1)))
		cDetached = TRUE;
    hWnd = (HWND)windowsP[ExecWn].wp;
    rcMovie = movieNativeRect;
    MacOffsetRect(&rcMovie,(short)(-rcMovie.left),(short)(-rcMovie.top));
    cFlags = mcTopLeftMovie;
    if (!cVis)
		cFlags |= mcNotVisible;
    mcController = NewMovieController(mMovie,&rcMovie,cFlags);

    /* eliminate grow box */

	rcMovie.top = rcMovie.left = rcMovie.bottom = rcMovie.right = 0;
    MCDoAction(mcController, mcActionSetGrowBoxBounds,(LPVOID) &rcMovie);

    /* eliminate speaker button */

    MCDoAction(mcController,mcActionGetFlags,(LPVOID)&cFlags);
    cFlags |= mcFlagSuppressSpeakerButton;
    if (qtMoviePaletteUseF) {
		cFlags |= mcFlagsUseWindowPalette;
		qtControllerHasPalette = TRUE;
    } else qtControllerHasPalette = 0;
    MCDoAction(mcController,mcActionSetFlags,(LPVOID)cFlags);

    if (!cVis) {
		MCSetVisible(mcController,FALSE);
    }

    /* position movie and (as yet) invisible controller */

    rcMovie.left = x1;
    rcMovie.top = y1;
    rcMovie.right = x2;
    rcMovie.bottom = y2+movieCtrlH;
    MCPositionController(mcController,&rcMovie,NULL,
	    (long)mcTopLeftMovie);

    /* move controller if neccessary */

    if (cDetached) {
		rcMovie.left = cx1;
		rcMovie.right = cx2;
		rcMovie.top = cy1;
		rcMovie.bottom = cy1+movieCtrlH;
		mRet = MCSetControllerAttached(mcController,FALSE);
		mRet = MCSetControllerBoundsRect(mcController,&rcMovie);
    }

    /* initialize movie to stopped */

    MCDoAction(mcController, mcActionPlay,(LPVOID) 0L);

    /* start at begin of movie */

    TUTORzero((char FAR *)&timRec,(long)sizeof(TimeRecord));
	timRec.scale = GetMovieTimeScale(mMovie);
    mRet = MCDoAction(mcController,mcActionGoToTime,(LPVOID)&timRec);

    /* activate the movie */

    SetMovieActive (mMovie, TRUE);
    qtMovieControllerF = TRUE;

 /*   rcMovie.left = 0;
    rcMovie.top = 0;
    rcMovie.right = windowsP[ExecWn].wxsize;
    rcMovie.bottom = windowsP[ExecWn].wysize;
    ValidateRect(hWnd,(RECT FAR *)&rcMovie); */

    /* handle loop */

    if (qtMovieLoopF)
		MCDoAction(mcController,mcActionSetLooping,(LPVOID)((long)TRUE));

	/* horrible kludge - validate everything */
	rcKludge.right = rcKludge.left = 0;
	rcKludge.right = windowsP[ExecWn].wxsize-1;
	rcKludge.bottom = windowsP[ExecWn].wysize-1;
	ValidateRect(hWnd,(RECT FAR *)&rcKludge); 

    SetTimer(FirstWinH,1,750,(TIMERPROC)FARNULL); /* slow down timer */

	peekF2 = PeekMessage(&pMsg,(HWND)NULL,WM_PAINT,WM_PAINT,PM_NOREMOVE);
	if (!peekF1 && peekF2) /* check for redraw */
		qtSuppressPaint++; /* ignore the next PAINT signal */
    return(-1);

} /* qtMovieRectangle */

/* ------------------------------------------------------------------- */

int qtMovieLoop(doLoop)
int doLoop;

{   
    qtMovieLoopF = doLoop;

    if (qtMovieControllerF)
		MCDoAction(mcController,mcActionSetLooping,(LPVOID)((long)doLoop));

    return(-1);

} /* qtMovieLoop */

/* ------------------------------------------------------------------- */

int qtMovieSound(volume)
double volume; /* -1 = default, 0 = off, 100 = max */

{   
    movieSoundV = volume; /* set volume (movie might not be open) */
    if (!qtMovieOpenF)
		return(FILENOTOPEN);

    return(-1);

} /* qtMovieSound */

/* ------------------------------------------------------------------- */

int qtMoviePaletteUse(useIt) /* set to use / not use movie palette */
int useIt;

{
	if (MillionsColor)
	    useIt = FALSE; /* no palette if true color */
	qtMoviePaletteUseF = useIt;
	return(-1);
	
} /* qtMoviePaletteUse */

/* ------------------------------------------------------------------- */

int qtMovieHalt()

{
    if (qtMovieOpenF && qtMovieControllerF)
		MCDoAction(mcController, mcActionPlay,(LPVOID) 0L);
    return(-1);

} /* qtMovieHalt */

/* ------------------------------------------------------------------- */

int qtMovieShow(showTime)
double showTime;

{	TimeRecord timRec;

    if ((!qtMovieOpenF) || (!qtMovieControllerF))
		return(FILENOTOPEN);

    qtMovieHalt();

    movieFromTime = movieToTime = showTime;

	TUTORzero((char FAR *)&timRec,(long)sizeof(TimeRecord));
    timRec.scale = GetMovieTimeScale(mMovie);
    timRec.base = 0;
    timRec.value.lo = (unsigned long)(showTime*timRec.scale);
    timRec.value.hi = (unsigned long)((showTime*timRec.scale)/65536.0);
    MCDoAction(mcController,mcActionGoToTime,(LPVOID)&timRec);

    return(-1);

} /* qtMovieShow */

/* ------------------------------------------------------------------- */

int qtMoviePlay(fromTime,toTime)
double fromTime;
double toTime;

{   TimeRecord timRec;
    ComponentResult mRet;
    Fixed sVolume;
    long lVolume;

    if ((!qtMovieOpenF) || (!qtMovieControllerF))
		return(FILENOTOPEN);

    qtMovieHalt();

    if (movieSoundV < 0) {
		sVolume = GetMoviePreferredVolume(mMovie);
    } else {
		sVolume = (long)(255.0*(movieSoundV/100.0));
    }
    lVolume = sVolume & 0xffL;
    mRet = MCDoAction(mcController,mcActionSetVolume,(LPVOID)lVolume);

    if (fromTime < 0.0)
	fromTime = 0.0;
    if (toTime < 0.0)
	toTime = movieDuration;

    movieFromTime = fromTime;
    movieToTime = toTime;

    timRec.scale = GetMovieTimeScale(mMovie);
    timRec.base = 0;
    timRec.value.lo = (unsigned long)(fromTime*timRec.scale);
    timRec.value.hi = (unsigned long)((fromTime*timRec.scale)/65536.0);
    mRet = MCDoAction(mcController,mcActionGoToTime,(LPVOID)&timRec);

    qtMovieSound(movieSoundV); /* restore sound setting */

    MCDoAction(mcController, mcActionPlay,(LPVOID)0x10000L);

    return(-1);

} /* qtMoviePlay */

/* ------------------------------------------------------------------- */

int qtMovieStep(nSteps) /* step forwards or backwards n frames */
long nSteps;

{   short ssStep;
    ComponentResult mRet;

    if ((!qtMovieOpenF) || (!qtMovieControllerF))
	return(FILENOTOPEN);

    if (nSteps == 0) {
	qtMovieHalt();
	return(-1);
    }

    ssStep = (short)nSteps;
    mRet = MCDoAction(mcController, mcActionStep,(LPVOID)ssStep);

    if (mRet != noErr)
		return(FILEPARAMETER);

    return(-1);

} /* qtMovieStep */

/* ------------------------------------------------------------------- */

double qtMovieGetTime()

{   TimeValue curTime;

    if (qtMovieOpenF) {
		curTime = MCGetCurrentTime(mcController,NULL);
		lastTime = (double)curTime/(double)movieTimeScale;
    }
    return(lastTime);

} /* qtMovieGetTime */

/* ******************************************************************* */
