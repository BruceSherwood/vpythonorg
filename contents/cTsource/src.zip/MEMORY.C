
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>
#include <signal.h>
#include "baseenv.h"
#include "compute.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "memory.h"
#include "kglobals.h"
#include "tfiledef.h"

#ifdef ctproto
extern int TUTORlog(char *str);
int  TUTORcopy_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  TUTORcopy_fileref_dir(struct  _fref FAR *dirname,struct  _fref FAR *fullname);
int  TUTORstat(struct  _fref FAR *fRef,struct  stat *buff);
extern int TUTORfiles_init(void);
int  TUTORinq_file_info(struct	_fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
int  StopProgram(char  *s);
extern int MacSysFolder(FileRef *fR,int type);
extern char *TUTORgetenv(char *str);
extern int DefDel(void);
extern int TUTORdeferred_dealloc(char FAR *ptr);
extern int TUTORdeferred_free(Memh hh);
extern int add_deferred(int type,Memh handle,char FAR *ptr);
extern int TUTORget_lockcount(Memh hh);
extern int TUTORinq_fast_swap(void);
extern int TUTORzero(char SHUGE *ptr,long len);
extern int TUTORdealloc(char FAR *ptr);
extern int TUTORcompare(char FAR *pa,char FAR *pb,long len);
int LockMemoryTable(void);
int UnlockMemoryTable(void);
int  killptr(char  FAR * FAR *ptr);
char  FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
int TUTORchecksum(char FAR *addr,long length);
extern char FAR *GetHandleAddress(struct htab FAR *hp);
unsigned char  FAR *TUTORscan_bytes(unsigned char  FAR *bp,unsigned char  FAR *be,unsigned char  *tp,int  nTab);
int  TUTORcount_bytes(unsigned char  FAR *tp,unsigned char  FAR *te,int  cc);
unsigned int  TUTORcopy_handle(unsigned int  mm);
long  TUTORget_hsize(unsigned int  mm);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
int  AllowHandlePurge(unsigned int  mm);
int  ChangedHandle(unsigned int  mm,int  stillPurge);
int  TUTORhandle_ispurged(unsigned int  mm);
int  TUTORrecover_handle(struct  htab FAR *hp,char  FAR *areap,int  handle);
void  TUTORinit_swap(void);
void  TUTORclose_swap(void);
int  TUTORinq_swap(void);
int  TUTORexpand_swap(void);
void  TUTORread_swap(long  pos,long  length,char  FAR *memp);
void  TUTORscan_swap(long  pos,long  length,char  FAR *memp);
void  TUTORdelete_swap(long  pos);
long  TUTORwrite_swap(char  FAR *memp,long  size);
int  assoc_name(struct  _fref FAR *fn,struct  _fref FAR *bfilen,char  *extnNew);
char  *machinename(void);
int  TUTORinsert_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nIns);
int  TUTORdelete_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nDel);
int  TUTORreplace_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  replaceN,int  newN,char  FAR *datP);
int  TUTORcompress_darray(unsigned int  da,int  offset);
int  TUTORdump(char  *s);
struct  htab FAR *TUTORget_entry_mem(int  handle);
int  ReleasePtr(unsigned int  mm);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
char  FAR *GetPtr(unsigned int  mm);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORdelete_file(struct  _fref FAR *fRef);
int  TUTORclose(int  findx);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  TUTORtemp_file_name(struct  _fref FAR *baseN,struct  _fref FAR *tempN);
int  TUTORcvt_path(char  *ssx,struct  _fref FAR *fRef,struct  _fref FAR *baseRef,int isFile);
extern char *getenv(char *varname);
int  TUTORopen_xms(long  FAR *size);
int  TUTORopen_ems(long  FAR *size);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
int  TUTORseek(int  findx,long  pos);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
char  FAR *strcatf(char  FAR *aa,char  FAR *bb);
int  strlenf(char  FAR *aa);
int  strncmpf(char  FAR *aa,char  FAR *bb,int  nn);
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
long  TUTORwrite(char  FAR *ptr,int  pSize,long  count,int  findx);
#endif /* ctproto */

#ifdef macproto
#ifdef THINKC5
typedef int (*PFI)(...);
#else
typedef int (*PFI)();
#endif
#endif

#ifndef MAC
typedef int (*PFI)();
#endif

extern char FAR *GetPtr();
extern int      ReleasePtr();
extern unsigned int TUTORhandle();
extern Memh TUTORcopy_handle();
extern int      TUTORfree_handle();
extern int      TUTORpurge_info();
extern int      AllowHandlePurge();
extern int      ChangedHandle();
extern struct htab FAR *TUTORget_entry_mem();
extern char *machinename();

void TUTORinit_swap();
void TUTORclose_swap();
int TUTORexpand_swap();
void TUTORread_swap();
void TUTORscan_swap();
void TUTORdelete_swap();
long TUTORwrite_swap();
char *TUTORgetenv();

struct swapl {
    char used;
    char dead_space;
    long length;
};

/* If you change this structure, be prepared to change the offset value
    for all calls to TUTOR*_darray() */

#define SWAPINIT SWAPINC+10

typedef struct _sd {
    char expandFlag; /* TRUE when we are doing memory management */
                     /* to increase swap handle */
    char unused[3];
    long nArrays;
    long offsets[1];
    long handlesize;
    DArrayHeader head;
    struct swapl swapList[SWAPINIT];
} SwapDat;

#define SWAPOFF 4

typedef SwapDat FAR *SwapDatP;

FileRef swapRef;

static Memh swapHandle = 0;
static int swapf;
static short swapFree = 0;    /* # of free entries in swap handle */

struct DeferEntry { /* item in deferred-delete list */
    int type;   /* type of object to delete */
    Memh handle; /* handle on object to delete */
    char FAR *ptr; /* pointer to object to delete */
};

static int deferN = 0; /* number items in deferred-delete list */
static int deferA = 0; /* size of deferred-delete list */
static Memh deferH = 0; /* handle on deferred-delete list */

#ifdef DOSPC
extern long mem_conv; /* conventional memory found */
extern long mem_xms; /* xms found */
extern long mem_ems; /* ems found */
extern long mem_disk; /* disk swap found */

static int emsf = 0;
static int xmsf[4] = { 0,0,0,0 };
#endif

/* small utilities, should really be machine dependent: ***************/

#ifndef THINKC5

/* ------------------------------------------------------------------- */

unsigned char FAR *TUTORscan_bytes(bp,be,tp,nTab) /* scan for some bytes */
register unsigned char FAR *bp;    /* pointer at beginning of scan region */
register unsigned char FAR *be;    /* pointer at last byte in scan region */
register unsigned char *tp;    /* pointer to table of bytes to search for */
register int nTab;    /* # of entries in table */
/* returns the position of bp when a byte is found, or NULL if not found */
    
{   register unsigned char cc;
    
    /* special case when there is only 1 table entry */

    if (nTab == 1) {
        cc = *tp;
        if (bp <= be) { /* forward scan */
            while (*bp != cc && bp < be)
                bp++;
        } else { /* backwards scan */
            while (*bp != cc && bp > be)
                bp--;
        }
        if (*bp == cc)
            return(bp); /* found char */
        return(FARNULL); /* didn't find it */
    } /* nTab if */
    
    /* more general case */

    if (bp <= be) { /* forward scan */
        while (bp <= be) {
            for (cc=0; cc < nTab; cc++)
                if (*bp == tp[cc])
                    return(bp);
            bp++;
        } /* while */
    } else { /* backwards scan */
        while (TRUE) {
            for (cc=0; cc < nTab; cc++)
                if (*bp == tp[cc])
                    return(bp);
            if (bp == be)
                break; /* we've run out of characters */
            bp--;
        } /* while */
    } /* else */
    return(FARNULL); /* didn't find */

} /* TUTORscan_bytes */
#endif

#ifndef THINKC5

/* ------------------------------------------------------------------- */

TUTORcount_bytes(tp,te,cc) /* count bytes of a certain kind */
register unsigned char FAR *tp;    /* pointer to start of range */
register unsigned char FAR *te;    /* pointer to last char of range */
register int cc;

{   register int count;
    
    count = 0;
    while (tp <= te) {
        if (*tp == cc)
            count++;
        tp++;
    } /* while */
    
    return(count);

} /* TUTORcount_bytes */

#endif

/* ------------------------------------------------------------------- */

Memh TUTORcopy_handle(mm) /* returns a copy of a handle */
Memh mm; /* handle to copy */
    
{   struct htab FAR *hp;
    Memh newH;
    char FAR *p1, FAR *p2;
    char label[10];
    long size;
    int purge;
    
    /* allocate new handle */
    hp = (struct htab FAR *) TUTORget_entry_mem(mm);
    LockMemoryTable();
    size = hp->size;
#ifdef CTSWAP
    purge = hp->purge;
#endif
#ifdef MEMVERIFY
strncpyf((char FAR *)label,hp->label,8);
label[8] = '0';
#else
strcpy(label,"copyhand");
#endif
    UnlockMemoryTable();
    newH = TUTORhandle(label,size,purge & (~M_RPROC));
    if (!newH) 
    	return(0);
    
    /* copy contents */
    p1 = GetPtr(mm);
    p2 = GetPtr(newH);
    TUTORblock_move(p1,p2,size);
    ReleasePtr(mm);
    KillPtr(p1);
    ReleasePtr(newH);
    KillPtr(p2);
    
    return(newH);

} /* TUTORcopy_handle */

/* ------------------------------------------------------------------- */

long TUTORget_hsize(mm) /* return size of memory area */
Memh mm;

{
    return(TUTORget_entry_mem(mm)->size);
}
/* ------------------------------------------------------------------- */

int TUTORget_lockcount(mm) /* return handles lock count */
Memh mm;

{
    return(TUTORget_entry_mem(mm)->lockcount);
}

/* ------------------------------------------------------------------- */

TUTORpurge_info(mm, ptype, restoreproc, restorearg)
Memh mm;    /* handle to set info for */
int ptype; /* M_NOPURGE, M_REALLOC, M_RPROC, M_WORM, or M_WMRM */
int (FAR *restoreproc) ();    /* pointer to procedure for ptype 2 handles */
int restorearg;    /* argument for restoreproc */

{   struct htab FAR *hp;    /* pointer to handle table entry */

#ifdef CTSWAP
    hp = (struct htab FAR *) TUTORget_entry_mem(mm);
    /* clear purge bit and type field */

    hp->purge &= ~M_TYPEMASK;
    hp->purge |= ptype; 
    if (ptype == M_RPROC) { 
        hp->position = (long)restoreproc;/* set procedure to call */
        hp->rarg = restorearg;    /* argument to pass */
    }
#endif

} /* TUTORpurge_info */

/* ------------------------------------------------------------------- */

AllowHandlePurge(mm)        /* allow purge of specified memory area */
    Memh            mm;    /* handle on area */

{   struct htab FAR *hp;    /* pointer to handle table entry */

#ifdef CTSWAP
    hp = (struct htab FAR *) TUTORget_entry_mem(mm);
    hp->purge |= M_PURGEABLE;    /* set purge-enabled bit */
#endif

} /* AllowHandlePurge */

/* ------------------------------------------------------------------- */

ChangedHandle(mm,stillPurge) /* take care of purgeability when a handle is changed */
Memh mm;
int stillPurge;    /* TRUE if still purgeable */
    {
    struct htab FAR *hp;
    
#ifdef CTSWAP
    hp =  (struct htab FAR *) TUTORget_entry_mem(mm);
    LockMemoryTable();
    if (!stillPurge)
        hp->purge &= ~M_PURGEABLE;    /* clear purge bit */
    else if ((hp->purge & M_WORM) && hp->position >= 0) {
        TUTORdelete_swap(hp->position); /* disk image is invalid */
        hp->position = -1; /* mark no disk image */
    }
    UnlockMemoryTable();
#endif   
    return(0);
    }

/* ------------------------------------------------------------------- */

TUTORhandle_ispurged(mm)
Memh mm;

{   struct htab FAR *hp;

#ifdef CTSWAP
    hp = (struct htab FAR *) TUTORget_entry_mem(mm);
    if (hp->purge & M_NOTINMEM)
        return (TRUE);
#endif
    return (FALSE);

} /* TUTORhandle_ispurged */

/* ------------------------------------------------------------------- */

TUTORrecover_handle(hp,areap,handle)
struct htab FAR *hp;
char FAR *areap;
int handle;

{   long rsize; /* size to read from swap */
    int pType; /* purge type */
    int sum;    /* checksum of recovered memory */
	long sPos;
	char *dp;

#ifdef CTSWAP
    rsize = hp->size;
    hp->purge &= ~M_NOTINMEM; /* clear purged bit */

#ifdef DOSPC

    /* size must be even for XMS read on PC - safe as PC memory */
    /* alloc always rounds up to 4-byte boundary */

    if (rsize & 1)
    rsize++;
#endif

	sPos = hp->position;
    pType = hp->purge & M_TYPEMASK;
    
    switch (pType) {

    case M_REALLOC:    /* re-allocate handle */
        break;    /* nothing to do - already allocated */

    case M_RPROC:    /* call re-allocate procedure */
    (*((PFI)(hp->position))) (handle, areap, hp->size, hp->rarg);
        break;

    case M_WORM:
    TUTORscan_swap(hp->position, rsize, areap);
        break;

    case M_WMRM:
    TUTORread_swap(hp->position, rsize, areap);
        hp->position = -1; /* indicates that it is no longer on disk */
        break;

    default:
        TUTORdump("TUTORrecover_handle");
    }

#ifdef MEMVERIFY
#ifdef MAC
    if (pType == M_WORM || pType == M_WMRM)
        { /* check the checksum */
        sum = TUTORchecksum(areap,rsize);
        if (sum != hp->swapSum) {
            TUTORdump("Bad checksum in TUTORrecover_handle");
		}
        }
#endif /* MAC */
#endif /* MEMVERIFY */
#endif /* CTSWAP */
}

/* ------------------------------------------------------------------- */

/* TUTORinit_swap() gets a handle for the swapList, and initializes
   the Handle for use with the dynamic array package.  It also creates
   a unique file name for the swap file.
   */
#ifdef MAC

void TUTORinit_swap()
{
    REGISTER SwapDatP swapPtr;
    FileRef tempRef;
    long shift;
    char *tempP;
    char buf[100];
    int jj;

    swapHandle = HNULL;
    
#ifdef NOSUCH
    if (pswappath) {
        if ((jj = strlenf(pswappath)) <= 80) {
            strcpy((char FAR *)buf,pswappath); /* copy path */ 
            if (buf[jj-1] != ':') 
                strcat(buf,":"); /* append colon after path */
	    TUTORcvt_path(buf,(FileRef FAR *)&tempRef,ctDirP,TRUE);
            havePath = TRUE;
        }
    } /* pswappath if */
#endif

	swapf = MacSysFolder(&swapRef,3); /* open system-defined temp */
	
	if (!swapf) {
	
    	/* open file and get findx */
    	
	tempRef = *ctDirP; /* use path to cT */
    	TUTORtemp_file_name((FileRef FAR *)&tempRef, (FileRef FAR *)&swapRef);

    	/* open to create and, if necessary, delete */

    	swapf = TUTORopen((FileRef FAR *)&swapRef, FALSE, TRUE, FALSE);
    }
    if (!swapf)
        return;

    TUTORclose(swapf);
    swapf = TUTORopen((FileRef FAR *)&swapRef, TRUE, TRUE, FALSE);
    if (!swapf)
        return;

    shift = ((long) swapf) << 24;

    /* set up swap list */

    swapHandle = TUTORhandle("swapList", (long) sizeof(SwapDat),FALSE);
    swapPtr = (SwapDatP) GetPtr(swapHandle);
    swapPtr->expandFlag = FALSE;
    swapPtr->nArrays = 1;
    swapPtr->offsets[0] = (char FAR *) &swapPtr->head - (char FAR *) swapPtr;
    swapPtr->handlesize = sizeof(SwapDat);
    swapPtr->head.dAnn = 2;
    swapPtr->head.dAnAlloc = SWAPINIT;
    swapPtr->head.nBuff = NOLDFIND;
    swapPtr->head.itemSize = sizeof(struct swapl);
    swapPtr->swapList[0].used = 1;
    swapPtr->swapList[0].length = shift;
    swapPtr->swapList[1].used = 0;
    swapPtr->swapList[1].length = maxSwapLen;
    swapFree = swapPtr->head.dAnAlloc - swapPtr->head.dAnn;
    ReleasePtr(swapHandle);
    KillPtr(swapPtr);

} /* TUTORinit_swap() */
#endif /* MAC */

/* ------------------------------------------------------------------- */

#ifdef WINPC

void TUTORinit_swap()

{   SwapDatP swapPtr;
    FileRef tempRef;
    int ii, jj;
    long size, add_element, boundary = 0;
    char buf[100], *c;

#ifdef CTSWAP
    swapHandle = TUTORhandle("swapList",(long)sizeof(SwapDat),FALSE);
    swapPtr = (SwapDatP) GetPtr(swapHandle);
    swapPtr->expandFlag = FALSE;
    swapPtr->nArrays = 1;
    swapPtr->offsets[0] = (char FAR *)&swapPtr->head-(char FAR *)swapPtr;
    swapPtr->handlesize = sizeof(SwapDat);
    swapPtr->head.nn = 0;
    swapPtr->head.nAlloc = SWAPINIT;
    swapPtr->head.nBuff = NOLDFIND;
    swapPtr->head.itemSize = sizeof(struct swapl);
    add_element = 0;
	c = TUTORgetenv("CT_TEMP");
	if (!c)
    	c = TUTORgetenv("TMP"); /* get ptr to path in environment, if any */
    if (!c)
    	c = TUTORgetenv("TEMP");
    TUTORzero((char SHUGE *)&tempRef,(long)sizeof(FileRef));
    if (pswappath) {
    if ((jj = strlenf(pswappath)) <= 80) {
        strcpyf((char FAR *)buf,pswappath); /* copy path */
        if (buf[jj-1] != '\\')
        strcat(buf,"\\"); /* append backslash after path */
	TUTORcvt_path(buf,(FileRef FAR *)&tempRef,ctDirP,TRUE);
    }
    } /* pswappath if */
    if (tempRef.path[0]) { /* have temp file path */
    strcat(tempRef.path,"ctt");
    } else if (c) {
    strcpy(buf, c);
    if (buf[strlen(buf)-1] != '\\')
        strcat(buf,"\\");
    strcat(buf, "ctt");
    TUTORcvt_path(buf, (FileRef FAR *)&tempRef, FARNULL,TRUE);
    } else {
    TUTORcvt_path("ctt", (FileRef FAR *)&tempRef,ctDirp,TRUE);
    }
    TUTORtemp_file_name((FileRef FAR *)&tempRef, (FileRef FAR *)&swapRef);
    /* open to create and, if necessary, delete */
    swapf = TUTORopen((FileRef FAR *)&swapRef, FALSE, TRUE, FALSE);
    if (swapf) {
    size = maxSwapLen;
    TUTORclose(swapf);
    add_element = swapf = TUTORopen((FileRef FAR *)&swapRef, TRUE, TRUE, FALSE);
    }

    if (add_element != 0) {
    if (TUTORinsert_darray(swapHandle, (char FAR *)swapPtr, SWAPOFF, 0, -1, 2) == FALSE)
        TUTORdump("Dynamic array failure in TUTORinit_swap");
    jj = swapPtr->head.nn - 2;
    add_element = add_element << 24;
    swapPtr->swapList[jj].used = 1;
    swapPtr->swapList[jj++].length = add_element - boundary;
    swapPtr->swapList[jj].used = 0;
    swapPtr->swapList[jj].length = size;
    boundary = add_element + size;
    } /* add_element if */
    swapFree = swapPtr->head.nAlloc - swapPtr->head.nn;
    ReleasePtr(swapHandle);
#endif /* CTSWAP */
    return(0);

} /* TUTORinit_swap() */

#endif /* WINPC */

/* ------------------------------------------------------------------- */

#ifdef DOSPC

void TUTORinit_swap()

{   REGISTER SwapDatP swapPtr;
    FileRef tempRef;
    int ii, jj;
    int emsov,xmsov; /* 0 if ems, xms in use */
    long size, add_element, boundary = 0;
    char buf[100], *c;


    emsov = xmsov = 1; /* non-zero = not in use */
    if (useEMS)
        emsov = _OvrInitEms(0,0,0);
    if (useXMS)
        xmsov = _OvrInitExt(0L,0L);

    swapHandle = TUTORhandle("swapList",(long)sizeof(SwapDat),FALSE);
    swapPtr = (SwapDatP) GetPtr(swapHandle);
    swapPtr->expandFlag = FALSE;
    swapPtr->nArrays = 1;
    swapPtr->offsets[0] = (char FAR *)&swapPtr->head-(char FAR *)swapPtr;
    swapPtr->handlesize = sizeof(SwapDat);
    swapPtr->head.nn = 0;
    swapPtr->head.nAlloc = SWAPINIT;
    swapPtr->head.nBuff = NOLDFIND;
    swapPtr->head.itemSize = sizeof(struct swapl);

    for (ii = 0; ii < 6; ii++) {
        add_element = 0;
        switch(ii) {
        case 0:
            add_element = emsf = TUTORopen_ems((long FAR *)&size);
            mem_ems += size;
            break;
        case 1:
        case 2:
        case 3:
        case 4:
            add_element = xmsf[ii - 1] = TUTORopen_xms((long FAR *)&size);
            mem_xms += size;
            break;
        case 5:
			c = TUTORgetenv("CT_TEMP");
			if (!c)
            	c = TUTORgetenv("TMP"); /* get ptr to path in environment, if any */
            if (!c) 
                c = TUTORgetenv("TEMP");
            TUTORzero((char SHUGE *)&tempRef,(long)sizeof(FileRef));
            if (pswappath) {
                if ((jj = strlenf(pswappath)) <= 80) {
                    strcpyf((char FAR *)buf,pswappath); /* copy path */ 
                    if (buf[jj-1] != '\\') 
                        strcat(buf,"\\"); /* append backslash after path */
		    TUTORcvt_path(buf,(FileRef FAR *)&tempRef,ctDirP,TRUE);
                }
            } /* pswappath if */
            if (tempRef.path[0]) { /* have temp file path */
                strcat(tempRef.path,"ctt");
            } else if (c) {
                strcpy(buf, c);
                if (buf[strlen(buf)-1] != '\\')
                    strcat(buf,"\\");
                strcat(buf, "ctt");
                TUTORcvt_path(buf, (FileRef FAR *)&tempRef, FARNULL,TRUE);
            }
            else {
		TUTORcvt_path("ctt", (FileRef FAR *)&tempRef,ctDirP,TRUE);
            }
            TUTORtemp_file_name((FileRef FAR *)&tempRef, (FileRef FAR *)&swapRef);
            /* open to create and, if necessary, delete */
            swapf = TUTORopen((FileRef FAR *)&swapRef, FALSE, TRUE, FALSE);
            if (swapf) {
                mem_disk = size = maxSwapLen;
                TUTORclose(swapf);
                add_element = swapf = TUTORopen((FileRef FAR *)&swapRef, TRUE, TRUE, FALSE);
            }
            break;
        default:
            TUTORdump("Illegal level in TUTORinit_swap");
            break;
        } /* switch */
        if (add_element != 0) {
            if (TUTORinsert_darray(swapHandle, (char FAR *)swapPtr, SWAPOFF, 0, -1, 2) == FALSE)
                TUTORdump("Dynamic array failure in TUTORinit_swap");
            jj = swapPtr->head.nn - 2;
            add_element = add_element << 24;
            swapPtr->swapList[jj].used = 1;
            swapPtr->swapList[jj++].length = add_element - boundary;
            swapPtr->swapList[jj].used = 0;
            swapPtr->swapList[jj].length = size;
            boundary = add_element + size;
        } /* add_element if */
    } /* for */
    swapFree = swapPtr->head.nAlloc - swapPtr->head.nn;
    ReleasePtr(swapHandle);
    KillPtr(swapPtr);

} /* TUTORinit_swap() */

#endif /* IBMPC */

/* ------------------------------------------------------------------- */

#ifdef ANDREW

void TUTORinit_swap()

{   REGISTER SwapDatP swapPtr;
    FileRef tempRef;
    long shift;

    TUTORcvt_path("/tmp/temp", (FileRef FAR *)&tempRef, FARNULL,TRUE);
    TUTORtemp_file_name((FileRef FAR *)&tempRef, (FileRef FAR *)&swapRef);

    /* open to create and, if necessary, delete */
    swapf = 0; /* in case of failure */
    swapHandle = HNULL;
    swapf = TUTORopen((FileRef FAR *)&swapRef, FALSE, TRUE, FALSE);
    if (!swapf)
        return;
    TUTORclose(swapf);
    swapf = TUTORopen((FileRef FAR *)&swapRef, TRUE, TRUE, FALSE);
    if (!swapf)
        return;

    shift = ((long) swapf) << 24;
    /* set up swap list */
    swapHandle = TUTORhandle("swapList", (long) sizeof(SwapDat),FALSE);
    swapPtr = (SwapDatP) GetPtr(swapHandle);
    swapPtr->expandFlag = FALSE;
    swapPtr->nArrays = 1;
    swapPtr->offsets[0] = (char FAR *) &swapPtr->head - (char FAR *) swapPtr;
    swapPtr->handlesize = sizeof(SwapDat);
    swapPtr->head.nn = 2;
    swapPtr->head.nAlloc = SWAPINIT;
    swapPtr->head.nBuff = NOLDFIND;
    swapPtr->head.itemSize = sizeof(struct swapl);
    swapPtr->swapList[0].used = 1;
    swapPtr->swapList[0].length = shift;
    swapPtr->swapList[1].used = 0;
    swapPtr->swapList[1].length = maxSwapLen;
    swapFree = swapPtr->head.nAlloc - swapPtr->head.nn;
    ReleasePtr(swapHandle);
    KillPtr(swapPtr);

} /* TUTORinit_swap() */

#endif /* ANDREW */

/* ******************************************************************* */

/* TUTORclose_swap() closes and deletes the swap file.  It also frees
   the handle that was used for the swapList. */

void TUTORclose_swap()

{   int ii;

    if (!swapHandle)
        return;
    if (swapf)
        TUTORclose(swapf);
#ifdef DOSPC

    /* close ems and xms handles */

    if (emsf) 
        TUTORclose(emsf);
    for(ii=0; ii<4; ii++) {
        if (xmsf[ii])
        TUTORclose(xmsf[ii]);
        xmsf[ii] = 0;
    } /* for */
#endif
    TUTORdelete_file((FileRef FAR *)&swapRef);
    TUTORfree_handle(swapHandle);
}

/* ******************************************************************* */

TUTORinq_swap() /* returns number free items in swapList */

{
    return(swapFree);

} /* TUTORinq_swap */

/* ******************************************************************* */

int TUTORinq_fast_swap() /* returns TRUE if swap is to memory */

{
#ifdef DOSPC
    if (emsf || xmsf[0])
    return(TRUE);
#endif
    return(FALSE);

} /* TUTORinq_fast_swap */

/* ******************************************************************* */

/* TUTORexpand_swap() tries to ensure that there are at least SWAPINC
   items available in the swapList.  It returns the number of items available
   after the attempt.
   */
int TUTORexpand_swap()
{
    REGISTER SwapDatP swapPtr;
    int ii;

    if (!swapHandle)
        return(0);

    if (swapFree >= SWAPINC)
        return(swapFree);
    
    swapPtr = (SwapDatP) GetPtr(swapHandle);
    ii = swapPtr->expandFlag;
    if (!ii) /* set flag to avoid reccursive calls */
        swapPtr->expandFlag = TRUE;
    ReleasePtr(swapHandle);
    KillPtr(swapPtr);
    if (ii) /* don't expand when we are already in process of expanding */
        return((swapFree > SWAPINC) ? SWAPINC : swapFree);
    
    if (TUTORinsert_darray(swapHandle, FARNULL, SWAPOFF, 0, -1, SWAPINC) == TRUE) {
        swapPtr = (SwapDatP) GetPtr(swapHandle);
        swapPtr->expandFlag = FALSE;
        /* Altering the ->head structure is kind of risky */
        swapPtr->head.dAnn -= SWAPINC;
        swapFree = swapPtr->head.dAnAlloc - swapPtr->head.dAnn;
        ReleasePtr(swapHandle);
        KillPtr(swapPtr);
        return(swapFree);
    }

    /* Failed the insert_darray.  Return what we've got. */
    swapPtr = (SwapDatP) GetPtr(swapHandle);
    swapPtr->expandFlag = FALSE; /* done with expansion */
    swapFree = swapPtr->head.dAnAlloc - swapPtr->head.dAnn;
    ReleasePtr(swapHandle);
    KillPtr(swapPtr);
    return (swapFree);
}

/* ******************************************************************* */

/* TUTORread_swap() takes a position in the swap file, a length of the
   data to read in, and a pointer with enough space already allocated.
   It reads the information from the swap file into the memp and then
   marks the space as unused in the swapList.  This is for use with
   WMRM memory.
   */

void TUTORread_swap(pos, length, memp) /* read and mark unused */
long pos;            /* position in swap file */
long length;        /* length of data */
char FAR *memp;    /* memory to store data in */
{
    long offset = 0;
    short ii;
    REGISTER SwapDatP swapPtr;
    register struct swapl FAR *swapLP;
    int findx;
	long nIn;

    if (pos == 0)
        return; /* don't do anything with empty handle */

    findx = pos >> 24;

    if (!findx)
        return;
    swapPtr = (SwapDatP) GetPtr(swapHandle);
    swapLP = swapPtr->swapList;

    /* find block */
    for (ii = 0; offset != pos; ii++) {
        offset += swapLP->length;
        swapLP++;
    }

    pos &= 0xffffff;
    /* read into memory */
    TUTORseek(findx, pos);
    nIn = TUTORread(memp, 1, length, findx);
	if (nIn != length)
		TUTORdump("read from swap file failed 2");

    /* mark as unused in list */
    /* if previous or following list item is also unused, merge them */
    swapLP->used = 0;
    if ((ii + 1 < swapPtr->head.dAnn) && !(swapLP+1)->used) {
        swapLP->length += (swapLP+1)->length;
        TUTORdelete_darray(swapHandle, (char FAR *) swapPtr, SWAPOFF, 0, ii + 1, 1);
    }
    if (ii && !(swapLP-1)->used) {
        (swapLP-1)->length += swapLP->length;
        TUTORdelete_darray(swapHandle, (char FAR *) swapPtr, SWAPOFF, 0, ii, 1);
    }
    
    swapFree = swapPtr->head.dAnAlloc - swapPtr->head.dAnn;
    ReleasePtr(swapHandle);
    KillPtr(swapPtr);
    
    return;
}                /* TUTORread_swap() */

/* ******************************************************************* */

/* TUTORscan_swap() takes the same arguments as TUTORread_swap() but
   does not delete the data from the swap file.  This is for use with
   WORM memory.
   */

void TUTORscan_swap(pos, length, memp) /* read and don't mark changes */
long pos;            /* position in swap file */
long length;        /* length of data */
char FAR *memp;    /* block of memory to use */
{
    int findx;
	long nIn;

   if (pos == 0)
        return; /* don't do anything with empty handle */

    findx = pos >> 24;

    /* go to position passed */
    if (!findx)
        return;
    TUTORseek(findx, (pos & 0xffffff));
    nIn = TUTORread(memp, 1, length, findx);
	if (nIn != length)
		TUTORdump("read from swap file failed 1");
}                /* TUTORscan_swap() */

/* ******************************************************************* */

/* TUTORdelete_swap() takes a position in the swap file.  It then marks
   that area as deleted.  This is particularly useful for expiring WORM
   memory that has been put out to disk.  Because this does no disk
   access, it is relatively inexpensive.
   */

void TUTORdelete_swap(pos)
long pos;
{
    int ii, findx;
    long offset = 0;
    REGISTER SwapDatP swapPtr;
    register struct swapl FAR *swapLP;

    if (pos == 0)
        return; /* don't do anything with empty handle */

    findx = pos >> 24;
    if (!findx)
        return;

    swapPtr = (SwapDatP) GetPtr(swapHandle);
    swapLP = swapPtr->swapList;

    for (ii = 0; offset != pos; ii++) {
        offset += swapLP->length;
        swapLP++;
    }

    /* mark as unused in list */
    /* if previous or following list item is also unused, merge them */
    swapLP->used = 0;
    if ((ii + 1 < swapPtr->head.dAnn) && !(swapLP+1)->used) {
        swapLP->length += (swapLP+1)->length;
        TUTORdelete_darray(swapHandle, (char FAR *) swapPtr, SWAPOFF, 0, ii + 1, 1);
    }
    if (ii && !(swapLP-1)->used) {
        (swapLP-1)->length += swapLP->length;
        TUTORdelete_darray(swapHandle, (char FAR *) swapPtr, SWAPOFF, 0, ii, 1);
    }
    swapFree = swapPtr->head.dAnAlloc - swapPtr->head.dAnn;
    ReleasePtr(swapHandle);
    KillPtr(swapPtr);
}

/* ******************************************************************* */

/* TUTORwrite_swap() takes a length and a pointer to an area of memory.
   It finds the first available space in the swap file (appending if
   necessary) and writes it to that location.  It returns the position
   in the file that it wrote the memory to (-1 on failure). */

long TUTORwrite_swap(memp, size) /* first fit only */
char FAR *memp;    /* block of memory to write */
long size;            /* length of block */
{
    register long offset = 0;
    short ii, found;
    REGISTER SwapDatP swapPtr;
    register struct swapl FAR *swapLP;
    int findx;
	long nOut;
	struct tutorfile FAR *tfp;

    if (size == 0)
        return(0L); /* don't do anything with empty handle */

    found = FALSE;
    swapPtr = (SwapDatP) GetPtr(swapHandle);

    /* run through list looking for length and unused */
    swapLP = swapPtr->swapList;
    for (ii = 0; ii < swapPtr->head.dAnn; ii++) {
        if (!swapLP->used && (swapLP->length >= size)) {
            found = TRUE;
            break;
        } else {
            offset += swapLP->length;
            swapLP++;
        }
    }

    if (!found) {
        ReleasePtr(swapHandle);
        KillPtr(swapPtr);
        return -1L;
    }

    findx = offset >> 24;
    if (!findx) {
        ReleasePtr(swapHandle);
        KillPtr(swapPtr);
        return -1L;
    }
    offset &= 0xffffff; /* take the lower 24 bits */
	tfp = (struct tutorfile FAR *)GetPtr(filesopen); /* lock file table */
	tfp += findx;

    TUTORseek(findx, offset);

    nOut = TUTORwrite(memp, 1, size, findx);
	ReleasePtr(filesopen); /* release file table */
	if (nOut != size) {
		TUTORdump("write to swap file failed");
		return(-1L);
	}

    /* append if necessary */
    if (swapLP->length == size) {
        swapLP->used = 1;
    } else { /* swapLP->length > size */
        if (TUTORinsert_darray(swapHandle, (char FAR *) swapPtr, SWAPOFF, 0, ii + 1, 1) == FALSE) {
            /* the insert failed.  abort the function */
            ReleasePtr(swapHandle);
            KillPtr(swapPtr);
            return -1L;
        }
        /* set up new block */
        (swapLP+1)->length = swapLP->length - size;
        (swapLP+1)->used = 0;
        
        /* fill out fields for block we are using */
        swapLP->length = size;
        swapLP->used = 1;
    }
    swapFree = swapPtr->head.dAnAlloc - swapPtr->head.dAnn;
    ii = swapPtr->expandFlag;
    ReleasePtr(swapHandle);
    KillPtr(swapPtr);
    
    return (offset | ((long) findx << 24));
}

/* ******************************************************************* */

assoc_name(fn,bfilen, extnNew) /* generate associated file name from source name */
FileRef FAR *fn; /* pointer to (possible) source file name */
FileRef FAR *bfilen; /* place to put binary file name */
char *extnNew; /* extension desired */

{    char extn[20]; /* file name extension */
    char FAR *cp; /* pointer in file name */
    int fnl; /* length of file name */
    int exl; /* length of extension */

    /* build file name extension */

    extn[0] = '\0';
#ifdef ANDREW
    strcat(extn,".");
    strcat(extn,machinename());
#else
#ifdef SYSV
    strcat(extn,".");
    strcat(extn,machinename());
#endif
#endif
    strcat(extn,extnNew); /* append file extension */

    /* get file name, check if already have same extension */

    TUTORcopy_fileref(bfilen, fn);
    fnl = strlenf(bfilen->path); /* get length of file name */
    exl = strlen(extn);
    if ((fnl >= exl) && (strncmpf(bfilen->path+fnl-exl,(char FAR *) extn,exl) == 0))
        return(0); /* already have proper extension */

    /* remove .t extension if present */

    if ((fnl > 2) && ((bfilen->path[fnl-1] == 't') || (bfilen->path[fnl-1] == 'T')) && (bfilen->path[fnl-2] == '.')) {
        bfilen->path[fnl-2] = '\0'; /* kill .t extension */
        fnl -= 2; 
    } /* if */

    /* check if other extension */

#ifdef IBMPC
    fnl = strlenf(bfilen->path); /* get index in name */
    cp = &bfilen->path[fnl];
    while (fnl > 0) {
        cp--;
        fnl--;
        if (*cp == '.') {
            *cp = '\0'; /* remove extension */
            break;
        } else if (*cp == '\\')
            break;
    } /* while */
#endif

    strcatf(bfilen->path,(char FAR *) extn); /* append extension */
    return(0);

} /* assoc_name */

/* ******************************************************************* */

static char *machine_namep = NULL;

char *machinename() /* return machine name string */

{    char *pmstr; /* pointer to machine name string */

    if (machine_namep)
        return(machine_namep); /* already know machine name */
        
    /* get machine name from environment, if possible */
    
    machine_namep = TUTORgetenv("CT_CPU");
    if (machine_namep) {
        return(machine_namep);
    }

    pmstr = NULL;

#ifdef vax
    pmstr = "vax";
#endif

#ifdef mips
    pmstr = "dec3100";
#endif

#ifdef    sparc
    pmstr = "sparc";
#endif

#ifdef sunV3
#ifdef mc68020
       pmstr = "sun3";
#else
    pmstr = "sun2";
#endif
#endif

#ifdef ibm032
    if (fpastat()) pmstr = "ibm-rt1";
    else pmstr = "ibm-rt2";
#endif

#ifdef IBMPC
    pmstr = "ibm-pc";
#endif

#ifdef MAC
    pmstr = "mac";
#endif

#ifdef LINUX
    pmstr = "linux";
#endif

    if (pmstr == NULL) {
#ifdef GENERICSYS
        pmstr = "generic";
#else
        pmstr = "unrec";
#endif
    } /* pmstr if */
    machine_namep = pmstr; 
    return(pmstr);

} /* machinename */

/* ******************************************************************* */

TUTORfiles_init() /* initialize file table */

{   struct tutorfile FAR *tfp;

    if (filesmalloc == 0){ /* allocate file table if not present */
        filesmalloc = 2;
        filesopen = TUTORhandle("files  ",(long)(filesmalloc*sizeof(struct tutorfile)),FALSE);
        if (!filesopen)
            StopProgram(NEARNULL);
        tfp = (struct tutorfile FAR *) GetPtr(filesopen);
        tfp->inuse = (tfp+1)->inuse = FALSE;
        ReleasePtr(filesopen);
        KillPtr(tfp);
    }

} /* TUTORfiles_init */

/**************   DYNAMIC ARRAY machinery *************************/

#ifdef COMMENT
A dynamic array is a variable length array at the end of a handle.  A given
handle may have more than one array.  The first will be accesible via C, the
rest will only be indirectly accesible.
We will expect a data structure of the form:

    {
    int xx;    /* various fields of data */
    int yy;
    ...
    long nArrays;            /* # of arrays in this handle */
                            /* offset arg in routines refers to position of nArrays */
    long offsets[nArrays];    /* offsets (in bytes) from handle start to DarrayHeader of array */
    long handleSize;        /* the total size of the handle */
    
    DArrayHeader head0;        /* header for first darray */
    zzstruct elements0[1]; /* variable length array */
    
    DArrayHeader head1;        /* header for second array */
    yystruct elements1[1];
    ...
    }

Where DArrayHeader is defined as:

typedef struct _dah
    {
    unsigned short nn;      /* # of items in array */
    unsigned short nAlloc;  /* # of items in use */
    unsigned short nBuff;   /* # of items extra we want around */
    unsigned short itemSize;    /* size (in bytes) of each item */
    } DArrayHeader;
    
The dynamic array is most easily manipulated with the various TUTOR*_darray
routines, which will do the bookkeeping and shift data around properly.

Note that the elements will be stored without reference to byte alignment,
so if byte alignment is important the structure definition of elements
needs to be carefully stated.  On machines that
require word alignment, the structure definitions for the "elements" needs
to have an even number of bytes.  Machines that need longword alignments for longwords
will want elements with a length divisable by 4.  The easiest way to guarantee proper alignment
is to end the structure definition with a field of the type that is requires the strictest alignment.
Then the compiler should put appropriate pad bytes into the structure, for your machine.

The dynamic array machinery will internally pad each dynamic array so that every DArrayHeader
starts on a longword boundary.  This, along with the fact that the DArrayHeader is four unsigned
shorts, should keep the dynamic array machinery from fouling up alignment itself.

A declaration for a structure which will be in a handle with several
dynamic arrays in it will typically declare each array with 1 element.
The various fields of the DArrayHeader can then be set up
in the C code.  But once the arrays are larger than declared, the structure
definition will be invalid - references to structure elements after
the first array should never be made.

The TUTOR*_darray routines take an argument "offset".  This is the offset in
the handle to the nArrays structure element.  This allows the routines
to work with any handles.

#endif /* COMMENT */

TUTORinsert_darray(da,dp,offset,arrayN,ind,nIns) /* open space for more items */
Memh da; /* only needs to be unlocked if expansion is required */
char FAR *dp; /* if exists, pointer to locked handle */
int offset;
int arrayN; /* which array in handle */
int ind; /* space will be opened up here (-1 for append) - 0 based */
int nIns;  /* # of places to open up */
/* returns success flag */
    {
    long tempL, daSize, addSize;
    long nPad;    /* # of bytes (from 0 to 3) needed to maintain longword alignment
                of dynamic arrays following this one */
    long oldPad; /* # of pad bytes we had before */
    short ii, nNew;
    char FAR *cp;
    long FAR *lp; /* points at header info for all darrays */
    DArrayHeader FAR *hp; /* points at header info for this darray */
    char gotPointer;
    long followN;    /* byte offset to following data */
    
    if (!da) return(FALSE);
    if (nIns <= 0)
        return(TRUE);
    
    /* get a pointer to the handle, but only if we need to */
    if (!dp)
        {
        gotPointer = TRUE;
        dp = GetPtr(da);
        }
    else
        gotPointer = FALSE;

    lp = (long FAR *) (dp + offset);
    if (arrayN < 0 || arrayN >= lp[0])
        { /* bad array */
        if (gotPointer)
            {
            ReleasePtr(da);
            KillPtr(dp);
            }
        return(FALSE);
        }
    
    daSize = lp[lp[0]+1];
    hp = (DArrayHeader FAR *) (dp + lp[1+arrayN]); /* set hp to point at array data */
        
    if (ind > hp->dAnn || ind < 0)
        ind = hp->dAnn; /* append */
    if (hp->dAnn+nIns > hp->dAnAlloc)
        { /* need to allocate more space */
        if (!gotPointer)
            return(FALSE); /* we were handed locked handle! */
        
        nNew = hp->nBuff + nIns - (hp->dAnAlloc - hp->dAnn);
        addSize = hp->itemSize*nNew; /* size of added array items */
        
        /* calculate # of bytes needed for longword alignment: */
        oldPad = (lp[2+arrayN] - lp[1+arrayN]) - (hp->itemSize * hp->dAnAlloc) -
                        sizeof(DArrayHeader); /* # of old pad bytes */
        nPad = 3 & (4L - (3 & ((long) hp->itemSize)*(nNew+hp->dAnAlloc))); /* # of pad bytes we want */
        nPad -= oldPad; /* nPad is now # of bytes to add (could be negative) */
        
        ReleasePtr(da);
        KillPtr(dp);
        TUTORset_hsize(da,daSize + addSize+nPad,TRUE);
        dp = GetPtr(da);
        lp = (long FAR *) (dp + offset); /* lp points to nArrays */
        lp[lp[0]+1] += addSize+nPad; /* update total handle size */
        
        hp = (DArrayHeader FAR *) (dp + lp[1+arrayN]); /* set hp to point at array data */
        hp->dAnAlloc += nNew;
        
        if (arrayN < lp[0] - 1)
            { /* there are other arrays following this one
                    we have to shift everything that follows */
            cp = (char FAR *) (dp + lp[2+arrayN]); /* points to following data */
            /* move following data: */
            TUTORblock_move(cp,cp+addSize+nPad,daSize - lp[2+arrayN]);
            for (ii=arrayN+1; ii<lp[0]; ii++)
                lp[1+ii] += addSize+nPad; /* update offsets to array headers */
            }
        }
    
    if (ind < hp->dAnn)
        { /* have to shift items in block */
        cp = ((char FAR *) (hp+1)) + ind*hp->itemSize; /* points where new item goes */
        tempL = (hp->dAnn - ind) * hp->itemSize;
        TUTORblock_move(cp,cp+hp->itemSize*nIns,tempL);
        }
    
    /* update nDat */
    hp->dAnn += nIns; /* update number of items */
    
    if (gotPointer)
        {
        ReleasePtr(da);
        KillPtr(dp);
        }
    
    return(TRUE);
    }

TUTORdelete_darray(da,dp,offset,arrayN,ind,nDel)  /* delete items */
Memh da; /* doesn't have to be unlocked */
char FAR *dp;
int offset;
int arrayN; /* which darray to delete from */
int ind; /* index of first item to be deleted */
int nDel; /* # of items to be deleted */
    {
    long tempL;
    short sizeEach, nItems;
    char FAR *cp;
    long FAR *lp; /* points at header info for all darrays */
    DArrayHeader FAR *hp; /* points at header info for this darray */
    char gotPointer;
    
    if (!da) return(FALSE);
    if (nDel <= 0)
        return(TRUE);
    
    /* get a pointer to the handle, but only if we need to */
    if (!dp)
        {
        gotPointer = TRUE;
        dp = GetPtr(da);
        }
    else
        gotPointer = FALSE;

    lp = (long FAR *) (dp + offset);
    if (arrayN < 0 || arrayN >= lp[0])
        { /* bad array */
        if (gotPointer)
            {
            ReleasePtr(da);
            KillPtr(dp);
            }
        return(FALSE);
        }
    
    hp = (DArrayHeader FAR *) (dp + lp[1+arrayN]); /* set hp to point at array data */

    if (ind >= hp->dAnn)
        {
        if (gotPointer)
            {
            ReleasePtr(da);
            KillPtr(dp);
            }
        return(FALSE);
        }
    
    if (ind + nDel > hp->dAnn)
        nDel = hp->dAnn - ind;
    
    if (ind + nDel < hp->dAnn)
        { /* need to shift trailing elements down */
        cp = ((char FAR *) (hp+1)) + hp->itemSize*(ind+nDel);
        tempL = (hp->dAnn-(ind+nDel))*hp->itemSize;
        TUTORblock_move(cp,cp-nDel*hp->itemSize,tempL);
        }
    
    hp->dAnn -= nDel;
    
    if (gotPointer)
        {
        ReleasePtr(da);
        KillPtr(dp);
        }
    
    return(TRUE);    
    }

TUTORreplace_darray(da,dp,offset,arrayN,ind,replaceN,newN,datP)
Memh da; /* doesn't have to be unlocked */
char FAR *dp;
int offset;
int arrayN;
int ind; /* where we should start replacing */
int replaceN; /* # of items to replace */
int newN; /* # of new items */
char FAR *datP;
    {
    long tempL;
    short sizeEach, nItems;
    char FAR *cp;
    long FAR *lp; /* points at header info for all darrays */
    DArrayHeader FAR *hp; /* points at header info for this darray */
    char gotPointer, gp2;
    
    if (!da) return(FALSE);
    if (replaceN < 0)
        replaceN = 0;
    if (newN < 0)
        newN = 0;
    if (replaceN == 0 && newN == 0)
        return(TRUE);
    
    /* get a pointer to the handle, but only if we need to */
    if (!dp)
        {
        gotPointer = TRUE;
        dp = GetPtr(da);
        }
    else
        gotPointer = FALSE;

    lp = (long FAR *) (dp + offset);
    if (arrayN < 0 || arrayN >= lp[0])
        { /* bad array */
        if (gotPointer)
            {
            ReleasePtr(da);
            KillPtr(dp);
            }
        return(FALSE);
        }
    
    hp = (DArrayHeader FAR *) (dp + lp[1+arrayN]); /* set hp to point at array header data */
    cp = (char FAR *) (hp+1); /* points at actual data */
    
    /* make sure parameters are workable */
    if (ind >= hp->dAnn || ind < 0)
        { /* force to append */
        ind = hp->dAnn;
        }
    if (ind + replaceN > hp->dAnn)
        replaceN = hp->dAnn - ind;
    
    /* fast case for simple append */
    if (ind+replaceN == hp->dAnn && hp->dAnAlloc >= hp->dAnn + newN - replaceN)
        { /* simple append without reallocation - do it quick */
        if (newN)
            TUTORblock_move(datP,cp+hp->itemSize*ind,(long) (hp->itemSize * newN));
        hp->dAnn += (newN - replaceN);
        if (gotPointer)
            {
            ReleasePtr(da);
            KillPtr(dp);
            }
        return(TRUE);
        }
    
    /* complete cases */
    if (replaceN > newN)
        { /* delete some characters */
        TUTORdelete_darray(da,dp,offset,arrayN,ind,replaceN - newN);
        }
    else if (replaceN < newN)
        { /* make some space */
        if (hp->dAnAlloc < hp->dAnn + newN - replaceN)
            { /* will need to do reallocation, so release pointer */
            if (!gotPointer)
                return(FALSE); /* we weren't handed unlocked handle! */
            ReleasePtr(da);
            KillPtr(dp);
            gp2 = TRUE;
            }
        else
            gp2 = FALSE;
        TUTORinsert_darray(da,FARNULL,offset,arrayN,ind+replaceN,newN - replaceN);
        if (gp2)
            { /* get pointers back */
            dp = GetPtr(da);
            lp = (long FAR *) (dp + offset);
            hp = (DArrayHeader FAR *) (dp + lp[1+arrayN]); /* set hp to point at array header data */
            cp = (char FAR *) (hp+1); /* points at actual data */
            }
        }
    
    /* move data into place */
    if (newN)
        TUTORblock_move(datP,cp+hp->itemSize*ind,(long) (hp->itemSize * newN));
    
    if (gotPointer)
        {
        ReleasePtr(da);
        KillPtr(dp);
        }
    
    return(TRUE);
    }

TUTORcompress_darray(da,offset) /* compress out any extra space, if any */
Memh da; /* should be unlocked (for TUTORset_hsize) */
int offset;
    {
    char FAR *dp;
    long tempL;
    char FAR *cp;
    long FAR *lp; /* points at header info for all darrays */
    DArrayHeader FAR *hp; /* points at header info for this darray */
    int ii;
    long nMove;
    
    if (!da) return(FALSE);
    
    /* get a pointer to the handle */
    dp = GetPtr(da);

    lp = (long FAR *) (dp + offset);
    nMove = 0L;
    
    for (ii=0; ii<lp[0]; ii++)
        { /* for every darray... */
        hp = (DArrayHeader FAR *) ((char FAR *) dp + lp[1+ii]); /* set hp to point at array data */
        if (nMove)
            { /* need to shift this data downwards */
            lp[1+ii] -= nMove;
            tempL = sizeof(DArrayHeader) + (hp->dAnn * hp->itemSize);
            cp = (char FAR *) (hp); /* points at data in this darray (including header) */
            TUTORblock_move(cp,cp-nMove,tempL);
            hp = (DArrayHeader FAR *) ((char FAR *) hp - nMove); /* shift header pointer to new place */
            }
        if (hp->dAnAlloc > hp->dAnn + hp->nBuff)
            { /* too much slack, compress this darray */
            nMove += (hp->dAnAlloc - hp->dAnn - hp->nBuff) * (long) hp->itemSize;
            nMove &= ~3; /* to maintain longword alignment */
            hp->dAnAlloc = hp->dAnn + hp->nBuff;
            }
        }
    
    if (nMove)
        { /* we will be downsizing the handle */
        lp[ii+1] -= nMove; /* lp[ii+1] (ii is nItems) is total handle size */
        tempL = lp[ii+1]; /* save, because we are releasing handle */
        }
    
    ReleasePtr(da);
    KillPtr(dp);
    
    if (nMove)
        { /* handle uses fewer bytes, make it smaller (now that it is unlocked) */
        TUTORset_hsize(da,tempL,TRUE);
        }

    return(0);
    }

/* ******************************************************************* */

int TUTORcompare(pa,pb,lth) /* compare two blocks of memory */
char FAR *pa; /* pointer to first area */
char FAR *pb; /* pointer to 2nd area */
long lth; /* length of areas */

{ 
    while (lth--) {
        if (*pa++ != *pb++)
            return(FALSE); /* compare failed */
    } /* while */       
    return(TRUE);

} /* TUTORcompare */

/* ******************************************************************* */

int TUTORchecksum(ptr,lth) /* check-sum a block of memory */
register char FAR *ptr;
register long lth;

{   register long ii;
    register int sum;

    sum = 0;
    for(ii=0; ii<lth; ii++) 
        sum += *ptr++;

    return(sum);

} /* TUTORchecksum */

/* ******************************************************************* */

killptr(ptr) /* set pointer to invalid value for debugging */
char FAR * FAR *ptr;

{    long testv;

    *ptr = (char FAR *)BADPOINTER;

} /* killptr */

/* ******************************************************************* */

TUTORdeferred_dealloc(ptr) /* deferred dealloc of generic pointer */
char FAR *ptr;

{
    add_deferred(DEFDEL_POINTER,HNULL,ptr);
    return(0);
    
} /* TUTORdeferred_dealloc */


/* ******************************************************************* */

TUTORdeferred_free(handle) /* deferred dealloc of generic pointer */
Memh handle;

{
    add_deferred(DEFDEL_HANDLE,handle,FARNULL);
    return(0);
    
} /* TUTORdeferred_free */

/* ******************************************************************* */

int add_deferred(type,handle,ptr) /* add to deferred delete list */
int type; /* type of object to delete */
Memh handle; /* handle on object to delete */
char FAR *ptr; /* pointer to object to delete */

{   long size; /* size of list */
    int newEntries; /* TRUE if list lengthened */
    struct DeferEntry FAR *deferP; /* pointer to deferred delete list */
    int ii; /* index in list */

    newEntries = FALSE;
    if (deferH == HNULL) { /* no list, create */
        deferA = 5; /* initialize list */
        size = deferA*sizeof(struct DeferEntry);
        deferH = TUTORhandle("defdel",size,TRUE);
    } /* deferH if */
    
    if (deferN >= deferA) { /* list full, lengthen list */
        deferA += 10;
        size = deferA*sizeof(struct DeferEntry);
        TUTORset_hsize(deferH,size,TRUE);
    } /* deferN if */
    
    deferP = (struct DeferEntry FAR *)GetPtr(deferH);
    if (newEntries) { /* list size changed, pre-zero */
        for(ii=deferN; ii<deferA; ii++) 
            deferP[ii].type = 0;
    } /* newEntries if */
    
    /* add new item to list */
    
    deferP[deferN].type = type;
    if (type == DEFDEL_HANDLE) 
        deferP[deferN++].handle = handle;
    else if (type == DEFDEL_POINTER) 
        deferP[deferN++].ptr = ptr;
        
    ReleasePtr(deferH); /* release list handle */
    return(0);
    
} /* add_deferred */

/* ******************************************************************* */

int DefDel() /* process deferred deletes */

{   struct DeferEntry FAR *deferP; /* pointer to list */
    int ii; /* index in list */

    if (deferN == 0) return(0); /* nothing to do */
    
    /* destroy all objects in list */
    
    deferP = (struct DeferEntry FAR *)GetPtr(deferH);
    for(ii=0; ii<deferN; ii++) {
        if (deferP[ii].type == DEFDEL_HANDLE) {
            TUTORfree_handle(deferP[ii].handle);
        } else if (deferP[ii].type = DEFDEL_POINTER) {
            TUTORdealloc(deferP[ii].ptr);
        } /* deferP else-if */
        deferP[ii].type = 0; /* remove from list */
    } /* for */
    ReleasePtr(deferH);
    deferN = 0; /* list is empty */
    
    /* destroy list */
    
    if (deferA > 25) { /* check if list getting large */
        TUTORfree_handle(deferH);
        deferH = deferA = 0;
    }
    
    return(0);
    
} /* DefDel */

/* ******************************************************************* */
