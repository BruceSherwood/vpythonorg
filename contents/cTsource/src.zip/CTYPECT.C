
/*
A component of the cT (TM) programming environment.
(c) Copyright 1991 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#ifndef	_ct_ctypeh_
#include "ct_ctype.h"
#endif

#ifdef ctproto
#endif /* ctproto */

/*
	Character types for ISO-8859 character set
	ksw 2/91
*/

char _ct_ctypeDummy[2] = {0,0}; /* so that if we look at _ct_type[-1] we get 0 */
char _ct_ctype[256] =
{
		0,0,0,0,0,0,0,0, /* 7 */
		0,_space_, /* 9 */
		_space_, /* 10 */
		0,0,_space_, /* 13 */
		0,0, /* 15 */
		0,0,0,0,0,0,0,0, /* 23 */
		0,0,0,0,0,0,0,0, /* 31 */
		_space_, /* 32 */
		_punct_,_punct_,_punct_,_punct_,_punct_,_punct_,_punct_, /* 39 */
		_punct_,_punct_,_punct_,_punct_,_punct_,_punct_,_punct_,_punct_, /* 47 */
		_digit_,_digit_,_digit_,_digit_, /* 51 '3' */
		_digit_,_digit_,_digit_,_digit_, /* 55 '7' */
		_digit_,_digit_,_punct_,_punct_, /* 59, ';' */
		_punct_,_punct_,_punct_,_punct_,0, /* 64 '@' */
		_alpha_,_alpha_,_alpha_, /* 67 'C' */
		_alpha_,_alpha_,_alpha_,_alpha_, /* 71 'G' */
		_alpha_,_alpha_,_alpha_,_alpha_, /* 75 'K' */
		_alpha_,_alpha_,_alpha_,_alpha_, /* 79 'O' */
		_alpha_,_alpha_,_alpha_,_alpha_, /* 83 'S' */
		_alpha_,_alpha_,_alpha_,_alpha_, /* 87 'W' */
		_alpha_,_alpha_,_alpha_, /* 90 'Z' */
		_punct_,_punct_,_punct_,0,_punct_,_punct_, /* 96 '`' */
		_alpha_,_alpha_,_alpha_, /* 99 'c' */
		_alpha_,_alpha_,_alpha_,_alpha_, /* 103 'g' */
		_alpha_,_alpha_,_alpha_,_alpha_, /* 107 'k' */
		_alpha_,_alpha_,_alpha_,_alpha_, /* 111 'o' */
		_alpha_,_alpha_,_alpha_,_alpha_, /* 115 's' */
		_alpha_,_alpha_,_alpha_,_alpha_, /* 119 'w' */
		_alpha_,_alpha_,_alpha_, /* 122 'z' */
		_punct_,_punct_,_punct_,_punct_,0,	/* 127 (0x7f) */
		0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
		0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0, /* 0x9f */
		_space_, /* 0xa0 */
		_punct_,_punct_,_punct_,_punct_,_punct_,_punct_,_punct_, /* 0xa7 */
		_punct_,0,0,0,0,_punct_,0,0, /* 0xaf */
		0,0,0,0,_punct_,0,0,0, /* 0xb7 */
		0,0,0,0,0,0,0,_punct_, /* 0xbf */
		_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_, /* 0xc7 */
		_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_, /* 0xcf */
		_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,0, /* 0xd7 */
		_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_, /* 0xdf */
		_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_, /* 0xe7 */
		_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_, /* 0xef */
		_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,0, /* 0xf7 */
		_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_,_alpha_ /* 0xff */
};

