
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* ******************************************************** */

	/* code generation subroutines for SUN-3 */

#ifdef MACtst
#define sun3f 0
#else
#ifdef sunzzzz
#define sun3f 1
#else
#define sun3f 0
#endif
#endif

#if sun3f	/* compile for Sun-3 unless MACtst */

#include "compile.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "compute.h"
#include "tglobals.h"

#define nindr 6 	/* number array indexes allowed to register */

#define regtl 33	/* size of register reservation table */
			/* last slot in table must always be unused */

#define regx 0		/* unuseable register */
#define rega 1		/* subroutine argument/return/internal register */
#define regw 2		/* general working register */
#define regf 3		/* floating point register */

#ifdef ctproto
extern int InitExpressionTable(struct exprt FAR *xt);
#endif

extern long lowcore();	/* low-memory routines */
extern long lciresult();
extern double lcfresult();
extern long lcloop();
extern long lcftoi();
extern long lcflt();
extern long lcfgt();
extern long lcfle();
extern long lcfge();
extern long lcfeq();
extern long lcfne();	
extern long lclt();
extern long lcgt();
extern long lcle();
extern long lcge();
extern long lceq();
extern long lcne();	
extern long lcimult();
extern long lclshf();
extern long lcrshf();
extern long lcunion();
extern long lcmask();
extern long lcdiff();
extern long lcidivr();
extern long lcidivt();
extern long lccomp();
extern long lcbitcnt();
extern double lcitof();
extern double lcfadd();
extern double lcfsub();
extern double lcfmult();
extern double lcfdiv();
extern double lcfumin();
extern double lcsin();
extern double lccos();
extern double lctan();
extern double lccsc();
extern double lcsec();
extern double lccot();
extern double lcfexpon();
extern double lcfexpic();
extern double lcarcsin();
extern double lcarccos();
extern double lcarccsc();
extern double lcarcsec();
extern double lcarccot();
extern double lcsqrt();
extern double lcabs();
extern double lcexp();
extern double lclog();
extern double lcalog();
extern double lcln();
extern double lcsinh();
extern double lccosh();
extern double lctanh();
extern double lcgamma();
extern double lcfsysv();
extern long lcint();
extern double lcfrac();
extern long lcsign();
extern long lcerr();

extern long apadd();	/* assembly language routines */
extern long apsub();
extern long apmult();
extern long apdiv();

static short regtyp[regtl];	/* physical register usage type */
static int regrsv[regtl];	/* register reservation table */
static short reguse[regtl];	/* register used flags */
static int regtrack[regtl];	/* last use of register */

static long slasta;	/* address of store-able operand */
static int slastk;	/* local/global int/float type of store-able operand */
static int slastt;	/* TFLOAT, TINT, TBYTE type of store-able operand */

static int globalr;	/* TRUE if pointer to globals in register */
static int localr;	/* TRUE if pointer to locals in register */
static long aerrorc;	/* address of array bounds error exit call */
static int ifcode;	/* begin of expression code (ICODE or FCODE) */
static int codep;	/* index to expression type byte of compiled code */
static int codeb;	/* index to length field of compiled code */
static int prevret;	/* index to previous rts instruction */
static int genloopi = FALSE;	/* genloop(0) called - setup registers appropriately */

/* ******************************************************************* */

machcod()

	/* generate compiled code for Sun-2/Sun-3 68000/68020 */

{	register int is; 	/* index in token stack */
	register struct xtoken *t;	/* pointer to current token */
	int ia,ib;	/* index of argument tokens */
	int opc, iac, ibc;	/* op, arg1, arg2 codes */
	int ar,br,rr,tr;	/* arg1, arg2, result, temporary registers */
	int codel;	/* length of compiled code */
	int ploc;	/* relative location in code */
	int nt, pt;	/* index of next/previous tokens */
	int aaf;	/* array assign flag */
	int iaa;	/* index of token being assigned */
	int dim;	/* number array dimensions */
	long abase;	/* base address of array */
	int asize;	/* size of array elements */
	long amaxl;	/* maximum length of array */
	long alength;	/* array length (by dimension) */
	long alower;	/* array lower bound (by dimension) */
	long aclth;	/* accumulated length of array */
	long aindex;	/* current (accumulated) index in array */
	int aaddrf;	/* TRUE if array address, FALSE if value */
	int larrayi;	/* index of last array reference (for store-ability) */
	int air[nindr];	/* array index registers */
	long *pd;	/* pointer to array description info */
	int removed;	/* number bytes removed for appended expression */
	int i,j;	/* work variables */
	long lv;
	char c;
	unsigned char *ucp;

	/* make register assignments for compiled code */

if (!pgen) {
	for (i=0; i<regtl; i++) { /* initialize register tables */
		regrsv[i] = 0;
		regtrack[i] = 0;
		reguse[i] = FALSE;
	} /* for */
	slasta = -1;	/* no storeable operand yet */

	is = 0;	/* initialize index */
	topw = 0;	/* initialize stack */
	ploc = 0;	/* initialize relative location */
	larrayi = 0;	/* initialize index of last array reference */
	t = &xtokd[is];
	while (!xt[t->code].endop) {

		/* chain forward to next operator/operand */

		is = xtokd[is].nextt;	/* link to next token in chain */
		t = &xtokd[is];
		opc = t->code;		/* get operator code */
		t->loc = (++ploc);	/* set logical order */
		xtokd[is].result = tundef;	/* pre-set result undefined */
		if (!xt[opc].cgen) pgen = TRUE;	/* cant generate compiled code */
	
		/* process operand */

		if (!t->opad)  {

			/* process indexed array */

			if (xt[opc].array == 1) {
				larrayi = is;	/* save index of array reference */
				for (i=0; i<nindr; i++) air[i] = tundef; /* no registers yet */
				
				/* pick up array dimensions */

				if (tstga(opc)) dim = (long)unit[0].descriptors[t->ivalue+3];
				else dim = (long)unit[compunit].descriptors[t->ivalue+3];

				/* pop operand being assigned to indexed array */

				aaf = tstaa(opc);
				if (aaf)  {
					iaa = popw();		/* pop operand */
					if ((opc == GARRAYADDR) || (opc == LARRAYADDR))
						xtokd[iaa].result = 10;
					else {
						ar = asgreg(iaa); /* assign to register */
						relreg(ar);
						if (ar < 0) 
							xtokd[iaa].result = 10; /* to a2 */
					} /* not-float if */
				} /* array assign if */

				/* pop array indexes from working stack */

				for (i=1; i<=dim; i++) {
					ia = popw();
					j = dim-i;
					if (j<nindr) {
						if ((i == 1) && (!aaf)) air[j] = fixreg(ia,1);
						else air[j] = asgreg(ia); /* index to reg */
						xtokd[ia].result = air[j];
					} else
						xtokd[ia].result = tonstk; /* index to stack */
				} /* for */
				for (i=0; i<nindr; i++) relreg(air[i]);	/* release registers */

				/* restore operand being assigned to indexed array */

				if (aaf) pushw(iaa); /* push operand back on stack */

			} /* array if */

			pushw(is); /* push result operand on working stack */

		} /* operand if */
 
		/* process operator */

		else {

			/* process unary operator */

			if (xt[opc].unary) {
				ia = popw();	/* pop operand from working stack */
				iac = xtokd[ia].code;
				if (xt[opc].rr) {	/* process register operator */
					if ((opc == ENDI) || (opc == ENDF)) {
						xtokd[is].result = 0;	/* result = d0 */
						xtokd[ia].result = 0;
					} else {
						if (xt[iac].subr) 
							xtokd[ia].result = 0; /* opr in d0 */
						ar = asgreg(ia); /* to reg if not in d0 */
						relreg(ar);
					} /* ENDI else */
				} /* register if */
				else stkop(ia);	/* stack operand */
			} /* unary if */

			/* process binary operator */

			else {
				ib = popw();	/* pop 2nd operand from working stack */
				ibc = xtokd[ib].code;
				ia = popw();	/* pop 1st operand from working stack */
				iac = xtokd[ia].code;
				if (xt[opc].rr){
					if ((opc == IASSIGN) || (opc == BASSIGN)) {
						xtokd[ib].result = 8; /* addr opr to a0 */
						ar = asgreg(ia); /* assign to register */
						relreg(ar);
						if (srmod(ar)) xtokd[ia].result = 10;	/* result to a2 */
					} /* assign if */
					else {
						ar = asgreg(ia); /* assign operand to reg */
						if (xt[ibc].subr) 
							xtokd[ib].result = 0; /* opr in d0 */
						br = asgreg(ib); /* to reg if not in d0 */
						relreg(ar);
						relreg(br);
					} /* assign else */
				} /* all register if */
				else if (opc == ASSIGN) {
					xtokd[ib].result = 8; /* assign address opr to a0 */
					if (xtokd[ia].result == tundef)
						xtokd[ia].result = tonstk; /* value to stack */
				} /* assign if */
				else {
					stkop(ia); /* stack operands */
					stkop(ib);
				} /* not-register else */
			} /* binary else */

			pushw(is); /* push result operand on working stack */

		} /* operator else */

	};  /* while */
	exprmsg("after register\n"); dmpexpr();

} /* not-pgen if */

/* ------------------------------------------------------------------------------ */

	/* generate machine instructions */

	if (!pgen) {
		is = 0;	/* initialize index */
		topw = 0;	/* initialize working stack */
		reguse[12] = reguse[13] = TRUE;	/* a4, a5 used */
		t = &xtokd[0];

		/* initialize for first of multiple expressions */

		if (cmp->multiple == 1) {
			multei = 0; /* init index */
			cmp->multcode = TRUE; /* all compiled so far */
		} /* multiple if */

		/* process continued -calc- and multiple expressions */

		if ((cmp->multiple > 1) && (cmp->multcode))
			cmp->apprev = TRUE; /* can append if multiple, compiled */
		if (cmp->apprev && ((cmpl-codep) > 16000))
			cmp->apprev = FALSE; /* limit code size */

		if (cmp->apprev) {
			removed = cmpl-prevret; /* number bytes removed */
			cmpl = prevret; /* re-set to remove previous return */
			                /* and new -calc- command */
			ifcode = ((endopc == ENDI)? ICODE: FCODE);
			if (cmp->calc || cmp->multiple) ifcode = ICODE;
			plantbyte(ifcode,(long)(codep));
		} else {

			/* add compiled code flag, insure code starts on word boundary */

			codep = cmpl; /* start of expression */
			ifcode = ((endopc == ENDI)? ICODE: FCODE);
			if (cmp->calc || cmp->multiple) ifcode = ICODE;
			addbyte(ifcode);
			if  (cmpl & 1) addbyte(0);	/* force word boundary */
			codeb = cmpl;		/* save pointer to length */
			addbyte(0);		/* reserve space for code length */
			addbyte(0);
			aerrorc = 0;	/* address of call to array error exit */
			globalr = localr = FALSE; /* pointers not in register */
		} /* not continued else */

		if (cmp->apprev || cmp->apnext || cmp->calc || cmp->multiple || genloopi) {
			genloopi = FALSE; /* turn off special set-up flag */
			stdregs(); /* assume all registers used */
		} 

		if (!cmp->apprev) genbegin();

		/* if appended code generate code to update cmdloc */
		/* in case of exec error */

		if (cmp->apprev && (cmp->multiple == 0)) {

			/* generate code to set cmdloc in case exec err */

			genmovl(5,5,1,1); /* move.l  k(a5),a1 */
			addint2(PCMDLOC*sizeof(struct exprt));
			genmovl(4,7,1,2); /* move.l  #k,(a1) */
			if (cmpl <= (prevret+removed)) lv = prevret+removed+1;
			else lv = cmpl; /* insure bias in this command, not prev */
			addint4(lv);
		} /* appended if */

		/* generate code for each operator/operand */

		while (!xt[t->code].endop) {

			/* chain forward to next operator/operand */

			is = xtokd[is].nextt;	/* link to next token in chain */
			t = &xtokd[is];
			opc = t->code;		/* get operator code */
			tr = rr = t->result;	/* get result register */
			
			/* process operand */

			if (!t->opad)  {

				/* process indexed array */

				if (xt[opc].array == 1) {
				
					/* pick up array description */
	
					if (tstga(opc)) pd = unit[0].descriptors+t->ivalue;
					else pd = unit[compunit].descriptors+t->ivalue;
					asize = siza(opc);	/* size of array elements */
					abase = (*pd)+4; /* base address of array */
					amaxl = *(pd+1); /* total length of array */
					pd += 3;
					dim = (int)(*pd); /* get number dimensions */
					pd = pd+(dim*2); /* advance to end of dimensions */
				} /* array if  */
			} /* operand if */
 
			/* process operator */

			else {

				/* process unary operator */

				if (xt[opc].unary) {
					ia = popw();	/* pop operand from working stack */
					ar = xtokd[ia].result;	/* get operand register */
					if (xt[opc].rr) {
						if (srmod(tr)) tr = 0;	/* result to d0 */
						if (srmod(ar)) 
							ar = genopwr(ar,0); /* operand to d0 */
					} /* register if */
				} /* unary if */

				/* process binary operator */

				else {
					ib = popw(); /* pop 2nd op from working stack */
					ia = popw(); /* pop 1st op from working stack */
 					ar = xtokd[ia].result; /* get 1st operand reg */
					br = xtokd[ib].result; /* get 2nd operand reg */
					if (xt[opc].rr) {
						if ((opc == IASSIGN) || (opc == BASSIGN)){
							if (br != 8) br = genopwr(br,8); /* operand to a0 */
							if (srmod(ar)) genopwr(ar,0); /* operand to reg */
						} else {
							if (srmod(ar)) ar = genopwr(ar,0);	/* opr to reg */
							if (srmod(br)) br = genopwr(br,1);	/* opr to reg */
						} /* else */
					} /* all register if */
					else if (opc == ASSIGN) {
						if (br != 8) br = genopwr(br,8); /* operand to a0 */
					} /* assign else if */
				} /* binary else */

			} /* operator else */

			switch (opc) {

			case ENDI:
			case ENDM:
			if (cmp->calc) {
				; /* nothing to do */
			} else if (cmp->multiple) {
				if (cmp->reqstore) {
					if (ar != tonstk) /* move.l  rr,-(sp) */
						genmovl(prnum(ar),srmod(ar),7,4); 
				} else if (srmod(ar) || (prnum(ar))) /* move.l rr,d0 */
					genmovl(prnum(ar),srmod(ar),prnum(0),drmod(0));
			} else if (srmod(ar) || (prnum(ar)))
				genmovl(prnum(ar),srmod(ar),prnum(0),drmod(0));
			tr = rr = 0; /* result in d0 */
			break;

			case ENDF:
			if (cmp->calc && rr) {
				addbyte(0x4f); /* lea  sp@(8),sp */
				addbyte(0xef);
				addint2(8);
			} else if (cmp->multiple) {
				if (cmp->reqstore) {
					if (ar != tonstk) {
						/* move.l d1,-(sp) */
						genmovl(prnum(ar+1),srmod(ar),7,4); 
						/* move.l d0,-(sp) */
						genmovl(prnum(ar),srmod(ar),7,4);
					} /* ar if */
				} else if (rr) {
					genmovl(7,3,0,0); /* move.l  sp@+,d0 */
					genmovl(7,3,1,0); /* move.l  sp@+,d1 */
				} /* rr else-if */			
			} else if (rr) {
				genmovl(7,3,0,0); /* move.l  sp@+,d0 */
				genmovl(7,3,1,0); /* move.l  sp@+,d1 */
			} /* multiple else */
			tr = rr = 0; /* result in d0 */
			break;

			case ILITERAL:
			genmovl(4,7,prnum(rr),drmod(rr)); /* move.l  #k,r */
			addint4(t->ivalue);	/* add literal value */
			break;

			case FLITERAL:
			ar = ((rr == tonstk) ? tonstk: rr+1);
			genmovl(4,7,prnum(ar),drmod(ar)); /* move.l  #k,rr or sp@- */
			ucp = (unsigned char *) &t->fvalue; /* set pointer to floating value */
			ucp = ucp+4;
			for (i=1; i<=4; i++) addbyte(*ucp++); /* add least significant part */
			genmovl(4,7,prnum(rr),drmod(rr)); /* move.l  #k,rr or sp@- */
			ucp = (unsigned char *) &t->fvalue;
			for (i=1; i<=4; i++) 
				addbyte(*ucp++); /* add most significant part */
			break;

			case GLOBALVAL:
			setlasta(t->ivalue,PVGLOBALF,TFLOAT);
			ar = ((rr == tonstk) ? tonstk: rr+1);
			genga0(t->ivalue); /* get address to a0 */
 			/* move.l  4(a0),rr or sp@- */
			genmovl(0,5,prnum(ar),drmod(ar));
			addint2(4); /* add displacement */
			/* move.l  (a0),rr or sp@- */
			genmovl(0,2,prnum(rr),drmod(rr)); 
			break;

			case IGLOBALVAL:
			setlasta(t->ivalue,PVGLOBALI,TINT);
			gengp(); /* set pointer to globals */
			if (t->ivalue <= 0x7fff) {
				/* move.l  k(a4),r */
				genmovl(4,5,prnum(rr),drmod(rr)); 
				addint2((int)(t->ivalue)); /* add disp wd */
			} else {
				genmovl(4,7,0,1); /* move.l  #k,a0 */
				addint4(t->ivalue); /* add displacement value */
				genroe(13,0,7,4,1); /* adda.l  a4,a0 */
				/* move.l  (a0),r */
				genmovl(0,2,prnum(rr),drmod(rr)); 
			} /* long address else */
			break;

			case BGLOBALVAL:
			setlasta(t->ivalue,PVGLOBALB,TBYTE);
			gengp();	/* set pointer to globals */
			if (srmod(tr) != 0) tr = 0;	/* use d0 if result not register */
			addbyte(0x42);	/* clr.l  r */
			addbyte(0x80+prnum(tr));
			if (t->ivalue <= 0x7fff) {
				/* move.b  k(a4),r */
				genmovb(4,5,prnum(tr),drmod(tr));
				addint2((int)(t->ivalue)); /* add disp wd */
			} else {
				genmovl(4,7,0,1); /* move.l  #k,a0 */
				addint4(t->ivalue); /* add displacement value */
				genroe(13,0,7,4,1); /* adda.l  a4,a0 */
				/* move.b  (a0),r */
				genmovb(0,2,prnum(tr),drmod(tr));	
			} /* long address else */
			break;

			case GLOBALADDR:
			case IGLOBALADDR:
			case BGLOBALADDR:
			if (opc == GLOBALADDR) { i = PVGLOBALF; j = TFLOAT; }
			else if (opc == IGLOBALADDR) { i = PVGLOBALI; j= TINT; }
			else { i = PVGLOBALB; j = TBYTE; }
			setlasta(t->ivalue,i,j);
			genga0(t->ivalue);		/* get address to a0 */
			tr = 8;	/* result in a0 */
			break;

			case LOCALVAL:
			setlasta(t->ivalue,PVLOCALF,TFLOAT);
			genla0(t->ivalue);	/* get address to a0 */
			ar = ((rr == tonstk) ? tonstk: rr+1);
			/* move.l  4(a0),rr or sp@- */
			genmovl(0,5,prnum(ar),drmod(ar));	
			addint2(4); /* add displacement */
			/* move.l  (a0),rr or sp@- */
			genmovl(0,2,prnum(rr),drmod(rr));
			break;

			case ILOCALVAL:
			setlasta(t->ivalue,PVLOCALI,TINT);
			genlp();	/* set pointer to locals */
			if (t->ivalue <= 0x7fff) {
				/* move.l  k(a4),r */
				genmovl(4,5,prnum(rr),drmod(rr)); 
				/* add displacement word */
				addint2((int)(t->ivalue));		
			} else {
				genmovl(4,7,0,1);	/* move.l  #k,a0 */
				addint4(t->ivalue); /* add displacement value */
				genroe(13,0,7,4,1);	/* adda.l  a4,a0 */
				/* move.l  (a0),r */
				genmovl(0,2,prnum(rr),drmod(rr));	
			} /* long address else */
			break;

			case BLOCALVAL:
			if (srmod(tr) != 0) tr = 0; /* use d0 if result not reg */
			setlasta(t->ivalue,PVLOCALB,TBYTE);
			genlp();	/* set pointer to locals */
			addbyte(0x42);	/* clr.l  r */
			addbyte(0x80+prnum(tr));
			if (t->ivalue <= 0x7fff) {
				/* move.b  k(a4),r */
				genmovb(4,5,prnum(tr),drmod(tr));
				/* add displacement word */	
				addint2((int)(t->ivalue));		
			} else {
				genla0(t->ivalue); /* get address to a0 */
				/* move.b  (a0),r */
				genmovb(0,2,prnum(tr),drmod(tr));	
			} /* long address else */
			break;

			case LOCALADDR:
			setlasta(t->ivalue,PVLOCALF,TFLOAT);
			genla0(t->ivalue);	/* load address to a0 */
			tr = 8;		/* result in a0 */
			break;

			case ILOCALADDR:
			setlasta(t->ivalue,PVLOCALI,TINT);
			genla0(t->ivalue);	/* load address to a0 */
			tr = 8;		/* result in a0 */
			break;

			case BLOCALADDR:
			setlasta(t->ivalue,PVLOCALB,TBYTE);
			genla0(t->ivalue);	/* load address to a0 */
			tr = 8;		/* result in a0 */
			break;

			case GARRAYVAL:
			case GARRAYADDR:
			case IGARRAYVAL:
			case IGARRAYADDR:
			case BGARRAYVAL:
			case BGARRAYADDR:
			case LARRAYVAL:
			case LARRAYADDR:
			case ILARRAYVAL:
			case ILARRAYADDR:
			case BLARRAYVAL:
			case BLARRAYADDR:

			/* set up store-ablilty info */

			slasta = -1;	/* turn off final lastaddr/lastkind */
			if ((opc == GARRAYVAL) || (opc == GARRAYADDR))
				{ slastk = PVGLOBALF; slastt = TFLOAT; }
			else if ((opc == IGARRAYVAL) || (opc == IGARRAYADDR))
				{ slastk = PVGLOBALI; slastt = TINT; }
			else if ((opc == BGARRAYVAL) || (opc == BGARRAYADDR))
				{ slastk = PVGLOBALB; slastt = TBYTE; }
			else if ((opc == LARRAYVAL) || (opc == LARRAYADDR))
				{ slastk = PVLOCALF; slastt = TFLOAT; }
			else if ((opc == ILARRAYVAL) || (opc == ILARRAYADDR))
				{ slastk = PVLOCALI; slastt = TINT; }
			else if ((opc == BLARRAYVAL) || (opc == BLARRAYADDR))
				{ slastk = PVLOCALB; slastt = TBYTE; }

			/* check for assignment to array */

			aaddrf = tstaa(opc); /* TRUE if address */
			if (aaddrf) iaa = popw(); /* pop operand being assigned */

			/* generate code to compute index into array */

			aclth = 1;		/* accumulated length */
			for (i=1; i<=dim; i++) {
				ia = popw();	/* pop next index from working stack */
				ar = xtokd[ia].result;
				if (srmod(ar) || ((i == 1) && (ar != 1))) {
					/* use d1 1st time, d0 afterwards */
					j = ((i == 1) ? 1: 0);	
					/* move.l  an or sp@+,dj */
					genmovl(prnum(ar),srmod(ar),j,0);	
				} else j = ar;
				alength = *(pd--);	/* lth this dimension */
				alower = *(pd--);	/* lower bound */

				if (alower == 1) {
					addbyte(0x53);	/* subq.l  #1,dj */
					addbyte(0x80+j);
				} else {
					addbyte(0x04);	/* subi.l  #k,dj */
					addbyte(0x80+j);
					addint4(alower);
				} /* lower else */
				addbyte(0x6b);		/* bmi  *+8 or *-k */
				if (aerrorc == 0) addbyte(8);
				else {
					lv = (cmpl+1)-aerrorc;
					/* short displacement */
					if (lv < 127) addbyte(-lv);
					/* long displacement */		
					else {
						addbyte(0);			
						addbyte(((-lv) >> 8) & 0xff);
						addbyte(-lv);
					} /* <127 else */
				} /* aerrorc else */
				addbyte(0x0c); /* cmpi  #k,dj */
				addbyte(0x80+j);
				addint4(alength);
				if (aerrorc == 0) {
					addbyte(0x6b); /* bmi  *+12 */
					addbyte(12);
					aerrorc = cmpl;
					genmovl(4,7,7,4); /* move.l  #k,sp@- */
					/* 1 = array bounds error */
					addint4((long)(1));
					gensubr(PCALCE);
				} else {
					addbyte(0x6a); /* bpl *-k */
					lv = (cmpl+1)-aerrorc;
					/* short displacement */
					if (lv < 127) addbyte(-lv);
					/* long displacement */
					else {
						addbyte(0);
						addbyte(((-lv) >> 8) & 0xff);
						addbyte(-lv);
					} /* <127 else */
				} /* aerrorc else */
				if (i != 1) {
#ifdef mc68020
					addbyte(0x4c);	/* mulul #k,dj */
					addbyte(0x3c);
					addbyte(j << 4);
					addbyte(0);
					addint4(aclth);
					genroe(13,1,2,j,0); /* add.l  dj,d1 */
#else
					genmovl(1,0,7,4); /* move.l  d1,sp@- */
					genmovl(j,0,7,4); /* move.l  dj,sp@- */
					genmovl(4,7,0,0); /* move.l  #k,d0 */
					addint4(aclth);		
					genmovl(0,0,7,4); /* move.l  d0,sp@- */
					gensubr(ITIMES); /* jsr  multiply */
							/* lea  sp@(k),sp */
					genmovl(7,3,1,0); /* move.l  sp@+,d1 */
					genroe(13,1,2,0,0); /* add.l  d0,d1 */
#endif
				} /* 1st index else */
				aclth = aclth*alength;
			} /* for */

			/* generate code to set arrayitems for store-ability */

			if ((cmp->canstore) && (cmp->reqstore) && (is == larrayi)) {
				genmovl(4,7,0,0); /* move.l  #k,d0 */
				addint4(amaxl);
				genroe(0x09,0,2,1,0); /* sub.l  d1,d0 */
				genmovl(5,5,0,1); /* move.l  k(a5),a0 */
				addint2(PARRAYI*sizeof(struct exprt)); 
				genmovl(0,0,0,2); /* move.l  d0,(a0) */
			} /* store-able if */

			/* generate code to form absolute address and load value */

			/* get global or local base address to a0 */
			if (tstga(opc)) genga0(abase);	
			else genla0(abase);
			if (aaddrf) tr = 8;	/* result in a0 if address */
			if (asize == 8) {
				addbyte(0xe7); /* lsl.l  #3,d1 */
				addbyte(0x89);
				genroe(0xd,0,7,1,0); /* add.l  d1,a0 */
				if (!aaddrf) {
					if (rr == tonstk) {
						/* move.l  4(a0),sp@- */
						genmovl(0,5,7,4); 
						addint2(4); /* add displacement */
						/* move.l  (a0),sp@- */
						genmovl(0,2,7,4);	
						tr = tonstk;
					} else {
						/* move.l  4(a0),d1 */
						genmovl(0,5,1,0);	
						addint2(4); /* add displacement */
						/* move.l  (a0),d0 */
						genmovl(0,2,0,0);	
						tr = 0;
					} /* not-stack else */
				} /* value if */
			} else if (asize == 4) {
				addbyte(0xe5); /* lsl.l  #2,d1 */
				addbyte(0x89);
				genroe(0xd,0,7,1,0); /* add.l  d1,a0 */
				/* move.l  (a0),tr */
				if (!aaddrf) genmovl(0,2,prnum(tr),drmod(tr));	
			} else {
				genroe(0xd,0,7,1,0); /* add.l  d1,a0 */
				if (!aaddrf) {
					/* to d0 if not reg */
					if (drmod(tr)) tr = 0; 
					addbyte(0x42);	/* clr.l  tr */
					addbyte(0x80+tr);
					/* move.b  (a0),tr */
					genmovb(0,2,prnum(tr),drmod(tr));
				} /* value if */
			} /* size else */

			/* generate code to set lastaddr, lastkind for store-info */

			if ((cmp->canstore) && (cmp->reqstore) && (is == larrayi)) {
				genmovl(5,5,1,1); /* move.l  k(a5),a1 */
				addint2(PLASTK*sizeof(struct exprt)); 
				genmovw(4,7,1,2);	/* move.w #k,(a1) */
				addint2((int)(slastt));
				genmovl(5,5,1,1); /* move.l  k(a5),a1 */
				addint2(PLASTA*sizeof(struct exprt)); 
				genmovl(0,1,1,2);	/* move.l  a0,(a1) */
			} /* store-able if */

			/* restore operand being assigned to indexed array */

			if (aaddrf) pushw(iaa);	/* push operand back on stack */
			break;

			case IPLUS:
			genroe(13,prnum(ar),2,prnum(br),srmod(br));
			tr = ar;	/* result in arg 1 register */
			break;

			case IINC:
			addbyte(0x52);	/* addq.l  #1,r */
			addbyte(0x80+(drmod(ar) << 3)+prnum(ar));
			tr = ar;	/* result in arg 1 register */
			break;

			case IMINUS:
			genroe(9,prnum(ar),2,prnum(br),srmod(br));
			tr = ar;	/* result in arg 1 register */
			break;

			case IDEC:
			addbyte(0x53);	/* subq.l  #1,r */
			addbyte(0x80+(drmod(ar) << 3)+prnum(ar));
			tr = ar;	/* result in arg 1 register */
			break;

			case IUMINUS:
			addbyte(0x44);	/* neg.l  r */
			addbyte(0x80+prnum(ar));
			tr = ar;	/* result in arg 1 register */
			break;

			case ITIMES:
#ifdef mc68020
			addbyte(0x4c);	/* mulsl br,ar */
			addbyte(br);
			addbyte((ar << 4)+0x8);
			addbyte(0);
			tr = ar;	/* result in arg 1 register */
#else
			gensubr(opc);	/* jsr  subr */
					/* lea  sp@(k),sp */
			tr = 0;	/* result in d0 */	
#endif
			break;

			case LSHIFT:
			addbyte(0xe1+(br << 1));	/* lsl.l  ar,br */
			addbyte(0xa8+ar);
			tr = ar;	/* result in arg 1 register */
			break;

			case RSHIFT:
			addbyte(0xe0+(br << 1));	/* lsr.l  ar,br */
			addbyte(0xa8+ar);
			tr = ar;	/* result in arg 1 register */
			break;

			case COMP:
			addbyte(0x46);			/* not.l  ar */
			addbyte(0x80+ar);
			tr = ar;	/* result in arg 1 register */
			break;

			case LMASK:
			genroe(0xc,ar,2,prnum(br),srmod(br));	/* and.l  br,ar */
			tr = ar;	/* result in arg 1 register */
			break;

			case LUNION:
			genroe(0x8,ar,2,prnum(br),srmod(br));	/* or.l  br,ar */
			tr = ar;	/* result in arg 1 register */
			break;

			case LDIFF:
			genroe(0xb,br,6,prnum(ar),srmod(ar));	/* eor.l  br,ar */
			tr = ar;	/* result in arg 1 register */
			break;

			case FTOI:
			gensubr(opc);	/* jsr  subr */
					/* lea  sp@(k),sp */
			tr = 0;	/* result in d0 */
			if (rr == tonstk) {
				genmovl(0,0,7,4);	/* move.l  d0,a7@- */
				tr = tonstk;	/* result on stack */
			} /* stack if */
			break;

			case ASSIGN:
			if (ar == tonstk) {
				genmovl(7,2,0,3);	/* move.l  sp@,(a0)+ */
				genmovl(7,5,0,2);	/* move.l  sp@(4),(a0) */
				addint2(4);
				tr = tonstk;	/* result on stack */
			} /* on stack if */
			else {
				/* move.l  dn,(a0)+ */
				genmovl(prnum(ar),srmod(ar),0,3);
				/* move.l  dn+1,(a0) */		
				genmovl(prnum(ar+1),srmod(ar),0,2);	
				tr = ar;	/* result in register */
			} /* not-stack else */
			break;

			case IASSIGN:
			genmovl(prnum(ar),srmod(ar),0,2); /* move.l  ra,(a0) */
			tr = ar;	/* result in arg 1 register */
			break;

			case BASSIGN:
			genmovb(prnum(ar),srmod(ar),0,2); /* move.b  ra,(a0) */
			tr = ar;	/* result in arg 1 register */
			break;

			case EXPONIC:
			case SYSVAR:
			genmovl(4,7,7,4); /* move.l  #k,sp@- */
			addint4(t->ivalue); /* add literal value */
			gensubr(opc); /* call subroutine */
			tr = 0;	/* result in d0 */
			break;

			case IEQ:
			case INE:
			case IGT:
			case ILT:
			case IGE:
			case ILE:
			if (srmod(tr)) tr = 0; /* result to d0 if not register */
			/* sub.l  br,ar */
			genroe(9,prnum(ar),2,prnum(br),srmod(br));
			if (opc == IEQ) addbyte(0x67); /* beq  *+4 */
			else if (opc == INE) addbyte(0x66); /* bne  *+4 */
			else if (opc == IGT) addbyte(0x6e); /* bgt  *+4 */
			else if (opc == ILT) addbyte(0x6d); /* blt  *+4 */
			else if (opc == IGE) addbyte(0x6c); /* blt  *+4 */
			else if (opc == ILE) addbyte(0x6f); /* ble  *+4 */
			addbyte(0x04);
			addbyte(0x42); /* clr.l  tr */
			addbyte(0x80+prnum(tr));
			addbyte(0x60); /* bra  *+6 */
			addbyte(0x06);
			genmovl(4,7,prnum(tr),srmod(tr)); /* move.l  #-1,tr */
			addint4((long)(-1));
			break;

			case PLUS:
			case MINUS:
			case TIMES:
			case DIVIDE: 
			case UMINUS:
			case SIGN:
			case EXPONENT:
			case IDIVR:
			case IDIVT:
			case BITCNT:
			case ITOF:
			case INT:
			case FRAC:
			case ROUND:
			case EQ:
			case NE:
			case GT:
			case LT:
			case GE:
			case LE:
			gensubr(opc);	/* jsr  subr */
					/* lea  sp@(k),sp */
			tr = 0;	/* result in d0 */
			break;

			case FFUNCT:
			gensubr(t->ivalue+256); /* jsr  subr */
			                        /* lea  sp@(k),sp */
			tr = 0;	/* result in d0 */
			break;

			default:
			printf("compile/codegen - unrecognized op %d\n",opc);
			break;

			} /* switch */
			
			/* transfer result register if neccessary */

			if ((prnum(rr) != prnum(tr)) || (srmod(rr) != srmod(tr))) {
				if (tr == tonstk) {
					genmovl(prnum(tr),srmod(tr),prnum(rr),drmod(rr));	
					if (xt[opc].trel == TFLOAT)
						genmovl(prnum(tr),srmod(tr),prnum(rr+1),drmod(rr));
				} /* from stack if */
				else {
					if (xt[opc].trel == TFLOAT) {
						j = ((rr == tonstk) ? tonstk: rr+1);
						genmovl(prnum(tr+1),srmod(tr),prnum(j),drmod(j));
					} /* float if */
					genmovl(prnum(tr),srmod(tr),prnum(rr),drmod(rr));	
				} /* from stack else */
			} /* not in right place if */

			pushw(is);	/* push result back on working stack */

		};  /* while */

		/* generate code to set lastaddr/lastkind for store-ability */

		if ((cmp->canstore) && (cmp->reqstore) && (slasta >= 0)) {
			if (narrayi) {
				genmovl(5,5,1,1); /* move.l  k(a5),a1 */
				addint2(PARRAYI*sizeof(struct exprt)); 
				genmovl(4,7,1,2); /* move.l  #k,(a1) */
				addint4(narrayi);
			} /* array storeable if */
			genmovl(5,5,1,1); /* move.l  k(a5),a1 */
			addint2(PLASTK*sizeof(struct exprt)); 
			genmovw(4,7,1,2);	/* move.w #k,(a1) */
			addint2((int)(slastt));
       			if ((slastk==PVGLOBALF) || (slastk==PVGLOBALI) ||
			   (slastk==PVGLOBALB)) genga0(slasta);
			else genla0(slasta);
			genmovl(5,5,1,1); /* move.l  k(a5),a1 */
			addint2(PLASTA*sizeof(struct exprt)); 
			genmovl(0,1,1,2); /* move.l  a0,(a1) */
		} /* store-able if */

		/* generate call to multiple-expression subroutine */
		/* or code to build table of results */

		if (cmp->multiple) {
			if (cmp->reqstore) {
				if (cmp->multiple == 1) {
					genmovl(5,5,1,1); /* move.l  k(a5),a1 */
					addint2(PRESULTI*sizeof(struct exprt)); 
					addbyte(0x42);	/* clr.l  (a1) */
					addbyte(0x91);
				} /* initialize if */	
				if (endopc == ENDI) gensubr(ENDIM);
				else gensubr(ENDFM);
			} else {

				/* compute address of table entry */

				genmovl(5,5,1,1); /* move.l  k(a5),a1 */
				addint2(PRESULT*sizeof(struct exprt));
				i = multei*sizeof(struct evresult);
				addbyte(0x43); /* lea  (k)a1,a1 */
				addbyte(0xe9);
				addint2(i);

				/* set integer/float type */

				if (endopc == ENDI) {
					addbyte(0x42);	/* clr.l  (a1)+ */
					addbyte(0x99);
					genmovl(0,0,1,2); /* move.l  d0,(a1) */
				} else {
					genmovl(4,7,1,2); /* move.l  #k,(a1) */
					addint4(TRUE);
					genmovl(0,0,1,5); /* move.l  d0,8(a1) */
					addint2(8);
					genmovl(1,0,1,5); /* move.l  d1,12(a1) */
					addint2(12);
				} /* endopc else */

				/* update index in table */

				genmovl(5,5,1,1); /* move.l  k(a5),a1 */
				addint2(PRESULTI*sizeof(struct exprt));
				if (cmp->multiple == 1) {
					genmovl(4,7,1,2); /* move.l  #1,(a1) */
					addint4(1);
				} else {
					addbyte(0x52); /* addq.l  #1,(a1) */
					addbyte(0x91);
				} /* multiple else */
			} /* reqstore else */
		} /* multiple if */

		/* generate code to update uloc, restore registers and return */

		prevret = cmpl;	/* save for multiple expr or continued -calc- */
		if (cmp->calc) {
			genmovl(5,5,1,1); /* move.l  k(a5),a1 */
			addint2(PULOC*sizeof(struct exprt));
			genmovw(4,7,1,2); /* move.w  #k,(a1) */
			lv = cmpl;
			addint2(0); /* reserve space for uloc value */
			genret(); /* generate code to restore registers and return */
			plantint2((int)(cmpl),lv); /* plant uloc value */
		} else genret();

		/* set length of compiled code */

		codel = cmpl-(codeb+2);
		cmpbuf[codeb] = (codel >> 8) & 0xff;
		cmpbuf[codeb+1] = codel & 0xff;

		/* if multiple expression, build table */

		if (cmp->multiple) {
			multeic[multei++] = codep; /* index to begin */
		} /* multiple if */

	} /* not-pgen if */

} /* machcod */

/* ******************************************************************* */

int genloop(mode,cmdp,addr)
/* generate compiled code for -loop- and related commands*/

int mode; /*  0 = initializations */
          /* +n = command number, cmdp assumed valid */
long cmdp; /* starting position of command */
long addr; /* -outloop- loop exit address */

{	long brptr; /* position of branch displacement */
	long brptr1, brptr2, brptr3; 
	long headptr; /* position of top of loop */
	int codel; /* length of compiled code */
	int cangen; /* TRUE if can compile  loop */
	int i; /* work variable */

	if (!codegen) return(FALSE);
	if (mode == 0) {
		genloopi = TRUE; /* force all registers used */
		return(TRUE);
	} /* mode if */

	if (cmdp > 0x7ff0) return(FALSE);

	/* compile "loop" (no tag) or "loop (condition)" forms */
	/* compile "loop  i:=a,b" and "loop  i:=a,b,c" forms */

	if ((mode == LOOP) || (mode == LOOPB) || (mode == ILOOPONEB) || 
	    (mode == ILOOPGENB)) {
		brptr1 = brptr2 = brptr3 = 0;
		if ((mode == ILOOPONEB) || (mode == ILOOPGENB)) {
			if (cmpbuf[cmdp+3] != ICODE) return(FALSE);
			if (!cmp->multcode) return(FALSE);
			i = cmpbuf[cmdp];
			if ((i != ILOOPONEB) && (i != ILOOPGENB)) 
				return(FALSE);
			cmpl = prevret; /* reset to remove return */

			/* generate test to skip first increment+test */

			genmovl(5,5,1,1); /* move.l  k(a5),a1 */
			addint2(PLOOPINT*sizeof(struct exprt));
			genmovl(1,2,0,0); /* move.l  (a1),d0 */ 
			addbyte(0x42); /* clr.l  (a1) */
			addbyte(0x91);
			addbyte(0x4a); /* tst.l  d0 */
			addbyte(0x80);				
			addbyte(0x6b); /* bmi  *+k */
			brptr1 = cmpl;
			addbyte(0); /* reserve byte for displacement */

			/* get address of results table */

			genmovl(5,5,1,1); /* move.l  k(a5),a1 */
			addint2(PRESULT*sizeof(struct exprt));

			/* get increment for general increment case */

			if (mode == ILOOPGENB) {
				i = (2*sizeof(struct evresult))+4;
				addbyte(0x45); /* lea  (k)a1,a2 */
				addbyte(0xe9);
				addint2(i); /* bias to xresult[2].lval */
				genmovl(2,2,1,0); /* move.l  (a2),d1 */
			} /* mode if */

			/* get address of index var from results table */

			addbyte(0x45); /* lea  (18)a1,a2 */
			addbyte(0xe9);
			addint2(18); /* bias to xresult[0].lastaddr */
			genmovl(2,2,2,1); /* move.l  (a2),a2 */

			/* increment index */

			if (mode == ILOOPGENB) {
				addbyte(0xd3); /* add.l  d1,(a2) */
				addbyte(0x92);
			} else {
				addbyte(0x52); /* addq.l  #1,(a2) */
				addbyte(0x92);
			} /* else */
			genmovl(2,2,0,0); /* move.l  (a2),d0 */

			/* compute address of end value table entry */

			i = sizeof(struct evresult)+4; /* bias to end value */
			addbyte(0x45); /* lea  (k)a1,a2 */
			addbyte(0xe9);
			addint2(i); /* bias to xresult[1].lval */

			/* generate end-test */
			/* perform appropriate test for sign of increment */

			if (mode == ILOOPGENB) {
				addbyte(0x4a); /* tst.l  d1 */
				addbyte(0x81);	
				addbyte(0x6a); /* bpl  *+k */
				brptr = cmpl;
				addbyte(0); /* reserve byte for displacement */
				genroe(0xb,0,2,2,2); /* cmp.l  (a2),d0 */
				addbyte(0x6a); /* bpl  *+k - jump to continue loop */
				brptr2 = cmpl;
				addbyte(0); /* reserve byte for displacement */
				addbyte(0x60); /* bra  *+k - jump to end loop */
				brptr3 = cmpl; 
				addbyte(0); /* reserve byte for displacement */
				plantbyte((cmpl-(brptr+1)),brptr); /* plant branch displ */
			} /* mode if */
			genroe(0xb,0,2,2,2); /* cmp.l  (a2),d0 */
			addbyte(0x6f); /* ble  *+k - jump to continue loop */
			brptr = cmpl;
			addbyte(0); /* reserve byte for displacement */
		} else if (mode == LOOP){
			if (cmpbuf[cmdp+3] != ICODE) return(FALSE);
			if (!cmp->multcode) return(FALSE);
			cmpl = prevret; /* reset to remove return */

			/* generate test and branch */

			addbyte(0x4a); /* tst.l  d0 */
			addbyte(0x80);				
			addbyte(0x6b); /* bmi  *+k */
			brptr = cmpl;
			addbyte(0); /* reserve byte for displacement */
		} else if (mode == LOOPB) {

			/* set up expression header and setup code */

			codep = cmpl; /* start of expression */
			addbyte(ICODE);
			if (cmpl & 1) addbyte(0); /* force word boundary */
			codeb = cmpl;	/* save pointer to length */
			addbyte(0);	/* reserve space for code length */
			addbyte(0);
			aerrorc = 0;	/* address of call to array error exit */
			globalr = localr = FALSE; /* pointers not in register */
			stdregs(); /* normal (all) registers used */
			genbegin(); /* initial setup code */

			/* generate branch over exit code */

			addbyte(0x60); /* bra  *+k */
			brptr = cmpl;
			addbyte(0); /* reserve byte for displacement */
		} else return(FALSE);

		/* generate code to update uloc */

		loopexit = cmpl; /* save address of update code */
		if (brptr3)
			plantbyte((cmpl-(brptr3+1)),brptr3); /* plant branch displ */
		genmovl(5,5,1,1); /* move.l  k(a5),a1 */
		addint2(PCODEP*sizeof(struct exprt)); 
		genmovl(1,2,1,1); /* move.l  (a1),a1 */ 
		addbyte(0x43); /* lea  (k)a1,a1 */
		addbyte(0xe9);
		addint2(cmdp+1); 
		genmovb(1,3,1,0); /* move.b (a1)+,d1 */
		addbyte(0xe1); /* lsl.l  #8,d1 */
		addbyte(0x89);
		genmovb(1,2,1,0); /* move.b (a1),d1 */
		genmovl(5,5,1,1); /* move.l  k(a5),a1 */
		addint2(PULOC*sizeof(struct exprt));
		genmovw(1,0,1,2); /* move.w  d1,(a1) */

		/* generate code to exit and terminate loop */

		genret(); /* generate return from subroutine */

		/* fill in forward refs to continuing-loop code */

		plantbyte((cmpl-(brptr+1)),brptr); /* plant branch displacement */
		if (brptr1)
			plantbyte((cmpl-(brptr1+1)),brptr1); /* plant branch displ */
		if (brptr2)
			plantbyte((cmpl-(brptr2+1)),brptr2); /* plant branch displ */

		/* generate code to update uloc and return for continuing-loop */

		prevret = cmpl;	/* save for multiple expr or continued -calc- */
		genmovl(5,5,1,1); /* move.l  k(a5),a1 */
		addint2(PULOC*sizeof(struct exprt));
		genmovw(4,7,1,2); /* move.w  #k,(a1) */
		brptr = cmpl;
		addint2(0); /* reserve space for uloc value */
		genret(); /* generate code to restore registers and return */
		plantint2((int)(cmpl),brptr); /* plant uloc value */

		/* set length of compiled code */

		codel = cmpl-(codeb+2);
		cmpbuf[codeb] = (codel >> 8) & 0xff;
		cmpbuf[codeb+1] = codel & 0xff;

		plantbyte(CLOOP,cmdp); /* replace command code */

		/* set up so next compile can append to this */

		appendok = TRUE;
		prevend = cmpl;
		return(TRUE);
	} /* loop if */

	/* compile "endloop" */

	else if (mode == ENDLOOP) {
		headptr = (cmpbuf[cmdp+1] & 0xff) << 8;
		headptr += cmpbuf[cmdp+2] & 0xff;
		cangen = TRUE; /* assume can compile */
		if (cmpbuf[headptr] != CLOOP) cangen = FALSE;
		else if (!appendok) cangen = FALSE;
		if (cangen) {
			cmpl = prevret; /* re-set end of previous calc */

			/* generate code to update uloc */

			genmovl(5,5,1,1); /* move.l  k(a5),a1 */
			addint2(PULOC*sizeof(struct exprt));
			genmovw(4,7,1,2); /* move.w  #k,(a1) */
			addint2(headptr); /* add literal value */

			/* generate call to loop interrupt-check routine */

			gensubr(PLOOP); 

			/* generate test+branch back to top of loop */

			genret(); /* generate code to restore registers */
			cmpl -= 2; /* remove rts instruction */
			addbyte(0x4a); /* tst.l  d0 */
			addbyte(0x80);				
			headptr += 6; /* advance to compiled code */
			if (headptr & 1) headptr++; 
			addbyte(0x67); /* beq  *-k */
			addbyte(0);
			addint2(-(cmpl-headptr));
			addbyte(0x4e);	/* rts */
			addbyte(0x75);	

			/* set length of compiled code */

			codel = cmpl-(codeb+2);
			cmpbuf[codeb] = (codel >> 8) & 0xff;
			cmpbuf[codeb+1] = codel & 0xff;
			return(TRUE);
		} /* cangen if */
	} /* endloop else if */

	/* compile "outloop" */

	else if ((mode == OUTLOOP) || (mode == OUTLOOPB)) {
		if (addr < 0) return(FALSE);

		if (mode == OUTLOOPB) {
			if (!appendok) return(FALSE);
			cmpl = prevret; /* append to previous -calc- */

			/* generate unconditional branch to top of loop */

			addbyte(0x60); /* bra  *-k */
			addbyte(0);
			addint2(-(cmpl-addr)); /* branch back to loop exit code */
			appendok = FALSE; /* cant append to this */
		} else {
			if (!cmp->multcode) return(FALSE);
			cmpl = prevret; /* append to condition expr */
			if (!appendok)
				plantbyte(CLOOP,cmdp); /* replace command code */

			/* generate test and branch */

			addbyte(0x4a); /* tst.l  d0 */
			addbyte(0x80);				
			addbyte(0x6b); /* bmi  *-k */
			addbyte(0);
			addint2(-(cmpl-addr)); /* branch back to loop exit code */

			/* generate code to update uloc and exit */

			prevret = cmpl; /* save address of exit */
			genmovl(5,5,1,1); /* move.l  k(a5),a1 */
			addint2(PULOC*sizeof(struct exprt));
			genmovw(4,7,1,2); /* move.w  #k,(a1) */
			brptr = cmpl;
			addint2(0); /* reserve space for uloc value */
			genret(); /* generate code to restore registers and return */
			plantint2((int)(cmpl),brptr); /* plant uloc value */
			appendok = TRUE;
		} /* OUTLOOPB else */

		/* set length of compiled code */

		codel = cmpl-(codeb+2);
		cmpbuf[codeb] = (codel >> 8) & 0xff;
		cmpbuf[codeb+1] = codel & 0xff;
		prevend = cmpl;
		return(TRUE);
	} /* outloop else if */

	return(FALSE);

} /* genloop */

/* ******************************************************************* */

	/* code generation subroutines for Sun-III */

/* ------------------------------------------------------------------------------ */

asgreg(t)		/* assign operand to working register */
int t;			/* index of token to assign */

{	int rn;	/* register number selected */
	int i;		/* index */

	if (xtokd[t].result != tundef)  rn = xtokd[t].result;	/* already assigned */
	else {

		/* attempt to locate free working register */

		i  = -1;	/* initialize index */
		rn = tonstk;	/* no register yet */
		do {
			i++;
			if ((regtyp[i] == regw) && (regrsv[i] == 0) &&
			   (regtrack[i] <= xtokd[t].loc)) {
				rn = i;
				xtokd[t].result = rn;	/* assign token to register */
				regrsv[rn] = t;		/* assign register to token */
				reguse[rn] = TRUE;
				regtrack[rn] = xtokd[t].loc;
			} /* regtyp if */
		} while ((i < (regtl-1)) && (rn == tonstk));

		/* assign operand to register */

		xtokd[t].result = rn;		/* assign operand to register */
	} /* not assigned else */
	return(rn);

} /* asgreg */

/* ------------------------------------------------------------------------------ */

fixreg(t,rn)	/* assign operand to argument (fixed) register */
int t;			/* index of operand to assign */
int rn;		/* register number to assign to */

{	int opc;		/* operand/operator code of token */
	int opcf;		/* integer/floating flag */

	opc = xtokd[t].code;
	opcf = (xt[opc].trel == TFLOAT);

	/* check if specified register available */

	if ((regtrack[rn] <= xtokd[t].loc) && (regrsv[rn] == 0) &&
	  ((!opcf) || ((regtrack[rn+1] <= xtokd[t].loc) &&
	  (regrsv[rn+1] == 0)))) {	
		regrsv[rn] = t;	/* reserve specified register (pair) */
		regtrack[rn] = xtokd[t].loc;
		reguse[rn] = TRUE;
		if (opcf) {
			regrsv[rn+1] = t;
			regtrack[rn+1] = xtokd[t].loc;
			reguse[rn+1] = TRUE;
		} /* float if */
		xtokd[t].result = rn;	/* assign token to register */
	} /* available if */

	/* move elsewhere if register not available */

	else rn = asgreg(t);	/* desired register not available */
	return(rn);

} /* fixreg */

/* ------------------------------------------------------------------------------ */

relreg(rn)		/* release register */
int rn;		/* register to release */

{
	if (rn >= 0)  regrsv[rn] = 0;
	return(0);

} /* relreg */

/* ------------------------------------------------------------------------------ */

stkop(t)		/* force result of operation to run-time stack */
int t;			/* index of token to force */

{
	if (xtokd[t].result >= 0) relreg(xtokd[t].result);	/* release register */
	xtokd[t].result = tonstk;	/* flag on stack */
	return(0);

} /* stkop */

/* ------------------------------------------------------------------------------ */

setlasta(lasta,lastk,lastt)		/* set store-ability information */
long	lasta;	/* address of operand */
int lastk;		/* local/global integer/float type of operand */
int lastt;		/* TFLOAT, TINT, TBYTE */

{
	slasta = lasta;
	slastk = lastk;
	slastt = lastt;

} /* setlasta */

/* ------------------------------------------------------------------------------ */

genopwr(sr,dr)		/* generate code to load to stack/register */
int sr;			/* source register */
int dr;			/* destination register */

{
	if (srmod(dr) != srmod(sr)) {
		genmovl(prnum(sr),srmod(sr),prnum(dr),drmod(dr));
	} /* if */
	return(dr);
	
} /* genopwr */

/* ------------------------------------------------------------------------------ */

genmovl(srn, srm, drn, drm)	/* generate move.l instruction */
int srn;		/* source register number */
int srm;		/* source addressing mode */
int drn;		/* destination register number */
int drm;		/* destination addressing mode */

{	int i;

	i = 0x20 + (drn << 1)+((drm >> 2) & 1);		/* 0010rrrm */
	addbyte(i);
	i = ((drm & 3) << 6)+(srm << 3)+srn;		/* mmnnnrrr */
	addbyte(i);
	return;

} /* genmovl */

/* ------------------------------------------------------------------------------ */

genmovw(srn, srm, drn, drm)	/* generate move.w instruction */
int srn;		/* source register number */
int srm;		/* source addressing mode */
int drn;		/* destination register number */
int drm;		/* destination addressing mode */

{	int i;

	i = 0x30 + (drn << 1)+((drm >> 2) & 1);		/* 0011rrrm */
	addbyte(i);
	i = ((drm & 3) << 6)+(srm << 3)+srn;		/* mmnnnrrr */
	addbyte(i);
	return;

} /* genmovw */

/* ------------------------------------------------------------------------------ */

genmovb(srn, srm, drn, drm)	/* generate move.b instruction */
int srn;		/* source register number */
int srm;		/* source addressing mode */
int drn;		/* destination register number */
int drm;		/* destination addressing mode */

{	int i;

	i = 0x10 + (drn << 1)+((drm >> 2) & 1);		/* 0001rrrm */
	addbyte(i);
	i = ((drm & 3) << 6)+(srm << 3)+srn;		/* mmnnnrrr */
	addbyte(i);
	return;

} /* genmovb */

/* ------------------------------------------------------------------------------ */

genroe(cod,rn,om,drn,drm)	/* generate reg/op-mode/ea form instruction */
int cod;	/* instruction code */
int rn;		/* register number */
int om;		/* op-mode */
int drn;	/* effective address register number */
int drm;	/* effective address mode */

{
	addbyte((cod << 4)+(rn << 1)+((om >> 2) & 1));	/* ccccrrro */
	addbyte(((om & 3) << 6)+(drm << 3)+drn);	/* oommmrrr */

} /* genroe */

/* ------------------------------------------------------------------------------ */

gengp() /* generate code to load pointer to globals */

{
	if (!globalr) {
		genmovl(5,5,4,1); /* move.l  k(a5),a4 */
		addint2(PGLOBAL*sizeof(struct exprt)); /* add displacement */
		genmovl(4,2,4,1);	/* move.l  (a4),a4 */
		globalr = TRUE;
		localr = FALSE;
	}
	return;

} /* gengp */

/* ------------------------------------------------------------------------------ */

genlp() /* generate code to load pointer to locals */

{
	if (!localr) {
		genmovl(5,5,4,1); /* move.l  k(a5),a4 */
		addint2(PLOCAL*sizeof(struct exprt)); /* add displacement */
		genmovl(4,2,4,1);	/* move.l  (a4),a4 */
		localr = TRUE;
		globalr = FALSE;
	}
	return;

} /* genlp */

/* ------------------------------------------------------------------------------ */

genga0(addr)	/* generate code to load global var address to a0 */
long addr;	/* address of local variable */

{
	gengp();	/* set pointer to globals */
	if (addr<0x7fff) {
		addbyte(0x41);		/* lea  a4@(k),a0 */
		addbyte(0xec);
		addint2((int)(addr));
	} else {
		genmovl(4,7,0,1);	/* move.l  #k,a0 */
		addint4((int)(addr));	/* add displacement value */
		genroe(13,0,7,4,1);	/* add.l  a4,a0 */
	} /* large address else */
	return;

} /* genga0 */

/* ------------------------------------------------------------------------------ */

genla0(addr)		/* generate code to load local var address to a0 */
long addr;	/* address of local variable */

{
	genlp();	/* set pointer to locals */
	if (addr < 0x7fff) {
		addbyte(0x41);		/* lea  a4@(k),a0 */
		addbyte(0xec);
		addint2((int)(addr));
	} else {
		genmovl(4,7,0,1);	/* move.l  #k,a0 */
		addint4(addr);		/* add displacement value */
		genroe(13,0,7,4,1);	/* add.l  a4,a0 */
	} /* large address else */
	return;

} /* genla0 */

/* ------------------------------------------------------------------------------ */

gensubr(opc)		/* generate call to subroutine */
int opc;		/* address of subroutine */

{	int nbs; /* number argument bytes to remove from stack */
	int nargs; /* number arguments to function */
	int xtdisp; /* displacement into xt[] */

	/* generate code to load a0 with address of routine */

	xtdisp = opc*sizeof(struct exprt); /* displacement in table */
if (xtdisp > 0x3fff) TUTORdump("expression table too small");
	genmovl(5,5,0,1); /* move.l  k(a5),a0 */
	addint2(xtdisp); /* add displacement */

	/* generate subroutine call */

	addbyte(0x4e);	/* jsr  (a0) */
	addbyte(0x90);

	/* compute number bytes, and generate lea to clear stack */

	if ((opc != PCALCE) && (opc != PLOOP)) {
		if (opc == EXPONIC) nbs = 12; /* number bytes to pop */
		else if (opc == SYSVAR) nbs = 4;
		else {
			nargs = (xt[opc].unary ? 1: 2); /* number arguments */
			nbs = ((xt[opc].targ == TFLOAT) ? 8: 4); /* bytes per arg */
			nbs = nbs*nargs;
		} /* else */
		addbyte(0x4f); /* lea  sp@(nbs),sp */
		addbyte(0xef);
		addint2(nbs);
	} /* opc if */
	return;

} /* gensubr */

/* ------------------------------------------------------------------------------ */

stdregs()	/* set standard registers-used */
		/* normal assumption for a block of compiled code */

{	int i;

	for (i=2; i<8; i++) reguse[i] = TRUE;
	for (i=2; i<7; i++) reguse[i+8] = TRUE;

} /* stdregs */

/* ------------------------------------------------------------------------------ */	

genbegin() 	/* generate initial setup code */

{	int i; /* index in reguse */
	int j; /* register mask */

	/* get address of xt[] table from stack */

	genmovl(7,5,0,0); /* movel 4(sp),d0) */
	addint2(4); /* add displacement */

	/* generate movem.l instruction to save registers */

	j = 0;	/* initialize register mask */
	for (i=2; i<8; i++)	/* build d register part of mask */
		if (reguse[i]) j = j | (1 << ((7-i)+8)); /* d2-d7 */
	for (i=2; i<7; i++)	/* build a register part of mask */
		if (reguse[i+8]) j =  j | (1 << (7-i)); /* a2-a7 */
	addbyte(0x48);	/* movem.l  /.../,sp@- */
	addbyte(0xe7);
	addint2(j);

	/* copy address of xt[] table to a5 */

	genmovl(0,0,5,1); /* move.l d0,a5 */

} /* genbegin */

/* ------------------------------------------------------------------------------ */	

genret()	/* generate return from compiled code */

{	int i,j;

	/* generate movem.l instruction to restore registers */

	j = 0;	/* initialize register mask */
	for (i=2; i<8; i++)	/* build d register part of mask */
		if (reguse[i]) j = j | (1 << i);		/* d2-d7 */
	for (i=2; i<7; i++)	/* build a register part of mask */
		if (reguse[i+8]) j =  j | (1 << (i+8));	/* a2-a6 */
	addbyte(0x4c);	/* movem.l  /.../,sp@- */
	addbyte(0xdf);
	addint2(j);

	/* generate return from subroutine */

	addbyte(0x4e);	/* rts */
	addbyte(0x75);

} /* genret */

/* ------------------------------------------------------------------------------ */

prnum(rn)			/* return physical register number for logical register */
int rn;			/* logical register number */

{	
	if (rn == tonstk) return(7); /* stack = a7 */
	if (rn < 8 ) return(rn);	/* d0 - d7 */
	return(rn-8);			/* a0 - a7 */

} /* prnum */


/* ------------------------------------------------------------------------------ */

srmod(rn)		/* return addressing mode for source logical register */
int rn;		/* logical register number */

{
	if (rn == tonstk) return(3);	/* sp@+ */
	if (rn<8) return(0);		/* d0 - d7 */
	return(1);			/* a0 - a7 */

} /* srmod */

/* ------------------------------------------------------------------------------ */

drmod(rn)		/* return addressing mode for destination logical register */
int rn;		/* logical register number */

{
	if (rn == tonstk) return(4); /* sp@- */
	return(srmod(rn));

} /* drmod */

/* ------------------------------------------------------------------------------ */

icgen()		/* initializations for code generator */

{	int i;		/* index in expression analyzer table */
	struct exprt *t;	/* pointer to current table entry */
	double (*dfp)();	/* pointer to floating routine */
	long (*lfp)();		/* pointer to integer routine */

	for (i=0; i<regtl; i++){ regtyp[i] = regx; regrsv[i] = 0; }

	regtyp[0] = rega;		/* d0 subroutine */
	regtyp[1] = rega;		/* d1 subroutine */
	regtyp[2] = regw;		/* d2 available */
	regtyp[3] = regw;		/* d3 available */
	regtyp[4] = regw;		/* d4 available */
	regtyp[5] = regw;		/* d5 available */
	regtyp[6] = regw;		/* d6 available */
	regtyp[7] = regw;		/* d7 available */
	regtyp[8] = rega;		/* a0 subroutine */
	regtyp[9] = rega;		/* a1 subroutine */
	regtyp[10] = rega;		/* a2 storage */
	regtyp[11] = rega;		/* a3 storage */
	regtyp[12] = rega;		/* a4 pointer */
	regtyp[13] = rega;		/* a5 pointer */

	xt[ENDI].cgen = TRUE;
	xt[ENDIM].cgen = TRUE;
	xt[ENDF].cgen = TRUE;
	xt[ENDFM].cgen = TRUE;
	xt[ILITERAL].cgen = TRUE;
	xt[FLITERAL].cgen = TRUE;
	xt[GLOBALVAL].cgen = TRUE;
	xt[IGLOBALVAL].cgen = TRUE;
	xt[BGLOBALVAL].cgen = TRUE;
	xt[LOCALVAL].cgen = TRUE;
	xt[ILOCALVAL].cgen = TRUE;
	xt[BLOCALVAL].cgen = TRUE;
	xt[GLOBALADDR].cgen = TRUE;
	xt[IGLOBALADDR].cgen = TRUE;
	xt[BGLOBALADDR].cgen = TRUE;
	xt[LOCALADDR].cgen = TRUE;
	xt[ILOCALADDR].cgen = TRUE;
	xt[BLOCALADDR].cgen = TRUE;
	xt[GARRAYVAL].cgen = TRUE;
	xt[GARRAYADDR].cgen = TRUE;
	xt[IGARRAYVAL].cgen = TRUE;
	xt[IGARRAYADDR].cgen = TRUE;
	xt[BGARRAYVAL].cgen = TRUE;
	xt[BGARRAYADDR].cgen = TRUE;
	xt[LARRAYVAL].cgen = TRUE;
	xt[LARRAYADDR].cgen = TRUE;
	xt[ILARRAYVAL].cgen = TRUE;
	xt[ILARRAYADDR].cgen = TRUE;
	xt[BLARRAYVAL].cgen = TRUE;
	xt[BLARRAYADDR].cgen = TRUE; 
	xt[IPLUS].cgen = TRUE;
	xt[IMINUS].cgen = TRUE;
	xt[IUMINUS].cgen = TRUE;
	xt[IINC].cgen = TRUE;
	xt[IDEC].cgen = TRUE;
	xt[ITIMES].cgen = TRUE;
	xt[IDIVR].cgen = TRUE;
	xt[IDIVT].cgen = TRUE;
	xt[LSHIFT].cgen = TRUE;
	xt[RSHIFT].cgen = TRUE;
	xt[LMASK].cgen = TRUE;
	xt[LUNION].cgen = TRUE;
	xt[LDIFF].cgen = TRUE;
	xt[COMP].cgen = TRUE;
	xt[BITCNT].cgen = TRUE;
	xt[ASSIGN].cgen = TRUE;
	xt[IASSIGN].cgen = TRUE;
	xt[BASSIGN].cgen = TRUE;
	xt[IEQ].cgen = TRUE;
	xt[INE].cgen = TRUE;
	xt[IGT].cgen = TRUE;
	xt[ILT].cgen = TRUE;
	xt[IGE].cgen = TRUE;
	xt[ILE].cgen = TRUE;
	xt[EQ].cgen = TRUE;
	xt[NE].cgen = TRUE;
	xt[GT].cgen = TRUE;
	xt[LT].cgen = TRUE;
	xt[GE].cgen = TRUE;
	xt[LE].cgen = TRUE;  
	xt[ITOF].cgen = TRUE;
	xt[FTOI].cgen = TRUE;
	xt[PLUS].cgen = TRUE;
	xt[MINUS].cgen = TRUE;
	xt[UMINUS].cgen = TRUE;
	xt[TIMES].cgen = TRUE;
	xt[DIVIDE].cgen = TRUE;
	xt[INT].cgen = TRUE;
	xt[FRAC].cgen = TRUE;
	xt[ROUND].cgen = TRUE;
	xt[SIGN].cgen = TRUE;
	xt[EXPONENT].cgen = TRUE;
	xt[EXPONIC].cgen = TRUE;
	xt[SYSVAR].cgen = TRUE;
	xt[FFUNCT].cgen = TRUE;

	xt[ENDI].rr = TRUE;
	xt[ENDIM].rr = TRUE;
	xt[ENDF].rr = TRUE;
	xt[ENDFM].rr = TRUE;
	xt[ILITERAL].rr = TRUE;			
	xt[IGLOBALVAL].rr = TRUE;		
	xt[BGLOBALVAL].rr = TRUE;		
	xt[ILOCALVAL].rr = TRUE;		
	xt[BLOCALVAL].rr = TRUE;		
	xt[IGLOBALADDR].rr = TRUE;	
	xt[BGLOBALADDR].rr = TRUE;	
	xt[ILOCALADDR].rr = TRUE;		
	xt[BLOCALADDR].rr = TRUE;		
	xt[IPLUS].rr = TRUE;
	xt[IMINUS].rr = TRUE;;			
	xt[IUMINUS].rr = TRUE;		
	xt[IINC].rr = TRUE;
	xt[IDEC].rr = TRUE;
	xt[IASSIGN].rr = TRUE;
	xt[BASSIGN].rr = TRUE;
	xt[LSHIFT].rr = TRUE;
	xt[RSHIFT].rr = TRUE;
	xt[LMASK].rr = TRUE;
	xt[LUNION].rr = TRUE;
	xt[LDIFF].rr = TRUE;
	xt[COMP].rr = TRUE;
	xt[IEQ].rr = TRUE;
	xt[INE].rr = TRUE;
	xt[IGT].rr = TRUE;
	xt[ILT].rr = TRUE;
	xt[IGE].rr = TRUE;
	xt[ILE].rr = TRUE;

#ifdef mc68020
	xt[ITIMES].rr = TRUE;
#else
	xt[ITIMES].subr = TRUE;
	lfp = lcimult;
	xt[ITIMES].xaddr = (long)lfp;
#endif
	
	lfp = lciresult;	xt[ENDIM].xaddr = (long)lfp;
	dfp = lcfresult;	xt[ENDFM].xaddr = (long)dfp;
	lfp = lcftoi;	xt[FTOI].xaddr = (long)lfp;	xt[FTOI].subr = TRUE;
	lfp = lcidivr;	xt[IDIVR].xaddr = (long)lfp;	xt[IDIVR].subr = TRUE;
	lfp = lcidivt;	xt[IDIVT].xaddr = (long)lfp;	xt[IDIVT].subr = TRUE;
	lfp = lcbitcnt;	xt[BITCNT].xaddr = (long)lfp;	xt[BITCNT].subr = TRUE;
	lfp = lcint;	xt[INT].xaddr = (long)lfp;	xt[INT].subr = TRUE;
	lfp = lcftoi;	xt[ROUND].xaddr = (long)lfp;	xt[ROUND].subr = TRUE;
	lfp = lcsign;	xt[SIGN].xaddr = (long)lfp;	xt[SIGN].subr = TRUE;
	lfp = lcfeq;	xt[EQ].xaddr = (long)lfp;	xt[EQ].subr = TRUE;
	lfp = lcfne;	xt[NE].xaddr = (long)lfp;	xt[NE].subr = TRUE;
	lfp = lcfgt;	xt[GT].xaddr = (long)lfp;	xt[GT].subr = TRUE;
	lfp = lcflt;	xt[LT].xaddr = (long)lfp;	xt[LT].subr = TRUE;
	lfp = lcfge;	xt[GE].xaddr = (long)lfp;	xt[GE].subr = TRUE;
	lfp = lcfle;	xt[LE].xaddr = (long)lfp;	xt[LE].subr = TRUE;
	dfp = lcfrac;	xt[FRAC].xaddr = (long)dfp;	xt[FRAC].subr = TRUE;
	dfp = lcitof;	xt[ITOF].xaddr = (long)dfp;	xt[ITOF].subr = TRUE;
	dfp = lcfadd;	xt[PLUS].xaddr = (long)dfp;	xt[PLUS].subr = TRUE;
	dfp = lcfsub;	xt[MINUS].xaddr = (long)dfp;	xt[MINUS].subr = TRUE;
	dfp = lcfmult;	xt[TIMES].xaddr = (long)dfp;	xt[TIMES].subr = TRUE;
	dfp = lcfdiv;	xt[DIVIDE].xaddr = (long)dfp;	xt[DIVIDE].subr = TRUE;
	dfp = lcfumin;	xt[UMINUS].xaddr = (long)dfp;	xt[UMINUS].subr = TRUE;
	dfp = lcfexpon;	xt[EXPONENT].xaddr = (long)dfp;	xt[EXPONENT].subr = TRUE;
	dfp = lcfexpic;	xt[EXPONIC].xaddr = (long)dfp;	xt[EXPONIC].subr = TRUE;
	dfp = lcfsysv;	xt[SYSVAR].xaddr = (long)dfp;	xt[SYSVAR].subr = TRUE;

	dfp = lcsin;	xt[SIN+256].xaddr = (long)dfp;	xt[SIN+256].subr = TRUE;
	dfp = lccos;	xt[COS+256].xaddr = (long)dfp;	xt[COS+256].subr = TRUE;
	dfp = lctan;	xt[TAN+256].xaddr = (long)dfp;	xt[TAN+256].subr = TRUE;
	dfp = lccsc;	xt[CSC+256].xaddr = (long)dfp;	xt[CSC+256].subr = TRUE;
	dfp = lcsec;	xt[SEC+256].xaddr = (long)dfp;	xt[SEC+256].subr = TRUE;
	dfp = lccot;	xt[COT+256].xaddr = (long)dfp;	xt[COT+256].subr = TRUE;
	dfp = lcarcsin; xt[ARCSIN+256].xaddr = (long)dfp;	xt[ARCSIN+256].subr = TRUE;
	dfp = lcarccos;	xt[ARCCOS+256].xaddr = (long)dfp;	xt[ARCCOS+256].subr = TRUE;
	dfp = lcarccsc;	xt[ARCCSC+256].xaddr = (long)dfp;	xt[ARCCSC+256].subr = TRUE;
	dfp = lcarcsec;	xt[ARCSEC+256].xaddr = (long)dfp;	xt[ARCSEC+256].subr = TRUE;
	dfp = lcarccot; xt[ARCCOT+256].xaddr = (long)dfp;	xt[ARCCOT+256].subr = TRUE;
	dfp = lcsqrt; 	xt[SQRT+256].xaddr = (long)dfp;	xt[SQRT+256].subr = TRUE;
	dfp = lcabs; 	xt[ABS+256].xaddr = (long)dfp;	xt[ABS+256].subr = TRUE;
	dfp = lcexp; 	xt[EXP+256].xaddr = (long)dfp;	xt[EXP+256].subr = TRUE;
	dfp = lclog; 	xt[LOG+256].xaddr = (long)dfp;	xt[LOG+256].subr = TRUE;
	dfp = lcalog; 	xt[ALOG+256].xaddr = (long)dfp;	xt[ALOG+256].subr = TRUE;
	dfp = lcln; 	xt[LN+256].xaddr = (long)dfp;	xt[LN+256].subr = TRUE;
	dfp = lcsinh; 	xt[SINH+256].xaddr = (long)dfp;	xt[SINH+256].subr = TRUE;
	dfp = lccosh; 	xt[COSH+256].xaddr = (long)dfp;	xt[COSH+256].subr = TRUE;
	dfp = lctanh; 	xt[TANH+256].xaddr = (long)dfp;	xt[TANH+256].subr = TRUE;
	dfp = lcgamma;	xt[GAMMA+256].xaddr = (long)dfp;	xt[GAMMA+256].subr = TRUE;

	InitExpressionTable(xt);
	lfp = lcerr;
	xt[PCALCE].xaddr = (long)lfp;	
	xt[PCODEP].xaddr = (long)(&pcodep);
	lfp = lcloop;
	xt[PLOOP].xaddr = (long)lfp;

} /* icgen */

/* ******************************************************************* */

#endif
