/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Implement CMU Tutor -answer- command, including spelling checker.

Tom Neuendorffer, CMU 1985
*/

#include "execdefs.h"
#include "tglobals.h"
#include "eglobals.h"
#include "ct_ctype.h"
#include "commands.h"

#ifdef ctproto
extern unsigned char  *nextword(unsigned char  *s);
extern int  allpunct(unsigned char  *s);
extern int  mylen(unsigned char  *s);
extern int  orderlist(unsigned int  lh);
extern int  listmatch(unsigned char  *s,unsigned int  lh,int  place,struct  sword FAR *wi);
extern int  capspellcmp(unsigned char  *p,unsigned char  *d,int  len);
extern int  spellcmp(unsigned char  *p,unsigned char  *d,int  len,struct  sword FAR *wi);
extern int  capanswercmp(unsigned char  *p,unsigned char  *d,int  n);
extern int  answercmp(unsigned char  *p,unsigned char  *d,int  n,struct  sword FAR *wi);
extern int  getlist(unsigned char  *s);
extern int  normalize(unsigned char  *pat);
extern int  needblank(unsigned char  *p);
extern int  shove(unsigned char  *p,int  ch);
struct  sline *o_pm(unsigned char  FAR *inputst,unsigned char  *pat);
int  evalscore(struct  sline *ip);
int  markup(struct  sline *ip);
int  o_setwordzvars(struct  sline *match);
char  *strf2n(char  FAR *strp);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  CTtolower(int  cc);
int  CTtoupper(int  cc);
int  CTislower(int  cc);
int  CTisupper(int  cc);
char  FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  appenddoc(unsigned int  theDoc,char  FAR *sP,int  sLen);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
int  EncloseRange(unsigned int  doc,long  pl,long  len,unsigned int  style);
long  TUTORget_len_doc(unsigned int  doc);
#endif /* ctproto */

extern long TUTORget_len_doc();

#define MARKUP
#undef MAX
#define MAX(a,b) ((a > b) ? a : b)
#ifndef STANDALONE
#define punc checkbit(exS.arr.specsbits, PUNC)	/* if true, only punctuation found in pattern allowed */
#define okcap checkbit(exS.arr.specsbits, OKCAP)	/* if true, any words may be capitalized	*/
#define okextra checkbit(exS.arr.specsbits, OKEXTRA)	/* if true, allows extra words	*/
#define noorder checkbit(exS.arr.specsbits, NOORDER) /* if true, allows words in any order */
#define okspell checkbit(exS.arr.specsbits, OKSPELL) /* if true, misspelled words SPELLCOUNT 
			characters long or longer are ok */
#define nospell checkbit(exS.arr.specsbits, NOSPELL) /* if true, no attempt is made to check spelling */
#endif
/*
these (already defined) system variables are set as follows:
arr.zcaps = -1 if no capitalization errors, else 0
arr.zentire = -1 if all required words present, else 0
arr.zextra = -1 if no extra words present, else 0
arr.zorder = -1 if word order is correct, else 0
arr.zspell = -1 if spelling is correct, else 0
arr.zwcount = number of words

*/

#undef isgraph
#define isgraph(A) (A > ' ')

/* 	definitions for evaluating student answers */
#define CAPBAD 3
#define VALSPELL (okspell)? 1:4
#define VALEXTRA (okextra)?1:3
#define VALCAP (okcap)?1:CAPBAD
#define VALMISSING 6
#define VALORDER (noorder)? 1:3
#define VALPUNCT (punc)? 1:3

#define NONE_FOUND -2
#define PUNCT -1
#define NONE -1
#define OPT 0
#define MAND 1
#define ISMAND(A) (A > OPT)
#define ISOPT(A) (A == OPT)
#define STAT(A) (A)?"ON":"OFF"
#define SPELLCOUNT 5 /* see okspell below */
#define ERRORMAX 1 /* Maximum number of allowable
	  spelling errors in a word ( not including misplaced letters ) */

extern char *strf2n();

static int badorder;	/* Will be set to non-zero if a bad order is found by pm() */

/* NOTE (KSW) - when FAR pointers implemented almost everything was made FAR because the code is
   too tangled to comprehend */


/*********************************************/
static unsigned char *nextword(s)
unsigned char *s;
/* Returns next word from string */
{
	while(isgraph(*s))  s++;
	while(*s != '\0' && !(isgraph(*s))) s++;
	if(*s == '\0') return(NULL);
	return(s);
	}

/*********************************************/
static allpunct(s)
unsigned char *s;
{
	while(CTispunct(*s)) s++;
	if(*s == '\0' || ! isgraph(*s)) return(TRUE);
	return(FALSE);
	}

/*********************************************/
static mylen(s)
unsigned char *s;
{
	register unsigned char *p;

	for(p = s; isgraph(*p); p++);
	return((int)(p - s));
	}

/*********************************************/
static orderlist(lh)
Memh lh;
{
/* 	routine to change [hi Hi] to [Hi hi] so zcaps will
	be set properly (sigh) */
	register struct anslist FAR *ll,FAR *nl;
	struct anslist FAR *l;
	unsigned char lword[80];

	l = (struct anslist FAR *)GetPtr(lh);
	if(l->word == NULL) {
		ReleasePtr(lh);
		KillPtr(l);
		return(0);
	}
	for(ll = l,nl = ll + 1; nl->word != NULL;
	   ll++,nl++){
             strncpy((char *) lword,strf2n((char FAR *) ll->word + 1),79);
             lword[79] = '\0';
	     if(ll->type == nl->type && 
		ll->len == nl->len &&
		CTislower(*(ll->word)) &&
		(CTtoupper(*(ll->word)) == *(nl->word)) &&
		(ll->len == 1 || 
		strncmp((char *) lword,strf2n((char FAR *) nl->word + 1)
		   ,ll->len - 1) == 0)) { 
			*(ll->word) = *(nl->word);
			*(nl->word) = CTtolower(*(nl->word));
			}
		}
	ReleasePtr(lh);
	KillPtr(l);
	}	
/*********************************************/
#define BADSPELL(A) !okspell && A->spell == 0 
#define BADCAPS(A,B) (B != OPT) && (A->cap == 1 || (!okcap && A->cap == 0 ))
#define ETEST slen == ll->len && (answercmp((unsigned char *) strf2n((char FAR *) ll->word),s,ll->len,wi)) == 0
#define CTEST slen == ll->len && (capanswercmp((unsigned char *) strf2n((char FAR *) ll->word),s,ll->len)) == 0
#define STEST slen >= ll->len - 1 && slen <= ll->len + 1 && (spellcmp((unsigned char *) strf2n((char FAR *) ll->word),s,slen,wi))== 0
#define CSTEST slen >= ll->len - 1 && slen <= ll->len + 1 && (capspellcmp((unsigned char *) strf2n((char FAR *) ll->word),s,slen))== 0
#define FOUNDSPELLERROR wi->spell = 0;  wi->goodspell=ll->word;wi->res = ll->type;wi->gslen=ll->len ;rType = ll->type; ReleasePtr(lh); KillPtr(ll); return(rType);
#define FOUNDWORD wi->spell = -1; wi->goodspell=ll->word; wi->res = ll->type; rType = ll->type; ReleasePtr(lh); KillPtr(ll); return(rType);

static listmatch(s,lh,place,wi)
unsigned char *s;
Memh lh;
int place;
struct sword FAR *wi;
/*	Tests if the first word in string s matches any word in list l */
	{
	struct anslist FAR *l;
	REGISTER struct anslist FAR *ll;
	register int slen = mylen(s);
	int rType; /* return value */

/* first pass looks for mandatory word in right location */
	l = (struct anslist FAR *)GetPtr(lh);
	wi->order = -1;
	wi->extra = -1;
	wi->spell = -1;
	wi->cap = -1;
	wi->word = s;
	wi->len = slen;
	 wi->gslen = 0;
	for(ll = l; ll->word != NULL; ll++){
		if( ll->type == place && CTEST ){
			FOUNDWORD
			}	
		}
	for(ll = l; ll->word != NULL; ll++){
		if( ll->type == place && ETEST ){
			FOUNDWORD
			}	
		}
/* second pass looks for optional word */
	for(ll = l; ll->word != NULL; ll++){
		if(ISOPT(ll->type) && CTEST){
			FOUNDWORD
			}
		}
	for(ll = l; ll->word != NULL; ll++){
		if(ISOPT(ll->type) && ETEST){
			FOUNDWORD
			}
		}
/* third pass looks for mandatory word in wrong location */
	for(ll = l; ll->word != NULL; ll++){
		if(ISMAND(ll->type) &&  ll->type != place &&
		  CTEST ){
			wi->order = 0;
			FOUNDWORD
			}
		}
	for(ll = l; ll->word != NULL; ll++){
		if(ISMAND(ll->type) &&  ll->type != place &&
		  ETEST ){
			wi->order = 0;
			FOUNDWORD
			}
		}
	if(/* okspell && */ slen >= SPELLCOUNT){
/*	Now look for misspelled words 	*/
/* first pass looks for mandatory word in right location */
	for(ll = l; ll->word != NULL; ll++){
		if( ll->type == place
		   && CSTEST){
			FOUNDSPELLERROR
			}
		}
	for(ll = l; ll->word != NULL; ll++){
		if( ll->type == place
		   && STEST){
			FOUNDSPELLERROR
			}
		}
/* second pass looks for optional word */
	for(ll = l; ll->word != NULL; ll++){
		if(ISOPT(ll->type) &&
		   CSTEST){
			FOUNDSPELLERROR
			}
		}
	for(ll = l; ll->word != NULL; ll++){
		if(ISOPT(ll->type) &&
		   STEST){
			FOUNDSPELLERROR
			}
		}
/* third pass looks for mandatory word in wrong location */
	for(ll = l; ll->word != NULL; ll++){
		if(ISMAND(ll->type) &&  ll->type != place &&
		  CSTEST){
			wi->order = 0;
			FOUNDSPELLERROR
			}
		}
	for(ll = l; ll->word != NULL; ll++){
		if(ISMAND(ll->type) &&  ll->type != place &&
		  STEST){
			wi->order = 0;
			FOUNDSPELLERROR
			}
		}
	}
	wi->extra = 0;
	wi->res = (allpunct((unsigned char *) strf2n((char FAR *) s)))? PUNCT: NONE_FOUND;
	KillPtr(l);
	ReleasePtr(lh);
	return(wi->res);
	}

#define CHARCHECK(X,Y) (X == Y || (okcap && CTisupper(Y) && CTtolower(Y) == X))
#define CAPCHECK(X,Y)  (CTisupper(Y) && CTtolower(Y) == X)
#define CHECKCAP(X,Y) CAPCHECK(Y,X)
/*********************************************/
static capspellcmp(p,d,len) /* return 0 if found match, else -1 */
register unsigned char *p,*d;
register int len;
{
	register int x = 0;
	if (nospell) { /* must be exact match */
		for (;len && *d;p++,d++,len--) {
			if(*p == *d) continue;
			return(-1);
		}
		return(0);
	}
	/* first char must match exact */
	if(*p == *d) len--;
	else return -1;
	p++;d++;
	for(;len && *d;p++,d++,len--) {
		if(*p == *d) continue;
		if(*p == *(d - 1)) continue;
		if(*p == *(d + 1)) continue;
		if(*(p + 1) == *d) continue;
		if(*(p - 1) == *d) continue;
		if(++x > ERRORMAX) return(-1);
		}
	return(0);
	}

/*********************************************/
static spellcmp(p,d,len,wi) /* return 0 if found match, else -1 */
register unsigned char *p,*d;
register int len;
struct sword FAR *wi;
{
	register int x = 0;
	register int capwrong = 0;
	register int match = 0;
	if (nospell) { /* must be exact match */
		for (;len && *d;p++,d++,len--) {
			if(*p == *d) continue;
			return(-1);
		}
		return(0);
	}
	/* first char must match exact */
	if(*p == *d) len--;
	else if(CAPCHECK(*p,*d) ) {
		capwrong++;len--;
		}
	else if(CHECKCAP(*p,*d) ) {
		match++;capwrong++;len--;
		}
	else return -1;
	p++;d++;
	for(;len && *d;p++,d++,len--) {
		if(*p == *d) continue;
		if(*p == *(d - 1)) continue;
		if(*p == *(d + 1)) continue;
		if(*(p + 1) == *d) continue;
		if(*(p - 1) == *d) continue;
		capwrong++;
		if(CAPCHECK(*p,*d)) continue;
		if(CAPCHECK(*p,*(d-1))) continue;
		if(CAPCHECK(*p,*(d+1))) continue;
		if(CAPCHECK(*(p+1),*d)) continue;
		if(CAPCHECK(*(p-1),*d)) continue;
		match++;
		if(CHECKCAP(*p,*d)) continue;
		if(CHECKCAP(*p,*(d-1))) continue;
		if(CHECKCAP(*p,*(d+1))) continue;
		if(CHECKCAP(*(p+1),*d)) continue;
		if(CHECKCAP(*(p-1),*d)) continue;
		if(++x > ERRORMAX) return(-1);
		capwrong--; match-- ; 
		}
	if(match){
		exS.arr.zcaps = 0;
		wi->cap = 1;
		}
	else if(capwrong){
		exS.arr.zcaps = 0;
		wi->cap = 0;
		}
	return(0);
	}


/*********************************************/
static capanswercmp(p,d,n)
register unsigned char *p, *d;
register int n;
{
	for(;n && *d;p++,d++,n--) {
		if(*p == *d) continue;
		return(-1);
		}
	if(n) return(-1);
	if(*d && isgraph(*d)) return(-1);
	return(0);
	}

/*********************************************/
static answercmp(p,d,n,wi)
register unsigned char *p, *d;
register int n;
struct sword FAR *wi;
{
	register int capwrong = 0;
	register int match = 0;
	for(;n && *d;p++,d++,n--) {
		if(*p == *d) continue;
		capwrong++;
		if(CAPCHECK(*p,*d)) continue;
		match++;
		if(CAPCHECK(*d,*p)) continue;
		return(-1);
		}
	if(n) return(-1);
	if(*d && isgraph(*d)) return(-1);
	if(match){
		exS.arr.zcaps = 0;
		wi->cap = 1;
		}
	else if(capwrong){
		exS.arr.zcaps = 0;
		wi->cap = 0;
		}
	return(0);
	}

/*********************************************/
static getlist(s)
unsigned char *s;
/* 	compiles list lt(hand) of match words from string s.
	return number of mandatory words
*/	
{
	struct anslist FAR *ltp;
	register unsigned char FAR *p,FAR *x,FAR *y;
	int optmode,mandmode,endmode,done,mnum;

	optmode = FALSE ; mandmode = FALSE ; endmode = FALSE;
	mnum = 1;
	done = FALSE;
	ltp = (struct anslist FAR *)GetPtr(exS.arr.lthand);
	ltp->word = NULL;
	if(s == FARNULL) {
		ReleasePtr(exS.arr.lthand);
		KillPtr(ltp);
		return(0);
	}
	while(*s != '\0' && *s == ' ') s++;
	if (*s == '\0') {
		ReleasePtr(exS.arr.lthand);
		KillPtr(ltp);
		return(0);
	}
	for(p = s; ;p++){
		if(done){
			done = FALSE;
			mandmode = FALSE;
			}
		switch	(*p){
		case '<'	:
			optmode++;
			break;
			
		case '['	:
			mandmode++;
			break;
		case ']'	:
		case '>'	:
			if(ltp->word == NULL) {
				optmode = FALSE;
				mandmode = FALSE;
				break;
				}
			endmode = TRUE;
		case '\0':
		case ' ' :
			if(ltp->word == NULL) {
				break;
				}
			ltp->len = p - ltp->word ;
			if(optmode) ltp->type = OPT;
			else if(mandmode)
				ltp->type = mnum;
			else {
				ltp->type = mnum;
				done = TRUE;
				}
			if(*p == '\0') done = TRUE;
			else if(endmode){
				endmode = FALSE;
				if(optmode){
					optmode = FALSE;
					}
				else done = TRUE;
				}
			ltp++;
			if(done) mnum++;
			ltp->word = NULL;
			break;
		case '\\'	:
			y = p;
			x = p;
			x++;
			if(*x == '\0') break;
			while(*y != '\0')
				*y++ = *x++;
		default:
			if(ltp->word == NULL)
				ltp->word = p;
			break;
			}
		if(*p == '\0') break;
		}
	ReleasePtr(exS.arr.lthand);
	KillPtr(ltp);
	return(--mnum);
	}

/*********************************************/
static normalize(pat)
  unsigned char *pat;
{
  /* 	convert tabs to spaces;
	remove multiple adjacent spaces ;
	insert space around punctuation 	
	BUG:	may cause problems with [ >= ]
  */

  register int foundblank; 
  register unsigned char *p, *t;

  t = pat;
  foundblank = TRUE;
  for(  p = pat; *p != '\0'; p++) {
	if(CTispunct(*p) && needblank(p)){
		p++;
		if(!CTisspace(*p)) shove(p,' ');	
		p--;
		if(foundblank == FALSE )
			shove(p,' ');
		}
	if(CTisspace(*p)) {
		if(foundblank) continue;
		*t++ = ' ';
		foundblank = TRUE;
		}
	else {
		foundblank = FALSE;
		*t++ = *p;
		}
	}
  *t = '\0';
  }

/*********************************************/
static needblank(p)
register unsigned char *p;
{
/*	determine if a punctuation character should be spaced apart */
	switch(*p){
	case '-':
	case '[':
	case ']':
	case '<':
	case '>':
	case '\\':
	case '\'':
		return(FALSE);
	case '.':
		p++;
		if(CTisdigit(*p)) return(FALSE);
	default:
		return(TRUE);
	}
}

/*********************************************/
static shove(p,ch)
unsigned char *p;
int ch;
{
/*	shove a character into a string  */
	register unsigned char *q,*r;

	for(q = p;*q != '\0'; q++);
	r = q;
	for(q++;r >= p ;q--,r-- ){
		*q = *r;
		}
	*p = ch;
	}	

#define CantAccept(A) okextra ? (A == 0) : (A != 1)
/*********************************************/
struct sline *o_pm(inputst,pat)
unsigned char FAR *inputst;
unsigned char *pat;
/*	Pattern Match Function
*	returns TRUE if there is a match
*	st is the string to be tested (e.g. student response)
*	pat is the pattern (e.g. tag of author -answer-)
*/
{
	unsigned char *nextword(), *cw;
	unsigned char fflag[256];
	static unsigned char mst[512];
	int ord[128],*op,i,result,endlist,place,done,j;
	int panicctr;
	static struct sword FAR *warr=FARNULL;
	struct sword FAR *wi;
	static struct sline lineres;

	if (!warr) /* need to initialize */
		warr = (struct sword FAR *) 
		       TUTORalloc((long)(100*sizeof(struct sword)),TRUE,"answer");

	lineres.zcaps = -1; lineres.zentire = -1; lineres.zextra = -1;
	lineres.zorder = -1; lineres.zspell = -1; lineres.zwcount = 0;
	exS.arr.zcaps = -1;

/* kludge upon kludge upon kludge */
/* since string can get longer when spaces are inserted around */
/* punctuation, work only with "short" strings and hope for the best */

	strncpyf((char FAR *) mst,(char FAR *) inputst,400);
	mst[400] = mst[401] = mst[511] = '\0'; /* insure terminating zero */


	/* normalize changes tab to space, deletes extra spaces, */
	/* and surrounds punctuation with spaces */
	normalize(mst);
	normalize(pat);
	endlist = getlist((pat)); /* number of mandatory words (can be 0) */
	orderlist(exS.arr.lthand);
	badorder = 0;
	panicctr = 0; /* kludge, kludge, kludge */
	place = 1;
	op = ord;
	done = 0;
	result = NONE;
	for(cw = fflag+1,i = endlist;i--;cw++) *cw = 0;
	wi = warr ;
	if (*mst != '\0')  /* student response is not blank */
	   for(cw = mst;((cw != NULL) && (panicctr < 98)); wi++,op++,cw = nextword(cw)){
		panicctr++;
		if(! allpunct(cw)) lineres.zwcount++;
		*op = listmatch(cw,exS.arr.lthand,place,wi);
		if(BADSPELL(wi) ) {
			result = FALSE;
			lineres.zspell = wi->spell;
			}
		if(BADCAPS(wi,*op) ) {
			wi->cap = 0;
			result = FALSE;
			}
		if(*op > 0){
			if(fflag[*op]) wi->extra = 0;
			fflag[*op]++;
			}
		if(done == TRUE && okextra){
			if(*op == NONE_FOUND) lineres.zextra = 0;
 			continue;
			}
		if(*op == place){
		/*mandatory word found in right place */
			if(++place > endlist){
				if(result == NONE)
					 result = TRUE;
				done = TRUE;
				}
			}
		else {
		  switch(*op){
		case OPT:
		/* optional word found */
			break;
		case PUNCT:
		/* punctuation found */
			if(punc) result = FALSE;
			break;
		case NONE_FOUND:
		/* no match */
			lineres.zextra = 0;
			if(!okextra) result =FALSE;
			break;
		default:
		/*mandatory word found in wrong place */
			if(!noorder) result = FALSE;
			badorder++;	
			break;
			} /* switch */
		   }
		}
	lineres.alen = wi - warr;
	lineres.zcaps = exS.arr.zcaps;
	if(badorder) lineres.zorder = 0;
/* check if all mandatory words were found  */
	for(cw = fflag + 1, i = endlist ,j = 0; i; cw++,i--){
		if(*cw == 0) continue;
		j++;
		if(*cw > 1  && !okextra) /* more than one equal mand. word found */
			result = FALSE;
		}
	lineres.manfound = j;
	if(result != FALSE && noorder && badorder && j == endlist) result = TRUE;
	else if(result == NONE) /* ok if no mandatory author words */
		result = (endlist == 0) ? TRUE : FALSE;
/* 	check if zentire and zextra flags can remain -1	*/
	for(cw = fflag + 1, i = endlist ; i; cw++){
		if(*cw == 0) lineres.zentire = 0;
		if(*cw > 1) lineres.zextra = 0;
		i--;
		}
	lineres.result = result;
	lineres.wordarray = warr;
	lineres.authornum = endlist;
	return(&lineres);
	}

/*********************************************/
evalscore(ip)
struct sline *ip;
{
/* NOTE: extra mandatory words are probably  counted more than they should */
	struct sword FAR *iw;
	int i,sum;
	sum=0;
	for(iw=ip->wordarray,i = ip->alen;i--;iw++){
		if(iw->spell == 0 )sum += VALSPELL ;
		else if (iw->extra == 0){
			if(iw->res == PUNCT) sum += VALPUNCT;
			else  sum += VALEXTRA ; 
			}
		else if(iw->cap == 0){
			if(CAPCHECK(*(iw->goodspell), *(iw->word)))
				sum +=VALCAP;
			else sum += CAPBAD;
			}
		if(iw->order == 0 ) sum += VALORDER;
		}
	sum += VALMISSING * (ip->authornum - ip->manfound);
	return(sum);
	}

/*********************************************/
#ifdef MARKUP
markup(ip)
struct sline *ip;
{
	
	struct sword FAR *iw;
	int i,j,sn,la,mres;
	long cdot, k;
	unsigned char foo[256], tempS[4];
	Memh d ;

	if((d = exS.dTextLayout) == 0) return(0);
	la = 0 ;mres = 0;
	if(noorder){
		for(iw=ip->wordarray,i = ip->alen;i--;iw++){
			if(iw->res > 0) foo[iw->res] = 'A';
			}
		}
	for(iw=ip->wordarray,i = ip->alen,sn = 1;i--;iw++){
		cdot =TUTORget_len_doc(d);
		InsertString(d,cdot,(char FAR *) iw->word, (long) iw->len);
		EncloseRange(d,cdot,(long) iw->len,0); /* make word plain */
		if(iw->spell == 0 && !okspell){
			EncloseRange(d,cdot,(long) iw->len ,style_italic);
			}
		else if (iw->extra == 0 ){
			if(CTispunct(*(iw->word))){
				if( punc)  
					EncloseRange(d,cdot,(long) iw->len ,style_bold);
				}
			else if(!okextra)
					EncloseRange(d,cdot,(long) iw->len ,style_bold);
			}
		else if(iw->cap == 0 ){
			unsigned char FAR *ca,FAR *cs;
			ca = iw->goodspell;cs = iw->word;
			for(j = iw->len,k = cdot;j--; ca++, cs++ ,k++){
				if( CAPCHECK(*ca,*cs)||  (CAPCHECK(*cs,*ca) && !okcap))
					EncloseRange(d,k,(long) 1,style_bold);
				}
			}
		if(iw->res > 0){
			if( sn > iw->res && !noorder)
				{
				InsertString(d,cdot,(char FAR *) "<-",(long) 2);
				}
			while(iw->res - sn  > la){
				if(!noorder  || foo[sn + la] != 'A')
					{
					InsertString(d,cdot,(char FAR *) "[]",2L);
					}
				la++;
				}
			}
			
/* 	If the author res == 0 , don't count the optional word */
/*		if(iw->res > 0 || (iw->res < 0 && okextra) sn++; */
		if(iw->res != 0  && iw->extra != 0) sn++; 
		mres = MAX(mres,iw->res);
		tempS[0] = ' '; tempS[1] = '\0';
		appenddoc(d,(char FAR *) tempS,1);
		}
	while (mres++ <  ip->authornum)   
		{
		tempS[0] = '['; tempS[1] = ']';
		appenddoc(d,(char FAR *) tempS,2);
		}
	return(ip->result);
	}
#endif


/*********************************************/
o_setwordzvars(match) struct sline *match; { /* set zspell etc. */
if (match) {
  exS.arr.zcaps = match->zcaps;
  exS.arr.zentire = match->zentire;
  exS.arr.zextra = match->zextra;
  exS.arr.zorder = match->zorder;
  exS.arr.zspell = match->zspell;
  exS.arr.zwcount = match->zwcount; }
else {
  exS.arr.zcaps = exS.arr.zentire = exS.arr.zextra = exS.arr.zorder = exS.arr.zspell = -1;
  exS.arr.zwcount = 0; }
}
