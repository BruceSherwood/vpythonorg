
/*
A component of the cT (TM) programming environment.
(c) Copyright 1995 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
 */

/* ******************************************************************* */

#include "baseenv.h"
#include "compute.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "memory.h"

/* ******************************************************************* */

extern char FAR *malloc();
extern char FAR *t_malloc();
extern int t_free();
extern char FAR *t_realloc();
extern int TUTORblock_move();

/* ******************************************************************* */

#define MEM_BLK_SIZE 10000L /* size of block to ask for */

struct mem_hdr {
    long length; /* length of this memory area */
    long logical; /* logical size of memory area */
    struct mem_hdr FAR *next_area; /* pointer to next memory area */
    long used; /* TRUE if this block in use */
}; /* mem_hdr  - 16 bytes */

struct mem_hdr FAR *first_area = NULL; /* ptr to first block in chain */
struct mem_hdr FAR *last_area; /* ptr to (start of) last block in chain */

/* ******************************************************************* */

char FAR *t_malloc(size) /* allocate a memory block */
long size; /* size of logical block required */

{   long newBlockSize; /* size of new block if needed */
    struct mem_hdr FAR *nextA; /* pointer to next area */
    struct mem_hdr FAR *prevA; /* pointer to previous area */
    long targetSize; /* size of raw block required */
    long roundSize; /* size rounded to multiple of 8 bytes */
    struct mem_hdr FAR *foundA; /* pointer to area found */

t_check();
    newBlockSize = MEM_BLK_SIZE;
    if (newBlockSize < (size+128))
        newBlockSize += size;  /* bigger than normal chunk */

    roundSize = (size+7) & (~7); /* multiple of 8 bytes */
    targetSize = roundSize+sizeof(struct mem_hdr);

    if (!first_area) {
        first_area = (struct mem_hdr FAR *)malloc(newBlockSize);
        if (!first_area)
            TUTORdump("(t_malloc) initial malloc failed");
        last_area = first_area;
        first_area->length = newBlockSize;
        first_area->next_area = NULL;
        first_area->used = FALSE;
        first_area->logical = 0;
    }

    /* look for a big enough free space */

    nextA = first_area;
    foundA = prevA = NULL;
    while (nextA) {
        if (!nextA->used && (nextA->length >= targetSize)) {
            foundA = nextA; /* found some space */
            break;
        }
        prevA = nextA; /* previous block */
        nextA = nextA->next_area; /* move to next block */
    } /* while */

    if (!foundA) {
        foundA = (struct mem_hdr FAR *)malloc(newBlockSize);
        if (!foundA)
            return(NULL);
        last_area = foundA;
        foundA->length = newBlockSize;
        foundA->next_area = NULL;
        foundA->used = FALSE;
        prevA->next_area = foundA; /* chain previous to this */
    } /* foundA if */

    foundA->used = TRUE;
    foundA->logical = size;

    if ((foundA->length-targetSize)  >= sizeof(struct mem_hdr)) {
        nextA = (struct mem_hdr FAR *) ((char FAR *)(foundA)+targetSize);
        nextA->next_area = foundA->next_area;
        nextA->logical = 0;
        nextA->used = FALSE;
        nextA->length = foundA->length-targetSize;
        foundA->next_area = nextA;
        foundA->length = targetSize;
    }
    return((char FAR *)(foundA)+sizeof(struct mem_hdr)); 

} /* t_malloc */

/* ******************************************************************* */

t_free(dataP) /* free a block of memory */
char FAR *dataP; /* pointer to data to release */

{   struct mem_hdr FAR *areaP; /* pointer to area to free */
    struct mem_hdr FAR *prevP; /* pointer to previous area */

t_check();
    areaP = (struct mem_hdr FAR *)(dataP-sizeof(struct mem_hdr)); /* back up to header */
    if (!areaP->used)
        TUTORdump("(t_free) of already freed area ");
    areaP->used = FALSE;
    areaP->logical = 0;

   /* find previous block */

    prevP = NULL;
    if (areaP != first_area) {
        prevP = first_area;
        while (prevP->next_area != areaP) {
            prevP = prevP->next_area;
            if (!prevP)
                TUTORdump("(t_realloc) memory chain broken");
        } /* while */
    } /* oldA if */

    /* check if can collapse following block into this */

    if ((areaP->next_area) && 
        ((char FAR *)(areaP->next_area) == ((char FAR *)(areaP)+areaP->length))) {
         if (!areaP->next_area->used) {
            /* collapse following free area into this */
            areaP->length += areaP->next_area->length;
            areaP->next_area = areaP->next_area->next_area;
        }
    }

    /* check if can collapse this block into previous */

    if ((prevP) && 
        ((char FAR *)(areaP) == ((char FAR *)(prevP)+prevP->length))) {
         if (!prevP->used) {
            /* collapse this area into previous */
            prevP->length += areaP->length;
            prevP->next_area = areaP->next_area;
        }
    } /* prevP if */

} /* t_free */

/* ******************************************************************* */

char FAR *t_realloc(oldP,newSize)
char FAR *oldP; /* pointer to previous area */
long newSize; /* new size for area */

{   char FAR *newP; /* pointer to new area */
    struct mem_hdr FAR *oldA; /* pointer to current (old) block header */
    struct mem_hdr FAR *prevA; /* pointer to previous (in memory) header */
    long xferSize;

t_check();

    /* determine size to transfer */

    oldA = (struct mem_hdr FAR *)(oldP-sizeof(struct mem_hdr));
    xferSize = newSize;
    if (oldA->logical < newSize)
        xferSize = oldA->logical;

    /* allocate new block and transfer data */

    newP = t_malloc(newSize);
    if (!newP)
        return(NULL);
    TUTORblock_move(oldP,newP,xferSize);
    t_free(oldP); /* release previous block */
    return(newP);

} /* t_realloc */

/* ******************************************************************* */

int t_check() /* check memory chain */

{   struct mem_hdr FAR *nextA; /* pointer to next block */
    long nextL; /* address of block as long */
    int foundLast;  /* TRUE if found last (malloc) block */
    
    nextA = first_area;
    foundLast = FALSE;
    while(nextA) {
         if (nextA == last_area)
             foundLast = TRUE;
         if ((nextA->length < 0) || (nextA->length > 100000L))
            TUTORdump("(t_check) bad length in memory chain");
        nextA = nextA->next_area;
        nextL = (long)nextA;
        if (!nextL && !foundLast)
            TUTORdump("(t_check) memory chain broken");
        if ((nextL == 0xffff0000L) || (nextL == 0xffffffffL))
            TUTORdump("(t_check) bad address in memory chain");
    }
} /* t_list */

/* ******************************************************************* */

int t_list() /* print memory chain */

{   struct mem_hdr FAR *nextA; /* pointer to next block */
    
    printf("memory chain\n");
    nextA = first_area;
    while(nextA) {
        printf("area %lx length %ld logical %ld next %lx used %ld\n",nextA,nextA->length,nextA->logical,nextA->next_area,nextA->used);
        nextA = nextA->next_area;
    }
} /* t_list */

/* ******************************************************************* */
