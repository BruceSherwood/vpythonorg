
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University. */

#include "execdefs.h"
#include "eglobals.h"
#include "tglobals.h"
#include "txt.h"
#include "exprdefs.h"
#include "fkeys.h"
#include "kglobals.h"
#include "editor.h"
#include "kdefs.h"
#include "txtv.h"
#include "commands.h"
#include "editmenu.h"
#include "ecglobal.h"

#ifdef MAC
#ifdef THINKC5
#include <Quickdraw.h>
#endif
#endif

/* ******************************************************************* */

#ifdef ctproto
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,
 int ebsref,struct  _trect *theR,int  relInfo,int  mintw,int  wrap,
 unsigned int  doc,long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),
 int  ro,int  corner,int  erase,int  frame,int tabsz,int lm,int rm,int inhss,int type);
int  GetUnitName(int  unitn,unsigned char  *name);
extern int inhibit_objects(int type);
extern int inhibit_editdraw(int type);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
int  TUTORfill_abs_rect(struct	_trect FAR *tr,int  pattInd,int  pattC);
int  TUTORclose_doc(unsigned int  doc);
unsigned int  TUTORnew_doc(int  string,int  honorP);
extern int plotText(Memh doc,long start,long end);
int  write_abs_text(unsigned int  textDoc,long  startSel,long  endSel,int  xstart,int  ystart,struct  _trect FAR *marginR,int  wrap,int  *maxX,int  *maxY);
int  RoundCoord(long  xx);
extern int TUTORset_sub_new(int sub,int new);
extern int iexec_option_menu(void);
int  TUTORflush(void);
extern void TUTORset_color(int select,struct tutorColor FAR *newColor);
int  TUTORforward_window(int  wix);
extern int checkRadians(void);
int  TUTORdraw_arc(int  calledby,long xc,long yc,double radius,long  x1,long  y1,long  x2,long  y2,
 double  startAngle,double  stopAngle,int  unbroken);
extern int  TUTORhsv_to_rgb(double  hue,double  saturation,double  value,double  *red,double  *green,double  *blue);
extern int TUTORset_color_rgb(int select,int SysOrPal,double rr,double gg,double bb);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORpost_event(struct  tutorevent *event);
int  TUTORdealloc(char  FAR *ptr);
extern int clearkeys(void);
extern int TUTORpoll_events(int block);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  marker_file_name(struct  markvar FAR *mx,struct  _fref FAR *fullRef,int  symbolic);
extern int TUTORinq_slider_busy(void);
extern int TUTORinq_abs_string_width(unsigned char FAR *ss, int lth, int *dx);
extern int post_event_unit(void);
extern int arraybnds(void);
int  TUTORset_cursor(int  cInd,int  cChar);
int  DrawPanel(unsigned int  edH);
int  TUTORclose_panel(unsigned int  theV);
int  TUTORdefault_styles_font_doc(int  font,unsigned int  doc);
extern int argtextm(int type);
extern int TUTORtrace(char *str);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,int ebsref,
 struct  _trect *theR,int  relInfo,int  mintw,int  wrap,unsigned int  doc,
 long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),int  ro,int  corner,int  erase,
 int  frame,int tabsz,int lm,int rm,int inhss,int type);
extern int cmd_showz(void);
extern int cmd_showe(void);
extern int zeshow(int type);
extern int ws_txt_str(char *str);
extern int EqFloat(double v1,double v2);
extern int TstIndefinite(double value);
int ex_arrayerr(void);
extern int FinishPicture(void);
extern int TUTORinq_icon_code_size(int iconFont);
int  myexit(void);
int  cmd_brancht(void);
int  cmd_branchf(void);
int  cmd_branch(void);
int  cmd_color(void);
int  xlegal_color(int  colorn);
int  cmd_at(void);
int  cmd_atnm(void);
int  cmd_dot(void);
int  cmd_draw(void);
int  cmd_fill(void);
int  cmd_erase(void);
int  cmd_erasep(void);
int  cmd_circle(void);
int  cmd_circleb(void);
int  cbcircle(int  type);
int  cmd_disk(void);
int  cmd_box(void);
int  cmd_vector(void);
int  cmd_plot(void);
int cmd_ploti(void);
int  cmd_move(void);
int  cmd_rmove(void);
int  cmd_gmove(void);
int  argmove(int  type);
int  cmd_randu(void);
int  cmd_inhibit(void);
int  cmd_allow(void);
int  inhalw(int  type);
int  cmd_mode(void);
int  cmd_pause(void);
int  cmd_menu(void);
int  cmd_begintext(void);
int  cmd_begintext1(void);
int  cmd_begintext4(void);
extern int  BeginText(int  flag);
int  cmd_begintext2(void);
int  cmd_begintext3(void);
int  cmd_endtext(void);
int  cmd_endtext1(void);
int  cmd_endtext2(void);
int  cmd_wrapstyle(void);
int  cmd_write(void);
int  cmd_write1(void);
int  cmd_write2(void);
int  cmd_show(void);
int  cmd_showb(void);
int  cmd_showo(void);
int  cmd_showh(void);
int  cmd_showt(void);
int  ShowTOffset(unsigned int  doc,long  pos,int  nDig,int  nMin);
int  cmd_text(void);
int  cmd_rtext(void);
int  cmd_gtext(void);
int  cmd_textm(void);
int  cmd_rtextm(void);
int  cmd_gtextm(void);
int  argtext(int  type);
int  cmd_string(void);
int  cmd_append(void);
int  cmd_replace(void);
int  cmd_zero(void);
int  cmd_zerom(void);
extern int  xzero(int  type);
int  cmd_set(void);
int  cmd_setc(void);
int  cmd_compute(void);
int  cmd_markpt(void);
int  cmd_cond(void);
int  cmd_condout(void);
int  cmd_case(void);
int  cmd_caset(void);
int  cmd_casem(void);
int  cmd_clause(void);
int  cmd_endcase(void);
int  cmd_calc(void);
int  cmd_iloop1init(void);
int  cmd_iloopinit(void);
int  cmd_icloopinit(void);
int  cmd_iloop1(void);
int  cmd_iloopinc(void);
int  cmd_floopinit(void);
int  cmd_floopinc(void);
int cmd_objw(void);
int  cmd_do(void);
int   cmd_jump(void);
int  xdojmp(int  type);
int  cmd_endunit(void);
int  cmd_next(void);
int  cmd_back(void);
int  cmd_jumpout(void);
int  cmd_outunit(void);
int  cmd_slice(void);
int  cmd_dmp(void);
int  cmd_cmds(void);
int  cmd_old(void);
int  TUTORline_to(long  x,long  y);
int  TUTORmove_to(long  x,long  y);
int  flush(void);
int  TUTORdraw_dot(long  x1,long  y1);
int  execerr(char  *msgstr);
int  CTset_background_color(int  color);
int  CTset_foreground_color(int  color);
int  TUTORfill_disk(int type,long xc,long yc,long  x1,long  y1,long  x2,long  y2);
long  IntToCoord(int  xx);
int  arc(long  radius,double  angle1,double  angle2,int  unbroken);
long  FloatToCoord(double  zz);
int  setmode(int  m);
int  TUTORerase_solid_rect(long  x1,long  y1,long  x2,long  y2);
int  FullScreenErase(void);
int  TUTORfill_polygon(int  npoints,long  *fx,long  *fy);
int  TUTORfill_rectangle(long  x1,long  y1,long  x2,long  y2);
int  graph_to_fine(double  gx,double  gy,long  *cx,long  *cy);
int  relative_to_fine(double  rx,double  ry,long  *cx,long  *cy);
long  DivCoord(long  xx,long  yy);
int  TUTORinq_abs_pen_pos(int  *x,int  *y);
int  TUTORdraw_icons(char  *is,int  len);
int  makevector(long  xtail0,long  ytail0,long  xpoint0,long  ypoint0,double  type);
int  makebox(int  tgiven,long  x1,long  y1,long  x2,long  y2,int  thick);
int  setclip(void);
int  TUTORabs_line_to(int  x,int  y);
int  TUTORabs_move_to(int  x,int  y);
int  lclocy(long  q);
int  lclocx(long  q);
int  unclip(void);
extern int TUTORzero(char SHUGE *ptr,long lth);
int  setkey(int  cc);
int  SetFlushState(int  flag);
int  enabledisplay(void);
int  inhibitdisplay(void);
int  defaultinhibit(void);
int  fputvar(unsigned char SHUGE *vaddr,int  vkind,double  fvalue);
extern int rand(void);
int  Randum(int  begin,int  end);
int  sync(void);
int  TUTORclear_doc(unsigned int  doc);
unsigned int  dtextv(void);
int  TUTORadd_menu(unsigned int  barh,char  *card,int  cp,char  *item,int  ip,int  keyBind,int  type,int  unit,double  unitArg,int  eType);
int  translate_ct_string(unsigned char  *s0);
int  TUTORdelete_menu(unsigned int  barh,char  *card,char  *item);
int  DeleteAllAuthorMenus(void);
int  MakeMenus(void);
int  TriggerEventTime(int  (*routine)(),long  t);
int  TimedPauseStub(void);
int  PauseMenus(void);
int  enable(int  bits);
int  settouchkey(struct  tutorevent FAR *event);
int  RunOnEvent(struct  tutorevent FAR *event);
long  get_exec_pt(void);
int  TUTORinq_font_info(int  *ascent,int  *descent,int  *maxwidth,int  *leading);
int  TUTORset_abs_clip_rect(struct  _trect FAR *cr);
int  TUTORabs_move(int  x,int  y);
int  TUTORdraw_text(unsigned char  FAR *buf,int  count);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
int  TUTORset_rect(struct  _trect *r,int  left,int  top,int  right,int  bottom);
int  TUTORset_textfont(int  jj);
int  TUTORintersect_rect(struct  _trect FAR *r1,struct  _trect FAR *r2,struct  _trect FAR *rdest);
int  TUTORinq_abs_clip_rect(struct  _trect *cr);
int  TUTORdump(char  *s);
int  writetext(unsigned int  textDoc,long  startSel,long  endSel,int  nDig,int  nMin);
int  mvar_temp_cleanup(void);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
int  TUTORdelete_doc(unsigned int  doc,long  pos,long  len,long  *extraPos);
int  TUTORstyle_doc(unsigned int  doc,long  pos,long  len,int  type,int  dat,int  canCombine,long  *extraPos);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
int  TUTORshow(int type,double  value,int  sigfig,char  *ss);
extern double fabs(double x);
int  TUTORinq_abs_string_width(unsigned char  FAR *s,int  lth,int *dx);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  _TUTORset_textfont_doc(struct  _ktd FAR *dp,short  *curStyles);
int  _TUTORget_styles_doc(struct  _ktd FAR *dp,long  pos,short  *curStyles);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORshowt(double  value,int  nBefore,int  nAfter,int  showperiod,char  *s);
int  exec_text(void);
int  mvar_assign(struct markvar SHUGE  *vaddr,struct  markvar SHUGE *mx);
int  mvar_init(struct  markvar FAR *mp);
long  ResetTextSize(int  force,int  showmessage);
int  iputvar(unsigned char SHUGE *vaddr,int  vkind,long  ivalue);
int  sizetv(int  opc);
int  mvar_replace(struct  markvar FAR *mx,struct  markvar FAR *my);
int  mvar_append(struct  markvar FAR *mx,struct  markvar FAR *my);
int  set_exec_pt(unsigned int  uloc);
double  evalduser(struct  markvar FAR *mx);
int  fuzzylt(double  x,double  y);
int  fuzzygt(double  x,double  y);
int  fuzzyeq(double  x,double  y);
int  mvar_compare(struct  markvar FAR *ma,struct  markvar FAR *mb,int  exact);
int  InsureUnit(int  unitn);
int  init_array_desc(int  unitn,long  stacki);
int  assign_pfun(long  addr,long  pfunct);
int  ReallocStack(long  newl);
int  InitMainUnit(int  reshape,int  ieu);
int  items_close(int  unitn,long  stacki,int  vars,int  graphics);
int  unstack_all_units(void);
int  CloseLocalFiles(void);
int CloseUnitLocalFiles(void);
int  FullHalt(void);
int  Halt(void);
int  EndUnitMenus(void);
int  TUTORforce_redraw(int  wix);
int  shouldint(void);
int  stacks(long  lvalue);
int  mvar_ref_doc(unsigned int  docH);
long  unstacks(void);
int  unstackblock(unsigned char  *addr,int  length);
int  CloseArrow(int  eFlag);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  assoc_name(struct  _fref FAR *fn,struct  _fref FAR *bfilen,char  *extnNew);
int  TUTORclose(int  findx);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
extern int sprintf(char *ss, char *form, ...);
extern int printf(char *form, ...);
#endif

extern long TUTORget_len_doc();
extern long l_bin();
extern long l_read();
extern double f_bin();
extern double f_read();
extern long array_addr();
extern  double lcfsysv();
extern  long lcmsysa();
extern  long lcbitcnt();
extern double CoordToFloat();
extern long pass_addr();
extern long get_exec_pt();
extern  int TimedPauseStub();
extern double evalduser();
extern Memh darrowv(); /* handle on arrow text */
extern Memh dtextv();   /* handle on displayed text */
extern  Coord IntToCoord();
extern  Coord FloatToCoord();
extern  Coord DivCoord();
extern  long TUTORwrite();
extern char FAR *GetPtr();
extern  long TUTORread();
extern long lcftoi();
extern Memh TUTORcopy_handle();
extern long TUTORinq_msec_clock();
extern unsigned char interactDepth;
extern char FAR *TUTORalloc();

/* ******************************************************************* */

extern int execrun; /* executor run/return flag */

#ifndef long_align
#define long_read(addr) (*(long SHUGE *)(addr))
#define flt_read(addr) (*(double SHUGE *)(addr))
#else
#define long_read(addr) (l_read(addr))
#define flt_read(addr) (f_read(addr))
#endif

/* ------------------------------------------------------------------- */

long txt_count; /* number characters text output */
static long *txt_stacki; /* base position in integer stack for embedded commands */
static double *txt_stackf; /* base pos in floating stack for embeds */
static struct markvar FAR *txt_stackm; /* base pos in marker stack for embeds*/
static int txt_indentDig, txt_indentMin; /* indentations for -showt- */
static long txt_wraploc; /* starting position for WRAPSTYLES */
static char txt_string; /* TRUE if string operation, FALSE if display */
static char txt_simpleshow; /* TRUE if current show is simple */
static Memh txt_doc; /* handle on text document building = 0 if in-line */
static long txt_pos; /* where we want to write from txt_doc (len is txt_count) */
unsigned char txt_buffer[WRT_TXT_LTH+2]; /* buf for simple text (also used by arrow) */

/* ******************************************************************* */

cmd_brancht() /* conditional branch on true */

{   int branch;

    branch = *(--iresP);
    if (*(--iresP) < 0) {
        ex_binP = (short FAR *)(pcodep+branch);
            	
        /* check if should interrupt */

    	if ((++exS.loopcounter > 50) || exS.outcnt || exS.shouldint) { 
			exS.loopcounter = 0;
			exS.uloc = branch; /* set relative address */
			if (shouldint() || (exS.outcnt > 10)) {
	    		execrun = FALSE; /* return from executor */
	    		waitflag = atinterrupt;
			}
    	}
    }

} /* cmd_brancht */

/* ------------------------------------------------------------------- */

cmd_branchf() /* conditional branch on false */

{   int branch;

    branch = *(--iresP);
    if (*(--iresP) >= 0) {
        ex_binP = (short FAR *)(pcodep+branch);
        
    	/* check if should interrupt */

    	if ((++exS.loopcounter > 50) || exS.outcnt || exS.shouldint) { 
			exS.loopcounter = 0;
			exS.uloc = branch; /* set relative address */
			if (shouldint() || (exS.outcnt > 10)) {
	    		execrun = FALSE; /* return from executor */
	    		waitflag = atinterrupt;
			}
    	}
    }

} /* cmd_cbranchf */


/* ------------------------------------------------------------------- */

cmd_branch() /* unconditional branch */

{   int branch;

    branch = *(--iresP);
    ex_binP = (short FAR *)(pcodep+branch);

    /* check if should interrupt */

    if ((++exS.loopcounter > 50) || exS.outcnt || exS.shouldint) { 
		exS.loopcounter = 0;
		exS.uloc = branch; /* set relative address */
		if (shouldint() || (exS.outcnt > 10)) {
	    	execrun = FALSE; /* return from executor */
	    	waitflag = atinterrupt;
		}
    }

} /* cmd_branch */

/* ------------------------------------------------------------------- */

cmd_color() /* -color- command execution */

{   register int nn;
    int ii; /* index in integer stack */
    int fi; /* index in floating stack */
    int colorn,colorc;
    int SysOrPal; /* look in system or our palette */
    double red,green,blue;
    double hue,sat,val;

    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* pop stacks */
    fresP = fstack;
    ii = fi = 0;

	/* handle palette form */
	
    if (istack[0] < 2) {
    	ii = 1; /* index of first color */
    	if (istack[0]) { /* 1st argument present */
        	colorn = istack[ii++];
        	xlegal_color(colorn);
        	CTset_foreground_color(colorn);
        	ExecVp->fgndColor = fgndColor;
    	}
    	if (ii < nn) { /* 2nd argument present */
        	colorn = istack[ii];
        	xlegal_color(colorn);
        	CTset_background_color(colorn);
        	ExecVp->bgndColor = bgndColor;
    	}
    	return(0); /* done with palette form */
    }
    
    /* handle rgb/hsv forms */
    
    colorc = 0; /* 0 = foreground, 1 = background */
    while ((colorc < 2) && (ii < nn)) {
    	if (istack[ii] == 2) { /* rgb */
    		ii++;
    		SysOrPal = istack[ii++];
    		red = fstack[fi++];
    		green = fstack[fi++];
    		blue = fstack[fi++];
    		colorn = TRUE; /* have color value */
    	} else if (istack[ii] == 3) { /* hsv */
    		ii++;
    		SysOrPal = istack[ii++];
    		hue = fstack[fi++];
    		sat = fstack[fi++];
    		val = fstack[fi++];
    		TUTORhsv_to_rgb(hue,sat,val,&red,&green,&blue);
    		colorn = TRUE; /* have color value */
    	} else {
    		ii++;
    		colorn = FALSE; /* argument not present */
    	}
	if (colorn) {
	    TUTORset_color_rgb(colorc,SysOrPal,red,green,blue);
	    if (colorc == 0)
	    	ExecVp->fgndColor = fgndColor;
	    else if (colorc == 1)
	    	ExecVp->bgndColor = bgndColor;
	}
    	colorc++; /* 1 = background */
    } /* while */	

} /* cmd_color */

xlegal_color(colorn) /* check color value legal */
register int colorn;

{
    if ((colorn < -2) || (colorn > 255))
        execerr("Invalid color index.");

} /* xlegal_color */

/* ------------------------------------------------------------------- */

cmd_at() /* -at- command execution */

{   register long x1,y1,x2,y2;
    long tt;
    int ii,nn;

    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* pop stack */
    exS.ScreenX = x1 = istack[0]; /* get position/left margin */
    exS.ScreenY = y1 = istack[1];
    if (nn == 4) {
        x2 = istack[2]; /* get right margin */
        y2 = istack[3];         
    } else {
        x2 = exS.RegionXmax; /* get default right margin */
        y2 = exS.RegionYmax;
    } /* nn else */

    /* adjust so that x1,y1 is upper left of area */

    if (x1 > x2) {
        tt = x1; /* swap x1,x2 */
        x1 = x2;
        x2 = tt;
    }
    if (y1 > y2) {
        tt = y1; /* swap y1,y2 */
        y2 = y1;
        y1 = tt;
    }

    /* set margins */

    exS.MarginBeginX = x1;
    exS.MarginEndX = x2;
    exS.MarginBeginY = y1;
    exS.MarginEndY = y2;
        
} /* cmd_at */

/* ------------------------------------------------------------------- */

cmd_atnm() /* -atnm- command execution */

{
    exS.ScreenY = *(--iresP); 
    exS.ScreenX = *(--iresP);

} /* cmd_atnm */

/* ------------------------------------------------------------------- */

cmd_dot() /* -dot- command execution */

{   register long xx,yy;
    register int ii,nn;
	Coord radius;

    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* pop stack */
    
    for(ii=0; ii<nn; ii += 2) {
        xx = (istack[ii]);
        yy = (istack[ii+1]);
		TUTORdraw_dot(xx,yy);
    } /* for */
	exS.ScreenX  = xx;
	exS.ScreenY = yy;
    exS.outcnt += nn;
    OUTGO;

} /* cmd_dot */

/* ------------------------------------------------------------------- */

cmd_draw() /* -draw- command execution */

{   register long xx,yy;
    long ox,oy;
    int opt, lastop;
    register int ii,nn;

    nn = iresP-istack; /* number items on stack */
    iresP = istack;
    
    ii = lastop = 0;
    while(ii < nn) {
        xx = istack[ii++];
        yy = istack[ii++];
        opt = istack[ii++];
        if (opt == TPOINT) {
            if (ii == 3) TUTORmove_to(xx,yy);
            else {
                if (exS.startdrawcnt > 0) { /* -inhibit startdraw- */
                    exS.startdrawcnt--; 
                    TUTORmove_to(xx,yy);
                opt = -1;
                } else TUTORline_to(xx,yy);
            } /* ii else */
        } else if (opt == TDOT) {
            if (exS.startdrawcnt > 0) { /* -inhibit startdraw- */
                exS.startdrawcnt--; 
                TUTORmove_to(xx,yy);
            } else TUTORdraw_dot(xx,yy);
        } else { /* skip */
            if ((exS.mode == xormode) && (lastop == TPOINT)){
                TUTORdraw_dot(ox,oy);
            } /* xor if */
            TUTORmove_to(xx,yy);
        }
        lastop = opt;
        ox = xx;
        oy = yy;
    }
    if ((exS.mode == xormode) && (lastop == TPOINT)){
    	;
        /* TUTORdraw_dot(xx,yy); on mac, also done in tgraph? */
    } /* xor if */
        exS.ScreenX  = xx;
        exS.ScreenY = yy;
        exS.outcnt += nn;
    OUTGO;

} /* cmd_draw */

/* ------------------------------------------------------------------- */

cmd_fill() /* -fill- command execution */

{   register int ii,jj,nn;
    Coord fxarray[FILLPOINTS+2]; /* arrays for -fill- */
    Coord fyarray[FILLPOINTS+2];
    TRect tr;

    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* pop stack */

    if (nn == 0) { /* blank tag form */
	unclip();
	tr.left = tr.top = 0;
	tr.right = windowsP[ExecWn].wxsize;
	tr.bottom = windowsP[ExecWn].wysize;
	TUTORfill_abs_rect(&tr, exS.patternFont, exS.patternChar);
	setclip();
	return;
    }

    ii = 0;
    jj = 1;
    while (ii < nn) {
        fxarray[jj] = istack[ii++];
        fyarray[jj++] = istack[ii++];
    } /* while */
    if (nn == 2) /* single point case */
        TUTORdraw_dot(fxarray[1],fyarray[1]);
    else if (nn == 4) /* 2-point (rectangle) */
        TUTORfill_rectangle(fxarray[1],fyarray[1],fxarray[2],fyarray[2]);
    else TUTORfill_polygon(jj-1,fxarray,fyarray);
    exS.ScreenX = fxarray[1];
    exS.ScreenY = fyarray[1];
        exS.outcnt += nn;
    OUTGO;

} /* cmd_fill */
     
/* ------------------------------------------------------------------- */

cmd_erase() /* -erase- command (full screen or coarse grid) execution */

{   register int nn;
    int nchars; /* number coarse-grid chars to erase */
    int nrows; /* number coarse-grid rows to erase */
    Coord x2,y2; /* lower right for erase */
    
    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* pop stack */

    /* process full screen erase */

    if (nn == 0) { /* no arguments */
        FullScreenErase();
        exS.ScreenX = exS.RegionXmin; /* set to upper-left */
        exS.ScreenY = exS.RegionYmin;
        return(0);
    }  /* nn if */

    /* process coarse-grid erase */

    nchars = istack[0]; /* characters to erase */
    if (nn > 1) nrows = istack[1]; /* rows to erase */
    else nrows = 1;
    x2 = exS.ScreenX+IntToCoord((int)(nchars*exS.CoarseW));
    y2 = exS.ScreenY+IntToCoord((int)(nrows*exS.CoarseH));
    TUTORerase_solid_rect(exS.ScreenX,exS.ScreenY,x2,y2);
    flush();
 
} /* cmd_erase */

/* ------------------------------------------------------------------- */

cmd_erasep() /* -erase- command (area) execution */

{   register int oldmode;

    oldmode = exS.mode; /* save current write/erase mode */
    setmode(erasemode);
    cmd_fill(); /* format is same as fill command */  
    setmode(oldmode);

} /* cmd_erasep */

/* ------------------------------------------------------------------- */

cmd_circle()  { cbcircle(1); } /* -circle-  command execution */
cmd_circleb() { cbcircle(0); } /* -circleb- command execution */

cbcircle(type) /* circle, circleb command exectutions */
int type; /* 1 = solid lines circle, 0 = broken lines circle */ 

{   Coord radius;
    double sangle; /* starting angle */
    double eangle; /* ending angle */
    int ni; /* items on integer stack */
    int nf; /* items on floating stack */

	ni = iresP-istack; /* number items on integer stack */
	iresP = istack;
    nf = fresP-fstack; /* number items on floating stack */
    fresP = fstack; 

	if (istack[0] == 0) { /* radius form */
	
		/* handle radius form of command */
		
    	radius = FloatToCoord(fstack[0]); /* radius */
    	if (nf == 1) { /* complete circle */
        	sangle = 0.0; /* start angle  */
        	eangle = 360.0; /* end angle   */
    	} else { /* arc (partial circle) */
    		if (checkRadians()) {
				fstack[1] = fstack[1]/RDN; /* convert to degrees */
				fstack[2] = fstack[2]/RDN;
			}
        	sangle = fstack[1];
        	eangle = fstack[2];
    	}
    	arc(radius,sangle,eangle,type);
    } else { /* rectangle form */
    
    	/* handle rectangle form of command */

		TUTORdraw_arc(4,coordZero,coordZero,0.0, 
	              istack[1], istack[2],istack[3], istack[4], 
		          0.0,0.0,type); 
    }

} /* cbcircle */

/* ------------------------------------------------------------------- */

cmd_disk() /* -disk- command execution */

{   Coord radius;

	iresP = istack; /* pop stack */
	if (istack[0] == 0) { /* radius form */
    	radius = IntToCoord((int)(istack[1])); /* radius */
    	TUTORfill_disk(0,exS.ScreenX,exS.ScreenY,exS.ScreenX-radius,exS.ScreenY-radius,
                   exS.ScreenX+radius,exS.ScreenY+radius);
    } else { /* rectangle form */
        TUTORfill_disk(1,0,0,istack[1],istack[2],istack[3],istack[4]);
    }
    flush();
	exS.outcnt += 2;

} /* cmd_disk */

/* ------------------------------------------------------------------- */

cmd_box() /* -box- command execution */

{   register int ax1,ay1,ax2,ay2;
    int thick,thicks;
    int nn;

    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* pop stack */
    
    if (nn == 0) { /* blank tag form */
        unclip();  /* draw frame 1 pixel outside display area */
        ax1 = exS.OffsetX+(int)lclocx(exS.RegionXmin)-1;
        ay1 = exS.OffsetY+(int)lclocy(exS.RegionYmin)-1;
        ax2 = exS.OffsetX+(int)lclocx(exS.RegionXmax)+1;
        ay2 = exS.OffsetY+(int)lclocy(exS.RegionYmax)+1;
        TUTORabs_move_to(ax1,ay1);
        TUTORabs_line_to(ax2,ay1);
        TUTORabs_line_to(ax2,ay2);
        TUTORabs_line_to(ax1,ay2);
        TUTORabs_line_to(ax1,ay1);
        setclip();
    } else {
        if (nn > 4) {
            thick = istack[4];
            thicks = TRUE; /* thick explicitely specified */
        } else {
            thick = 1;
            thicks = FALSE;
        }
        makebox(thicks,istack[0],istack[1],istack[2],istack[3],thick);
    } /* box */

    exS.outcnt += 4;   
    OUTGO;

} /* cmd_box */

/* ------------------------------------------------------------------- */

cmd_vector() /* -vector- command execution */

{   double headsz;
    register int nf;

    nf = fresP-fstack;
    iresP = istack; /* pop stacks */
    fresP = fstack;
    
    if (nf) headsz = fstack[0];
    else headsz = 0;
    makevector(istack[0],istack[1],istack[2],istack[3],headsz);

} /* cmd_vector */

/* ------------------------------------------------------------------- */

cmd_plot() /* -plot- command execution */

{   register int nn;
    int ii;
    int si; /* index in string */
    int ix,iy; /* initial screen position */
    int rx,ry; /* final screen position */
    int is16bit; /* TRUE if 16-bit 'characters' */
    char str[120]; /* output string (60 char max) */
 
    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* pop stack */

    /* check if 16-bit characters */
    
    is16bit = TUTORinq_icon_code_size(exS.iconFont);
    si = 0; /* index in string */
    if (!is16bit) {
        for(ii=0; ii<nn; ii++) /* build string */
            str[si++] = istack[ii];
    } else {
        for(ii=0; ii<nn; ii++) { /* build string of 16-bit chars */
            str[si++] = (istack[ii] >> 8) & 0xff;
            str[si++] = istack[ii] & 0xff;
        } /* for */
    } /* is16bit else */
    str[si] = '\0';

    TUTORmove_to(exS.ScreenX, exS.ScreenY);
    TUTORinq_abs_pen_pos(&ix,&iy);
    TUTORdraw_icons(str,si);
    TUTORinq_abs_pen_pos(&rx,&ry);
    exS.ScreenX += DivCoord(IntToCoord(rx-ix),exS.ScaleX);
    exS.ScreenY += DivCoord(IntToCoord(ry-iy),exS.ScaleY);
    exS.outcnt += nn;
    OUTGO;

} /* cmd_plot */

/* ------------------------------------------------------------------- */

cmd_ploti() /* -plot- command execution (embedded image) */

{	int xstart,ystart; /* start of draw, in pixels */
	TRect marginR;
	Memh textH;
	long pos,len;
	long extraPos;
	Coord mx1,my1,mx2,my2; /* saved margins */
	
	iresP = istack;
	markP = markstack;
	
	/* save margins, set to whole region */
	
	mx1 = exS.MarginBeginX;
	my1 = exS.MarginBeginY;
	mx2 = exS.MarginEndX;
	my2 = exS.MarginEndY;
	exS.MarginBeginX = exS.RegionXmin;
	exS.MarginEndX = exS.RegionXmax; 
	exS.MarginBeginY = exS.RegionYmin;
	exS.MarginEndY = exS.RegionYmax;

    /* plot text with embedded image */
    		
	pos = istack[0]+unittab[exS.execunit].textp;
	len = istack[1];
	textH = TUTORnew_doc(TRUE,TRUE);
	TUTORdefault_styles_font_doc(exS.baseFont,textH);
    TUTORchange_doc_doc(textH,0L,0L,0L,0L,
                        textpool,pos,len,&extraPos,TRUE);
	plotText(textH,0L,len);	
	TUTORclose_doc(textH);
	
	/* restore margins */	
	
    exS.MarginBeginX = mx1;
    exS.MarginEndX = mx2;
    exS.MarginBeginY = my1;
    exS.MarginEndY = my2;
	OUTGO;
	
} /* cmd_ploti */

/* ------------------------------------------------------------------- */

cmd_move()  { argmove(0); } /* -move- command execution */
cmd_rmove() { argmove(1); } /* -rmove- command execution */
cmd_gmove() { argmove(2); } /* -gmove- command execution */

argmove(type) /* move, rmove, gmove commands */
int type; /* 0 = move, 1 = rmove, 2 = gmove */

{   register int nn;    /* number of arguments on integer stack */
    int nfrom; /* number icons in erase list */
    int nto; /* number icons in plot list */
    long fromx,fromy; /* from position */
    long tox,toy; /* to position */
    int fromi; /* stack index of from icons list */
    int toi; /* stack index of to icons list */
    char fromstr[40]; /* erase icons list */
    char *tostr; /* plot icons list */
    char tostrx[40]; /* plot icons list */
    int ii;

    nn = iresP-istack;
    iresP = istack;
    fresP = fstack;

    nfrom = istack[nn-2]; /* number icons in from list */
    nto = istack[nn-1]; /* number icons in to list */

    /* build from icons string from stack */

    fromi = ((type == 0) ? 4: 0); /* start of from icons list in stack */
    for(ii=0; ii<nfrom; ii++) {
        fromstr[ii] = istack[fromi+ii];
    } /* for */
    fromstr[ii] = '\0';

    /* build to icons string from stack */

    if (nto) {
        toi = fromi+nfrom; /* start of to icons list in stack */
        tostr = &tostrx[0]; 
        for(ii=0; ii<nto; ii++) {
            tostr[ii] = istack[toi+ii];
        } /* for */
        tostr[ii] = '\0';
    } else { /* no to list */
        nto = nfrom;
        tostr = &fromstr[0]; /* set to list = from list */
    } /* else */

    /* get from and to co-ordinates */

    if (type == 0) {
        fromx = istack[0];  
        fromy = istack[1];
        tox = istack[2];
        toy = istack[3];
    } else if (type == 1) {
        relative_to_fine(fstack[0],fstack[1],&fromx,&fromy);
        relative_to_fine(fstack[2],fstack[3],&tox,&toy);        
    } else {
        graph_to_fine(fstack[0],fstack[1],&fromx,&fromy);
        graph_to_fine(fstack[2],fstack[3],&tox,&toy);
    } /* else */

    exS.ScreenX = tox;
    exS.ScreenY = toy;

    if (exS.startdrawcnt > 0) { /* inhibit startdraw */
        exS.startdrawcnt--;
    } else {
        switch (exS.mode) {
        case writemode: 
            setmode(erasemode); 
            break;
        case erasemode: 
            setmode(writemode); 
            break;
        case rewritemode: 
            setmode(erasemode); 
            break;
        case inversemode: 
            setmode(writemode); 
            break;
        } /* switch */
        TUTORmove_to(fromx,fromy);
        TUTORdraw_icons(fromstr,nfrom);
    } /* startdrawcnt else */
    
    setmode(exS.mode);
    TUTORmove_to(tox,toy);
    TUTORdraw_icons(tostr,nto);
    TUTORmove_to(tox,toy);
    sync(); 

} /* argmove */

/* ------------------------------------------------------------------- */

cmd_randu() /* -randu- command execution */

{   register int inn;   
    double randv; /* random value */
    register int range; /* random range */
    int vkind; /* variable kind */
    unsigned char SHUGE *vaddr; /* variable address */

    inn = iresP-istack; /* number items on integer stack */
    iresP = istack; /* pop stacks */
    fresP = fstack;

    vkind = istack[1]; /* storeable variable kind */
    vaddr = (unsigned char SHUGE *)istack[2];

    if (inn > 4) { /* range argument present */
        range = istack[4];
        if (range < 1) 
            execerr("Range of -randu- must be 1 or greater.");
        randv = Randum(1,range);
    } else {
#ifdef ANDREW
        /* 2147483648 is 2**31; random() range is 0 to 2**31-1 */
        randv = ((double)random()+1.0)/2147483648.0;
#endif
#ifdef IBMPC
        /* PC rand() range is 0 to +32767 */
        randv = ((double)rand()+1.0)/32768.0;
#endif
#ifdef MAC
        /* Mac Random() range is -32767 to +32767 */
        randv = ((double)Random()+32768.0)/65535.0;
#endif
    } /* nn else */

    /* store random value in author variable */

    fputvar(vaddr,vkind,randv);

} /* cmd_randu */

/* ------------------------------------------------------------------- */

cmd_inhibit() { inhalw(0); } /* -inhibit- command execution */
cmd_allow()   { inhalw(1); } /* -allow-   command execution */

inhalw(type) /* inhibit and allow command executions */
int type; /* 0 = inhibit, 1 = allow */

{   register int nn;
    register int ii;
    register int option; /* current inhibit/allow option */
    Memh nextObjH; /* handle on next edit/button/slider object */
    Memh tmpH;
    struct ebshdr FAR *nextObjP; /* pointer to next object header */

    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* pop stack */

    if (nn == 0) { /* blank tag form */
    	exS.inhibbits = 0; 
        defaultinhibit();
        exS.startdrawcnt = 0; 
        return(0); /* done with blank tag form */
    } /* nn if */

    ii = 0; /* index in arguments */
    while (ii < nn) { /* loop thru arguments */
        option = istack[ii++];
	if (type == 0) exS.inhibbits |= 1L << option;
	else exS.inhibbits &= (~(1L << option));
        if (option == CLEAR) {
        	exS.inhibbits = 0;
            defaultinhibit();
            exS.startdrawcnt = 0;
        } else if (option == INHDISPLAY) {
            if (type == 0) inhibitdisplay(); /* inhibit */
            else enabledisplay(); /* allow */
        } else if (option == INHSTARTDRAW) {
            if (type == 0) /* inhibit */
                exS.startdrawcnt = istack[ii++];
            else exS.startdrawcnt = 0; /* allow */
        } else if (option == INHUPDATE) {
            if (type == 0) SetFlushState(0); /* inhibit */
            else SetFlushState(1); /* allow */
        } else if (option == INHOBJDEL) { /* objdelete */
		if (type == 0) exS.inhibbits |= 1L << INHERASE;
		else exS.inhibbits &= (~(1L << INHERASE));
        } else if (option == INHOPTION) {
        	if (type == 0) {
				TUTORdelete_menu(exS.execmenus,"Option",NEARNULL); /* delete Option card */
				exS.optionInhib = TRUE;
			} else if (type == 1) {
				iexec_option_menu();
	    	} /* type == 1 if */	
			TUTORflush();
        } else if (option == INHOBJECT) {
			inhibit_objects(type);
        } else if (option == INHEDITD) {
        	inhibit_editdraw(type);
        }
    } /* while */

} /* inhalw */

/* ------------------------------------------------------------------- */

cmd_mode() /* -mode- command execution */

{

    exS.mode = *(--iresP);
    setmode(exS.mode);
#ifdef DOPSCRIPT
       /* Check PostScript here, because setmode called many other times. */
      if(pscript)
          {if ( exS.mode == erasemode)        sprintf(PSbuff, "1 setgray\n\n") ; 
           else if ( exS.mode == writemode )  sprintf(PSbuff, "0 setgray\n\n") ; 
           PostScriptOutput(PSbuff) ;
          }
#endif

} /* cmd_mode */

/* ------------------------------------------------------------------- */

cmd_pause() /* -pause- command execution */

{   int nn;
    int timef; /* TRUE if timed pause */
    int keysf; /* TRUE if keys= list */
    int kcount; /* number keys in list */
    long timeval; /* milliseconds to pause */
    int bits; /* touch/enable bits */
    int ptype; /* 0 = blank, 1 = keys, 2 = time, 3 = time+keys */
    int ki; /* index to next key code in stack */   
    int kbyte,kbit; /* byte/bit for pause key bit table */
    int ii, jj;
    int etype;  /* type of event that breaks pause */
    int xkey;   /* current key */

    nn = iresP-istack;
    iresP = istack; /* void stacks */
    fresP = fstack;

    flush(); 
    exS.proc_obj_unit = 0; /* allow button/slider/hot interrupt */
    exS.hold_objectH = 0;
    if (runflag == halt)
        return(0); /* menu halted running, presumably */
    if (exS.needredraw) {
        /* force the redraw that the ieu buffered */
        TUTORforce_redraw(exS.baseView->window);
        exS.needredraw = FALSE;
    }   
    if (nn) {
        timef = istack[nn-2]; 
        keysf = istack[nn-1];
        kcount = (keysf ? istack[nn-3]: 0);
    } else { /* blank tag */
        kcount = timef = keysf = 0;
    } /* nn else */
    ptype = keysf+(timef << 1); 

    /* get time value if present, handle zero-time pause */

    if (timef) {
        timeval = 1000.0*fstack[0]; /* milliseconds */
        if (timeval == 0) {
            setkey(KTIMEUP);
            return(0); /* done with zero-length timed pause */  
        }
        if ((timeval < 0) && (ptype == 2))
            ptype = 0; /* pause -1 same as pause (no tag) */
    } /* timef if */

    /* process key list */

    bits = 0; /* no touch/ext bits yet */
    TUTORzero((char SHUGE *) exS.pausekeys,38L*sizeof(unsigned char)); /* zero bit list */
    if (keysf) {
        ki = 0; /* index in key list */
        for(ii=0; ii<kcount; ii++) {
            xkey = istack[ki++];
            if (xkey == KTOUCH) {
                bits |= istack[ki++]; /* set touch bit(s) */
            } else if (xkey == KEXT) {
                bits |= 1 << ENABLEEXT; /* set ext bit */
            } else if (xkey == KALL) {
                for(jj=0; jj<38; jj++) 
                    exS.pausekeys[jj] = 0xff; /* all keys enabled */
            } else {
                kbyte = xkey >> 3; /* index of byte */
                kbit = xkey-(kbyte << 3); /* index of bit */
                kbit = 0x80 >> kbit;
                exS.pausekeys[kbyte] |= kbit; /* set bit for this key */
            } /* else */
        } /* for */
    } /* keysf if */
    
    if (ptype == 2 || ptype == 3)
        { /* make sure KTIMEUP is a key that breaks timed pause */
        kbyte = KTIMEUP >> 3;
        kbit = 0x80 >> (KTIMEUP - ((KTIMEUP >> 3) << 3));
        exS.pausekeys[kbyte] |= kbit;
        }
    
    exS.pausetouch = bits; /* set ext/touch bits */

    /* set up to pause */

    if (bits)
        enable(exS.enablebits | bits); /* enable touch/ext */
    exS.pausetype = ptype; /* set pause type */
    exS.pauseuloc = exS.markpt; /* re-execute -pause- after menu-driven unit */
    exS.pauseuloca = get_exec_pt(); /* command after -pause- */
    waitflag = atpause;

    if (ptype != 2) { /* not simple timed pause */
        /* check to see if top event will break pause */
        if (nevents > 0 && RunOnEvent(eventque))
        { /* top event breaks pause */
            etype = eventque[0].type;
            if (etype == EVENT_FKEY)
                setkey(eventque[0].value);
            else if (etype == EVENT_KEY)
                setkey(eventque[0].keys[0]);
            else
                settouchkey(eventque);
            
            /* we've used top key event get rid of it */
            if (eventque[0].type != EVENT_KEY || eventque[0].nkeys <= 1) {
                eventque[0].type = -1; /* cancel the event */
            } else
            { /* we have to delete the key that we are using to break event
                    but keep the rest of the keys in the burst */
                eventque[0].nkeys--;
                for (ii=0; ii<eventque[0].nkeys; ii++)
                    eventque[0].keys[ii] = eventque[0].keys[ii+1];
            }
            /* already done, go to next command */
            exS.pausetype = -1;
            waitflag = runflag;
            enable(exS.enablebits); /* restore pre-pause enable condition */
            
            /* process BACK - execute unit */
            
            if (exS.zkey == KBACK && exS.backunit) {
                /* jump to back unit */
                exS.execunit = exS.backunit;
                unstack_all_units();
                InitMainUnit(FALSE,FALSE);
                if (pcodeh) {
                    ReleasePtr(pcodeh);
                    KillPtr(pcodep);
                }
                pcodeh = 0;
                InsureUnit(exS.execunit);
            } /* zkey if */
            
            return(0);
        } /* RunOnEvent if */
    } /* ptype if */

    /* there isn't already an event to break pause, finish setup */

    if (ptype != 2)
	PauseMenus(); /* this must precede TriggerEventTime */
    /* (because it calls checkkey, which can cancel trigger) */

    if (ptype >= 2) { /* timed pause */
        timeflag = TRUE; /* interact loop should look at times */
        exS.pausetimer = TriggerEventTime(TimedPauseStub,timeval);
    } /* ptype if */

    exS.loopcounter = 0; 
    execrun = FALSE; /* return from executor */
    return(0); /* wait for an event */

} /* cmd_pause */

/* ------------------------------------------------------------------- */

cmd_menu() /* -menu- command execution */

{   register int nn;
    register unsigned char *cardn; /* pointer to menu card name */
    unsigned char *itemn; /* pointer to menu item name */ 
    int clen; /* length of card string */
    int ilen; /* length of item string */
    int cprior; /* card priority */
    int iprior; /* item priority */
    int ui; /* index to unit number in istack */
    int fi; /* index to arguments in fstack */
    int unitn; /* unit number */
    double uarg; /* unit argument */
    int mcode; /* menu operation code (exec_unit or exec_unita) */

	exS.inOver = FALSE; /* allow step mode again */
    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* pop stack */
    fresP = fstack;
    exS.execmenu = TRUE; /* have executed a -menu- command */
    MakeMenus(); /* set up menus if not already set up */
    if (nn == 0) { /* blank tag form */
        DeleteAllAuthorMenus();
        return(0);
    }

    if (istack[1]) { 

        /* process card;item form */

        cardn = txt_buffer; /* point to card name */
        clen = strlen((char *) cardn);
        itemn = &txt_buffer[clen+1]; /* point to item name */
        ilen = strlen((char *) itemn);
        cprior = istack[0]; 
        iprior = istack[2];
        ui = 3; /* index of unit number */
    } else {

        /* process item only form */

        cardn = NULL; /* no card name */
        clen = 0;
        cprior = 0;
        itemn = txt_buffer; /* point to item name */
        ilen = strlen((char *) itemn);
        iprior = istack[0];
        ui = 2; /* index of unit number */
    } /* card else */
        
    if (clen > 63) { /* truncate for WM */
        cardn[63] = '\0'; 
        clen = 63;
    } /* clen if */
    if (ilen > 63) { /* truncate for WM */
        itemn[63] = '\0';
        ilen = 63;
    }

    /* get unit number and argument */

    unitn = istack[ui++];
    if (unitn < 0) {

        /* if no unit specified, delete card, item or all */

        if (!clen && !ilen) /* no card and no item */
            DeleteAllAuthorMenus();
        else {
        	if (!translate_ct_string(cardn) || !translate_ct_string(itemn))
        		execerr("Illegal character in menu command");
        	TUTORdelete_menu(exS.execmenus,(char *) cardn,(char *) itemn);
        }
        return(0);
    } 

    fi = 0; /* index in floating stack */
    if (istack[ui++]) {
        mcode = exec_unita; /* unit with argument */
        uarg = fstack[fi++]; /* get unit argument */
    } else {
        mcode = exec_unit; /* unit without argument */
        uarg = 0.0;
    }

    /* add menu card/item */

    if (!clen && !ilen)
        execerr("No card or item specified in menu command.");
    if (!translate_ct_string(cardn) || !translate_ct_string(itemn))
        execerr("Illegal character in menu command");
    TUTORadd_menu(exS.execmenus,(char *) cardn,cprior,(char *) itemn,iprior,
                  0,mcode,unitn,uarg,EVENT_MENU);
    
} /* cmd_menu */

/* ------------------------------------------------------------------- */

cmd_begintext() /* set for text commands - assemble in document */

{
	exS.inText = TRUE; /* TRUE while executing embedded -write-s */
    txt_string = FALSE; /* set display/string flag = display */
    txt_count = txt_indentDig = txt_indentMin = 0;
    txt_stacki = istack; /* set base position in stack */
    txt_stackf = fstack;
    txt_stackm = markstack;
    txt_doc = dtextv();
    txt_pos = 0L;
    txt_wraploc = -1;
    exS.arr.arrowLastR.left = -1;
    if (txt_doc && (txt_doc == dtextv()))
    	TUTORclear_doc(txt_doc); /* pre-clear document */

} /* cmd_begintext */

/* ------------------------------------------------------------------- */

cmd_begintext1() /* set up for text commands - assmeble in buffer */
    { BeginText(1); }
cmd_begintext4() /* set up for simple shows (not embedded) */
    { BeginText(4); }

static BeginText(flag)
int flag;

{
	exS.inText = TRUE; /* TRUE while executing embedded writes */
    txt_string = txt_simpleshow = txt_doc = txt_count = txt_indentDig = txt_indentMin = 0; 
    txt_stacki = istack; /* set base position in stack */
    txt_stackf = fstack;
    txt_stackm = markstack;
    txt_wraploc = exS.arr.arrowLastR.left = -1;
    if (flag == 4)
        txt_simpleshow = TRUE;

} /* cmd_begintext1 */

/* ------------------------------------------------------------------- */

cmd_begintext2() /* set up for text string commands - assemble in buffer */

{
	exS.inText = TRUE; /* TRUE while executing embedded writes */
    txt_string = TRUE; /* set display/string flag = string */
    txt_stacki = istack; /* set base position in stack */
    txt_stackf = fstack;
    txt_stackm = markstack;
    txt_doc = txt_simpleshow = txt_count = txt_indentDig = txt_indentMin = 0;
    txt_wraploc = -1;

} /* cmd_begintext2 */

/* ------------------------------------------------------------------- */

cmd_begintext3() /* set up for text commands - assemble in buffer */
                 /* allow multiple text strings in buffer */

{
	exS.inText = TRUE; /* TRUE while executing embedded -write-s */
    txt_stacki = iresP; /* set base position in stack */
    txt_stackf = fresP;
    txt_stackm = markP;
    txt_count++; /* advance past previous terminating zero */

} /* cmd_begintext3 */


/* ------------------------------------------------------------------- */

cmd_endtext() /* end of a series of text commands */

{
    exS.inText = FALSE;
    if (txt_string || !txt_count)
        return(0); /* nothing to do */
    
    /* display text */

    writetext(txt_doc,txt_pos,txt_pos+txt_count,txt_indentDig,txt_indentMin);
    exS.outcnt += txt_count;
    if (txt_doc && (txt_doc == dtextv()))
    	TUTORclear_doc(txt_doc); /* clear document */
    txt_pos = txt_count = 0;
    OUTGO;

} /* cmd_endtext */

/* ------------------------------------------------------------------- */

cmd_endtext1() /* end of a series of text commands */
    
{   int leftMar,rightMar,ystart,botMar;
    int fx,fy; /* final x,y position */
    int ascent,descent,leading;
    int extraOff;   /* extra offset needed to make things look the way they always have */
    int penX, penY;  /* initial pen position in abs coords */
    int maxX, maxY; /* maximum extent of write */
    short cx1, cy1, cx2, cy2; /* current clip rectangle */
    TRect tr, clipRect;
    int leftClip;   /* left edge of clip region */
    int showTOff, textW;

	exS.inText = FALSE;
    if (exS.wrapWrite)
        TUTORdump("endtext1 when wrapping");
    
    if (txt_string || txt_count == 0)
        return(0); /* nothing to do */
    
    /* this routine will only ever display 1 line of text */
    
    /* display text */

    penX = lclocx(exS.ScreenX) + exS.OffsetX;
    penY = lclocy(exS.ScreenY) + exS.OffsetY;
    leftMar = lclocx(exS.MarginBeginX) + exS.OffsetX + 1;
    rightMar = lclocx(exS.MarginEndX)+exS.OffsetX-1;
    ystart =  penY+1; /* 1 pixel border at top */
    botMar = lclocy(exS.MarginEndY)+exS.OffsetY-1; /* 1 pixel border at bottom */
    
    /* to make text look as it always has, we need: */
    extraOff = (penX < leftMar) ? 1 : 0;
    showTOff = ShowTOffset(HNULL,0L,txt_indentDig,txt_indentMin); /* to correctly handle -showt- */
    if (showTOff > 0)
        { /* had offset due to showt */
        extraOff += showTOff;
        }
    
    /* set clip region properly */
    leftClip = (penX < leftMar) ? penX : leftMar; /* leftwards possible extend of text */
    TUTORinq_abs_clip_rect(&clipRect);
    TUTORset_rect(&tr,leftClip,ystart,rightMar,botMar);
    TUTORintersect_rect((TRect FAR *) &tr,(TRect FAR *) &clipRect,(TRect FAR *) &tr);
    TUTORset_abs_clip_rect((TRect FAR *) &tr);
    
    /* figure out font */
    TUTORset_textfont(exS.baseFont);
    TUTORinq_font_info(&ascent,&descent,NEARNULL,NEARNULL);
    if ((ascent+descent) < exS.newLine)
    	ascent += exS.newLine-ascent-descent;
    
#ifdef ANDREW
    if (exS.mode == rewritemode || exS.mode == inversemode)
        { /* fill in background for modes rewrite & inverse */
        TUTORinq_abs_string_width((unsigned char FAR *) txt_buffer,(int) txt_count,&textW);
        TUTORset_rect(&tr,penX+extraOff-showTOff,ystart,penX+extraOff+textW-1,ystart+ascent+descent-1);
        TUTORdraw_abs_solid_rect((TRect FAR *) &tr,-1);
        }
#else
    if (showTOff && (exS.mode == rewritemode || exS.mode == inversemode))
        { /* we need to clear our special indentation */
        TUTORset_rect(&tr,penX+extraOff-showTOff,ystart,penX+extraOff-1,ystart+ascent+descent-1);
        TUTORdraw_abs_solid_rect((TRect FAR *) &tr,-1);
        }
#endif
    
    /* draw the text */
    TUTORabs_move_to(penX + extraOff,ystart+ascent);
    TUTORdraw_text((unsigned char FAR *) txt_buffer,(int) txt_count);
    TUTORabs_move(0,-ascent); /* return pen to top of text */
    TUTORset_abs_clip_rect((TRect FAR *) &clipRect);
    TUTORinq_abs_pen_pos(&fx,&fy); /* get pen after write */
    exS.ScreenX += DivCoord(IntToCoord(fx-penX),exS.ScaleX);
    exS.ScreenY += DivCoord(IntToCoord(fy-ystart),exS.ScaleY);
    exS.outcnt += txt_count;

    /* set arrow variables */
    if (exS.arr.arrowunit >= 0)
        { /* there is an arrow */
        if (fy > ystart)
            maxX = rightMar;
        else
            maxX = fx;
        TUTORinq_font_info(&ascent,&descent,NEARNULL,&leading);
        if ((ascent+descent+leading) < exS.newLine)
        	ascent += exS.newLine-(ascent+descent+leading);
        maxY = fy + ascent + descent + leading;
        
        if (exS.arr.arrowLastR.left == -1 || exS.arr.arrowLastR.left > 29000)
            { /* not accumulating bounds or this is first write */
            /* write boundaries are what we've just used */
            exS.arr.arrowLastR.left = penX+extraOff;
            exS.arr.arrowLastR.top = ystart;
            exS.arr.arrowLastR.right = maxX;
            exS.arr.arrowLastR.bottom = maxY;
            }
        else
            { /* accumulating continued writes */
            if (maxX > exS.arr.arrowLastR.right)
                exS.arr.arrowLastR.right = maxX;
            if (maxY > exS.arr.arrowLastR.bottom)
                exS.arr.arrowLastR.bottom = maxY;
            }
        }
    txt_count = 0; /* no text in buffer */
    OUTGO;

    } /* cmd_endtext1 */

/* ------------------------------------------------------------------- */

cmd_endtext2() /* end of a series of text commands */
               /* terminate text string in buffer */

{
	exS.inText = FALSE;
    txt_buffer[txt_count] = '\0';

} /* cmd_endtext2 */

/* ------------------------------------------------------------------- */

cmd_wrapstyle() /* style wrapped around -show- command */

{   register int ii; /* style index */
    int nStyles;    /* # of styles we are going to wrap */
    long len; /* length of text */
    long slen;  /* length of style */
    short kind,dat;
    int applystyle; /* TRUE if style will be applied */
    DocP dp; /* pointer to document structure */
    int canCombine; /* style combine flag/mask */

    /* pop stacks */
    nStyles = (iresP - txt_stacki) / 2; /* # of wrap styles */
    iresP = txt_stacki; /* note: values in txt_stacki are used below */
    fresP = txt_stackf;
    markP = txt_stackm;

    len = txt_count;
    InsertString(txt_doc,len,(char FAR *) " ",1L); /* add a dummy space */
    slen = len - txt_wraploc;
    for (ii=0; ii<nStyles; ii++) {
        applystyle = TRUE; /* assume we are going to apply style */
        canCombine = 0;
        kind = txt_stacki[ii*2];
        dat = txt_stacki[ii*2+1];
        if (kind == FACESTYLE) {
        	if (dat == 0) { /* plain */
            	dp = (DocP)GetPtr(txt_doc);
            	if (dp->styles)
                	applystyle = FALSE; /* let marker styles thru */
            	ReleasePtr(txt_doc);
            	KillPtr(dp);
            } else canCombine = -1; /* or styles together */
        } else if (kind == PARASTYLE) {
        	canCombine = 0xffff & (~VISMASK); /* don't combine invisible */
        }
        if (applystyle)
            TUTORstyle_doc(txt_doc,txt_wraploc,slen,kind,dat,canCombine,NEARNULL);
    }
    TUTORdelete_doc(txt_doc,len,1L,NEARNULL); /* delete dummy space */

} /* cmd_wrapstyle */

/* ------------------------------------------------------------------- */

cmd_write() /* -write- command, output to document */

{   register long pos; /* position of text in text pool */
    register long len; /* length of text */
    long extraDumm;

    len = *(--iresP);
    pos = unittab[exS.execunit].textp+*(--iresP);
    TUTORchange_doc_doc(txt_doc,txt_count,0L,0L,txt_count,
                        textpool,pos,len,&extraDumm,FALSE);
    txt_count += len;
    txt_wraploc = pos; /* so that <|cr|>, <|tab|>, etc. work when styled */

} /* cmd_write */

/* ------------------------------------------------------------------- */

cmd_write1() /* -write- command, output string */

{   char FAR *addr; /* position of text in text pool */
    register long len; /* length of text */

    len = *(--iresP);
    addr = (char FAR *)(*(--iresP));
    if ((txt_count+len) >= WRT_TXT_LTH) {
        execerr("-write- or -show- too long");
    }
    if (len) TUTORblock_move(addr,(char SHUGE *)&txt_buffer[txt_count],len);
    else txt_buffer[txt_count] = '\0'; /* handle zero-length write */
    txt_count += len;

} /* cmd_write1 */

/* ------------------------------------------------------------------- */

cmd_write2() /* make txt_doc refer directly to textpool, for later cmd_endtext */

{   register long pos; /* position of text in text pool */
    register long len; /* length of text */
    long extraDumm;

    /* we will have gone thru begintext1 to get here */
    /* if we output embedded stuff we will change textpool! */
    
    txt_count = *(--iresP);
    txt_pos = unittab[exS.execunit].textp+*(--iresP);
    txt_doc = textpool;
    
} /* cmd_write2 */

/* ------------------------------------------------------------------- */

cmd_show() /* -show- command execution */

{   register int nn;
    int nf;
    double value; /* floating value to show */
    int sigfigs; /* number significant figures */
    double minimum; /* minimum value */
    long len; /* length of string */
    struct markvar SHUGE *mv; /* pointer to marker status */
    char nstr[120]; /* numeric string */
    long extraDumm;

    nn = iresP-txt_stacki; /* number items on integer stack */
    nf = fresP-txt_stackf; /* number items on floating stack */
    iresP = txt_stacki; /* pop stacks */
    fresP = txt_stackf;
    markP = txt_stackm;

    /* process show of marker */

    if (txt_stacki[1] == TMARK) { /* process marker */
        mv = txt_stackm;
        if (txt_doc) { /* this is an embedded show */
            txt_wraploc = txt_count;
            TUTORchange_doc_doc(txt_doc,txt_wraploc,0L,0L,txt_wraploc,
                            mv->doc,mv->pos,mv->len,&extraDumm,FALSE);
            txt_count += mv->len;
        } else if (txt_simpleshow) {
            /* this must be a non-embedded show, set txt_doc to marker doc */
            /* NOTE: if this isn't simple show, we will change marker! */
            txt_doc = mv->doc;
            txt_count = mv->len;
            txt_indentDig = txt_indentMin = 0;
            txt_pos = mv->pos;
            txt_simpleshow = FALSE; /* so next show works correctly */
            } else {
                /* embedded show to buffer - get string */
                len = mv->len;
                if (txt_count+len >= WRT_TXT_LTH) 
                    execerr("-write- or -show- too long");
                TUTORget_string_doc(mv->doc,mv->pos,len,
                    ((unsigned char FAR *) txt_buffer)+txt_count);
                txt_count += len;
            }
        return(0);
    } /* TMARK if */

    /* process floating numeric show */

    txt_simpleshow = FALSE; /* so next show works correctly (not used for numeric) */
    if (txt_stacki[1] == TFLOAT) {
        value = txt_stackf[0];
    } else
        value = txt_stacki[0]; 
    sigfigs = 4; /* default number significant figures */
    minimum = 1.0E-9; /* default minimum value */
    if (nn > 4)
        sigfigs = txt_stacki[4];
    if (nf > 1)
        minimum = fabs(txt_stackf[1]);
    if ((fabs(value) < minimum) && !TstIndefinite(value) && 
        !EqFloat(value,Infinite))
        value = 0.0;
    if (sigfigs > 40)
        execerr("-show- format too large.");
    TUTORshow(0,value,sigfigs,nstr);
    ws_txt_str(nstr); /* output string */

} /* cmd_show */

/* ------------------------------------------------------------------- */

cmd_showb() /* -showb- command execution */

{   register int nn;
    register int digits; /* number digits to display */
    char str[34]; /* output string */

    nn = iresP-txt_stacki; /* number items on stack */
    iresP = txt_stacki; /* pop stack */

	if (txt_stacki[1] == TFLOAT) {
		txt_stacki[0] = txt_stackf[0]; /* duplicate on integer stack */ 
		fresP = txt_stackf; /* pop stack */
	}	
		
    if (nn > 4) {
        digits = txt_stacki[4]; /* num digits to show */
        if ((digits > 32) || (digits < 0)) 
            execerr("-showb- format error");
        if (digits == 0) return(0);
    } else if (txt_stacki[1] == TBYTE) 
        digits = 8; /* display 8 bits/digits for byte variable */
    else digits = 32; /* default - display 32 digits */

    for(nn = 1; nn <= digits; nn++)
        str[nn-1] = (txt_stacki[0] & (1L << (digits-nn))) ? '1' : '0';
    if (txt_doc) {
        txt_wraploc = txt_count; /* set location for wrapstyle */
        InsertString(txt_doc,txt_wraploc,(char FAR *) str,(long)digits);    
    } else {
        if (txt_count+digits >= WRT_TXT_LTH) 
            execerr("-write- or -show- too long");
        TUTORblock_move((char SHUGE *)str,(char SHUGE *)&txt_buffer[txt_count],
                       (long)digits);   
    } /* txt_doc else */
    txt_count += digits;

} /* cmd_showb */

/* ------------------------------------------------------------------- */

cmd_showo() /* -showo- command execution */

{   register int nn;
    register int digits; /* number digits to display */
    char str[34]; /* output string */

    nn = iresP-txt_stacki; /* number items on stack */
    iresP = txt_stacki; /* pop stack */
    
	if (txt_stacki[1] == TFLOAT) {
		txt_stacki[0] = txt_stackf[0]; /* duplicate on integer stack */ 
		fresP = txt_stackf; /* pop stack */
	}	
	
    if (nn > 4) {
        digits = txt_stacki[4]; /* num digits to show */
        if ((digits > 11) || (digits < 0)) 
            execerr("-showo- format error");
        if (digits == 0) return(0);
    } else if (txt_stacki[1] == TBYTE)
        digits = 3; /* display 3 digits for byte variable */
    else digits = 11; /* default = 11 digits = about 32 bits */

    sprintf(str,"%0*lo",digits,txt_stacki[0]);
    if (txt_doc) {
        txt_wraploc = txt_count; /* set loc for wrapstyle */
        InsertString(txt_doc,txt_wraploc,(char FAR *) str,(long)digits);
    } else {
        if (txt_count+digits >= WRT_TXT_LTH) 
            execerr("-write- or -show- too long");
        TUTORblock_move((char SHUGE *)str,(char SHUGE *)&txt_buffer[txt_count],(long)digits);
    }
    txt_count += digits;

} /* cmd_showo */

/* ------------------------------------------------------------------- */

cmd_showh() /* -showh- command execution */

{   register int nn;
    register int digits; /* number digits to display */
    char str[34]; /* output string */

    nn = iresP-txt_stacki; /* number items on stack */
    iresP = txt_stacki; /* pop stack */
    
	if (txt_stacki[1] == TFLOAT) {
		txt_stacki[0] = txt_stackf[0]; /* duplicate on integer stack */ 
		fresP = txt_stackf; /* pop stack */
	}	

    if (nn > 4) {
        digits = txt_stacki[4]; /* num digits to show */
        if ((digits > 11) || (digits < 0)) 
            execerr("-showh- format error");
        if (digits == 0) return(0);
    } else if (txt_stacki[1] == TBYTE)
        digits = 2; /* display 2 digits for byte variable */
    else digits = 8; /* default = 8 digits */
    sprintf(str,"%0*lx",digits,txt_stacki[0]);
    if (txt_doc) {
        txt_wraploc = txt_count; /* set loc for wrapstyle */
        InsertString(txt_doc,txt_wraploc,(char FAR *) str,(long)digits);
    } else {
        if (txt_count+digits >= WRT_TXT_LTH) 
            execerr("-write- or -show- too long");
        TUTORblock_move((char SHUGE *)str,(char SHUGE *)&txt_buffer[txt_count],(long)digits);
    } /* txt_doc else */
    txt_count += digits;

} /* cmd_showh */

/* ------------------------------------------------------------------- */

cmd_showt() /* -showt- command execution */
  
{   register int nn;
    double value;
    int left,right; /* number digits to display */
    int showperiod; /* 1 if should display decimal point */
    int spaces; /* number spaces filler */
    int nchars; /* total number chars to show */
    int cw;
    Coord x2,y2;
    char str[82]; /* output string */

    nn = iresP-txt_stacki; /* number items on stack */
    iresP = txt_stacki; /* pop stack */
    fresP = txt_stackf;

    value = txt_stackf[0];
    left = 4; /* set default digits to display */
    right = 3;
    showperiod = 1;

    if (nn > 0) {
        left = txt_stacki[0];
        right = 0;
        showperiod = 0;
    }
    if (nn > 1) {
        right = txt_stacki[1];
        if (right)
            showperiod = 1;
    }
    if ((left < 0) || (right < 0))
        execerr("Negative -showt- format");
    nchars = left+right; /* chars to display */
    if (nchars >= 40) execerr("Too many -showt- digits.");
    if (nchars ==  0) return(0);
    TUTORshowt(value,left,right,showperiod,str);
    if (!txt_string) {

        /* display form of -showt- command */

        for (spaces=0;str[spaces]==' ';spaces++); /* count leading spaces */
        nn = strlen(str+spaces);
        if (nn > 60)
            execerr("-showt- too wide.");
        if (txt_count == 0) {
            /* if mode erase/inverse and not embedded, clear region */
            if (exS.mode == rewritemode || exS.mode == inversemode) {
                cw = TUTORinq_abs_string_width((unsigned char FAR *)"0",1,NEARNULL);
                x2 = exS.ScreenX+IntToCoord((int)(nchars*cw));
                if (showperiod) {
                    cw = TUTORinq_abs_string_width((unsigned char FAR *)".",1,NEARNULL);
                    x2 += IntToCoord(cw);
                }
                y2 = exS.ScreenY+IntToCoord((int)(exS.CoarseH));
                TUTORerase_solid_rect(exS.ScreenX,exS.ScreenY,x2,y2);   
            } /* mode if */
        } /* txt_count if */
        if (txt_doc) { 

            /* general case - output to document+view */

            if (txt_count) { /* show previous text */
                writetext(txt_doc,0L,txt_count,txt_indentDig,txt_indentMin);
                txt_indentDig = txt_indentMin = txt_count = 0;
                if (txt_doc && (txt_doc == dtextv()))
                	TUTORclear_doc(txt_doc);
            } /* if */

            txt_wraploc = txt_count;
            InsertString(txt_doc,txt_count,(char FAR *) (str+spaces),(long)nn);
        } else { 
            /* simple cases - output text to buffer */
            if (txt_count+nn >= WRT_TXT_LTH) 
                execerr("-write- or -show- too long");
            TUTORblock_move((char SHUGE *)(str+spaces),
                       (char SHUGE *)(&txt_buffer[txt_count]),(long)nn);
        } 

        /* remember number of leading digits, used to offset when we draw the text */
        txt_indentDig = spaces;
        txt_indentMin = (*(str+spaces) == '-') ? 1 : 0;

        txt_count += nn;
    } else {

        /* string form of -showt- command */

        nn = strlen(str);
        if (txt_doc) {
        	txt_wraploc = txt_count; /* set loc for wrapstyle */
        	InsertString(txt_doc,txt_wraploc,(char FAR *) str,(long)nn);
    	} else {
        	if (txt_count+nn >= WRT_TXT_LTH) 
            	execerr("-write- or -show- too long");
        	TUTORblock_move((char SHUGE *)str,(char SHUGE *)&txt_buffer[txt_count],(long)nn);
    	} /* txt_doc else */
        txt_count += nn;
    } /* else */

} /* cmd_showt */

/* ------------------------------------------------------------------- */

ShowTOffset(doc,pos,nDig,nMin)
Memh doc; /* the document where showt is (if null we use exS.baseFont for style) */
long pos; /* the position in document */
int nDig;   /* # of leading digits we need to space over */
int nMin;   /* # of leading minus signs we need to account for */
    {
    DocP dp;
    short curStyles[NSTYLES];
    int zerowidth, minuswidth;
    unsigned char c1;
    int retVal;
    
    if (!nDig && !nMin)
        return(0);

    if (doc)
        { /* have a styled doc, use styles */
        dp = (DocP) GetPtr(doc);
        _TUTORget_styles_doc(dp,pos,curStyles);
        _TUTORset_textfont_doc(dp,curStyles);
        ReleasePtr(doc);
        KillPtr(dp);
        }
    else
        { /* no doc, use exS.baseFont */
        TUTORset_textfont(exS.baseFont);
        }
    
    c1 = '0';
    TUTORinq_abs_string_width((unsigned char FAR *) &c1,1,&zerowidth);
    if (nMin)
        {
        c1 = '-';
        TUTORinq_abs_string_width((unsigned char FAR *) &c1,1,&minuswidth);
        }

    retVal = nDig*zerowidth;
    if (nMin)
        retVal += zerowidth - minuswidth;
    if (retVal < 0)
        retVal = 0;
    
    return(retVal);
    }
    
/* ------------------------------------------------------------------- */

cmd_showz() { zeshow(1); } /* -showz- command execution */
cmd_showe() { zeshow(2); } /* -showe- command execution */

zeshow(type) /* showz and showe execution */
int type; 

{   int nn;
    int nf;
    double value; /* floating value to show */
    int sigfigs; /* number significant figures */
    long len; /* length of string */
    char nstr[120]; /* numeric string */
    long extraDumm;

    nn = iresP-txt_stacki; /* number items on integer stack */
    nf = fresP-txt_stackf; /* number items on floating stack */
    iresP = txt_stacki; /* pop stacks */
    fresP = txt_stackf;
    
    value = txt_stackf[0];
    sigfigs = 4; /* default number significant figures */
    txt_simpleshow = FALSE; /* so next show works correctly */
    if (nn > 0)
        sigfigs = txt_stacki[0];
    if (sigfigs > 40)
        execerr("-show- format too large.");
    TUTORshow(type,value,sigfigs,nstr);
    ws_txt_str(nstr);

} /* zeshow */

/* ------------------------------------------------------------------- */

static ws_txt_str(str) /* output text string for -write- or -show- */
char *str;

{   int len;

    len = strlen(str);
    if (txt_doc) {
        txt_wraploc = txt_count; /* set location for wrapstyle */ 
        InsertString(txt_doc,txt_wraploc,(char FAR *) str,len);
    } else {
        if (txt_count+len >= WRT_TXT_LTH) 
            execerr("-write- or -show- too long");
        TUTORblock_move((char SHUGE *)str,(char SHUGE *)&txt_buffer[txt_count],
                        (long)len); 
    } /* txt_doc else */
    txt_count += len;   
    
} /* ws_txt_str */

/* ------------------------------------------------------------------- */

cmd_text()  { argtext(0); } /* -text-  command execution */
cmd_rtext() { argtext(1); } /* -rtext- command execution */
cmd_gtext() { argtext(2); } /* -gtext- command execution */

argtext(type) /* text, rtext, gtext command executions */
int type; /* = 0 = text  */
          /* = 1 = rtext */
          /* = 2 = gtext */

{   register int nn;
    int sv_height; /* saved character height */
    int sv_font; /* saved font */
    Coord endx,endy; /* lower right margin */
    Coord sv_x1,sv_y1,sv_x2,sv_y2; /* saved margins */
    long pos; /* position of text in text pool */
    long len; /* length of text */
    int saveWrap;   /* to save value of wrapWrite */

    nn = (type == 0) ? (iresP-istack) : (fresP-fstack); /* number items on stack */
    iresP = istack; /* pop stack */
    fresP = fstack;
    txt_stacki = istack; /* set base position in stack */
    txt_stackf = fstack;
    txt_stackm = markstack;

    /* initialize for following -write- and -show- commands */

    txt_string = FALSE; /* set display/string flag = display */
    txt_count = txt_indentDig = txt_indentMin = 0;
    txt_doc = dtextv();
    txt_wraploc = exS.arr.arrowLastR.left = -1;
    txt_pos = 0L;
    if (txt_doc && (txt_doc == dtextv()))
    	TUTORclear_doc(txt_doc); /* pre-clear document */

    /* rescale text if sized -rtext- */

    sv_font = -1; /* no need to save/restore font yet */
    if (type == 1) {
        if (exS.RAngle != 0) 
            execerr("-rtext- cannot rotate text yet.");
        if (exS.RXsize || exS.RYsize) {
            sv_height = exS.CharHeight;
            exS.CharHeight = ((exS.RXsize < exS.RYsize) ?
                                exS.RXsize:exS.RYsize)*exS.CharHeight;
            sv_font = exS.baseFont; /* save font for later restore */
            ResetTextSize(FALSE,FALSE);
        } /* size if */
    } /* type if */

    sv_x1 = exS.MarginBeginX; /* save margins */
    sv_y1 = exS.MarginBeginY;
    endx = sv_x2 = exS.MarginEndX;
    endy = sv_y2 = exS.MarginEndY;

    if (nn) {
        switch(type) {
        case 0: /* -text- */
            exS.ScreenX = istack[0];
            exS.ScreenY = istack[1];
            if (nn > 2) {
                endx = istack[2];
                endy = istack[3];
            } /* nn if */
            break;
        case 1: /* -rtext- */
            relative_to_fine(fstack[0],fstack[1],&exS.ScreenX,&exS.ScreenY);
            if (nn > 2)
                relative_to_fine(fstack[2],fstack[3],&endx,&endy);
            break;
        case 2: /* -gtext- */
            graph_to_fine(fstack[0],fstack[1],&exS.ScreenX,&exS.ScreenY);
            if (nn > 2)
                graph_to_fine(fstack[2],fstack[3],&endx,&endy);
            break;
        } /* switch */

        /* set margins */

        exS.MarginBeginX = exS.ScreenX;
        exS.MarginBeginY = exS.ScreenY;
        exS.MarginEndX = endx;
        exS.MarginEndY = endy;

        /* adjust so that ScreenX, ScreenY is upper left */

        if (endx < exS.MarginBeginX) {
            exS.MarginEndX = exS.MarginBeginX;
            exS.MarginBeginX = exS.ScreenX = endx;
        } /* endx if */
        if (endy < exS.MarginBeginY) {




            exS.MarginEndY = exS.MarginBeginY;
            exS.MarginBeginY = exS.ScreenY = endy;
        } /* endy if */ 
    } /* nn if */

    saveWrap = exS.wrapWrite;
    exS.wrapWrite = TRUE; /* text commands ALWAYS wrap */
    exec_text(); /* process write/show commands */
    iresP = istack; /* void stacks */
    fresP = fstack;
    markP = markstack;
    exS.wrapWrite = saveWrap;

    /* restore margins */

    exS.MarginBeginX = sv_x1; /* restore margins */
    exS.MarginBeginY = sv_y1;
    exS.MarginEndX = sv_x2;
    exS.MarginEndY = sv_y2;

    /* restore font if neccessary */

    if (sv_font >= 0) { /* restore font if neccessary */
        exS.CharHeight = sv_height;
        exS.baseFont = sv_font;
        ResetTextSize(FALSE,FALSE);
    } /* sv_font if */

} /* argtext */

/* ------------------------------------------------------------------- */

cmd_textm()  { argtextm(0); } /* -text-  (marker) command execution */
cmd_rtextm() { argtextm(1); } /* -rtext- (marker) command execution */
cmd_gtextm() { argtextm(2); } /* -gtext- (marker) command execution */

static argtextm(type) /* text, rtext, gtext */
int type; /* 0 = absolute, 1 = relative, 2 = graphing */
    
{   int nn;
    struct markvar SHUGE *mtxt;
    Coord x1,y1,x2,y2; /* region */
    TRect theR; /* where on screen */
    Memh newT; /* handle on text panel */
    TextVDat FAR *tpp; /* pointer to text panel */
    TViewP tvp; /* pointer to text view */
    struct tutorview FAR *cv; /* current view */
    long tmpl;

    nn = iresP-istack;
    markP = markstack;
    iresP = istack;

    /* get rectangle */

    if (type == 0) {
        x1 = istack[0];
        y1 = istack[1];
        x2 = istack[2];
        y2 = istack[3];
    } else if (type == 1) {
        relative_to_fine(fstack[0],fstack[1],&x1,&y1);
        relative_to_fine(fstack[2],fstack[3],&x2,&y2);
        if (exS.RAngle != 0) 
            execerr("-rtext- cannot rotate text.");
    } else if (type == 2) {
        graph_to_fine(fstack[0],fstack[1],&x1,&y1);
        graph_to_fine(fstack[2],fstack[3],&x2,&y2);
    } /* type else */
    
    theR.left = exS.OffsetX + lclocx(x1);
    theR.top = exS.OffsetY + lclocy(y1);
    theR.right = exS.OffsetX + lclocx(x2);
    theR.bottom = exS.OffsetY + lclocy(y2);

    /* normalize rectangle */

    if (theR.left > theR.right) { /* normalize x */
        tmpl = theR.left;
        theR.left = theR.right;
        theR.right = tmpl;
    }
    if (theR.top > theR.bottom) { /* normalize y */
        tmpl = theR.top;
        theR.top = theR.bottom;
        theR.bottom = tmpl;
    }

    mtxt = markstack; /* get text marker */

    /* create text panel */

    /* make sure doc is set up with correct default styles */
    TUTORdefault_styles_font_doc(exS.baseFont, mtxt->doc);
    newT = MakeTextPanel(ExecWn,0L,0,0,&theR,3,0,TRUE,  
                       mtxt->doc,mtxt->pos,mtxt->len,FALSE,FALSE,
                       FARNULL,TRUE,FALSE,FALSE,FALSE,-1,-1,-1,FALSE,3);
    if ((exS.mode == rewritemode) || (exS.mode == inversemode))
        TUTORdraw_abs_solid_rect((TRect FAR *)&theR,PAT_BACKGROUND);
    DrawPanel(newT);

    TUTORclose_panel(newT);
    
    /* restore executor cursor */   
    cursorChar = -1; /* force re-set of cursor */
    TUTORset_cursor(exS.cursorFont,exS.cursorChar); 
    
    mvar_temp_cleanup();

    return(0);

} /* argtextm */

/* ------------------------------------------------------------------- */

cmd_string() /* -string- command execution */

{   register struct markvar SHUGE *mxv;
    struct markvar mtmp;

    iresP = istack; /* empty stack */
    markP = markstack;

    mxv = (struct markvar SHUGE *)(istack[2]);
    mvar_init((struct markvar SHUGE *)&mtmp); /* set up new doc */
    mvar_assign((struct markvar SHUGE *)istack[2],(struct markvar SHUGE *)&mtmp);
    txt_string = TRUE; /* set display/string flag = string */
    txt_count = txt_indentDig = txt_indentMin = 0;
    txt_doc = mxv->doc; /* set document for text */
    txt_stacki = istack; /* set base positions in stacks */
    txt_stackf = fstack;
    txt_stackm = markstack;
    exS.inText = TRUE;
    exec_text(); /* execute write/show commands */
    iresP = istack; /* void stacks */
    fresP = fstack;
    markP = markstack;
    mxv->pos = 0L;
    mxv->len = txt_count;
    mxv->alteredF = 0;
    mvar_temp_cleanup(); /* clean up temporary docs */

} /* cmd_string */

/* ------------------------------------------------------------------- */

cmd_append() /* -append- command execution */

{   register struct markvar SHUGE *mx;
    register struct markvar SHUGE *my;

    iresP = istack; /* void stack */
    markP = markstack;
    mx = markP; /* expression involving marker var */
    my = markP+1; /* 2nd marker */
    mvar_append(mx,my); /* append 2nd to first */
    mx->alteredF = 0;
    mvar_temp_cleanup(); /* clean up temporary docs */

} /* cmd_append */

/* ------------------------------------------------------------------- */

cmd_replace() /* -replace- command execution */

{
    iresP = istack; /* void stack */
    markP = markstack;
    mvar_replace(markP,markP+1);
    mvar_temp_cleanup(); /* clean up temporary docs */

} /* cmd_replace */

/* ------------------------------------------------------------------- */

cmd_zero() { xzero(0); }
cmd_zerom() { xzero(1); }

static xzero(type) /* -zero-, -zerom- command executions */
int type; /* 0 = zero int/float, 1 = zero markers */

{   long nn;
    char SHUGE *addr; /* address of variable */
    register int kind; /* type of variable */
    long maxlth; /* maximum legal length to zero */
    register long length; /* length to zero */
    int size; /* size of individual element */
    int arrayf; /* TRUE if whole array */
    int lthf; /* TRUE if length argument present */
    long SHUGE *llp;

    nn = iresP-istack;
    iresP = istack; /* void stacks */
    fresP = fstack;

    lthf = istack[nn-1]; /* TRUE if length argument */
    arrayf = istack[nn-2]; /* TRUE if whole array */

    kind = istack[1];
    addr = (char SHUGE *)istack[2];
    if (arrayf == 1) 
        addr += ARRAYHDR; /* skip past array header */
    else if (arrayf == 2){ /* dynamic array */
        if (istack[3] <= 0)
            return; /* exit if no length */
        llp = ((long SHUGE *)addr)+1;
        addr = (char SHUGE *)(*llp); /* pointer to actual array */
    }
    maxlth = istack[3];
    length = (arrayf ? maxlth: 1);
    if (lthf) {
        length = istack[nn-3];
        if (length > maxlth)
           arraybnds();
    } /* lthf if */
    size = sizetv(kind); /* get size of element */

	if ((long)(addr) == 0)
		arraybnds();
    if (type == 0) {
        TUTORzero((char SHUGE *)addr,length*size);
    } else {
    	for(nn=0; nn<length; nn++) {
        	mvar_assign((struct markvar SHUGE *)addr,(struct markvar FAR *)FARNULL);
        	addr += size;
    	} /* for */
    } /* type else */

} /* xzero */

/* ------------------------------------------------------------------- */

static int set_kind; /* expression type for -set- command */
static int set_size; /* size of item for -set- command */
static unsigned char SHUGE *set_addr; /* current address for -set- command */
static long set_items; /* number items in array for -set- command */

cmd_set() /* -set- command execution */

{   int nn,nm,nf;
    register int si,fi,mi; /* indexes in result stacks */
    long SHUGE *llp;

    nn = iresP-istack; /* number items on stack */
    nf = fresP-fstack;
    nm = markP-markstack;
    iresP = istack; /* void stacks */
    fresP = fstack;
    markP = markstack;

    set_kind = istack[1];
    set_addr = (unsigned char SHUGE *)istack[2];
    set_items = istack[3]; 
    
    si = 5; /* index in integer stack */
    fi = 1; /* index in floating stack */
    mi = 1; /* index in marker stack */
    
    if (set_kind == FARRAY) {
        set_kind = TFLOAT;
        fi = 0; /* no result on floating stack */
    } else if (set_kind == MARRAY) {
        set_kind = TMARK;
        mi = 0; /* no result on marker stack */
    } 
    
    if (istack[4] == 1) 
        set_addr += ARRAYHDR; /* increment past array header */
    else if (istack[4] == 2){
        if (set_items <= 0)
            ex_arrayerr();
        llp = ((long SHUGE *)set_addr)+1;
        set_addr = (unsigned char SHUGE *)(*llp); /* address of actual array */
    }
    set_size = sizetv(set_kind); /* get size of element */

    while ((si < nn) || (mi < nm) || (fi < nf)) {
        if ((set_items--) <= 0)
            arraybnds();
        if (set_kind == TFLOAT) 
            fputvar(set_addr,TFLOAT,fstack[fi++]);
        else if (set_kind == TMARK) 
            mvar_assign((struct markvar SHUGE *)set_addr,&markstack[mi++]);
        else iputvar(set_addr,set_kind,istack[si++]);
        set_addr += set_size; /* advance to next item */
    } /* while */
    mvar_temp_cleanup();

} /* cmd_set */

/* ------------------------------------------------------------------- */

cmd_setc() /* continued -set- command execution */

{   int nn,nm,nf;
    register int si,fi,mi; /* indexes in result stacks */

    nn = iresP-istack; /* number items on stack */
    nf = fresP-fstack;
    nm = markP-markstack;
    iresP = istack; /* void stack */
    fresP = fstack;
    markP = markstack;

    si = fi = mi = 0; /* indexes in expression/marker stacks */
    while ((si < nn) || (mi < nm) || (fi < nf)) {
        if ((set_items--) <= 0)
            arraybnds();
        if (set_kind == TFLOAT) 
            fputvar(set_addr,TFLOAT,fstack[fi++]);
        else if (set_kind == TMARK)
            mvar_assign((struct markvar SHUGE *)set_addr,&markstack[mi++]);
        else iputvar(set_addr,(int)set_kind,istack[si++]);
        set_addr += set_size; /* advance to next item */
    } /* while */

    /* if marker set, clean up temporaries and check if need */
    /* to interrupt: -set- of a large marker array can take time */

    if (set_kind == TMARK) {
	mvar_temp_cleanup();
#ifdef Nosuch
        if (shouldint()) {
            execrun = FALSE; /* return from executor */
	    waitflag = atinterrupt;
	} /* shouldint if */
#endif
    } /* set_kind if */

    return(0);

} /* cmd_setc */

/* ------------------------------------------------------------------- */

cmd_compute() /* -compute- command execution */

{   int nn;
    unsigned char SHUGE *vaddr; /* address of result variable */
    long vkind; /* type of result variable */
    register struct markvar SHUGE *mx; /* pointer to marker  */
    double result;

    nn = markP-markstack;
    iresP = istack; /* void stacks */
    fresP = fstack;
    markP = markstack;

    vkind = istack[1]; /* result variable address, kind */
    vaddr = (unsigned char SHUGE *)istack[2];
    if (nn == 0) mx = exS.arr.jbuffer; /* source from judge buffer */
    else mx = markP;
    result = evalduser(mx);
    fputvar(vaddr,(int)vkind,result);
   
} /* cmd_compute */

/* ------------------------------------------------------------------- */

cmd_markpt() /* -markpt- command execution  */

{ 
    exS.markpt = get_exec_pt()-2; /* set location of command */

} /* cmd_markpt */

/* ------------------------------------------------------------------- */

cmd_cond() /* conditional command execution */

{   int maxcond; /* maximum value of condition */
    int condv; /* condition value */
    unsigned int condtab; /* address of condition table */
    register unsigned char FAR *tptr; /* pointer to condition table entry */

    iresP -= 4; /* pop our stuff off stack */
    exS.condt_uloc = *iresP; /* exit address */
    
    /* look up address in table */
    
    tptr = &pcodep[*(iresP+1)];
    condtab = (*(iresP+1))+4; /* table address */
    maxcond = *(iresP+2); /* maximum value of condition */
    condv = *(iresP+3); /* value of condition expression */
    if (condv < 0) condv = -1; /* insure condition legal */
    if (condv > maxcond) condv = maxcond; 
    condv = 2*(condv+1); /* index in table */
    tptr = &pcodep[condtab+condv];
    condtab = *(short FAR *)tptr; /* get table entry */
    set_exec_pt(condtab); /* execute conditional command */
    
    iresP = istack; /* void stacks */
    fresP = fstack;
    markP = markstack;
    return(condtab); /* return position for compiled code */
    
} /* cmd_cond */

/* ------------------------------------------------------------------- */

cmd_condout() /* terminate conditional command */

{   register unsigned int loc;

    loc = exS.condt_uloc;
    set_exec_pt(loc); /* exit conditional command */
    exS.condt_uloc = 0; /* not in conditional */
    return(loc); /* return position for compiled code */

} /* cmd_condout */

/* ------------------------------------------------------------------- */

static int case_type; /* -case- expression type */
static long case_integer; /* integer expression value */
static double case_float; /* floating expression value */
static struct markvar case_mx; /* marker expression result */

cmd_case() /* numeric -case- command execution */

{   
    iresP = istack; /* void stacks */
    fresP = fstack;

    case_type = istack[1]; /* type of expression */

    /* un-optimized form - linear search thru clauses */

    if (case_type == TFLOAT)
        case_float = fstack[0];
    else
        case_integer = istack[0];

} /* cmd_case */

/* ------------------------------------------------------------------- */

cmd_caset() /* optimized numeric -case- command */

{   int table; /* address of table for optimized form */
    long min,max; /* minimum/maximum of table */
    register int branch; /* relative address in unit */
    register short FAR *sptr;

    iresP = istack; /* void stack */

    case_type = istack[1]; /* type of expression */
    table = istack[3]; /* table for optimized integer form */
    
    /* handle optimized form - use table */

    case_integer = istack[0]; 
    sptr = ((short FAR *)(&pcodep[table]))+1;
    min = *sptr++; /* get min and max of table */
    max = *sptr++;
    branch = 0; /* default is branch to else/endcase */
    if ((case_integer >= min) && (case_integer <= max)) {
        branch = *(sptr+(case_integer-min)); /* get addr from table */
    } 
    if (!branch) 
        branch = istack[2]; /* branch to else/endcase */
    set_exec_pt(branch); 
    return(branch); /* return relative addr for compiled code */
    
} /* cmd_caset */

/* ------------------------------------------------------------------- */

cmd_casem() /* marker -case- command execution */

{   
    iresP = istack; /* void stacks */
    markP = markstack;

    case_type = TMARK; /* type of expression */
    case_mx = markstack[0]; /* marker */

} /* cmd_casem */

/* ------------------------------------------------------------------- */

cmd_clause() /* -case- command execution */

{   int match; /* TRUE if found a match */
    struct markvar SHUGE *my; /* pointer to marker status */
    register int bs; /* beginning index in integer/float/mark stack */
    register int es; /* end-test for index in stack */
    int ii; /* index in stack */

    if (case_type == TMARK) {
        bs = 0; /* starting index */
        es = markP-markstack; /* end-test */
        markP = markstack; /* void stack */
    } else if (case_type == TFLOAT) {
        bs = 0; /* starting index */
        es = fresP-fstack; /* end-test */
        fresP = fstack; /* void stack */
    } else {
        bs = 1; /* starting index */
        es = iresP-istack; /* end-test */
    } /* else */
    iresP = istack; /* void integer stack */

    match = FALSE; /* no match yet */
    for(ii=bs; ii<es; ii++) {
        if (case_type == TMARK) { /* string */
            my = &markstack[ii];
            match = (mvar_compare((struct markvar SHUGE *)&case_mx,my,TRUE) == 0);
        } else if (case_type == TFLOAT) {
            match = fuzzyeq(case_float,fstack[ii]);
        } else { /* integer */
            match = (istack[ii] == case_integer);
        } /* else */
        if (match) { /* match found */
            if (case_type == TMARK) {
                mvar_temp_cleanup();
                case_type = 0; /* cleanup not neccessary */
            } /* case_type if */
            return(0); /* fall thru to next statement */
        } /* match if */
    } /* for */

    /* didnt find a match - go to next clause */
        
    set_exec_pt((unsigned short)istack[0]);
    return((int)istack[0]);

} /* cmd_clause */

/* ------------------------------------------------------------------- */

cmd_endcase() /* -endcase- command execution */

{
    if (case_type == TMARK) {
        mvar_temp_cleanup();
        case_type = 0;
    } /* tmark if */

} /* cmd_endcase */

/* ------------------------------------------------------------------- */

cmd_calc() /* -calc- command execution */

{
    iresP = istack; /* void stacks */
    fresP = fstack;
    markP = markstack;

} /* cmd_calc */

/* ------------------------------------------------------------------- */

cmd_iloop1init() /* initialization for iterated loop, integer index */
                 /* increment = 1 */

{   register long value,end; /* current value, ending value */

    iresP = istack; /* void stack */

    value = istack[0]; /* current value of index */
    end = istack[1]; /* end-test */
    if (value <= end) /* begin loop */
        set_exec_pt((unsigned short)istack[2]);
    else /* exit loop */
        set_exec_pt((unsigned short)istack[3]);
    

} /* cmd_iloop1init */

/* ------------------------------------------------------------------- */

cmd_iloopinit() /* initialization for iterated loop, integer index */

{   register long value,end; /* current value, ending value */

    iresP = istack; /* void stack */

    value = istack[0]; /* current value of index */
    end = istack[1]; /* end-test */
    if (istack[2] >= 0) { /* positive increment */
        if (value <= end) /* begin loop */
            set_exec_pt((unsigned short)istack[3]);
        else /* exit loop */
            set_exec_pt((unsigned short)istack[4]);
    } else { /* negative increment */
        if (value >= end) /* begin loop */
            set_exec_pt((unsigned short)istack[3]);
        else /* exit loop */
            set_exec_pt((unsigned short)istack[4]);
    } /* else */

} /* cmd_iloopinit */

/* ------------------------------------------------------------------- */

cmd_icloopinit() /* initialization for iterated loop, integer index, */
                 /* constant begin, end, increment */

{   register long value,end; /* current value, ending value */

    iresP = istack; /* void stack */

    set_exec_pt((unsigned short)istack[1]); /* begin loop */

} /* cmd_icloopinit */

/* ------------------------------------------------------------------- */

cmd_iloop1() /* iterated loop, integer index, increment = 1 */

{   register long index; /* current loop index */
    
    iresP = istack; /* void stack */

    index = istack[0]+1;
    iputvar((unsigned char SHUGE *)istack[2],(int)istack[1],index);
    if (index > istack[4]) /* end test */
        set_exec_pt((unsigned short)istack[5]);

} /* cmd_iloop1 */

/* ------------------------------------------------------------------- */

cmd_iloopinc() /* iterated loop, integer index */

{   register long index; /* current loop index */
    register long inc; /* increment */
    
    iresP = istack; /* void stack */

    inc = istack[5];
    index = istack[0]+inc;
    iputvar((unsigned char SHUGE *)istack[2],(int)istack[1],index);
    if (inc >= 0) {
        if (index > istack[4]) /* end test */
            set_exec_pt((unsigned short)istack[6]);
    } else {
        if (index < istack[4]) /* end test */
            set_exec_pt((unsigned short)istack[6]);
    } /* else */

} /* cmd_iloopinc */

/* ------------------------------------------------------------------- */

int cmd_floopinit() /* initialization for iterated loop, floating index */

{   double value,end; /* current value, ending value */
    register unsigned int exloc; /* new execution point */

    iresP = istack; /* void stacks */
    fresP = fstack;

    value = fstack[0]; /* current value of index */
    end = fstack[1]; /* end-test */
    if (fstack[2] >= 0.0) { /* positive increment */
        if (fuzzygt(value,end)) /* exit loop */
            set_exec_pt(exloc = (unsigned int)istack[1]);
        else /* begin loop */
            set_exec_pt(exloc = (unsigned int)istack[0]);
    } else { /* negative increment */
        if (fuzzylt(value,end)) /* exit loop */
            set_exec_pt(exloc = (unsigned int)istack[1]);
        else /* begin loop */
            set_exec_pt(exloc = (unsigned int)istack[0]);
    } /* else */
    return(exloc); /* return new execution point for compiled code */
    
} /* cmd_floopinit */

/* ------------------------------------------------------------------- */

int cmd_floopinc() /* iterated loop, floating index */

{   double index; /* current loop index */
    double inc; /* increment */
    register unsigned int exloc; /* new execution position */
    
    fresP = fstack; /* void stacks */
    iresP = istack;

    inc = fstack[2];
    index = fstack[0]+inc;
    fputvar((unsigned char SHUGE *)istack[2],(int)istack[1],index);
    exloc = 0; /* 0 = continue with next command */
    if (inc >= 0.0) {
        if (fuzzygt(index,fstack[1])) /* end test */
            set_exec_pt(exloc = (unsigned short)istack[4]);
    } else {
        if (fuzzylt(index,fstack[1])) /* end test */
            set_exec_pt(exloc = (unsigned short)istack[4]);
    } /* else */
    return(exloc); /* return new execution point for compiled code */

} /* cmd_floopinc */

/* ------------------------------------------------------------------- */

static int objw_count = 0;

cmd_objw() /* check for active object */
/* postpone jump or other action which might destroy object */

{   int doInt; /* TRUE if should interrupt */

    if (objw_count > 3) { /* avoid infinite loop */
	objw_count = 0;
	doInt = TRUE;
    } else {
	doInt = shouldint(); /* check if time to interrupt */
	if (TUTORinq_slider_busy() || (interactDepth > 1)) {
	    /* back-up uloc to re-execute this command */
	    exS.uloc = (((unsigned char FAR *)(ex_binP))-pcodep)-2;
	    set_exec_pt(exS.uloc);
	    doInt = TRUE;
	    objw_count++; /* count number times we've waited */
	} else
	    objw_count = 0;
    }
    if (doInt) {
        execrun = FALSE; /* return from executor */
        waitflag = atinterrupt;
    } /* shouldint if */
    return(0);

} /* cmd_objw */

/* ------------------------------------------------------------------- */

cmd_do() { int debug; xdojmp(0); } /* -do- command execution */
cmd_jump() { int debug; xdojmp(1); } /* -jump- command execution */

xdojmp(type) /* do/jump execution */
int type;

{   int ni;
    int unitn; /* target unit */
    int nvargs,naargs; /* number value and address args */
    register int aii; /* index in arguments */
    int iii; /* index in istack */
    int fii; /* index in fstack */
    int mii; /* index in markstack */
    unsigned char SHUGE *vaddr; /* address of variable */
    register struct arg_desc FAR *argp; /* pointer to argument descriptors */
    long stackrel; /* relative position in stack */
    unsigned char SHUGE *oldstack; /* former address of stack */
    register unsigned char SHUGE *lstackp; /* pointer to local variables */
    int argtype; /* argument int/float/mark type */
    long SHUGE *lp;
    register struct unitinfo FAR *up; /* pointer to unit table entry */
    long newLen; /* new stack requirement for -do- */

    ni = iresP-istack;
    iresP = istack; /* void stacks */
    fresP = fstack;
    markP = markstack;

    unitn = istack[0]; /* target unit number */
    if (unitn == UNITX) return(0); /* do-nothing case */
    up = &unittab[unitn];

    nvargs = istack[ni-2]; /* get number args */
    naargs = istack[ni-1];

    oldstack = exS.stackP;
    if (type == 0) { /* stack current status for -do- */

	/* be sure we have enough stack space */

	stackrel = exS.stackpntr-exS.stackP;
	newLen = stackrel+up->nlvars+64L+64L+100L;
	if (exS.stackmalloc < newLen) {
	    ReallocStack(newLen+500L);
        }

	exS.uloc = ((unsigned char FAR *)(ex_binP))-pcodep;
        exS.do_errunit = exS.execunit; /* pre-set for execution error */
        exS.do_errpos = exS.uloc;

#ifdef IBMPC
	exS.stackpntr += 44; /* make do status 64 bytes on stack */
        lp = (long SHUGE *)exS.stackpntr;
        exS.stackpntr += 20;
        *(lp) = exS.execunit;
        *(lp+1) = exS.uloc;
        *(lp+2) = exS.condt_uloc;
        exS.condt_uloc = 0; 
        *(lp+3) = exS.lvars;
        *(lp+4) = STACK_DO;
#else
        lp = (long SHUGE *)exS.stackpntr;
        exS.stackpntr += 5*sizeof(long);
        *(lp) = exS.execunit;
        *(lp+1) = exS.uloc;
        *(lp+2) = exS.condt_uloc;
        exS.condt_uloc = 0; 
        *(lp+3) = exS.lvars;
        *(lp+4) = STACK_DO;
#endif
    } else { /* set exec error info for -jump- */
        exS.do_errunit = exS.execunit; /* pre-set for execution error */
        exS.do_errpos = get_exec_pt();
    } /* type else */

    exS.execunit = unitn; /* set to execute new unit */
    exS.uloc = 0;

    if (type) { /* jump */
        rerunflag = runflag = waitflag = runall; /* we're fully running now */
        exS.condt_uloc = 0; /* clear conditional command flag/pos */
        CloseLocalFiles();
        unstack_all_units(); /* void -do-/-arrow- stack */
        stackrel = gvaraddr; /* at top of -do- stack */
        exS.inieu = FALSE;
        InitMainUnit(FALSE,FALSE); /* no reshape, no ieu */
    } else { /* -do- */

        /* set up stack frame for new unit */

        stackrel = exS.stackpntr-exS.stackP;
        exS.lvarP = exS.stackpntr;
        assign_pfun((long)(&exs_addr[EXS_LOCALP]),(long)exS.lvarP);
        exS.lvars = stackrel;
        exS.stackpntr += up->nlvars;
#ifdef IBMPC
	exS.stackpntr += 52; /* round up to 64 byte chunk */
#endif
        lp = (long SHUGE *)exS.stackpntr;
        exS.stackpntr += 3*sizeof(long);
        *(lp) = exS.lvars;
        *(lp+1) = unitn;
        *(lp+2) = STACK_UNIT;
        TUTORzero((char SHUGE *)(exS.lvarP),up->nlvars);
        /* set local array descriptors */
        if (up->descl)
            init_array_desc(unitn,(long)exS.lvars);
        InsureUnit(exS.execunit); /* insure unit in memory */
        ex_binP = (short FAR *)(&pcodep[exS.uloc]); /* update execution pointer */
    } /* do else */

    if (nvargs != up->nvargs) {
        execerr("Incorrect number of pass-by-value arguments.");
    }
    if (naargs != up->naargs) {
        execerr("Incorrect number of pass-by-address arguments.");
    }

    if (nvargs || naargs) {
        iii = 1;
        fii = mii = 0;
        argp = (struct arg_desc FAR *)
               (descP+up->descp+up->argdesc);
        /* get pointer to local variables for do-ne or main unit */
        lstackp = exS.stackP+stackrel; 

        /* pass value arguments */

        for(aii=0; aii<nvargs; aii++) {
            argtype = istack[iii+1];
            if (argtype != argp->ltype)
                if ((argtype == TMARK) || (argp->ltype == TMARK)) 
                    execerr("Pass-by-value type mismatch.");
            if (argp->global) vaddr = exS.stackP+argp->addr;
            else vaddr = lstackp+argp->addr;
            if (argtype == TFLOAT) 
                fputvar(vaddr,(int)argp->ltype,fstack[fii++]);
            else if (argtype == TMARK) 
                mvar_assign((struct markvar SHUGE *)vaddr,(struct markvar SHUGE *)&markstack[mii++]);
            else iputvar(vaddr,(int)argp->ltype,istack[iii]);
            iii += 4; /* advance index in stack */
            argp++; /* advance pointer in arguments */
        } /* for */

        /* pass address arguments */

        for(aii=0; aii<naargs; aii++) {
            if (istack[iii+1] != argp->ltype) {
                execerr("Pass-by-address type mismatch.");
            }
            if (argp->global) vaddr = exS.stackP+argp->addr;
            else vaddr = lstackp+argp->addr;
            *(long SHUGE *)(vaddr) = (unsigned char SHUGE *)(istack[iii+2])-oldstack; 
            iii += 4; /* advance index in stack */
            argp++; /* advance pointer in arguments */
        } /* for */
    } /* args if */

    exS.do_errunit = -1; /* unset execution error status */

    if (type == 1) {
        if (exS.needredraw) {
            /* force the redraw that the ieu buffered */
            TUTORforce_redraw(exS.baseView->window);
            exS.needredraw = exS.inieu = FALSE;
			exS.loopcounter = 100; /* force interrupt */
        }
    } /* type if */
    
    /* check if should interrupt */
    
    if (++exS.loopcounter > 70) { 
        exS.loopcounter = 0;
        execrun = FALSE; /* return from executor */
        waitflag = atinterrupt;
    }

} /* xdojmp */

/* ------------------------------------------------------------------- */

cmd_endunit() /* end-of-unit */

{   struct unitinfo FAR *up; /* pointer to unit table entry */
    long SHUGE *lp;

	if (exS.stepMode) {
		if (exS.stepMode == 2) { /* stepping over -do- */
    		if ((exS.stackpntr-exS.stackP) <= exS.stepStackTarget) {
				exS.stepMode = 1; /* done stepping over -do- */
				exS.stepStackTarget = 0; /* clear target */
			}
		}
	} /* stepMode if */

    if ((exS.execunit == exS.proc_obj_unit) && exS.proc_obj_unit) {
        /* update uloc in case post-event -do- performed */
        exS.uloc = (((unsigned char FAR *)(ex_binP))-pcodep)-2; 
        set_exec_pt(exS.uloc);
        post_event_unit(); /* post-event handling */
        return; /* execute possible other unit, or return here */
    }
    up = &unittab[exS.execunit];
    if (up->hasfile) 
        CloseUnitLocalFiles();
    if (refhead)
        mvar_temp_cleanup(); /* release temporary documents */

    if (exS.lvars == gvaraddr) {

        /* end of main unit */
        
        exS.inieu = FALSE; /* can't be in ieu any more */
        if (exS.pictF) 
            FinishPicture(); /* finish up if making image of screen */
        if (exS.needredraw) {
            /* force the redraw that the ieu buffered */
            TUTORforce_redraw(exS.baseView->window);
            exS.needredraw = FALSE;
        }
        /* update uloc, back up 2 in case menu-driven -do- is performed */
        exS.uloc = (((unsigned char FAR *)(ex_binP))-pcodep)-2; /* update uloc */
        if (runflag == runall) {
            set_exec_pt(exS.uloc);
            EndUnitMenus();
            waitflag = atendunit; 
        } else 
            Halt(); 
        if (ctedit && (!exS.nobjects) && (!exS.nextunit) &&
       (!exS.backunit)) {
            /* no place to go, no objects active */
        }
        execrun = FALSE; /* terminate execution loop */
        exS.proc_obj_unit = 0; /* allow button/slider/hot interrupt */
        exS.hold_objectH = 0;
        return(0); 
    } else if (exS.execunit == 0) { 
		
		/* end of IEU - if we've been holding a redraw, force it thru */
		
		exS.inieu = FALSE;
		if (exS.needredraw) 
			TUTORforce_redraw(exS.baseView->window);
		if (exS.needredraw || nevents) {
			exS.needredraw = FALSE;
			execrun = FALSE; /* return from executor */
        	waitflag = atinterrupt;
        }
	}

    if (up->descl) 
        items_close(exS.execunit,exS.lvars,TRUE,TRUE); /* close local markers */
    exS.stackpntr = exS.lvarP; /* delete current local vars */
    lp = (long SHUGE *)exS.stackpntr;
#ifdef IBMPC
	exS.stackpntr -= 64;
#else
    exS.stackpntr -= 5*sizeof(long);
#endif
    if (exS.stackpntr < (exS.stackP+gvaraddr)) 
        execerr("System error -- stack underflow at end of unit.");
    else if (exS.stackpntr>=(exS.stackP+exS.stackmalloc)) 
        execerr( "System error -- stack overflow at end of unit.");  
    if (*(lp-1) != STACK_DO)
        execerr("Systerm error -- stack incorrect at end of unit");
    exS.lvars = *(lp-2); 
    exS.lvarP = exS.stackP+exS.lvars;
    assign_pfun((long)&exs_addr[EXS_LOCALP],(long)exS.lvarP);
    exS.condt_uloc = *(lp-3);
    exS.uloc = *(lp-4);
    exS.execunit = *(lp-5);
    InsureUnit(exS.execunit);
    ex_binP = (short FAR *)(&pcodep[exS.uloc]); /* update execution pointer */

} /* cmd_endunit */

/* ------------------------------------------------------------------- */

cmd_next() /* -next- command execution */

{
    iresP = istack;
    exS.nextunit = istack[0];

} /* cmd_next */

/* ------------------------------------------------------------------- */

cmd_back() /* -back- command execution */

{
    iresP = istack;
    exS.backunit = istack[0];

} /* cmd_back */

/* ------------------------------------------------------------------- */
	
cmd_jumpout()
    
{   int nn,nf,nm; /* number items on stacks */
	struct tutorevent switchEv;
	struct tutorevent editEv;
	FileRef FAR *fRefP; /* cT program to jumpout to */
	FileRef targetFile; /* target source or binary file */
	int findx; /* index of file in cT table */
	int argN; /* number arguments */
	int argH; /* handle on argument data */
	int ii,fi,mi; /* indexes in int, float, mark stacks */
	Memh argMemH; /* handle on argument memory */
	long argMemL; /* size of argument memory */
	char SHUGE *argMemP; /* pointer in argument memory */
	int aii; /* index in arguments */
	long argtype; /* type of current argument */
	struct markvar FAR *argMarkP; /* pointer to marker argument */
	char FAR *fromP; /* from pointer for move */
	long moveL; /* length to move */
	long lwv;

	nn = iresP-istack;
	nf = fresP-fstack;
	nm = markP-markstack;
	markP = markstack; /* void stacks */
	fresP = fstack;
	iresP = istack;
	fRefP = FARNULL;
	argMemH = HNULL;
	argMemL = 0;
	
	if (istack[0] == 1) return; /* x = no-op */
	if (istack[0] == 2)
		nm = 0; /* q = quit program */
	if (nm && markP->len == 0)
		nm = 0; /* treat empty marker like blank tag */
		
	if (nm) { /* jumpout to another program */
	
		/* allocate memory for fileref */
	
		fRefP = (FileRef FAR *)TUTORalloc((long)sizeof(FileRef),FALSE,"fref");
		if (fRefP == FARNULL) { /* failed, no memory */
			exS.zreturn = FILEMEM;
			return;
		}
	
		/* get file name */
	
		marker_file_name(markP,(FileRef FAR *)fRefP,TRUE);
		
		/* check source or binary file exists */
	
		findx = 0;
		if (EditWn[0] < 0) { /* no editor, look for binary first */
			targetFile = *fRefP; 
			assoc_name(fRefP, (FileRef FAR *) &targetFile, ".ctb");
			findx = TUTORopen((FileRef FAR *) &targetFile,TRUE,FALSE,FALSE);
		}
		if (!findx) {
			targetFile = *fRefP; 
			findx = TUTORopen((FileRef FAR *) &targetFile,TRUE,FALSE,FALSE);
		}

		if (!findx) {
			exS.zreturn = FILEMISSING;
			TUTORdealloc((char FAR *)fRefP); 
			return(0); /* can't do the jumpout */
		}
		TUTORclose(findx);
		
		/* process arguments, compute storage requirements */
	
		argN = istack[nn-1]; /* pick up number arguments */
		ii = 1;
		mi = 1;
        for(aii=0; aii<argN; aii++) {
        	argMemL += sizeof(long); /* always need type */
            argtype = istack[ii+1];
            if (argtype == TFLOAT) 
                argMemL += sizeof(double);
            else if (argtype == TMARK) {
                argMarkP = &markstack[mi++];
                argMemL += sizeof(long); /* for length field */
                argMemL += argMarkP->len; /* length of string */
            } else argMemL += sizeof(long);
            ii += 4; /* advance index in stack */
        } /* for */
	} /* nm if */
	
	/* transfer arguments to handle */
	
	if (argMemL) {
		argMemL = (argMemL & ~3)+8; /* round length */
		argMemH = TUTORhandle("jmpout",argMemL,TRUE);	
		if (argMemH == HNULL) {
			exS.zreturn = FILEMEM;
			TUTORdealloc((char FAR *)fRefP);
			return(0); /* can't do the jumpout */
		}
		argMemP = (char FAR *)GetPtr(argMemH);
		ii = 1;
		fi = 0; 
		mi = 1;
		for(aii=0; aii<argN; aii++) {
			argtype = istack[ii+1];
			TUTORblock_move((char FAR *)&argtype,argMemP,(long)sizeof(long));
			argMemP += sizeof(long);
			if (argtype == TFLOAT) {
				fromP = (char FAR *)&fstack[fi++];
				moveL = sizeof(double);
			} else if (argtype == TMARK) {
				argMarkP = &markstack[mi++];
				lwv = argMarkP->len;
				TUTORblock_move((char FAR *)&lwv,argMemP,(long)sizeof(long));
				argMemP += sizeof(long);
				TUTORget_string_doc(argMarkP->doc,argMarkP->pos,lwv,
				                    (unsigned char FAR *)argMemP);
				argMemP += lwv;
				moveL = 0;
			} else {
				fromP = (char FAR *)&istack[ii];
				moveL = sizeof(long);
			}
			ii += 4; /* advance index in stack */
			if (moveL) {
				TUTORblock_move(fromP,argMemP,moveL);
				argMemP += moveL;
			}
		} /* for */	
		ReleasePtr(argMemH);
		KillPtr(argMemP);
	} /* argMemL if */
	
	/* stop executing current program */
	
	exS.finishunit = 0; /* cancel the finish unit pointer */
    FullHalt();  /* halt execution */
    execrun = FALSE; /* return from executor */

	/* handle blank-tag jumpout */
	
    if (nm == 0) {
		if (nosourcelayout)
        	myexit(); /* quit if executor only */
		return;
	}

    /* clear executor event queue */

    TUTORpoll_events(FALSE); /* make sure pending event is read */
    clearkeys(); /* clear out the local queue */

	/* pass handle containing arguments */
	/* this must be done after calling FullHalt() as FullHalt */
	/* destroys -jumpout- information */
	
	exS.JinfoH = argMemH; 
	exS.JargN = argN;
	if (EditWn[0] >= 0) /* use source file name if have editor */
		TUTORblock_move((char FAR *)&sourcetable[0].fRef,(char FAR *)&exS.fromRef,
	                (long)sizeof(FileRef));
	else /* use binary name if no editor */
		assoc_name(&sourcetable[0].fRef,&exS.fromRef, ".ctb");
	
    /* post switch/jumpout event */

	fileSpecified = 4; /* file name from -jumpout- command */
	TUTORzero((char FAR *)&switchEv,(long)sizeof(struct tutorevent));
	switchEv.type = EVENT_MENU;
	switchEv.eDataP = (char FAR *)fRefP;
	switchEv.timestamp = 0;
	if (EditWn[0] >= 0) { /* if editor present */
		
		/* switch focus to editor temporarily */
		
    	TUTORzero((char SHUGE *)&editEv,(long)sizeof(struct tutorevent));
    	CurEditWi = 0;
    	editEv.window = EditWn[0];
    	editEv.type = EVENT_MSG;
    	editEv.a1 = exec_toedit;
    	windowsP[EditWn[0]].MenuFocus = EditVp[0];
    	TUTORpost_event(&editEv); /* send event to editor */

		/* finish jumpout event */
		
	    switchEv.a1 = edit_switch;
		switchEv.a2 = 2;
    	switchEv.window = EditWn[0];
    	switchEv.view = EditVp[0];
	} else { /* executor only */
		switchEv.a1 = exec_jumpout;
		switchEv.window = ExecWn;
		switchEv.view = ExecVp;
	}
    TUTORpost_event(&switchEv);

} /* cmd_jumpout */

/* ------------------------------------------------------------------- */

cmd_outunit() /* -outunit- command execution */

{   register int nn;
    register int stackc; /* stack item type */
    register Memh arrdoc; /* arrow-related document */

    nn = iresP-istack;
    iresP = istack; /* void stack */

    if ((nn == 0) || (istack[0] < 0)) {
        if (exS.execunit == exS.arr.arrowunit && 
                exS.stackpntr == (exS.arr.arrowstack+exS.stackP)) {
            exS.arr.arrowunit = -1;
            stackc = unstacks(); /* look at top item on stack */
            if (stackc == STACK_ARROW) {
#ifdef IBMPC
				exS.stackpntr -= 60; /* arrow status is 64 bytes on PC */
#endif
                CloseArrow(FALSE);
            } else if (stackc == STACK_ARROW_NEST) {
                CloseArrow(FALSE);
                unstackblock((unsigned char *) &exS.arr,(int)sizeof(struct arrows));
                unstacks(); /* len */
                unstacks(); /* pos */
                arrdoc = unstacks(); /* jbuffer doc */
#ifdef IBMPC
				exS.stackpntr -= exS.arrExtra; /* remove modulo 64 padding */
#endif
                mvar_ref_doc(arrdoc); /* allow clean-up of document */
            } else stacks((long)stackc); /* restore stack item */
        }
		if (exS.useCompiled && unittab[exS.execunit].pcodeBetaH)
			set_exec_pt((unsigned int)(unittab[exS.execunit].pcodeBetaL-2)); 
		else
			set_exec_pt((unsigned int)(unittab[exS.execunit].pcodeAlphaL-2)); 
    } /* nn if */

} /* cmd_outunit */

/* ------------------------------------------------------------------- */

cmd_slice() /* return to interact loop */

{
    if (shouldint()) {
        execrun = FALSE; /* return from executor */
        waitflag = atinterrupt;
    } /* shouldint if */
    return(0);

} /* cmd_slice */

/* ------------------------------------------------------------------- */

#ifdef MAC
extern int DumpMemoryMap(void);
#endif

cmd_dmp()

{

#ifdef MAC
/*	DumpMemoryMap();  */
#endif
    return(1);

} /* cmd_dmp */

/* ------------------------------------------------------------------- */

extern int logcmd;

cmd_cmds()

{   

if (iresP != istack)
  TUTORdump("integer stack invalid in cmd_cmds");
    logcmd = (logcmd ? 0: 1);

} /* cmd_cmds */

/* ------------------------------------------------------------------- */

cmd_old() /* return to old style execution */

{

} /* cmd_old */

/* ******************************************************************* */
