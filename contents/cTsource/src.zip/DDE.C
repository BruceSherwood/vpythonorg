
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University. */

/* ******************************************************************* */

#include "baseenv.h"

#ifdef WINPC /* file is windows specific */

#define STRICT

#include <windows.h> /* required for all Windows applications */
#include <ddeml.h>
#include "ctmsw.h" /* specific to this program */

#include "execdefs.h"
#include "eglobals.h"
#include "tglobals.h"
#include "tfiledef.h"
#include "exprdefs.h"
#include "kglobals.h"
#include "video.h"
#include "ctstring.h"
#include "txt.h"
#include "commands.h"

/* ******************************************************************* */

#ifdef ctproto
extern int dde_server_names(struct markvar SHUGE *mxp);
extern int dde_topic_names(struct markvar SHUGE *mxp,char *servP);
extern int dde_item_names(struct markvar SHUGE *mxp,char *servP,char *topP);
static int dde_items_parse(struct markvar SHUGE *mxp,BYTE FAR *pData);
extern int dde_proc_unit(HCONV hConv,char FAR *dataP,long dataL);
static HCONV dde_connect(char *szService,char *szTopic);
static Memh alloc_dde(void);
static Memh identify_dde(HCONV hConv);
extern int get_dde_ref(Memh objH);
extern int set_last_dde(Memh objH,int ref);
extern int dde_event(struct tutorevent *event);
extern int TUTORclose_dde(Memh ddH);
extern int procexecwstub(unsigned int  wh,struct  tutorevent *event);
extern int object_var_close(long  SHUGE *vaddr);
extern int object_close(unsigned int  objH);
extern unsigned int find_free_object(int type);
extern int  TUTORinsert_string_doc(unsigned int  doc,long  pos,unsigned char  FAR *ss,long  sLen);
extern int  TUTORchange_doc(unsigned int  doc,long  pos,long  len,long	mpos,long  mlen,unsigned char  FAR *cp,long  cLen,long	fromOff,unsigned int  styles,unsigned int  specialT,long  *extraPos,int  eupFlag);
extern int  TUTORclear_doc(unsigned int  doc);
extern int  TUTORget_string_doc(unsigned int  doc,long	pos,long  len,unsigned char  FAR *destS);
extern int strlen(char *cc);
extern int  strlenf(char  FAR *aa);
extern long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
extern int TUTORtrace(char *s);
long  TUTORget_hsize(unsigned int  mm);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORpost_event(struct  tutorevent *event);
extern int  set_exec_pt(unsigned int  uloc);
extern long  get_exec_pt(void);
int  set_exec_pt(unsigned int  uloc);
extern int AllowHandlePurge(Memh hh);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
extern int TUTORblock_move(char SHUGE *aa,char SHUGE *bb,long length);
extern int mvar_empty(void);
extern int arraybnds(void);
int ex_arrayerr(void);
char FAR *TUTORalloc(long len,int abort,char *label);
int TUTORdealloc(char FAR *ptr);
extern int TUTORfree_handle(Memh hh);
extern int TUTORzero(char SHUGE *ptr,long length);
extern Memh TUTORhandle(char *name,long size, int puregewmrm);
int  marker_file_name(struct  markvar FAR *mx,struct  _fref FAR *fullRef,int  symbolic);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  execerr(char  *msgstr);
int  mvar_temp_cleanup(void);
int  mvar_assign(struct markvar SHUGE *vadr,struct  markvar SHUGE *mx);
int  killptr(char  FAR * FAR *ptr);
int  mvar_init(struct  markvar SHUGE *mp);
int  marker_to_string(struct  markvar SHUGE *mx,char  *s,int  limit);
long  lcftoi(double  dv);
int  iputvar(unsigned char SHUGE *vaddr,int  vkind,long  ivalue);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
extern int cmd_dde(void);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */
#ifdef macproto
#ifndef THINKC5
extern int sprintf(char *ss, char *form, ...);
extern int printf(char *form, ...);
#endif
#endif

extern long TUTORget_len_doc();
extern long l_bin();
extern long l_read();
extern double f_bin();
extern double f_read();
extern long array_addr();
extern  double lcfsysv();
extern  long lcmsysa();
extern  long lcbitcnt();
extern double CoordToFloat();
extern long pass_addr();
extern long get_exec_pt();
extern  Coord IntToCoord();
extern  Coord FloatToCoord();
extern  Coord DivCoord();
extern char FAR *GetPtr();
extern long lcftoi();
extern Memh TUTORcopy_handle();
extern long TUTORinq_msec_clock();
extern char FAR *TUTORalloc();

/* ******************************************************************* */

extern DWORD dwDDEInst; /* DDE instance handle */
extern int execrun; /* executor run/return flag */

#ifndef long_align
#define long_read(addr) (*(long SHUGE *)(addr))
#define flt_read(addr) (*(double SHUGE *)(addr))
#else
#define long_read(addr) (l_read(addr))
#define flt_read(addr) (f_read(addr))
#endif

/* ------------------------------------------------------------------- */

struct DDEinf {
    Memh ebshdrH; /* handle on object header */
    int ebsRef; /* reference count on cT object header */
    int used; /* TRUE if this item in use */
    HCONV hConv; /* handle on DDE converstation */
    char adviseUnitF; /* non-zero if cT unit to invoke */
		      /* = 0 = no unit */
		      /* = 1 = unit, no arguments */
		      /* = 2 = unit + value argument */
    int adviseUnitN;  /* unit number to invoke */
    double adviseUnitA; /* argument to pass to unit */
    long dataSize; /* size of last data block received */
    char FAR *dataP; /* pointer to last data block received */
    Memh nextDDE; /* handle on next DDE object in chain */
}; /* DDEinf */

static Memh firstDDE = HNULL; /* handle on first DDE object in chain */

/* ------------------------------------------------------------------- */

int cmd_dde() /* dynamic data exchange commands */

{   int ni; /* number items on integer stack */
    int nm; /* number items on marker stack */
    int cmdType; /* type of command to execute */
    struct markvar mx; /* temp marker */
    struct markvar SHUGE *mxp; /* pointer to marker var */
    struct markvar SHUGE *maddr; /* address of marker variable */
    struct markvar SHUGE *mz; /* pointer to marker argument */
    long len; /* length of name string */
    char serverN[128]; /* server name or value string */
    char topicN[128]; /* topic or item name */
    Memh objH; /* handle on dde object header */
    struct ebshdr FAR *objP; /* pointer to object header */
    Memh ddeH; /* handle on dde object */
    struct DDEinf FAR *ddeP; /* pointer to dde object */
    int unitN; /* unit to invoke */
    int unitF; /* unit argument flag */
    double unitArg; /* argument to pass to unit */
    HSZ hszItem; /* handle on item name */
    HSZ hszValue; /* handle on item value */
    HCONV hConv; /* handle on conversation */
    DWORD dwResult, dwLength;
    HDDEDATA hDDEData; /* transaction reply */
    BYTE FAR *pData; /* pointer to reply data */
    long extraDumm;

    ni = iresP-istack;
    nm = markP-markstack;
    iresP = istack; /* void stacks */
    fresP = fstack;
    markP = markstack;
    exS.zreturn = -1; /* pre-set for success */
    exS.zretinf = 0; /* no names yet */

    cmdType = (int)istack[0]; /* pick up command type */
    if ((cmdType == 1) || (cmdType == 2) || (cmdType == 3)) {

	/* set up result marker for information requests */

	maddr = (struct markvar SHUGE *)istack[3];
	mvar_init((struct markvar SHUGE *)&mx); /* set up new marker */
	mx.pos = mx.len = mx.doclen = 0;
	mxp = (struct markvar SHUGE *)&mx;
    } /* cmdType if */

    switch (cmdType) {

    case 1: /* servers */
	exS.zretinf = dde_server_names(mxp);
	mvar_assign(maddr,mxp);
	break;

    case 2: /* topics */
    case 3: /* items */
	mz = markP+1; /* 2nd marker on stack = server name */
	len = mz->len;
	if (len >= 126) len = 126;
	TUTORget_string_doc(mz->doc,mz->pos,len,
			   (unsigned char FAR *)serverN);
	serverN[len] = 0;
	if (cmdType == 2) {
	    exS.zretinf = dde_topic_names(mxp,serverN);
	} else if (cmdType == 3) {
	    mz = markP+2; /* 3rd marker on stack = topic name */
	    len = mz->len;
	    if (len >= 126) len = 126;
	    TUTORget_string_doc(mz->doc,mz->pos,len,
			       (unsigned char FAR *)topicN);
	    topicN[len] = 0;
	    exS.zretinf = dde_item_names(mxp,serverN,topicN);
	}
	mvar_assign(maddr,mxp);
	break;

    case 4: /* connect */

	/* close DDE object if already open */

	if (istack[1]) {
	    if (exS.last_dde == (Memh)istack[1])
		exS.last_dde = HNULL;
	    object_var_close((long SHUGE *)istack[3]);
        }

	/* attempt to connect to server */

	mz = markP; /* 1st marker on stack = server name */
	len = mz->len;
	if (len >= 126) len = 126;
	TUTORget_string_doc(mz->doc,mz->pos,len,
			   (unsigned char FAR *)serverN);
	serverN[len] = 0;
	mz = markP+1; /* 2nd marker on stack = topic name */
	len = mz->len;
	if (len >= 126) len = 126;
	TUTORget_string_doc(mz->doc,mz->pos,len,
			   (unsigned char FAR *)topicN);
	topicN[len] = 0;
	hConv = dde_connect(serverN,topicN);
	if (!hConv) {
	    exS.zreturn = FILEMISSING;
	    return(0); /* no go */
	}

	/* create DDE object+header */

	objH = find_free_object(TXDDE);
	objP = (struct ebshdr FAR *)GetPtr(objH);
	ddeH = alloc_dde(); /* allocate DDEinf */
	if (!ddeH) {
	    exS.zreturn = FILEMEM; /* couldn't create data structure */
	    break;
	}
	ddeP = (struct DDEinf FAR *)GetPtr(ddeH);
	ddeP->ebshdrH = objH; /* cT object header */
	ddeP->ebsRef = objP->refcnt; /* reference count */
	ddeP->hConv = hConv; /* handle on conversation */
	objP->objectH = ddeH;
	ReleasePtr(objH); /* done with object header */
	*(long FAR *)istack[3] = (long)objH;
	ReleasePtr(ddeH); /* done with dde object */
	break;

    case 5: /* request */

	/* get item name from marker variable */

	mz = markP; /* 1st marker on stack = item name */
	len = mz->len;
	if (len >= 126) len = 126;
	TUTORget_string_doc(mz->doc,mz->pos,len,
			   (unsigned char FAR *)topicN);

	/* set up result marker for request reply */

	maddr = (struct markvar SHUGE *)istack[7];
	mvar_init((struct markvar SHUGE *)&mx); /* set up new marker */
	mx.pos = mx.len = mx.doclen = 0;
	mxp = (struct markvar SHUGE *)&mx;
	mvar_assign(maddr,mxp); /* reassign marker */

	/* get connection info */

	objH = (Memh)istack[1];
	if (!objH) {
	    exS.zreturn = FILENOTOPEN;
	    return(0);
	}
	objP = (struct ebshdr FAR *)GetPtr(objH);
	ddeH = objP->objectH;
	ddeP = (struct DDEinf FAR *)GetPtr(ddeH);
	hConv = ddeP->hConv;
	if (hConv) { /* connection established */

	    /* post request of item to server */

	    hszItem = DdeCreateStringHandle(dwDDEInst,topicN,CP_WINANSI);
	    hDDEData = DdeClientTransaction(NULL,0,hConv,hszItem,CF_TEXT,
				    XTYP_REQUEST,5000L,&dwResult);
	    DdeFreeStringHandle(dwDDEInst,hszItem);

	    /* copy reply data to marker */

	    if (hDDEData) {
		pData = DdeAccessData(hDDEData,&dwLength); /* lock data */
		if (pData) {
		    len = strlenf(pData);
		    if (len) {
			TUTORchange_doc(mx.doc,0L,0L,0L,0L,
				    (unsigned char FAR *)pData,len,
				    0L,HNULL,HNULL,&extraDumm,FALSE);
		    }
		    DdeUnaccessData(hDDEData); /* release data handle */
		    mxp->len = mxp->doclen = len;
		} /* pData if */
		DdeFreeDataHandle(hDDEData); /* release memory */
	    } /* hDDEData if */
	} else {
	    exS.zreturn = FILENOTOPEN; /* no connection */
	}
	ReleasePtr(ddeH);
	ReleasePtr(objH);
	break;

    case 6: /* advise */

	/* get item name from marker variable */

	mz = markP; /* 1st marker on stack = item name */
	len = mz->len;
	if (len >= 126) len = 126;
	TUTORget_string_doc(mz->doc,mz->pos,len,
			   (unsigned char FAR *)topicN);

	/* get connection info */

	objH = (Memh)istack[1];
	if (!objH) {
	    exS.zreturn = FILENOTOPEN;
	    return(0);
	}
	objP = (struct ebshdr FAR *)GetPtr(objH);
	ddeH = objP->objectH;
	ddeP = (struct DDEinf FAR *)GetPtr(ddeH);
	hConv = ddeP->hConv;
	if (hConv) { /* connection established */

	    /* set unit to respond to advise transactions */

	    unitN = (int)istack[5]; /* unit number */
	    unitF = 1; /* assume no argument */
	    unitArg = 0.0;
	    if (istack[6]) { /* unit has argument */
		unitArg = fstack[0];
		unitF = 2; /* unit has argument */
	    } /* istack if */
	    if (unitN == UNITX) unitF = 0; /* unit x can't have argument */

	    ddeP->adviseUnitF = unitF;
	    ddeP->adviseUnitN = unitN;
	    ddeP->adviseUnitA = unitArg;

	    /* post advise start request to server */

	    hszItem = DdeCreateStringHandle(dwDDEInst,topicN,CP_WINANSI);
	    hDDEData = DdeClientTransaction(NULL,0,hConv,hszItem,CF_TEXT,
				    XTYP_ADVSTART,5000L,NULL);
	    DdeFreeStringHandle(dwDDEInst,hszItem);
	} else {
	    exS.zreturn = FILENOTOPEN; /* no connection */
	}
	ReleasePtr(ddeH);
	ReleasePtr(objH);
	break;

    case 7: /* poke */

	/* get item name from marker variable */

	mz = markP; /* 1st marker on stack = item name */
	len = mz->len;
	if (len >= 126) len = 126;
	TUTORget_string_doc(mz->doc,mz->pos,len,
			   (unsigned char FAR *)topicN);

	/* get item value from marker variable */

	mz = markP+1; /* 2nd marker on stack = item value */
	len = mz->len;
	if (len >= 126) len = 126;
	TUTORget_string_doc(mz->doc,mz->pos,len,
			   (unsigned char FAR *)serverN);
	serverN[len] = 0;
	len++; /* include terminating zero */

	/* get connection info */

	objH = (Memh)istack[1];
	if (!objH) {
	    exS.zreturn = FILENOTOPEN;
	    return(0);
	}
	objP = (struct ebshdr FAR *)GetPtr(objH);
	ddeH = objP->objectH;
	ddeP = (struct DDEinf FAR *)GetPtr(ddeH);
	hConv = ddeP->hConv;
	if (hConv) { /* connection established */

	    /* post poke request to server */

	    hszItem = DdeCreateStringHandle(dwDDEInst,topicN,CP_WINANSI);
	    hDDEData = DdeClientTransaction((void FAR *)serverN,len,hConv,
				    hszItem,CF_TEXT,XTYP_POKE,5000L,NULL);
	    DdeFreeStringHandle(dwDDEInst,hszItem);
	} else {
	    exS.zreturn = FILENOTOPEN; /* no connection */
	}
	ReleasePtr(ddeH);
	ReleasePtr(objH);
	break;

    case 8: /* execute */

	/* get execute command from marker variable */

	mz = markP; /* 1st marker on stack = command */
	len = mz->len;
	if (len >= 126) len = 126;
	TUTORget_string_doc(mz->doc,mz->pos,len,
			   (unsigned char FAR *)serverN);
	serverN[len] = 0;
	len++; /* include terminating zero */

	/* get connection info */

	objH = (Memh)istack[1];
	if (!objH) {
	    exS.zreturn = FILENOTOPEN;
	    return(0);
	}
	objP = (struct ebshdr FAR *)GetPtr(objH);
	ddeH = objP->objectH;
	ddeP = (struct DDEinf FAR *)GetPtr(ddeH);
	hConv = ddeP->hConv;
	if (hConv) { /* connection established */

	    /* post execute request to server */

	    hDDEData = DdeClientTransaction((void FAR *)serverN,len,hConv,
				    NULL,CF_TEXT,XTYP_EXECUTE,5000L,NULL);
	} else {
	    exS.zreturn = FILENOTOPEN; /* no connection */
	}
	ReleasePtr(ddeH);
	ReleasePtr(objH);
	break;

    default:
	break;

    } /* switch */

    mvar_temp_cleanup(); /* release temp document(s) */
    return(0);

} /* cmd_dde */

/* ------------------------------------------------------------------- */

static int dde_server_names(mxp) /* read active server names to marker */
struct markvar SHUGE *mxp; /* pointer to marker var */

{   HSZ hszSystem; /* string handle */
    HCONVLIST hConvList; /* handle on list of conversations */
    HCONV hConv; /* conversation handle */
    CONVINFO cInfo; /* structure for conversation data */
    UINT infRet; /* return from query function */
    int nFound; /* number server names found */
    long infol; /* length of info found */
    long ml; /* current marker length */
    long extraDumm;
    char buf[128]; /* buffer for server name */

    nFound = 0; /* haven't found anything yet */
    hszSystem = DdeCreateStringHandle(dwDDEInst,SZDDESYS_TOPIC,CP_WINANSI);
    hConvList = DdeConnectList(dwDDEInst,NULL,hszSystem,NULL,NULL);
    DdeFreeStringHandle(dwDDEInst, hszSystem);

    if (hConvList) {

	/* build list of server names */

	hConv = NULL;
	cInfo.cb = sizeof(CONVINFO); /* must specify length */
 
	while (hConv = DdeQueryNextServer(hConvList,hConv)) {

	    /* get information on next conversation */

	    infRet = DdeQueryConvInfo(hConv,(DWORD)QID_SYNC,&cInfo);

	    /* get name of next server */

	    DdeQueryString(dwDDEInst,cInfo.hszSvcPartner,buf,sizeof(buf),
			   CP_WINANSI);

	    /* add to marker */

	    infol = strlen(buf);
	    if (infol) {
		nFound++; /* increment number names */
		ml = mxp->doclen;
		if (ml) { /* insert space before next name */
		    TUTORchange_doc(mxp->doc,mxp->doclen,0L,0L,0L,(unsigned char FAR *)" ",
			1L,0L,HNULL,HNULL,&extraDumm,FALSE);
		    mxp->doclen = ml = ml+1;
		}
		TUTORchange_doc(mxp->doc,mxp->doclen,0L,0L,0L,(unsigned char FAR *)buf,
		    infol,0L,HNULL,HNULL,&extraDumm,FALSE);
		mxp->len = mxp->doclen = ml+infol;
	    } /* infol if */
	} /* while */
	DdeDisconnectList(hConvList); /* free conversation list handle */
    } /* hConvList if */

    mxp->alteredF = 0;
    return(nFound);

} /* dde_server_names */

/* ------------------------------------------------------------------- */

static int dde_topic_names(mxp,szService) /* get topics for server */
struct markvar SHUGE *mxp; /* pointer to marker var */
char *szService; /* pointer to server name */

{   HSZ hszService, hszSystem, hszItem;
    HCONV hConv;
    HDDEDATA hDDEData;
    DWORD dwResult, dwLength;
    BYTE FAR *pData;
    int nFound; /* number topics found */

    /* connect to server */

    hszSystem = DdeCreateStringHandle(dwDDEInst,SZDDESYS_TOPIC,
				      CP_WINANSI);
    hszService = DdeCreateStringHandle(dwDDEInst,szService,
				      CP_WINANSI);
    hConv = DdeConnect(dwDDEInst,hszService,hszSystem,NULL);
    DdeFreeStringHandle(dwDDEInst,hszSystem); /* release memory */
    DdeFreeStringHandle(dwDDEInst,hszService);
    if (!hConv)
	return(0); /* couldn't talk to server */

    /* get topic list in CF_TEXT format */

    hszItem = DdeCreateStringHandle(dwDDEInst,SZDDESYS_ITEM_TOPICS,
                                    CP_WINANSI);
    hDDEData = DdeClientTransaction(NULL,0,hConv,hszItem,CF_TEXT,
				    XTYP_REQUEST,5000L,&dwResult);
    DdeFreeStringHandle(dwDDEInst,hszItem);

    nFound = 0; /* nothing found yet */
    if (hDDEData) {
	pData = DdeAccessData(hDDEData,&dwLength); /* lock data */
	if (pData) {
	    nFound = dde_items_parse(mxp,pData);
	    DdeUnaccessData(hDDEData); /* release data handle */
	} /* pData if */
	DdeFreeDataHandle(hDDEData); /* release memory */
    } /* hDDEData if */

    DdeDisconnect(hConv); /* terminate conversation */

    return(nFound);

} /* dde_topic_names */

/* ------------------------------------------------------------------- */

static int dde_item_names(mxp,szService,szTopic) /* get items for server,topic */
struct markvar SHUGE *mxp; /* pointer to marker var */
char *szService; /* pointer to server name */
char *szTopic; /* pointer to topic name */

{   HSZ hszItem;
    HCONV hConv;
    HDDEDATA hDDEData;
    DWORD dwResult, dwLength;
    BYTE FAR* pData;
    int nFound; /* number topics found */

    nFound = 0; /* haven't found anything yet */

    /* connect to server */

    hConv = dde_connect(szService,szTopic);
    if (!hConv)
	return(0); /* couldn't talk to server */

    /* get item list in CF_TEXT format */
    /* if "system" topic, use "SysItems", not "TopicItemList" */

    if (lstrcmpi(szTopic, SZDDESYS_TOPIC) == 0) {
        hszItem = DdeCreateStringHandle(dwDDEInst,
					SZDDESYS_ITEM_SYSITEMS,CP_WINANSI);
    } else {
        hszItem = DdeCreateStringHandle(dwDDEInst,
					SZDDE_ITEM_ITEMLIST,CP_WINANSI);
    }
    hDDEData = DdeClientTransaction(NULL,0,hConv,hszItem,CF_TEXT,
				    XTYP_REQUEST,5000L,&dwResult);
    DdeFreeStringHandle(dwDDEInst,hszItem);
    if (hDDEData) {
	pData = DdeAccessData(hDDEData, &dwLength);
	if (pData) {
	    nFound = dde_items_parse(mxp,pData);
	    DdeUnaccessData(hDDEData); /* release data handle */
	} /* pData if */
	DdeFreeDataHandle(hDDEData); /* release memory */
    } /* hDDEData if */

    DdeDisconnect(hConv); /* terminate conversation */

    return(nFound);

} /* dde_item_names */

/* ------------------------------------------------------------------- */

static int dde_items_parse(mxp,pData) /* parse item or topic names */
struct markvar SHUGE *mxp; /* pointer to result marker var */
BYTE FAR *pData; /* pointer to topic/item name string */

{   long namel; /* length of current name */
    long ml; /* current marker length */
    char FAR *tbP; /* pointer to start of name */
    char FAR *twP; /* pointer in name */
    int nFound; /* number names found */
    long extraDumm;

    if (!pData)
	return(0); /* nothing to do */
    nFound = 0; /* haven't found anything yet */

    /* extract topic/item names */

    tbP = pData;
    while (*tbP) {
	twP = tbP; /* start of name */
	while (*twP && (*twP != '\t'))
	    twP++;
	namel = twP-tbP;
	if (namel) {
	    nFound++; /* increment number names */
	    ml = mxp->doclen;
	    if (ml) { /* insert space before next name */
		TUTORchange_doc(mxp->doc,mxp->doclen,0L,0L,0L,
				(unsigned char FAR *)" ",
				1L,0L,HNULL,HNULL,&extraDumm,FALSE);
		 mxp->doclen = ml = ml+1;
	    } /* ml if */
	    TUTORchange_doc(mxp->doc,mxp->doclen,0L,0L,0L,
			    (unsigned char FAR *)tbP,
			    namel,0L,HNULL,HNULL,&extraDumm,FALSE);
	    mxp->len = mxp->doclen = mxp->doclen = ml+namel;
	    if (!(*twP))
		break; /* exit while */
	    tbP = twP+1; /* advance to start of next name */
	} /* namel if */
    } /* tbP while */

    return(nFound); /* return number names found */

} /* dde_items_parse */

/* ------------------------------------------------------------------- */

static HCONV dde_connect(szService,szTopic) /* connect to server */
char *szService; /* pointer to server name */
char *szTopic; /* pointer to topic name */

{   HSZ hszService, hszTopic;
    HCONV hConv;

    /* connect to server */

    hszTopic = DdeCreateStringHandle(dwDDEInst,szTopic,CP_WINANSI);
    hszService = DdeCreateStringHandle(dwDDEInst,szService,CP_WINANSI);
    hConv = DdeConnect(dwDDEInst,hszService,hszTopic,NULL);
    DdeFreeStringHandle(dwDDEInst, hszTopic);
    DdeFreeStringHandle(dwDDEInst, hszService);
    return(hConv);

} /* dde_connect */

/* ------------------------------------------------------------------- */

int dde_proc_unit(hConv,dataP,dataL) /* process advise event */
HCONV hConv; /* handle on conversation */
char FAR *dataP; /* pointer to data received */
long dataL; /* size of data received */

{   Memh ddeH; /* handle on dde object */
    struct DDEinf FAR *ddeP; /* pointer to dde object */
    struct tutorevent aev; /* event to send to executor */

    ddeH = identify_dde(hConv); /* look up object */
    if (!ddeH)
	return(FALSE); /* can't identify conversation */
    ddeP = (struct DDEinf FAR *)GetPtr(ddeH);
    TUTORzero((char FAR *)&aev,(long)sizeof(struct tutorevent));
    aev.type = EVENT_SIGNAL;
    aev.window = -1; /* not sent to a window */
    aev.eDataP = dataP; /* pointer to data */
    aev.a4 = dataL; /* length of data */
    aev.a5 = (long) hConv; /* conversation */
    aev.timestamp = 0;
    aev.vproc = procexecwstub;
    if (ddeP->adviseUnitF == 1)
	aev.a1 = BUTTONSIGNAL;
    else
	aev.a1 = BUTTONSIGNALA;
    aev.a2 = ddeP->ebshdrH;
    aev.a6 = ddeP->ebsRef;
    aev.a3 = ddeP->adviseUnitA;
    aev.value = ddeP->adviseUnitN;
    TUTORpost_event(&aev);

    ReleasePtr(ddeH);
    return(TRUE);

} /* dde_proc_unit */

/* ------------------------------------------------------------------- */

int dde_event(event) /* set up data for dde event */
struct tutorevent *event; /* pointer to dde event */

{   Memh ddeH; /* handle on dde object */
    struct DDEinf FAR *ddeP; /* pointer to dde object */

    ddeH = identify_dde((HCONV)event->a5); /* look up conversation */
    if (!ddeH)
	return(0); /* can't identify conversation */
    ddeP = (struct DDEinf FAR *)GetPtr(ddeH);
    if (ddeP->dataP)
	TUTORdealloc(ddeP->dataP); /* deallocate previous block */
    ddeP->dataSize = event->a4; /* set size of data block */
    ddeP->dataP = event->eDataP;
    event->eDataP = FARNULL; /* detach data block from event */
    ReleasePtr(ddeH);
    return(0);

} /* dde_event */

/* ------------------------------------------------------------------- */

int set_last_dde(objH,refcnt) /* set zdde */
Memh objH; /* handle on cT object */
int refcnt; /* reference count of object */

{   struct ebshdr FAR *objP; /* pointer to cT object header */
    int hdrrefc; /* reference count from header */
    int objref; /* reference count from object */

    hdrrefc = -1; 
    if (objH) {
        objP = (struct ebshdr FAR *)GetPtr(objH);
        hdrrefc = objP->refcnt; /* get reference count from header */
        ReleasePtr(objH);
    }
    objref = get_dde_ref(objH);
    if ((refcnt != objref) || (objref != hdrrefc) || (!objref))
        objH = objref = 0; /* object is no longer valid */
    exS.last_dde = objH;
    exS.last_dde_ref = objref;
    return(0);

} /* set_last_dde */

/* ------------------------------------------------------------------- */

int get_dde_ref(objH) /* get dde object reference count */
Memh objH; /* handle on cT object */

{   struct ebshdr FAR *objP; /* pointer to cT object */
    Memh ddeH; /* handle on DDE info */
    struct DDEinf FAR *ddeP; /* pointer to dde object */
    int refcnt;
    
    if (!objH) return(0);
    objP = (struct ebshdr FAR *)GetPtr(objH);
    ddeH = objP->objectH; /* handle on dde info */
    ReleasePtr(objH);
    ddeP = (struct DDEinf FAR *)GetPtr(ddeH);
    refcnt = ddeP->ebsRef; /* get reference count */
    ReleasePtr(ddeH);
    return(refcnt);

} /* get_dde_ref */

/* ------------------------------------------------------------------- */

int get_zddetext() /* sets up marker containing last dde data block */

{   Memh objH; /* handle on cT object */
    struct ebshdr FAR *objP; /* pointer to cT object */
    Memh ddeH; /* handle on DDE info */
    struct DDEinf FAR *ddeP; /* pointer to dde object */
    char FAR *dataP; /* pointer to data block */
    long dataL; /* length of data block */

    dataL = 0; /* no data lock yet */
    objH = *(--iresP);
    if (objH) {
	objP = (struct ebshdr FAR *)GetPtr(objH);
	ddeH = objP->objectH; /* handle on dde info */
	ReleasePtr(objH);
	ddeP = (struct DDEinf FAR *)GetPtr(ddeH);
	dataP = ddeP->dataP; /* pointer to data block */
	dataL = ddeP->dataSize; /* get size of data block */
	if ((!dataP) || (!ddeP->used))
	    dataL = 0; /* no data */
	ReleasePtr(ddeH);
    } /* objH if */

    if (!dataL) {
        mvar_empty(); 
    } else {
        mvar_init(markP); /* set up new temp marker */
	TUTORinsert_string_doc(markP->doc,0L,(unsigned char FAR *)dataP,dataL);
	markP->doclen = markP->len = dataL;
	markP++;
    } /* else */
    return(0);

} /* get_zddetext */

/* ------------------------------------------------------------------- */

static Memh alloc_dde() /* allocate dde object */

{   Memh foundH; /* handle on dde object found */
    Memh nextH; /* handle on next object in chain */
    Memh tempH;
    struct DDEinf FAR *ddeP; /* pointer to dde object */

    foundH = HNULL; /* haven't found anything yet */

    /* look for existing free object */

    nextH = firstDDE;
    while (nextH && (!foundH)) {
	tempH = nextH; /* save nextH */
	ddeP = (struct DDEinf FAR *)GetPtr(tempH);
	if (!ddeP->used)
	    foundH = tempH; /* found a free object */
	nextH = ddeP->nextDDE; /* handle on next object */
	ReleasePtr(tempH);
    } /* while */

    /* if didn't find free object, create one */

    if (!foundH) {
	foundH = TUTORhandle("dde",(long)sizeof(struct DDEinf),TRUE);
	if (!foundH)
	    return(0); /* no go */
	ddeP = (struct DDEinf FAR *)GetPtr(foundH);
	ddeP->nextDDE = firstDDE; /* point to next object */
	firstDDE = foundH; /* make this first */
	ReleasePtr(foundH);
    } /* foundH if */

    /* initialize or recycle DDE object */

    ddeP = (struct DDEinf FAR *)GetPtr(foundH);
    nextH = ddeP->nextDDE; /* save handle on next object */
    TUTORzero((char SHUGE *)ddeP,(long)sizeof(struct DDEinf));
    ddeP->nextDDE = nextH; /* restore next */
    ddeP->used = TRUE;
    ReleasePtr(foundH);

    return(foundH);

} /* alloc_dde */

/* ------------------------------------------------------------------- */

static Memh identify_dde(hConv) /* identify dde object of conversation */
HCONV hConv; /* handle on conversation */

{   Memh foundH; /* handle on dde object found */
    Memh nextH; /* handle on next object in chain */
    Memh tempH;
    struct DDEinf FAR *ddeP; /* pointer to dde object */

    foundH = HNULL; /* haven't found anything yet */

    /* look for specified conversation */

    nextH = firstDDE;
    while (nextH && (!foundH)) {
	tempH = nextH; /* save nextH */
	ddeP = (struct DDEinf FAR *)GetPtr(tempH);
	if (ddeP->used && (ddeP->hConv == hConv))
	    foundH = tempH; /* found the object */
	nextH = ddeP->nextDDE; /* handle on next object */
	ReleasePtr(tempH);
    } /* while */

    return(foundH); /* return handle on object found */

} /* identify_dde */

/* ------------------------------------------------------------------- */

int TUTORclose_dde(ddeH) /* close dde connection */
Memh ddeH; /* handle on dde connection */

{   struct DDEinf FAR *ddeP; /* pointer to DDE info */

    if (!ddeH)
	return(0);
    ddeP = (struct DDEinf FAR *)GetPtr(ddeH);
    ddeP->used = FALSE; /* no longer in use */
    if (ddeP->hConv)
	DdeDisconnect(ddeP->hConv); /* terminate conversation */
    ddeP->hConv = (HCONV)FARNULL;
    if (ddeP->dataP)
	TUTORdealloc(ddeP->dataP); /* drop data block */
    ddeP->dataP = FARNULL;
    ddeP->dataSize = 0;
    ReleasePtr(ddeH);
    return(0);

} /* TUTORclose_dde */

/* ------------------------------------------------------------------- */

#endif /* WINPC */
