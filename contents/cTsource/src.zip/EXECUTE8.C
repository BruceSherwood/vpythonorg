
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University. */

/* file & io commands */

#include <stdio.h>
#include "execdefs.h"
#include "eglobals.h"
#include "tglobals.h"
#include "tfiledef.h"
#include "exprdefs.h"
#include "kglobals.h"
#include "video.h"
#include "txt.h"
#include "editor.h"

/* ******************************************************************* */

#ifdef ctproto
extern int TUTORclose_dde(Memh hh);
extern long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
extern int TUTORtrace(char *s);
extern int TUTORinput_dialog(int wn,char *msg,char *input);
extern int TUTORync_dialog(int wn, char *msg);
extern int TUTORok_dialog(int wn,char *msg);
long  TUTORget_hsize(unsigned int  mm);
int  TUTORfree_handle(unsigned int  mm);
extern Memh TUTORget_default_rgb(void);
extern int CTcount_colors(int oldF);
int TUTORset_color_rgb(int select,int SysOrPal,double red,double green,double blue);
extern int  set_exec_pt(unsigned int  uloc);
extern long  get_exec_pt(void);
extern int TUTORwait_socket(int fIndx,int type);
extern int cmd_sockwait(void);
extern int TUTORpoll_events(int block);
int  set_exec_pt(unsigned int  uloc);
extern int MovieSupport(void);
extern int MovieOpen(FileRef *fRef);
extern int MoviePlay(double from,double to);
extern int TUTORforce_redraw(int wid);
extern int AllowHandlePurge(Memh hh);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
int cvt_font_name(char *nstr);
int  TUTORadd_inset_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,int  kind,unsigned int  dat,long  *extraPos);
extern int TUTORblock_move(char SHUGE *aa,char SHUGE *bb,long length);
extern int arraybnds(void);
extern int cmd_block(void);
extern int UnlockExec(void);
extern int LockExec(void);
extern int TUTORrelease_font(int findx,long fam,int size,int face,int forget);
long TUTORparse_font_family(struct  _fref *fontTag,struct  _fref *familyName,int  isFont,int  oneTag,int  *fontSize);
int CTset_foreground_color(int cn);
int CTset_background_color(int cn);
extern int TUTORset_view(struct tutorview FAR *vp);
extern int TUTORinq_foreground_color(struct tutorColor *fc);
extern int TUTORinq_background_color(struct tutorColor *bc);
int  RefreshPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  cpos,long  clen,long  newC,long  selStart,long  selLen,int  scroll,int force);
extern int StartPicture(int type,int fileid,TRect FAR *pR,int dpi);
extern int FinishPicture(void);
int ex_arrayerr(void);
long  TUTORinq_symbolic_font_id(char  *fontName);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
int  mvar_get_inf(unsigned int  docH,long  *len,long *users,long  *head);
int  TUTORmaintain_doc_view(struct  _ktd FAR *dp,long  pos,long len,long  cpos,long  clen,long  newC);
int  TUTORstyle_hot_doc(unsigned int  doc,long  pos,long  len,unsigned char FAR *ss,long  sLen);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
int  TUTORstyle_doc(unsigned int  doc,long  pos,long  len,int  type,int  dat,int  canCombine,long  *extraPos);
char FAR *TUTORalloc(long len,int abort,char *label);
int TUTORdealloc(char FAR *ptr);
extern int TUTORfree_handle(Memh hh);
extern int TUTORzero(char SHUGE *ptr,long length);
extern Memh TUTORhandle(char *name,long size, int puregewmrm);
extern  int TUTORset_file_type(FileRef FAR *fName,int findx,int type,int xx,int yy);
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
int  CloseFile(long SHUGE *loc);
int  lclocy(long  q);
int  lclocx(long  q);
int  InitMMotionVideo(void);
int  InitExternalVideo(int  findx);
int  TUTORopen_serial(int  port,long  baud,int  datab,int  parity,double  stopb);
int  marker_file_name(struct  markvar FAR *mx,struct  _fref FAR *fullRef,int  symbolic);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  FinishFileOpen(long SHUGE *loc,int  findx);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  TUTORfile_exists(struct  _fref FAR *fRef);
int  setclip(void);
int  TUTORreadfile_dialog(int  wn,char  *msghdr,struct  _fref *filename,char *defname,int  maxRet,int  type,int  msgb,int  doRedraw);
int  unclip(void);
int  execerr(char  *msgstr);
int  TUTORclose(int  findx);
int  mvar_temp_cleanup(void);
int  TUTORfwrite_doc(unsigned int  doc,long  pos,long  len,int  fInd,int  nativeF);
int  FileWriteOK(long  findx);
int  fputvar(unsigned char SHUGE *vaddr,int  vkind,double  fvalue);
int  ReadNumber(int  findx,double  *value);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORfread_doc(unsigned int  doc,long  len,int  docKind,int  fInd);
int  mvar_assign(struct markvar SHUGE *vadr,struct  markvar SHUGE *mx);
int  killptr(char  FAR * FAR *ptr);
int  FileIsOpen(long  fid);
int  mvar_init(struct  markvar SHUGE *mp);
int  sizetv(int  opc);
int  flush(void);
int  TUTORreset_file(int  findx,int  option);
int  DeleteFile(long SHUGE *loc);
long  TUTORwrite(char  FAR *ptr,int  pSize,long  count,int  findx);
int  marker_to_string(struct  markvar SHUGE *mx,char  *s,int  limit);
int  TUTORwrite_char(int cc,int  findx);
long  lcftoi(double  dv);
int  iputvar(unsigned char SHUGE *vaddr,int  vkind,long  ivalue);
int  TUTORget_char(int  findx,int  tryHard);
int  TUTORsocket_client(char  *addr,int  aType,int  nn);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int  TUTORserver(char  *addr,int  aType,char  *info);
int  TUTORsocket_server(int  fInd);
int  appenddoc(unsigned int  theDoc,char  FAR *sP,int  sLen);
int  TUTORcvt_native_chars(unsigned char  FAR *cp,long  clen);
int  TUTORchange_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,unsigned char  FAR *cp,long  cLen,long  fromOff,unsigned int  styles,unsigned int  specialT,long  *extraPos,int  eupFlag);
int  TUTORhosts(char  *addr,int  nn,char  *info,int  infoSize,int  *nNames);

extern int cmd_dde(void);

#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
#ifndef THINKC5
#ifndef WERKS
extern int sprintf(char *ss, char *form, ...);
extern int printf(char *form, ...);
#endif
#endif
#endif

extern long TUTORget_len_doc();
extern long l_bin();
extern long l_read();
extern double f_bin();
extern double f_read();
extern long array_addr();
extern  double lcfsysv();
extern  long lcmsysa();
extern  long lcbitcnt();
extern double CoordToFloat();
extern long pass_addr();
extern long get_exec_pt();
extern  int TimedPauseStub();
extern double evalduser();
extern Memh darrowv(); /* handle on arrow text */
extern Memh dtextv();   /* handle on displayed text */
extern  Coord IntToCoord();
extern  Coord FloatToCoord();
extern  Coord DivCoord();
extern  long TUTORwrite();
extern char FAR *GetPtr();
extern  long TUTORread();
extern long lcftoi();
extern Memh TUTORcopy_handle();
extern long TUTORinq_msec_clock();
long  TUTORabs_save_region();
extern char FAR *TUTORalloc();

/* ******************************************************************* */

extern int execrun; /* executor run/return flag */

#ifndef long_align
#define long_read(addr) (*(long SHUGE *)(addr))
#define flt_read(addr) (*(double SHUGE *)(addr))
#else
#define long_read(addr) (l_read(addr))
#define flt_read(addr) (f_read(addr))
#endif

#ifndef style_plain
#define style_plain 0
#endif

/* ------------------------------------------------------------------- */

int cmd_dde()

{
	return(0); 

} /* cmd_dde */

/* ------------------------------------------------------------------- */

int TUTORclose_dde(hh)
Memh hh;

{
	return(0);
	
} /* TUTORclose_dde */

/* ------------------------------------------------------------------- */

extern int dde_event(void);
extern int get_dde_ref(void);
extern int get_zddetext(void);
extern int set_last_dde(void);

int dde_event() { return(0); }
int get_dde_ref() { return(0); }
int get_zddetext() { return(0); }
int set_last_dde() { return(0); }

/* ------------------------------------------------------------------- */
