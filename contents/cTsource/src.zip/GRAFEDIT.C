
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "compute.h" /*note this also includes <strings.h> and <math.h>.*/
#include "commands.h"
#include "tutor.h"
#include "ecglobal.h"
#include "edglobal.h"
#include "tglobals.h"
#include "ct_ctype.h"
#include "editor.h"

/* - if this is defined, grafedit will work, but it sees executor variables */
#define LOOKEXECUTOR
#ifdef LOOKEXECUTOR
#include "eglobals.h" /* just for SetCoordString routine! */

/* checkbit defined in execdefs.h */
#define checkbit(qq,nn) ((qq & (1 << nn)) != 0)

extern double lcfcoord();
extern double lcitof();
extern long TUTORget_len_doc();

/*#define DEBUGGING 0 */

#define g_Absolute 1
#define g_InitGraph 2
#define g_Graphing 3
#define g_Relative 4
#define g_Calc 5
#define g_Special 6
#define g_NoGood 7

static int command; /* command which starts current line when inserting x,y */
#else
grafedit(MouseAction, mx, my)
/* MouseAction is zk(left: down) etc. -- CMU Tutor format */
	int MouseAction, mx, my;
	{
	return(FALSE); /* no graphics editing */
	}
#endif

#ifdef LOOKEXECUTOR

#ifdef ctproto
extern int killptr(char FAR * FAR *pp);
int BSEtype(int command);
int  grafedit(struct  tutorevent *evp);
char  FAR *GetPtr(unsigned int  mm);
int  ReleasePtr(unsigned int  mm);
extern int setbasesrc(void);
extern int  ParseCommandLine(char  *sep,long  *sPos,long  *sLen);
extern int  my_getcommand(unsigned int  mydoc,long  mypos);
extern int  WhichCoord(int  cmdtoken);
extern int  SetCoordString(char  *cstring,int  mx,int  my,long  *sPos,long  *sLen);
extern int  InsertHitCoord(char  *str,long  sPos,long  sLen);
int  AlteredSource(long  pos,long  len,long  newLen);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
long  TUTORget_len_doc(unsigned int  doc);
int  GetSelect(unsigned int  theV,long  *pos,long  *len);
int  TUTORset_view(struct  tutorview FAR *vp);
struct  tutorview FAR *TUTORinq_view(void);
double  lcfcoord(double  dv);
double  CoordToFloat(long  xx);
int  RelativeScale(long  fnx,long  fny,double  *cx,double  *cy);
int  GraphScale(long  fnx,long  fny,double  *cx,double  *cy);
long  DivCoord(long  xx,long  yy);
long  IntToCoord(int  xx);
int  getrealcommand(void);
int  TUTORdelete_doc(unsigned int  doc,long  pos,long  len,long  *extraPos);
int  TUTORsave_do_doc(unsigned int  doc,long  pos,long  len,int  op,long  newLen);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
extern int sprintf(char *ss, char *form, ...);
#endif

extern  struct tutorview FAR *TUTORinq_view();

static Memh sourceVH = HNULL; /* handle on source view */

/**************************************************/

grafedit(evp)
struct tutorevent *evp;
/* returns TRUE if should compile+execute unit */

	
{	struct tutorview FAR *cv;
	char cstring[30];
	long sPos, sLen;
	int ret;
	int wix; /* index of editor window */
	int sii; /* index in sourcetable */
    Memh editH; /* handle on editor */
    EditDat FAR *ep;
    TextVDat FAR *vp; /* pointer to text panel */

	if (CurEditWi < 0)
		return(0);
	wix = EditWn[CurEditWi];
	if (wix < 0)
		return(0);
	if (EditVp[CurEditWi] == FARNULL)
		return 0; /* no editor view */
	if (evp->type != EVENT_LEFTDOWN)
		return 0; /* we only handle leftdowns */
		
	/* look up editor in sourcetable */
	
	for(sii=0; sii<sourcemalloc; sii++)
		if (sourcetable[sii].editI == CurEditWi)
			break;
	if (sii >= sourcemalloc) 
		return(0);
	source = sourcetable[sii].doc; /* set source document */
	editH = windowsP[wix].wH; /* handle on editor */
    ep = (EditDat FAR *) GetPtr(editH);
    vp = (TextVDat FAR *) GetPtr(ep->textPanel);
    vp->alteredc++; /* make sure we track any changes */
    sourceVH = vp->textv; /* handle on text view */
    ReleasePtr(ep->textPanel);
    KillPtr(vp);
    ReleasePtr(editH);
    KillPtr(ep);
		
	if ((SetCoordString(cstring, evp->x, evp->y, &sPos, &sLen) == 0)) 
		return 0;

	cv = TUTORinq_view();
	TUTORset_view(EditVp[CurEditWi]);	/* set to editor view */
	ret = InsertHitCoord(cstring, sPos, sLen);
	setbasesrc(); /* restore source */
	TUTORset_view(cv);	/* restore to original view */
	return(ret); 
	
} /* grafedit */

/**************************************************/
static int ParseCommandLine(sep, sPos, sLen) 
char *sep; long *sPos, *sLen;
/* function return is type of command (absolute, graphing, relative) */
/* sep set to contain separator if any to precede the coordinate pair to be inserted */
/* before = TRUE if separator BEFORE selection region */
/* sPos and sLen returned marking adjusted selection region */
	{
	register char c; register long mypos;
	long pos, len, savepos, savelen;
	int WhichCoord(), ctype;
	int commas;

/* First task: back up to the newline or beginning of code document, and perform a switch 
on the command name string found. Is it a Graphing, Relative, or Absolute coordinate command? 
If not, return without any adjustment of selection box. If it is a coordinate command, adjust 
selection to prepare for coordinate string insertion. */

	GetSelect(sourceVH,&pos,&len);
	if ((pos <= 2) || (c = TUTORcharat_doc(source, pos-1)) == NEWLINE)
		{
		return(g_NoGood);
		}

	for(mypos = pos; ((mypos > 0) && (TUTORcharat_doc(source, mypos-1)) != NEWLINE); --mypos);

/* if the beginning of the command line is indented, skip over indents to the real command. An INDENT is a dot and a tab.*/
	while((command = my_getcommand(source, mypos)) == INDENT)
	{
	 mypos += (TUTORcharat_doc(source, mypos)=='.') ? 2L : 1L;
	}

	if ((ctype = WhichCoord(command)) == g_NoGood)
		{
		return(g_NoGood);
		}
	else if (ctype == g_Special)
		{
		return(g_Special);
		}

/* First adjust select position length so we're in a good spot to add coordinates to source code document. */

	savepos = pos;
	savelen = len;
 	*sep = (command==C_DO || command==C_SET) ? ',' : ';' ; 

	if ((command == C_SET) && (savelen == 0)) {
		commas = 0;
	} else {
/* move pos backward over numeric */
		while (pos > 1 &&
		    (CTisdigit(c=TUTORcharat_doc(source, pos-1)) || (c == ' ') ||
			   (c == '.') || (c == '+') || (c == '-') ||
			   (c==',' && *sep==';')))
			{
			pos--;
			}

		if (pos < 1 || (command == C_DO && TUTORcharat_doc(source, pos-1) != '(')) return(g_NoGood);

/* search forward from start of selection, bracketing one comma */
		len = 0;
		commas = 0;  /* count commas in the selection region */
		while ((CTisdigit(c=TUTORcharat_doc(source, pos+len)) || (c == ' ') ||
			c == '.' || c == '-' || c == '+' || c == ',') &&
			   (pos+len) < TUTORget_len_doc(source) )
			{
			if (c == ',') {
				if (commas) break;
				commas++;
				}
			len++;
			}
	} /* else */

	if (commas == 0) {
	/* if originally a non-zero selection, reject because no comma in it */
		if (savelen != 0) return(g_NoGood);
		len = 0;  /* no comma, make it a zero-length selection */
		}
	if (savelen == 0) {
		if (savepos > pos &&
		  ((savepos-pos) > (pos+len-savepos))) pos += len;
		len = 0;
		}
	savepos = pos;
	while ((c = TUTORcharat_doc(source, savepos-1)) == ' ') savepos--;
	if (c == NEWLINE) return(g_NoGood);
	if (len==0)
		{
		if (!(c=='\t' || c==';' || c==',' || c=='=' || c=='('))
			{ /* need separator BEFORE selection */
			InsertString(source, pos, (char FAR *) sep, 1L);
			AlteredSource(pos,0L,1L);
			pos++;
			*sep = '\0';
			
#ifdef NoSuCh
		} else if ((c == '\t') && BSEtype(command) && 
		     (TUTORcharat_doc(source,savepos) == NEWLINE)) {
			/* need semicolon before selection */
			InsertString(source, pos, (char FAR *)";", 1L);
			AlteredSource(pos,0L,1L);
			pos++;
#endif
		} else if (!CTisalnum(c = TUTORcharat_doc(source, pos))) { 
			/* don't need separator AFTER selection */
			*sep = '\0';
		} else if ((pos+len) >= TUTORget_len_doc(source)) {
			*sep = '\0';
		}
		}
	else *sep = '\0'; /* no separator needed */
	*sPos = pos;
	*sLen = len;
	return(ctype);
	}

/* ******************************************************************* */

/* Local getcommand routine, takes a struct document* and a position integer. */
/* It calls getcommand, which requires that source and srcPos be set */

static int my_getcommand(mydoc, mypos)
Memh mydoc;
long mypos;

{
	source = mydoc;
	srcPos = mypos;
	return(getrealcommand());

} /* my_getcommand */

/**************************************************/
static int WhichCoord(cmdtoken)
	int cmdtoken;
	{
	switch (cmdtoken)
		{
/* these commands are lifted from "commands.h".*/

/* Absolute coordinate commands: */
		case C_ARROW:
		case C_AT:
		case C_ATNM:
		case C_AXES:
		case C_BOUNDS:
		case C_BOX:
		case C_CLIP:
		case COMMENT:
		case C_DO:
		case C_DOT:
		case C_DRAW:
		case C_ERASE:
		case C_FILL:
		case C_FINE:
		case C_GORIGIN:
		case C_MOVE:
		case C_RORIGIN:
		case C_SET:
		case C_TEXT:
		case C_VECTOR:
		case C_EDIT:
        case C_BUTTON:
		case C_SLIDER:
		case C_TOUCH:
		case C_GET:
		case C_PUT:
		case C_VIDEO:
		case C_CIRCLE:
		case C_CIRCLEB:
		case C_DISK:
			return(g_Absolute);

/*relative commands */

		case C_RARROW:
		case C_RAT:
		case C_RATNM:
		case C_RBOX:
		case C_RCLIP:
		case C_RDOT:
		case C_RDRAW:
		case C_RERASE:
		case C_RFILL:
		case C_RMOVE:
		case C_RTEXT:
		case C_RVECTOR:
		case C_REDIT:
        case C_RBUTTON:
		case C_RSLIDER:
		case C_RTOUCH:
		case C_RGET:
		case C_RPUT:
		case C_RCIRCLE:
		case C_RCIRCLEB:
		case C_RDISK:
			return(g_Relative);

/* graphing commands */

		case C_GARROW:
		case C_GAT:
		case C_GATNM:
		case C_GBOX:
		case C_GCLIP:
		case C_GDOT:
		case C_GDRAW:
		case C_GERASE:
		case C_GFILL:
		case C_GMOVE:
		case C_GTEXT:
		case C_GVECTOR:
		case C_HBAR:
		case C_VBAR:
		case C_GEDIT:
        case C_GBUTTON:
		case C_GSLIDER:
		case C_GTOUCH:
		case C_GPUT:
		case C_GGET:
		case C_GCIRCLE:
		case C_GCIRCLEB:
		case C_GDISK:
			return(g_Graphing);

/* Special commands - no coordinates, but affected by scaling. */

#ifdef NOSUCH /* nothing left in this category at present */		
		case C_
			return(g_Special);
#endif
/* NoGood commands (coordinates make no sense for them):*/
		default:	
			return(g_NoGood);
		} /* end switch statement */

	} /* end function Which_Coord */
/**************************************************/
/* SetCoordString returns a 1 if it successfully set the passed mouse X,Y coordinates into the string argument, and returns 0 if it didn't. If the current line starts with a command for which X,Y coordinates make no sense, SetCoordString will also return a 0. */
static int SetCoordString(cstring, mx, my, sPos, sLen)
	int mx, my;
	char *cstring;
	long *sPos, *sLen;
	{
	Coord fmx, fmy;
	double fmxout, fmyout;
	char sep;

	fmx = DivCoord(IntToCoord(mx-exS.OffsetX),exS.ScaleX)+exS.RegionXmin;
	fmy = DivCoord(IntToCoord(my-exS.OffsetY),exS.ScaleY)+exS.RegionYmin;

	switch (ParseCommandLine(&sep, sPos, sLen))
		{

/**************************************************/
		case g_Graphing:	GraphScale(fmx,fmy,&fmxout,&fmyout);
				fmxout =  0.1*lcfcoord(10.0*fmxout);
				fmyout =  0.1*lcfcoord(10.0*fmyout);
				break;

/**************************************************/
		case g_Relative:	RelativeScale(fmx,fmy,&fmxout,&fmyout);
				fmxout =  0.1*lcfcoord(10.0*fmxout);
				fmyout =  0.1*lcfcoord(10.0*fmyout);
				break;

/**************************************************/
		case g_Absolute:	
			if (command == C_AXES || command == C_BOUNDS)
				{
				fmx = fmx - exS.GXorigin;
				fmy = exS.GYorigin - fmy;
				}
				fmxout = lcfcoord(CoordToFloat(fmx));
				fmyout = lcfcoord(CoordToFloat(fmy));
				break;

/**************************************************/
		case g_Special:
		case g_NoGood:
		default:
				return(0);
		} /* end of switch */

 /* insert the scaled X and Y coordinates into string which will be eventually inserted into source code document. */

	if (sep == '\0') sprintf(cstring, "%G,%G", fmxout, fmyout);
	else sprintf(cstring, "%G,%G%c", fmxout, fmyout, sep);
	return (1);

	}

/* ******************************************************************* */

static int InsertHitCoord(str, sPos, sLen)
/* returns TRUE if should compile+execute unit */
char *str;
long sPos, sLen;
	
{	long length;
	register char prevc;

	prevc = TUTORcharat_doc(source,sPos-1);
	length = (long)strlen(str);

	/* save this action for undo-ing (0 is key) */
	TUTORsave_do_doc(source,sPos,sLen,0,length);

	TUTORdelete_doc(source, sPos, sLen,NEARNULL);
	InsertString(source, sPos, (char FAR *) str, length);
	AlteredSource(sPos,sLen,length);

	if (sLen != 0) {
		if (command != COMMENT) return(TRUE);
	} else {
		if ((command == C_EDIT) || (command == C_REDIT) || (command == C_GEDIT) ||
			(command == C_BUTTON) || (command == C_RBUTTON) || (command == C_GBUTTON) ||
			(command == C_SLIDER) || (command == C_RSLIDER) || (command == C_GSLIDER) ||
			(command == C_TOUCH) || (command == C_RTOUCH) || (command == C_GTOUCH) ||
			(command == C_GET) || (command == C_RGET) || (command == C_GGET) ||
			(command == C_PUT) || (command == C_RPUT) || (command == C_GPUT) ||
			(command == C_VIDEO))
				return(FALSE);
		if (command != COMMENT && (prevc !='\t' ||
			command == C_AXES ||
			command == C_BOUNDS ||
			command == C_GORIGIN ||
			command == C_RORIGIN ||
			command == C_DOT ||
			command == C_RDOT ||
			command == C_GDOT ||
			command == C_HBAR ||
			command == C_VBAR)) return(TRUE);
	} /* sLen else */
	return(FALSE);
	
} /* InsertHitCoord */

/* ******************************************************************* */

static int  BSEtype(command) /* check if button/slider/edit command */
int command;

{
	if ((command == C_EDIT) || (command == C_REDIT) || (command == C_GEDIT) ||
	   (command == C_BUTTON) || (command == C_RBUTTON) || (command == C_GBUTTON) ||
	   (command == C_SLIDER) || (command == C_RSLIDER) || (command == C_GSLIDER))
	   	return(TRUE);
	return(FALSE);
	
} /* BSEtype */

/* ******************************************************************* */

#endif

