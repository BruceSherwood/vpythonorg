
/* experimental stuff */

#include <windows.h>
#include <mmsystem.h>
#include <digitalv.h>

#include "execdefs.h"
#include "eglobals.h"
#include "tglobals.h"
#include "tfiledef.h"
#include "exprdefs.h"
#include "kglobals.h"

extern int  marker_file_name(struct  markvar FAR *mx,struct  _fref FAR *fullRef,int  symbolic);
extern int  ReleasePtr(unsigned int  mm);
extern char  FAR *GetPtr(unsigned int  mm);
extern int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
extern int  TUTORfile_exists(struct  _fref FAR *fRef);
extern char *CtoPstr(char *ss);
extern char *PtoCstr(char *ss);
extern int TUTORclose(int findx);
extern int  lclocy(long  q);
extern int  lclocx(long  q);

int cmd_dma(void);
/* function declarations */

void fileCloseMovie(HWND hWnd);
void fileOpenMovie(HWND hWnd,char *filestr,int x1,int y1,
int x2,int y2);
void positionMovie(HWND hWnd,int left,int top,int right,int bottom);
void playMovie(HWND hWnd, WORD wDirection);
void seekMovie(HWND hWnd, WORD wAction);
void stepMovie(HWND hWnd, WORD wDirection);

/* ------------------------------------------------------------------- */

int cmd_dma() /* -dma- command execution */

{   Coord x1,y1,x2,y2; /* movie region */
    int fileid; /* cT index of file */
    FileRef fRef; /* cT file reference */
    struct tutorfile FAR *fP; /* pointer to cT file table entry */
    char namestr[FILEL];
    long tmpl;
    HWND hWnd;

    iresP = istack; /* void stacks */
    markP = markstack;
    exS.zreturn = -1; /* pre-set worked */
    
    /* evaluate file name expression */

    marker_file_name(markP,(FileRef FAR *) &fRef,TRUE); 
    
    /* get movie display rectangle */
    
    x1 = istack[0];
    y1 = istack[1];
    x2 = istack[2];
    y2 = istack[3];
    x1 = exS.OffsetX + lclocx(x1);
    y1 = exS.OffsetY + lclocy(y1);
    x2 = exS.OffsetX + lclocx(x2);
    y2 = exS.OffsetY + lclocy(y2);

    /* normalize rectangle */

    if (x1 > x2) { /* normalize x */
        tmpl = x1;
        x1 = x2;
        x2 = tmpl;
    }
    if (y1 > y2) { /* normalize y */
        tmpl = y1;
        y1 = y2;
        y2 = tmpl;
    }
        
    /* open movie file */

    fileid = TUTORopen((FileRef FAR *)&fRef,TRUE,FALSE,FALSE);
    if (fileid <= 0) {
        exS.zreturn = FILEMISSING;
        return(0);
    } /* fileid if */

    fP = fileid+(struct tutorfile FAR *)GetPtr(filesopen);
    strcpyf((char FAR *)&namestr[0],fP->fRef.path);
    ReleasePtr(filesopen);
    TUTORclose(fileid);
    
    InitAVI();
    hWnd = windowsP[ExecWn].wp;
    fileOpenMovie(hWnd,namestr,x1,y1,x2,y2);
    playMovie(hWnd,1);
    return(0);
    
} /* cmd_dma */

/* ------------------------------------------------------------------- */

gork_vid(vidpath,x1,y1,x2,y2)
char FAR *vidpath;
int x1,y1,x2,y2;

{	char namestr[1000];
	HWND hWnd;

	strcpyf((char FAR *)&namestr[0],vidpath);
 	InitAVI();
    hWnd = windowsP[ExecWn].wp;
    fileOpenMovie(hWnd,namestr,x1,y1,x2,y2);
    playMovie(hWnd,1);

} /* gork_vid */

/* ------------------------------------------------------------------- */

static WORD wMCIDeviceID = 0; /* MCI Device ID for the AVI file */
static HWND hwndMovie; /* window handle of the movie */
static RECT rcMovie; /* the rect where the movie is positioned */
static BOOL fDriver = FALSE; /* AVI driver flag: TRUE = driver opened */
static BOOL fPlaying = FALSE;	/* Play flag: TRUE == playing, FALSE == paused */
static BOOL fMovieOpen = FALSE;/* Open flag: TRUE == movie open, FALSE = none */
static HANDLE hAccel = NULL;	/* accelerator table */
static HMENU hMenuBar = NULL;	/* menu bar handle */
static char szAppName [] = "MovPlay";
static long lastFrame; /* last frame played */

/* ------------------------------------------------------------------- */

int MovieOpen(fRef) /* open movie file for play */
FileRef *fRef; /* movie file */

{   int fileid; /* cT index of movie file */
    struct tutorfile FAR *fP; /* pointer to file table entry */
    char namestr[CTPATHLEN]; /* full path to file */
    HWND hWnd; /* handle on executor window */

    if (fPlaying) 
        MovieHalt(); /* halt current movie */
    if (fMovieOpen)
        MovieClose(); /* close current movie */

    /* open movie file */

    fileid = TUTORopen((FileRef FAR *)fRef,TRUE,FALSE,FALSE);
    if (fileid <= 0) 
        return(FILEMISSING);
    fP = fileid+(struct tutorfile FAR *)GetPtr(filesopen);
    strcpyf((char FAR *)&namestr[0],fP->fRef.path);
    ReleasePtr(filesopen);
    TUTORclose(fileid);
    
    InitAVI();
    hWnd = windowsP[ExecWn].wp;
/*  fileOpenMovie(hWnd,namestr,x1,y1,x2,y2);	  */
    playMovie(hWnd,1);

} /* MovieOpen */

/* ------------------------------------------------------------------- */

int MovieClose(type) /* close current movie */
int type; /* 0 = close driver */ 
          /* 1 = close movie file */

{   MCI_GENERIC_PARMS  mciGeneric;
    
    if (!fMovieOpen)
        return(FILENOTOPEN);
    MovieHalt(); /* halt movie if playing */
    mciSendCommand(wMCIDeviceID, MCI_CLOSE, 0L, 
                 (DWORD)(LPMCI_GENERIC_PARMS)&mciGeneric);
    fMovieOpen = FALSE;	/* movie closed */
    if (type == 0)
        termAVI(); /* close device driver */
    return(-1);

} /* MovieClose */

/* ------------------------------------------------------------------- */

int MovieHalt() /* halt currently playing movie */

{   MCI_DGV_PAUSE_PARMS mciPause;

    if (!fPlaying)
        return(-1);
    mciSendCommand(wMCIDeviceID,MCI_PAUSE,0L,
                   (DWORD)(LPMCI_DGV_PAUSE_PARMS)&mciPause);
    fPlaying = FALSE;
    return(-1);

} /* MovieHalt */

/* ------------------------------------------------------------------- */

int MovieRectangle(mode,x1,y1,x2,y2) /* set up rectangle for movie play */
int mode; /* 0 = clip, 1 = scale, 2 = center */
int x1,y1; /* upper left of rectangle */
int x2,y2; /* lower right of rectangle */

{   RECT rcClient, rcMovieBounds;
    MCI_DGV_RECT_PARMS mciRect;
    HWND hWnd; /* handle on executor window */
   
   if (!fMovieOpen)
	   return;
   
    hWnd = windowsP[ExecWn].wp; /* get executor window */
    GetClientRect(hWnd, &rcClient);	/* get the parent windows rect */
	   
    /* get the original size of the movie */
    mciSendCommand(wMCIDeviceID, MCI_WHERE, 
                  (DWORD)(MCI_DGV_WHERE_SOURCE), 
                  (DWORD)(LPMCI_DGV_RECT_PARMS)&mciRect);
    rcMovieBounds = mciRect.rc;	/* get it in the movie bounds rect */
   
    rcMovie.left = x1;
    rcMovie.top = y1;
    rcMovie.right = x2;
    rcMovie.bottom = y2;
   
    /* reposition the playback (child) window */
    MoveWindow(hwndMovie, rcMovie.left, rcMovie.top,
               rcMovieBounds.right, rcMovieBounds.bottom, TRUE);
    return(0);

} /* MovieRectangle */

/* ------------------------------------------------------------------- */

int MoviePlay(from,to) /* play specified section of movie */
long from; /* starting position */
long to; /* ending position */

{   DWORD dwFlags;
    MCI_DGV_PLAY_PARMS mciPlay;
    HWND hWnd; /* handle on executor window */

    hWnd = (HWND)windowsP[ExecWn].wp;
    mciPlay.dwCallback = MAKELONG(hWnd,0);
    mciPlay.dwFrom = mciPlay.dwTo = 0;
    dwFlags = MCI_NOTIFY;   
    mciSendCommand(wMCIDeviceID, MCI_PLAY, dwFlags,
              (DWORD)(LPMCI_DGV_PLAY_PARMS)&mciPlay);
    return(0);

} /* MoviePlay */

/* ------------------------------------------------------------------- */

long MovieGetFrame(void) /* return current position of movie */

{
    return(0);

} /* MovieGetFrame */

/* ------------------------------------------------------------------- */

int MovieSupport(void) /* Mac service routine - not needed on PC */

{
    return(0);

} /* MovieSupport */

/* ------------------------------------------------------------------- */

BOOL initAVI(void) /* initialize AVI driver */

{   MCI_DGV_OPEN_PARMS	mciOpen;
    BOOL openF;
		 
    /* set up the open parameters */
    mciOpen.dwCallback = NULL;
    mciOpen.wDeviceID = mciOpen.wReserved0 = mciOpen.wReserved1 = 0;
    mciOpen.lpstrDeviceType = "avivideo";
    mciOpen.lpstrElementName = NULL;
    mciOpen.lpstrAlias = NULL;
    mciOpen.dwStyle = 0;
    mciOpen.hWndParent = NULL;
		 
    /* try to open the driver */
    openF = mciSendCommand(0, MCI_OPEN, (DWORD)(MCI_OPEN_TYPE), 
                          (DWORD)(LPMCI_DGV_OPEN_PARMS)&mciOpen);


} /* initAVI */

/* ------------------------------------------------------------------- */

int termAVI(void) /* close AVI driver */

{   WORD wID;
    MCI_GENERIC_PARMS mciClose;

    wID = mciGetDeviceID("avivideo");
    mciSendCommand(wID,MCI_CLOSE,0L,
		   (DWORD)(LPMCI_GENERIC_PARMS)&mciClose);
    return(0);

} /* termAVI */

/* ------------------------------------------------------------------- */

/*--------------------------------------------------------------+ 
| positionMovie - sets the movie rectange <rcMovie> 	|
|								|
+--------------------------------------------------------------*/
VOID positionMovie(HWND hWnd,int x1,int y1,int x2,int y2)
{
   RECT	rcClient, rcMovieBounds;
   MCI_DGV_RECT_PARMS	mciRect;
   
   /* if there is no movie yet then just get out of here */
   if (!fMovieOpen)
	   return;
   
   GetClientRect(hWnd, &rcClient);	/* get the parent windows rect */
	   
   /* get the original size of the movie */
   mciSendCommand(wMCIDeviceID, MCI_WHERE, 
                  (DWORD)(MCI_DGV_WHERE_SOURCE), 
                  (DWORD)(LPMCI_DGV_RECT_PARMS)&mciRect);
   rcMovieBounds = mciRect.rc;	/* get it in the movie bounds rect */
   
   rcMovie.left = x1;
   rcMovie.top = y1;
   rcMovie.right = x2;
   rcMovie.bottom = y2;
   
   /* reposition the playback (child) window */
   MoveWindow(hwndMovie, rcMovie.left, rcMovie.top,
	   rcMovieBounds.right, rcMovieBounds.bottom, TRUE);
}

/*--------------------------------------------------------------+ 
| fileCloseMovie - close the movie and anything associated	|
|		   with it.					|
|								|
| This function clears the <fPlaying> and <fMovieOpen> flags	|
|								|
+--------------------------------------------------------------*/
void fileCloseMovie(HWND hWnd)
{
  MCI_GENERIC_PARMS  mciGeneric;
    
  mciSendCommand(wMCIDeviceID, MCI_CLOSE, 0L, 
                 (DWORD)(LPMCI_GENERIC_PARMS)&mciGeneric);

  fPlaying = FALSE;	// can't be playing any longer
  fMovieOpen = FALSE;	// no more movies open
  
  /* cause a total repaint to occur */
  InvalidateRect(hWnd, NULL, TRUE);
  UpdateWindow(hWnd);
}


/*--------------------------------------------------------------+ 
| fileOpenMovie - open an AVI movie. 	|
|	         handle the initialization to	|
|		show the movie and position it properly.  Keep	|
|		the movie paused when opened.			|
|								|
|		Sets <fMovieOpened> on success.			|
+--------------------------------------------------------------*/
void fileOpenMovie(HWND hWnd,char *filestr,int x1,int y1,
int x2,int y2)
{
   
   /* use CommDlg to get our filename */
   if (TRUE){
	 MCI_DGV_OPEN_PARMS	mciOpen;
	 MCI_DGV_WINDOW_PARMS	mciWindow;
	 MCI_DGV_STATUS_PARMS	mciStatus;

	 /* we got a filename, now close any old movie and open */
	 /* the new one.					*/
	 if (fMovieOpen)
		 fileCloseMovie(hWnd);	
	 
	 /* we have a .AVI movie to open, use MCI */
	 /* set up the open parameters */
	 mciOpen.dwCallback = NULL;
	 mciOpen.wDeviceID = mciOpen.wReserved0 =
		 mciOpen.wReserved1 = 0;
	 mciOpen.lpstrDeviceType = NULL;
	 mciOpen.lpstrElementName = filestr;
	 mciOpen.lpstrAlias = NULL;
	 mciOpen.dwStyle = WS_CHILD;
	 mciOpen.hWndParent = hWnd;

	 /* try to open the file */
	 if (mciSendCommand(0, MCI_OPEN, 
		 (DWORD)(MCI_OPEN_ELEMENT|MCI_DGV_OPEN_PARENT|MCI_DGV_OPEN_WS), 
       (DWORD)(LPMCI_DGV_OPEN_PARMS)&mciOpen) == 0){

		 /* we opened the file o.k., now set up to */
		 /* play it.				   */
		 wMCIDeviceID = mciOpen.wDeviceID;	/* save ID */
		 fMovieOpen = TRUE;	/* a movie was opened */

		 /* show the playback window */
        
		 mciWindow.dwCallback = NULL;
		 mciWindow.hWnd = NULL;
		 mciWindow.wReserved1 = mciWindow.wReserved2 = 0;
		 mciWindow.nCmdShow = SW_SHOW;
		 mciWindow.lpstrText = (LPSTR)NULL;
		 mciSendCommand(wMCIDeviceID, MCI_WINDOW, 
			 MCI_DGV_WINDOW_STATE, 
			 (DWORD)(LPMCI_DGV_WINDOW_PARMS)&mciWindow);

		 /* get the window handle */
		 mciStatus.dwItem = MCI_DGV_STATUS_HWND;
		 mciSendCommand(wMCIDeviceID, 
			 MCI_STATUS, MCI_STATUS_ITEM,
			 (DWORD)(LPMCI_STATUS_PARMS)&mciStatus);
		 hwndMovie = (HWND)mciStatus.dwReturn;

		 /* now get the movie centered */
		 positionMovie(hWnd,x1,y1,x2,y2);
	 } else {
		/* generic error for open */
		MessageBox(hWnd, "Unable to open Movie", NULL, 
			      MB_ICONEXCLAMATION|MB_OK);
		fMovieOpen = FALSE;
	 }
   }
   
}

/*--------------------------------------------------------------+
| playMovie - play/pause the movie depending on the state	|
|		of the <fPlaying> flag.				|
|								|
| This function sets the <fPlaying> flag appropriately when done|
|								|
+--------------------------------------------------------------*/
void playMovie(HWND hWnd, WORD wDirection)
{
   fPlaying = !fPlaying;	/* swap the play flag */
   if (wDirection == NULL)
	   fPlaying = FALSE;	/* wDirection == NULL means PAUSE */

   /* play/pause the AVI movie */
   if (fPlaying){
	   DWORD		            dwFlags;
	   MCI_DGV_PLAY_PARMS	mciPlay;
		   
	   /* init to play all */
 	   mciPlay.dwCallback = MAKELONG(hWnd,0);
	   mciPlay.dwFrom = mciPlay.dwTo = 0;
	   dwFlags = MCI_NOTIFY;
	   
		   
	   mciSendCommand(wMCIDeviceID, MCI_PLAY, dwFlags,
		               (DWORD)(LPMCI_DGV_PLAY_PARMS)&mciPlay);
   } else {
	   MCI_DGV_PAUSE_PARMS	mciPause;
	   
	   /* tell it to pause */
	   mciSendCommand(wMCIDeviceID,MCI_PAUSE,0L,
                     (DWORD)(LPMCI_DGV_PAUSE_PARMS)&mciPause);
   }
}

/*--------------------------------------------------------------+
| seekMovie - seek in the movie depending on the wAction.	|
|	      Possible actions are IDM_HOME (start of movie) or	|
|	      IDM_END (end of movie)				|
|								|
|	      Always stop the play before seeking.		|
|								|
+--------------------------------------------------------------*/
void seekMovie(HWND hWnd, WORD wAction)
{
   /* first stop the movie from playing if it is playing */
   if (fPlaying){
	   playMovie(hWnd, NULL);	
   }
   if (wAction == 0){
	   /* home the movie */
	   mciSendCommand(wMCIDeviceID, MCI_SEEK, MCI_SEEK_TO_START, 
			(DWORD)(LPVOID)NULL);
			
   } else if (wAction == 1){
	   /* go to the end of the movie */
	   mciSendCommand(wMCIDeviceID, MCI_SEEK, MCI_SEEK_TO_END, 
			(DWORD)(LPVOID)NULL);
   } 
}

/*--------------------------------------------------------------+
| stepMovie - step forward or reverse in the movie.  wDirection	|
|		can be IDM_STEP (forward) or IDM_RSTEP (reverse)|
|								|
|		Again, stop the play if one is in progress.	|
|								|
+--------------------------------------------------------------*/
void stepMovie(HWND hWnd, WORD wDirection)
{
   MCI_DGV_STEP_PARMS	mciStep;
   
   if (fPlaying)
	   playMovie(hWnd, NULL);  /* turn off the movie */
   
	   
   mciStep.dwFrames = 1L;
   if (wDirection == 0)
	   mciSendCommand(wMCIDeviceID, MCI_STEP, MCI_DGV_STEP_FRAMES,
		   (DWORD)(LPMCI_DGV_STEP_PARMS)&mciStep);
   else
	   mciSendCommand(wMCIDeviceID, MCI_STEP, 
		   MCI_DGV_STEP_FRAMES|MCI_DGV_STEP_REVERSE,
		   (DWORD)(LPMCI_DGV_STEP_PARMS)&mciStep);
}

/* ------------------------------------------------------------------- */
