
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Declarations for cT execution, referenced by compiler.
*/

#include "compute.h"
#include "ecglobal.h"


#ifdef ctproto
#endif /* ctproto */

int new_defs; /* testing new -define- machinery */

Memh ed1H;  /* editor text view */
long lvaraddr; /* local define address -- no. of stack vars used */
Memh source;  /* source read from disk */
int sourcemalloc;           /* number of table entries */
int csourcen;   /* index of current source in sourcetable */
int twf;    /* trace window debugging (PC) */
int spyf;   /* profiling on/off flag */
int lforkf; /* layout fork flag (-d) option on command */
int DictWn; /* dictionary window number */
struct tutorview FAR *DictVp;   /* dictionary main view number */
int HelpWn; /* help window number */
struct tutorview FAR *HelpVp;  /* help main view number */
int DebugWn;  /* debugger window number */
struct tutorview FAR *DebugVp;  /* debugger main view number */
int MsgWn; /* message window number */
struct tutorview FAR *MsgVp; /* message main view number */
Memh MsgDocH; /* handle on message document */
Memh MsgPanelH; /* handle on message text panel */
int AboutWn; /* about box window number */
struct tutorview FAR *AboutVp; /* about box view */
int TraceWn;    /* trace window number */
int SelectWn; /* select program window */
struct tutorview FAR *SelectVp; /* select program view */
FileRef binaryFile; /* file where current binary is stored */
int fileSpecified; /* 0 = no file name specified */
                   /* 1 = file name from command line */
                   /* 2 = file name from AppleEvent */
                   /* 3 = file name from executor dialog box */
                   /* 4 = file name from -jumpout- command */
                   /* 5 = file name from Switch File dialog */
                   /* 6 = file name from Save As dialog */
                   /* 7 = untitled file from New menu or startup */
int newsrfile;  /* TRUE if newly-created source file */
int codegen;    /* TRUE if can generate compiled code */
int ExecWinX; /* initial executor window X size */
int ExecWinY; /* initial executor window Y size */
int usesColor; /* least sig bit set if program has -color- commands */    
               /* next      bit set if program has -palette- commands */
char exechalt;
Memh unitNames;
unsigned unitmalloc; /* number of unit slots malloc-ed */
int labelID; /* label id for next internal branch */
jmp_buf errjmpbuff; /* general compile/execution error longjmp */

short mkall;    /* marks entire document */
