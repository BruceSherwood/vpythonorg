
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
part of the command compiler
*/

#include "ctutor.h"
#include "tutor.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "txt.h"
#include "exprdefs.h"
#include "yacc.h"
#include "ct_ctype.h"

#ifdef ctproto
extern int TUTORmem_alert(void);
unsigned int  TUTORcopy_handle(unsigned int  mm);
extern int cmdlookp(char *s);
int  strlenf(char  FAR *aa);
extern Memh LoadTable(char *tableFile,int *tableSize);
extern int pRelevant(char *msgstr);
extern int TUTORalert(int wn, char *msg);
int  initsourcet(int  i);
int CheckEditOnFile(FileRef FAR *fRef,Memh *docHP,int Exclude);
int  EditorDefaultStyles(unsigned int  doc);
extern int TUTORdump(char *str);
int  AllowHandlePurge(unsigned int  mm);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
int  ictcomp(void);
int  FindUnits(void);
int  SetupUnits(void);
extern int  SetupFile(int  si);
extern int  SetupUse(void);
extern int  readuse(struct  _fref *fn);
int  useerr(char  *errstr);
extern int  ReadUnitName(char  *str);
int  Seek(char  *ss,unsigned int  dd,long  start,long  *found);
int  RefillBuffer(void);
int  getdefines(long  currentkind);
int  cerror(int  errnumber,char  *execstr);
int  terror(char  *errstr);
int  eError(char  *errstr,int sourceI,long pos,long len,int type);
int  StopCompile(void);
extern int  skipblanklines(void);
char  *parse_env(void);
int  cmpbuf_flt(double  d);
int  cmpbuf_word(int  n);
int  cmpbuf_plant_word(unsigned int  addr,int  n);
int  cmpbuf_long(long  nn);
int  cmpbuf_xref(int  kind,int  label);
int  add_xref(int  kind,int  label,unsigned int  aref,unsigned int  adest);
int  plant_xref(int  iref,unsigned int  adest);
int  satisfy_xref(int  index,int  kind,int  label,unsigned int  adest);
int  add_dest(int  type,int  label,unsigned int  pos);
int  compile_ubranch(int  kind,int  label);
int  compile_cbranch(int  logic,int  kind,int  label);
int  xref_open(int  unitn);
unsigned int  xref_copy(int unitn);
int  xref_close(void);
int  _TUTORset_state_internal_marker(int  ind,long  pos,long  len,int  altered);
int  TUTORdealloc(char  FAR *ptr);
int  TUTORcmp_fileref(struct  _fref FAR *f1,struct  _fref FAR *f2);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  _TUTORinq_state_internal_marker(int  ind,long  *pos,long  *len,int  *altered);
int  TUTORstat(struct  _fref FAR *fRef,struct  stat *buff);
int  setbasesrc(void);
int  StopProgram(char  *s);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORfree_handle(unsigned int  mm);
int  Seekunit(unsigned int  sdoc,long  *loc);
int  AllocUnits(int  unl);
int  AddUnitName(unsigned char  *name,int  unitNum);
int  Halt(void);
int  SkipLine(void);
int  MatchUnitName(unsigned char  *name);
int  getcommand(void);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
int  TUTORcvt_path(char  *ssx,struct  _fref FAR *fRef,struct  _fref FAR *baseRef,int fileF);
int  _TUTORinternal_marker(struct  markvar FAR *mp,unsigned int  stackH,long  rloc);
int  _TUTORclose_internal_marker(int  ind);
char  FAR *GetPtr(unsigned int  mm);
int  CTisascii(int  cc);
int TMessage(char FAR *s);
int  readdoc(unsigned int  doc,struct  _fref FAR *fRef,int  *iswrite);
int  TUTORclear_doc(unsigned int  doc);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
char  FAR *TUTORrealloc(char  FAR *ptr,long  oldsize,long  newsize,int  abort);
int  GetUnitName(int  unitn,unsigned char  *name);
int  TUTORget_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  skip_white_cB(void);
int  FillBuffer(unsigned int  readDoc,long  readPos,long  maxRead);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
long  TUTORsearch_string_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sLen,long  pos,long  posEnd);
int  strncmpf(char  FAR *aa,char  FAR *bb,int  nn);
int  StripLineStart(unsigned char  * *cpp,int  oldCmd,int  *nIndent);
int  EndCompileMsg(int  wn);
int  TUTORpost_event(struct  tutorevent *event);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
extern void longjmp(jmp_buf env, int value);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
int  TUTORtrace(char  *s);
long  lcftoi(double  dv);
int  getnum(char  *s,int  *floatf,long  *i,double  *d,char  * *errm,int  *errn);
long  TUTORget_hsize(unsigned int  mm);
int  compile_simple_numeric(int  nmask,int  fmask,int  stopl);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
extern char *strcat(char *aa, char *bb);
extern char *strcpy(char *aa, char *bb);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
#ifdef THINKC5
#include <stdio.h>
#else
extern int sprintf(char *,char *,...);
#endif
#endif

extern long TUTORsearch_string_doc();
extern long TUTORget_len_doc();
char *parse_env();

extern Memh TUTORnew_doc();
extern long lcftoi();   /* round double to integer conversion */
extern char *kUnrecStr; /* unrecognized variable message */

/* ******************************************************************* */

ictcomp() /* initializations for compiler */

{   int ii;
    struct caseopt *casep; /* -case- optimization table */
    char *errp; /* pointer to parse_env error message */

    /* set up default expression analyzer params */

    defexp.teol = TRUE;      /* eol is legal terminator */
    defexp.tcomma = TRUE;    /* comma is legal terminator */
    defexp.tsemic = FALSE;
    defexp.tassign = FALSE;
    defexp.tcolon = FALSE;
    defexp.tparen = FALSE;
    defexp.tembed = FALSE;
    defexp.tcond = FALSE;
    defexp.tpercent = FALSE;
    defexp.userc = FALSE;     /* not -compute- */
    defexp.userd = FALSE;     /* not debug */
    defexp.reqstore = FALSE;  /* storability info not required */
    defexp.arrayok = FALSE;   /* whole array not allowed */
    defexp.allowsk = FALSE;   /* SKIP not allowed */
    defexp.allowf = FALSE;    /* file variable not allowed */
    defexp.allowm = FALSE;    /* marker result not allowed */
    defexp.allowscrn = FALSE; /* pixmap variable not allowed */
    defexp.allowbutn = FALSE; /* button variable not allowed */
    defexp.allowslid = FALSE; /* slider variable not allowed */
    defexp.allowedit = FALSE; /* edit variable not allowed */
    defexp.mfunctst = TRUE;   /* marker functions are store-able */
    defexp.nogen = FALSE;     /* do generate p-code */
    defexp.calc = FALSE;      /* not -calc- command */
    defexp.rtype = 0;         /* numeric (int or float) result required */
    defexp.text = textpool;   /* styled string literals in textpool doc */
    defexp.srcH = source;     /* default source input document */
    defexp.srcbase = &startofline; /* base of cB, cI */
    defexp.src = &cB[0];      /* source input from cB, cI */
    defexp.srcpos = &cI;
    defexp.pcode = cmpbuf;    /* pcode output to cmpbuf, cmpl */
    defexp.pcodepos = &cmpl;

    /* initialize conditional command table */

    condTh = 0; /* no table yet */
    condTalloc = 0;

    /* initialize tables used in -case- optimization */

    for(ii=0; ii<MAXINDENTS; ii++) {
        casep = &caseod[ii];
        casep->nitems = casep->nalloc = 0;
        casep->cv = NULL;
    } /* for */

    /* initialize table used in unit argument processing */
    
    uargH = TUTORhandle("uargs   ",
        (long)((MAXPASSVAL+MAXPASSADDR+1)*sizeof(struct argdef)),TRUE);
    TUTORpurge_info(uargH,M_WMRM,FARNULL,0);
    AllowHandlePurge(uargH);
    uargP = FARNULL;
    
    errp = parse_env(); /* interpret $keyword statements */
    sourcetable[0].ctutv = ctutv; /* set version */
    if (errp) eError(errp,0,0L,0L,0);
    cmpH = TUTORhandle("cmpbuf  ",(long)(CMPBUFL*sizeof(unsigned char)),TRUE /* FALSE */);
    if (!cmpH)
        StopProgram(NEARNULL);
    TUTORpurge_info(cmpH,M_WORM,0L,0);
    AllowHandlePurge(cmpH); /* compile buff is purgeable (when not locked) */
    xrefH = 0; /* no relocation table yet */
    srbimapH = 0; /* no source/binary map table yet */
    if (nunits <= 0)
        FindUnits();
    allowcoarse = FALSE; /* don't allow coarse grid */

} /* ictcomp */

/* ******************************************************************* */

FindUnits() /* check that units are correctly located */

{   int units,legalname, found;
    long unitloc;
    char unitname[NAMEL+1];
    int slastunit;  /* last unit in base source file */
    int i;
    struct stat fst; /* file status block */
    struct sourcefile FAR *osrctable; /* saved table of source file names/pointers */
    struct sourcefile FAR *srcP; /* pointer in source table */
    int osrcmalloc; /* saved length of table */
    long docLen;    /* length of source document */
    int ieuChanged,unitChanged;
    long tempL;

    /* insure newline at end of file, remove extra newline codes */
    setbasesrc();

    /* check if use file altered */
    /* if any -use- file altered, ieu may have altered, changing define locations
       therefore we have to recompile the whole program */

	srcP = sourcetable;
    for(i=1; i<sourcemalloc; i++) { /* for every -use- file */
    	srcP++;
    	/* check files that are vaild, part of program, and not being edited */
        if (srcP->valid && srcP->programpart && (srcP->editI == -1)) {
            TUTORstat(&srcP->fRef,&fst);
            if (fst.st_mtime != sourcetable[i].mtime) {
                /* file has changed */
                nunits = -1; /* force new setup */
                srcP->valid = FALSE;
            } /* time if */
        } /* valid if */
    } /* for */

    /* check if IEU altered - may have new -use- commands */

    if (unittab[0].marki >= 0)
        _TUTORinq_state_internal_marker(unittab[0].marki,NEARNULL,NEARNULL,&ieuChanged);
    else
        ieuChanged = FALSE;

    if ((nunits > 0) && ieuChanged) {

        /* check if any -use- command altered */

        osrcmalloc = sourcemalloc;
        osrctable = (struct sourcefile FAR *) 
                  TUTORalloc((long)(osrcmalloc*sizeof(struct sourcefile)),TRUE,"osrctable");
        if (!osrctable)
            nunits = -1; /* force full setup */
        else {

            /* save source table, re-evaluate -use- commands */
            /* and check if anything changed */
            /* note that a re-ordering is considered a change */

            for (i=0; i<sourcemalloc; i++)
                osrctable[i] = sourcetable[i];
            if (!SetupUse())
                nunits = -1;
            if (osrcmalloc != sourcemalloc)
                nunits = -1; /* change in # of -use- files */
            else for (i=0; i<osrcmalloc; i++) {
                if (osrctable[i].valid != sourcetable[i].valid)
                    nunits = -1;
                if (osrctable[i].programpart != sourcetable[i].programpart)
                    nunits = -1;
                if (TUTORcmp_fileref(&osrctable[i].fRef,&sourcetable[i].fRef))
                    nunits = -1; /* different file */
            } /* for */
            TUTORdealloc((char FAR *) osrctable);
        } /* else */
    } else if (ieuChanged) {
        unittab[0].compiled = FALSE;
        _TUTORset_state_internal_marker(unittab[0].marki,-1L,-1L,FALSE);
    } /* unittab[0] if */

    /* check if initial setup successfully performed */

    if (nunits <= 0) {  /* initial entry */
        SetupUnits();
        return 0;
    } /* nunits if */

    /* loop thru all units: check if modified */

    units = 0;
    while (TRUE) {
        while (units < nunits)
            {
            csourcen = unittab[units].beginfile;
            if ((csourcen < 0) || (csourcen >= sourcemalloc) || 
                (!sourcetable[csourcen].valid) || (!sourcetable[csourcen].programpart)) {
                SetupUnits();
        		return 0;
            }
            _TUTORinq_state_internal_marker(unittab[units].marki,&srcPos,&tempL,&unitChanged);
        	source = sourcetable[csourcen].doc;
        	docLen = TUTORget_len_doc(source);
        	if (((srcPos+tempL) > docLen) || (tempL <= 0) || (srcPos >= docLen)) {
        		SetupUnits(); /* unit gone, or at or past end of document */
        		return(0);
        	}
        	if (unitChanged)
                break;
            units++;
            }
        if (units >= nunits) { /* we've gone thru all the units */
            setbasesrc(); /* re-set to base doc */
            return 0;
        }
        unittab[units].compiled = FALSE;
        _TUTORset_state_internal_marker(unittab[units].marki,-1L,-1L,FALSE);
        _TUTORinq_state_internal_marker(unittab[units].marki,&srcPos,NEARNULL,NEARNULL);
        csourcen = unittab[units].beginfile;
        source = sourcetable[csourcen].doc;
        if (units != 0) {   /* should start with old unit command */
            if (srcPos > 0 && TUTORcharat_doc(source,srcPos-1) != NEWLINE) {
                SetupUnits();
                return 0;
            }
            if (getcommand() != C_UNIT) {
                SetupUnits();
                return 0;
            }
            legalname = ReadUnitName(unitname);
            if (!legalname || MatchUnitName((unsigned char *) unitname) != units) {
                SetupUnits();
                return 0;
            }
            SkipLine();
        }
        if (srcPos) 
        	srcPos--; /* back up to include cr at end of unit */
        do { 
            found = Seekunit(source,&unitloc);
        } while (found && (seekcmd != C_UNIT));
        
        if ((units < nunits-1) && found){
            _TUTORinq_state_internal_marker(unittab[units+1].marki,&tempL,NEARNULL,NEARNULL);
            if (unitloc != tempL) { /* found -unit- in wrong place */
                SetupUnits();
                return 0;
            }
        } else { /* last unit was changed */
            if (found && (seekcmd == C_UNIT)) { /* another unit after last */
                SetupUnits();
                return 0;
            }
        }
        units++;
    } /* while */

} /* FindUnits */

/* ******************************************************************* */ 

extern int VerifyFindUnits(void);
extern int CheckUnitMarkers(void);
int  GetUnitName(int  unitn,unsigned char  *name);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);

int VerifyFindUnits()

{	int uii; /* index in units */
	int nii; /* index in unit name */
	long locL; /* location of unit command */
	int srcI; /* index of source file */
	Memh docH; /* handle on source document */
	unsigned char ustring[60];
	unsigned char uname[40];

	if (nunits < 0) 
		return(1); /* failed */
	ustring[4] = 0;
CheckUnitMarkers();	
	for(uii=1; uii<nunits; uii++) {
		srcI = unittab[uii].beginfile;
		if ((srcI < 0) || (srcI > sourcemalloc))
			return(2); /* failed */
		docH = sourcetable[srcI].doc;
		_TUTORinq_state_internal_marker(unittab[uii].marki,&locL,NEARNULL,NEARNULL);
		if (locL) {
			TUTORget_string_doc(docH,locL,59L,(unsigned char FAR *)ustring);
			if (strncmp((char *)ustring,"unit",4) != 0) 
				return(3); /* failed */
			nii = 4;
			while ((ustring[nii] == ' ') || (ustring[nii] == '\t'))
				nii++;
			GetUnitName(uii,uname);
			locL = strlen((char *)uname);
			if (strncmp((char *)&ustring[nii],(char *)uname,(int)locL) != 0)
				return(4);
		} /* locL if */
	}
	return(0);

} /* VerifyFindUnits */

/* ******************************************************************* */ 

#define USESTACKL 10    /* max depth in nested -use- */

static SetupUnits() /* mark locations of all units */

{   int si; /* index of current file */

    Halt(); /* cannot execute - destroying pcodes */

    /* locate all -use-d files */

    if (!SetupUse()) {
        nunits = -1; /* unit setup failed */
        setbasesrc(); /* re-set to base doc */
        return 0;
    } /* SetupUse if */

    /* locate all units in all files */

    si = 0;
    nunits = 0;
    while ((si<sourcemalloc) && (nunits >= 0)) {
        if (sourcetable[si].valid && sourcetable[si].programpart) {
            if (si > 0) {
                AllocUnits(nunits);
            } /* si if */
            SetupFile(si);
        } /* sourcetable if */
        si++;
    } /* while */
    setbasesrc(); /* re-set to base doc */

} /* SetupUnits */

/* ******************************************************************* */ 

static SetupFile(si) /* mark locations of all units in file */
int si; /* index in sourcetable */

{   long loc; /* location of current unit/use command */
    long prevloc; /* location of previous unit/use command */
    long ulen; /* length of current unit */
    int found; /* unit/end-of-file flag */
    int i;
    char ws[2+NAMEL]; /* unit name string */
    char ms[40+NAMEL]; /* error message string */
    struct unitinfo FAR *unp;
    struct markvar unitMark;

    if ((!sourcetable[si].valid) || (!sourcetable[si].programpart))
        return 0;

    csourcen = si; /* set index of current source file */
    source = sourcetable[si].doc;
    srcPos = 0;
    loc = 0;
    AddUnitName((unsigned char *) "*ieu",nunits);
    sourcetable[si].ieu = nunits;
    sourcetable[si].firstunit = 0; /* not determined yet */
    sourcetable[si].lastunit = 0;
    while (TRUE) {
        if (nunits+1 >= unitmalloc)
            { /* need to allocate more unit */
            AllocUnits(nunits);
            }
        prevloc = loc;
        do {
            found = Seekunit(source,&loc);
        } while (found && (seekcmd != C_UNIT));
        unp = &unittab[nunits];
        if (unp->pcodeAlphaH) {
            TUTORfree_handle(unp->pcodeAlphaH);
			if (unp->pcodeBetaH)
				TUTORfree_handle(unp->pcodeBetaH);
            unp->pcodeAlphaH = unp->pcodeBetaH = HNULL;
            unp->pcodeBetaL = unp->pcodeAlphaL = 0;
            unp->pdskadr = unp->bdskadr = unp->rdskadr = -1;
        } /* pcode if */
        ulen = (found ? loc-prevloc : TUTORget_len_doc(source)-prevloc);
        if (unittab[nunits].marki >= 0)
            _TUTORclose_internal_marker(unittab[nunits].marki);
        unitMark.pos = prevloc;
        unitMark.len = ulen;
        unitMark.alteredF = FALSE;
        unitMark.doc = source;
        unittab[nunits].marki = _TUTORinternal_marker((struct markvar SHUGE *) &unitMark,0,0L);
        unittab[nunits].compiled = FALSE;
        unittab[nunits].beginfile = csourcen;
        unittab[nunits].baseuse = sourcetable[si].outeruse;
        if (!found) {
        	if (nunits && si && (sourcetable[si].firstunit == 0))
        		sourcetable[si].firstunit = nunits; /* may be only ieu */
            sourcetable[si].lastunit = nunits;
            nunits++; /* to account for the unit we just finished handling */
            return 0;
        } /* not found if */
        nunits++;
        if (!ReadUnitName(ws)){
            terror("Only letters and numbers, <= 30 long.");
            nunits = -1;    /* indicate units not set up yet */
            return 0;
        } else {
            i = MatchUnitName((unsigned char *) ws);
            if (i >= 0) { 
                /* another unit with this name */           
                srcPos--;
                sprintf(ms, "Duplicate unit name:  %s",ws);
                terror(ms);
                nunits = -1;    /* units not set up yet */
                return 0;
            } /* dup name if */
            else { /* this is a new name */
                AddUnitName((unsigned char *) ws, nunits);
            }
        } /* else */
        if (sourcetable[si].firstunit == 0) /* 1st -unit- command */
            sourcetable[si].firstunit = nunits;
    } /* while */

} /* SetupFile */

/* ******************************************************************* */ 

static SetupUse() /* locate all -use- commands: build sourcetable */
           /* returns TRUE if succeeded, FALSE if error */

{   long loc;   /* location of current unit/use command */
    int found;  /* unit/end-of-file flag */
    int cnt;    /* length of file name string */
    int ictutv;     /* current cmututor version for -use- check */
    char *p, c; /* input string */
    int useindex;   /* index of -use- file in sourcetable */
    char useS[CTPATHLEN+1]; /* -use- file path name (as in source) */
    FileRef usefilen;   /* -use- file reference */
    int usefile[USESTACKL]; /* nested -use- sourcetable indexes */
    long usepos[USESTACKL]; /* nested -use- positions */
    int usedepth; /* current depth in nested use */
    char *errp; /* pointer to parse_env error message */
    int i;      /* work variable */

    usedepth = 0; /* not in -use-d code */
    setbasesrc(); /* start with base source file */
    for(i=1; i<sourcemalloc; i++) sourcetable[i].programpart = FALSE;

    do {
        found = Seekunit(source,&loc); /* locate -unit- or -use- command */

        /* process -use- command */

        if (seekcmd == USE) {

            /* process -use- argument = file name */

            p = useS;
            cnt = 0;
            while (((c = TUTORcharat_doc(source,srcPos)) == ' ') ||
                      (c == '\t')) 
                srcPos++; /* skip white space */
            if (c != '"') {
                useerr("File name must be within quotes.");
                return(FALSE);
            }
            srcPos++; /* advance past quote mark */
            while (((c = TUTORcharat_doc(source,srcPos)) != NEWLINE) && 
                  (c != '"') && (cnt<CTPATHLEN)) {
                srcPos++; /* advance char pointer */
                cnt++;
                *p++ = c; /* build file name */
            } /* while */
            if (c != '"') {
                useerr("File name must be within quotes.");
                return(FALSE);
            }
            srcPos++; /* advance past terminating quote */
            /* strip trailing blanks on file name */
            while (*(p-1) == ' ' && p>useS) p--;
            *p = '\0';
            while (((c = TUTORcharat_doc(source,srcPos)) == ' ') ||
                      (c == '\t')) 
                srcPos++; /* skip white space */
            /* convert path to file reference: */
	    	TUTORcvt_path(useS,(FileRef FAR *) &usefilen,sourceDirP,TRUE);

            if ((c == '$') && (TUTORcharat_doc(source,srcPos+1) == '$')) {
                while ((c = TUTORcharat_doc(source,srcPos)) != NEWLINE)
                    srcPos++; /* proceed to end of line */
            } /* comment if */
            if (c != NEWLINE){ 
                useerr("Improperly formed -use- command.");
                return(FALSE);
            } /* newline if */

            /* read -use- source file */

            useindex = readuse(&usefilen);
            if (useindex < 0) return(FALSE);

            /* stack current file and position */

            if (usedepth >= USESTACKL) {
                useerr("Too deep in nested -use- commands.");
                return(FALSE);
            } /* usedepth */
            if (usedepth == 0)
                sourcetable[useindex].outeruse = srcPos;
            else 
                sourcetable[useindex].outeruse = usepos[0];
            usefile[usedepth] = csourcen;   /* save current file */
            usepos[usedepth] = srcPos;  /* save current position */
            usedepth++; /* increment depth in nested -use- */

            /* switch to -use- file */

            csourcen = useindex;
            source = sourcetable[useindex].doc;
            srcPos = 0;

            /* process beginning lines of new file */

            ictutv = ctutv; /* save current cmututor version */
            ctutv = 0; /* no version */
            errp = parse_env(); /* parse inital environment lines */
            if (errp) {
                useerr(errp);
                return(FALSE);
            } /* error if */
            srcPos = 0; /* reset to begin of file */

            /* check if source conversion of use file required */

            if (ctutv != ictutv) {
                ctutv = ictutv; /* restore version */
                useerr("-use- of incompatible $syntaxlevel.");
                if (sourcetable[useindex].editI == -1)
                	sourcetable[useindex].valid = FALSE;
                return(FALSE);
            } /* version if */
            sourcetable[useindex].ctutv = ctutv;
        } /* seekcmd if */

        /* process end-of-file on -use-d file */

        if (((!found) || (seekcmd == C_UNIT)) && usedepth) {
            usedepth--;
            csourcen = usefile[usedepth];   /* re-set to previous file */
            source = sourcetable[csourcen].doc;
            srcPos = usepos[usedepth];
            found = TRUE; /* continue search */
            seekcmd = 0; /* suppress -unit- while check */
        } /* usedepth if */
    } while (found && (seekcmd != C_UNIT));
    return(TRUE); /* exit happy */

} /* SetupUse */

/* ******************************************************************* */

static int readuse(fn)  /* process -use- file - returns index in sourcetable */
FileRef *fn;        /* file name */

{   int i,jj;       /* work variables */
    int findex; /* index in file name table */
    int eindex; /* index of editor on file */
    Memh d; /* handle on document */
    struct stat fst;    /* file status block */
    char errmsg[256];   /* error message buffer */
    struct sourcefile FAR *sourceP;

    if (!fn->path[0]) {
        useerr("Cannot read -use- file.");
        return(-1);
    } /* strlen if */

    /* check if file has already been opened */

    findex = -1;    /* pre-set not found */
    sourceP = FARNULL;
    for(i = 0; ((i < sourcemalloc) && (findex<0)); i++) {
        if (TUTORcmp_fileref(&sourcetable[i].fRef,(FileRef FAR *) fn) == 0) {
        	findex = i;
        	sourceP = sourcetable+findex;
        	break; /* exit for */
        }
    } /* for */

	/* allocate new source table entry if neccessary */
		
	if (findex < 0) {
		findex = sourcemalloc;  /* index of this file */
        sourcetable = (struct sourcefile FAR *) TUTORrealloc(
                      (char FAR *)sourcetable,
                      (long)(sourcemalloc*sizeof(struct sourcefile)),
                      (long)((sourcemalloc+1)*sizeof(struct sourcefile)),TRUE);
        if (sourcetable == NULL) {
            useerr("Insufficient memory for -use-.");
            return(-1);
        } /* sourcetable if */
        sourcemalloc++;
        initsourcet(findex); /* initialize new table entry */
        sourceP = sourcetable+findex; /* pointer to table entry */
    }
    
	/* check if editor on this source file */
	
	eindex = CheckEditOnFile((FileRef FAR *)fn,&d,-1);
	if (eindex >= 0) {
	
		/* connect source table entry to editor */
		
		sourceP->valid = TRUE; /* must be valid if being edited */
		sourceP->editI = eindex; /* set index of editor */
		sourceP->doc = d; /* set handle on document */
		sourceP->writeable = TRUE;
		sourceP->ctutv = 0;
		TUTORcopy_fileref(&sourceP->fRef,(FileRef FAR *) fn);
	} /* eindex if */
	
    /* read new source file, or re-read if previous attempt failed */

    if (!sourceP->valid) {
        if (sourceP->doc == HNULL) { /* new entry in sourcetable */
            TUTORcopy_fileref(&sourceP->fRef,(FileRef FAR *) fn);
            sourceP->doc = TUTORnew_doc(FALSE,TRUE); /* set up document */
        } /* findex if */
        sourceP->ctutv = 0; /* no version yet */
        d = sourceP->doc;   /* get pointer to document */
        TUTORclear_doc(d); /* empty document */
        EditorDefaultStyles(d);
        i = readdoc(d,(FileRef FAR *) fn,&jj);
        sourceP->writeable = jj;
        if (!i) {
            strcpy(errmsg,"Cannot read -use- file.");
            strcat(errmsg,NEWLINES);
            strncat(errmsg,fn->path,200);
            useerr(errmsg);
            return(-1);
        } /* i if */
        sourceP->valid = TRUE; /* file contents valid */
        TUTORstat(&sourceP->fRef,&fst);
        sourceP->mtime = fst.st_mtime;
    } /* findex if  */

    sourceP->programpart = TRUE; /* file is being -use-d */
    return(findex); /* return index of file in sourcetable */

} /* readuse */

/* ******************************************************************* */

int useerr(errstr) 
char *errstr;   /* message string */

{   int i;

    eError(errstr,0,0L,0L,0); /* display error message  */

    /* re-compile everything: don't know which unit is bad */

    for (i=0; i<unitmalloc; i++) { 
        unittab[i].compiled = FALSE;
    } /* for */

    return(CMDERR); 

} /* useerr */


/* ******************************************************************* */

static int ReadUnitName(str) /* read unit name to str, return TRUE if legal */
char *str;

{   int nc;
    char c;

    while ((cB[cI] == ' ') || (cB[cI] == '\t')) cI++;
    if ((!CTisascii(cB[cI]) || !CTisalpha(cB[cI]))) return(FALSE);
    nc = 0; /* no characters yet */
    while ((CTisascii(cB[cI])) && (CTisalnum(cB[cI]) || (cB[cI] == '_')) 
           && (nc < NAMEL)) {
        str[nc++] = cB[cI++];
    } /* while */
    if (nc >= NAMEL) return(FALSE);
    str[nc] = '\0';
    c = cB[cI]; /* terminating character */
    if ((c != NEWLINE) && (c != '(') && (c != '[') && (c != ' ') &&
        (c != '\t') && (c != '$')) return(FALSE);
    return(TRUE);

} /* ReadUnitName */

/*********************************************/
Seek(ss, dd, start, found) /* fill found with location of s in d, or return FALSE */
char *ss;
Memh dd;
long start, *found;
    {
    long fLen; /* length of found string */
    int foundIt;
    DocP dp;
    long sLen;

    dp = (DocP) GetPtr(dd);
    sLen = strlen(ss);
    *found = TUTORsearch_string_doc(dp,(unsigned char FAR *) ss, sLen,
                start, dp->totLen);
    foundIt = (*found >= 0);
    ReleasePtr(dd);
    KillPtr(dp);
    return(foundIt);
    }

/* ******************************************************************* */
RefillBuffer() /* recharge buffer in the middle of a line */
    {
    FillBuffer(source,startofline+cI, srcEnd - (startofline+cI));
    /* make it look like line begin... */
    startofline += cI;
    cI = 0;
    }

/* ******************************************************************* */

static Memh msgTableH = HNULL; /* handle on message table */

cerror(errnumber, execstr) 
int errnumber;  /* error number */
char  *execstr; /* error message string */

{   char cerrmsg[500];  /* error message buffer */
    int errunit;    /* unit number error occurred in */
    int i,j;    /* index in message string */
    long spos,slen; /* selection position, length */
    char c;
    char filename[FILEL+1], unitname[NAMEL+1];
    long tempL;
	char FAR *msgP; /* pointer in error messages */

	if ((errnumber == MISSINGUNIT) || (errnumber == DUPUNIT))
		nunits = -1; /* force full re-compile if missing unit */

	/* get error message */

    if (errnumber == SPECIFICERR) {
        strcpy(cerrmsg,execstr);
    } else {
		if (!msgTableH)
			msgTableH = LoadTable("messages.tab",NEARNULL);
		if (!msgTableH) {
			strcpy(cerrmsg,"No memory for error message");
		} else {
			msgP = GetPtr(msgTableH);
			i = 0; /* index in error messages */
			while (i < errnumber) { /* loop till find our message */
				msgP += strlenf(msgP)+1; /* advance to next message */
				i++;
			} /* while */
        	strcpyf(cerrmsg,msgP);
			ReleasePtr(msgTableH);
		}
    } /* else */

	if (compunit == 0)
		nunits = -1; /* force full re-compile if error in IEU */
		/* something of a kludge, but insures no problems will ocurr if */
		/* error before end_global_defines() */
    if (compunit >= 0) {
        unittab[compunit].haserrors = TRUE;
        unittab[compunit].compiled = FALSE;
        if (unittab[compunit].pcodeAlphaH) {
        	TUTORfree_handle(unittab[compunit].pcodeAlphaH);
        	unittab[compunit].pcodeAlphaH = HNULL;
        	unittab[compunit].pcodeAlphaL = 0;
        }
    }
    
    if (srcPos && LastChar == NEWLINE && errnumber != BADINDENT)
        srcPos--;
    if (errnumber == BADTEXT) {
        errnumber = SPECIFICERR; /* differs for conditional form */
    } /* errnumber if */

	/* check for specific types of error */
	
	if (compunit && !local_def_fin) {
		pRelevant(cerrmsg);
		strcat(cerrmsg,"The compiler is processing local defines before the first command");
	}
	j = strlen(kUnrecStr);
	if (strncmp(kUnrecStr,cerrmsg,j) == 0) { /* unrecognized variable */
		if (cmdlookp(cerrmsg+j) > 0) {
			pRelevant(cerrmsg);
			strcat(cerrmsg,"Name begins with a legal command (incorrect indenting?)");
		}
	}
	
	/* get area to highlight for editor */
	
    if (EditVp[0]) {
        srcPos = startofline+cI - ciStart;
        spos = startofline;
        slen = srcPos-startofline;
        if (slen <= 0) slen = 0;
    } /* edit view if */
		
	eError(cerrmsg,csourcen,spos,slen,0); /* display error message */

    rerunflag = halt;
    Halt();
    StopCompile();
    longjmp(errjmpbuff,1);

} /* cerror */

/* ******************************************************************* */

terror(errstr) 
char *errstr;   /* pointer to message */

{   long startline; /* index of 1st char of bad line */
    int si; /* index of source file */
 
    if (csourcen) {
        si = csourcen;
        setbasesrc();
        srcPos = sourcetable[si].outeruse;
    } /* csourcen if */
    startline = srcPos;
    if (startline) startline--;
    while ((TUTORcharat_doc(source,startline) != NEWLINE) && startline)
        startline--;
    startline++;
    if (EditVp[0]) {
        if (startline < 0) startline = 0;
		eError(errstr,0,startline,0L,1); /* display error message */
    } /* edit view if */

    Halt();

} /* terror */

/* ------------------------------------------------------------------- */

eError(errstr,sourceI,pos,len,type) /* send error message to editor (if possible) */
char *errstr;   /* pointer to message */
int sourceI; /* index in source file table */
long pos; /* position of error in source file */
long len; /* length to highlight */
int type; /* 0 = normal compile error */
          /* 1 = FindUnits failure */

{   struct tutorevent errevent; /* event sent to editor */
    int eventid;

	eventid = 0;
	errevent.eDataP = FARNULL;
    if (EditVp[0]) {
        errevent.window = EditWn[0];
        errevent.view = FARNULL; /* message sent to window */
        errevent.type = EVENT_TIME;
        errevent.value = time_err;
        errevent.timestamp = 1;
        errevent.a1 = TRUE; /* FindUnits type error */
        errevent.a2 = sourceI; /* index in sourcetable */
        errevent.a4 = pos; /* pass position+length */
        errevent.a5 = len;
        errevent.eDataP = TUTORalloc((long)strlen(errstr)+2L,TRUE,"errmsg");
        strcpyf(errevent.eDataP,(char FAR *)errstr);
        eventid = TUTORpost_event(&errevent); /* send event to editor */
    } /* edit view if */

	if (!eventid) {
    	TMessage((char FAR *)errstr); /* display message if haven't sent event */
        if (errevent.eDataP)
            TUTORdealloc(errevent.eDataP); /* didnt post event */
	}

} /* eError */

/* ------------------------------------------------------------------- */

StopCompile()   /* abort current unit compile */

{
    setbasesrc();   /* set up for main (editing) source file */
    if (EditWn[0] >= 0) EndCompileMsg(EditWn[0]);
    else if (ExecWn >= 0) EndCompileMsg(ExecWn);
    if (cmpLocked) { /* free compile buffer */
        ReleasePtr(cmpH);
        KillPtr(cmpbuf);
        cmpLocked = FALSE;
    }
    if (srbimapH) { /* free source map */
    	ReleasePtr(srbimapH);
    	srbimapH = HNULL;
    	srbimapP = FARNULL;
    }
    if (descP) { /* free descriptors */
        ReleasePtr(descH);
        KillPtr(descP);
        descP = FARNULL;
    }
    if (xtokmalloc) { /* free token table */
        TUTORdealloc((char FAR *)xtokd);
        xtokmalloc = 0;
        xtokd = NULL;
    }
    if (xtP) { /* free expression analyzer table */
        ReleasePtr(xtH);
        xtP = NULL;
    }
    if (uargP) { /* free unit arguments table */
        ReleasePtr(uargH);
        uargP = NULL;
    } 

} /* StopCompile */

/* ******************************************************************* */

pRelevant(msgStr)
char *msgStr;

{
	strcat(msgStr,NEWLINES);
	strcat(msgStr,"Possibly relevant: ");
}

/* ******************************************************************* */

setbasesrc()    /* restore to base file: not in -use- code */

{
    csourcen = 0; /* initialize index of source file */
    srcPos = 0;
    source = sourcetable[0].doc; /* re-set to base doc */
        defexp.srcH = source; /* source input doc for expressions */

} /* setbasesrc */

/* ******************************************************************* */

static skipblanklines() /* skip over blank or comment lines in parsing $ lines */
    
{   long docLen;
    unsigned char *c2;
    int startIndent;

    docLen = TUTORget_len_doc(source);
    while (TRUE) { /* keep skipping lines while they are comments */
        FillBuffer(source,srcPos,docLen-srcPos);
        srcPos += nBuffChars; /* srcPos at begin of next line (unless buffer overflow) */
        if (nBuffChars == 0) break; /* out of input */
        c2 = cB;
        if (StripLineStart(&c2, 0,&startIndent))
            break; /* found a non-comment line */
    } /* while */
    srcPos -= nBuffChars; /* to position at begin of non-comment line */

} /* skipblanklines */

/* ******************************************************************* */

char *parse_env() /* process $keyword environment variables at begin of file */
/* returns address of error message or NULL if all ok */

{   double dw1,dw2; /* floating work variables */
    long lw1,lw2; /* long work variables */
    int term; /* terminating character */
    char FAR *cp; /* ptr to current character */
    int cc; /* current character */
    int errf; /* getnum error flag */
    char *errp; /* getnum message ptr */
    int floatf;

    srcPos = 0;
    indentlevel = 0; /* no indentations */
    nocliptext = FALSE;
    oldfontsize = FALSE;
    wrapwrite = FALSE;
    oldcolor = pcoldcolor = useNativeChars = FALSE;
    nostylemarkf = FALSE;
    ExecWinX = ExecWinY = 0;
    usesColor = 0;

    skipblanklines();

    /* process $directive lines */

    while (TUTORcharat_doc(source,srcPos) == '$') {
    	startofline = srcPos;
        FillBuffer(source,srcPos,(long)(TUTORget_len_doc(source)-srcPos));
        cI = 0; /* index in tag buffer */

        /* process "$syntaxlevel n" directive */

        if (strncmpf((char FAR *) &cB[cI],(char FAR *)"$syntaxlevel",12) == 0) {
            cI += 12;
            skip_white_cB();

            /* extract numeric value */

            errf = 0; /* no error yet */
            getnum((char *) &cB[cI],&floatf,&lw1,&dw1,&errp,&errf);
            if (errf) return("$syntaxlevel numeric value bad.");
            if (!floatf) dw1 = lw1; /* convert to floating */
            dw1 = dw1+19.0; /* convert to internal form */
            ctutv = lcftoi(dw1);

            /* advance past number */
    
            while (((cB[cI] >= '0') && (cB[cI] <= '9')) ||
                  (cB[cI] == '.')) cI++;    

        /* process "$nocliptext" directive */

        } else if (strncmpf((char FAR *) &cB[cI],(char FAR *)"$nocliptext", 11) == 0) { 
            nocliptext = TRUE;
            wrapwrite = TRUE;
            cI += 11;

        /* process "$oldfontsize" directive */

        } else if (strncmpf((char FAR *) &cB[cI],(char FAR *)"$oldfontsize", 12) == 0) {
            oldfontsize = TRUE;
           cI += 12;
           
        /* process "$nativechars" directive */

        } else if (strncmpf((char FAR *) &cB[cI],(char FAR *)"$nativechars", 12) == 0) {
           useNativeChars = TRUE;
           cI += 12;

        /* process "$writewrap" directive */

        } else if (strncmpf((char FAR *) &cB[cI],(char FAR *)"$writewrap", 10) == 0) {
            wrapwrite = TRUE;
            cI += 10;

        /* process "$oldcolor" directive */

        } else if (strncmpf((char FAR *) &cB[cI],(char FAR *)"$oldcolor", 9) == 0) {
            oldcolor = TRUE;
            cI += 9;

        /* process "$pcoldcolor" directive */

        } else if (strncmpf((char FAR *) &cB[cI],(char FAR *)"$pcoldcolor", 11) == 0) {
#ifdef IBMPC
            pcoldcolor = TRUE;
#endif
            cI += 11;

        /* process "$nostylemark" directive */

        } else if (strncmpf((char FAR *) &cB[cI],(char FAR *)"$nostylemark", 12) == 0) {
            nostylemarkf = TRUE;
            cI += 12;

		/* process "$window" directive */
		
		} else if (strncmpf((char FAR *) &cB[cI],(char FAR *)"$window", 7) == 0) {
            cI += 7;
 			skip_white_cB();
			errf = 0; /* no error yet */

			if (cB[cI] == NEWLINE) {
				lw1 = lw2 = -1; /* set for full screen */
			} else {

				/* extract numeric value */
 
				getnum((char *) &cB[cI],&floatf,&lw1,&dw1,&errp,&errf);
				if (errf) return(errp);
				if (floatf) lw1 = dw1; /* convert to integer */

				/* advance to comma */
    
				while ((cc = cB[cI]) != NEWLINE) {
            		cI++;
            		if ((cc == ';') || (cc == ':'))
            			return("Bad character in $syntaxlevel.");
            		if (cc == ',')
            			break; /* exit while */
				} /* while */

           		/* extract second numeric value */
           	
				getnum((char *) &cB[cI],&floatf,&lw2,&dw1,&errp,&errf);
				if (errf) return("$syntaxlevel numeric value bad.");
				if (floatf) lw2 = dw1; /* convert to integer */
			} /* NEWLINE else */
			ExecWinX = lw1; /* initial executor window size */
			ExecWinY = lw2;
			
			 while (cB[cI] != NEWLINE) 
                cI++; /* skip to end of line */
			
        /* process $$ comment */

        } else if (strncmpf((char FAR *) &cB[cI],(char FAR *)"$$",2) == 0) {
            while (cB[cI] != NEWLINE) 
                cI++; /* skip to end of line */
        }

        /* process unrecognized keyword */

        else return("unrecognized $keyword.");

        /* skip white space and $$ comment */

        srcPos += cI;
        while (((cc = TUTORcharat_doc(source,srcPos)) == ' ') || (cc == '\t')) 
            srcPos++;
        if ((cc == '$') && (TUTORcharat_doc(source,srcPos+1) == '$')) {
            while ((cc = TUTORcharat_doc(source,srcPos)) != NEWLINE)
                srcPos++;   /* skip over comment */
        } /* $ if */

        /* check if at end of line */

        cc = TUTORcharat_doc(source,srcPos);    /* get terminating character */
        if ((cc == NEWLINE)) srcPos++; /* advance to next line */
        else return("too many arguments");
        skipblanklines();
        if (srcPos >= TUTORget_len_doc(source)) 
            break;
    } /* $ while */
    
    if (ctutv <= 20)
        wrapwrite = TRUE; /* set for old version */
        
    return(NULL);

} /* parse_env */

/* ******************************************************************* */

cmpbuf_flt(d) /* add double floating value to output pcodes */
double d;

{   char *vp; /* pointer in floating value */
    char FAR *bp; /* pointer in pcodes */
    int ii;

    vp = (char *) &d; /* set pointer to floating value */
    bp = (char FAR *)(cmpbuf+cmpl);
    for(ii=0; ii < sizeof(double); ii++)
        *bp++ = *vp++; 
    cmpl += sizeof(double);

} /* cmpbuf_flt */

/* ******************************************************************* */

cmpbuf_word(n) /* add 2-byte integer to pcodes in cmpbuf */
int n; 

{
    *((short FAR *)(cmpbuf+cmpl)) = n;
    cmpl += 2;

} /* cmpbuf_word */

/* ******************************************************************* */

cmpbuf_plant_word(addr,n) /* add 2-byte integer to pcodes in cmpbuf */
unsigned int addr; /* index in cmpbuf */
int n; 

{
    *((short FAR *)(cmpbuf+addr)) = n;

} /* cmpbuf_plant_word */

/* ******************************************************************* */

cmpbuf_long(nn) /* add 4-byte integer to pcodes in cmpbuf */
long nn;

{   short *vp; /* pointer in long value */
    short FAR *bp; /* pointer in pcodes */
    unsigned char FAR *cp; /* pointer in pcodes */

    vp = (short *) &nn; /* set pointer to long value */
    cp = cmpbuf+cmpl;
    bp = (short FAR *)(cp);
    *bp++ = *vp++; /* add 4 bytes */
    *bp++ = *vp++;
    cmpl += 4;

} /* cmpbuf_long */

/* ******************************************************************* */

int cmpbuf_xref(kind,label) /* add relative-to-unit address */
/* returns index in relocation table */
int kind; /* type of branch/structure */
int label; /* internal label referred to */

{   unsigned int aref; /* relative address of reference */

    cmpbuf_word(ULOCADDR); /* address-in-unit operator */
    aref = cmpl;
    cmpbuf_word(0); /* add destination address field */
    return(add_xref(kind,label,aref,0)); /* add to relocation table */
    
} /* cmpbuf_xref */

/* ******************************************************************* */

int add_xref(kind,label,aref,adest) /* add new entry to relocation table */
/* returns index in relocation table */
int kind; /* type of branch/structure */
int label; /* internal label referred to */
unsigned int aref; /* relative address of reference */
unsigned int adest; /* relative address of destination */

{   int nrefs;

    nrefs = unittab[compunit].nrefs++; /* number entries in table */
    if (nrefs >= xrefL) { /* expand table */
        if (xrefH == HNULL)
	    TUTORdump("no xref table");
        ReleasePtr(xrefH);
        KillPtr(xrefP);
        TUTORset_hsize(xrefH,(long)((nrefs+20)*sizeof(struct locref)),TRUE);
        xrefL += 20;
        xrefP = (struct locref FAR *)GetPtr(xrefH); /* update pointer */
    } /* nrefs if */

    xrefP[nrefs].kind = kind; /* type of branch/structure */
    xrefP[nrefs].label = label;
    xrefP[nrefs].aref = aref; /* relative addr of reference */
    xrefP[nrefs].adest = adest; /* rel addr of destination if known */
    return(nrefs); /* return index */

} /* add_xref */

/* ******************************************************************* */

plant_xref(iref,adest) /* plant destination for reloc table entry */
int iref; /* index of reference */
unsigned int adest; /* destination address */

{
    xrefP[iref].adest = adest; /* set table */
    *((short FAR *)(cmpbuf+xrefP[iref].aref)) = adest; /* set pcode */
    xrefP[iref].kind |= 0x80; /* mark reference satsified */
    
} /* plant_xref */

/* ******************************************************************* */

satisfy_xref(index,kind,label,adest) /* satisfy references */
int index; /* starting index in relocation table */
int kind; /* type of branch/structure */
int label; /* internal label referred to */
unsigned int adest; /* relative address of destination */

{   int ri; /* index in relocation table */

    for(ri = index; ri < unittab[compunit].nrefs; ri++) {
        if ((xrefP[ri].kind == kind) && (xrefP[ri].label == label)) 
            plant_xref(ri,adest);
    } /* for */

} /* satisfy_xref  */

/* ******************************************************************* */

add_dest(type,label,pos) /* add branch destination to xref table */
int type; /* type of branch/structure */
int label; /* internal label of this location */
unsigned int pos; /* relative position of destination */

{
    add_xref(type,label,pos,0);

} /* add_dest */

/* ******************************************************************* */

compile_ubranch(kind,label) /* compile unconditional branch */
int kind; /* type of branch/structure */
int label; /* internal label referred to */

{   unsigned int aref; /* address of reference */

    cmpbuf_word(ULOCADDR);
    aref = cmpl; /* location of branch address */
    cmpbuf_word(0);
    add_xref(kind,label,aref,-1); /* add to reloc table */
    cmpbuf_word(C_BRANCH); /* unconditional branch */

} /* compile_ubranch */

/* ******************************************************************* */

int compile_cbranch(logic,kind,label) /* compile unconditional branch */
/* returns relocation table index of reference */
int logic; /* TRUE  = branch-on-true */
           /* FALSE = branch-on-false */
int kind; /* type of branch/structure */
int label; /* internal label referred to */

{   unsigned int aref; /* address of reference */
    int iref; /* index in reloc table */
    int op; /* branch code */

    compile_simple_numeric(0x80,0x00,FALSE); /* condition expr */
    cmpbuf_word(ULOCADDR);
    aref = cmpl; /* location of branch address */
    cmpbuf_word(0);
    iref = add_xref(kind,label,aref,-1); /* add to reloc table */
    op = (logic ? C_BRANCHT: C_BRANCHF);
    cmpbuf_word(op); /* conditional branch */
    return(iref);

} /* compile_cbranch */

/* ******************************************************************* */

xref_open(unitn) /* open cross-reference tables for this unit */
int unitn;

{
    if (xrefH) {
        ReleasePtr(xrefH); /* release previous ref table */
        KillPtr(xrefP);
    }
    xrefH = unittab[unitn].xrefs; /* handle on current table */
    if (xrefH == HNULL) {
        xrefH = TUTORhandle("xrefs",0L,TRUE); /* create cross-ref table */
        unittab[unitn].xrefs = xrefH;
        unittab[unitn].nrefs = 0;
    }
    xrefL = TUTORget_hsize(xrefH); /* current length of table (bytes) */
    xrefL = xrefL/sizeof(struct locref); /* length (entries) */
    xrefP = (struct locref FAR *)GetPtr(xrefH);

} /* xref_open */

/* ******************************************************************* */

unsigned int xref_copy(unitn) /* open working copy of cross-reference tables for this unit */
int unitn;

{	Memh orgH; /* original xref table */

    if (xrefH) {
        ReleasePtr(xrefH); /* release previous ref table */
        KillPtr(xrefP);
    }
    orgH = unittab[unitn].xrefs; /* handle on current table */
    if (orgH == HNULL) {
        orgH = TUTORhandle("xrefs",0L,TRUE); /* create cross-ref table */
        if (orgH == HNULL) {
        	TUTORmem_alert();
        	return(0);
        }
        unittab[unitn].xrefs = orgH;
        unittab[unitn].nrefs = 0;
    }
    xrefH = TUTORcopy_handle(orgH); /* make a copy of xref table */
    if (!xrefH) {
    	TUTORmem_alert();
    	return(0);
    }
    xrefL = TUTORget_hsize(xrefH); /* current length of table (bytes) */
    xrefL = xrefL/sizeof(struct locref); /* length (entries) */
    xrefP = (struct locref FAR *)GetPtr(xrefH);
    return(xrefH);

} /* xref_copy */

/* ******************************************************************* */

xref_close() /* close cross-reference tables */

{
    if (xrefH) {
        ReleasePtr(xrefH);
        KillPtr(xrefP);
    }
    xrefH = 0; /* no handles */
    xrefP = NULL; /* no pointers */
    xrefL = 0;
    
} /* xref_close */

/* ******************************************************************* */
