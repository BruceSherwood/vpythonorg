
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Execute cT pcode.
*/

/* This file contains "service" routines for execution:  initializations, 
    general routines, menu treatment, etc.
*/

#include "execdefs.h"
#include "eglobals.h"
#include "tglobals.h"
#include "commands.h"


#ifdef ctproto
extern void TUTORset_color(int select,struct tutorColor FAR *newColor);
extern int checkRadians(void);
int TUTORset_color_rgb(int select,int SysOrPal,double red,double green,double blue);
int  ResetFine(void);
long  ResetTextSize(int  force,int  showmessage);
int  DefaultFine(void);
extern int  ShowComment(char  *s);
extern int  DeleteComment(void);
int  inhibitdisplay(void);
int  enabledisplay(void);
int  setclip(void);
int  unclip(void);
int  setmode(int  m);
int  FullScreenErase(void);
int  arc(long  radius,double  angle1,double  angle2,int  unbroken);
int  makebox(int  tgiven,long  x1,long  y1,long  x2,long  y2,int  thick);
int  makevector(long  xtail0,long  ytail0,long  xpoint0,long  ypoint0,double  type);
int  TUTORcvt_font_size(long ffid,int  crsize,int  *realSize);
int  TUTORinq_font_descr(int  fontN,long  *fam,int  *siz,int  *fac);
int  RoundCoord(long  xx);
long  HalveCoord(long  xx);
long  IntToCoord(int  xx);
extern long MulCoord(long xx,long yy);
long  DivCoord(long  xx,long  yy);
int  flush(void);
int  CTset_background_color(int  color);
int  TUTORclear_screen(void);
int  TUTORget_colors(struct tutorColor *fcx,struct tutorColor *bcx,struct tutorColor *wcx);
int  TUTORset_comb_rule(int  rule);
int  TUTORunset_clip_rectangle(void);
int  TUTORset_clip_rectangle(long  x1,long  y1,long  x2,long  y2);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
int  TUTORset_rect(struct  _trect *r,int  left,int  top,int  right,int  bottom);
int  TUTORabs_move_to(int  x,int  y);
int  TUTORdraw_text(unsigned char  FAR *buf,int  count);
int  TUTORset_textfont(int  jj);
int  TUTORinq_abs_screen_size(int  *x,int  *y,int  *dx,int  *dy);
int  TUTORinq_abs_pen_pos(int  *x,int  *y);
int  TUTORget_font2(long fam,int  size,unsigned int  face,int cid);
int  TUTORrescale_message(void);
extern double sin(double x);
extern double cos(double x);
extern double sqrt(double x);
extern double atan2(double x, double y);
double  CoordToFloat(long  xx);
int  TUTORdraw_rectangle(long  x1,long  y1,long  x2,long  y2);
int  TUTORthick_box(long  x1,long  y1,long  x2,long  y2,long  thick,long  thickx,long  thicky);
int  TUTORfill_rectangle(long  x1,long  y1,long  x2,long  y2);
extern int abs(int nn);
long  FloatToCoord(double  zz);
int  TUTORdraw_arc(int  calledby,long xc, long yc, double radius, long  x1,long  y1,
    long  x2,long  y2,double  startAngle,double  stopAngle,int  unbroken);
int  TUTORfill_polygon(int  npoints,long  *fx,long  *fy);
int  TUTORend_line(long  x,long  y);
int  TUTORmove_to(long  x,long  y);
int  TUTORline_to(long  x,long  y);
#endif /* ctproto */

#ifdef macproto
int sprintf(char *,char *,...);
#endif

#ifndef WERKS
extern double atan2();
#endif

extern Coord ResetTextSize();
extern long  FloatToCoord();
extern double sin();
extern double cos();
extern double sqrt();
extern double CoordToFloat();
extern long  HalveCoord();
extern long  IntToCoord();
extern long MulCoord();
extern long  DivCoord();

#define VectorHEAD 20
#define VectorClosedANGLE 20
#define VectorOpenANGLE 20

/*********************************************/
ResetFine()
	{ /* rescale based on fine and rescale */
	Coord tempCo, ratio;
	
	/* calculate scales */
	
	if (exS.RescaleX && exS.ScreenW != coordZero)
		exS.ScaleX = DivCoord(exS.ScreenW,exS.RegionXmax-exS.RegionXmin+coordOne);
	else
		exS.ScaleX = coordOne;
	
	if (exS.RescaleY && exS.ScreenH != coordZero)
		exS.ScaleY = DivCoord(exS.ScreenH,exS.RegionYmax-exS.RegionYmin+coordOne);
	else
		exS.ScaleY = coordOne;
	
	if (exS.RoundCircles)
		{ /* constrain scaling to maintain aspect ratio */
		if (!exS.RescaleX || !exS.RescaleY) /* at least one coord isn't rescaling */
			{ /* to maintain aspect ratio, rescale neither */
			exS.ScaleX = exS.ScaleY = coordOne;
			}
		else
			{ /* to maintain aspect ratio make both scales the minimum */
			if (exS.ScaleX < exS.ScaleY)
				exS.ScaleY = exS.ScaleX;
			else
				exS.ScaleX = exS.ScaleY;
			}
		}
	
#ifdef IBMPC
	if (exS.yfudge != coordOne && exS.RescaleY)
		exS.ScaleY = MulCoord(exS.ScaleY,exS.yfudge);
#endif /* IBMPC */

	/* calculate OffsetX */
	tempCo = MulCoord(exS.ScaleX,exS.RegionXmax-exS.RegionXmin+coordOne);
	exS.OffsetX = exS.ScreenX0 + RoundCoord(HalveCoord(exS.ScreenW-tempCo));
	if ((exS.OffsetX < 0) && (!exS.RescaleX))
		exS.OffsetX = exS.ScreenX0;
	
	/* calculate OffsetY */
	tempCo = MulCoord(exS.ScaleY,exS.RegionYmax-exS.RegionYmin+coordOne);
	exS.OffsetY = exS.ScreenY0 + RoundCoord(HalveCoord(exS.ScreenH-tempCo));
	if ((exS.OffsetY < 0) && (!exS.RescaleY))
		exS.OffsetY = exS.ScreenY0;
	

	/* adjust for text */
	ratio = ResetTextSize(FALSE, TRUE);
	if (exS.ConstrainScale && exS.RescaleT && ratio < coordOne)
		{
		if (exS.RescaleX)
			exS.ScaleX = MulCoord(exS.ScaleX,ratio);
		if (exS.RescaleY)
			exS.ScaleY = MulCoord(exS.ScaleY,ratio);
		exS.OffsetX = exS.ScreenX0 + RoundCoord(HalveCoord(exS.ScreenW-MulCoord(exS.ScaleX,
	   					exS.RegionXmax-exS.RegionXmin+coordOne)));
		exS.OffsetY = exS.ScreenY0 + RoundCoord(HalveCoord(exS.ScreenH-MulCoord(exS.ScaleY,
	   					exS.RegionYmax-exS.RegionYmin+coordOne)));
		}

#ifdef IBMPC
	/* fix offscreen OffsetY (possible because of yfudge) */
	if (exS.OffsetY < 0)
		exS.OffsetY = 0;
#endif


	} /* ResetFine */

/* ******************************************************************* */

Coord ResetTextSize(force, showmessage)  /* scale font for current window size */
int force; /* TRUE if should set font even if no size change (ignored) */
int showmessage; /* TRUE if should display messages about window too small (font too big) */
/* return ratio of actual char height to requested char height */

/* 
    Choose a font size that will fit inside whatever graphics
    surround the text.  This means choosing the next smaller
    available size. Note that the requested CharHeight is in
    design (or fine or device-independent) dots, not pixels
    nor printer point size.  Choose a font which will produce
    letters which from the bottom of a lower-case y to the top
    of a capital Y is equal to CharHeight if NewFontSize is FALSE,  or the newline
    height of the font is equal to CharHeight if NewFontSize is TRUE.
*/

/* note that in the call from the FONT: command in execute, textFont may be set
	to no more than	the font family stub in the font table.  This is ok since force
	is TRUE (this is the only time force is TRUE)
*/

	{
	int height, realSize;
	Coord scale, desired;
	int newSize, currentSize;
	long family; 
	int messageFlag; /* 0: no message, 1: window maximum, 2: window not max */

	if (exS.CharHeight == -1)
		return(coordOne);  /* use specific font */

	/* get height, the desired size of the text */

	if (exS.RescaleT)
		{
		scale = (exS.ScaleX < exS.ScaleY) ? exS.ScaleX : exS.ScaleY;
		desired = exS.CharHeight*scale;
		}
	else
		desired = IntToCoord(exS.CharHeight);

	height = RoundCoord(desired - HalveCoord(coordOne)); /* round desired height down */
	/* height is desired font height, in pixels */

	/* get the correct system size for the height */
	TUTORinq_font_descr(exS.baseFont,&family,&currentSize,NEARNULL);
	newSize = TUTORcvt_font_size(family,height,&realSize);
	/* realSize is actual size of font (in pixels) */

	if (!exS.RescaleT || height >= realSize)
		messageFlag = 0; /* text is just fine, no message needed */
	else
		messageFlag = TUTORrescale_message(); /* check if window can grow */

	if (messageFlag == 2 && showmessage)
		{ /* ask user to make window bigger */
		if (exS.RoundCircles)
			{
			if  ((exS.OffsetY-exS.ScreenY0) < (exS.OffsetX-exS.ScreenX0))
				ShowComment("NEED TALLER WINDOW");
			else
				ShowComment("NEED WIDER WINDOW"); 
			}
		else
			{
			if (exS.ScaleX >= exS.ScaleY)
				ShowComment("TALLER WINDOW, PLEASE");
			else
				ShowComment("WIDER WINDOW, PLEASE"); 
			}
		}
	else
		{
		if (messageFlag == 1 && showmessage)
			ShowComment("NO FONT SMALL ENOUGH");
		else
			DeleteComment(); /* clear any comment */
		}

	/* reset the font */
	exS.baseFont = TUTORget_font2(family,newSize,0,120);
	TUTORset_textfont(exS.baseFont);
	exS.textFont = exS.baseFont;
	
	return(DivCoord(IntToCoord(realSize),desired));

	} /* ResetTextSize */

/*********************************************/
DefaultFine() {
exS.FineW = exS.ScreenW;
exS.FineH = exS.ScreenH;
exS.RegionXmin = exS.RegionYmin = coordZero;
exS.RegionXmax = exS.FineW - coordOne;
exS.RegionYmax = exS.FineH - coordOne;
}

/* ******************************************************************* */

#ifdef MAC
#ifdef THINKC5
#include <Quickdraw.h>
#endif
#endif

static ShowComment(s)	/* display message in executor window */
char *s;	/* message to display */

{	int oldx, oldy;	/* saved x,y position */
	int xmin,ymin,xmax,ymax;	/* screen boundaries */
	int slen; /* length of message */

	DeleteComment();
	unclip();
	setmode(writemode);
	TUTORinq_abs_pen_pos(&oldx, &oldy);
	TUTORinq_abs_screen_size(&xmin,&ymin,&xmax,&ymax);
	TUTORset_textfont(textFont0); /* set to default font */
#ifdef MAC
	TextSize(9); /* set to smallest size of font */
	TUTORabs_move_to(5,ymax-2);
#else
	TUTORabs_move_to(10, ymax-16);
#endif
	TUTORdraw_text((unsigned char FAR *) s,strlen(s));
	TUTORabs_move_to(oldx, oldy); /* restore screen location */
	setmode(exS.mode); /* restore mode */
	setclip();

} /* ShowComment */

/*********************************************/
static DeleteComment()
	{
	TRect tr;
	
	unclip();
	TUTORset_rect(&tr,(int) exS.ScreenX0,
				(int) exS.ScreenY0+RoundCoord(exS.ScreenH)+1,
				(int) exS.ScreenX0+RoundCoord(exS.ScreenW) -1,
				(int) exS.ScreenY0+RoundCoord(exS.ScreenH)+18);
	TUTORdraw_abs_solid_rect((TRect FAR *) &tr, PAT_WHITE);
	exS.outcnt += 2;
	OUTGO;
	setclip();
	}

/*********************************************/
inhibitdisplay() {
TUTORset_clip_rectangle(coordZero,coordZero,coordZero,coordZero);
}

/*********************************************/
enabledisplay() {
setclip();
}

/*********************************************/
setclip() {
if (checkbit(exS.inhibbits, INHDISPLAY))
    {inhibitdisplay(); return(0); }
TUTORset_clip_rectangle(exS.ClipX, exS.ClipY, exS.ClipX2, exS.ClipY2) ;
}

/*********************************************/
unclip() {
TUTORunset_clip_rectangle();
}
/* ******************************************************************* */

int checkRadians() 

{
	return(checkbit(exS.inhibbits, INHDEGREE));
	
} /* checkRadians */

/* ******************************************************************* */

setmode(m) /* set mode (write, rewrite, etc) */
int m; 

{
	switch (m) {
	case writemode:
  		TUTORset_comb_rule(SRC_OR);
		break;
	case rewritemode:
		TUTORset_comb_rule(SRC_COPY);
		break;
	case erasemode:
		TUTORset_comb_rule(SRC_BIC);
		break;
	case inversemode:
		TUTORset_comb_rule(NOT_SRC_COPY);
		break;
	case xormode:
		TUTORset_comb_rule(SRC_XOR);
		break;
	} /* switch */

} /* setmode */

/**********************************************/

FullScreenErase()

{   struct tutorColor fc,bc,wc;

	setmode(writemode);
	unclip();
	TUTORget_colors(&fc,&bc,&wc);
	TUTORset_color(1,(struct tutorColor FAR *)&wc);
	TUTORclear_screen();
	TUTORset_color(1,(struct tutorColor FAR *)&bc);
	setmode(exS.mode);
	setclip();
	exS.outcnt += 2;
	OUTGO;

} /* FullScreenErase */

/*********************************************/

arc(radius, angle1, angle2, unbroken)
Coord  radius;
double  angle1, angle2 ;     /* start, end angles in degrees */
int unbroken ;                 /* 1 = circle, 0 = circleb */
	{ double xyradius;
	
	xyradius = radius/65536.0;
	TUTORdraw_arc(1,exS.ScreenX,exS.ScreenY, xyradius, exS.ScreenX-radius, exS.ScreenY-radius,
		exS.ScreenX+radius, exS.ScreenY+radius, 
		angle1, angle2, unbroken); 

	if( angle1 != 0.0 || angle2 != 360.0 )
		{/* an arc, set current screen position to end of arc */
		exS.ScreenX = exS.ScreenX + MulCoord(radius,FloatToCoord(cos(angle2*RDN)));
		exS.ScreenY = exS.ScreenY + MulCoord(radius,FloatToCoord(sin(angle2*RDN)));
		}
	}


/***************   makebox   **************************/

makebox(tgiven, x1,y1,x2,y2,thick)
/* expects fine coordinates */
/* ScreenX, ScreenY on completion are first point mentioned */
Coord x1,y1, x2,y2;
int thick;
int tgiven;  /* TRUE if thickness given specifically */
	{
	Coord thickC;

	exS.ScreenX = x1;
	exS.ScreenY = y1;
	
	/* is thick large enough to fill entire box? */
	if (thick < 0) 
		{
		if (-thick > abs(RoundCoord(x1-x2)+1)/2 || -thick > abs(RoundCoord(y1-y2)+1)/2)
			{
			TUTORfill_rectangle(x1,y1, x2, y2); 
            return (0);
			}
		}

	if (tgiven)
		{
		thickC = IntToCoord(thick);
		TUTORthick_box(x1, y1, x2, y2, thickC, thickC, thickC) ;
		}
	else
		TUTORdraw_rectangle(x1, y1, x2, y2) ;
	
	return(0);
	}

/*****************  makevector  *************************/

makevector(xtail0,ytail0, xpoint0,ypoint0, type) 
 /* expects fine coords */
 Coord xtail0, ytail0, xpoint0, ypoint0;
 double type ;
{int closed ;
  double x1, x2, y1, y2;    /* corners of vector head */
  double dxm, dym ;       /* intersection of shaft with filled head */
  double alpha, beta ;
  double vhead, vlength, headedge ;
  Coord  fx[4], fy[4] ;
  double xtail, ytail, xpoint, ypoint;

if( xtail0==xpoint0 && ytail0==ypoint0) return (0);  /* 0-length */

exS.ScreenX = xpoint0;
exS.ScreenY = ypoint0;

/* work should all be done in Coord rather than double, but this code is too messy to convert (KSW) */

xtail = CoordToFloat(xtail0);
ytail = CoordToFloat(ytail0);
xpoint = CoordToFloat(xpoint0);
ypoint = CoordToFloat(ypoint0);
   
beta = atan2( (ypoint-ytail)/CoordToFloat(exS.yfudge), xpoint-xtail ) ;      /* angle of vector */
vlength =sqrt( (ypoint-ytail)*(ypoint-ytail) + (xpoint-xtail)*(xpoint-xtail) ) ;

/* select type of arrowhead to display */
if (type >= 0)       /* closed vectorhead  */
    {closed = 1 ;  
      alpha = VectorClosedANGLE*RDN ;   /* spread of vectorhead */
    }
else                    /* open vectorhead */
  {closed = 0 ; 
    alpha = VectorOpenANGLE*RDN ;
    type = -type ;       /* having set "closed", make type positive */
  }

 /* set vectorhead size */
 if( type == 0) { /* default */  
 	if (vlength <= (2*VectorHEAD)) {
 		type = 0.5;
 		vhead = vlength*type; /* proportional */
 	} else vhead = VectorHEAD;
 } else if ( type >= 1)  vhead = type     ;            /* size in screen units */
 else                        vhead = vlength* type ;  /* proportional */

/* find corners of vectorhead */
headedge = vhead / cos(alpha) ;
x1 = xpoint - headedge * cos(beta -alpha) ;
y1 = ypoint - headedge * sin(beta -alpha)*CoordToFloat(exS.yfudge);  
x2 = xpoint - headedge * cos(beta+alpha) ;
y2 = ypoint - headedge * sin(beta+alpha)*CoordToFloat(exS.yfudge);

if (closed == 0 ) 		/* draw open vector */
  {TUTORmove_to(FloatToCoord(xtail),FloatToCoord(ytail) );           /* draw shaft:  tail */
    TUTORend_line(FloatToCoord(xpoint),FloatToCoord(ypoint) );     /* head */
    TUTORmove_to(FloatToCoord(x1), FloatToCoord(y1) );              /* draw arms */
    TUTORline_to( FloatToCoord(xpoint), FloatToCoord(ypoint)); 
    TUTORend_line( FloatToCoord(x2),FloatToCoord(y2));  
   }

if (closed == 1)   		/* draw closed vector */
     {/* find point where vector intersects head */
       if( xtail == xpoint )    /* vertical vector */
              { dym = y1;  dxm = xtail; }
       else if( ytail == ypoint )      /* horizontal vector */
              { dym = ytail;  dxm = x1; }
       else
              {dym = -(xtail-xpoint)*(y1-y2) + (ytail-ypoint)*(x1-x2) ;
                dym = ((ytail-ypoint)*(x1*y2 - x2*y1) - (xtail*ypoint - xpoint*ytail)*(y1-y2)) / dym ;
                dxm = ((x1-x2)*dym - (x1*y2 - x2*y1)) / (y1-y2) ; 
               }

      TUTORmove_to( FloatToCoord(xtail),FloatToCoord(ytail) );          /* tail */
      TUTORend_line( FloatToCoord(dxm),FloatToCoord(dym));            /* intersection */

 /**  if in xormode, there is a white dot left at the intersection of the line and the fill area.  I don't know how to deal with this in a reasonably way and still keep all the Andrew stuff in tgraph.be1.c  **/

       fx[1] = FloatToCoord(xpoint);    fy[1] = FloatToCoord(ypoint);       /* prepare for area fill */
       fx[2] = FloatToCoord(x1);         fy[2] = FloatToCoord(y1);
       fx[3] = FloatToCoord(x2);         fy[3] = FloatToCoord(y2);
       TUTORfill_polygon(3, fx, fy) ;
     }

 }
