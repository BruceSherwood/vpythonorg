
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "ctutor.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "exprdefs.h"
#include "yacc.h"
#include "ct_ctype.h"

#ifdef ctproto
int  InitParse(void);
int  Parse1Line(void);
int  MidCompile(int  cmdN);
int  StripLineStart(unsigned char  * *cpp,int  oldCmd,int  *nIndent);
extern int  DetermineCommand(unsigned char  * *cpp,unsigned char  *repeatC,int  foundIndent,int  *nIndent,int  oldCmd);
extern int  RepeatCommand(int  oldCmd);
extern int  IsLegalConditional(int  cmdN);
extern int  RealCondTag(int  cmdN,unsigned char  *startP,unsigned char  *endP);
int  StripTrailingComment(int  cIndex,int  cmdN);
extern int  CompileIndent(int  cmdN);
extern int  PushIndentStack(int  iKind);
extern int  PopIndentStack(int  iKind);
extern int  CheckIndentStack(void);
extern int  FindPhysIndent(int  delIndent);
int  FindBreakIndent(int  fKind);
extern int  FindPreviousCase(void);
int  StartCondTable(void);
extern int  AddCondTable(void);
int  cerror(int  errnumber,char  *execstr);
int  _TUTORinq_state_internal_marker(int  ind,long  *pos,long  *len,int  *altered);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  FillBuffer(unsigned int  readDoc,long  readPos,long  maxRead);
int  cmpbuf_word(int  n);
int  add_dest(int  type,int  label,unsigned int  pos);
int  cmpbuf_xref(int  kind,int  label);
int  compile1(void);
int  getcmd2(char  *inps);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
#endif /* ctproto */


/* general variables */

int oldCmnd; /* last command encountered */
static int oldIndent; /* current indentation level */
static int delIndent; /* change of current indent from oldIndent */

static int condCmd; /* conditional command being compiled */
static short nCase; /* # of case commands currently active */
static short caseLevel; /* physical indent level of most recent case */

static char srcPosComm; /* TRUE if next srcPos actually inside comment of previous line */
static char condContin; /* TRUE if conditional command can be continued (set in RepeatCommand) */
static char condCompiled; /* TRUE if we have really compiled the most recent conditional */

/* ******************************************************************* */

InitParse() /* initialize variables at start of unit compile */
    
{
	oldCmnd = CMDERR;
        continFlag = FALSE;
        condFlag = 0;
        condCmd = CMDERR;
        delIndent = 0; /* no change from "previous" indent */
        /* that has to be here or error check in CompileIndent fails... */
        indentlevel = -1; /* so Push makes it 0 */
        PushIndentStack(nonekind); /* 0th indent is nothing */
        nCase = 0;
        FillBuffer(0,0L,0L); /* initialize document buffer */
        srcPosComm = FALSE;
        MidCompile(UNITSTART);

} /* InitParse */

/* ******************************************************************* */


int Parse1Line() /* read & process 1 line of input */
/* returns TRUE if there is more to read */
    {
    register unsigned char *cP; /* general use fast pointer */
    unsigned char *c1, *c2; /* general use pointers */
    unsigned char cc;
    unsigned char repeatC; /* TRUE if cmdN set via repeat */
    int cmdN; /* command we will compile */
    int startIndent;
    int nIndent; /* # of indents on this line */
    int tagCount; /* # of conditional tags (other than selector expression) on this line */
    int sls; /* return from StripLineStart */
    int ii;
    long tempPos;
    int arrowlabel; /* internal label at head of arrow */

    /********************** get input into buffer */
    
    if (srcPosComm)
        { /* srcPos is in comment which overflowed last buffer.  We need to fill buffer,
           find end of comment (NEWLINE) and set srcPos to begin of next line so
           the usual read will work */
        buffFull = TRUE;
        while (buffFull)
            { /* keep reading till get a newline in buffer */
            FillBuffer(source,srcPos,srcEnd-srcPos);
            srcPos += nBuffChars;
            if (nBuffChars == 0)
                break; /* out of input */
            }
        /* now srcPos is at begin of next line */
        }
        
    startofline = srcPos;
    FillBuffer(source,srcPos,srcEnd-srcPos);
    srcPos += nBuffChars; /* srcPos at begin of next line (unless buffer overflow) */

    /* build table mapping source to binary */

    if (srbimapH) {
        ii = unittab[compunit].nmap;
        if (ii >= srbimapL) {
            srbimapL += 50; /* expand table */
            ReleasePtr(srbimapH); /* allow memory move */
            KillPtr(srbimapP);
            TUTORset_hsize(srbimapH,(long)(srbimapL*sizeof(struct srbimap)),TRUE);
            srbimapP = (struct srbimap FAR *)GetPtr(srbimapH);
        }
        _TUTORinq_state_internal_marker(unittab[compunit].marki,&tempPos,NEARNULL,NEARNULL);
        (srbimapP+ii)->srcr = startofline - tempPos;
        (srbimapP+ii)->binr = cmpl;
        unittab[compunit].nmap++;
    }

    if (nBuffChars == 0)
        { /* out of input */
        if (condFlag) {
            if (condCmd == C_TEXT || condCmd == C_RTEXT || condCmd == C_GTEXT ||
                    condCmd == C_STRING) {
                /* -text- conditional not finished properly */
                cI = 0;
                cerror(BADTEXT,"Conditional -text- must end with two backslashes.");
            } else {
                if (condCmd == C_WRITE && condCompiled) {
                    MidCompile(C_ENDTEXT); /* finish -write- command */
		    oldCmnd = -1; /* suppress C_ENDTEXT */
                }
                MidCompile(C_CONDDONE); /* finish conditional */
            }
        }
	if (oldCmnd == C_DEFINE || oldCmnd == C_UNIT)
            MidCompile(C_DEFINEEND);
	else if (oldCmnd == C_WRITE)
            MidCompile(C_ENDTEXT);
        return(FALSE);
        }
    
    /********************** check line begin (comment lines & indents) */

    c2 = cB; /* set to begin of compile buffer */
    sls = StripLineStart(&c2, oldCmnd,&startIndent);
    if (!sls)
        return(TRUE); /* no compilation for this line, we're done */
    cP = c2; /* positioned after indents */

    /* special case for TEXT commands */
    if (oldCmnd == C_TEXT || oldCmnd == C_GTEXT || oldCmnd == C_RTEXT || oldCmnd == C_STRING)
        {
	oldCmnd = CMDERR; /* so won't do end of -text- processing next call */
        /* this also means that TEXT commands can't be repeated */

        cP = cB; /* to begin of compile buffer */
        if (*cP != '\\')
            return(FALSE); /* shouldn't get here, compiler should handle error */
        if (condFlag && *(cP+1) == '\\')
            { /* conditional ended */
            MidCompile(C_CONDDONE);
            condFlag = 0;
	    oldCmnd = CMDERR; /* can't repeat command from conditional */
            cP++; /* advance to second \ (now looks like end of normal TEXT) */
            }
        StripTrailingComment(cP-cB,C_TEXT);
        if (!condFlag)
            { /* normal text */
            if (*(cP+1) != NEWLINE)
                { /* rest of line should have been comment and wasn't */
                cI = (cP+1) - cB;
                cerror(SPECIFICERR,"Extra characters on -text- terminator line");
                return(FALSE);
                }
            else
                return(TRUE); /* finished -text- conclusion */
            }
        /* otherwise we are looking at another tag to a conditional TEXT */
        }

    /********************** special handling for end of conditional */

    if (condFlag &&
!(condCmd == C_TEXT || condCmd == C_GTEXT || condCmd == C_RTEXT || condCmd == C_STRING) &&
 ((!condContin && *cP != '\\') || (condContin && startIndent <= oldIndent)))
        { /* conditional ended (for TEXT, done above) */
        if (condcount == 0)
            { /* conditional command ended without any clauses */
            cI = cP - cB;
            cerror(SPECIFICERR,"The preceeding conditional command has no arguments.");
            return(FALSE);
            }
        if (condCmd == C_WRITE && condCompiled) {
            MidCompile(C_ENDTEXT); /* finish -write- */
        }
        MidCompile(C_CONDDONE);
        condFlag = 0;
	oldCmnd = CMDERR; /* can't repeat command from conditional */
        }
    
    /********************** determine the command */
    if (!condFlag)
        { /* normal case */
        c1 = c2 = cP; /* points to beginning of command */
	cmdN = DetermineCommand(&c2,&repeatC,startIndent, &nIndent, oldCmnd);
        cP = c2; /* now points to character following command */
        
        delIndent = nIndent - oldIndent;
        if (delIndent > 0)
            { /* commands can't be too far right */
            cI = cP - cB;
            cerror(SPECIFICERR,"Too many indents.");
            return(FALSE);
            }
        
        /* check for end of -define- or -write- */
            
	if ((oldCmnd == C_DEFINE || oldCmnd == C_UNIT) && (cmdN != C_DEFINE))
            MidCompile(C_DEFINEEND); /* end of definitions */
	else if ((oldCmnd == C_WRITE) && (!continFlag))
            MidCompile(C_ENDTEXT); /* end of -write- statement */
            
        /* special case of ending an answer command */
        if (delIndent < 0 && anskind == CheckIndentStack() &&
                (cmdN != C_OUTLOOP && cmdN != C_RELOOP && cmdN != C_OUTIF && cmdN != C_OUTCASE))
            {  /* answer blocks ended */
            while (delIndent < 0 && anskind == CheckIndentStack())
                MidCompile(C_ENDANS);
            }

        if (nCase && nIndent == caseLevel && cmdN != C_ELSE &&
                 cmdN != C_ENDCASE && cmdN != C_OUTCASE)
            { /* this must really be a case expression */
            cmdN = C_CLAUSE;
            if (delIndent == -1)
                MidCompile(C_ENDCLAUSE); /* finish previous clause */
            cP = c1; /* restore pointer to begin of command */
                /* so that command becomes tag (expression) */
            }

        if (cmdN == C_CASE)
            { /* activate new level of cases */
            nCase++;
            caseLevel = nIndent;
            }
        else if (cmdN == C_ENDCASE)
            { /* get rid of most recent level of cases */
            nCase--;
            if (nCase)
                caseLevel = FindPreviousCase();
            }

        if (cmdN == CMDERR)
            { /* can't determine command some indeterminable command - error */
            cI = cP - cB;
            cerror(BADCOMMAND,NEARNULL);
            return(FALSE);
            }
	if (oldCmnd == C_CASE && cmdN != C_CLAUSE)
            {
            cI = c1 - cB; /* index to beginning of command */
            cerror(SPECIFICERR,"No commands allowed immediately after -case-.");
            return(FALSE);
            }

	oldCmnd = cmdN;
        
        /* special case of ending indented commands after -arrow- */
        if (delIndent == -1 && PopIndentStack(arrow0kind)) {
            /* post-arrow indented commands ended */
            /* this really should be a psuedo-command compiled now... */
            /* indentlevel should now be referring to the current -arrow- structure */
            delIndent = 0;

            /* compile end of post-arrow indents */

            add_dest(RD_ARROW,labelID++,cmpl);
            cmpbuf_word(C_ARROW1); /* end-post-arrow */
            indent[indentlevel].headloc = cmpl;
            /* forward reference to ifmatch */
            indent[indentlevel].nextlabel = arrowlabel = labelID;
            indent[indentlevel].endlabel = arrowlabel+1;
            indent[indentlevel].headref = cmpbuf_xref(R_ARROW1,arrowlabel); 
            labelID += 2; /* reserve label for endarrow also */
            /* forward reference to endarrow */
            cmpbuf_xref(R_ARROW2,arrowlabel+1); 
            add_dest(RD_ARROW,labelID++,cmpl);
            cmpbuf_word(C_ARROW2); /* add wait-for-input command */
            add_dest(RD_ARROW,labelID++,cmpl);
            cmpbuf_word(C_ARROW3);
            /* indicates post-arrow indent code complete */
            indent[indentlevel].lastif = 1; 
        }

        /* remove trailing comments */
        StripTrailingComment(cP-cB,cmdN);

        /* special case for non-conditional blank-tag command */
        if (*cP == NEWLINE)
            { /* blank tag command, no more processing needed */
            cI = cP - cB;
            MidCompile(cmdN);
            return(TRUE);
            }
        
        if (!repeatC && cmdN != C_CLAUSE && cmdN != ENVIC)
            {
            if (*cP != '\t')
                {
                cI = cP - cB;
                cerror(SPECIFICERR,"Command must be followed by tab.");
                return(FALSE);
                }
            cP++; /* skip over tab that follows explicit command name */
            }
        }
    else
        { /* working on conditional */
        if (condCmd == C_TEXT || condCmd == C_GTEXT || 
            condCmd == C_RTEXT || condCmd == C_STRING)
	    { /* oldCmnd set to CMDERR above (in \ processing), fix it */
	    oldCmnd = condCmd;
            cmdN = condCmd; /* just to be sure */
            }
        else
            { /* "normal" conditional */
            if (oldIndent+1 != startIndent)
                { /* incorrectly formed conditional tag */
                /* note that oldIndent <= startIndent (end of conditional) case is handled above */
                cI = cP - cB;
                cerror(SPECIFICERR,"Bad conditional tag");
                return(FALSE);
                }
            if (*cP == '\\')
                cmdN = condCmd; /* new conditional tag */
            else
                { /* if this is continuable command ok, else error */
                cmdN = RepeatCommand(condCmd);
                if (cmdN != condCmd || !continFlag)
                    { /* this is an error */
                    cI = cP - cB;
                    cerror(SPECIFICERR,"bad conditional tag");
                    return(FALSE);
                    }
                /* otherwise continuable command ok (note cmdN & continFlag properly set now) */
                }
            delIndent = 0; /* no indentation changes inside conditional */
            }
        }

    /********************** special handling for some non-conditional situations */
    
    if (!condFlag && *cP == '\\' && !continFlag)
        { /* attempt start of conditional command */
        if (!IsLegalConditional(cmdN))
            {
            cI = cP - cB;
            cerror(SPECIFICERR,"This command cannot be made conditional.");
            return(FALSE);
            }
        condFlag = 1; /* begin of conditional */
        RepeatCommand(cmdN); /* to set condContin flag */
        continFlag = 0;  /* can't continue into conditional */
        }

    if (!condFlag && cmdN == C_WRITE && buffFull)
        { /* long WRITE requires special handling */
        /* WRITEs in conditionals handled below */
        cI = cP - cB; /* buffer index refers to begin of tag */
        MidCompile(cmdN);
        return(TRUE);
        }
    
    /* check for buffer overflow */
    if ((!condFlag && buffFull) &&
          !(cmdN == C_DRAW || cmdN == C_RDRAW || cmdN == C_GDRAW || cmdN == C_DOT))
        { /* filled buffer on single-tag line, command not allowed to continue */
        cI = srcPos - startofline; /* to get whole line */
        cerror(SPECIFICERR,"Line too long");
        return(FALSE);
        }
    
    /********************** process tag */

    /* tag begins (with tab) at where cP is now */

    if (condFlag)
        { /* conditional command tag */
        if (condFlag == 1)
            { /* begin of conditional */
            /* look for end of expression (\ or end of line) */
            cP++; /* get past \ */
            c2 = cP;
            while (*cP != NEWLINE && *cP != '\\') cP++;
            cc = *cP;
            if (cc == NEWLINE)
                { /* had only selector on first line */
                if (cmdN == C_TEXT || cmdN == C_RTEXT || 
                        cmdN == C_GTEXT || cmdN == C_STRING)
                    { /* \ for first case of -text- MUST be on first line */
                    cI = cP - cB;
                    cerror(SPECIFICERR,"Incorrect -text- conditional");
                    return(FALSE);
                    }
                StripTrailingComment(c2-cB,cmdN);
                }
            else
                *cP = NEWLINE; /* to compile expression */
            cI = c2 - cB; /* make index refer to begin of tag */
            condCmd = cmdN; /* has to be set before MidCompile for PREANS... */
            MidCompile(C_COND);
            if (cc == '\\')
                *cP = '\\'; /* restore for further processing (not really end of line) */
            condFlag = 2; /* have compiled expression */
            condcount = 0; /* total # of tags of this conditional */
            condCompiled = FALSE; /* haven't compiled anything yet */
            }
        else
            { /* another line of conditional tags */
            cc = *cP;
            if (condFlag == 3 && !continFlag)
                {
                if (cmdN == C_WRITE && condCompiled)
                    MidCompile(C_ENDTEXT);
                MidCompile(C_CONDEND); /* to terminate previous tag */
                }
            }
        
        tagCount = 0; /* # of tags this line.  Used only for TEXT-type */
        while (cc != NEWLINE)
            { /* keep compiling tags on this line */
            /* find next end */
            condFlag = 3; /* working on tags */
            condCompiled = FALSE; /* working on new tag, haven't compiled it yet */
            c1 = cP; /* to restore cP in case of buffer overflow handling (below) */
            if (cc == '\\')
                {
                cP++; /* get past \ */
                condcount++; /* we have another clause */
                tagCount++;
                }
            c2 = cP; /* begin of tag */
            while (*cP != NEWLINE && *cP != '\\') cP++;
            cc = *cP;
            if (cc == NEWLINE)
                { /* end of buffer */
                if (buffFull)
                    { /* ran out of line because ran thru buffer, need to read more before
                        processing this tag.  Reset srcPos and clean up.  tag will
                        be proccessed on next call of routine */
                    srcPos = startofline + c1-cB;
                    MidCompile(C_CONDEND); /* to end previous tag */
                    return(TRUE);
                    }
                /* otherwise it was the end of the line */
                StripTrailingComment(c2-cB,cmdN);
                }
            else
                {
                if ((cmdN == C_TEXT || cmdN == C_RTEXT || 
    cmdN == C_GTEXT || cmdN == C_STRING) && tagCount)
                    { /* only one tag per line for conditional -text- */
                    cI = cP - cB;
                    cerror(SPECIFICERR,"More than one -text- tag in conditional line");
                    return(FALSE);
                    }
                *cP = NEWLINE; /* make the \ a newline for compilation */
                }
            if (!continFlag)
                { /* new command, put its location in table */
                AddCondTable();
                }
            if (RealCondTag(cmdN,c2,cP))
                {
                cI = c2 - cB; /* buffer index refers to begin of tag */
                MidCompile(cmdN); /* compile command */
                condCompiled = TRUE;
                }
            if (cc == '\\')
                { /* will have another tag on this line */
                if (cmdN == C_WRITE && condCompiled) 
                    MidCompile(C_ENDTEXT);
                MidCompile(C_CONDEND);
                *cP = '\\'; /* restore (not really end of line) */
                }
            continFlag = FALSE; /* may be set to TRUE when we start next line */
            }
        }
    else
        { /* not conditional (THIS IS THE NORMAL CASE) */
        cI = cP - cB; /* set buffer index to refer to tag begin */
        MidCompile(cmdN);
        }
    
    return(TRUE);
} /* Parse1Line */
 
MidCompile(cmdN) /* mid-level work, mostly indentation */
int cmdN;
    {
    int testCmd;
    int myCiStart;

    startcommand = cmpl; /* length of pcode */
    CompileIndent(cmdN);

    /* take care of PREANS command for some answer commands */
    /* note that care must be taken in case of a conditional answer.  The PREANS command must
    preceed the C_COND command! (and not get done for each conditional tag) */

    testCmd = cmdN;
    if (cmdN == C_COND)
        testCmd = condCmd;  /* want to check real command */
    else if (condFlag)
        testCmd = CMDERR; /* so don't redo PREANS... */
    switch(testCmd)
        { /* answer commands need a pre-command compiled in */
        
        case C_OKCMD:
        case C_NOCMD:
        case C_ANSWER:
        case C_WRONG:
        case C_EXACT:
        case C_EXACTW:
        case C_ANSV:
        case C_WRONGV:
            add_dest(RD_PREANS,labelID++,cmpl);
            MidCompile(C_PREANS); /* PREANS checks indent, etc. */
            startcommand = cmpl; /* start of real command */
            break;
        default:
            break;
        }

    /* compile commands */

    addcmd = newcmd = cmdN; /* tell compiler the command */
    oldcmd = newcmd; /* command as handed to compiler */
    refillBuff = FALSE;
    compile1();
    if (addcmd > 0)
        cmpbuf_word(addcmd); /* add command after tags */
    if ((cmdN == C_DRAW || cmdN == C_RDRAW || cmdN == C_GDRAW || cmdN == C_DOT) &&
            refillBuff)
        { /* command continued over buffer boundary */
        while (refillBuff)
            { /* continuing compile for allowably long commands */
            /* refill buffer */
            srcPos = startofline + cI - ciStart;
            myCiStart = ciStart - cI; /* "real" ciStart */
            FillBuffer(source,srcPos,srcEnd-srcPos);
            ciStart = myCiStart; /* restore ciStart */
            cI = 0; /* to point at first char of next tag */
            StripTrailingComment(0,cmdN);
             /* set srcPos to begin of next line (unless buffer overflow) */    
            srcPos += nBuffChars;
            /* make sure compiler is happy */
            oldcmd = newcmd = addcmd = cmdN;
            refillBuff = FALSE;
            continFlag = TRUE;
            startcommand = cmpl;
            compile1();
            if (addcmd > 0)
                    cmpbuf_word(addcmd); 
            }
        }
    lastcmd = newcmd; /* command as finished by compiler */

#ifdef KSWnotyet
    /* make sure complete tag was used */
    /* unfortunately, we can't be sure whether cI is left AT the NEWLINE (as it is direct from MidCompile)
       or 1 AFTER the NEWLINE (as it would be after the expression compiler is used) */

    if (cB[cI] != NEWLINE && cB[cI] - 1 != NEWLINE)
        cerror(BADTAG,NEARNULL);
#endif

    return(0);
    }

#ifdef KSWTRACE
static TraceCompile(cmdN,nIndent)
int cmdN;
int nIndent;
/* returns TRUE if command has tag */
    {
    char FAR *cmdname();
    char *cName;
    char hasTag;
    short ii;
    char *tagP, *cEnd;

    hasTag = TRUE; /* most commands expect a tag */
    switch (cmdN)
        {
        case C_COND:
            cName = "Condstart"; hasTag = TRUE; break;
        case C_CONDEND:
            cName = "Condend"; hasTag = FALSE; break;
        case C_CONDDONE:
            cName = "Conddone"; hasTag=FALSE; break;
        case C_CLAUSE:
            cName = "Caseexpr"; hasTag = TRUE; break;
        case C_ENDCLAUSE:
            cName = "Case1done"; hasTag = FALSE; break;
        case UNITSTART:
            TUTORtrace("----------------------\n");
            cName = "Unitstart";
            hasTag = FALSE;
            break;
        case UNITEND:
            cName = "Unitend"; hasTag = FALSE; break;
        case C_ENDANS:
            cName = "Endanswer"; hasTag = FALSE; break;
        case C_DEFINEEND:
            cName = "Enddefine"; hasTag = FALSE; break;
        default:
	    cName = strf2n(cmdname(cmdN));
            hasTag = TRUE;
            break;
        }
    for (ii=0; ii<nIndent; ii++)
#ifdef MAC
        ShowSTrace("\p."); /* show indentations with periods */
    ShowCTrace(cName); /* command name */
#else
        printf(".");
    printf("%s",cName);
#endif

    if (hasTag && cB[cI] == NEWLINE)
        hasTag = FALSE; /* don't really have tag */

    if (hasTag)
        {
        /* find \n and convert to \0 for printing */
        tagP = cEnd = cB+cI;
        while (*cEnd != NEWLINE) cEnd++;
        *cEnd = '\0';
#ifdef MAC
        ShowSTrace(continFlag ? "\p& " : "\p ");
        ShowCTrace(tagP);
#else
        printf("%s%s\n",(continFlag ? "& " : " "),tagP);
#endif
        *cEnd = NEWLINE; /* convert back, to be sure */
        }
    else
#ifdef MAC
        ShowSTrace(continFlag ? "\p&" : "\p");
#else
        printf(continFlag ? "&\n" : "\n");
#endif
    return(hasTag);
    }
#endif

StripLineStart(cpp, oldCmd,nIndent) /* count # of indentations, check for simple comment */
unsigned char **cpp; /* points to begin of line, will be set to point after indentations */
int oldCmd; /* previous command */
int *nIndent; /* to be set to # of indents found */
/* returns FALSE if whole line is comment */
    {
    register unsigned char *cP; /* points to begin of line */
    int maxIndent;

    if (oldCmd == C_TEXT || oldCmd == C_RTEXT || oldCmd == C_GTEXT || oldCmd == C_STRING)
        { /* TEXT-type commands.  We should be at \ in column 0 */
        /* this is handled in caller */
        *nIndent = 0;
        return(TRUE); /* so that line is processed */
        }

    if (**cpp == '*')
        return(FALSE); /* no matter what else, * in first column is comment */

    /* for WRITE, we never allow nIndent to exceed oldIndent+1 */
    maxIndent = (oldCmd == C_WRITE) ? oldIndent+1 : 1000;
    cP = *cpp;
    *nIndent = 0;
    while (*cP != NEWLINE && *nIndent < maxIndent)
        {
        if (*cP == '\t')
            { /* simple indent */
            cP++;
            (*nIndent)++;
            }
        else if (*cP == '.')
            {
            while (*(cP+1) == ' ')
                cP++; /* skip spaces */
            if (*(cP+1) == '\t')
                { /* .tab indent */
                cP += 2;
                (*nIndent)++;
                }
            else if (*(cP+1) == NEWLINE)
                { /* last period can be indent all by itself */
                cP++;
                (*nIndent)++;
                }
            else
                break; /* a period, not an indent */
            }
        else if (*cP == ' ')
            cP++; /* ignore spaces */
        else
            break; /* not indent */
        }
    *cpp = cP;

    if (*cP == NEWLINE || *cP == '*' || (*cP == '$' && *(cP+1) == '$'))
        { /* looks like simple comment - a blank line */
        if (oldCmd != C_WRITE)
            return(FALSE); /* it definitely is a comment */
        /* else, this must be a continued WRITE */
        if (*nIndent <= oldIndent)
            { /* this is just a carriage return line */
            /* do compile right here, so as not to confuse the rest of parser */
            /* make cB[cI] = NEWLINE so compiler regards this as blank line */
            cI = 0;
            cB[0] = NEWLINE;
            continFlag = TRUE; /* this is a continued command */
            MidCompile(C_WRITE);
            return(FALSE); /* so rest of parser doesn't do anything */
            }
        }

    return(TRUE); /* not a comment */
    }

static DetermineCommand(cpp,repeatC,foundIndent,nIndent,oldCmd)
/* returns command (or CMDERR if can't determine) */
unsigned char **cpp;
unsigned char *repeatC;
int foundIndent, *nIndent;
int oldCmd;

{   register unsigned char *cP;
    int cmdN;
    unsigned char commandS[20]; /* to hold command name for getcmd2 */
    int nComm; /* # of chars in command name */
    
    cP = *cpp;  
    /* depending on state, indentation may determine command */
    cmdN = CMDERR; /* command not yet determined */
    *repeatC = FALSE;
    continFlag = FALSE;
    /* repeat if we are indented 1 more than the current indentation (usually set by last line) */
    if (foundIndent == oldIndent + 1) { /* repeated command via indent */
        cmdN = RepeatCommand(oldCmd);
        if (cmdN != CMDERR) {
            *nIndent = oldIndent; /* repeated command, no extra indentation */
            *repeatC = TRUE;
        }
    }

    /* otherwise determine command by looking at line after tabs */
    if (cmdN == CMDERR) { /* need to get command */
        /* NOTE: spaces ANYWHERE in command are ignored */
        *nIndent = foundIndent; /* save indentation */
        while (*cP == ' ') cP++; /* skip leading spaces */
        nComm = 0;
        while ((CTisalpha(*cP) || *cP == ' ' || ((*cP == '$') && (*(cP+1) != '$'))) && nComm < 18){
            if (*cP != ' ')
                commandS[nComm++] = *cP;
            cP++;
        }
        if (nComm < 18) { /* legitimate length for command */
            commandS[nComm] = '\0';
            cmdN = getcmd2((char *) commandS);
        }
        /* otherwise command is still CMDERR (because too long) */
    } /* cmdN if */

    /* cP is pointing at char immediately following command field */
    *cpp = cP;
    
    return(cmdN);

} /* DetermineCommand */

static RepeatCommand(oldCmd)
int oldCmd; /* the previous command */
/* returns the new command, or CMDERR if can't repeat oldCmd */
/* as a side effect, may set continFlag */
    {
    condContin = FALSE; /* default */
    
    /* This routine is used for two different purposes.
        1) To find out the command to use when some old command is repeated
        2) To set the condContin flag.
    Both purposes use the same "table" (the critical information is which commands
    repeat as continuations) so they both call this routine */
    
    switch(oldCmd)
        {
        /* commands that repeat as different commands */
        case C_UNIT:
            return(C_DEFINE);
        
        /* commands that repeat as continuations */

        case C_WRITE:
        case C_DRAW:
        case C_GDRAW:
        case C_RDRAW:
        case C_FILL:
        case C_GFILL:
        case C_RFILL:
        case C_DOT:
        case C_RDOT:
        case C_GDOT:
        case C_ERASE:
        case C_GERASE:
        case C_RERASE:
        case C_AT:
        case C_GAT:
        case C_RAT:
		case C_EDIT:
		case C_REDIT:
		case C_GEDIT:
		case C_EDITR:
		case C_REDITR:
		case C_GEDITR:
		case C_TOUCH:
		case C_RTOUCH:
		case C_GTOUCH:
		case C_VIDEO:
		case C_VSET:
        /* case BEEP: -- ought to but compiler doesn't handle it */
        case C_SET:
            condContin = TRUE;
            continFlag = TRUE;
            return(oldCmd);
        case C_PALETTE:
        case C_NEWPAL:
            /* usually repeats.  But not blank tag -newpal- or array type for either */
            if (lastcmd == -1)
                return(CMDERR);
            continFlag = TRUE;
            return(oldCmd);
            break;
        
        /* commands that just repeat */
        case C_DEFINE:
        case C_RGB:
        case C_HSV:
        case C_CALC:
            return(oldCmd);

        /* everything else doesn't repeat */
        default:
            return(CMDERR);
        }
    }

static IsLegalConditional(cmdN)
int cmdN; /* the command */
/* returns TRUE if command is legal conditional */
    {
    switch(cmdN) /* check that this is legal conditional */
        {
        case C_UNIT:
        case C_DEFINE:
        case C_IF:
        case C_ELSEIF:
        case C_ELSE:
        case C_ENDIF:
        case C_LOOP:
        case C_ENDLOOP:
        case C_CASE:
        case C_ENDCASE:
        case C_ARROW:
        case C_RARROW:
        case C_GARROW:
        case C_ENDARROW:
        case C_IFMATCH:
        case C_PALETTE:
        case C_NEWPAL:
		case C_EDIT:
		case C_REDIT:
		case C_GEDIT:
/*		case C_BUTTON:
		case C_RBUTTON:
		case C_GBUTTON:
		case C_SLIDER:
		case C_RSLIDER:
		case C_GSLIDER:
		case C_TOUCH:
		case C_RTOUCH:
		case C_GTOUCH: */
		case C_VIDEO:
		case C_VSET:
            return(FALSE);
        default:
            return(TRUE);
        }
    }

static RealCondTag(cmdN,startP,endP)
int cmdN; /* command we are working on */
unsigned char *startP, *endP; /* bounds of conditional tag */
/* returns TRUE if this is compilable tag, FALSE if blank-tag */
    
{
    /* check for no tag at all (can happen with TEXT-type commands) */
    if (*startP == NEWLINE &&
		(cmdN == C_TEXT || cmdN == C_GTEXT || cmdN == C_RTEXT || 
		cmdN == C_WRITE ||cmdN == C_STRING))
        return(TRUE);

	if (cmdN == C_JUMPOUT)
		return(TRUE); /* blank tag = q */
    if (endP == startP)
        return(FALSE); /* had \\ following */

    /* otherwise, see if tag only white space */

    /* but if command takes literal text, that would be ok */
    if (cmdN == C_WRITE || cmdN == C_EXACT || cmdN == C_EXACTW)
        return(TRUE);

    while (startP < endP)
        {
        if (*startP != ' ' && *startP != '\t')
            break;
        startP++;
        }

    return((startP < endP) ? TRUE : FALSE);

} /* RealCondTag */

/* ******************************************************************* */

StripTrailingComment(cIndex,cmdN)
int cIndex; /* index to start scan for $$ comment (cB[cIndex] should be outside quote marks) */
int cmdN; /* command of this line */
    {
    register unsigned char *cP; /* points where scan should start for $$ comment */
    char inQuote; /* keep track if chars are in quotation */
    register unsigned char *cpOld;

    cP = cB+cIndex;
    inQuote = 0;
    cpOld = cP; /* original cP */

    /* strip blanks  && comments on end */
    /* scan forward till find $$ */
    while (*cP && *cP != NEWLINE)
        {
        if (*cP == '"')
            inQuote = 1 - inQuote; /* toggle inQuote */
        else if (*cP == '$' && *(cP+1) == '$' && !inQuote)
            break;
        cP++;
        }
    if (!*cP)
        return(0); /* overflowed buffer, don't do anything */

    /* now we either have comment (*cP == '$') or at end of line.  */

    /* for WRITE, EXACT and EXACTW we don't strip trailing white space, but
       we do take out the trailing $$ comment */
    if (cmdN == C_WRITE || cmdN == C_EXACT || cmdN == C_EXACTW)
        {
        *cP = NEWLINE;
        if (buffFull)
            { /* now as if buffer not full, but we don't know next srcPos */
            buffFull = FALSE;
            srcPosComm = TRUE;
            }
        return(0);
        }

    /* for other commands we want to strip white space trailing tag */
    /* strip white space backwards */
    cP--; /* back off end */
    /* don't backtrack over cpOld or -command-space$$ won't work */
    while ((*cP == ' ' || *cP == '\t') && cP >= cpOld)
        cP--;
    *(cP+1) = NEWLINE; /* strip line by putting newline earlier */

    if (buffFull)
        { /* now as if buffer not full, but we don't know next srcPos */
        buffFull = FALSE;
        srcPosComm = TRUE;
        }

    return(0);
    }

static CompileIndent(cmdN)
int cmdN; /* the command */
    {
    /* error case */
    if (delIndent > 0 || (delIndent < -1 && cmdN != C_OUTLOOP && 
             cmdN != C_RELOOP && cmdN != C_OUTIF
            && cmdN != C_OUTCASE && cmdN != C_ENDANS && cmdN != C_ENDTEXT))
        cerror(BADINDENT,NEARNULL); 

    /* at this point delIndent is 0 or -1 (except for OUTLOOP, RELOOP, OUTIF, OUTCASE) */
    switch(cmdN)
        {
        case C_ENDTEXT:
            break; /* ignore psuedo-command */
        case C_IF:
            if (delIndent != 0) cerror(BADINDENT,NEARNULL);
            PushIndentStack(ifkind);
            break;
        case C_ELSEIF:
            if (delIndent != -1) cerror(BADINDENT,NEARNULL);
            if (ifkind != CheckIndentStack())
                cerror(SPECIFICERR,"-elseif- not matching -if-");
            break;
        case C_ENDIF:
            if (delIndent != -1) cerror(BADINDENT,NEARNULL);  
            if (!PopIndentStack(ifkind))
                cerror(SPECIFICERR,"-endif- not matching -if-");
            break;
        case C_OUTIF:
            if (delIndent == 0)
                breaklevel = FindBreakIndent(ifkind); /* find most recent if */
            else
                breaklevel = FindPhysIndent(delIndent); /* find matching if */
            if (!breaklevel || indent[breaklevel].stype != ifkind)
                cerror(SPECIFICERR,"-outif- not matching -if-");
            break;
        case C_CASE:
            if (delIndent != 0)  cerror(BADINDENT,NEARNULL);
            PushIndentStack(casekind);
            break;
        case C_CLAUSE:
            if (delIndent == 0)
                { /* should be immediately following -case- */
                if (casekind != CheckIndentStack())
                    cerror(BADINDENT,NEARNULL);
                PushIndentStack(caseexprkind);
                }
            else
                { /* delIndent == -1 */
                if (caseexprkind != CheckIndentStack())
                    cerror(BADINDENT,NEARNULL);
                }
            break;
        case C_ENDCLAUSE:
            break; /* won't get here unless delIndent == -1 */
        case C_ENDCASE:
            if (delIndent != -1 || !PopIndentStack(caseexprkind))
                cerror(BADINDENT,NEARNULL);
            if (!PopIndentStack(casekind))
                cerror(SPECIFICERR,"-endcase- without matching -case-");
            break;
        case C_OUTCASE:
            if (delIndent == 0)
                breaklevel = FindBreakIndent(caseexprkind); /* find most recent caseexpr */
            else
                breaklevel = FindPhysIndent(delIndent); /* find matching caseexpr */
            if (!breaklevel || indent[breaklevel].stype != caseexprkind)
                cerror(SPECIFICERR,"-outcase- not matching -case-");
            break;
        case C_ELSE:
            if (delIndent != -1) cerror(BADINDENT,NEARNULL);
            if (CheckIndentStack() == ifkind)
                ; /* don't need to do anything */
            else if (CheckIndentStack() == caseexprkind)
                { /* need to finish previous case */
                MidCompile(C_ENDCLAUSE);
                }
            else
                cerror(SPECIFICERR,"-else- not matching -if- or -case-");
            break;
        case C_LOOP:
            if (delIndent != 0) cerror(BADINDENT,NEARNULL);
            PushIndentStack(loopkind);
            break;
        case C_ENDLOOP:
            if (delIndent != -1) cerror(BADINDENT,NEARNULL);
            if (!PopIndentStack(loopkind))
                cerror(SPECIFICERR,"-endloop- not matching -loop-");
            break;
        case C_OUTLOOP:
        case C_RELOOP:
            if (delIndent == 0)
                breaklevel = FindBreakIndent(loopkind); /* find recent loop */
            else
                breaklevel =FindPhysIndent(delIndent); /* find matching loop */
            if (breaklevel && indent[breaklevel].stype == loopkind)
                break; /* ok */
            else if (cmdN == C_OUTLOOP)
                cerror(SPECIFICERR,"-outloop- not matching -loop-");
            else
                cerror(SPECIFICERR,"-reloop- not matching -loop-");
            break;
        case C_ARROW:
        case C_RARROW:
        case C_GARROW:
            if (delIndent != 0) cerror(BADINDENT,NEARNULL);
            PushIndentStack(arrowkind);
            PushIndentStack(arrow0kind);
            break;

        case C_PREANS:
        case C_IFMATCH:
            if (delIndent != 0)
                cerror(BADINDENT,NEARNULL);
            PushIndentStack(anskind);
            break;

        case C_ENDANS:
            if (!PopIndentStack(anskind))
                cerror(BADINDENT,NEARNULL); /* shouldn't ever happen */
            delIndent++;
            break;

        case C_ENDARROW:
            if (delIndent == -1)
                if (!PopIndentStack(anskind)) cerror(BADINDENT,NEARNULL);
            if (!PopIndentStack(arrowkind))
                cerror(SPECIFICERR,"-endarrow- not matching -arrow-.");
            break;
        case UNITSTART:
            oldIndent = 0; /* physical indent */
            indentlevel = 0; /* logical indent */
            break;
        case UNITEND:
            while (indentlevel>0)
                { /* take care of missing end-of-indents */
                startofline = indent[indentlevel].headsource;
                switch (indent[indentlevel].stype)
                    {
                    case casekind:
                    case caseexprkind:
                        cerror(SPECIFICERR,"Missing -endcase-.");
                        break;
                    case ifkind:
                        cerror(NOENDIF,NEARNULL);
                        break;
                    case loopkind:
                        cerror(NOENDLOOP,NEARNULL);
                        break;
                    case arrow0kind:
                    case arrowkind:
                        cerror(NOENDARROW,NEARNULL);
                        break;
                    case anskind:
                        MidCompile(C_ENDANS);
                        startcommand = cmpl; /* restore startcommand (after recursive MidCompile) */
                        break;
                    }
                indentlevel--;
                }
            break;
        case C_COND:
        case C_CONDDONE:
            break;
        default:
            if (delIndent == -1)
                { /* regular command ending an answer... */
                if (!PopIndentStack(anskind))
                    cerror(BADINDENT,NEARNULL); 
                }
            /* otherwise do nothing !!!!!! THE USUAL CASE !!!!! */
            break;
        }

    return(0);
    }

static PushIndentStack(iKind) /* push thing onto indent stack */
int iKind;
    {
    indentlevel++;
    if (indentlevel >= MAXINDENTS)
        cerror(SPECIFICERR,"Indents nested too deeply");
    indent[indentlevel].stype = iKind;
    indent[indentlevel].headloc = startcommand;
    indent[indentlevel].headsource = startofline;

    if (iKind != arrowkind && iKind != casekind)
        oldIndent++; /*  maintain expected physical indent */

    return(0);
    }

static PopIndentStack(iKind) /* attempt to pop indent stack */
int iKind; /* kind of thing expected */
/* returns TRUE if pop succeeded */
    {
    if (indentlevel <= 0 || indent[indentlevel].stype != iKind)
        return(FALSE);
    indentlevel--;

    if (iKind != arrowkind && iKind != casekind)
        oldIndent--; /* maintain expected physical indent */
    return(TRUE);
    }

static CheckIndentStack() /* returns kind of top of indent stack */
    {
    if (indentlevel <= 0)
        return(nonekind);
    return(indent[indentlevel].stype);
    }

static FindPhysIndent(delIndent) /* find item down in stack by physical indents */
int delIndent; /* how far back to look (a negative number) */
/* returns stack index or 0 for error */
    {
    int iIndex;

    iIndex = indentlevel+1; /* current top of stack + 1 */
    /* if delIndent is -1 we look at top of stack, -2 is one below, etc. */
    /* we want to skip over arrowkind and casekind entries, which aren't "real" */

    for (;delIndent < 0; delIndent++)
        {
        iIndex--;
        if (iIndex <= 0)
            return(0); /* back too far */
        while (indent[iIndex].stype == arrowkind || indent[iIndex].stype == casekind)
            {
            iIndex--;
            if (iIndex <= 0)
                return(0); /* back too far */
            }
        }

    return(iIndex);
    }

FindBreakIndent(fKind) /* look for most recent indentation kind */
int fKind; /* indent kind to find */
/* returns index, or 0 for error */
    {
    int iIndex;

    iIndex = indentlevel;
    while (iIndex && indent[iIndex].stype != fKind)
        iIndex--;

    return(iIndex);
    }

static FindPreviousCase() /* find physical indent level of case previous to topmost */
/* returns indent level */
    {
    int ii, jj,kk;

    ii = indentlevel;

    /* find current case level */
    while(indent[ii].stype != casekind)
        ii--;

    /* find previous case level */
    ii--;
    while (indent[ii].stype != casekind)
        ii--;

    /* now count physical indent levels up to that point */
    kk = 0; /* # of indents */
    /* start at 1 since first is nonekind (at 0th level) */
    for (jj=1; jj<ii; jj++)
        {
        if (indent[jj].stype != arrowkind && indent[jj].stype != casekind)
            kk++;
        }

    return(kk);
    }

/* ******************************************************************* */

StartCondTable() /* begin conditional command table */
    
{
    if (!condTh){
        condTalloc = 32;
        condTh = TUTORhandle("condtabl",(long) (condTalloc * sizeof(struct condctab)),TRUE);
    }
    nCondTag = 0;

    return(0);

} /* StartCondTable */

/* ******************************************************************* */

static AddCondTable() /* add entry to conditional command table */
    
{   struct condctab FAR *condPos;

    if (nCondTag >= condTalloc) {
        /* make cond table bigger */
        condTalloc += 16;
        TUTORset_hsize(condTh,(long)(condTalloc*sizeof(struct condctab)),TRUE);
    }
    condPos = (struct condctab FAR *) GetPtr(condTh);
    condPos[nCondTag].label = labelID;
    condPos[nCondTag++].pos = cmpl;
    ReleasePtr(condTh);
    KillPtr(condPos);
    add_dest(RD_COND3,labelID++,cmpl);

    return(0);


} /* AddCondTable */

/* ******************************************************************* */
