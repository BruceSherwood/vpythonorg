
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University. */

#include "execdefs.h"
#include "eglobals.h"
#include "tglobals.h"
#include "txt.h" 
#include "exprdefs.h"
#include "yacc.h"
#include "fkeys.h" 
#include "editor.h"
#include "txtv.h" 
#include "ct_ctype.h"
#include "tfiledef.h"
#include "kglobals.h"
#include "commands.h"

/* ******************************************************************* */

#ifdef ctproto
extern int TUTORinq_mouse_xy(long *xx,long *yy);
extern int TUTORinq_region_info(long rID,int *ww,int *hh);
extern int zsearch_icons(struct markvar SHUGE *target,struct markvar SHUGE *region);
int  tdoc_getstyles(unsigned int  theD,long  pos,short  *styles);
extern int TUTORinq_left_down(void);
extern int TUTORinq_right_down(void);
extern int  getnum(char  *s,int  *floatf,long  *i,double  *d,char  * *errm,int  *errn);
int  ex_isysvar(void);
int  exs_isysvar(void);
extern int MovieInfo(int *ww,int *hh,double *ll,int *isPlay);
int  GraphScale(long  fnx,long  fny,double  *cx,double  *cy);
int  RelativeScale(long  fnx,long  fny,double  *cx,double  *cy);
int  ex_cotofn(void);
int  ex_tsysvar(void);
int  exs_tsysvar(void);
int get_edit_ref(Memh eH);
int get_button_ref(Memh bH);
int get_slider_ref(Memh sH);
int get_dde_ref(Memh dH);
int  ex_zxyi(void);
int  ex_zxya(void);
int  ex_zxyr(void);
int  ex_zxyg(void);
int  ex_ccode(void);
int ex_dcode(void);
int  exec_text(void);
int  exec_compute(short  FAR *codep);
extern long dyn_array_lth(long FAR *ptr);
extern long dyn_array_index(long idescp);
extern int uplow(char FAR *str);
int ex_zfilepath(void);
int ex_zswidth(void);
int ex_zsheight(void);
int xfilenm(int type);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
int ex_zlengthf(void);
int  mvar_zero(struct  markvar SHUGE *mp);
int  ex_ztextsel(void);
int  ex_ztextvis(void);
int  ex_zeditbase(void);
int  ex_zhotsel(void);
int  arg_ztextmarker(int  arg);
int  ex_zhotinfoe(void);
int  ex_zhotinfom(void);
int  ex_zvalueb(void);
int  ex_zvalues(void);
int ex_zddetext(void);
extern int ex_loopchk(void);
int ex_nofun(void);
int  GetUnitName(int  unitn,unsigned char  *name);
int  ex_bitcnt(void);
long  lcbitcnt(long  av);
int  CTinq_closest_color(int  wn,double  redF,double  greenF,double  blueF,int  hsvf);
int  ex_zrgbn(void);
int  ex_zhsvn(void);
int  ex_zlength(void);
int  ex_gamma(void);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int ex_zfilename(void);
int  ex_znextword(void);
int ex_znextexpr(void);
int ex_znextline(void);
int ex_znextnum(void);
int mvar_next_item(int type);
extern long TUTORsearch_doc();
long  _TUTORsearch_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sGood,long  sLen,unsigned int  strSpecial,long  strSOff,long  pos,long  posEnd,unsigned char  FAR *cTable);
int  ex_zsearch(void);
extern int dynerr(void);
extern long dyn_array_index(long idescp);
extern long dyn_array_lth(long FAR *ptr);
extern int gdy_array_inf(void);
extern int ldy_array_inf(void);
extern int pdy_array_inf(void);
extern int exs_gdyarray(void);
extern int exs_ldyarray(void);
int  set_exec_pt(unsigned int  uloc);
long  get_exec_pt(void);
int ex_gdyarrayval(void);
int exs_gdyarrayval(void);
int ex_gdyarrayaddr(void);
int exs_gdyarrayaddr(void);
int ex_igdyarrayval(void);
int exs_igdyarrayval(void);
int ex_igdyarrayaddr(void);
int exs_igdyarrayaddr(void); 
int ex_bgdyarrayval(void);
int exs_bgdyarrayval(void);
int ex_gdyarray(void);

int ex_ldyarrayval(void);
int exs_ldyarrayval(void);
int ex_ldyarrayaddr(void);
int exs_ldyarrayaddr(void);
int ex_ildyarrayval(void);
int exs_ildyarrayval(void);
int ex_ildyarrayaddr(void);
int exs_ildyarrayaddr(void); 
int ex_bldyarrayval(void);
int exs_bldyarrayval(void);
int ex_ldyarray(void);
int ldy_array_inf(void);

int ex_pdyarrayval(void);
int exs_pdyarrayval(void);
int ex_pdyarrayaddr(void);
int exs_pdyarrayaddr(void);
int ex_ipdyarrayval(void);
int exs_ipdyarrayval(void);
int ex_ipdyarrayaddr(void);
int exs_ipdyarrayaddr(void); 
int ex_bpdyarrayval(void);
int exs_bpdyarrayval(void);
int ex_pdyarray(void);
int pdy_array_inf(void);

int  ex_storinf(void);
int  exs_storinf(void);
int  exs_floatinit(void);
int  ex_tkeyword(void);
int  ex_textarg(void);
int  ex_textarg1(void);
int  ex_ulocaddr(void);
int  exs_storeaddr(void);
int  ex_loopchk(void);
int  ex_arrayerr(void);
extern long  array_index(long  idescp);
extern int  global_array_inf(void);
extern int  local_array_inf(void);
extern int  pass_array_inf(void);
extern int  exs_pass_array_inf(void);
extern int gdy_array_inf(void);
long  l_bin(void);
double  f_bin(void);
long  l_read(char  FAR *addr);
double  f_read(char  FAR *addr);
int  n_follow(int  branchtype);
extern int  mvar_stack(long  addr);
int  mvar_init(struct  markvar SHUGE *mp);
int  mvar_assign(struct markvar SHUGE *vaddr,struct  markvar SHUGE *mx);
int  mvar_compare(struct  markvar SHUGE *ma,struct  markvar SHUGE *mb,int  exact);
int  ex_nofun(void);
double  lcfexpon(double  y,double  x);
long  lcbitcnt(long  av);
long  IntToCoord(int  xx);
int  RoundCoord(long  xx);
int  GraphScale(long  fnx,long  fny,double  *cx,double  *cy);
int  RelativeScale(long  fnx,long  fny,double  *cx,double  *cy);
int  TUTORdump(char  *s);
int  TUTORtrace(char  *s);
int  flush(void);
extern int get_zddetext(void);
int  TUTORforce_redraw(int  wix);
int  TUTORflush(void);
int  ReleaseStack(void);
int  mvar_temp_cleanup(void);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  InsureUnit(int  unitn);
unsigned char  SHUGE *LockStack(void);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
long  FloatToCoord(double  zz);
int  execerr(char  *msgstr);
int  matherror(int  errnum,char  *s);
int  MatchUnitName(unsigned char  *name);
long  lcftoi(double  dv);
double  lcitof(long  iv);
extern double floor(double x);
extern double atan2(double x, double y);
extern double atan(double x);
extern double log10(double x);
extern double sqrt(double x);
int  fuzzyeq(double  x,double  y);
extern double acos(double x);
extern double fabs(double x);
extern double asin(double x);
extern double cos(double x);
extern double sin(double x);
extern double tan(double x);
extern double tanh(double x);
extern double cosh(double x);
extern double sinh(double x);
extern double pow(double x,double y);
extern double exp(double x);
extern double log(double x);
int  mvar_get_inf(unsigned int  docH,long  *len,long  *users,long  *head);
int  TUTORinsert_string_doc(unsigned int  doc,long  pos,unsigned char  FAR *ss,long  sLen);
int  scoderr(void);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
unsigned int  mvar_new(int  ref);
long  _TUTORsearch_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sGood,long  sLen,unsigned int  strSpecial,long  strSOff,long  pos,long  posEnd,unsigned char  FAR *cTable);
int  _TUTORload_buffer_doc(struct  _ktd FAR *dp,long  pos);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
char  FAR *GetPtr(unsigned int  mm);
int  _TUTORinfo_vbar_tview(struct  _viewp FAR *tvp,struct  _sbarinf *vb);
int  TUTORinq_select_tview(unsigned int  theV,long  *pos,long  *len);
int  TUTORdealloc(char  FAR *ptr);
int  strlenf(char  FAR *aa);
char  FAR *CTzks(int  code,char  *tempS);
double  TUTORinq_slider_value(unsigned int  sbi);
int  TUTORinq_button_value(unsigned int  bH);
unsigned char  FAR *GetHotstringTStyle(unsigned int  pd,int  id,long  *len,long  *spos,long  *slen,int  getS);
int  fuzzyle(double  x,double  y);
int  fuzzygt(double  x,double  y);
int  fuzzylt(double  x,double  y);
int  fuzzyge(double  x,double  y);
int  fuzzyne(double  x,double  y);
int  jzjcount(void);
int  TUTORtrace_n(char  *s,long  nn);
double  CoordToFloat(long  xx);
long  TUTORinq_msec_clock(void);
int  GetUnitName(int  unitn,unsigned char  *name);
extern char *TUTORgetenv(char *varname);
double  MovieGetTime(void);
int  TUTORget_colors(struct tutorColor *fcx,struct tutorColor *bcx,struct tutorColor *wcx);
int  CTcount_colors(int  oldF);
int  TUTORshowt(double  value,int  nBefore,int  nAfter,int  showperiod,char  *s);
int  TUTORshow(int type,double  value,int  sigfig,char  *ss);
int  shouldint(void);
int  mvar_attach_doc(struct  markvar SHUGE *mvarP,unsigned int  docH,unsigned char  SHUGE *stackP);
int  mvar_detach_doc(struct  markvar SHUGE *mvarP,unsigned int  docH,unsigned char  SHUGE *stackP);
extern int TUTORzero(char SHUGE *ptr,long lth);
int  TUTORfree_handle(unsigned int  mm);
int  _TUTORcmp_doc(struct  _ktd FAR *dp,long  pos0,long  dLen0,long  *docUsed,unsigned char  FAR *ss,long  ssGood,long  *cLen0,unsigned int  strSpecial,long  strSOff,unsigned char  FAR *cTable,int  exactF);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifndef __MC68K__
extern double  gamma(double  a);
#endif

#ifdef macproto
#ifndef THINKC5
#ifndef WERKS
extern int sprintf(char *ss, char *form,...);
extern int printf(char *form,...);
#endif
#endif
extern int MacFilePath(FileRef *fRef,char *str,int len);
extern long Mac_Zncolors(void);
#endif

#ifndef WERKS
extern double atan();
extern double atan2();
extern double sin(), cos(), tan(), asin(), acos(), atan();
extern double fabs(), sqrt(), exp(), pow(), log10(), log();
extern double alog(), sinh(), cosh(), tanh();
#endif

extern long quickLast,quickVal;
extern  long lcbitcnt();
extern long l_bin();
extern long l_read();
extern double f_bin();
extern double f_read();
extern long array_index();
extern long pass_addr();
extern Coord IntToCoord();
extern Coord FloatToCoord();
extern long array_index();
extern long lcftoi();
extern double lcitof();
extern double floor();
extern  double lcfexpon();
extern double fabs();
extern Memh mvar_new();
extern unsigned char FAR *GetHotstringTStyle();
extern char FAR *TUTORalloc();
extern double CoordToFloat();
extern int TUTORcharat_doc();
extern double TUTORinq_slider_value();
extern double MovieGetTime();
extern long dyn_array_index();

/* ******************************************************************* */

#ifndef long_align
#define long_bin (*((long FAR *)(ex_binP)))
#define long_read(addr) (*(long SHUGE *)(addr))
#define flt_bin (*((double FAR *)(ex_binP)))
#define flt_read(addr) (*(double SHUGE *)(addr))
#else
#define long_bin (l_bin())
#define long_read(addr) (l_read(addr))
#define flt_bin (f_bin())
#define flt_read(addr) (f_read(addr))
#endif

#define IHUGE 0x7fffffff
#define abstolerance 0.000000001
#define reltolerance 0.00000000001
#define onep 1.0

extern int logcmd;
extern int movieCtrlH;

/* ------------------------------------------------------------------- */

exec_text() /* execute embedded write/show commands */

{   register int code;
#ifdef THINKC5
	int (*funcp)(...);
#else
    register int (FAR *funcp)();
#endif

    do {
        code = *ex_binP++;
        funcp = exs_addr[code];
        (*funcp)();
    } while ((code != C_ENDTEXT) && (code != C_ENDTEXT1) && 
             (code != C_ENDTEXT2));

} /* exec_text */

/* ------------------------------------------------------------------- */

exec_compute(codep) /* execute expression for -compute- */
short FAR *codep; /* pointer to pcodes */

{   
#ifdef THINKC5
	int (*funcp)(...);
#else
	register int (FAR *funcp)();
#endif

    ex_binP = codep;
    while (*ex_binP) {
        funcp = exs_addr[*ex_binP++];
        (*funcp)();
    } /* while */

} /* exec_compute */

/* ------------------------------------------------------------------- */

#ifdef NOSUCH
char msg[80];
if (logcmd) {
    sprintf(msg,"executing machine code at: %lx",(long)ex_binP);
    TUTORtrace(msg);
}
if (iresP < istack)
  TUTORdump("integer stack underflow: ex_ccode");
#endif

#ifdef __POWERPC__
extern void PPCjump(short *ptrc,long *ptrd);
#endif

ex_ccode() /* execute machine code */

{   
#ifdef __POWERPC__
	PPCjump(ex_binP,(long *)&exs_addr[0]);
#else
    (*((int(*)())ex_binP))(&exs_addr[0]);
#endif

} /* ex_ccode */

ex_dcode() /* execute machine code */

{   
	ex_binP++;
#ifdef __POWERPC__
	PPCjump(ex_binP,(long *)&exs_addr[0]);
#else
    (*((int(*)())ex_binP))(&exs_addr[0]);
#endif
    
} /* ex_dcode */

/* ------------------------------------------------------------------- */

ex_cotofn() /* coarse grid to fine grid conversion */

{   register int rc,xx,yy;

    rc = RoundCoord(*(--iresP)); /* get coarse grid */
    xx = (rc%100-1)*exS.CoarseW;
    yy = (rc/100-1)*exS.CoarseH; 
    *iresP++ = IntToCoord(xx);
    *iresP++ = IntToCoord(yy); 

} /* ex_cotofn */

/* ------------------------------------------------------------------- */

ex_zxyi() /* current screen position (absolute, integer) */

{
    *iresP++ = RoundCoord(exS.ScreenX); 
    *iresP++ = RoundCoord(exS.ScreenY);

} /* ex_zxyi */

/* ------------------------------------------------------------------- */

ex_zxya() /* current screen position (absolute, Coord) */

{
    *iresP++ = exS.ScreenX; 
    *iresP++ = exS.ScreenY;

} /* ex_zxya */

/* ------------------------------------------------------------------- */

ex_zxyr() /* current screen position (relative, floating) */

{   double fx,fy;
    
    RelativeScale(exS.ScreenX,exS.ScreenY,&fx,&fy);
    *fresP++ = fx; 
    *fresP++ = fy;

} /* ex_zxyr */

/* ------------------------------------------------------------------- */

ex_zxyg() /* current screen position (graph, floating) */

{   double fx,fy;
    
    GraphScale(exS.ScreenX,exS.ScreenY,&fx,&fy);
    *fresP++ = fx; 
    *fresP++ = fy;

} /* ex_zxyg */

/* ------------------------------------------------------------------- */

ex_gdyarrayval() /* floating dynamic global array value */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_gdyarrayval();

} /* ex_gdyarrayval */

/* ------------------------------------------------------------------- */

exs_gdyarrayval() /* floating dynamic global array value */
                  /* compiled code call-able version */
 
{   register long rel;

    rel = *(--iresP);
    store_addr = dyn_array_index(rel);
    *fresP++ = flt_read(store_addr);
    
} /* exs_gdyarrayval */

/* ------------------------------------------------------------------- */

ex_gdyarrayaddr() /* floating dynamic global array address */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_gdyarrayaddr();

} /* ex_gdyarrayaddr */

/* ------------------------------------------------------------------- */

exs_gdyarrayaddr() /* floating dynamic global array address */
                   /* compiled code call-able version */
 
{   register long rel;

    rel = *(--iresP);
    store_addr = dyn_array_index(rel);
    *iresP++ = store_addr; /* push addr to assign into */
    
} /* exs_gdyarrayaddr */

/* ------------------------------------------------------------------- */

ex_igdyarrayval() /* integer dynamic global array value */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_igdyarrayval();

} /* ex_igdyarrayval */

/* ------------------------------------------------------------------- */

exs_igdyarrayval() /* value of integer dynamic global array item */
                   /* compiled code call-able version */

{   register long rel;

    rel = *(--iresP);
    store_addr = dyn_array_index(rel);
    *iresP++ = long_read(store_addr);

} /* exs_igdyarrayval */

/* ------------------------------------------------------------------- */

ex_igdyarrayaddr() /* integer dynamic global array address */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_igdyarrayaddr();
    
} /* ex_igdyarrayaddr */

/* ------------------------------------------------------------------- */

exs_igdyarrayaddr() /* integer dynamic global array address */
                    /* compiled code call-able version */

{   register long rel; /* relative address */
    register long vv; /* value to be assigned */

    rel = *(--iresP);
    vv = *(--iresP); /* pop value to be assigned */
    store_addr = dyn_array_index(rel);
    *iresP++ = vv; /* restore value to be assigned */
    *iresP++ = store_addr; /* push addr to assign into */
        
} /* exs_igdyarrayaddr */

/* ------------------------------------------------------------------- */

ex_bgdyarrayval() /* byte dynamic global array value */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_bgdyarrayval();

} /* ex_bgdyarrayval */

/* ------------------------------------------------------------------- */

exs_bgdyarrayval() /* value of byte dynamic global array item */
                   /* compiled code call-able version */

{   register long rel;

    rel = *(--iresP);
    store_addr = dyn_array_index(rel);
    *iresP++ = *(unsigned char FAR *)(store_addr);

} /* exs_bgdyarrayval */

/* ------------------------------------------------------------------- */

ex_gdyarray() /* entire dynamic floating global array */

{
    gdy_array_inf();
    
} /* ex_gdyarray */

/* ------------------------------------------------------------------- */

ex_ldyarrayval() /* floating dynamic local array value */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_ldyarrayval();

} /* ex_ldyarrayval */

/* ------------------------------------------------------------------- */

exs_ldyarrayval() /* floating dynamic local array value */
                  /* compiled code call-able version */
 
{   register long rel;

    rel = *(--iresP);
    store_addr = dyn_array_index(exS.lvars+rel);
    *fresP++ = flt_read(store_addr);
    
} /* exs_ldyarrayval */

/* ------------------------------------------------------------------- */

ex_ldyarrayaddr() /* floating dynamic local array address */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_ldyarrayaddr();

} /* ex_ldyarrayaddr */

/* ------------------------------------------------------------------- */

exs_ldyarrayaddr() /* floating dynamic local array address */
                   /* compiled code call-able version */
 
{   register long rel;

    rel = *(--iresP);
    store_addr = dyn_array_index(exS.lvars+rel);
    *iresP++ = store_addr; /* push addr to assign into */
    
} /* exs_ldyarrayaddr */

/* ------------------------------------------------------------------- */

ex_ildyarrayval() /* integer dynamic local array value */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_ildyarrayval();

} /* ex_ildyarrayval */

/* ------------------------------------------------------------------- */

exs_ildyarrayval() /* value of integer dynamic local array item */
                   /* compiled code call-able version */

{   register long rel;

    rel = *(--iresP);
    store_addr = dyn_array_index(exS.lvars+rel);
    *iresP++ = long_read(store_addr);

} /* exs_ildyarrayval */

/* ------------------------------------------------------------------- */

ex_ildyarrayaddr() /* integer dynamic local array address */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_ildyarrayaddr();
    
} /* ex_ildyarrayaddr */

/* ------------------------------------------------------------------- */

exs_ildyarrayaddr() /* integer dynamic local array address */
                    /* compiled code call-able version */

{   register long rel; /* relative address */
    register long vv; /* value to be assigned */

    rel = *(--iresP);
    vv = *(--iresP); /* pop value to be assigned */
    store_addr = dyn_array_index(exS.lvars+rel);
    *iresP++ = vv; /* restore value to be assigned */
    *iresP++ = store_addr; /* push addr to assign into */
        
} /* exs_ildyarrayaddr */

/* ------------------------------------------------------------------- */

ex_bldyarrayval() /* byte dynamic local array value */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_bldyarrayval();

} /* ex_bldyarrayval */

/* ------------------------------------------------------------------- */

exs_bldyarrayval() /* value of byte dynamic local array item */
                   /* compiled code call-able version */

{   register long rel;

    rel = *(--iresP);
    store_addr = dyn_array_index(exS.lvars+rel);
    *iresP++ = *(unsigned char FAR *)(store_addr);

} /* exs_bldyarrayval */

/* ------------------------------------------------------------------- */

int ex_ldyarray() /* entire floating dynamic local array */

{
    ldy_array_inf();
    
} /* ex_ldyarray */

/* ------------------------------------------------------------------- */

ex_pdyarrayval() /* floating dynamic passed array value */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_pdyarrayval();

} /* ex_pdyarrayval */

/* ------------------------------------------------------------------- */

exs_pdyarrayval() /* floating dynamic passed array value */
                  /* compiled code call-able version */
 
{   register long rel;

    rel = *(--iresP);
    rel = *(long SHUGE *)(exS.lvarP+rel);
    store_addr = dyn_array_index(rel);
    *fresP++ = flt_read(store_addr);
    
} /* exs_pdyarrayval */

/* ------------------------------------------------------------------- */

ex_pdyarrayaddr() /* floating dynamic passed array address */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_pdyarrayaddr();

} /* ex_pdyarrayaddr */

/* ------------------------------------------------------------------- */

exs_pdyarrayaddr() /* floating dynamic passed array address */
                   /* compiled code call-able version */
 
{   register long rel;

    rel = *(--iresP);
    rel = *(long SHUGE *)(exS.lvarP+rel);
    store_addr = dyn_array_index(rel);
    *iresP++ = store_addr; /* push addr to assign into */
    
} /* exs_pdyarrayaddr */

/* ------------------------------------------------------------------- */

ex_ipdyarrayval() /* integer dynamic passed array value */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_ipdyarrayval();

} /* ex_ipdyarrayval */

/* ------------------------------------------------------------------- */

exs_ipdyarrayval() /* value of integer dynamic passed array item */
                   /* compiled code call-able version */

{   register long rel;

    rel = *(--iresP);
    rel = *(long SHUGE *)(exS.lvarP+rel);
    store_addr = dyn_array_index(rel);
    *iresP++ = long_read(store_addr);

} /* exs_ipdyarrayval */

/* ------------------------------------------------------------------- */

ex_ipdyarrayaddr() /* integer dynamic passed array address */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_ipdyarrayaddr();
    
} /* ex_ipdyarrayaddr */

/* ------------------------------------------------------------------- */

exs_ipdyarrayaddr() /* integer dynamic passed array address */
                    /* compiled code call-able version */

{   register long rel; /* relative address */
    register long vv; /* value to be assigned */

    rel = *(--iresP);
    vv = *(--iresP); /* pop value to be assigned */
    rel = *(long SHUGE *)(exS.lvarP+rel);
    store_addr = dyn_array_index(rel);
    *iresP++ = vv; /* restore value to be assigned */
    *iresP++ = store_addr; /* push addr to assign into */
        
} /* exs_ipdyarrayaddr */

/* ------------------------------------------------------------------- */

ex_bpdyarrayval() /* byte dynamic passed array value */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_bpdyarrayval();

} /* ex_bpdyarrayval */

/* ------------------------------------------------------------------- */

exs_bpdyarrayval() /* value of byte dynamic passed array item */
                   /* compiled code call-able version */

{   register long rel;

    rel = *(--iresP);
    rel = *(long SHUGE *)(exS.lvarP+rel);
    store_addr = dyn_array_index(rel);
    *iresP++ = *(unsigned char FAR *)(store_addr);

} /* exs_bpdyarrayval */

/* ------------------------------------------------------------------- */

int ex_pdyarray() /* entire floating dynamic passed array */

{
    pdy_array_inf();
    
} /* ex_pdyarray */

/* ------------------------------------------------------------------- */

long dyn_array_index(idescp) /* index into dynamic array, return address */
long idescp; /* stack addr of index of descriptor */

{   long i, n;
    unsigned char SHUGE *base;
    int dim;
    struct array_desc FAR *pda; /* pointer to array description */
    struct dim_desc FAR *pdd; /* pointer to dimension description */
    Memh arrayH; /* handle on array */
    char SHUGE *arrayP; /* pointer to array */
    long SHUGE *lpp;

#ifdef long_align
if (idescp & 3) 
    TUTORdump("unaligned array descriptor 1");
#endif
    base = exS.stackP+idescp;
    lpp = (long SHUGE *)(base);
    pda = (struct array_desc FAR *) (descP+*lpp);
    dim = pda->ndim; /* number dimensions */
    pdd = (struct dim_desc FAR *)(pda+1); /* bias to base of dimensions */
    
    /* check array has been allocated */
    
    arrayH = *(lpp+2);
    arrayP = (char SHUGE *)(*(lpp+1));
    if (!arrayH)
        ex_arrayerr();
        
    /* lock array if not yet locked */
    
    if (!arrayP) {
        arrayP = GetPtr(arrayH); /* lock handle */
        *(lpp+1) = (long)arrayP; /* set pointer to array */
        exS.dynLocked++;
    }

if ((pda->dtype != 6) && (pda->dtype != 1))
    TUTORdump("bad array descriptor 2");

    if (dim == 1) { /* one-dimensional array */
        n = *(--iresP)-pdd->lower; 
        if (n < 0 || n >= pdd->length) 
            ex_arrayerr();
    } else {
        n = 0; /* cumulative index */
        pdd += dim-1; /* bias to last dimension */
        while ((--dim) >= 0) { /* peel off indices in reverse order */
            i = *(--iresP)-pdd->lower; 
            if (i < 0 || i >= pdd->length) 
                ex_arrayerr();
            n += i*((pdd--)->multiplier);
        } /* dim while */
    } /* dim else */    
    store_items = pda->length-n;
    return((long)(arrayP+(n*pda->size))); /* compute address */

} /* dyn_array_index */

/* ------------------------------------------------------------------- */

long dyn_array_lth(stkP) /* return current length of dynamic array */
long FAR *stkP; /* address of array info on stack */

{   struct array_desc FAR *pda; /* pointer to array description */

    pda = (struct array_desc FAR *) (descP+*stkP);
    
if ((pda->dtype != 6) && (pda->dtype != 1))
    TUTORdump("bad array descriptor 3");

    return((long)pda->length);

} /* dyn_array_lth */

/* ------------------------------------------------------------------- */

static gdy_array_inf() /* stack info for unsubscripted dynamic global array */

{   long SHUGE *llp; /* pointer to array info on stack */
    Memh arrayH; /* handle on array */

    *iresP++ = 0; /* no result */
    *iresP++ = long_bin; /* expression type */
    ex_binP += 2;
    llp = ((long SHUGE *)(exS.stackP+long_bin));
    arrayH = *(llp+2); /* get handle on array */
    if (!arrayH) {
        *iresP++ = (long)(llp); 
        *iresP++ = 0; /* no length */
        ex_binP += 4;
        return;
    }
    if (!(*(llp+1))) {
        if (arrayH == (Memh)(-1)) dynerr();
        *(llp+1) = (long)GetPtr(arrayH); /* lock handle */
        exS.dynLocked++;
    }
    *iresP++ = (long)(llp);
    ex_binP += 4;
    *iresP++ = dyn_array_lth(llp); 

} /* gdy_array_inf */

dynerr() { execerr("? Don't have address of array on stack"); }

/* ------------------------------------------------------------------- */

static ldy_array_inf() /* stack info for unsubscripted dynamic local array */

{   long SHUGE *llp; /* pointer to array info on stack */
    Memh arrayH; /* handle on array */

    *iresP++ = 0; /* no result */
    *iresP++ = long_bin; /* expression type */
    ex_binP += 2;
    llp = ((long SHUGE *)(exS.lvarP+long_bin));
    arrayH = *(llp+2); /* get handle on array */
    if (!arrayH) {
        *iresP++ = (long)(llp);
        *iresP++ = 0; /* no length */
        ex_binP += 4;
        return;
    }
    if (!(*(llp+1))) {
        if (arrayH == (Memh)(-1)) dynerr();
        *(llp+1) = (long)GetPtr(arrayH); /* lock handle */
        exS.dynLocked++;
    }
    *iresP++ = (long)(llp);
    ex_binP += 4;
    *iresP++ = dyn_array_lth(llp);

} /* ldy_array_inf */

/* ------------------------------------------------------------------- */

static pdy_array_inf() /* stack info for unsubscripted dynamic passed array */

{   long SHUGE *llp; /* pointer to array info on stack */
    Memh arrayH; /* handle on array */

    *iresP++ = 0; /* no result */
    *iresP++ = long_bin; /* expression type */
    ex_binP += 2;
    llp = ((long SHUGE *)(exS.lvarP+long_bin));
    llp = (long SHUGE *)(exS.stackP+*llp);
    arrayH = *(llp+2); /* get handle on array */
    if (!arrayH) {
        *iresP++ = (long)(llp);
        *iresP++ = 0; /* no length */
        ex_binP += 4;
        return;
    }
    if (!(*(llp+1))) {
        if (arrayH == (Memh)(-1)) dynerr();
        *(llp+1) = (long)GetPtr(arrayH); /* lock handle */
        exS.dynLocked++;
    }
    *iresP++ = (long)(llp);
    ex_binP += 4;
    *iresP++ = dyn_array_lth(llp);

} /* pdy_array_inf */

/* ------------------------------------------------------------------- */

exs_gdyarray() /* stack info for entire global dynamic array */

{   int type; /* float,int,mark type */
    long addr; /* address of array */
    long passd; /* index in descriptors */
    long SHUGE *llp; /* pointer to array header */
    Memh arrayH; /* handle on array */
    struct array_desc FAR *adsc; /* pointer to array description */

    addr = (long)(exS.stackP+*(--iresP));
    llp = ((long SHUGE *)addr);
    arrayH = *(llp+2);
    if (arrayH) { /* have handle, array allocated */
        if (arrayH == (Memh)(-1)) dynerr(); 
        if  (!(*(llp+1)))
            *(llp+1) = (long)GetPtr(arrayH); /* lock handle */
    }
    type = *(--iresP);
    *iresP++ = 0; /* no result */
    *iresP++ = type; /* expression type */
    *iresP++ = addr;
    passd = long_read(addr); /* index in descriptors */
    adsc = (struct array_desc FAR *)(descP+passd);
    if (adsc->length < 0)
        ex_arrayerr();
    *iresP++ = store_items = adsc->length; /* length of array */

} /* exs_gdyarray */

/* ------------------------------------------------------------------- */

exs_ldyarray() /* stack info for entire local dynamic array */

{   int type; /* float,int,mark type */
    long addr; /* address of array */
    long passd; /* index in descriptors */
    long SHUGE *llp; /* pointer to array header */
    Memh arrayH; /* handle on array */
    struct array_desc FAR *adsc; /* pointer to array description */

    addr = (long)(exS.lvarP+*(--iresP));
    llp = ((long SHUGE *)addr);
    arrayH = *(llp+2);
    if (arrayH) { /* have handle, array allocated */
        if (arrayH == (Memh)(-1)) dynerr(); 
        if  (!(*(llp+1)))
            *(llp+1) = (long)GetPtr(arrayH); /* lock handle */
    }
    type = *(--iresP);
    *iresP++ = 0; /* no result */
    *iresP++ = type; /* expression type */
    *iresP++ = addr;
    passd = long_read(addr); /* index in descriptors */
    adsc = (struct array_desc FAR *)(descP+passd);
    if (adsc->length < 0)
        ex_arrayerr();
    *iresP++ = store_items = adsc->length; /* length of array */

} /* exs_ldyarray */

/* ------------------------------------------------------------------- */

ex_zsearch() /* search for target string in marked region */

{   register struct markvar SHUGE *target; /* target marker */
    struct markvar SHUGE *region; /* region marker */
    struct markvar result; /* result marker */
    DocP dRegion;
    REGISTER DocP dTarget;
    int checkLong;
    register long checkLen, curPos;
    long regionEnd;
    unsigned char FAR *cTable;  /* sort table to use */
    int maxAliasLen, ii, ccode;
    long tempL;
    long sGoodLen;  /* valid length of target string pointer */
    unsigned char FAR *tempS;
    unsigned char FAR *tp;

    target = --markP;
    region = --markP;
    result = *region;
    result.pos = result.len = 0; /* set up empty marker */
    exS.loopcounter += 10; /* crude means of accounting for expensive operation */

    /* check for empty strings or other impossible cases */
    if (!target->len || !region->len || (target->len > region->len && exS.exactMatch)) {
        /* don't do compare, one string is empty, or target doesn't fit */
        *(markP++) = result;
        return(0);
    }

	/* check if need specialized search that recognizes icons */
	
    for(ii=0; ii<target->len; ii++) {
    	ccode = TUTORcharat_doc(target->doc,target->pos+ii);
        if (ccode == ICONSPECIAL) { 
        	zsearch_icons(target,region);
        	return(0);     
        } /* ccode if */
    } /* for */

    /* get sort table */
    if (!exS.exactMatch)
        cTable = exS.sortTable ? (unsigned char FAR *) GetPtr(exS.sortTable) :
                    (unsigned char FAR *) -1L;
    else
        cTable = FARNULL;
    if (cTable)
        maxAliasLen = cTable[257];
    else
        maxAliasLen = 1;

    curPos = region->pos;
    regionEnd = region->pos + region->len;
    dRegion = (DocP) GetPtr(region->doc);
    dTarget = (DocP) GetPtr(target->doc);
    
    /* get target string set up correctly */
    tempS = FARNULL;
    checkLong = FALSE; /* normally we don't have to do compares here */
                        /* but if target is very long we may only search for the
                            first part of it and then compare what we found against
                            the whole target */
    
    if (!dTarget->shortText && region->doc == target->doc)
        { /* region & target in same doc, try to force all text into buffer */
        tempL = region->pos;
        if (tempL > target->pos)
            tempL = target->pos;
        _TUTORload_buffer_doc(dTarget,tempL);
        if (target->pos + target->len > dTarget->buffEnd ||
                region->pos + region->len > dRegion->buffEnd)
            { /* can't get both in buffer, allocate temporary space */
            sGoodLen = target->len;
            if (sGoodLen > 999)
                sGoodLen = 999;
            tempS = (unsigned char FAR *) TUTORalloc(sGoodLen,TRUE,"srchtmp");
            if (sGoodLen >= target->len)
                checkLen = target->len;
            else
                {
                checkLen = sGoodLen - maxAliasLen + 1;
                checkLong = TRUE;
                }
            }
        else
            { /* we managed to fit both target & region in buffer */
            sGoodLen = target->len;
            checkLen = sGoodLen;
            }
        }
    else if (!dTarget->shortText && !(target->pos >= dTarget->buffStart &&
            target->pos + target->len <= dTarget->buffEnd))
        { /* load buffer of target doc */
        _TUTORload_buffer_doc(dTarget,target->pos);
        if (!(target->pos >= dTarget->buffStart &&
                target->pos + target->len <= dTarget->buffEnd))
            { /* it didn't all fit in buffer, we'll have to do compares here */
            sGoodLen = dTarget->buffEnd - target->pos;
            checkLen = sGoodLen - maxAliasLen + 1;
            checkLong = TRUE;
            }
        }
    else
        { /* target in short text doc */
        checkLen = target->len;
        sGoodLen = checkLen;
        }

    do
        { /* need to loop because of very long target */
        if (!tempS)
            tp = dTarget->text+target->pos-dTarget->buffStart;
        else
            tp = tempS; /* allocated target string */
        result.pos = _TUTORsearch_doc(dRegion,tp,sGoodLen,checkLen,
                                dTarget->specialT,target->pos,curPos,regionEnd,cTable);
        if (result.pos == -1L)
            { /* didn't find */
            result.pos = 0; /* return to empty */
            }
        else
            {
            if (!checkLong)
                { /* we found match */
                result.len = target->len;
                }
            else
                { /* we need to compare entire strings */
                tempL = region->pos; /* save & restore region->pos */
                region->pos = result.pos;
                ii = mvar_compare(target,region,TRUE);
                region->pos = tempL;
                if (!ii)
                    { /* found match */
                    result.len = target->len;
                    checkLong = FALSE; /* we're done */
                    }
                else
                    { /* first part matched, but not the rest */
                    curPos = result.pos+1; /* where we want to continue the search */
                    if (!tempS)
                        _TUTORload_buffer_doc(dTarget,target->pos); /* make sure target buffer is ok */
                    }
                }
            }
        
        } while (checkLong);

    if (!exS.exactMatch && exS.sortTable)
        {
        ReleasePtr(exS.sortTable);
        KillPtr(cTable);
        }

    if (tempS)
        TUTORdealloc((char FAR *) tempS);
    
    ReleasePtr(region->doc);
    KillPtr(dRegion);
    ReleasePtr(target->doc);
    KillPtr(dTarget);
    *(markP++) = result;
    return(0);

} /* ex_zsearch */

/* ------------------------------------------------------------------- */

ex_znextword() { mvar_next_item(0); }
ex_znextline() { mvar_next_item(1); }
ex_znextnum()  { mvar_next_item(2); }
ex_znextexpr() { mvar_next_item(3); }

static mvar_next_item(type) /* return marker on next item in marker */
int type; /* = 0 = next word */
          /* = 1 = next line */
          /* = 2 = next number */
          /* = 3 = next algebraic expression */

{   struct markvar SHUGE *mx;
    long spos,cpos;
    int state; /* 0 = pre-word - skip over terminator(s) */
               /* 1 = in word - stop on terminator */
    int cc; /* current character */
	double fvalue; /* floating result of znextnum/getnum */
	long ivalue; /* integer result of getnum */
	int uminus; /* TRUE if unary minus */
	int numeric; /* TRUE if this character numeric */
	int isfloat; /* TRUE if floating */
	int errn; /* error number */
	int nbii; /* index in number buffer */
	int parenc; /* current paren balance */
	int quotec; /* current quote balance */
	char *nP; /* pointer to buffer */
	char numbuf[102]; /* buffer to assemble number */

    mx = markP-1;
    if ((type == 0) || (type == 1) || (type == 3))
    	cpos = mx->pos+mx->len;
    else if (type == 2)
        cpos = mx->pos;
    spos = -1; /* haven't found start of word yet */
    state = uminus = nbii = parenc = quotec = 0;
	fvalue = 0.0;

    /* scan to find next word/line/number */

    while (TRUE) {
        if (mx->doc == 0)
            break; /* no document */
        if (cpos >= mx->doclen) 
            break; /* end of document */
		if ((type == 2) && (cpos >= (mx->pos+mx->len)))
			break;
        cc = TUTORcharat_doc(mx->doc,cpos);
        if (type == 0) { 
        
        	/* next word */
        	
            if (CTisspace(cc)) {
                if (state == 0) 
                    cpos++; /* advance to next character */
                else 
                    break; /* built word */
            } else {
                if (state == 0) {
                    state = 1; /* building word */
                    spos = cpos; /* starting position of word */
                }
                cpos++; /* advance to next character */
            } /* else */
        } else if (type == 1) { 
        
        	/* next line */
        	
            if (spos < 0)
                spos = cpos;
            cpos++; /* marker will include newline */
            if (cc == NEWLINE)
                break; /* found end of line */
        } else if (type == 2) { 
        
        	/* next number */
        	
			numeric = ((cc >= '0') && (cc <= '9'));
			if (state == 0) { /* looking for start of number */
				if (numeric) {
					state = 2; /* begin collecting number */
				} else if ((cc == '+') || (cc == '.')) {
					state = 1;
				} else if (cc == '-') {
					uminus = TRUE;
					state = 1;
				}
				if (state > 0) 
					numbuf[nbii++] = cc; /* get first character */
			} else if (state == 1) { /* possible stsrt of number */
				if (numeric) {
					state = 2; /* definitely collecting number */
					numbuf[nbii++] = cc;
				} else {
					nbii = uminus = state = 0; /* start over */
				}
			} else if (state == 2) { /* collecting number */
				if (numeric) {
					numbuf[nbii++] = cc; /* collect number */
				} else if (((cc == 'E') || (cc == 'e') || (cc == '.')) &&
					((numbuf[nbii-1] >= '0') && (numbuf[nbii-1] <= '9'))) {
					numbuf[nbii++] = cc; /* exponent/decimal point */
				} else 
					break; /* end of number */
				if (nbii >= 100) break; /* too big */
			} /* state else-if */
			cpos++; /* advance to next character */
		} else if (type == 3) {
		
			/* next expression */
			
			if (spos < 0)
				spos = cpos; /* starting position */
			if ((!parenc) && (!quotec))
				if ((cc == ',') || (cc == ';') || (cc == NEWLINE) ||
					(cc == '\0'))
					break; /* end of expression */
			if (!quotec) {
				if (cc == '(') parenc++;
				else if (cc == ')') parenc--;
			}
			if (cc == '"') quotec = (quotec ? 0: 1);
			cpos++; /* advance to next character */
		} /* type else-if */
    }; /* while */

	if ((type == 0) || (type == 1) || (type == 3)) {
	
    	/* return marker on word/line */

    	if (spos < 0) { /* never found start of word/line */
        	mx->pos = mx->doclen; /* zero length, at end */
        	mx->len = 0;
    	} else {
        	mx->pos = spos;
        	mx->len = cpos-spos;
    	} /* spos else */
	} else if (type == 2) {
	
		/* return numeric value */
		
		markP--; /* pop argument */
		if (nbii) { /* have numeric string to evaluate */
			nP = numbuf; /* over-use as error message buffer */
			numbuf[nbii] = 0; /* insure terminated */
			numeric = getnum(numbuf,&isfloat, &ivalue,&fvalue,&nP,&errn);
			if (numeric) {
				if (!isfloat) 
					fvalue = ivalue; /* convert integer->float */
			} else
				fvalue = 0.0;
		}
		*fresP++ = fvalue;
	}

} /* mvar_next_item */

/* ------------------------------------------------------------------- */

ex_zfilename() { xfilenm(0); } /* return file name */
ex_zfilepath() { xfilenm(1); } /* return file path */

static xfilenm(type) /* return file name or path */
int type; /* = 0 = file name, = 1 = file path */

{   char *strp; /* pointer to file name string */
    int slen; /* length of string */
    int findex; /* index in file table */
    int nind; /* additional increment to name */
    struct tutorfile FAR *tfp; /* pointer in file table */
    char fname[CTPATHLEN]; /* file name string */

    mvar_init(markP); /* initialize new temp marker */
    strp = NULL;
    slen = 0;
    findex = *(--iresP); /* get index in file table */
    
    /* look up file in file table */
    
    if (findex > 0) {
        tfp = (struct tutorfile FAR *)GetPtr(filesopen);
        tfp += findex;
        strp = &fname[0];
#ifdef MAC
        if (type == 0)
            strcpyf((char FAR *)strp,tfp->fRef.path);
        else {
            MacFilePath(&tfp->fRef,fname,CTPATHLEN);
        }
#else
        if (type == 0) {
            strcpyf((char FAR *)strp,tfp->fRef.path+tfp->fRef.nameInd);
        } else {
            *strp = '\0'; /* zero-length string */
            nind = 0; /* name at fRef.nameInd+nind */
#ifdef IBMPC
            strp[0] = tfp->fRef.drive+'a'-1; /* attach drive specifier */
            strp[1] = ':';
            strp[2] = '\0';
            nind = 2;
#endif
            strcatf((char FAR *)strp,tfp->fRef.path);
            fname[tfp->fRef.nameInd+nind] = '\0'; /* terminate before file name */
        }
#endif
        ReleasePtr(filesopen);
        KillPtr(tfp);
    } /* findex if */
    
    /* build marker containing file name or path */
    
    if (strp != NULL) {
#ifdef IBMPC
        uplow((char FAR *)strp); /* convert to lower case */
#endif
        slen = strlen(strp);
        InsertString(markP->doc,0L,(char FAR *)strp,(long)slen);
    }
    markP->pos = 0; /* wrap marker around string */
    markP->len = markP->doclen = slen;
    markP++; /* advance marker stack */
    return(0);

} /* xfilenm */

/* ------------------------------------------------------------------- */

ex_zlengthf() /* return length of file */

{   int findex; /* index in file table */
    struct tutorfile FAR *tfp; /* pointer in file table */
    long flen; /* length of file */
 
    flen = 0; /* pre-set no length */
    findex = *(--iresP); /* get index in file table */
    
    /* look up file in file table, get length */
    
    if (findex > 0) {
        tfp = (struct tutorfile FAR *)GetPtr(filesopen);
        tfp += findex;
        TUTORinq_file_info(&tfp->fRef,NEARNULL,&flen,NEARNULL,NEARNULL,NEARNULL);
        ReleasePtr(filesopen);
    } /* findex if */
    
    *iresP++ = flen; /* return length of file */

    return(0);

} /* ex_zlengthf */

/* ------------------------------------------------------------------- */

ex_zswidth() /* return width of image */

{	long regionID;
	int width,height;

	regionID = *(--iresP);
	TUTORinq_region_info(regionID,&width,&height);
	*iresP++ = width;
	
} /* ex_zswidth */
/* ------------------------------------------------------------------- */

ex_zsheight() /* return height of image */

{	long regionID;
	int width,height;

	regionID = *(--iresP);
	TUTORinq_region_info(regionID,&width,&height);
	*iresP++ = height;
		
} /* ex_zsheight */

/* ------------------------------------------------------------------- */

#ifdef ibm032
extern double lgamma();
double gamma(gv) double gv; { return(lgamma(gv)); }
#endif

ex_gamma() /* gamma function */

{   double x;

    x = gamma(*(fresP-1));
    if (x>88.0) x = Infinite;
    else x = exp(x);
    *(fresP-1) = x;

} /* ex_gamma */

/* ------------------------------------------------------------------- */

ex_zrgbn() /* return palette slot corresponding to RGB value */

{   
    *iresP++ = CTinq_closest_color(ExecWn,*(fresP-3),*(fresP-2),*(fresP-1), FALSE);
    fresP -= 3;

} /* ex_zrgbn */

/* ------------------------------------------------------------------- */

ex_zhsvn() /* return palette slot corresponding to HSV value */

{   
    *iresP++ = CTinq_closest_color(ExecWn,*(fresP-3),*(fresP-2),*(fresP-1), TRUE);
    fresP -= 3;

} /* ex_zhsvn */    
        
/* ------------------------------------------------------------------- */

ex_zlength() /* return size of unsubscripted array */

{   long length; /* length of array */

    length = *(iresP-1);
    iresP -= 3; /* remove type, address, length from stack */
    *(iresP-1) = length;

} /* ex_zlength */

/* ------------------------------------------------------------------- */

ex_bitcnt() /* count number set bits */

{
    *(iresP-1) = lcbitcnt(*(iresP-1));
        
} /* ex_bitcnt */

/* ------------------------------------------------------------------- */

long lcbitcnt(av)           /* bit count */
register long av;

{   register int i;         /* index */
    register long mask; /* mask for next bit */
    register int count;     /* count of bits set */

    count = 0;
    for(i=0; i<=31; i++) {
        mask = 1L << i;
        if (av & mask) count++;
    } /* for */
    return(count);

} /* lcbitcnt */

/* ------------------------------------------------------------------- */

ex_tsysvar() /* TXTYPE reserved word */

{   
    *iresP++ = *ex_binP++;
    exs_tsysvar();

} /* ex_tsysvar */

/* ------------------------------------------------------------------- */

exs_tsysvar() /* TXTYPE reserved word */
             /* compiled code call-able version */

{   int swi;    /* integer for switch */
    int fc,bc,wc;
    long rv; /* result value */
    int refc_last,refc_object; /* reference counts for validity checks */

    refc_object = 0; /* don't know reference count yet */
    swi = *(--iresP);
    switch (swi) {

    case ZEDIT:
        rv = exS.last_edit;
        refc_last = exS.last_edit_ref;
        refc_object = get_edit_ref(rv);
        break;

    case ZBUTTON:
        rv = exS.last_button;
        refc_last = exS.last_button_ref;
        refc_object = get_button_ref(rv);
        break;

    case ZSLIDER:
        rv = exS.last_slider;
        refc_last = exS.last_slider_ref;
        refc_object = get_slider_ref(rv);
        break;

    case ZDDE:
	rv = exS.last_dde;
	refc_last = exS.last_dde_ref;
	refc_object = get_dde_ref(rv);
        break;


    default:
	break;

    }  /* switch */

    if (refc_last != refc_object) /* check if object still valid */
        rv = 0;
    *iresP++ = rv;

} /* exs_tsysvar */

/* ------------------------------------------------------------------- */

ex_ztextsel()   /* selection region of edit panel */
    { arg_ztextmarker(0); }
ex_ztextvis()   /* visible region of edit panel */
    { arg_ztextmarker(1); }
ex_zeditbase()  /* portion of document being edited by edit panel */
    { arg_ztextmarker(2); }
ex_zhotsel() /* last hot text selected */
    { arg_ztextmarker(3); }

arg_ztextmarker(arg) /* get marker from edit panel */
int arg;    /* 0: selection, 1: visible, 2: body */

{   Memh hdrH; /* handle on object header */
    struct ebshdr FAR *hdrP; /* pointer to object header */
    Memh tpanel; /* handle on text panel */
    TextVDat FAR *tpp; /* pointer to text panel */
    TViewP tvp; /* pointer to TextView */
    long startSelect,lenSelect;
    struct markvar result; /* result marker */
    SBarInfo sinf; /* scroll bar info */
    DocP dp; /* pointer to document */
    
    tpanel = 0; /* no handle on panel yet */
    hdrH = *(--iresP); /* get handle on object header */
    if (hdrH) {
        hdrP = (struct ebshdr FAR *)GetPtr(hdrH);
        tpanel = hdrP->objectH; /* get handle on text panel */
        ReleasePtr(hdrH);
        KillPtr(hdrP);
    } /* hdrH if */
    
    mvar_zero((struct markvar SHUGE *) &result); /* clear result */
    
    if (tpanel == 0) {
        /* no text panel, result is zempty */
        ;
    } else {
        /* construct marker on edit document */
        tpp = (TextVDat FAR *) GetPtr(tpanel);
        tvp = (TViewP) GetPtr(tpp->textv);
        if ((arg != 3) || (tvp->hotPos >= 0)) {
            result.doc = tvp->doc;
            result.doclen = tvp->bounds.doclen;
        }
        
        if (arg == 0) { /* selection */
            TUTORinq_select_tview(tpp->textv,&startSelect,&lenSelect);
            result.pos = startSelect;
            result.len = lenSelect;
        } else if (arg == 1) { /* visible */
            _TUTORinfo_vbar_tview(tvp,&sinf);
            result.pos = sinf.rangePos;
            result.len = sinf.rangeLen;
        } else if (arg == 2) { /* base */
            result.pos = tvp->bounds.pos;
            result.len = tvp->bounds.len;
        } else if (arg == 3) { /* hot text selected */
            if (tvp->hotPos < 0) { 
                ; /* do nothing, return zempty */
            } else {
                result.pos = tvp->hotPos;
                result.len = tvp->hotLen;
            }
        } 
        
        dp = (DocP)GetPtr(tpp->textd); /* get document */
        if (result.pos+result.len > dp->totLen) {
            /* check if beyond document bounds (selection deleted) */
            result.pos = dp->totLen; /* zero length, at end */
            result.len = 0;
        }
        ReleasePtr(tpp->textd);
        KillPtr(dp);
        ReleasePtr(tpp->textv);
        KillPtr(tvp);
        ReleasePtr(tpanel);
        KillPtr(tpp);
    } /* tpanel else */

    if (result.doc == HNULL) /* no result */
        mvar_init((struct markvar SHUGE *)&result);
        
    *(markP++) = result;
    return(0);

} /* ex_ztextsel */

/* ------------------------------------------------------------------- */

ex_zhotinfoe() /* string associated with last hot text selected */

{   unsigned char FAR *strp; /* pointer to hot string */
    long slen; /* length of string */
    Memh hdrH; /* handle on object header */
    struct ebshdr FAR *hdrP; /* pointer to object header */
    long dmy; /* dummy for GetHotstringTStyle call */
    Memh tpanel; /* handle on text panel */
    TextVDat FAR *tpp; /* pointer to text panel */
    TViewP tvp; /* pointer to TextView */
    DocP dp; /* pointer to txtdoc */
    
    strp = NULL; /* no string yet */
    tpanel = slen = 0;
    hdrH = *(--iresP); /* get handle on object header */
    if (hdrH) {
        hdrP = (struct ebshdr FAR *)GetPtr(hdrH);
        tpanel = hdrP->objectH; /* get handle on text panel */
        ReleasePtr(hdrH);
        KillPtr(hdrP);
    } /* hdrH if */

    if (tpanel) {
        tpp = (TextVDat FAR *) GetPtr(tpanel);
        tvp = (TViewP) GetPtr(tpp->textv);
        if (tvp->idHot && (tvp->hotPos >= 0)) {
        dp = (DocP) GetPtr(tvp->doc);
            strp = GetHotstringTStyle(dp->styles,tvp->idHot,&slen,
                                  &dmy,&dmy,TRUE);
            ReleasePtr(tvp->doc);
            KillPtr(dp);
        }
        ReleasePtr(tpp->textv);
        KillPtr(tvp);
        ReleasePtr(tpanel);
        KillPtr(tpp);
    } /* tpanel if */

    mvar_init(markP); /* initialize new temp marker */
    if (strp) {
        InsertString(markP->doc,0L,(char FAR *)strp,(long)slen);
        TUTORdealloc((char FAR *) strp);
    }
    markP->pos = 0; /* wrap marker around string */
    markP->len = markP->doclen = slen;
    markP++; /* advance marker stack */

} /* ex_zhotinfoe */

/* ------------------------------------------------------------------- */

#ifdef NOSUCH
unsigned char FAR *GetHotstringTStyle(pd,id, len, spos, slen, getS) /* get hot text info string */
Memh pd;	/* the style structure */
int id;		/* the hot text id whose string we are looking for */
long *len;	/* returns the length of the string we found */
long *spos, *slen;	/* position and length of hot style */
int getS;	/* TRUE if we want to get string */
/* returns a TUTORalloc'ed string containing the hot text string (or FARNULL on error) */
#endif

ex_zhotinfom() /* information associated with "hot" marker */

{   struct markvar SHUGE *mx;
	struct markvar result; /* result marker */
    short styles[NSTYLES]; 
    int ii,si;
    long dmy; /* dummy for GetHotstringTStyle call */
    long spos; /* current position in result info string */
    long slen; /* length of hot info string */
    long totLen; /* length of accumulated hot info */
    DocP dp; /* pointer to txtdoc */
    unsigned char FAR *strp; /* pointer to hot string */
    int lastID; /* id of last hot text found */

    mx = --markP; /* marker to look at */
    strp = FARNULL; /* no string yet */
    spos = slen = totLen = 0; /* no length yet */
    lastID = 0; /* haven't found anything yet */
    mvar_init((struct markvar SHUGE *)&result); /* initialize new temp marker */
    result.pos = result.len = result.doclen = 0;
    
	for(ii=0; ii<markP->len; ii++) {
    	for(si=0; si<NSTYLES; si++) 
    		styles[si] = 0;
		tdoc_getstyles(markP->doc,markP->pos+ii,&styles[0]);
        if (styles[HOTSTYLE] && (styles[HOTSTYLE] != DEFSTYLE)) {
			if (styles[HOTSTYLE] != lastID) { /* new block of hot text */
            	dp = (DocP) GetPtr(markP->doc);
				lastID = styles[HOTSTYLE];
				strp = GetHotstringTStyle(dp->styles,lastID,&slen,
						&dmy,&dmy,TRUE);
				ReleasePtr(markP->doc);
				KillPtr(dp);
			    if (strp) {
        			InsertString(result.doc,totLen,(char FAR *)strp,(long)slen);
        			TUTORdealloc((char FAR *) strp);
        			totLen += slen;
        			result.len = result.doclen = totLen;
    			}	
			} /* lastID if */
        } /* styles if */          
    } /* for */
    
    *(markP++) = result; /* add result to marker stack */
    
} /* ex_zhotinfom */

/* ------------------------------------------------------------------- */

ex_zvalueb() /* value of button */

{   Memh objH; /* handle on object header */
    struct ebshdr FAR *objP; /* pointer to object header */
    Memh bh; /* handle on button */
    int value;

    value = bh = 0; /* pre-set in case no button */
    objH = *(--iresP); /* pop handle off integer stack */
    if (objH) {
        objP = (struct ebshdr FAR *)GetPtr(objH);
        bh = objP->objectH; /* get handle on button */
        ReleasePtr(objH);
        KillPtr(objP);
    } /* objH if */
    if (bh) {
        value = TUTORinq_button_value(bh);
        if (value) value = -1; /* convert to cT TRUE */
    }
    *iresP++ = value; /* result on integer stack */

} /* ex_zvalueb */

/* ------------------------------------------------------------------- */

ex_zvalues() /* value of slider */

{   Memh objH; /* handle on object header */
    struct ebshdr FAR *objP; /* pointer to object header */
    Memh sh; /* handle on slider */
    double value;

    value = 0.0; /* pre-set in case no slider */
    sh = 0;
    objH = *(--iresP); /* pop handle off integer stack */
    if (objH) {
        objP = (struct ebshdr FAR *)GetPtr(objH);
        sh = objP->objectH; /* get handle on button */
        ReleasePtr(objH);
    } /* objH if */
    if (sh) value = TUTORinq_slider_value(sh);
    *fresP++ = value; /* result on floating stack */

} /* ex_zvalues */

/* ------------------------------------------------------------------- */

ex_zddetext() /* information from DDE transfer */

{
    get_zddetext(); /* build marker containing text */

} /* ex_zddetext */

/* ------------------------------------------------------------------- */

ex_isysvar() /* integer reserved word */

{   
    *iresP++ = *ex_binP++;
    exs_isysvar();

} /* ex_isysvar */

/* ------------------------------------------------------------------- */

exs_isysvar() /* integer reserved word */
             /* compiled code call-able version */

{   int swi;    /* integer for switch */
    struct tutorColor fc,bc,wc;
    long downt,upt; /* down/up times for mouse */
    int irv; /* integer result value */
    long rv; /* result value */
    double dv;

    swi = *(--iresP);
    switch (swi) {

    case ZJCOUNT: 
        rv = jzjcount(); 
        break;
    case ZDEVICE: 
        rv = exS.zdevice;
        break;
    case ZKEY: 
        rv = exS.zkey;
        break;
    case ZEDITKEY:
    	rv = exS.zeditkey;
    	break;
    case ZEDITX:
    	dv = CoordToFloat(exS.zeditx);
    	rv = dv;
    	break;
    case ZEDITY:
    	dv = CoordToFloat(exS.zedity);
    	rv = dv;
    	break;
    case ZRETINF: 
        rv = exS.zretinf;
        break;
    case ZRETURN: 
        rv = exS.zreturn; 
        break;
    case ZRESHAPE: 
        rv = (exS.zreshape ? -1: 0); 
        break;
    case ZJUDGED: 
        rv = exS.arr.zjudged; 
        break;
    case ZANSCNT: 
        rv = exS.arr.zanscnt; 
        break;
    case ZCAPS: 
        rv = exS.arr.zcaps; 
        break;
    case ZENTIRE: 
        rv = exS.arr.zentire; 
        break;
    case ZEXTRA: 
        rv = exS.arr.zextra;
        break; 
    case ZNTRIES: 
        rv = exS.arr.zntries; 
        break;
    case ZOPCNT: 
        rv = exS.arr.zopcnt; 
        break;
    case ZVARCNT: 
        rv = exS.arr.zvarcnt;
        break;
    case ZORDER: 
        rv = exS.arr.zorder; 
        break;
    case ZSPELL: 
        rv = exS.arr.zspell; 
        break;
    case ZWCOUNT: 
        rv = exS.arr.zwcount;
        break;
    case ZHEIGHT: 
        rv = RoundCoord(exS.ScreenH); 
        break;
    case ZWIDTH: 
        rv = RoundCoord(exS.ScreenW); 
        break;
    case ZXPIXELS: 
        rv = RoundCoord(exS.ScreenW)-2*(exS.OffsetX-exS.ScreenX0);
        break; 
    case ZYPIXELS: 
        rv = RoundCoord(exS.ScreenH)-2*(exS.OffsetY-exS.ScreenY0); 
        break;
    case ZNCOLORS: 
#ifndef MAC
        rv = CTcount_colors(exS.oldcolor);
#else
        rv = Mac_Zncolors();
#endif
        break;
    case ZCOLORF:
    case ZCOLORB:
    case ZWCOLOR:
        TUTORget_colors(&fc,&bc,&wc);
        if (swi == ZCOLORF) rv = fc.palette;
        else if (swi == ZCOLORB) rv = bc.palette;
        else rv = wc.palette;
        break;
    case ZLEFTDOWN:
        rv = (TUTORinq_left_down() ? -1: 0);
        break;
    case ZRIGHTDOWN:
        rv = (TUTORinq_right_down() ? -1: 0);
        break;
    case ZVWIDTH:
	MovieInfo(&irv,NEARNULL,NEARNULL,NEARNULL);
    	rv = irv;
    	break;
    case ZVHEIGHT:
	MovieInfo(NEARNULL,&irv,NEARNULL,NEARNULL);
    	rv = irv;
    	break;
    case ZVCHEIGHT:
    	rv = movieCtrlH;
    	break;
    default:
	break;

    }  /* switch */

    *iresP++ = rv;

} /* exs_isysvar */

/* ------------------------------------------------------------------- */

ex_loopchk() /* check if time to interrupt and return to interact */

{	long timeVal;

#ifdef X11
	if (exS.outcnt > 10)
		exS.shouldint = TRUE;
#endif

	if (exS.loopcounter++ > 50) {
	    exS.loopcounter = 0;
		if ((((timeVal = quickCount())-quickLast) > quickVal) || exS.shouldint) {
    		quickLast = timeVal;
			if (shouldint()) {
            	return(1); /* 1 = interrupt */
        	}
    	}
    } /* loopcounter if */
    if (refnum > 5)
        mvar_temp_cleanup();
    return(0); /* 0 = don't interrupt */

} /* ex_loopchk */

/* ******************************************************************* */

ex_nofun() /* trap for missing function */

{   short fcode;

    fcode = *(--ex_binP);
    TUTORdump("Unimplemented command");

} /* ex_nofun */

/* ******************************************************************* */

