
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Execute cT pcode -- procedures for all relocatable commands
 and for those graphing command which use the same procedures
 as relocatable commands.

Judith N. Sherwood, CMU June 1985
*/

#include "execdefs.h"
#include "eglobals.h"

#ifdef ctproto
extern int  rboxrotate(double  x1,double  y1,double  x2,double  y2);
int  rfill(int  npoints,long  *fx,long  *fy);
int  rbox(int  tgiven,double  x1,double  y1,double  x2,double  y2,double  thick,int  scaleFirst);
int  rarc(int  type,long  xcenter,long  ycenter,double  radius,double  angle1,double  angle2,int  unbroken);
extern int  rboxframeit(double  x1,double  y1,double  x2,double  y2,double  thick);
int  relative_to_fine(double  rx,double  ry,long  *cx,long  *cy);
int  RelativeScale(long  fnx,long  fny,double  *cx,double  *cy);
long  FloatToCoord(double  zz);
int  TUTORfill_polygon(int  npoints,long  *fx,long  *fy);
int  TUTORfill_rectangle(long  x1,long  y1,long  x2,long  y2);
int  flush(void);
int  TUTORend_line(long  x,long  y);
int  TUTORline_to(long  x,long  y);
int  TUTORmove_to(long  x,long  y);
extern double sin(double x);
extern double cos(double x);
int  TUTORdraw_rectangle(long  x1,long  y1,long  x2,long  y2);
int  TUTORthick_box(long  x1,long  y1,long  x2,long  y2,long  thick,long  thickx,long  thicky);
extern double fabs(double x);
int  TUTORdraw_arc(int  calledby,long xc,long yc, double radius,long  x1,long  y1,
long  x2,long  y2, double  startAngle,double  stopAngle,int  unbroken);
int  TUTORfill_disk(int type,long xc,long yc,long  x1,long  y1,long  x2,long  y2);
#endif /* ctproto */

#ifdef macproto
int  TUTORdraw_line(long  x1,long  y1,long  x2,long  y2);
#endif

extern long  FloatToCoord();
extern double fabs();
extern double sin();
extern double cos();


static rboxrotate(x1,y1,x2,y2)  /* display single-line rotated box */
  double x1,y1,x2,y2 ;
 {
 double x3,y3, x4,y4 ;
 Coord cx1,cy1,cx2,cy2,cx3,cy3,cx4,cy4;

  x3 = x2 ;  y3 = y2 ;
  x4 = x1 ;  y4 = y2 ;
  y2 = y1 ;

  /* must get all 4 corner points before relative_to_fine because
      rotated points depend on both x & y */

  relative_to_fine(x1,y1,&cx1,&cy1) ;
  relative_to_fine(x2,y2, &cx2, &cy2 ) ;
  relative_to_fine(x3,y3, &cx3, &cy3 ) ;
  relative_to_fine(x4,y4, &cx4, &cy4 ) ;

  exS.ScreenX = cx1;
  exS.ScreenY = cy1;

  TUTORmove_to( cx1, cy1 ) ;
  TUTORline_to( cx2, cy2 ) ;
  TUTORline_to( cx3, cy3 ) ; 
  TUTORline_to( cx4, cy4 ) ;
  TUTORend_line( cx1, cy1);

  exS.outcnt += 5 ;   OUTGO ;
 }
 

/***************   rfill   **************************/
/* execution of both rfill & rerase                                 */
/* when done, zwherex, zwherey are set to first point mentioned  */

rfill(npoints, fx, fy)
register int npoints ;
Coord  fx[], fy[] ; /* already in fine coords */
	{
	register int i ;

	if ( npoints == 2 && exS.RAngle != 0 )
		{		/* rotated rectangle */
		
		/* we assumme that we can use fx[3] and fx[4]!!! */
		
		double rx[5], ry[5];
		RelativeScale(fx[1],fy[1],&rx[1],&ry[1]);
		fy[3] = fy[2] ;   fx[3] = fx[2]; 
		RelativeScale(fx[3],fy[3],&rx[3],&ry[3]);
		rx[2] = rx[3]; ry[2] = ry[1];
		rx[4] = rx[1]; ry[4] = ry[3];
		relative_to_fine(rx[2],ry[2],&fx[2],&fy[2]);
		relative_to_fine(rx[4],ry[4],&fx[4],&fy[4]);
		npoints = 4 ;
		}

	exS.ScreenX = fx[1] ;    
	exS.ScreenY = fy[1] ;

	if( npoints == 2)	/* non-rotated rectangle */
		TUTORfill_rectangle( fx[1], fy[1], fx[2], fy[2] ) ; 
	else
		TUTORfill_polygon(npoints, fx, fy) ;
	}

rbox(tgiven, x1,y1,x2,y2,thick,scaleFirst)
/* expects relative coords */
/* ScreenX, ScreenY on completion are first point mentioned */

double x1,y1, x2,y2, thick ;
int tgiven;  /* TRUE if thickness given specifically */
int scaleFirst; /* TRUE if first point needs scaling */

	{
	Coord thickx, thicky ;
	Coord fx[5], fy[5] ; /* need to be of length 5 for call to rfill */
	Coord c1, c2, c3, c4;

	if (scaleFirst)
		relative_to_fine(x1, y1, &c1, &c2) ;
	else
		{ /* first point was in fine coords */
		c1 = x1;
		c2 = y1;
		RelativeScale(FloatToCoord(x1),FloatToCoord(y1),&x1,&y1);
		}
	relative_to_fine(x2, y2, &c3, &c4) ;
	exS.ScreenX = c1;
	exS.ScreenY = c2;

	if (thick==0)
		return(0);
	if ((exS.RXsize==0) || (exS.RYsize==0))
		return(0);
  
	/* is thick large enough to fill entire box? */
	if (thick < 0) 
		{
		if ( ( fabs(thick) > (fabs(x1-x2)+1)/2)  ||  ( fabs(thick) > (fabs(y1-y2)+1)/2) )
			{
			fx[1] = c1; fy[1] = c2;
			fx[2] = c3; fy[2] = c4;
 			rfill(2, fx, fy);
            return (0); 					 /* exit */
           }
       }

	/** special exit conditions finished **/

	if(exS.RAngle != 0)
		{ /* rotated relative boxes */ 
		if  (tgiven)
			rboxframeit(x1,y1, x2,y2, thick) ;
		else
			rboxrotate(x1,y1, x2,y2);
		}
	else
		{
		if (tgiven)
			{
			thickx = FloatToCoord((exS.RXsize == 1) ?  thick  :  thick * fabs(exS.RXsize));
			thicky = FloatToCoord((exS.RYsize == 1) ?  thick  :  thick * fabs(exS.RYsize)); 
			TUTORthick_box(c1,c2,c3,c4, FloatToCoord(thick), thickx, thicky) ;
			}
		else
			TUTORdraw_rectangle(c1,c2,c3,c4) ;
		}
	
	return(0);
	}

/*****************  rcircle & rdisk  ******************/

rarc(type, xcenter, ycenter, radius, angle1, angle2, unbroken)
  int type ;  		/* 1 if circle, 2 if arc, 3 if disk */
         /* circle/arc distinction useful for postscript */
  Coord xcenter, ycenter;
  double radius ;
  double angle1, angle2 ;	 /* angle1 and angle2 are in degrees */
  int unbroken ;		 /* true if -rcircle-, false if -rcircleb- */
	{
	Coord x1, y1, x2, y2;

  /* note that this procedure does not include any scaling for the
     -rorigin-, because that is already included in xcenter,ycenter  */

  if (radius == 0.0) return(0);
  if (angle1 == angle2) return(0);

  /* after circle, position at center; after arc, position at end of arc */
  if (type == 2)
       {exS.ScreenX = xcenter + FloatToCoord(exS.RXsize*radius*cos(angle2*RDN));
         exS.ScreenY = ycenter + FloatToCoord(exS.RYsize*radius*sin(angle2*RDN));
        }
  else
       {exS.ScreenX = xcenter ;
         exS.ScreenY = ycenter ;
        }

  x1 = xcenter-FloatToCoord(exS.RXsize*radius);
  y1 = ycenter-FloatToCoord(exS.RYsize*radius);
  x2 = xcenter+FloatToCoord(exS.RXsize*radius);
  y2 = ycenter+FloatToCoord(exS.RYsize*radius);

 if ( type == 3 )
     TUTORfill_disk(0,xcenter,ycenter,x1, y1, x2, y2);
 else
     TUTORdraw_arc(3, xcenter, ycenter, radius,x1, y1, x2, y2, angle1, angle2, unbroken); 
 }

/************* rboxframeit **************/

static rboxframeit(x1,y1, x2,y2, thick)     /* display thick rotated box  */
double x1,y1, x2,y2, thick ;
	{
	double cornerx[5], cornery[5];
	Coord  tempx[5], tempy[5];
	register int ii,jj,kk;
	register int adjust;
	Coord boxx[11], boxy[11] ;
	int offset[5];

	/* we will draw box by filling 4 polygons, which look like the pieces
		of a picture frame.  So each polygon will have 4 vertices:
		outer corner & matching inner corner, then outer corner (on same side) and
		matching inner corner.  We store the fine coords in boxx and boxy in the order:
		outer, inner, outer, inner, etc. */
	
	/* calculate outer corners */
	adjust = (thick > 0 )  ?  thick-1  :  0 ;
	cornerx[1] = x1-adjust; cornery[1] = y1-adjust;
	cornerx[2] = x2+adjust; cornery[2] = y1-adjust;
	cornerx[3] = x2+adjust; cornery[3] = y2+adjust;
	cornerx[4] = x1-adjust; cornery[4] = y2+adjust;
	for (ii=1; ii<=4; ii++)
		relative_to_fine(cornerx[ii],cornery[ii],&boxx[2*ii-1],&boxy[2*ii-1]);

	/* set corners of inner box */
	adjust = (thick > 0 )  ?  0  :  (-thick - 1);
	cornerx[1] = x1+adjust; cornery[1] = y1+adjust;
	cornerx[2] = x2-adjust; cornery[2] = y1+adjust;
	cornerx[3] = x2-adjust; cornery[3] = y2-adjust;
	cornerx[4] = x1+adjust; cornery[4] = y2-adjust;
	for (ii=1; ii<=4; ii++)
		relative_to_fine(cornerx[ii],cornery[ii],&boxx[2*ii],&boxy[2*ii]);
	
	/* wrap around the coordinates of first outer & first inner vertices */
	boxx[9] = boxx[1];
	boxy[9] = boxy[1];
	boxx[10] = boxx[2];
	boxy[10] = boxy[2];

	/* draw the four polygons */
	offset[1] = 1; offset[2] = 2; offset[3] = 4; offset[4] = 3;
	for (ii=0; ii<4; ii++)
		{
		/* copy correct vertices into tempx, tempy */
		for (jj=1; jj <= 4; jj++) {
			kk = (2*ii)+offset[jj];
			tempx[jj] = boxx[kk];
			tempy[jj] = boxy[kk];
		} /* for */
#ifdef MAC
		if (exS.mode == xormode)
			TUTORdraw_line(tempx[1],tempy[1],tempx[2],tempy[2]);
#endif
		TUTORfill_polygon(4,tempx,tempy);
		/* note that TUTORfill_polygon has destroyed tempx, tempy values */
		}
	
	OUTGO ;
	}
