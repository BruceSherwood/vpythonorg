
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989,1992 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* ******************************************************************* */

#define STRICT
#include <windows.h>
#include <commdlg.h>
#include <dos.h>
#include <stdlib.h>
#include <string.h>
#include <direct.h>

#include "baseenv.h"
#include "ctmsw.h"
#include "tglobals.h"
#include "kglobals.h"
#include "txt.h"
#include "kdefs.h"
#include "ct_ctype.h"
#include "compute.h"
#include "eglobals.h"
#include "ecglobal.h"
#include "chardef.h"

/* ******************************************************************* */

#ifdef ctproto 
extern void cTReleaseDC(HWND hWnd,HDC hDC);
extern HDC cTGetDC(HWND hWnd);
extern char FAR *strncpyf(char FAR *aa,char FAR *bb,int len);  
extern int uplow(char FAR *str);  
extern int TUTORpalette_init(void);
extern int post_toedit(void);
extern int TUTORdevice_color(HDC hdc);   
extern int CTinit_old_default_palette(void);      
extern int CTinit_default_palette(void);
extern int TUTORzero(char FAR *zz,long len);
extern int TUTORblock_move(char SHUGE *ff,char SHUGE *tt,long len);
extern Memh TUTORalloc_palette(int nColor);
extern int  CTset_color_entry(struct  CTcolorentry FAR *cep,unsigned int  rr,unsigned int  gg,unsigned int  bb,int  ff,int  bf,int  res);
extern int cTOrderPalette(struct CTcolorentry FAR *cTPaletteP);
extern int fpc_clear_bitmap_cache(void);    
extern int TUTORnormal_cursor(void);
extern int TUTORclose(int findx);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
extern int TUTORlog(char *ss);
extern Memh LoadTable(char *tableFile,int *tableSize);
static void del_win_menu(Memh barH);
static void dup_pal(HPALETTE palH);
extern char *skip_white(char *sptr);
extern int fpc_add_bitmap_cache(Memh ftH,int charI,int type,HBITMAP mapH,struct pccharl *pDef);
extern HDC fpc_mem_dc(int type);
extern HBRUSH fpc_brush(int pattF,int pattC,int invertF);
extern int strncmpf(char FAR *aa,char FAR *bb,int nn);
extern int strcmpf(char FAR *aa,char FAR *bb);
extern Memh read_fpc(FileRef FAR *fpcPath);
extern char FAR *fpc_char(struct pcfont FAR *fpcP,long charI,
			  struct pccharl *charDef);
extern int fpc_draw_char(struct pcfont FAR *ftP,struct pccharl *charDef,
			 char FAR *bitP);
extern char  FAR *strcpyf(char	FAR *aa,char  FAR *bb);
extern char  FAR *strcatf(char	FAR *aa,char  FAR *bb);
extern int TUTORchecksum(char FAR *addr,long length);
extern int TutorDeleteCard(Memh barh,int cardI);
extern int MenuNames(unsigned int mbar,int item,char *cardName,char *itemName);
extern int cTRegisterWindow(HWND hWnd,int cTtype,int cTindex,int cmdN,Memh infH);
extern int TUTORset_hsize(unsigned int	mm,long newsize,int abort);
extern unsigned int TUTORhandle(char *name,long size,int purgewmrm);
extern int TUTORdone_startup(void);
extern int TUTORstart_menubar(unsigned int  barh);
extern int TUTORforward_window(int wix);
extern long TUTORadd_ffamily(struct  _fref *famName,int	isSys,int  isSwitch);
extern long TUTORparse_font_family(struct  _fref *fontTag,struct  _fref *familyName,int  isFont,int  oneTag,int  *fontSize);
extern int TUTORinq_abs_string_width(unsigned char  FAR *s,int  lth,int  *dx);
extern int TUTORtrace(char *str);
extern int TUTORset_abs_clip_rectangle(int x1,int y1,int x2,int y2);
extern int TUTORdraw_abs_solid_rect(TRect FAR *tr,int color);
extern int TUTORinq_abs_screen_size(int *x,int *y,int *dx,int *dy);
extern int TUTORinq_abs_pen_pos(int *x,int *y);
extern int TUTORabs_line_to(int xx,int yy);
extern int TUTORdump(char *s);
extern int  TUTORpost_event(struct  tutorevent *event);
extern int TUTORpoll_events(int block);
extern int TUTORdealloc(char  FAR *ptr);
extern int start_executor(void);
extern int  ReleasePtr(unsigned int  mm);
extern char  FAR *GetPtr(unsigned int  mm);
extern int TUTORcopy_fileref(FileRef FAR *fDest,FileRef FAR *fSource);
extern int TUTORcmp_fileref(FileRef FAR *f1,FileRef FAR *f2);
extern int TUTORcopy_fileref_name(FileRef FAR *fRef,char FAR *name);
extern int TUTORcopy_fileref_dir(FileRef FAR *dirname,FileRef FAR *fullname);
extern int  TUTORcvt_path(char	*ssx,struct  _fref FAR *fRef,struct  _fref FAR *baseRef,int isFile);
extern char  *strf2n(char  FAR *strp);
extern char  *strnf2n(char  FAR *strp,int  nn);
extern int TUTORstartup(int argc,char **argv,FileRef FAR *filenameR);
extern void initialFileDialog(HWND ww,char *fn);
#endif /* ctproto */

/* ******************************************************************* */

extern HANDLE hcTInst ; /* current instance of cT */
extern HWND FirstWinH; /* first window created in ctauth */
extern HWND CurrentWinH; /* handle on current window */
extern HDC CurrentDC; /* current window's device context */
extern int HaveDC; /* TRUE if have device context */
extern HPEN OriginalPen; /* handle on original pen */
extern HBRUSH hbrWhite; /* handle on stock white brush */
extern HBRUSH hbrBlack; /* handle on stock black brush */
extern HCURSOR ExecCursor; /* handle on executor-created cursor */
extern HPALETTE wPalH; /* handle on Windows logical palette */
extern int havePalette; /* TRUE if palette-based display */
extern int paletteNcolors; /* number colors in device palette */
extern int paletteNresv; /* number colors reserved by system */
extern jmp_buf mainenv; /* saved environment for longjmp */
extern int tDump; /* TRUE if crashed (TUTORdump called) */
extern int KeepRunning; /* TRUE if still alive */
extern char FAR *_pgmptr;
extern long scrBitSize; /* scratch bitmap size */
extern Memh scrBitH; /* handle on scratch bitmap */
extern Memh sysLogPalH; /* default Windows start-up palette */
extern int MillionsColor; /* TRUE if TrueColor */
extern int ReadOnlyColor; /* TRUE if static color */
extern Memh editmenus;
extern Memh helpmenus;
extern Memh dictmenus;
extern Memh paletteUseH; /* palette usage table */
extern Memh thePaletteH; /* logical palette */
extern char *ziconsStr;
extern char *zcursorsStr;
extern char *zpatternsStr;

extern char *kZsans;
extern char *kZserif;
extern char *kZfixed;
extern char *kZsymbol;

/* ******************************************************************* */

static char ofnFilter[] = {
		 "cT        (*.ctb)\0*.ctb\0" \
         "All Files (*.*)\0*.*\0\0"} ;

/* ******************************************************************* */

TUTORstartup(argc,argv,filenameR)
int argc;
char **argv; 
FileRef FAR *filenameR;

{   int i; /* work variables */
    FileRef cwd; /* path to current directory */
    char FAR *DOScmdLineP; /* pointer to command line arguments */
    char cmdLine[130]; /* copy of command line */
    char *cmdP; /* pointer in command line */
    int flen; /* length of file name */
    int aii; /* index to command arguments */
    char fileN[130]; /* file name from command line */

    /* initialization of variables altered by command line options */

    nosourcelayout = logevents = playevents = CompileAndExit = 0;
    lforkf = FALSE;
    twf = FALSE;        /* turn off trace window debug stuff */
    spyf = FALSE;       /* turn off profiling */
    codegen = FALSE;    /* no compiled code */

    /* set up FileRef for cT */

    TUTORcvt_path(strf2n(_pgmptr),ctDirP, (FileRef FAR *)FARNULL,TRUE);

    /* set up FileRef for current working directory */

    cwd.drive = _getdrive();
    _getcwd(cwd.path,FILEL);
    if (cwd.path[1] == ':')
        strcpy(cwd.path,cwd.path+2); /* get rid of drive specifier */
    i = strlen(cwd.path);
    if (cwd.path[i-1] != '\\') { /* path should terminate with \ */
        cwd.path[i] = '\\';
        i++; /* adjust length */
        cwd.path[i] = '\0'; /* insure null termination */
    }
    cwd.nameInd = i;

    /* set up FileRef for source file */

    TUTORcopy_fileref(filenameR,(FileRef FAR *) &cwd);

    /* process command line arguments */

    DOScmdLineP = GetCommandLine();
    flen = strlenf(DOScmdLineP);
    strcpyf((char FAR *)&cmdLine[0],DOScmdLineP);
    uplow((char FAR *)&cmdLine[0]); /* convert to lower case */
    cmdP = cmdLine;
    while(*cmdP) {
        if (*cmdP == '"')
            strcpy(cmdP,cmdP+1); /* eliminate quote mark */
        else cmdP++; /* advance thru string */
    }

    /* check if begins with path to executable */

    aii = 0;
    while (cmdLine[aii] && (strncmp(&cmdLine[aii],".exe",4) != 0))
        aii++;
    if (cmdLine[aii]) { /* found .exe */
        aii += 4; /* advance to arguments */
    } else aii = 0; /* assume only have arguments */

    /* handle arguments */

    cmdP = skip_white(&cmdLine[aii]);
    while (*cmdP == '/') { /* command line argument */
	    cmdP++;
	    if (strncmp(cmdP,"compile",7) == 0) {
	        CompileAndExit = 1;  /* set to compile program and exit */
	        cmdP += 7; /* advance past argument */
	    }
	    cmdP = skip_white(cmdP);
    } /* while */

    cmdP = skip_white(cmdP);
    flen = strlen(cmdP);
    strncpy(&fileN[0],cmdP,flen); /* get file name */
    fileN[flen] = 0;
    fileSpecified = 1;
    if (fileN[0] == 0) {
	initialFileDialog(FirstWinH,fileN); /* get file name */
	fileSpecified = 3;
	if (!fileN[0]) {
	    fileSpecified = 0;
#ifdef EXECUTE
		myexit();
#endif
#ifndef CTEDIT
		strcpy(fileN,"untitled"); /* set default name */
		fileSpecified = 7; /* untitled new file */
#else
		strcpy(fileN,"untitled.c"); /* set default name */
#endif
	}
    }
    if ((fileN[0] == '\\') || (fileN[1] == ':'))
	TUTORcvt_path(fileN,(FileRef FAR *) filenameR, (FileRef FAR *)FARNULL,TRUE);
    else
	TUTORcopy_fileref_name(filenameR,(char FAR *)&fileN[0]);

    /* sourceDir and currentDir are both set to where source was found */
    TUTORcopy_fileref_dir(sourceDirP,(FileRef FAR *)filenameR);
    TUTORcopy_fileref_dir(currentDirP,(FileRef FAR *)filenameR);
   
    /* initialize scratch area for creating bitmaps */

    scrBitSize = 128; /* initial size of area */
    scrBitH = TUTORhandle("scrbit",scrBitSize,TRUE);
          
    quickVal = 350; /* timeslice check at 350 milliseconds */
    
    TUTORpalette_init();
    return(0);

} /* TUTORstartup */

/* ******************************************************************* */

static void initialFileDialog(hWnd,ifile) /* obtain initial file name */
HWND hWnd; /* parent window for dialog */
char *ifile; /* returned with file name */

{   int ofRet; /* return from OpenFile */
    int nii; /* index in file name */
#ifdef EXECUTE
	OPENFILENAME ofn; /* open-file dialog info */    
#endif

    for(nii=0; nii<FILEL; nii++)
	ifile[nii] = 0;
    ofRet = 0; /* pre-set failed */

#ifdef EXECUTE

    /* set up GetOpenFileName data structure */

    ofn.lStructSize	  = sizeof(OPENFILENAME);
    ofn.hwndOwner	  = hWnd;
    ofn.hInstance	  = NULL;
    ofn.lpstrFilter	  = ofnFilter;
    ofn.lpstrCustomFilter = NULL;
    ofn.nMaxCustFilter	  = 0;
    ofn.nFilterIndex	  = 0;
    ofn.lpstrFile	  = (LPSTR)ifile;
    ofn.nMaxFile	  = FILEL;
    ofn.lpstrFileTitle	  = NULL;
    ofn.nMaxFileTitle	  = FILEL;
    ofn.lpstrInitialDir   = NULL;
    ofn.lpstrTitle	  = NULL;
    ofn.Flags		  = OFN_PATHMUSTEXIST;
    ofn.nFileOffset	  = 0;
    ofn.nFileExtension	  = 0;
    ofn.lpstrDefExt	  = "ctb";
    ofn.lCustData	  = 0L;
    ofn.lpfnHook	  = NULL;
    ofn.lpTemplateName	  = NULL;

    ofRet = GetOpenFileName(&ofn); /* do dialog */
#endif

    if (!ofRet) { /* failed */
	ifile[0] = 0; /* ensure no file name */

    }
    return;

} /* initialFileDialog */

/* ******************************************************************* */

int TUTORdone_startup() /* end of initializations */

{
#ifdef AUTHOR
    post_toedit(); /* be sure editor gets control */
#endif

    return(0);

} /* TUTORdone_startup */

/* ******************************************************************* */

int TUTORcolor_init() /* one-time color initializations */

{   HDC hdc; /* device context */

    hdc = cTGetDC(FirstWinH);
    TUTORdevice_color(hdc); /* get color properties for window device */
    cTReleaseDC(FirstWinH,hdc);

    /* initialize cT default palettes */

    CTinit_default_palette();
    CTinit_old_default_palette();

    return(0);

} /* TUTORcolor_init */

/* ******************************************************************* */

int TUTORdevice_color(hdc) /* get color properties for device */
HDC hdc; /* device context */

{   int deviceAttr; /* current device attribute */

    paletteNcolors = SysPal = 0; /* don't know number colors yet */
    paletteNresv = 0;
    SysColors = 20; /* assume standard 20 colors reserved */
    deviceAttr = GetDeviceCaps(hdc,RASTERCAPS);
    if (deviceAttr & RC_PALETTE) {
        havePalette = TRUE;
	SysColors = SysPal = paletteNcolors = GetDeviceCaps(hdc,SIZEPALETTE);
        paletteNresv = GetDeviceCaps(hdc,NUMRESERVED);
        paletteNcolors -= paletteNresv;
	if (paletteNcolors > 256)
	    paletteNcolors = 256; /* clamp to 256 colors */
        if (paletteNcolors <= 0)
            paletteNcolors = paletteNresv;
    } else { /* not a palette device */
	deviceAttr = GetDeviceCaps(hdc,BITSPIXEL);
	if (deviceAttr < 1) deviceAttr = 1;
	/* not a palette device, more than 8 bits/pixel - TrueColor? */
	if (deviceAttr > 8) {
	    if (deviceAttr >= 15) {
		SysColors = 0x7fff;
	    } else
		SysColors = 1 << deviceAttr;
	    MillionsColor = TRUE;
	} else SysColors = 1 << deviceAttr;
	deviceAttr = GetDeviceCaps(hdc,NUMCOLORS);
	if (deviceAttr > SysColors)
	    SysColors = deviceAttr;
    }
    if (SysColors <= 20)
	ReadOnlyColor = TRUE; /* windows colors only */

    return(SysColors);

} /* TUTORdevice_color */

/* ******************************************************************* */

static int TUTORpalette_init() /* read up copy of system palette */

{   int fsize,tmpSize; /* size of palette */
    Memh tmpH; /* handle on mem block */
    char FAR *tmpP; /* pointer to mem block */
    LOGPALETTE FAR *logP; /* pointer to logical palette */

    fsize = sizeof(LOGPALETTE)+(256*sizeof(PALETTEENTRY));
    thePaletteH = TUTORhandle("thepal",fsize,TRUE);
    paletteUseH = TUTORhandle("paluse",256L,TRUE);
    if (paletteUseH) {
		tmpP = GetPtr(paletteUseH);
		TUTORzero(tmpP,256L);  /* initialize slot usage table */
		ReleasePtr(paletteUseH);
    }

    /* get default Windows start-up palette */

    tmpH = LoadTable("system.pal",&tmpSize);
    if (tmpH) {
		tmpP = GetPtr(tmpH);
		logP = (LOGPALETTE FAR *)(tmpP+0x14); /* skip RIFF header */
		TUTORblock_move((char SHUGE *)logP,(char SHUGE *)tmpP,(long)fsize); /* move logpal to begin of block */
		ReleasePtr(tmpH);
		TUTORset_hsize(tmpH,fsize,TRUE); /* resize to logical palette size */
		sysLogPalH = tmpH;
    }
    return(0);

} /* TUTORpalette_init */

/* ******************************************************************* */

Memh initial_palette()

{   Memh initPalH; /* handle on editor palette */
    struct CTcolorentry FAR *initPalP; /* pointer to edit palette */
    int pii; /* index in palettes */
    LPLOGPALETTE sysLogPalP; /* pointer to original system palette */
    LPPALETTEENTRY wPalP; /* pointer to logical palette entry */

    if (!sysLogPalH)
	return(0);
    initPalH = TUTORalloc_palette(256);
    if (!initPalH)
	return(0);

    sysLogPalP = (LPLOGPALETTE)GetPtr(sysLogPalH);
    initPalP = (struct CTcolorentry FAR *)GetPtr(initPalH);
    for(pii=0; pii<256; pii++) {
	wPalP = &sysLogPalP->palPalEntry[pii];
	CTset_color_entry(initPalP+pii,wPalP->peRed << 8,
			  wPalP->peGreen << 8,
			  wPalP->peBlue << 8,
			  0,0,FALSE);
	(initPalP+pii)->realV = pii;
    } /* for */
    cTOrderPalette(initPalP); /* sort so zred, etc. work */
    ReleasePtr(initPalH);
    ReleasePtr(sysLogPalH);

    return(initPalH);

} /* initial_palette */

/* ******************************************************************* */

int TUTORinstall_fonts()

{   HFONT fontH; /* handle on Windows font */  
	char fPath[256]; /* path to *.fon files */
    char actual_face[256]; /* face name of font obtained */
    char *fontNs[] = { kZfixed,"zfixedb","zfixedbi","zfixedi",
		      kZsans,"zsansb","zsansbi","zsansi",
		      kZserif,"zserifb","zserifbi","zserifi",
		      kZsymbol,NEARNULL};  
	FileRef cTRef; /* FileRef for cT */ 
	FileRef theFile; /* *.fon file */
    int fii; /* index in fonts/files */
    int retN; /* return, number fonts installed */     
 
   /* set up FileRef for cT */

    TUTORcvt_path(strf2n(_pgmptr),(FileRef FAR *)&cTRef,(FileRef FAR *)FARNULL,TRUE);

    /* get device context if don't already have it */

    if (!HaveDC) {
		CurrentDC = cTGetDC(FirstWinH);
    }

    /* check if zserif font already installed */

    ExactMatchFont = FALSE; /* assume we won't find it */
    fontH = CreateFont(
	    15,  /* character height */
	    8,	 /* character width */
	    0,	 /* angle of line of text */
	    0,	 /* angle of character baseline */
	    400, /* character weight 400=normal, 700=bold */
	    0,	 /* TRUE if italic */
	    0,	 /* TRUE if underlined */
	    0,	 /* TRUE if characters struck out */
	    0,	 /* character set type (ANSI, OEM) */
	    0,	 /* closeness of character match */
	    0,	 /* type of clipping */
	    PROOF_QUALITY, /* always PROOF_QUALITY for CT */
	    FF_ROMAN | VARIABLE_PITCH, /* fixed, prop, modern, roman, etc */
	    (LPSTR)kZserif); /* face name */
    if (fontH) {
		SelectObject(CurrentDC,(HGDIOBJ)fontH);
		GetTextFace(CurrentDC,80,(LPSTR)&actual_face[0]);
		if (strcmp(actual_face,kZserif) == 0) {
	    	ExactMatchFont = TRUE;
	    	return(TRUE);
		}
    } 
    
	/* check if zserif is in cT directory */
    
    TUTORcopy_fileref_dir((FileRef FAR *) &theFile,(FileRef FAR *)&cTRef); 
    strcpy(fPath,theFile.path);
    TUTORcopy_fileref_name((FileRef FAR *) &theFile,(char FAR *)"zserif.fon");
    fii = TUTORopen((FileRef FAR *) &theFile,TRUE,FALSE,FALSE);   
    if (fii > 0) TUTORclose(fii);
    if (fii <= 0) {        
    
    	/* check if zserif is in ct/fonts directory */  
    	
    	strcat(fPath,"fonts\\");    
    	strcpy(theFile.path,fPath);
    	strcat(theFile.path,"zserif.fon");
    	fii = TUTORopen((FileRef FAR *) &theFile,TRUE,FALSE,FALSE);   
    	if (fii > 0) TUTORclose(fii);
       	else fPath[0] = 0; /* give up and use whatever directory we're in */     
    }

    fii = 0; /* index in font file names */
    while (fontNs[fii]) {   
    	actual_face[0] = theFile.drive+'A'-1;
    	actual_face[1] = ':';
    	actual_face[2] = 0;
    	strcat(actual_face,fPath);
		strcat(actual_face,fontNs[fii]);
		strcat(actual_face,".fon");
		retN = AddFontResource((LPSTR)actual_face);
		fii++;
    }
    return(TRUE);

} /* TUTORinstall_fonts */

/* ******************************************************************* */

int TUTORgraf_done() /* final cleanup at shutdown */

{   int ii;
    HDC hdc; /* handle on device context */
    HWND hWnd; /* handle on window */
    HPEN hPen; /* handle on current pen */
    HPALETTE hPal; /* handle on current palette */
    struct tutorfont FAR *fp; /* pointer in font table */

	if (!windowsP)
		return(0); /* didn't get far enough */
    fpc_mem_dc(0); /* release memory device context */
    fpc_clear_bitmap_cache(); /* dump contents of cache */
    if (HaveDC) { /* release device context */
        cTReleaseDC(CurrentWinH,CurrentDC);
    }

    /* destroy executor-created cursor */

    if (ExecCursor) {
	TUTORnormal_cursor();
	DestroyCursor(ExecCursor);
    }

    /* destroy palettes, pens, windows etc. */

    for(ii=0; ii<WINDOWLIMIT; ii++) {
	hWnd = (HWND)windowsP[ii].wp;
	if (hWnd) {
	    hdc = cTGetDC(hWnd);
	    if (OriginalPen) {
		hPen = SelectObject(hdc,OriginalPen);
		DeleteObject(hPen);
	    }
	    cTReleaseDC(hWnd,hdc);
	    DestroyWindow(hWnd);
	    hPal = (HPALETTE)windowsP[ii].winPalH;
	    if (hPal) {
		dup_pal(hPal); /* remove duplicate references */
		DeleteObject(hPal);
	    }
	} /* hWnd if */
    } /* for */

    /* delete fonts */

    fp = (struct tutorfont FAR *)GetPtr(fontsH);
    for(ii=0; ii<nfonts; ii++) {
	if (fp->fID && (fp->datType == 0) && (fp->fptr))
	    DeleteObject((HGDIOBJ)fp->fptr);
	fp++;
    }
    ReleasePtr(fontsH);

    /* delete menus not attached to windows */

    if (EditWn[0] < 0)
	del_win_menu(editmenus);
#ifndef CTEDIT
    if (HelpWn < 0)
	del_win_menu(helpmenus);
    if (DictWn < 0)
	del_win_menu(dictmenus);
#endif
    if ((ExecWn < 0) || (windowsP[ExecWn].menus != exS.execmenus))
	del_win_menu(exS.execmenus);
    if ((ExecWn < 0) || (windowsP[ExecWn].menus != grapheditmenus))
	del_win_menu(grapheditmenus);

    return(0);

} /* TUTORgraf_done */

/* ******************************************************************* */

static void dup_pal(palH) /* eliminate duplicate palette references */
HPALETTE palH;

{   int ii;

    if (!palH) return;

    for(ii=0; ii<WINDOWLIMIT; ii++) {
	if (windowsP[ii].wp && ((HPALETTE)windowsP[ii].winPalH == palH))
	    windowsP[ii].winPalH = HNULL;
    }
    return;

} /* dup_pal */

/* ******************************************************************* */

static void del_win_menu(barH)
Memh barH; /* handle on menu bar structure */

{   TutorMenuBar FAR *barP; /* pointer to menu bar structure */

    if (!barH) return;
    barP = (TutorMenuBar FAR *)GetPtr(barH);
    if (barP->menubarH) {
	DestroyMenu((HMENU)barP->menubarH);
    }
    ReleasePtr(barH);
    return;

} /* del_win_menu */

/* ******************************************************************* */

extern HANDLE hcTInst ; /* current instance of cT */

Memh LoadTable(tableFile,tableSize) /* read up a copy of a cT data table */
char *tableFile; /* file name */
int *tableSize; /* size of table */

{   FileRef theFile; /* table file reference */
    int fii; /* index of file */
    long fsize; /* size of file */
    char FAR *resP; /* pointer to resource data */
    Memh blockH; /* handle on memory block */
    char FAR *blockP; /* pointer to mem block */
    HRSRC theRes; /* handle on data resource */

    if (tableSize)
	*tableSize = 0;

    /* check if this file is a resource in executeable */

    theRes = NULL;
    resP = FARNULL;
    if (strcmp(tableFile,"commands.tab") == 0) {
		theRes = FindResource(hcTInst,(LPCSTR)"CMDRES",RT_RCDATA);
    } else if (strcmp(tableFile,"function.tab") == 0) {
		theRes = FindResource(hcTInst,(LPCSTR)"FUNRES",RT_RCDATA);
    } else if (strcmp(tableFile,"system.pal") == 0) {
		theRes = FindResource(hcTInst,(LPCSTR)"SYSPAL",RT_RCDATA);
    } else if (strcmp(tableFile,"webpal.bin") == 0) {
		theRes = FindResource(hcTInst,(LPCSTR)"WEBPAL",RT_RCDATA);
    } else if (strcmp(tableFile,zcursorsStr) == 0) {
		theRes = FindResource(hcTInst,(LPCSTR)zcursorsStr,RT_RCDATA);
    } else if (strcmp(tableFile,ziconsStr) == 0) {
		theRes = FindResource(hcTInst,(LPCSTR)ziconsStr,RT_RCDATA);
    } else if (strcmp(tableFile,zpatternsStr) == 0) {
		theRes = FindResource(hcTInst,(LPCSTR)zpatternsStr,RT_RCDATA);
    } else if (strcmp(tableFile,"messages.tab") == 0) {
		theRes = FindResource(hcTInst,(LPCSTR)"messages",RT_RCDATA);
    }

    /* extract content of resource, if found */

    if (theRes)
		theRes = LoadResource(hcTInst,theRes);
    if (theRes) {
		resP = LockResource(theRes);
		if (resP) {
			fsize = *(long FAR *)(resP);
			resP += sizeof(long);
			blockH = TUTORhandle("table",fsize,TRUE);
			if (blockH) {
				blockP = GetPtr(blockH);
				TUTORblock_move(resP,blockP,fsize);
				ReleasePtr(blockH);
			}
			UnlockResource(theRes);
		} /* resP if */
		FreeResource(theRes);
		if (tableSize)
			*tableSize = (int)fsize;
		return(blockH);
    } /* theRes if */

    TUTORcopy_fileref_dir((FileRef FAR *) &theFile,ctDirP);
    TUTORcopy_fileref_name((FileRef FAR *) &theFile,(char FAR *)tableFile);
    fii = TUTORopen((FileRef FAR *) &theFile,TRUE,FALSE,FALSE);
    if (fii < 0)
	return(0);
    TUTORinq_file_info((FileRef FAR *) &theFile,NEARNULL,&fsize,NEARNULL,NEARNULL,NEARNULL);
    if (fsize <= 0) {
	TUTORclose(fii);
	return(0);
    }
    blockH = TUTORhandle("table",fsize,TRUE);
    if (!blockH) {
	TUTORclose(fii);
	return(0);
    }
    blockP = GetPtr(blockH);
    TUTORread(blockP,1,fsize,fii);
    ReleasePtr(blockH);
    TUTORclose(fii);

    if (tableSize)
		*tableSize = (int)fsize;

    return(blockH);

} /* LoadTable */

/* ******************************************************************* */
