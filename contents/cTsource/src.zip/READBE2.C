
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* this module translates text with @x[ to ktxt format */

#include "baseenv.h"
#include "txt.h"
#include "tutor.h"
#include <stdio.h>
#include "tglobals.h"

#ifdef ctproto
extern int valid_style(int sN);
int  TUTORread_be2_doc(int  infile,unsigned int  theD,unsigned char  FAR *memP,long  memLen);
extern int  DoTranslate(int  infile,unsigned int  theD,int  headSkip);
extern long  Translate(int  nNest,int  immFlag);
extern int  FinishBufferBe2(void);
extern int  SkipHeader(long  *defStart,long  *defLen,int  *vers);
extern int  GetStyle(unsigned char  FAR * *textP,short  *sDat,int  *isMore);
extern int  MySCmp(unsigned char  FAR * *textP,char  *compareS);
extern int  FillBufferBe2(int  infile);
extern int  ReadUnstyledBe2(int  infile,unsigned int  theD);
extern long  AdjustBlock(char  FAR *t0,long  length);
extern  long StripCR(unsigned char  FAR *tp,long  len);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  AddTStyle(unsigned int  pd,long  start,long  len,long  docLen,int  type,int  newDat,int  combF);
unsigned int  NewTStyle(void);
int  TBlockToStringDoc(unsigned int  doc);
int  TUTORtrace_n(char  *s,long  nn);
int  TUTORinsert_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nIns);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORseek(int  findx,long  pos);
long  TUTORinq_file_pos(int  findx);
int  TUTORreset_file(int  findx,int  option);
int  _TUTORadd_tblock_doc(unsigned int  theD,unsigned int  textH,long  tLen);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
int  AtTStyle(unsigned int  pd,long  pos,short  *styles);
int  TUTORdump(char  *s);
long TUTORadd_ffamily(struct  _fref *famName,int  isSys,int  isSwitch);
long  TUTORinq_ffamily_id(struct  _fref *famName,int known);
int  TUTORsymbolic_fileref(struct  _fref FAR *fRef,char  FAR *syms);
unsigned char  FAR *TUTORscan_bytes(unsigned char  FAR *bp,unsigned char  FAR *be,unsigned char  *tp,int  nTab);
int  TUTORfree_handle(unsigned int  mm);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
#endif /* ctproto */

long Translate();
long TUTORget_hsize();
extern long TUTORread();
extern long AdjustBlock();
char FAR *GetPtr();
char FAR *TUTORalloc();
Memh TUTORhandle();
extern long TUTORinq_file_pos();
extern Memh NewTStyle();
extern unsigned char FAR *TUTORscan_bytes();

static unsigned char FAR *textP, FAR *endP; /* pointers at text */
static unsigned char FAR *ktxtP, FAR *ktxtP0; /* pointers at ktxt */
static Memh theKDoc; /* kdoc being created */

static Memh sDats; /* style data */
static Memh specialD; /* special data */
static short defParaLayout; /* default paragraph layout */

/* larger than the whole file (and therefore larger than the document) */
static long theEnd;

static int streamVersion = 11; 
/* text datastream version of current input, we recognize 11 or 12 */
/* the default action is suited to version 11, extra work is done for version 12 */

#define UNKNOWN 0
#define FACE 1
#define SIZE 2
#define FONT 3
#define JUSTIF 4
#define VISIB 5
#define SPECIAL 6
#define TERMINATE 99

/* need to skip one character of crlf on ibmpc (other machines skip no chars) */

/* maximum size of read-in text chunk (make it larger than the header!) */
#define MAXDBUFF 10000
/* critical size without newline. This needs to be large enough to handle the largest expected
	combination of style names, plus 1 char of actual text */
#define SIZECR 250

static Memh textH;		/* handle to current text */
static unsigned char FAR *inText;		/* current text */
static long curStart;	/* current start position (in file) of textH */
static long curLen;		/* current length of text in textH */
static long nextStart;	/* start position of next block to be read */
static int startSkip;	/* # of header chars at begin to be skipped */
static long docOffset;	/* offset from beginning of document to beginning of current buffer */
static char foundEnd;	/* TRUE when find end of text datastream before end of file */
static char lastBlock;	/* TRUE when no more blocks to read */
static char newlEnd;	/* TRUE if read-in block ends on newline */
static int readFile;	/* file we are reading */

#define NSIZETABLE 8
static short sizeTable[NSIZETABLE] = {-20, 0, 20, 40, 80, 140, 260, 380};
static short nSizes;

TUTORread_be2_doc(infile,theD,memP,memLen)
int infile; /* index of file (already open, at document start, left open when done) */
Memh theD; /* Doc being constructed (assummed empty, a string) */
unsigned char FAR *memP;  /* if NONNULL read from here rather than file */
long memLen;	/* length of chars in memP */
	{
	long defStart, defLen; /* marker on definitions */
	int skip;	/* # of chars to skip at beginning */
	int ii;
	DocP dp;	/* pointer to doc (theD) */

	if (!memP)
		{ /* read from file */
		nextStart = TUTORinq_file_pos(infile); /* next place to read */

		/* see how long file is */
		TUTORreset_file(infile,1);
		theEnd = TUTORinq_file_pos(infile) + 10L; /* past end of file */
		TUTORseek(infile,nextStart); /* restore position */

		/* allocate first buffer */
		lastBlock = FALSE;
		FillBufferBe2(infile);
		}
	else
		{ /* read directly from memory */
		textH = TUTORhandle("rbe2tmp1",memLen,FALSE);
		inText = (unsigned char FAR *) GetPtr(textH);
		TUTORblock_move((char SHUGE *) memP, (char SHUGE *) inText, memLen);
		curLen = memLen;
		endP = inText + curLen;
		ktxtP = ktxtP0 = textP = inText;
		lastBlock = TRUE;
		newlEnd = TRUE; /* this block has normal end */
		theEnd = curLen + 10; /* past end of text */
		}

	dp = (DocP) GetPtr(theD);

	dp->shortText = FALSE; /* we are going to put text into blocks... */
	defParaLayout = dp->defStyles[PARASTYLE] & PARALMASK; /* default layout */

	if (dp->txtH.dAnAlloc < TBUFFLEN+10)
		{ /* need to insert some items (so text buffer will be of size TBUFFLEN) */
		dp->txtH.dAnn = dp->txtH.dAnAlloc;
		ii = TBUFFLEN - dp->txtH.dAnn - dp->txtH.nBuff; /* # of items to insert */
		if (ii < 1)
			ii = 1;
		dp->buffEnd = -1;
		ReleasePtr(theD);
		KillPtr(dp);
		TUTORinsert_darray(theD,FARNULL,DOCOFFSET,DOCTEXT,-1,ii);
		}
	else
		{
		ReleasePtr(theD);
		KillPtr(dp);
		}
	
	skip = SkipHeader(&defStart,&defLen,&streamVersion);
	if (skip < 0)
		{ /* unstyled text */
		ReadUnstyledBe2(infile,theD);
		}
	else
		{ /* styled text */
		if (streamVersion != 11 && streamVersion != 12)
			{
			streamVersion = 12; /* default */
			}
		skip += defLen; /* ignore definitions for now */
		startSkip = skip;
	
		DoTranslate(infile,theD,skip);
		}
	
	dp = (DocP) GetPtr(theD);
	dp->shortText = FALSE;
	if (dp->totLen < MAXSTRINGLEN - 100)
		ii = TRUE;
	else
		ii = FALSE;
	ReleasePtr(theD);
	KillPtr(dp);
	if (ii)
		TBlockToStringDoc(theD);
	
	return(TRUE);
	}

static DoTranslate(infile,theD,headSkip)
int infile; /* file we are reading from */
Memh theD; /* KDoc we are building */
int headSkip; /* # of chars at beginning to skip (because they are definitions, etc) */
	{
	int ii;
	DocP dp;	/* pointer to doc (theD) */
	StyleDatP sp;	/* pointer to styles of doc */
	
	/* skip over header data in first block */
	textP += headSkip;

	/* offset from document begin to start of text in this buffer: */
	docOffset = 0L;
	
	/* initialize style data */
	specialD = 0; /* & special data */
	
	/* translate document */
	foundEnd = FALSE;
	theKDoc = theD;
	readFile = infile;
	
	/* put FULLJUST style around whole doc (be2 is by default FULLJUST) */
	sDats = NewTStyle();
	AddTStyle(sDats,0L,theEnd,theEnd,PARASTYLE,FULLJUST,JUSTMASK);
	
	nSizes = 1; /* where we start in the sizeTable */
	
	Translate(0,FALSE);
	
	/* clean up */
	if (sDats)
		{
		dp = (DocP) GetPtr(theD);

		/* strip off any styles at the end of document */
		sp = (StyleDatP) GetPtr(sDats);
		while (sp->sHead.dAnn > 0 && sp->styles[sp->sHead.dAnn-1].pos >= dp->totLen)
			sp->sHead.dAnn--;
		ReleasePtr(sDats);
		KillPtr(sp);
		
		dp->styles = sDats;
		ReleasePtr(theD);
		KillPtr(dp);
		}
	
	return(0);
	}

static long Translate(nNest,immFlag) /* routine called recursively on each new style */
int nNest;
int immFlag; /* TRUE if there is a style immediately (for complex styles) */
/* returns # of chars processed at this level of style indentation */
	{
	long pos;	/* current position in document */
	long len;	/* # of chars processed by recursive call to Translate */
	long lenTot;	/* total number of chars we've seen here (and below) */
	short oldDat;	/* style before we add new style (we remember for recovery) */
	short sDat;	/* style data returned by GetStyle */
	short styleDat;	/* style data we want to put into document (translated sDat) */
	short allowXor;	/* TRUE if new style can xor */
	int isMore; /* flag set if style is complex */
	int styleType;	/* type (FONTSTYLE, etc.) of new style */
	short skippedN;	/* TRUE if we've already skipped the fake newline */
	short curStyles[NSTYLES];	/* current styles */
	short ii;
	
	lenTot = 0;
	skippedN = FALSE; /* initialize version 12 skipped newline flag */
	while (TRUE) /* end of file test done at bottom of loop */
		{
		if (!immFlag && *textP == '}' && nNest)
			{ /* done with style */
			textP++;
			return(lenTot);
			}
		if (immFlag || *textP == '\\')
			{ /* start of a style */
			if (!immFlag)
				{
				textP++; /* skip the backslash */
				if (*textP == '\\' || *textP == '{' || *textP == '}')
					{ /* an escaped special character */
					*ktxtP++ = *textP++;
					lenTot++;
					continue; /* get back to while loop */
					}
				if (*textP == NEWLINE  && streamVersion == 12)
					continue; /* process NEWLINE as normal character */
				}
			if (!sDats)
				sDats = NewTStyle();
			
			switch(GetStyle((unsigned char FAR **) &textP,&sDat,&isMore))
				{
				case FONT:
					styleDat = sDat;
					allowXor = FALSE;
					styleType = FONTSTYLE;
					break;
				case SIZE:
					nSizes += sDat;
					ii = nSizes;
					if (ii < 0)
						ii = 0;
					if (ii >= NSIZETABLE)
						ii = NSIZETABLE-1;
					styleDat = sizeTable[ii];
					/* outside the table bigger/smallers are just 20% */
					styleDat += (nSizes - ii) * 20;
					allowXor = FALSE;
					styleType = SIZESTYLE;
					break;
				case FACE:
					styleDat = sDat;
					allowXor = -1;
					styleType = FACESTYLE;
					break;
				case JUSTIF:
					styleDat = sDat;
					styleType = PARASTYLE;
					allowXor = JUSTMASK;
					break;
				case VISIB:
					styleDat = sDat;
					styleType = PARASTYLE;
					allowXor = VISMASK;
					break;
				case SPECIAL:
					TUTORdump("Special style in readbe2.");
					break;
				case TERMINATE:
					FinishBufferBe2();
					foundEnd = TRUE; /* all done */
					return(lenTot);
				default:
					TUTORdump("Unsupported style in readbe2.");
					break;
				} /* end of style switch */
			
			pos = ktxtP - ktxtP0 + docOffset;
			/* put new style to end */
			AtTStyle(sDats,pos,curStyles);
			valid_style(styleType);
			oldDat = curStyles[styleType];
			AddTStyle(sDats,pos,theEnd-pos,theEnd,styleType,styleDat,allowXor);			
			len = Translate(nNest+1,isMore);
			AddTStyle(sDats,pos+len,theEnd-(pos+len),theEnd,styleType,oldDat,0);
			if (styleType == SIZESTYLE)
				nSizes -= sDat; /* undo effect of sizing */
			lenTot += len;
			if (immFlag)
				return(lenTot); /* "}" already found for complex style */
			} /* end of if haveStyle */
		else
			{ /* just a character */
			if (*textP == NEWLINE && streamVersion == 12)
				{
				if (skippedN)
					*ktxtP++ = *textP; /* this is the real newline */
				else
					{
					skippedN = TRUE; /* skipping first newline encountered in series */
					lenTot--; /* so lenTot++ further on is correct */
					}
				textP++;
				}
			else
				{
				*ktxtP++ = *textP++;
				skippedN = FALSE; /* reset streamVersion12 newline skip flag */
				}
			lenTot++; /* always done.  if char not added, lenTot was decremented (!!) */
			}
		if (foundEnd)
			break; /* we're done, pop up thru recursion */

		/* check if we are done with this buffer */
		if (textP >= endP)
			{ /* done with this buffer, finish it and get more */
			nextStart += textP - endP; /* compenate for use of chars past endP */
			FinishBufferBe2();
			if (!lastBlock)
				{ /* more input in file expected */
				FillBufferBe2(readFile);
				if (curLen == 0)
					{ /* we've hit the end of the file */
					foundEnd = TRUE;
					break;
					}
				}
			else
				{  /* no more text, we're done */
				foundEnd = TRUE;
				break;
				}
			}
		} /* end of while */
	
	/* have hit end of text, we're done */
	return(lenTot);
	}

static FinishBufferBe2()
	{
	if (!theKDoc)
		return(0); /* working directly in memory */

	curLen = ktxtP - ktxtP0; /* amount of text in document */
	ReleasePtr(textH);
	KillPtr(inText);
	TUTORset_hsize(textH,curLen,TRUE);
	_TUTORadd_tblock_doc(theKDoc,textH,curLen);
	docOffset += curLen;
	startSkip = 0; /* don't skip chars at start of next block */

	return(0);
	}

static SkipHeader(defStart,defLen, vers) /* skip lines beginning with \, or return < 0 for unstyled */
long *defStart, *defLen; /* marker on definitions */
int *vers; /* to be set to text datastream version # */
/* returns # of chars in header before the defines */
	{
	unsigned char FAR *cP;	/* pointer to text */
	
	/* values for defStart and defLen in case no definitions found */
	*defStart = -1L;
	*defLen = 0L;
	
	cP = inText;
	if (curLen == 0 || *cP != '\\') return(-1L); /* no text or unstyled text */
	
	*vers = 12; /* if don't find anything, assumme version is 12 */
	while (TRUE)
		{
		/* find a line break */
		while (*cP++ != NEWLINE)
			;
		if (*cP != '\\') return(cP-inText); /* begin of text, (no definitions) */
		if (MySCmp(&cP,"\\begindata")) continue;
		if (MySCmp(&cP,"\\textdsversion{"))
			{ /* read next two characters as digits */
			*vers = ((*cP++)-'0')*10;
			*vers += ((*cP++)-'0');
			continue;
			}
		if (MySCmp(&cP,"\\template")) continue;
		if (MySCmp(&cP,"\\define")) break;
		return(cP-inText); /* begin of text, with styles */
		}
		
	/* at this point cP points to the begin of a define line */
	*defStart = cP-inText;
	while (TRUE)
		{ /* look thru all the defs */
		while (*cP++ != '}') ; /* look for end of definition */
		cP++; /* advance to next line (skipping newline) */
		if (!MySCmp(&cP,"\\define")) break; /* didn't find another definition */
		}
	*defLen = (long)(cP-inText) - *defStart;
	return((int) *defStart);
	}

static GetStyle(textP,sDat,isMore)
register unsigned char FAR **textP;	/* pointer to text pointer (gets updated) */
register short *sDat;	/* to be filled with code indicating style */
int *isMore; /* set to true if there is another style to be had at this position (for complex styles) */
	{
	unsigned char FAR *tP;	/* text pointer (*textP) */
	static int nextDat=0, nextStyle=0; /* info for additional calls on complex styles */
	char fontName[70]; /* assumme that no font name is longer than 69! */
	int fInd;	/* index into fontName */
	FileRef fRef;	/* fileRef for font */
	
	*isMore = FALSE;
	if (nextDat)
		{ *sDat = nextDat; nextDat = 0; return(nextStyle); } /* second part of complex style */

	/* faces */
	if (MySCmp(textP,"bold{"))
		{ *sDat = 1; return(FACE); }
	if (MySCmp(textP,"italic{"))
		{ *sDat = 2; return(FACE); }
	if (MySCmp(textP,"underline{"))
		{ *sDat = 4; return(FACE); }
	if (MySCmp(textP,"outline{"))
		{ *sDat = 8; return(FACE); }
	if (MySCmp(textP,"shadow{"))
		{ *sDat = 16; return(FACE); }
	if (MySCmp(textP,"subscript{"))
		{ *sDat = 32; return(FACE); }
	if (MySCmp(textP,"superscript{"))
		{ *sDat = 64; return(FACE); }
	
	/* sizes */
	if (MySCmp(textP,"bigger{"))
		{ *sDat = 1; return(SIZE); }
	if (MySCmp(textP,"smaller{"))
		{ *sDat = -1; return(SIZE); }
	
	/* justifications */
	if (MySCmp(textP,"flushright{"))
		{ *sDat = RIGHTJUST; return(JUSTIF); }
	if (MySCmp(textP,"flushleft{"))
		{ *sDat = LEFTJUST; return(JUSTIF); }
	if (MySCmp(textP,"centerjust{"))
		{ *sDat = CENTERJUST; return(JUSTIF); }
	if (MySCmp(textP,"center{")) /* alternative form of centerjust */
		{ *sDat = CENTERJUST; return(JUSTIF); }
	
	/* visibilities */
	if (MySCmp(textP,"visible{"))
		{ *sDat = 0; return(VISIB); }
	if (MySCmp(textP,"invisible{"))
		{ *sDat = 1; return(VISIB); }
	
	/* special */
	if (MySCmp(textP,"cTspecial{"))
		{*sDat = 0 /* not used */; return(SPECIAL); }
	
	/* end of stream */
	if (MySCmp(textP,"enddata{"))
		return(TERMINATE);

	/* complex styles */
#ifdef KSWnomore
	if (MySCmp(textP,"majorheading{"))
		{ nextDat = CENTERJUST; nextStyle=JUSTIF; *isMore=TRUE; *sDat = 2; return(SIZE); }
	if (MySCmp(textP,"heading{") || MySCmp(textP,"subheading{"))
		{ nextDat =LEFTJUST; nextStyle=JUSTIF; *isMore=TRUE; *sDat = 1; return(FACE); }
	if (MySCmp(textP,"chapter{"))
		{ nextDat = 2; nextStyle=SIZE; *isMore=TRUE; *sDat = 1; return(FACE); }
	if (MySCmp(textP,"section{") || MySCmp(textP,"subsection{"))
		{ nextDat = LEFTJUST; nextStyle=JUSTIF; *isMore=TRUE; *sDat = 1; return(FACE); }
	if (MySCmp(textP,"paragraph{"))
		{ nextDat = LEFTJUST; nextStyle=JUSTIF; *isMore=TRUE; *sDat = 2; return(FACE); }
	if (MySCmp(textP,"quotation{"))
		{*sDat = 2; return(FACE); }
	if (MySCmp(textP,"description{") || MySCmp(textP,"example{") || MySCmp(textP,"display{"))
		{ *sDat = LEFTJUST; return(JUSTIF); }
#endif
	
	/* assume it's a font */
	fInd = 0;
	tP = *textP;
	while (*tP != '{')
		if (fInd < FILEL-1)
			fontName[fInd++] = *tP++;
	fontName[fInd] = '\0';
	if (strcmp(fontName,"symb") == 0)
		strcpy(fontName,"zsymbol"); /* fix for old PC/Unix versions */
	TUTORsymbolic_fileref((FileRef FAR *) &fRef,(char FAR *) fontName);
	fInd = (int)TUTORinq_ffamily_id(&fRef,TRUE);
	if (fInd < 0)
		{ /* couldn't find family in table, this must be a new font - try to add it */
		fInd = (int)TUTORadd_ffamily(&fRef,TRUE,TRUE);
		}
	*sDat = fInd;
	*textP = tP+1; /* advance past '{' */
	return(FONT);
	
	/* never get here now.  Really should check to see whether that thing WAS a font */

/*	return(UNKNOWN); */ /* unknown style */
	}

static MySCmp(textP,compareS) /* compare strings and update 1st pointer */
register unsigned char FAR **textP;	/* pointer to text pointer */
register char *compareS;	/* string to compare with */
	{
	register unsigned char FAR *tP;	/* text pointer (*textP) */
	
	tP = *textP;
	while (*compareS)
		if (*tP++ != *compareS++) return(FALSE);
	
	*textP = tP; /* update pointer */
	return(TRUE);
	}

static FillBufferBe2(infile) /* read text from file into inText */
int infile;	/* index of file we are reading from */
	{
	long newlLen;	/* length of chunk up to last newline */
	long readLen;	/* # of chars we actually read */
	long tempL;
	int noMore;  /* set to TRUE in weird PC case if we are out of file */

	textH = TUTORhandle("be2text2",(long) MAXDBUFF,FALSE);

	inText = (unsigned char FAR *) GetPtr(textH);
	/* Note that in the usual case the ReleasePtr(textH) is done in another routine */

	curStart = nextStart;
	TUTORseek(infile,curStart); /* move to read position */
	readLen = curLen = TUTORread((char FAR *) inText,1,(long) MAXDBUFF,infile);
	noMore = FALSE; /* only set to TRUE in weird PC case */
	
#ifdef IBMPC
	tempL = MAXDBUFF; /* current size of handle */
	while (*(inText+curLen-1) == 0xd)
		{ /* keep reading until we aren't in the middle of CRLF */
		
		/* increase buffer size by 1 */
		ReleasePtr(textH);
		KillPtr(inText);
		tempL++;
		TUTORset_hsize(textH,tempL,TRUE);
		
		/* read in 1 more char */
		inText = (unsigned char FAR *) GetPtr(textH);
		if (1L != TUTORread((char FAR *) (inText+tempL-1),1,1L,infile))
			{ /* ran out of file while looking for linefeed */
			noMore = TRUE;
			break;
			}
		curLen++;
		}
	readLen = curLen;
	
	/* now get rid of all the carriage returns */
	curLen -= StripCR(inText,curLen);
#endif

	/* change size of text handle (to match text actually read) */
	ReleasePtr(textH);
	KillPtr(inText);
	if (curLen == 0)
		{ /* no more text available */
		TUTORfree_handle(textH);
		lastBlock = TRUE;
		return(0);
		}
	TUTORset_hsize(textH,curLen,TRUE);
	inText = (unsigned char FAR *) GetPtr(textH);

	/* set up text pointers */
	textP = inText; /* first relevant character */
	ktxtP = ktxtP0 = inText; /* where characters go */
	if (readLen >= MAXDBUFF && !noMore)
		{ /* full buffer, more follows */
		newlLen = AdjustBlock((char FAR *) inText,curLen); /* get length of text thru last newline */
		/* set end pointer */
		if (*(textP+newlLen-1) != NEWLINE)
			{
			newlLen -= SIZECR; /* no newlines, stop processing early */
			newlEnd = FALSE;
			}
		else
			newlEnd = TRUE;
		endP = textP + newlLen;
		/* next starting position is current position backed up over characters we don't
		   use.  This may be modified if we use chars past newlLen (which will happen
		   in the case where full block doesn't end on newline, but on styles) */
		nextStart = TUTORinq_file_pos(infile) - (curLen - newlLen);
		curLen = newlLen;
		}
	else
		{ /* this is the last block of the file */
		endP = textP+curLen; /* break at the very end */
		lastBlock = TRUE;
		nextStart = TUTORinq_file_pos(infile); /* at end of file */
		newlEnd = TRUE; /* namely, no weird end */
		}

	return(0);
	}

static ReadUnstyledBe2(infile,theD) /* read in unstyled be2 document */
int infile;	/* index of file we are reading */
Memh theD; /* empty (includes alloc for 1 text block) KDoc */
/* returns TRUE on success */
	{
	DocP dp;	/* pointer to document */

	/* there is a little special processing here to handle the case of a completely empty document */
	/* that will be when curLen == 0 (textH won't exist) */

	/* the first text is already in textH, take care of it */

	if (curLen > 0)
		{
		ReleasePtr(textH);
		KillPtr(inText);
		if (!newlEnd)
			curLen += SIZECR; /* compensate for offset done in FillBufferBe2 */
		}
	else
		{ /* we need to allocate an empty textH */
		textH = TUTORhandle("be2text3",0L,FALSE);
		}

	_TUTORadd_tblock_doc(theD,textH,curLen); /* add first block */

	/* read multiple blocks */
	while (!lastBlock)
		{
		FillBufferBe2(infile); /* does GetPtr on textH */
		if (curLen == 0)
			{ /* last block is empty, we're done */
			break;
			}
		ReleasePtr(textH);
		KillPtr(inText);
		if (!newlEnd)
			curLen += SIZECR; /* compensate for offset done in FillBufferBe2 */
		TUTORset_hsize(textH,curLen,TRUE); /* in case had to skip chars */
		_TUTORadd_tblock_doc(theD,textH,curLen);
		}

	return(TRUE);
	}

static long AdjustBlock(t0,length) /* attempt to make block of unstyled text end on newline */
char FAR *t0;	/* pointer to beginning of text block */
long length; /* length of block */
/* returns length of text thru last newline (or full length if no newlines) */
	{
	register char FAR *tp;	/* pointer to text */
	char ss[2];	/* search target */

	ss[0] = NEWLINE;
	tp = t0+length-1; /* points at last char in block */
	tp = (char FAR *) TUTORscan_bytes((unsigned char FAR *) tp,(unsigned char FAR *) t0,(unsigned char *) ss,1);
	if (tp)
		{ /* found NEWLINE in block, shorten block */
		length = (long)(tp - t0) + 1; /* to include NEWLINE */
		}
	/* else length is left at length of whole block */

	return(length);
	}

#ifdef IBMPC
static long StripCR(tp,len)
unsigned char FAR *tp;	/* pointer to text */
long len;	/* length of text */
/* returns # of chars stripped out */
	{
	unsigned char FAR *cvtp; /* pointer for c.r./lf conversion */
	unsigned char FAR *cvt2; /* destination pointer for cr/lf conversion */
	long cvti; /* length for c.r./lf conversion */

	/* strip out carriage returns in carriage return/linefeed */
	cvti = len; /* number bytes to scan */
	cvtp = cvt2 = tp; /* pointer in input data */
	while (cvti--)
		{
		if (*cvtp != 0x0d) 
			*cvt2++ = *cvtp; /* we copy all chars except carriage returns */
		cvtp++;
		}
	return((long) (cvtp - cvt2));
	}
#endif
