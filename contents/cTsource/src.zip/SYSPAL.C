
/* ******************************************************************* */

Memh cTPaletteFromSys() /* translate system palette into cT palette */

{   Memh cTPaletteH; /* handle on cT palette */
    struct CTcolorentry FAR *cTPaletteP; /* pointer to cT palette */
    int pii; /* index in palette */
    int nEntries; /* number entries in Windows palette */
    PALETTEENTRY winColor;
    double redD,greenD,blueD;
    double hue,saturation,value;

    if (!HaveDC || (CurrentWindow < 0))
	return(0); /* ? */
    if (!(GetDeviceCaps(CurrentDC,RASTERCAPS) & RC_PALETTE))
	return(0);

    cTPaletteH = TUTORalloc_palette(256);
    if (!cTPaletteH)
	return(0); /* out of memory ? */

    nEntries = GetDeviceCaps(CurrentDC,SIZEPALETTE);
    if (nEntries > 256) nEntries = 256;
	
    /* copy individual entries from Windows palette to cT palette */
	
    cTPaletteP = (struct CTcolorentry FAR *)GetPtr(cTPaletteH);
    for(pii=0; pii<nEntries; pii++) {
	GetSystemPaletteEntries(CurrentDC,pii,1,&winColor);
	(cTPaletteP+pii)->red = winColor.peRed << 8;
	(cTPaletteP+pii)->green = winColor.peGreen << 8;
	(cTPaletteP+pii)->blue = winColor.peBlue << 8;
	(cTPaletteP+pii)->realV = pii;
	redD = (((double) (cTPaletteP+pii)->red)/(double) 0xffff) * 100.0;
    	greenD = (((double) (cTPaletteP+pii)->green)/(double) 0xffff) * 100.0;
    	blueD = (((double) (cTPaletteP+pii)->blue)/(double) 0xffff) * 100.0;
    	TUTORrgb_to_hsv(redD,greenD,blueD,&hue,&saturation,&value);
    	(cTPaletteP+pii)->cHue = hue*4.0;
    	(cTPaletteP+pii)->cSaturation = saturation*4.0;
    	(cTPaletteP+pii)->cValue = value*4.0;
    }
    ReleasePtr(cTPaletteH);
    return(cTPaletteH);

} /* cTPaletteFromSys */
