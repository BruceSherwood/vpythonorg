
/* setupct input-file output-file string */

/* modifies cT program binary to set binDirMagic string to specified */
/* string (path to ct.env file) */

/* ******************************************************************* */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>	

#define TRUE 1
#define FALSE 0

/* magic string which may be edited (in binary file) to point to ct.env file */
static char *binDirMagic = 
"\001binDirMagic23456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"; 

void main(argc,argv)
int argc;		/* argument count */
char *argv[ ];	/* pointers to arguments */
 
{   long inputl; /* total length of input file */
    long totalw; /* total amount written */
    long thisw;  /* amount written to this file */
    int rwl; /* length to read/write */
    FILE *ifile; /* input file */
    FILE *ofile; /* current output file */
    struct stat ifst; /* input file status block */
    char *iobuff;
    int rl,wl; /* length read, written */
	char *cP; /* pointer in binary file */

    if (argc < 4) {
		printf("setupct input output string\n");
		exit(0);
    } /* argc if */

    /* open input file */

    ifile = fopen(argv[1],"r"); /* open input file */
    if (!ifile) {
		printf("cant open input file: %s\n",argv[1]);
		exit(1);
    } /* ifile */
    stat(argv[1],&ifst);
    inputl = ifst.st_size;

	/* allocate buffer for input file */
	
	iobuff = (char *)malloc(inputl+4); /* allocate buffer for file */
	if (!iobuff) {
		printf("cant allocate %ld byte buffer for file %s\n",inputl,argv[1]);
		exit(1);
	}
	
	/* check size of replacement string */
	
	if (strlen(argv[3]) > strlen(binDirMagic)) {
		printf("replacement string is too long\n");
		exit(1);
	}
	
	/* read entire input file */
	
	rl = fread(iobuff,1,inputl,ifile); 
	if (rl != inputl) {
		printf("cant read input file %s\n",argv[1]);
		exit(1);
	}
	
	/* open output file */
	
	ofile = fopen(argv[2],"w");
	if (!ofile) {
	    printf("cant open output file: %s\n",argv[2]);
	    exit(0);
	} /* ofile if */
	
	cP = iobuff; /* pointer in binary file */
	while (cP < (iobuff+inputl)) {
		if ((*cP == *binDirMagic) && (*(cP+1) == *(binDirMagic+1))) {
			if (strcmp(cP,binDirMagic) == 0) {
				strcpy(cP,argv[3]); /* replace string */
				break; /* exit while */
			}
		}
		cP++;
	}
	if (cP >= (iobuff+inputl))
		printf("didn't find target string\n");
		
	wl = fwrite(iobuff,1,inputl,ofile); 
	if (wl != inputl) {
		printf("cant write output file %s\n",argv[2]);
		exit(1);
	}
	
	fclose(ofile); /* close this output file */
    fclose(ifile); /* close input file */
	exit(0);

} /* main */ 

/* ******************************************************************* */
