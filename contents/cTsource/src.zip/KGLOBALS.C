
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Declarations for kernel (events, windows, etc.) of cT
*/

#include "baseenv.h"
#include "tutor.h"
#include "kglobals.h"

#ifdef ctproto
#endif /* ctproto */

int CurrentMode;    /* write/rewrite etc. mode */
long SpaceShim; /* current space shim value */
int RealX, RealY;   /* current x/y position */
TRect tgclipR; /* clip rectangle */
int tgclipx,tgclipy;    /* x/y of clip rectangle */
int tgclipw,tgcliph;    /* width/height of clip rectangle */
short flushMenu; /* if false, wait to flush menus */
int lineThick; /* current line thickness */
int newlineH; /* current newline height */
int SupSub; /* current superscript/subscript */
struct tutorview FAR *CurrentView;      /* view currently selected */
struct tutorColor fgndColor,bgndColor, winColor; /* current foreground, background, window colors */
short CurrentPaletteSize;  /* size of cT palette */
Memh defaultPalette = HNULL;    /* the default cT palette */
Memh oldDefaultPalette = HNULL; /* default palette for executor with $oldcolor */
int paletteRef = 1; /* counter identifying current palette */

int patternFont, patternChar; /* current drawing pattern */
int cursorFont,cursorChar; /* current cursor font */
int textFont; /* current text font */

int ntiming;    /* number timing events currently queued */
Memh timeque;
struct tutorevent FAR *eventque;

int nfonts; /* number of font table entries */
Memh fontFamilies; /* font family table */
short nFamilies; /* number of font family table entries */
int CurrentWindow;  /* window currently selected */

int evlogfi; /* file index of event log file */
int evplayfi; /* file index of event replay file */

/* preferences */

char FAR *pffamilynP; /* pointer to preferred font name */
long pffamily; /* index of preferred font */
int pfsize, pfface; /* preferred font (not for executor) */
struct PrefRec FAR *prfP = FARNULL; /* pointer to preferences */

char *memStr = "Out of memory.";

#ifdef X11
/* X11 preferences */
char pprntr[40]; /* print command */
#endif

#ifdef IBMPC
char pprntr[10]; /* local printer name */
#endif

long quickLast,quickVal; /* timeslice timing */
