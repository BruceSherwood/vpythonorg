
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989,1992 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* ******************************************************************* */

#define STRICT
#include <windows.h>
#include <string.h>
#include <direct.h>

#include "baseenv.h"
#include "ctmsw.h"
#include "tglobals.h"
#include "kglobals.h"
#include "txt.h"
#include "kdefs.h"
#include "ct_ctype.h"
#include "compute.h"
#include "eglobals.h"
#include "ecglobal.h"
#include "chardef.h"
#include "editmenu.h"
#include "fkeys.h"

/* ******************************************************************* */

extern void cTReleaseDC(HWND hWnd,HDC hDC);
extern HDC cTGetDC(HWND hWnd);
extern int TUTORget_AE_win(void); 
extern int TUTORforce_redraw(int wix);        
int  TutorShowCard(unsigned int  barh,int  cardI);
int TMessage(char FAR *ss);
int TUTORclose_view(struct tutorview FAR *vp);
int GetCompose(int code,char *sr);
int  TutorDeleteItem(unsigned int  barh,int  cardI,int  itemI); 
struct keywdinf *GetComposeFKey(void);
extern int TUTORinq_icon_size(int fontid,int iconN,int *dx,int *dasc,int *ddes);
extern int TUTORzero(char FAR *ptr,long len);
extern int interact(int block);
extern HBRUSH fpc_brush(int pattF,int pattC,int invertF);
extern  long TUTORget_hsize(Memh mm);
extern int strncmpf(char FAR *aa,char FAR *bb,int nn);
extern int strcmpf(char FAR *aa,char FAR *bb);
extern Memh read_fpc(FileRef FAR *fpcPath);
extern char SHUGE *fpc_char(struct pcfont FAR *fpcP,long charI,
			  struct pccharl *charDef);
extern int fpc_draw_char(Memh ftH,struct pcfont FAR *ftP,int cc);
extern int fpc_add_bitmap_cache(Memh ftH,int charI,int type,HBITMAP mapH,struct pccharl *pDef);
extern int fpc_find_bitmap_cache(Memh fontH,int cc,int type);
extern HDC fpc_mem_dc(int type);
extern char  FAR *strcpyf(char	FAR *aa,char  FAR *bb);
extern char  FAR *strcatf(char	FAR *aa,char  FAR *bb);
extern int TUTORchecksum(char FAR *addr,long length);
extern int TutorDeleteCard(Memh barh,int cardI);
extern int MenuNames(unsigned int mbar,int item,char *cardName,char *itemName);
extern int cTRegisterWindow(HWND hWnd,int cTtype,int cTindex,int cmdN,Memh infH);
extern int TUTORset_hsize(unsigned int	mm,long newsize,int abort);
extern unsigned int TUTORhandle(char *name,long size,int purgewmrm);
extern int TUTORdone_startup(void);
extern int TUTORstart_menubar(unsigned int  barh);
extern int TUTORforward_window(int wix);
extern long TUTORadd_ffamily(struct  _fref *famName,int	isSys,int  isSwitch);
extern long TUTORparse_font_family(struct  _fref *fontTag,struct  _fref *familyName,int  isFont,int  oneTag,int  *fontSize);
extern int TUTORtrace(char *str);
extern int TUTORset_abs_clip_rectangle(int x1,int y1,int x2,int y2);
extern int TUTORdraw_abs_solid_rect(TRect FAR *tr,int color);
extern int TUTORinq_abs_screen_size(int *x,int *y,int *dx,int *dy);
extern int TUTORinq_abs_pen_pos(int *x,int *y);
extern int TUTORabs_line_to(int xx,int yy);
extern int TUTORdump(char *s);
extern int  TUTORpost_event(struct  tutorevent *event);
extern int TUTORpoll_events(int block);
extern int TUTORdealloc(char  FAR *ptr);
extern int start_executor(void);
extern int  ReleasePtr(unsigned int  mm);
extern char  FAR *GetPtr(unsigned int  mm);
extern int TUTORcopy_fileref(FileRef FAR *fDest,FileRef FAR *fSource);
extern int TUTORcmp_fileref(FileRef FAR *f1,FileRef FAR *f2);
extern int TUTORcopy_fileref_name(FileRef FAR *fRef,char FAR *name);
extern int TUTORcopy_fileref_dir(FileRef FAR *dirname,FileRef FAR *fullname);
extern char  *strf2n(char  FAR *strp);
extern char  *strnf2n(char  FAR *strp,int  nn);
extern int TUTORstartup(int argc,char **argv,FileRef FAR *filenameR);

extern long TUTORread();
extern long TUTORwrite();

/* ******************************************************************* */

extern HANDLE hcTInst ; /* current instance of cT */
extern HWND FirstWinH; /* first window created in ctauth */
extern HBRUSH hbrWhite; /* handle on stock white brush */
extern HBRUSH hbrBlack; /* handle on stock black brush */
extern jmp_buf mainenv; /* saved enviornment for longjmp */
extern int tDump; /* TRUE if crashed (TUTORdump called) */
extern int KeepRunning; /* TRUE if still alive */
extern char FAR *_pgmptr;
extern long winMainTime;
extern HWND CurrentWinH; /* handle on current window */
extern HDC CurrentDC; /* current window's device context */
extern long polltime; /* time of last poll */
extern Memh cTwinInfH; /* handle on cT window (cTwinInf) table */
extern int cTwinInfN; /* number entries in cT window table */
extern int paletteNcolors; /* size of color palette */
extern int leftDown;
extern int rightDown;
extern int AuxWn; /* debugger auxiliary window */     
extern struct tutorview FAR *AuxVp;   
extern struct tutorview FAR *TraceVp;

/* ******************************************************************* */

#pragma check_stack(on)

#define PALVERSION 0x300

/* ******************************************************************* */

int win_circle(x1,y1,x2,y2) /* drive windows native circle */
int x1,y1,x2,y2;

{	HBRUSH tBrush; /* dummy brush for filling ellipse */
	HBRUSH cBrush; /* current brush */
	
	tBrush = GetStockObject(NULL_BRUSH); /* use null brush so won't fill */
	cBrush = SelectObject(CurrentDC,tBrush); /* select into context */
	Ellipse(CurrentDC,x1,y1,x2,y2);
	SelectObject(CurrentDC,cBrush); /* restore brush */   
	return(0);

} /* win_circle */

/* ******************************************************************* */

int TUTORsize_exec_window(xx,yy) /* resize executor window */
int xx; /* new x size for window */
int yy; /* new y size for window */

{   HWND hWnd;
    RECT curRect;
    int dx,dy; /* amount we need to change window size */
	HWND deskH; /* handle on desktop window */
	RECT dR; /* desktop window rectangle */

    if (ExecWn < 0)
		return(0); /* no executor window */
    hWnd = (HWND)windowsP[ExecWn].wp;
    if (!hWnd)
		return(0); /* no executor window */

	if ((xx == -1) && (yy == -1)) { /* maximize window */
		deskH = GetDesktopWindow();
		GetWindowRect(deskH,(LPRECT)(&dR));
		xx = (dR.right-dR.left)+1;
		yy = (dR.bottom-dR.top)+1;
		SetWindowPos(hWnd,HWND_TOP,0,0,xx,yy,SWP_SHOWWINDOW);
		return(0);
	}

    if ((xx < 20) || (yy < 20) || (xx > 4096) || (yy > 4096))
		return(0);

    GetClientRect(hWnd,(RECT FAR *)&curRect);
    dx = xx-(curRect.right-curRect.left+1);
    dy = yy-(curRect.bottom-curRect.top+1);
    GetWindowRect(hWnd,(RECT FAR *)&curRect);
    curRect.right += dx;
    curRect.bottom += dy;
    xx = (curRect.right-curRect.left)+1;
    yy = (curRect.bottom-curRect.top)+1;
    SetWindowPos(hWnd,HWND_TOP,0,0,xx,yy,SWP_NOMOVE);
    TUTORforce_redraw(ExecWn);
    return(0);

} /* TUTORsize_exec_window */

/* ******************************************************************* */

int TUTORget_AE_win()

{   int wix; /* index of window */
    HWND hWnd;
    RECT wRect; /* window rectangle */

    if (EditWn[0] < 0)
		return(0); /* no go */

    wix = EditWn[0];
    hWnd = (HWND)windowsP[wix].wp;
    GetWindowRect(hWnd,(RECT FAR *)&wRect);
    prfP->editWp.left = wRect.left;
    prfP->editWp.top = wRect.top;
    prfP->editWp.right = wRect.right;
    prfP->editWp.bottom = wRect.bottom;

	if (ExecWn >= 0) {
    	wix = ExecWn;
    	hWnd = (HWND)windowsP[wix].wp;
    	GetWindowRect(hWnd,(RECT FAR *)&wRect);
		prfP->execWp.left = wRect.left;
		prfP->execWp.top = wRect.top;
		prfP->execWp.right = wRect.right;
		prfP->execWp.bottom = wRect.bottom;
    }

    if (MsgWn >= 0) {
		wix = MsgWn;
		hWnd = (HWND)windowsP[wix].wp;
		GetWindowRect(hWnd,(RECT FAR *)&wRect);
		prfP->msgWp.left = wRect.left;
		prfP->msgWp.top = wRect.top;
		prfP->msgWp.right = wRect.right;
		prfP->msgWp.bottom = wRect.bottom;
    }

    if (DebugWn >= 0) {
		wix = DebugWn;
		hWnd = (HWND)windowsP[wix].wp;
		GetWindowRect(hWnd,(RECT FAR *)&wRect);
		prfP->debugWp.left = wRect.left;
		prfP->debugWp.top = wRect.top;
		prfP->debugWp.right = wRect.right;
		prfP->debugWp.bottom = wRect.bottom;
    }

    if (AuxWn >= 0) {
		wix = AuxWn;
		hWnd = (HWND)windowsP[wix].wp;
		GetWindowRect(hWnd,(RECT FAR *)&wRect);
		prfP->stackWp.left = wRect.left;
		prfP->stackWp.top = wRect.top;
		prfP->stackWp.right = wRect.right;
		prfP->stackWp.bottom = wRect.bottom;
    }    
    
    return(0);

} /* TUTORget_AE_win */

/* ******************************************************************* */

int chkDebExeOverlap() /* check if executor and debugger windows overlap */

{	RECT eRect; /* executor window rectangle */   
	RECT dRect; /* debugger window rectangle */   
	RECT iRect; /* intersection rectangle */
    HWND hWnd;
    
	if ((ExecWn < 0) || (DebugWn < 0))
		return(FALSE);
	
    hWnd = (HWND)windowsP[ExecWn].wp;
    GetWindowRect(hWnd,(RECT FAR *)&eRect);
    hWnd = (HWND)windowsP[DebugWn].wp;
    GetWindowRect(hWnd,(RECT FAR *)&dRect);   
    if (IntersectRect(&iRect,&dRect,&eRect)) 
    	return(TRUE);
    return(FALSE);
    
} /* chkDebExe */

/* ******************************************************************* */

int  TUTORstart_menubar(barH)
Memh barH; /* handle on menu bar structure */

{   TutorMenuBar FAR *barP; /* pointer to menu bar structure */

    barP = (TutorMenuBar FAR *)GetPtr(barH);
    barP->theBar = 0; /* bar isn't showing yet */
    barP->menubarH = (long)(char FAR *)CreateMenu(); /* create the top-level menu */
    ReleasePtr(barH);
    return(0);

} /* TUTORstart_menubar */

/* ******************************************************************* */

TutorChangeMenuBar(oldBar,newBar) /* switch the menus of current window */
Memh oldBar;
Memh newBar;

{   TutorMenuBar FAR *oldbarP;
    TutorMenuBar FAR *newbarP;

    if (newBar == NIL)
        return(0); /* nothing to change to */

    /* change who is showing */

    newbarP = (TutorMenuBar FAR *)GetPtr(newBar);
    if (oldBar != NIL) {
        oldbarP = (TutorMenuBar FAR *)GetPtr(oldBar);
		oldbarP->theBar = 0; /* not showing */
        ReleasePtr(oldBar);
    }
    newbarP->theBar = 1; /* now showing */
    SetMenu(CurrentWinH,(HMENU)newbarP->menubarH);
    ReleasePtr(newBar);
    DrawMenuBar(CurrentWinH);            
    return(0);

} /* TutorChangeMenuBar */

/* ******************************************************************* */

TutorFindCard(barh,card)
Memh barh;
char *card; /* card name to look for */

{   short ii;
    TutorMenuBar FAR *bar;
    TutorMenuItem FAR *mp;
    int rVal; /* return value */

    bar = (TutorMenuBar FAR *) GetPtr(barh);
    rVal = -1; /* set for didn't find */
    for (ii=0, mp=bar->items; ii<bar->nItems; ii++, mp++) {
	if ((mp->itemKind == MENUCARD) &&
	    !strncmpf((char FAR *)card,mp->name,MENUNAMEL)) {
            rVal = ii;
            break;
        }
    } /* for */
    ReleasePtr(barh);
    return(rVal);

} /* TUTORfindCard */

/* ******************************************************************* */

TutorFindItem(barh,item,cardI)
Memh barh;
char *item; /* item name to look for */
int cardI; /* index of card info in menu list */

{   short ii;
    TutorMenuItem FAR *mp;
    TutorMenuBar FAR *bar;
    int rVal; /* return value */

    rVal = -1; /* preset for not found */
    bar = (TutorMenuBar FAR *) GetPtr(barh);
    for (ii=0, mp=bar->items; ii<bar->nItems; ii++, mp++) {
        if ((mp->itemKind == MENUITEM) && (mp->cardI == cardI) &&
                !strncmpf((char FAR *)item,mp->name,MENUNAMEL)) {
            rVal = ii;
            break;
        }
    } /* for */
    ReleasePtr(barh);
    return(rVal);

} /* TutorFindItem */

/* ******************************************************************* */

TutorNewCard(barh,cardName,cp,cardNN, cardInd)
Memh barh;
char *cardName; /* card name */
int cp; /* card's priority */
short *cardNN; /* unused */
int cardInd; /* index where card info will be stored */
/* returns new card id number */

{   TutorMenuBar FAR *bar;  /* pointer to menu bar structure */
    TutorMenuItem FAR *card; /* pointer to this memory card */
    TutorMenuItem FAR *mp;  /* pointer to individual card/item */
    int cardPos; /* index at which to insert card */
    int lastPos; /* last position found */
    int ii;

    bar = (TutorMenuBar FAR *) GetPtr(barh);
    card = bar->items+cardInd;
    card->nItems = 0; /* no items yet */
    card->menuidN = 0;
    card->nnth = 0; /* no position yet - assume first */
    card->menuitemH = (long)(char FAR *)CreateMenu();

    /* determine position for card, insert card */

    mp = bar->items;
    cardPos = lastPos = -1; /* don't know where to put card yet */
    for(ii=0; ii<bar->nItems; ii++) {
	if ((mp->itemKind == MENUCARD) && (ii != cardInd)) {
	    if (mp->nnth > lastPos)
		lastPos = mp->nnth; /* highest position so far */
	    if (mp->priority > cp) { /* high priority is to right */
		if ((cardPos > mp->nnth) || (cardPos == -1))
		    cardPos = mp->nnth; /* take lowest position for insert */
	    } /* priority if */
	} /* itemKind if */
	mp++; /* advance to next item */
    } /* for */
    if (cardPos < 0)
	cardPos = lastPos+1; /* last card */
    InsertMenu((HMENU)bar->menubarH,cardPos,MF_POPUP | MF_STRING |
		   MF_BYPOSITION,
		   (UINT)card->menuitemH,(LPCSTR)cardName);
    card->nnth = cardPos;

    /* adjust positions of following cards */

    mp = bar->items;
    for(ii=0; ii<bar->nItems; ii++) {
	if ((mp->itemKind == MENUCARD) && (mp->nnth >= cardPos) &&
	    (ii != cardInd)) {
	    mp->nnth++; /* adjust position */
	} /* nn if */
	mp++; /* advance pointer */
    } /* for */

    ReleasePtr(barh);
    windowsP[CurrentWindow].menuf = TRUE;
    return(cardInd);

} /* TutorNewCard */

/* ******************************************************************* */

TutorNewItem(barh,cardI,itemName,ip,keyBind,itemI)
Memh barh; /* handle on menu bar */
int cardI; /* index of card information for this item */
char *itemName; /* string for item name */
int ip; /* priority of this item */
int keyBind; /* if non-zero, the Mac keyBinding character -- unused */
int itemI; /* index where item info will be stored (info not there yet) */

{   TutorMenuBar FAR *bar; /* pointer to menu bar */
    TutorMenuItem FAR *card; /* pointer to card menu table entry */
    TutorMenuItem FAR *itemP; /* pointer to item menu table entry */
    TutorMenuItem FAR *mp; /* pointer in item table */
    TutorMenuItem FAR *targetP; /* pointer in item table */
    int itemPos; /* position to add this item at */
    int ii,jj;

    bar = (TutorMenuBar FAR *) GetPtr(barh);
    card = bar->items+cardI; /* card this item belongs to */
    itemP = bar->items+itemI; /* item table entry */
    itemP->nItems = 0; /* no items beneath item */
    itemP->menuidN = IDM_CT+itemI; /* identifier for menu event */
    itemP->cardI = cardI; /* card this item belongs to */
    itemP->priority = ip;
    itemP->nnth = 0; /* don't know position yet */

    if (card->nItems == 0) { /* first item */
	AppendMenu((HMENU)card->menuitemH,MF_STRING,IDM_CT+itemI,
	      (LPCSTR)itemName);
    } else {

	/* build card menu item positions */

	targetP = bar->items;
	for(jj=0; jj<bar->nItems; jj++) {
	    if ((targetP->cardI == cardI) && (targetP->itemKind == MENUITEM)) {
		mp = bar->items;
		itemPos = 0;
		for(ii=0; ii<bar->nItems; ii++) {
		    if ((mp->cardI == cardI) && (mp->itemKind == MENUITEM)) {
			if ((mp < targetP) && (mp->priority <= targetP->priority))
			    itemPos++;
			else if (mp->priority < targetP->priority)
			    itemPos++;
		    }
		    mp++;
		} /* ii for */
		targetP->nnth = itemPos;
	    } /* targetP->cardI if */
	    targetP++;
	} /* jj for */
		
	InsertMenu((HMENU)card->menuitemH,itemP->nnth,MF_STRING | MF_BYPOSITION,
		   IDM_CT+itemI,(LPCSTR)itemName);
    } /* nItems else */
    card->nItems++; /* increment count of items for this card */
    ReleasePtr(barh);
/*    windowsP[CurrentWindow].menuf = TRUE;	*/

    return(itemP->nnth);

} /* TutorNewItem */

/* ******************************************************************* */

TutorDeleteCard(barh,cardI) /* destroy menu card and all items on card */
Memh barh;
int cardI; /* index of card to delete */

{   TutorMenuBar FAR *bar; /* pointer to menu bar */
    TutorMenuItem FAR *card; /* pointer to this menu card */
    TutorMenuItem FAR *mp; /* pointer to next item in menu bar */
    int ii; /* index in menu bar items */

    bar = (TutorMenuBar FAR *) GetPtr(barh);
    card = bar->items+cardI;

    if (card->menuitemH) {

	/* delete items on this card */

	mp = bar->items;
	for (ii=0; ii<bar->nItems; ii++) {
	    if ((mp->itemKind == MENUITEM) && (mp->cardI == cardI))
		TutorDeleteItem(barh,cardI,ii); /* delete next item of card */
	    mp++;
	} /* for */

	/* delete this card */

	DeleteMenu((HMENU)bar->menubarH,card->nnth,MF_BYPOSITION);

	/* adjust positions of following cards */

	mp = bar->items;
	for (ii=0; ii<bar->nItems; ii++) {
	    if ((mp->itemKind == MENUCARD) && (mp->nnth > card->nnth))
		mp->nnth--;
	    mp++; /* advance pointer */
	} /* for */
    } /* menuitemH if */
    card->menuitemH = 0;
    card->itemKind = UNUSED;

    ReleasePtr(barh);
    DrawMenuBar(CurrentWinH);

    return 0;

} /* TutorDeleteCard */

/* ******************************************************************* */

TutorDeleteItem(barh,cardI,itemI)
Memh barh;
int cardI; /* index of card of item */
int itemI; /* index of item to be deleted */

{   TutorMenuBar FAR *bar; /* pointer to menu bar structure */
    TutorMenuItem FAR *card; /* pointer to card menu table entry */

    bar = (TutorMenuBar FAR *) GetPtr(barh);
    card = bar->items+cardI;
    DeleteMenu((HMENU)card->menuitemH,IDM_CT+itemI,MF_BYCOMMAND);
    ReleasePtr(barh);

    DrawMenuBar(CurrentWinH);

    return 0;

} /* TutorDeleteItem */

/* ******************************************************************* */

TutorModifyItem(barh,cardI,itemI,enableFlag,checkFlag,style)
Memh barh;
int cardI, itemI; /* indices into bar for card and item info */
int enableFlag; /* 1: enable, 0: disable, -1: do nothing */
int checkFlag; /* 1: check, 0: uncheck, -1: do nothing -- unused */
int style; /* 0 and up: face style for item, -1: do nothing -- unused */

{   TutorMenuBar FAR *bar;

    if (enableFlag == -1) return 0; /* only enable/disable supported by wm */

    bar = (TutorMenuBar FAR *) GetPtr(barh);
    if (!bar->theBar) {
	/* this bar isn't showing, don't tell wm anything */
	ReleasePtr(barh);
	return 0;
    } /* theBar */

/*  bar->items[cardI].altered = TRUE;	*/
    if (itemI >= 0 && bar->items[cardI].state != ITEMVISIBLE) {
	/* item's card currently not showing, don't tell wm anything */
	ReleasePtr(barh);
	return 0;
    } /* itemI if */

    if (itemI < 0) {
	/* we're working on a card */
	if (!enableFlag)
	    TutorDeleteCard(barh,cardI); /* disable by deleting */
	else
	    TutorShowCard(barh,cardI); /* enable by recreating all the visible items on the card */
	return 0;
    } /* itemI */

    if (!enableFlag)
	TutorDeleteItem(barh,cardI,itemI); /* disable by deleting */
    else
	TutorNewItem(barh,cardI,strf2n(bar->items[itemI].name),
	       bar->items[itemI].priority,0,itemI); /* enable by creating */

    ReleasePtr(barh);
    return 0;

} /* TutorModifyItem */

/* ******************************************************************* */

MenuNames(mbar,item,cardName,itemName)
Memh mbar;
int item;
char *cardName, *itemName;
    
{   TutorMenuBar FAR *bp;
    TutorMenuItem FAR *ip;

    bp = (TutorMenuBar FAR *) GetPtr(mbar);
    ip = bp->items + item;

    strcpyf((char FAR *) itemName,ip->name);
    strcpyf((char FAR *) cardName,bp->items[ip->cardI].name);

    ReleasePtr(mbar);
    return 0;

} /* MenuNames */

/* ******************************************************************* */

int TUTORinq_left_down() /* returns TRUE if left button down */

{
	return(leftDown);

} /* TUTORinq_left_down */

/* ******************************************************************* */

int TUTORinq_right_down() /* returns TRUE if right button down */

{
	return(rightDown);
	
} /* TUTORinq_right_down */

/* ******************************************************************* */

int TUTORhide_window(wix) /* hide (minimize) window */
int wix; /* index of window */

{ 	HWND hideW; /* window handle for window to hide */

	if (wix < 0) return(0);
	hideW = (HWND)windowsP[wix].wp;
	ShowWindow(hideW,SW_SHOWMINIMIZED);
	return(0); 
	
} /* TUTORhide_window */

/* ******************************************************************* */

void ConvertWM_CLOSE(ev) /* convert system WM_CLOSE to cT event */
struct tutorevent FAR *ev; /* event to built, window # already set */

{	int wType; /* window type */
	int wix; /* index of window */

	ev->type = -1; /* pre-set, no event */
	wix = ev->window;
	wType = windowsP[wix].type;
	if (wType == EDITW) {
		ev->type = EVENT_MENU;
		if (wix == EditWn[0]) {
			ev->a1 = edit_quit;
		} else {
			ev->a1 = edit_close;
		}
	} else if (wType == EXECW) {
		ev->type = EVENT_MENU;
		if (EditWn[0] >= 0) {
		    ev->a1 = edit_quit;
		    ev->window = EditWn[0];
		} else ev->a1 = exec_quit;
	} else if (wType == HELPW) {
	    if (HelpVp)
		TUTORclose_view(HelpVp);
	} else if (wType == DICTW) {
	    if (DictVp)
		TUTORclose_view(DictVp);
	} else if (wType == MESGW) {
	    TMessage(FARNULL);
	} else if (wType == DEBUGW) {   
		if (DebugVp)
			TUTORclose_view(DebugVp);   
	} else if (wType == DEBUGAUXW) {   
		if (AuxVp)
			TUTORclose_view(AuxVp);
	} else if (wType == ABOUTW) {
		if (AboutVp)
			TUTORclose_view(AboutVp);
	} else if (wType == TRACEW) {   
		if (TraceVp)
			TUTORclose_view(TraceVp);
	}
	return; 
	
} /* ConvertWM_CLOSE */

/* ******************************************************************* */

int TUTORis_foreground() /* return TRUE if executor is foreground window */

{   HWND hExec; /* handle on execute window */

    if (ExecWn < 0) return(FALSE);
    hExec = (HWND)windowsP[ExecWn].wp;
    if (hExec == GetActiveWindow())
	return(TRUE);
    return(FALSE);

} /* TUTORis_foreground */

/* ******************************************************************* */

double win_double_click()

{
    return(GetDoubleClickTime());

} /* win_double_click */

/* ******************************************************************* */

char FAR *CTzks(code,tempS) /* convert key code to name */
int code;
char *tempS;
    {
    char FAR *ss;
    struct keywdinf *keyseq;
    
    if (code > 350)
        return(""); /* not a key */
    
    if (code > 32 && code < 127)
        { /* perfectly normal key */
        tempS[0] = code;
        tempS[1] = '\0';
        return(tempS);
        }
    else if (code >= 0xa0 && code < 256)
        { /* extended characters.  These are composed */
        strcpy(tempS,"ctl-z ");
        GetCompose(code, tempS+6);
        return(tempS);
        }
    
    /* otherwise string is complicated */
    
    tempS[0] = '\0'; /* for assembly of strings */
    ss = FARNULL; /* not set yet */
    switch (code)
        {
        case KNEXT:
            ss = "enter"; break;
        case KTAB:
            ss = "tab"; break;
        case 32:
            ss = "space"; break;
        case KBACKTAB:
            ss = "left tab"; break;
        case KERASE:
            ss = "backspace"; break;
        case KCUT:
            ss = "shift-delete"; break;
        case KCOPY:
            ss = "shift-insert"; break;
        case KPASTE:
            ss = "insert"; break;
        case KUNDO:
	    ss = "ctl-u"; break;
        
        case KLEFT:
            ss = "leftarrow"; break;
        case KLEFT+1:
            ss = "shift-leftarrow"; break;    
        case KRIGHT:
            ss = "rightarrow"; break;
        case KRIGHT+1:
            ss = "shift-rightarrow"; break;
        case KUP:
            ss = "uparrow"; break;
        case KUP+1:
            ss = "shift-uparrow"; break;
        case KDOWN:
            ss = "downarrow"; break;
        case KDOWN+1:
            ss = "shift-downarrow"; break;
    
        case KBEGLINE:
            ss = "home"; break;
        case KBEGLINE+1:
            ss = "shift-home"; break;
        case KBEGFILE:
            ss = "ctl-home"; break;
        case KBEGFILE+1:
            ss = "shift-ctl-home"; break;
            
        case KENDLINE:
            ss = "end"; break;
        case KENDLINE+1:
            ss = "shift-endline"; break;
        case KENDFILE:
            ss = "ctl-end"; break;
        case KENDFILE+1:
            ss = "shift-ctl-end"; break;

        case KPAGEUP:
            ss = "pageup"; break;
        case KPAGEUP+1:
            ss = "shift-pageup";
        case KBEGPAGE:
            ss = "ctl-pageup"; break;
        case KBEGPAGE+1:
            ss = "shift-ctl-pageup"; break;
        
        case KPAGEDOWN:
            ss = "pagedown"; break;
        case KPAGEDOWN+1:
            ss = "shift-pagedown"; break;
        case KENDPAGE:
            ss = "ctl-pagedown"; break;
        case KENDPAGE+1:
            ss = "shift-ctl-pagedown"; break;
        
        case KESCAPE:
            ss = "escape"; break;

        case KTRANSPOSE:
            ss = "ctl-t"; break;
    
        case KHELP:
            ss = "F1"; break;
        case KFWDDEL:
            ss = "delete"; break;
        
        case KFA:
            ss = "F5"; break;
        case KFB:
            ss = "F6"; break;
        case KFC:
            ss = "F7"; break;
        case KFD:
            ss = "F8"; break;
        }
    
    if (!ss) { /* we don't have this key on this keyboard,
                get the composition sequence */
        strcpy(tempS,"ctl-z ");
        keyseq = GetComposeFKey(); /* get composition sequences */
        while (keyseq->value > 0) {
            if (keyseq->value == code)
                break;
            keyseq++;
        } /* while */
        if (keyseq->value > 0) {
            strcat(tempS,";");
            strcat(tempS,keyseq->name);
            ss = tempS;
        }
    }
    
    if (!ss) { /* we couldn't figure this out at all */
        ss = "";
    }
    
    return(ss);

} /* CTzks */

/* ******************************************************************* */

TUTORexit()

{
    longjmp(mainenv,1);  
    return(0);

} /* TUTORexit */
			
/* ******************************************************************* */
