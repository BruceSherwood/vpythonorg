
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>
#include "baseenv.h"
#include "kdefs.h"
#include "editmenu.h"
#include "tutor.h"
#include "editor.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "edglobal.h"
#include "commands.h"
#include "txt.h"
#include "kglobals.h"
#ifdef MAC
#ifdef THINKC5
#include <Menus.h>
#include <Printing.h>
#include <Memory.h>
#else
#ifdef WERKS
#include <Menus.h>
#include <Printing.h>
#include <Memory.h>
#else
#include <MenuMgr.h>
#include <PrintMgr.h>
#endif
#endif
#endif

#ifdef ctproto
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,
 int ebsref,struct  _trect *theR,int  relInfo,int  mintw,int  wrap,
 unsigned int  doc,long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),
 int  ro,int  corner,int  erase,int  frame,int tabsz,int lm,int rm,int inhss,int type);
int immediatePalette(Memh pp);
Memh initial_palette(void);
long  TUTORinq_msec_clock(void);
int  TUTORclear_doc(unsigned int  doc);
extern int TUTORzero(char SHUGE *ptr,long length);
extern int  TUTORset_cursor(int  cInd,int  cChar);
extern int EditWinMenu(int index,int addf);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  initedit0(void);
int  initeditviews(int  eview,struct  _fref FAR *filen,int  *ro);
int  initedit(int  wid,unsigned int  eDat1,unsigned int  doc);
unsigned int  initedit_menubar(int primary);
extern unsigned int  initedit_x11menus(void);
int  ReleasePtr(unsigned int  mm);
int  SetSelectPanel(struct  _tvdat FAR *vp,long  pos,long  len);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
int  TUTORset_menubar(unsigned int  barh,struct  tutorview FAR *newMenuView);
int  TUTORset_event_mask(int  eventc,int  value);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
int  TUTORset_view(struct  tutorview FAR *vp);
struct  tutorview FAR *TUTORinq_view(void);
int  TUTORset_window_title(int  wid,char  *wt);
int  TUTORget_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  TUTORmessage(struct  tutorview FAR *vp,int  eKind,int  eVal);
char  FAR *GetPtr(unsigned int  mm);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,int ebsref,
 struct  _trect *theR,int  relInfo,int  mintw,int  wrap,unsigned int  doc,long  pos,
 long  len,int  wantV,int  wantH,int  (*KeyF)(),int  ro,int  corner,int  erase,
  int  frame,int tabsz,int lm,int rm,int inhss,int type);
int  proceditstub(unsigned int  editH,struct  tutorevent *event);
int  killptr(char  FAR * FAR *ptr);
int  readdoc(unsigned int  doc,struct  _fref FAR *fRef,int  *iswrite);
int  EditorDefaultStyles(unsigned int  doc);
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
int  setmainfile(struct  _fref FAR *filename);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORadd_menu(unsigned int  barh,char  *card,int  cp,char  *item,int  ip,int  keyBind,int  type,int  unit,double  unitArg,int  eType);
unsigned int  TUTORinit_menubar(int  nItems);
long  TUTORinq_symbolic_font_id(char  *fontName);
int  TUTORpost_event(struct  tutorevent *event);
#endif /* ctproto */

#ifdef macproto
#ifndef THINKC5
#ifndef WERKS
extern char *PtoCstr(unsigned char *ss);
extern int sscanf(char *ss, char *form,...);
extern int sprintf(char *ss, char *form,...);
#endif
#endif
extern int cTPaletteFromMac(void);
extern int TellEventEditM(int ei);
extern int _CTmac_working_dir(FileRef FAR *fRef);
extern int DeactivateColor(void);
extern int TUTORforce_redraw(int wid);
extern  int TUTORmodify_menu(unsigned int barh,char *card,char *item,int enableFlag,int checkFlag,int style);
extern int ChangeFaceMenu(long faceList, int onOff);
extern int ChangeJustMenu(long oldJust, long newJust);
extern int ChangeSizeMenu(long oldSize, long newSize);
extern int ChangeFontMenu(long oldFont, long newFont);
extern  int PrintKView(unsigned int theV,char FAR *gPort,int nPage,int pSize);
extern int TUTORset_textfont(int jj);
#endif

extern char *machinename();
extern Memh MakeTextPanel();
extern struct tutorview FAR *TUTORinq_view();
extern int proceditstub();
extern Memh TUTORinit_menubar();
extern Memh initedit_menubar();
extern char *strf2n();
unsigned int GetLineKView();


extern char *faceNames[];
extern char *justNames[];
extern char *sizeNames[];

#ifndef MAC
#ifndef IBMPC
#define WORKSTATION
#endif
#endif

#ifdef GENERICSYS
extern Memh initedit_x11menus();
#endif


/* ******************************************************************* */

initedit0() /* one-time editor initializations */
    
{
    editmenus = 0; /* menus */
    return(0);

} /* initedit0 */

/* ******************************************************************* */

initeditviews(eview,filen,ro)
int eview; /* 0 = no main edit view (no edit views) */
           /* 1 = main edit view */
FileRef FAR *filen;
int *ro; /* set to true for readonly */
    
{   EditDat FAR *ep;
    int i;
    int drm; /* document read-only mode */

    vsource = 0;    /* no view on source yet */
    
    if (eview == 0) {
        editmenus = HNULL; /* no editor menus */
        ed1H = TUTORhandle("editdata",(long) sizeof(EditDat),TRUE);
        i = 0;
        *ro = TRUE;
    } else {
        ed1H = TUTORhandle("edittxt",(long) sizeof(EditDat),TRUE);
        setmainfile(&sourcetable[0].fRef); /* set main file name */
        ep = (EditDat FAR *) GetPtr(ed1H);
        TUTORcopy_fileref(filen,&ep->filename);
        EditorDefaultStyles(source);
        if (!fileSpecified) {
        	drm = TRUE;
        	i = TRUE;
        	TUTORclear_doc(source);
        } else i = readdoc(source,filen,&drm);
        *ro = !drm;
        ReleasePtr(ed1H);
        KillPtr(ep);
    }
    return(i);
    
} /* initeditviews */

/* ******************************************************************* */

initedit(wid,eDat1,doc) /* initializations for editor */
int wid; /* window index of window this editor is in */
Memh eDat1; /* handle to edit info (only contains file name) */
Memh doc; /* document to be edited */
    
{   int jj, corner;
    int info;
    struct tutorview FAR *cv;
    EditDat FAR *ep;
    TextVDat FAR *vp;
    char tempS[FILEL+1];
    struct tutorevent edevent;
    int wrap;
    int minWidth;   /* minimum layout width */
    Memh palH;

#ifdef THINKC5
    windowsP[wid].wproc = (int(*)(...))(proceditstub);
#else
    windowsP[wid].wproc = (int(*)())(proceditstub);
#endif
    windowsP[wid].wH = eDat1;
    windowsP[wid].normalCursorChar = 6;
    TUTORset_cursor(cursorFont0,6);

    ep = (EditDat FAR *) GetPtr(eDat1);
    ep->wid = wid;
    
    info = LEFTSTICK | TOPSTICK | RIGHTSTICK | BOTTOMSTICK;
        
    /* create text panel */
#ifdef MAC
    corner = TRUE;
#else
    corner = FALSE;
#endif

#ifdef CTEDIT
    wrap = FALSE;
    minWidth = 0;
#else
#ifdef Nosuchz
    wrap = TRUE;
    minWidth = 300;
#endif
    wrap = prfP->wordWrap;
    minWidth = 0;
#endif
    ep->textPanel = MakeTextPanel(wid,(long) wid,0,0,NEARNULL,info,minWidth,wrap,
                doc, 0L,-1L,TRUE,TRUE, FARNULL,FALSE,corner,FALSE,FALSE,-1,-1,-1,FALSE,0);
    
    /* finish setup */
    vp = (TextVDat FAR *) GetPtr(ep->textPanel);
#ifndef MAC
    TUTORmessage(vp->view,EVENT_VFOCUS,TRUE); /* activate view */
#endif
	ep->needCursor = TRUE;
    ep->savedc = ep->compilc = ep->checkptc = vp->alteredc;
    ep->chkpf = ep->didall = FALSE;
    curSelUnit = TUTORalloc(34L,TRUE,"selunit");
    curSelUnit[0] = '\0';
    TUTORget_fileref_name(&ep->filename,(char FAR *) tempS);
    TUTORset_window_title(vp->view->window,tempS);

    /* set up window */
    cv = TUTORinq_view();
    if (wid == EditWn[0])
    	EditVp[0] = vp->view;
    ep->view = vp->view;
    TUTORset_view(vp->view); /* set to text view */
    TUTORset_key_focus(vp->view->window,vp->view,FALSE);
    TUTORset_event_mask(EVENT_KEY,TRUE);
    TUTORset_event_mask(EVENT_FKEY,TRUE);
    TUTORset_event_mask(EVENT_MENU,TRUE);
    TUTORset_event_mask(EVENT_MSG,TRUE);
    TUTORset_event_mask(EVENT_LEFTDOWN,TRUE);
    TUTORset_event_mask(EVENT_RIGHTDOWN,TRUE);
    TUTORset_event_mask(EVENT_LEFTUP,TRUE);
    TUTORset_event_mask(EVENT_RIGHTUP,TRUE);
    TUTORset_event_mask(EVENT_DOWNMOVE,TRUE);
    TUTORset_event_mask(EVENT_PASTE,TRUE);
    TUTORset_event_mask(EVENT_FWD,TRUE);
    TUTORset_event_mask(EVENT_WFOCUS,TRUE);
    TUTORset_event_mask(EVENT_SCROLL,TRUE);
    TUTORset_event_mask(EVENT_HOT,TRUE);
    TUTORset_event_mask(EVENT_VFOCUS,TRUE);
    TUTORset_event_mask(EVENT_PRINT,TRUE);

    /* attach editor menus to this window */
    if (!editmenus)
        editmenus = initedit_menubar(TRUE); /* create the editor menu bar */
    TUTORset_menubar(editmenus,vp->view);
#ifdef MAC
    vp->styleMenu = editmenus;
#endif
    
#ifndef CTEDIT
    vsource = vp->textv;
#endif

    /* put selection at end of $syntaxlevel statement */
    jj = 0;
    if (TUTORcharat_doc(vp->textd,0L) == '$') 
        while (TUTORcharat_doc(vp->textd,(long) jj) != NEWLINE)
            jj++;
    SetSelectPanel(vp,(long) jj,0L);
    
    /* set up 1st checkpoint event */

    TUTORzero((char FAR *)&edevent,(long)sizeof(struct tutorevent));
    edevent.type = EVENT_TIME;
    edevent.window = wid; /* edit window */
    edevent.view = FARNULL; /* goes to window */
    edevent.value = time_checkpt; /* checkpoint */
    edevent.timestamp = (long)prfP->checkTime * 1000L; /* n seconds from now */ 
    ep->checkTime = TUTORinq_msec_clock()+edevent.timestamp;
    TUTORpost_event(&edevent);
    
    ReleasePtr(ep->textPanel);
    KillPtr(vp);
    ReleasePtr(eDat1);
    KillPtr(ep);
    TUTORset_view(cv);

	if (wid == EditWn[0])
		EditWinMenu(0,TRUE); /* add window menu item */

    palH = initial_palette();
    immediatePalette(palH); /* install the palette */

    return(0);
    
} /* initedit */

/* ******************************************************************* */

#ifndef MAC 

Memh initedit_menubar(primary) /* set up the editor menu bar */
int primary; /* TRUE if primary edit window */
  
{   short tempS;
    short fNLen, ii;
    char *fName;
    Memh eBar;
    int ep; /* priority of edit menu */
    int serifF, sansF, fixedF, symbolF;

#ifdef ANDREW
    Memh initedit_x11menus();
    if (isx11) {
        eBar = initedit_x11menus(); /* pulldown menus, not popup */
        return(eBar);
    }
#endif
#ifdef GENERICSYS
    if (isx11) {
        eBar = initedit_x11menus(); /* pulldown menus, not popup */
        return(eBar);
    }
#endif
#ifdef IBMPC
    Memh initedit_x11menus();
    eBar = initedit_x11menus(); /* initalize for pulldown menus */
    return(eBar);
#endif

    /* menus for Andrew-WM */
    
    ep = 5;
    /* get the font ids */
    serifF = TUTORinq_symbolic_font_id("zserif");
    sansF = TUTORinq_symbolic_font_id("zsans");
    fixedF = TUTORinq_symbolic_font_id("zfixed");
    symbolF = TUTORinq_symbolic_font_id("zsymbol");
    
    /* start edit menu bar */
    eBar = TUTORinit_menubar(102);
    
    /* create edit menu items */
    TUTORadd_menu(eBar,NEARNULL,ep,"Paste",30,'V',edit_paste,1,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,NEARNULL,ep,"Cut",30,'X',edit_cut,2,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,NEARNULL,ep,"Copy",30,'C',edit_copy,3,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,NEARNULL,ep,"Delete",30,0,edit_clear,5,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,NEARNULL,ep,"Undo",30,'Z',edit_undo,0,0.0,EVENT_MENU);
#ifndef CTEDIT
    if (ExecWn >= 0) {
        TUTORadd_menu(eBar,NEARNULL,0,"Execute current unit",40,0,edit_execcur,0,0.0,EVENT_MENU);
        TUTORadd_menu(eBar,NEARNULL,0,"Select unit",40,0,edit_selunit,0,0.0,EVENT_MENU);
        TUTORadd_menu(eBar,NEARNULL,0,"Execute selected unit",40,0,edit_rununit,0,0.0,EVENT_MENU);
    }
#endif
    TUTORadd_menu(eBar,NEARNULL,ep,"Save",50,'S',edit_save,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,NEARNULL,ep,"Save as",50,0,edit_saveas,0,0.0,EVENT_MENU);
/*    TUTORadd_menu(eBar,NEARNULL,ep,"Save (old format)...",50,0,edit_saveas,1,0.0,EVENT_MENU); */
    TUTORadd_menu(eBar,NEARNULL,ep,"Open",50,'W',edit_switch,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,NEARNULL,ep,"Insert file",50,0,edit_insertf,0,0.0,EVENT_MENU);
#ifndef CTEDIT
    TUTORadd_menu(eBar,"Window",ep,"Help",60,0,edit_help,0,0.0,EVENT_MENU);
    if (ctmouse)
        TUTORadd_menu(eBar,"Window",ep,"Commands",60,0,edit_command,0,0.0,EVENT_MENU);
#endif
    TUTORadd_menu(eBar,NEARNULL,ep,"Quit",70,'Q',edit_quit,0,0.0,EVENT_MENU);

/*  TUTORadd_menu(eBar,"Edit",20,"Search...",35,0,edit_search,0,0.0,EVENT_MENU); */
#ifndef CTEDIT
    TUTORadd_menu(eBar,"Edit",20,"Search For Unit",35,0,edit_searchu,2,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",20,"Hide Units",40,0,edit_hideunits,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",20,"Hide All Units",40,0,edit_hideunits,1,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",20,"Show Units",45,0,edit_showunits,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",20,"Show All Units",46,0,edit_showall,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",20,"Comment Lines",50,0,edit_comment,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",20,"Un-Comment Lines",55,0,edit_uncomment,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",20,"Indent Lines",60,0,edit_indent,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",20,"Un-Indent Lines",65,0,edit_unindent,0,0.0,EVENT_MENU);
#endif
    TUTORadd_menu(eBar,"Search",20,"Search...",50,0,edit_search,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Search",20,"Forward",51,0,edit_searchd,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Search",20,"Back",52,0,edit_searchd,4,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Search",20,"Replace",53,0,edit_searchd,1,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Search",20,"Replace+Find",54,0,edit_searchd,2,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Search",20,"Replace all",55,0,edit_searchd,3,0.0,EVENT_MENU);

#ifdef CTEDIT
    TUTORadd_menu(eBar,"Navigate",30,"Line number?",10,0,edit_linen,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Navigate",30,"Go to line...",10,0,edit_linen,1,0.0,EVENT_MENU);
#endif

    TUTORadd_menu(eBar,"Style",30,"Plainest",10,0,edit_plain,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,faceNames[8],20,0,edit_region,DEFSTYLE,(double) FACESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,faceNames[0],20,0,edit_region,0,(double) FACESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,faceNames[1],20,0,edit_region,1,(double) FACESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,faceNames[2],20,0,edit_region,2,(double) FACESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,sizeNames[0],30,0,edit_region,BIGGERSIZE,(double) SIZESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,sizeNames[1],30,0,edit_region,-BIGGERSIZE,(double) SIZESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,sizeNames[2],30,0,edit_region,DEFSTYLE,(double) SIZESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,faceNames[7],40,0,edit_region,SUPERSTYLE,(double) FACESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,faceNames[6],40,0,edit_region,SUBSTYLE,(double) FACESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,"Normal",70,0,edit_region,DEFSTYLE,(double) HOTSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,"Hot",70,0,edit_region,1,(double) HOTSTYLE,EVENT_MENU);
    
    TUTORadd_menu(eBar,"Font",40,"Default",10,0,edit_region,DEFSTYLE,(double) FONTSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Font",40,"Serif",10,0,edit_region,serifF,(double) FONTSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Font",40,"Sans Serif",10,0,edit_region,sansF,(double) FONTSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Font",40,"Fixed",10,0,edit_region,fixedF,(double) FONTSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Font",40,"Symbol",10,0,edit_region,symbolF,(double) FONTSTYLE,EVENT_MENU);
	TUTORadd_menu(eBar,"Font",40,"Icon",10,0,edit_icon,0,0.0,EVENT_MENU);

    TUTORadd_menu(eBar,"Color",40,"Default",10,0,edit_region,DEFSTYLE,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Black",10,0,edit_region,0,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"White",10,0,edit_region,1,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Red",10,0,edit_region,2,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Green",10,0,edit_region,3,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Blue",10,0,edit_region,4,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Yellow",10,0,edit_region,5,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Cyan",10,0,edit_region,6,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Magenta",10,0,edit_region,7,(double) COLORSTYLE,EVENT_MENU);
    
    TUTORadd_menu(eBar,"Justify",50,justNames[3],50,0,edit_region,FULLJUST,(double) PARASTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Justify",50,justNames[0],50,0,edit_region,LEFTJUST,(double) PARASTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Justify",50,justNames[1],50,0,edit_region,CENTERJUST,(double) PARASTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Justify",50,justNames[2],50,0,edit_region,RIGHTJUST,(double) PARASTYLE,EVENT_MENU);
        
    TUTORadd_menu(eBar,"Option",60,"Print",30,0,edit_print,0,0.0,EVENT_MENU);
#ifndef CTEDIT
    TUTORadd_menu(eBar,"Option",60,"Make Binary",35,0,edit_compile,1,0.0,EVENT_MENU);
#endif
        
    return(eBar);

} /* initedit_menubar */

static Memh initedit_x11menus() /* X11 has pulldown menus */

{   int serifF, sansF, fixedF, symbolF;
    Memh eBar;
    
    /* get the font ids */
    serifF = TUTORinq_symbolic_font_id("zserif");
    sansF = TUTORinq_symbolic_font_id("zsans");
    fixedF = TUTORinq_symbolic_font_id("zfixed");
    symbolF = TUTORinq_symbolic_font_id("zsymbol");

    /* start edit menu bar */
    eBar = TUTORinit_menubar(92);

    /* create edit menu items */

#ifdef WINPC
    TUTORadd_menu(eBar,"File",0,"New\tCtrl+N",10,'W',edit_switch,1,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"File",0,"Open\tCtrl+O",10,'W',edit_switch,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"File",0,"Save\tCtrl+S",10,'S',edit_save,0,0.0,EVENT_MENU);
#else
    TUTORadd_menu(eBar,"File",0,"New",10,'W',edit_switch,1,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"File",0,"Open...",10,'W',edit_switch,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"File",0,"Save",10,'S',edit_save,0,0.0,EVENT_MENU);
#endif
    TUTORadd_menu(eBar,"File",0,"Save as...",10,0,edit_saveas,0,0.0,EVENT_MENU);
/*    TUTORadd_menu(eBar,"File",0,"Save (old format)...",30,0,edit_saveas,1,0.0,EVENT_MENU); */
    TUTORadd_menu(eBar,"File",0,"Insert file",30,0,edit_insertf,0,0.0,EVENT_MENU);
    /* TUTORadd_menu(eBar,"File",0," ",20,0,0,0,0.0,EVENT_MENU); */
    TUTORadd_menu(eBar,"File",0,"Auxiliary file",31,'W',edit_open,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"File",0,"Close",31,'W',edit_close,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"File",0,"Print...",32,0,edit_print,1,0.0,EVENT_MENU);


    /* TUTORadd_menu(eBar,"File",0," ",30,0,0,0,0.0,EVENT_MENU); */
    TUTORadd_menu(eBar,"File",0,"Quit",35,'Q',edit_quit,0,0.0,EVENT_MENU);

    TUTORadd_menu(eBar,"Edit",1,"Undo",10,'Z',edit_undo,0,0.0,EVENT_MENU);
    /* TUTORadd_menu(eBar,"Edit",1," ",20,0,0,0,0.0,EVENT_MENU); */
#ifdef WINPC
    TUTORadd_menu(eBar,"Edit",1,"Cut\tCtrl+X",20,'X',edit_cut,2,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",1,"Copy\tCtrl+C",20,'C',edit_copy,3,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",1,"Paste\tCtrl+V",20,'V',edit_paste,1,0.0,EVENT_MENU);
#else
    TUTORadd_menu(eBar,"Edit",1,"Cut",20,'X',edit_cut,2,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",1,"Copy",20,'C',edit_copy,3,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",1,"Paste",20,'V',edit_paste,1,0.0,EVENT_MENU);
#endif
    TUTORadd_menu(eBar,"Edit",1,"Clear",20,0,edit_clear,5,0.0,EVENT_MENU);
    /* TUTORadd_menu(eBar,"Edit",1," ",30,0,0,0,0.0,EVENT_MENU); */
#ifdef CTEDIT
    TUTORadd_menu(eBar,"Edit",1,"Preferences",40,0,edit_prefer,0,0.0,EVENT_MENU);
#endif

#ifndef CTEDIT
    TUTORadd_menu(eBar,"Edit",1,"Hide Units",30,'H',edit_hideunits,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",1,"Hide All Units",30,0,edit_hideunits,1,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",1,"Show Units",30,'Y',edit_showunits,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",1,"Show All Units",30,0,edit_showall,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",1,"Comment Lines",30,0,edit_comment,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",1,"Un-Comment Lines",30,0,edit_uncomment,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",1,"Indent Lines",30,0,edit_indent,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",1,"Un-Indent Lines",30,0,edit_unindent,0,0.0,EVENT_MENU);
    /* TUTORadd_menu(eBar,"Edit",1,"Add pattern",30,0,edit_inset,0,0.0,EVENT_MENU); */
#endif
#ifdef WINPC
    TUTORadd_menu(eBar,"Search",20,"Find\tCtrl+F",50,0,edit_search,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Search",20,"Next\tF3",51,0,edit_searchd,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Search",20,"Back",52,0,edit_searchd,4,0.0,EVENT_MENU);
#else
    TUTORadd_menu(eBar,"Search",20,"Search...",50,0,edit_search,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Search",20,"Forward",51,0,edit_searchd,0,0.0,EVENT_MENU);
#endif
    TUTORadd_menu(eBar,"Search",20,"Back",52,0,edit_searchd,4,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Search",20,"Replace",53,0,edit_searchd,1,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Search",20,"Replace+Find",54,0,edit_searchd,2,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Search",20,"Replace all",55,0,edit_searchd,3,0.0,EVENT_MENU);
#ifndef CTEDIT
    TUTORadd_menu(eBar,"Search",20,"Find Unit...",70,0,edit_searchu,1,0.0,EVENT_MENU);
#endif

#ifdef CTEDIT
    TUTORadd_menu(eBar,"Navigate",30,"Line number?",10,0,edit_linen,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Navigate",30,"Go to line...",10,0,edit_linen,1,0.0,EVENT_MENU);
#endif

    TUTORadd_menu(eBar,"Style",30,faceNames[8],10,0,edit_region,DEFSTYLE,(double) FACESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,faceNames[0],10,0,edit_region,0,(double) FACESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,faceNames[1],10,0,edit_region,style_bold,(double) FACESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,faceNames[2],10,0,edit_region,style_italic,(double) FACESTYLE,EVENT_MENU);
    /* TUTORadd_menu(eBar,"Style",30," ",20,0,0,0,0.0,EVENT_MENU); */
    TUTORadd_menu(eBar,"Style",30,sizeNames[0],20,0,edit_region,BIGGERSIZE,(double) SIZESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,sizeNames[1],20,0,edit_region,-BIGGERSIZE,(double) SIZESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,sizeNames[2],20,0,edit_region,DEFSTYLE,(double) SIZESTYLE,EVENT_MENU);
    /* TUTORadd_menu(eBar,"Style",30," ",30,0,0,0,0.0,EVENT_MENU); */
    TUTORadd_menu(eBar,"Style",30,faceNames[7],30,0,edit_region,SUPERSTYLE,(double) FACESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,faceNames[6],30,0,edit_region,SUBSTYLE,(double) FACESTYLE,EVENT_MENU);
    /* TUTORadd_menu(eBar,"Style",30," ",40,0,0,0,0.0,EVENT_MENU); */
    TUTORadd_menu(eBar,"Style",30,"Normal",70,0,edit_region,DEFSTYLE,(double) HOTSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,"Hot",70,0,edit_region,1,(double) HOTSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,"Plainest",90,0,edit_plain,0,0.0,EVENT_MENU);

    TUTORadd_menu(eBar,"Font",40,"Default",10,0,edit_region,DEFSTYLE,(double) FONTSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Font",40,"Serif",10,0,edit_region,serifF,(double) FONTSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Font",40,"Sans Serif",10,0,edit_region,sansF,(double) FONTSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Font",40,"Fixed",10,0,edit_region,fixedF,(double) FONTSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Font",40,"Symbol",10,0,edit_region,symbolF,(double) FONTSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Font",40,"Icon",10,0,edit_icon,0,0.0,EVENT_MENU);

    TUTORadd_menu(eBar,"Color",40,"Default",10,0,edit_region,DEFSTYLE,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Black",10,0,edit_region,0,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"White",10,0,edit_region,1,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Red",10,0,edit_region,2,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Green",10,0,edit_region,3,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Blue",10,0,edit_region,4,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Yellow",10,0,edit_region,5,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Cyan",10,0,edit_region,6,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Magenta",10,0,edit_region,7,(double) COLORSTYLE,EVENT_MENU);
    
    TUTORadd_menu(eBar,"Justify",40,justNames[3],20,0,edit_region,
               FULLJUST,(double) PARASTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Justify",40,justNames[0],25,0,edit_region,
                   LEFTJUST,(double) PARASTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Justify",40,justNames[1],30,0,edit_region,
                   CENTERJUST,(double) PARASTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Justify",40,justNames[2],35,0,edit_region,
                   RIGHTJUST,(double) PARASTYLE,EVENT_MENU);

#ifndef CTEDIT
    if (ctexec){
#ifdef WINPC
        TUTORadd_menu(eBar,"Option",50,"Run from beginning\tF5",10,'A',edit_run,0,0.0,EVENT_MENU);
#else
        TUTORadd_menu(eBar,"Option",50,"Run from beginning",10,'A',edit_run,0,0.0,EVENT_MENU);
#endif
        TUTORadd_menu(eBar,"Option",50,"Execute current unit",10,0,edit_execcur,0,0.0,EVENT_MENU);
        TUTORadd_menu(eBar,"Option",50,"Select unit",10,0,edit_selunit,0,0.0,EVENT_MENU);
        TUTORadd_menu(eBar,"Option",50,"Run from selected unit",10,'K',edit_runfrom,0,0.0,EVENT_MENU);
        TUTORadd_menu(eBar,"Option",50,"Execute selected unit",10,'E',edit_rununit,0,0.0,EVENT_MENU);
      /* TUTORadd_menu(eBar,"Option",50," ",20,0,0,0,0.0,EVENT_MENU); */

    }
    TUTORadd_menu(eBar,"Option",50,"Make Binary",20,0,edit_compile,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Option",50,"Preferences",20,0,edit_prefer,0,0.0,EVENT_MENU);

    TUTORadd_menu(eBar,"Window",50,"Debug",30,0,edit_debug,0,0.0,EVENT_MENU); 
    TUTORadd_menu(eBar,"Window",50,"Exec",30,0,edit_execfwd,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Window",50,"VGA window",80,0,edit_sewind,0,0.0,EVENT_MENU);

#ifdef WINPC
    TUTORadd_menu(eBar,"Help",50,"Help on cT\tF1",30,0,edit_help,0,0.0,EVENT_MENU);
#else
    TUTORadd_menu(eBar,"Help",50,"Help on cT",30,0,edit_help,0,0.0,EVENT_MENU);
#endif
	TUTORadd_menu(eBar,"Help",50,"Commands",30,0,edit_command,0,0.0,EVENT_MENU);
	TUTORadd_menu(eBar,"Help",50,"About cT",85,0,edit_about,0,0.0,EVENT_MENU); 
#endif

return(eBar);

} /* initedit_x11menus */

#else /* MAC */

Memh initedit_menubar(primary) /* set up the editor menu bar */
int primary; /* TRUE if primary edit window */
    {
    short tempS;
    short fNLen, ii;
    char *fName;
    Memh eBar;
    int nFonts;
    int fontNum;
    int ep; /* priority of edit menu */

    MenuHandle tempM;
    /* create font menu (now so we can count the fonts) */
    tempM = NewMenu(999,"\pFontsx");
    AppendResMenu(tempM,'FONT');
    nFonts = CountMItems(tempM);
    ep = 15;
    
    /* start edit menu bar */
	eBar = TUTORinit_menubar(100+EDITWINDOWLIMIT+nFonts);
    
    TUTORadd_menu(eBar,"File",10,"New file...",30,'N',edit_switch,1,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"File",10,"Open...",30,'O',edit_switch,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"File",10,"Save",30,'S',edit_save,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"File",10,"Save as...",30,0,edit_saveas,0,0.0,EVENT_MENU);
/*     TUTORadd_menu(eBar,"File",10,"Save (old format)...",30,0,edit_saveas,1,0.0,EVENT_MENU); */
    TUTORadd_menu(eBar,"File",10,"Insert file...",30,0,edit_insertf,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"File",10,"Auxiliary file",30,0,edit_open,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"File",10,"Close",30,'W',edit_close,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"File",10,"-",40,0,0,0,0.0,EVENT_MENU);
    TUTORmodify_menu(eBar,"File","-",0,-1,-1);
    TUTORadd_menu(eBar,"File",10,"Page Setup...",50,0,edit_print,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"File",10,"Print...",50,0,edit_print,1,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"File",10,"---",80,0,0,0,0.0,EVENT_MENU);
    TUTORmodify_menu(eBar,"File","---",0,-1,-1);
    TUTORadd_menu(eBar,"File",10,"Quit",90,'Q',edit_quit,0,0.0,EVENT_MENU);
    
    tempS = TUTORadd_menu(eBar,"Edit",ep,"Undo",10,'Z',edit_undo,0,0.0,EVENT_MENU);
    TellEventEditM(tempS);
    TUTORadd_menu(eBar,"Edit",ep,"-",20,0,0,0,0.0,EVENT_MENU);
    TUTORmodify_menu(eBar,"Edit","-",0,-1,-1);
    TUTORadd_menu(eBar,"Edit",ep,"Cut",30,'X',edit_cut,2,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",ep,"Copy",30,'C',edit_copy,3,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",ep,"Paste",30,'V',edit_paste,1,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",ep,"Clear",30,0,edit_clear,5,0.0,EVENT_MENU);
#ifndef CTEDIT
    TUTORadd_menu(eBar,"Edit",ep,"--",40,0,0,0,0.0,EVENT_MENU);
    TUTORmodify_menu(eBar,"Edit","--",0,-1,-1);
    TUTORadd_menu(eBar,"Edit",ep,"Compose Character",50,'=',999,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",ep,"---",60,0,0,0,0.0,EVENT_MENU);
    TUTORmodify_menu(eBar,"Edit","---",0,-1,-1);
    TUTORadd_menu(eBar,"Edit",ep,"Hide Units",70,'H',edit_hideunits,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",ep,"Hide All Units",70,0,edit_hideunits,1,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",ep,"Show Units",70,'Y',edit_showunits,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",ep,"Show All Units",70,0,edit_showall,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",ep,"Comment Lines",70,',',edit_comment,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",ep,"Un-Comment Lines",70,'-',edit_uncomment,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",ep,"Indent Lines",70,']',edit_indent,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Edit",ep,"Un-Indent Lines",70,'[',edit_unindent,0,0.0,EVENT_MENU);
#endif

    TUTORadd_menu(eBar,"Search",20,"Search...",50,0,edit_search,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Search",20,"Forward",51,'F',edit_searchd,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Search",20,"Back",52,'B',edit_searchd,4,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Search",20,"Replace",53,'R',edit_searchd,1,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Search",20,"Replace & Find",54,'T',edit_searchd,2,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Search",20,"Replace all",55,0,edit_searchd,3,0.0,EVENT_MENU);
#ifndef CTEDIT
    TUTORadd_menu(eBar,"Search",20,"-",60,0,0,0,0.0,EVENT_MENU);
    TUTORmodify_menu(eBar,"Search","-",0,-1,-1);
    TUTORadd_menu(eBar,"Search",20,"Find Unit...",70,0,edit_searchu,1,0.0,EVENT_MENU);
#endif

    TUTORadd_menu(eBar,"Style",30,faceNames[8],10,0,edit_region,DEFSTYLE,(double) FACESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,faceNames[0],10,0,edit_region,0,(double) FACESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,faceNames[1],10,0,edit_region,1,(double) FACESTYLE,EVENT_MENU);
    TUTORmodify_menu(eBar,"Style",faceNames[1],-1,-1,1);
    TUTORadd_menu(eBar,"Style",30,faceNames[2],10,0,edit_region,2,(double) FACESTYLE,EVENT_MENU);
    TUTORmodify_menu(eBar,"Style",faceNames[2],-1,-1,2);
    TUTORadd_menu(eBar,"Style",30,faceNames[3],10,0,edit_region,4,(double) FACESTYLE,EVENT_MENU);
    TUTORmodify_menu(eBar,"Style",faceNames[3],-1,-1,4);
    TUTORadd_menu(eBar,"Style",30,faceNames[4],10,0,edit_region,8,(double) FACESTYLE,EVENT_MENU);
    TUTORmodify_menu(eBar,"Style",faceNames[4],-1,-1,8);
    TUTORadd_menu(eBar,"Style",30,faceNames[5],10,0,edit_region,16,(double) FACESTYLE,EVENT_MENU);
 /*   TUTORmodify_menu(eBar,"Style",faceNames[5],-1,-1,16); */
 	TUTORadd_menu(eBar,"Style",30,"  ",10,0,edit_region,/* 64 */ 16,(double) FACESTYLE,EVENT_MENU);
	TUTORadd_menu(eBar,"Style",30,faceNames[7],10,0,edit_region,64,(double) FACESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,faceNames[6],10,0,edit_region,32,(double) FACESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,"-",20,0,0,0,0.0,EVENT_MENU);
    TUTORmodify_menu(eBar,"Style","-",0,-1,-1);
    TUTORadd_menu(eBar,"Style",30,sizeNames[0],30,0,edit_region,BIGGERSIZE,(double) SIZESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,sizeNames[1],30,0,edit_region,-BIGGERSIZE,(double) SIZESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,sizeNames[2],30,0,edit_region,DEFSTYLE,(double) SIZESTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,"--",40,0,0,0,0.0,EVENT_MENU);
    TUTORmodify_menu(eBar,"Style","--",0,-1,-1);
    TUTORadd_menu(eBar,"Style",30,justNames[3],50,0,edit_region,FULLJUST,(double) PARASTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,justNames[0],50,0,edit_region,LEFTJUST,(double) PARASTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,justNames[1],50,0,edit_region,CENTERJUST,(double) PARASTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,justNames[2],50,0,edit_region,RIGHTJUST,(double) PARASTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,"---",60,0,0,0,0.0,EVENT_MENU);
    TUTORmodify_menu(eBar,"Style","---",0,-1,-1);
    TUTORadd_menu(eBar,"Style",30,"Normal",70,0,edit_region,DEFSTYLE,(double) HOTSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,"Hot",70,0,edit_region,1,(double) HOTSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Style",30,"----",80,0,0,0,0.0,EVENT_MENU);
    TUTORmodify_menu(eBar,"Style","----",0,-1,-1);
    TUTORadd_menu(eBar,"Style",30,"Plainest",90,0,edit_plain,0,0.0,EVENT_MENU);
    
    TUTORadd_menu(eBar,"Color",40,"Default",10,0,edit_region,DEFSTYLE,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Black",10,0,edit_region,0,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"White",10,0,edit_region,1,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Red",10,0,edit_region,2,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Green",10,0,edit_region,3,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Blue",10,0,edit_region,4,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Yellow",10,0,edit_region,5,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Cyan",10,0,edit_region,6,(double) COLORSTYLE,EVENT_MENU);
    TUTORadd_menu(eBar,"Color",40,"Magenta",10,0,edit_region,7,(double) COLORSTYLE,EVENT_MENU);
    
    /* now look thru the menu data to find font names */
    TUTORadd_menu(eBar,"Font",40,"Default",10,0,edit_region,DEFSTYLE,(double) FONTSTYLE,EVENT_MENU);
    HLock((Handle)tempM);
    fName = (char *) &(*tempM)->menuData;
    fName += *fName+1; /* skip menu title */
    for (ii=0; ii<200; ii++)
        { /* no more than 200 font families (!) */
        fNLen = *fName;
        PtoCstr((unsigned char *)fName);
        fontNum = (int)TUTORinq_symbolic_font_id(fName);
        /* fontNum is < 0 for unknown font, but don't load unknown font until it is used... */
        TUTORadd_menu(eBar,"Font",40,fName,10,0,edit_region,fontNum,(double) FONTSTYLE,EVENT_MENU);
        fName += fNLen+5;
        if (!*fName)
            break; /* no more fonts */
        }
    HUnlock((Handle)tempM);
    TUTORadd_menu(eBar,"Font",40,"Icon",10,0,edit_icon,0,0.0,EVENT_MENU);
    DisposeMenu((MenuHandle)tempM);

#ifndef CTEDIT
    if (ctexec)
        {
        TUTORadd_menu(eBar,NIL,50,"Run from beginning",10,'A',edit_run,0,0.0,EVENT_MENU);
        TUTORadd_menu(eBar,NIL,50,"Execute current unit",10,0,edit_execcur,0,0.0,EVENT_MENU);
        TUTORadd_menu(eBar,NIL,50,"Select unit",10,0,edit_selunit,0,0.0,EVENT_MENU);
        TUTORadd_menu(eBar,NIL,50,"Run from selected unit",10,'K',edit_runfrom,0,0.0,EVENT_MENU);
        TUTORadd_menu(eBar,NIL,50,"Execute selected unit",10,'E',edit_rununit,0,0.0,EVENT_MENU);
        TUTORadd_menu(eBar,NIL,50,"Quit running",10,0,exec_quit,3,0.0,EVENT_MENU);
        TUTORmodify_menu(eBar,NIL,"Quit running",0,-1,-1);
        TUTORadd_menu(eBar,NIL,50,"-",15,0,0,0,0.0,EVENT_MENU);
        TUTORmodify_menu(eBar,NIL,"-",0,-1,-1);
        }
    TUTORadd_menu(eBar,NIL,50,"Make Binary",20,0,edit_compile,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,NIL,50,"Preferences",20,0,edit_prefer,0,0.0,EVENT_MENU);
 /*   TUTORadd_menu(eBar,NIL,50,"---",40,0,0,0,0.0,EVENT_MENU);
    TUTORmodify_menu(eBar,NIL,"---",0,-1,-1); */
    TUTORadd_menu(eBar,"Window",50,"Help on cT",50,0,edit_help,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Window",50,"Commands",60,0,edit_command,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Window",50,"Message",61,0,edit_message,0,0.0,EVENT_MENU);
    TUTORadd_menu(eBar,"Window",50,"Debug",62,0,edit_debug,0,0.0,EVENT_MENU); 
    TUTORadd_menu(eBar,"Window",50,"Exec",63,0,edit_execfwd,0,0.0,EVENT_MENU);

    if (macKind & 16)
        { /* mac II, show "SE" menu item */
 /*       TUTORadd_menu(eBar,NIL,50,"----",70,0,0,0,0.0,EVENT_MENU);
        TUTORmodify_menu(eBar,NIL,"----",0,-1,-1); */
        TUTORadd_menu(eBar,"Window",50,"Mac SE window",80,0,edit_sewind,0,0.0,EVENT_MENU);
        TUTORadd_menu(eBar,"Window",50,"Mac II window",80,0,edit_sewind,1,0.0,EVENT_MENU);
        }
#endif /* CTEDIT */
    
    return(eBar);
    }

#endif /* MAC else */
