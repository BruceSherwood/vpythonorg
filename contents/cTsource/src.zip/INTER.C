
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>
/* #include <math.h> */

#include "baseenv.h"
#include "compute.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "editor.h"
#include "exprdefs.h"
#include "yacc.h"
#include "eglobals.h"

#ifdef ctproto
extern int  assoc_name(struct  _fref FAR *fn,struct  _fref FAR *bfilen,char  *extnNew);
extern int AppendSlash(char *str);
extern int EqFloat(double v1,double v2);
extern int log10_div(double value,double *divider);
extern int TstIndefinite(double val);
extern int abs(int val);
extern int TUTORshow(int type,double value, int sigfig, char *ss);
int  settitles(char  *filename);
int  StopProgram(char  *s);
int  TriggerEvent(int  (*routine)());
int  TriggerEventTime(int  (*routine)(),long  t);
int  sync(void);
int  TellUser(char  *str);
int  setmainfile(struct  _fref FAR *filename);
int  AlteredSource(long  pos,long  len,long  newLen);
int  RestoreUnit(unsigned int  unitH,char  FAR *up,long  uLen,int  unitn);
int  RestoreReloc(unsigned int  unitH,char  FAR *up,long  uLen,int  unitn);
int  GetUnitName(int  unitn,unsigned char  *name);
int  MatchUnitName(unsigned char  *name);
int  AddUnitName(unsigned char  *name,int  unitNum);
int  assign_pfun(long  addr,long  pfunct);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  TUTORset_view(struct  tutorview FAR *vp);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  RefreshPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  cpos,long  clen,long  newC,long  selStart,long  selLen,int  scroll,int force);
char  FAR *GetPtr(unsigned int  mm);
struct  tutorview FAR *TUTORinq_view(void);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
int  TUTORcopy_fileref_dir(struct  _fref FAR *dirname,struct  _fref FAR *fullname);
int  TUTORcmp_fileref(struct  _fref FAR *f1,struct  _fref FAR *f2);
int  editormsg(char  *ss,int  aFlag);
int  TUTORtrace(char  *s);
int  TUTORsync(void);
int  flush(void);
int  TUTORpost_event(struct  tutorevent *event);
int  myexit(void);
int  TUTORpoll_events(int  block);
int  ClearExecTiming(void);
int  TMessage(char FAR *s);
int  TUTORset_window_title(int  wid,char  *wt);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
int  strcmpf(char  FAR *aa,char  FAR *bb);
int  TUTORdump(char  *s);
int  TUTORclose(int  findx);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
int  TUTORseek(int  findx,long  pos);
extern double power10(int arg);
#endif /* ctproto */

extern  struct tutorview FAR *TUTORinq_view();
extern char *machinename();
long TUTORwrite(), TUTORread();
char *strf2n();
extern int RestoreBinaryStub();
long TUTORinq_file_pos();
extern double power10();

#ifdef ANDREW
extern long getpid();
#endif

/* ******************************************************************* */

settitles(filename) /* set editor/executor window titles */
char *filename;

{   char wt[38]; /* title string */
    
    wt[35] = 0; /* insure terminated */
    strncpy(wt,filename,35);
    if (EditVp[0])
        TUTORset_window_title(EditWn[0],wt);
	if (ExecVp) {   
		TUTORset_window_title(ExecWn,wt);
	}

} /* settitles */

/* ******************************************************************* */

StopProgram(s)
char *s;

{
    if (!s)
        s = "Insufficient memory available.";

    TMessage((char FAR *)s);
    ClearExecTiming();
    do {
        nevents = 0;    /* kill event queue */
        TUTORpoll_events(FALSE); /* swallow pending events */
    } while (nevents);
    while (nevents == 0) TUTORpoll_events(TRUE); /* wait for something */
    myexit();

} /* StopProgram */

/* ******************************************************************* */

int TriggerEvent(routine) /* set up event to execute specified routine */
int (*routine)(); 

{   struct tutorevent event;
    
    event.type = EVENT_PROC;
    event.window = ExecWn; /* execute window */
    event.view = ExecVp; /* execute view */
#ifdef THINKC5
    event.vproc = (int(*)(...))routine;  /* routine to call */
#else
    event.vproc = (int(*)())routine;  /* routine to call */
#endif
    event.timestamp = 0; /* no time delay */
    event.eDataP = FARNULL;
    return(TUTORpost_event(&event));

} /* TriggerEvent */

/* ******************************************************************* */

int TriggerEventTime(routine,t) /* que routine for t msec from now */
int (*routine)();   /* routine to call */
long t;         /* number milliseconds from now */

{   struct tutorevent event;
    
    event.type = EVENT_PROC;
    event.window = ExecWn; /* edit window */
    event.view = ExecVp; /* edit view */
#ifdef THINKC5
    event.vproc = (int(*)(...))routine;  /* routine to call */
#else
    event.vproc = (int(*)())routine;  /* routine to call */
#endif
    event.timestamp = t; /* set time delay */
    event.eDataP = FARNULL;
    return(TUTORpost_event(&event));

} /* TriggerEventTime */

/* ******************************************************************* */

sync()  /* sync with window manager */

{
    flush();
    TUTORsync();

} /* sync */

/* ******************************************************************* */

TellUser(str)   /* bottom-line message */
char *str;

{   struct tutorview FAR *cv;   /* current view number */

    if (!EditVp[0]) {
        TUTORtrace(str);
        return(0);
    } else {
        cv = TUTORinq_view();
        TUTORset_view(EditVp[0]); /* set to editor view */
        editormsg(str,TRUE);
        TUTORset_view(cv); /* restore to previous view */
    } /* else */

} /* TellUser */

/* ******************************************************************* */

setmainfile(filename)   /* set main (editing/executing) file */
FileRef FAR *filename;

{   long modtim; /* time file last modified */
    EditDat FAR *ep;

    if (TUTORcmp_fileref(filename,&sourcetable[0].fRef) != 0) {
        TUTORcopy_fileref(&sourcetable[0].fRef,filename);
    }
    TUTORcopy_fileref_dir(sourceDirP, filename); /* reset sourceDir */
    TUTORcopy_fileref_dir(currentDirP, filename);
    if (ctedit) {
        ep = (EditDat FAR *) GetPtr(ed1H);
        TUTORcopy_fileref(&ep->filename,filename);
        ReleasePtr(ed1H);
        KillPtr(ep);
    } /* ctedit if */
    TUTORinq_file_info(&sourcetable[0].fRef,NEARNULL,NEARNULL,
             &modtim,NEARNULL,NEARNULL);
    sourcetable[0].mtime = modtim;

} /* setmainfile */

/* ******************************************************************* */

AlteredSource(pos,len,newLen)   /* update for change to source file (grafedit) */
long pos,len,newLen;

{   struct tutorview FAR *cv;   /* current view number */
    EditDat FAR *ep;
    TextVDat FAR *vp;
    long selPos,selLen;

	if (CurEditWi < 0) return(0);
    if (!EditVp[CurEditWi]) return(0); /* no editor to update */
    cv = TUTORinq_view();
    TUTORset_view(EditVp[CurEditWi]); /* set to editor view */
    ep = (EditDat FAR *) GetPtr(windowsP[EditWn[CurEditWi]].wH);
    vp = (TextVDat FAR *) GetPtr(ep->textPanel);
    if (len != 0)
        {
        selPos = pos;
        selLen = newLen;
        }
    else
        {
        selPos = pos+newLen;
        selLen = 0;
        }
    RefreshPanel(vp,pos,len,pos,len,newLen,selPos,selLen,TRUE,FALSE);
    ReleasePtr(ep->textPanel);
    KillPtr(vp);
    ReleasePtr(windowsP[EditWn[CurEditWi]].wH);
    KillPtr(ep);
    TUTORset_view(cv); /* restore to original view */

} /* AlteredSource */

/*********************************************************************/

RestoreUnit(unitH,up,uLen,unitn) /* restore unit's binary from disk */
Memh unitH; /* handle to unit being restored (not used) */
char FAR *up; /* pointer to place to restore unit binary */
long uLen; /* length of unit */
int unitn;
    
{   int bFile; /* binary file */
    long TUTORread();

#ifdef CTDEBUG
#ifdef AUTHOR
    TUTORdump("RestoreUnit called while authoring");
#endif
#endif
    if (exS.useCompiled && unittab[unitn].bdskadr >= 0) {
        bFile = TUTORopen(&binaryFile,TRUE,FALSE,FALSE);
        TUTORseek(bFile,unittab[unitn].bdskadr);
        /* note unit[unitn].pcodeBetaL should == uLen */
        TUTORread(up,1,(long) unittab[unitn].pcodeBetaL,bFile);
        TUTORclose(bFile);
    } else if (unittab[unitn].pdskadr >= 0) {
        bFile = TUTORopen(&binaryFile,TRUE,FALSE,FALSE);
        TUTORseek(bFile,unittab[unitn].pdskadr);
        /* note unit[unitn].pcodeAlphaL should == uLen */
        TUTORread(up,1,(long) unittab[unitn].pcodeAlphaL,bFile);
        TUTORclose(bFile);
    } else
        TUTORdump("Reread non-disk binary?");
    
    return(0);

} /* RestoreUnit */

/*********************************************************************/

RestoreReloc(unitH,up,uLen,unitn) /* restore unit's reloc table from disk */
Memh unitH; /* handle to unit being restored (not used) */
char FAR *up; /* pointer to place to restore unit binary */
long uLen; /* length of unit */
int unitn;
    
{   int bFile; /* binary file */
    long TUTORread();
    long len;

    if (unittab[unitn].rdskadr >= 0) {
        bFile = TUTORopen(&binaryFile,TRUE,FALSE,FALSE);
        TUTORseek(bFile,unittab[unitn].rdskadr);
        len = unittab[unitn].nrefs*sizeof(struct locref);
        TUTORread(up,1,len,bFile);
        TUTORclose(bFile);
    } else
        TUTORdump("Reread non-disk binary?");
    
    return(0);

} /* RestoreReloc */

/* ******************************************************************* */
/* ksw-documentation
    Unit name table
    The unit name table (structure is defined in tglobals.h) has unit entries
    sorted alphabetically (by byte value actually, so A accent > a).  There will
    be nunits entries in the table.
    Note that there is an implicit assumption that we may add unit names incrementally,
    but that when we get rid of unit names we get rid of all of them.  If this were
    not the case we would have to carefully delete entries.
*/

GetUnitName(unitn,name)
register int unitn; /* name we are looking for */
unsigned char *name; /* should be of length NAMEL+1 at least */
/* returns TRUE if we found the unit */
    {
    register int ii;
    struct unitnames FAR *np;
    register struct unitdat FAR *udp;
    int retVal;
    
    /* do linear search thru table to find unit number */
    np = (struct unitnames FAR *) GetPtr(unitNames);
    udp = (struct unitdat FAR *) &np->udata[0];
    retVal = FALSE;
    for (ii=0; ii<nunits; ii++,udp++)
        {
        if (udp->unitnum == unitn)
            {
            retVal = TRUE;
            break; /* we found it */
            }
        }
    
    if (retVal)
        { /* copy name */
        strcpyf((char FAR *) name, (char FAR *) udp->name);
        }
    
    ReleasePtr(unitNames);
    KillPtr(np);
    
    return(retVal);
    }

/* ******************************************************************* */

MatchUnitName(name)
unsigned char *name;
/* returns unit number matching name, or -1 if no match found */
    {
    struct unitnames FAR *np;
    struct unitdat FAR *basep, FAR*lowp, FAR *midp, FAR *highp;
    int ii;
    int unitN;
    
    if (nunits < 1)
        return(-1); /* no units */

    if ((name == NEARNULL) || (*name == 0)) 
        return(-1);

    /* binary chop search */
    
    np = (struct unitnames FAR *) GetPtr(unitNames);
    lowp = basep = (struct unitdat FAR *) &np->udata[0];
    highp = lowp + nunits-1; /* there are nunits entries in the table */
    unitN = -1; /* assumme not found */
    
    while (lowp <= highp) {
        midp = lowp + (highp - lowp)/2;
        ii = strcmpf((char FAR *) name,(char FAR *) midp->name);
        if (ii == 0) { /* we found match */
            unitN = midp->unitnum;
            break;
        } else if (ii > 0)
            lowp = midp+1;
        else {
            if  (midp == basep) 
                break; /* can't allow PC pointer arith wraparound */
            highp = midp-1;
        }
    }
    
    ReleasePtr(unitNames);
    KillPtr(np);
    
    return(unitN);
    }

AddUnitName(name,unitNum)
unsigned char *name;
int unitNum;
    {
    struct unitnames FAR *np;
    struct unitdat FAR *lowp, FAR *midp, FAR *highp;
    int ii;
    long nMove;
    
    np = (struct unitnames FAR *) GetPtr(unitNames);
    
    lowp = (struct unitdat FAR *) &np->udata[0];
    if (nunits > 0)
        { /* binary chop search to find where to put unit */
        highp = lowp + nunits-1; /* there are nunits entries in the table */
        
        while (lowp <= highp)
            {
            midp = lowp + (highp - lowp)/2;
            ii = strcmpf((char FAR *) name,(char FAR *) midp->name);
            if (ii == 0)
                { /* we found match! */
                break;
                }
            else if (ii > 0)
                lowp = midp+1;
            else
                highp = midp-1;
            }
        
        if (lowp <= highp)
            { /* we found a match.  Make lowp point at entry following this one */
            lowp = midp+1;
            }
        /* else lowp already in the right place */
        }
    
    /* at this point lowp is pointing where we want to put the new entry */
    
    /* move following data */
    ii = lowp - (struct unitdat FAR *) &np->udata[0]; /* index of lowp */
    nMove = (long) sizeof(struct unitdat)*(nunits - ii);
    TUTORblock_move((char SHUGE *) lowp, (char SHUGE *) (lowp+1),nMove);

    /* put in new data */
    lowp->unitnum = unitNum;
    strcpyf((char FAR *) lowp->name,(char FAR *) name);
    
    ReleasePtr(unitNames);
    KillPtr(np);
    }

/* ******************************************************************* */

TUTORshow(arg_type,arg_value,arg_sigfigs,arg_str)
int arg_type; /* type of show (0 = -show-, 1 = -showz-, 2 = -showe-) */
double arg_value; /* floating value to show */
int arg_sigfigs; /* number significant digits to display */
char *arg_str; /* pointer to result string (should be at least 64 long) */

{   double wvalue; /* working floating value */
    int sigfigs; /* number significant figures to show */
    double flogval; /* floating log10 of value */
    int logval; /* log10 of value */
    int alogval; /* abs(log10 of value) */
    int sign; /* TRUE if negative value */
    int integerf; /* TRUE if integer value */
    long ivalue; /* integer form of value */
    int roundp; /* exponent of rounding value */
    double round; /* amount to round */
    int expform; /* TRUE if should display in exponential form */
    int leading; /* number leading zeros for fraction */
    int dii; /* digit index */
    int digit; /* current decimal digit */
    int digitcount; /* number digits needed */
    int decindx; /* index for decimal point */
    double divider;
    double fdigit; /* current decimal digit */
    char *cp; /* pointer in result string */

    wvalue = arg_value; /* pick up arguments */
    sigfigs = arg_sigfigs;
    cp = arg_str;
    if (sigfigs < 1) sigfigs = 1; /* sanity checks */
    if (sigfigs > 62) sigfigs = 62; 
    
    /* check for special cases 0, Infinite, Indefinite */

    if (EqFloat(wvalue,0.0)) {
        if (arg_type == 1) {
            for(dii=0; dii<sigfigs; dii++) {
                *cp++ = '0';
                if ((dii == 0) && (sigfigs > 1))
                    *cp++ = '.'; /* add decimal point */
            } /* dii for */
            *cp = 0; /* terminate string */
        } else {
            strcpy(cp,"0");
        }
        return(0);
    } else if (EqFloat(wvalue,Infinite)) {
        strcpy(cp,"INF");
        return(0);
    } else if (TstIndefinite(wvalue)) {
        strcpy(cp,"NAN");
        return(0);
    } 

    /* set up for numeric show */

    sign = wvalue < 0.0;
    wvalue = fabs(wvalue); /* work with positive numbers only */
    ivalue = floor(wvalue); /* convert to integer */
    integerf = (wvalue == (double)(ivalue)); /* TRUE if integer */
      
    /* check if should display in exponential form */
    
    logval = log10_div(wvalue,&divider);
    alogval = abs(logval);    
    digitcount = alogval+1;
    expform = FALSE; /* assume will display in normal form */
    if ((arg_type == 2) || (digitcount > sigfigs) || (wvalue < 0.0001))
        expform = TRUE;
    
    if (expform) {

        /* display in exponential form */
    
    	/* round value */
    
    	roundp = logval-sigfigs;
    	round = 5*power10(roundp);
    	wvalue = wvalue+round;
    	if (wvalue > (divider*10.0)) /* re-compute if rounded up */
        	logval = log10_div(wvalue,&divider);
   		 alogval = abs(logval);   
   		  
        for (dii=0; dii<sigfigs; dii++) {
            if (dii == 0) {
                if (sign)
                    *cp++ = '-'; /* insert sign if negative */
            } /* dii if */
            fdigit = floor(wvalue/divider);
            digit = fdigit;
            *cp++ = digit+'0';
            if ((dii == 0) && (sigfigs > 1)) {
                *cp++ = '.'; /* add decimal point */
            }
            wvalue = wvalue-(fdigit*divider);
            divider = divider/10.0;
        } /* dii for */
        *cp = '\0'; /* terminate string */
        
        /* add exponent */

        if (logval) {
            if (logval < 0)
                strcat(cp,"E-");
            else
                strcat(cp,"E+");
            cp += 2; /* adjust end-of-string pointer */
            if (alogval < 10) {
                strcat(cp,"0");
                cp++;
            }
            sprintf(cp,"%d",alogval); /* add exponent value */
        } /* logval if */
    } else {

        /* display in normal form */
    
    	/* round value */
    
    	if (logval < 0)
    		sigfigs++; /* account for leading zero */
    	roundp = logval-sigfigs;
    	if (logval < 0)
    		roundp = (-sigfigs);
    	round = 5*power10(roundp);
    	wvalue = wvalue+round;
    	if (wvalue > (divider*10.0)) /* re-compute if rounded up */
        	logval = log10_div(wvalue,&divider);
    	alogval = abs(logval);    
    
        if (integerf && (arg_type != 1) && (logval >= 0) && (logval < 10)) {

            /* use sscanf function for simple integer */

            if (sign) ivalue = -ivalue; /* restore sign */
            sprintf(cp,"%ld",ivalue);
        } else {

            /* figure out where to put decimal point */

            if (integerf && (arg_type != 1)) decindx = -1; /* no decimal point */
            else if (logval < 0)
                decindx = -1; /* decimal point already handled */
            else decindx = logval+1;
            leading = 0; /* no leading zeros after decimal pt yet */
            if (logval < 0)
                leading = alogval; /* number leading zeros */

            /* loop to display value */

            for (dii=0; dii<sigfigs; dii++) {
                if ((dii == 0) && sign)
                    *cp++ = '-'; /* insert sign if negative */
                if (dii == decindx) {
                    decindx = -2; /* flag did decimal point */
                    *cp++ = '.'; /* add decimal point */
                }
                if (dii < leading) {
                    *cp++ = '0'; /* fill in leading zeros */
                    if (dii == 0) {
                        *cp++ = '.'; /* add decimal point */
                        decindx = -2; /* did decimal point */
                    }
                } else {
                    fdigit = floor(wvalue/divider);
                    digit = fdigit;
                    *cp++ = digit+'0';
                    wvalue = wvalue-(fdigit*divider);
                    divider = divider/10.0;
                }
            } /* dii for */
            *cp = '\0'; /* terminate string */
            
            /* strip (fractional) trailing zeros */
            
            if ((arg_type != 1) && (decindx == -2)) { /* decimal point is in string */
                while (*(--cp) == '0') 
                    *cp = '\0'; /* strip trailing zeros */
                if (*cp == '.')
                    *cp = '\0'; /* and trailing decimal point */
            }
        } /* integer else */
    } /* expform else */

    return(0);

} /* TUTORshow */

/* ******************************************************************* */

static int log10_div(value,divp) /* compute log10 and divider */
double value; /* value to take log of */
double *divp; /* pointer to (returned) divider */

{   double divider;
    int logval;
    
    logval = floor(log10(value));
    divider = power10(logval);
    if (value > (divider*10.0)) {
        logval++;
        divider = power10(logval);
    }
    if (value < divider) {
        logval--;
        divider = power10(logval);
    }
    *divp = divider; /* return divider */
    return(logval); /* return log10 */
    
} /* log10_div */

/* ******************************************************************* */

/* ******************************************************************* */

int EqFloat(value1,value2) /* check floating values exactly equal */
double value1;
double value2;

{   unsigned char *vptr; /* pointer in value */
    unsigned char *wptr; /* pointer in Infinite */
    int inx;
    
    /* do compare the hard way to avoid using coprocessor's */
    /* idea of == compare */
    
    vptr = (unsigned char *)&value1;
    wptr = (unsigned char *)&value2;
    for(inx=0; inx<sizeof(double); inx++)
        if (*vptr++ != *wptr++)
            return(FALSE); /* did not compare */
    return(TRUE);

} /* EqFloat */

/* ******************************************************************* */

/* special kludge for IBM-RT - bypass type checking */

int assign_pfun(addr,pfunct) /* assign to pointer to function */
long addr; /* address of pointer */
long pfunct; /* address of function */

{
    *((long SHUGE *) addr) = pfunct;

} /* assign_pfun */


/* ******************************************************************* */
