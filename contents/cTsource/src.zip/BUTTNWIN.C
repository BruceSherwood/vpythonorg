
/* (c) Copyright Carnegie-Mellon University, 1988. */
/* May be used and copied freely for educational purposes, */
/* but may not be sold without the written consent of Carnegie-Mellon University. */

#include <stdio.h>
#include "baseenv.h"
#include "kdefs.h"
#include "tutor.h"
#include "editor.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "edglobal.h"
#include "compute.h"
#include "txt.h"
#include "fkeys.h"
#include "kglobals.h"
#include "prefs.h"
#include "editmenu.h"    
#include "eglobals.h"

#define MAXTITLE 81
typedef struct _buttonD {
    Memh owner;
    struct tutorview FAR *view; /* view of button */
    Memh ebshdrH; /* handle on ct object header (if any) */
    int ebsref; /* reference count on ct object header */
    int thick; /* thickness of button */
    int bFont; /* font to draw label in */
    char state; /* button state (1 if normal, 0 if gray) */
    char lastDraw; /* 0 = never, 1 = normal, 2 = highlight */
    char dddu;
    char eraseF; /* TRUE if we should erase on destroy */
    struct tutorColor fColor; /* button foreground color */
    struct tutorColor bColor; /* button background color */
    struct tutorColor dkGrey; /* dark  grey (if foreground black) */
    struct tutorColor ltGrey; /* light grey (if foreground black) */
    struct tutorColor bodyColor;
    struct tutorColor eColor; /* color to erase with */
    char value; /* button's value (0 or 1 usually) */
    char exValue; /* executor value for button */
    char title[MAXTITLE+1]; /* label on button */
    Memh titleDoc; /* styled label on button */
    short tx, ty; /* pen position (relative to button) for drawing title */
    Memh destH; /* data for "button pressed" signal */
    int (*DestProc)(); /* proc for "button pressed" signal */
    int destMsg; /* message for "button pressed" signal */
    int destMsg1;
    double destMsg2;
    int kind; /* button kind 0: normal, 1: check, 2: radio */
    int button_is_up; /* for eliminating flickering on mouse drags */
} ButtonDat;


/* button kinds */
#define NORMALBUTTON 0
#define RADIOBUTTON 2
#define CHECKBOXBUTTON 1
#define THREEDBUTTON 3


#ifdef ctproto    
extern int TUTORzero(char FAR *ss,long len);  
extern char *strcpy(char *aa,char *bb);
int  tdoc_getstyles(unsigned int  theD,long  pos,short  *styles);
int  TUTORstyle_doc(unsigned int  doc,long  pos,long  len,int  type,int  dat,int  canCombine,long  *extraPos);
int  write_abs_text(unsigned int  textDoc,long  startSel,long  endSel,int  xstart,int  ystart,struct  _trect FAR *marginR,int  wrap,int  *maxX,int  *maxY);
extern struct tutorview FAR *TUTORinq_button_view(Memh bH);
extern void TUTORset_color(int select,struct tutorColor FAR *newColor);
long TUTORparse_font_family(struct  _fref *fontTag,struct  _fref *familyName,int  isFont,int  oneTag,int  *fontSize);
extern char *PrefFaceStr(int index);
extern char *PrefColorStr(int index);
extern int PrefColorN(char *str);
long TUTORinq_symbolic_font_id(char  *fontName);
extern int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
extern int get_button_ref(Memh bH);
extern char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  TUTORalert(int  wn,char  *msg);
int  TUTORsavefile_dialog(int  wn,char  *msg,struct  _fref *filename,int  maxRet);
int  TUTORedit_dialog(int  wn,char  *msg,char  FAR *retS1,char *msg2,char  FAR *retS2,int  maxRet);
int  TUTORync_dialog(int  wn,char  *msg);
int  TUTORreadfile_dialog(int  wn,char  *msghdr,struct  _fref *filename,char *sname,int  maxRet,int  type,int  msgb,int  doRedraw);
extern int  SizeReadfileDialog(int  wn,struct  _trect FAR *bounds,struct  _DItem FAR *bb,int  redrawF);
int  TUTORmulti_line_dialog(int  wn,char  FAR * *msg,int  nmsg);
extern unsigned int  TUTORstart_dialog(int  wn,struct  _trect *bounds,int  kind,int  nItems,struct  _DItem *items,int  defaultB);
extern int  TUTORrun_dialog(unsigned int  dialog);
int  procdialogw(unsigned int  dialog,struct  tutorevent *event);
extern int  TUTORgettext_dialog(unsigned int  dialog,int  itemN,char  FAR *cp,int  maxChar);
extern int  TUTORclose_dialog(unsigned int  dialog,int  doRedraw);
int  procdialog(unsigned int  dialog,struct  tutorevent *cev);
extern int  TUTORdraw_dialog(struct  _dialinf FAR *dp,int  drawViews);
extern int  DrawItem(struct  _DItem *ip,int  drawAll);
extern int  DialogKeys(unsigned int  dialog,struct  tutorevent *cev);
extern int  ShiftFocusDialog(unsigned int  dialog,int  nChange);
int  ChangeFocusDialog(unsigned int  dialog,int  newItem,int  isClick,struct tutorevent *event);
extern int  ActivateDialogItem(struct  _dialinf FAR *dp,int  item,int  onoff);
extern int  KeyFilterDialog(long  dViewH,unsigned int  textv,struct  tutorevent *cev);
int  StartCompileMsg(int  wn);
int  EditCompileMsg(int  wn,char  *ms);
int  EndCompileMsg(int  wn);
unsigned int  TUTORnew_button(int  wn,unsigned int  owner,unsigned int	objH,int objR,
struct	_trect *tr,int	kind,int  thick,int  bFont,char  *title,unsigned int titleD,
unsigned int  destH,int  (*DestProc)(),int  destMsg,int  destMsg1,double  destMsg2,
int  erase);
int  TUTORreset_button(unsigned int  bH,int  value,int  aFlag,int  eraseF);
int  TUTORinq_button_value(unsigned int  bH);
int  TUTORmove_button(unsigned int  bH,int  left,int  top,int  right,int  bottom);
int  TUTORclose_button(unsigned int  bH);
int  CThighlight_normal_button(struct  _buttonD FAR *bp);
int  CThighlight_checkbox_button(struct  _buttonD FAR *bp);
int  CThighlight_radio_button(struct  _buttonD FAR *bp);
int  CThighlight_3D_button(struct  _buttonD FAR *bp);
int  CThighlight_button(unsigned int  bH);
int  procbutton(unsigned int  bH,struct  tutorevent *event);
int  TUTORdraw_button(unsigned int  bH);
int  TUTORdraw_normal_button(struct  _buttonD FAR *bp);
int  TUTORdraw_3D_button(struct  _buttonD FAR *bp);
int  TUTORdraw_radio_button(struct  _buttonD FAR *bp);
int  TUTORdraw_checkbox_button(struct  _buttonD FAR *bp);
int  OpenFileDialog(unsigned int  dialog,int  itemN);
int  ESTextSelect(unsigned int  dialog,unsigned int  edH,struct  tutorevent *event);
int  TUTORset_rect(struct  _trect *r,int  left,int  top,int  right,int  bottom);
int  TUTORcvt_path(char  *ssx,struct  _fref FAR *fRef,struct  _fref FAR *baseRef,int isFile);
char  *strf2n(char  FAR *strp);
int  TUTORdispose_dir(char  FAR *path);
int  TUTORfree_region(long  id);
int  TUTORabs_restore_region(long  id,int  x1,int  y1);
int  OpenFileDialogstub(unsigned int  dialog,int  itemN);
char  FAR *TUTORread_dir(struct  _fref FAR *fref);
long  TUTORabs_save_region(int  x1,int  y1,int  x2,int  y2);
extern char *strcat(char *aa, char *bb);
int  TUTORcopy_fileref_dir(struct  _fref FAR *dirname,struct  _fref FAR *fullname);
int  procdialogstub(unsigned int  hv,struct  tutorevent *event);
int  TUTORset_textfont(int  jj);
int  TUTORget_zfont(char  *famS,int  size);
int  CTset_background_color(int  color);
int  CTset_foreground_color(int  color);
int  TUTORset_view(struct  tutorview FAR *vp);
struct  tutorview FAR *TUTORinit_view(int  sW,unsigned int  vDat,int  (*vProc)());
struct  tutorview FAR *TUTORinq_view(void);
char  FAR *GetPtr(unsigned int  mm);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORinq_abs_string_width(unsigned char  FAR *s,int  lth,int  *dx);
int  strlenf(char  FAR *aa);
int  TUTORinq_font_info(int  *ascent,int  *descent,int  *maxwidth,int  *leading);
int  TUTORinq_select_line(unsigned int  theV,int  yy,long  *lineS,long  *lineL);
int  ESTextSelectstub(long  dialog,unsigned int  edH,struct  tutorevent *event);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,int ebsref,
    struct  _trect *theR,int  relInfo,int  mintw,int  wrap,unsigned int  doc,
    long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),int  ro,
    int  corner,int  erase,int  frame,int tabsz,int lm,int rm,int type);
int  TUTORinsert_string_doc(unsigned int  doc,long  pos,unsigned char  FAR *ss,long  sLen);
int  EditorDefaultStyles(unsigned int  doc);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  ReleasePtr(unsigned int  mm);
int  TUTORmessage(struct  tutorview FAR *vp,int  eKind,int  eVal);
int  TUTORset_select_tview(unsigned int  theV,long  pos,long  len,struct  _sbarinf *vb);
int  TUTORchange_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,unsigned char  FAR *cp,long  cLen,long  fromOff,unsigned int  styles,unsigned int  specialT,long  *extraPos,int  eupFlag);
int  TUTORclear_window(int  wid);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
int  interact(int  block);
int  TUTORflush(void);
int  procdialogwstub(unsigned int  dh,struct  tutorevent *event);
int  TUTORinq_event_mask(int  wid,int  eventc);
int  SetSelectPanel(struct  _tvdat FAR *vp,long  pos,long  len);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
int  TUTORset_abs_view_rect(int  x1,int  y1,int  w,int  h);
int  TUTORset_abs_clip_rect(struct  _trect FAR *cr);
int  TUTORforce_redraw(int  wix);
int  TUTORclose_view(struct  tutorview FAR *vp);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
long  TUTORget_len_doc(unsigned int  doc);
int  killptr(char  FAR * FAR *ptr);
int  TUTORpost_event(struct  tutorevent *event);
int  DrawPanel(unsigned int  edH);
int  TUTORdraw_text(unsigned char  FAR *buf,int  count);
int  TUTORabs_move_to(int  x,int  y);
int  TUTORinset_rect(struct  _trect FAR *rr,int  xx,int  yy);
int  TUTORframe_abs_rect(struct  _trect FAR *tr);
int  TUTORfree_handle(unsigned int  mm);
int  mvar_temp_cleanup(void);
extern char *strncpy(char *aa, char *bb, int nn);
int  RestartPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  selStart,long  selLen);
long  TUTORsearch_string_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sLen,long  pos,long  posEnd);
char  FAR *strcatf(char  FAR *aa,char  FAR *bb);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int  TUTORinq_select_tview(unsigned int  theV,long  *pos,long  *len);
extern int strlen(char *str);

char  FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
int  procbuttonstub(unsigned int  hv,struct  tutorevent *event);
int  TUTORabs_erase_rect(struct  _trect *tr,int  pattInd,int  pattC);
int  TUTORmove_rect(struct  _trect FAR *rr,int  xx,int  yy);
int  TUTORfill_abs_rect(struct  _trect FAR *tr,int  pattInd,int  pattC);
/* TUTORinq_is_dir() */
int  TUTORabs_line_to(int  x,int  y);
int  TUTORdraw_graphic_icons(int  iconFont,char  *s,int  len);
int  TUTORget_font2(long  fam,int  size,unsigned int  face,int cid);
long  TUTORinq_symbolic_font_id(char  *fontName);
int  TUTORdouble_click(short  *hh,short  *vv);
int  TUTORdump(char  *s);
extern double CoordToFloat(long cc);
#endif /* ctproto */

extern int OpenFileDialogstub();
extern int ESTextSelectstub();
extern char FAR *TUTORread_dir();
extern long TUTORsearch_string_doc();
extern char *PrefFaceStr();
extern int PrefFaceN();
extern char *PrefColorStr();
extern int PrefColorN();

/* default font height (in pixel size) for editor (newFontSize TRUE for edit & dict windows) */
#define DIALOGFONT "zsans"
#define DIALOGFSIZE 16

extern Memh MakeTextPanel();
extern Memh TUTORnew_doc();
extern long TUTORget_len_doc();
extern Memh TUTORnew_button();
extern int procbuttonstub();
extern int procbutton();
extern char *FullName ();

extern int procdialogstub();
extern int procdialogwstub();
extern struct tutorview FAR *TUTORinq_view();
extern struct tutorview FAR *TUTORinit_view();
extern Memh TUTORstart_dialog();
extern int KeyFilterDialog();
extern long TUTORabs_save_region();
extern char *strf2n();
extern int proceditstub();
extern long TUTORabs_save_region();
extern int TUTORdispose_dir();
extern void draw_button_text(); 
extern double CoordToFloat();

extern char *zcursorsStr;
extern char *ziconsStr;
extern char *zpatternsStr;

/* ******************************************************************* */

Memh TUTORnew_button(wn,owner,objH,objR,tr,kind,thick,bFont,title,titleD,destH,DestProc,destMsg,
                     destMsg1,destMsg2,erase)
int wn; /* window where button will appear */
Memh owner; /* where we send our filter messages */
Memh objH; /* handle on object header */
int objR; /* object reference count */
TRect *tr; /* where button goes */
int kind; /* button kind 0: normal, 1: check, 2: radio */
int thick; /* thickness of button */
int bFont; /* font label should be drawn in */
char *title; /* label on button */
Memh titleD; /* handle on document containing label on button */
Memh destH; /* data for "button pressed" signal */
int (*DestProc) (); /* proc for "button pressed" signal */
int destMsg, destMsg1; /* message for "button pressed" signal */
double destMsg2; /* message for "button pressed" signal */
int erase; /* TRUE if we should erase this button on destruction */

{   Memh bH;
    ButtonDat FAR *bp;
    FileRef fRef,famName;
    long famId;
    int ii, asc, desc, leading, height, insx;
    struct tutorview FAR *cv;
    TRect eR;
    long docLen;
    int maxX,maxY;
    int multiLine;
    TRect savClip;
    TRect tmpClip;
    short styles[NSTYLES];
    int zsansSize;
    double scale;

    bH = TUTORhandle("buttndat",(long) sizeof(ButtonDat),TRUE);
    if (!bH)
        return(0);

    if (kind == THREEDBUTTON)
		kind = NORMALBUTTON;

    bp = (ButtonDat FAR *) GetPtr(bH);
    TUTORzero((char FAR *)bp,(long)sizeof(ButtonDat));
    bp->button_is_up = 0;
    /* set up view */
    bp->view = TUTORinit_view(wn,bH,procbuttonstub);
    cv = TUTORinq_view();
    TUTORset_view(bp->view);
    TUTORset_abs_view_rect(tr->left,tr->top,tr->right - tr->left + 1,tr->bottom - tr->top + 1);
    if (cv) {
		bp->fColor = cv->fgndColor;
		bp->bColor = cv->bgndColor;
		bp->eColor = cv->winColor;
		TUTORset_color(0,&bp->fColor);
		TUTORset_color(1,&bp->bColor);
    } else {
		bp->fColor.palette = color_black;
		bp->fColor.red = bp->fColor.green = bp->fColor.blue = 0.0;
		bp->bColor.palette = color_white;
		bp->bColor.red = bp->bColor.green = bp->bColor.blue = 100.0;
		bp->eColor = bp->bColor;
    }
    if (titleD)
		bp->titleDoc = titleD;
    if (bFont < 0) {
	TUTORzero((char FAR *)&fRef,(long)sizeof(FileRef));
	/* strcpy(fRef.path,"system");	*/
	/* strcpy(fRef.path,"zfixed");	*/
	strcpy(fRef.path,"zsans");
	famId = TUTORparse_font_family(&fRef,&famName,2,FALSE,NEARNULL);
	zsansSize = 12;
	if (exS.RescaleT) {
	    scale = CoordToFloat((exS.ScaleX < exS.ScaleY) ? exS.ScaleX : exS.ScaleY);
	    if (scale < 1.0) {
			zsansSize = (int)(scale*zsansSize);
			if (zsansSize == 11) zsansSize = 10;
			else if (zsansSize == 9) zsansSize = 8;
			else if (zsansSize < 8) zsansSize = 8;
	    }
	}
	/* bFont = TUTORget_font2(famId,10,0,101); */
	bFont = TUTORget_font2(famId,zsansSize,style_bold,101);
    } /* bFont if */

    bp->view->caninput = FALSE;
    bp->ebshdrH = objH;
    bp->ebsref = objR;
    bp->thick = thick;
    bp->bFont = bFont;
    bp->state = 1; /* draw normally */
    bp->eraseF = erase;
    bp->value = 0;
    strncpyf(bp->title,(char FAR *) title,MAXTITLE);
    bp->title[MAXTITLE] = '\0';
    bp->destH = destH;
    bp->DestProc = DestProc;
    bp->destMsg = destMsg;
    bp->destMsg1 = destMsg1;
    bp->destMsg2 = destMsg2;
    bp->owner = owner;
    bp->dkGrey.red = bp->dkGrey.green = bp->dkGrey.blue = 50.0;
    bp->ltGrey.red = bp->ltGrey.green = bp->ltGrey.blue = 75.0;
    bp->bodyColor = bp->bColor; /* assume background color */
    bp->dkGrey.palette = bp->ltGrey.palette = color_rgb;
#ifndef CTEDIT
    if ((bp->fColor.palette == color_black) &&
	(bp->bColor.palette == color_white)) {
		bp->bodyColor = bp->ltGrey;
    }
#endif
    insx = 0; /* dont know inset yet */
    TUTORset_textfont(bFont);
 
    if (bp->titleDoc) { /* styled text */

	/* figure out where text should be */
		
	switch (kind) {
	    case RADIOBUTTON:
	    case CHECKBOXBUTTON:
		insx = 24; /* adjustment for inset */
		break;
	    case THREEDBUTTON:
		insx = 16; /* adjustment for inset */
		break;
	    default:
		break;
	} /* switch */

	/* force text to be centered if no paragraph style */
    	
	docLen = TUTORget_len_doc(bp->titleDoc);
	for(ii=0; ii<NSTYLES; ii++)
	    styles[ii] = DEFSTYLE;
	tdoc_getstyles(bp->titleDoc,0L,styles);
	if ((styles[PARASTYLE] == DEFSTYLE) && ((kind == 0) || (kind == 3))) {
	    TUTORstyle_doc(bp->titleDoc,0L,docLen,PARASTYLE,CENTERJUST,0,NEARNULL);
	}
        
	/* plot and measure the text */
        
	savClip = tgclipR; /* save clip rectangle */
	tmpClip.left = tmpClip.top = 0;
	tmpClip.right = tmpClip.bottom = 0;
	TUTORset_abs_clip_rect((TRect FAR *) &tmpClip); /* clip everything */
	eR = *tr;
	multiLine = write_abs_text(bp->titleDoc,0L,docLen,eR.left+insx,eR.top,(TRect FAR *)&eR,TRUE,&maxX,&maxY);
	TUTORinq_font_info(&asc,&desc,NEARNULL,&leading);
	height = 1+maxY-eR.top;
	bp->tx = insx;
	if (multiLine) {
	    bp->ty = ((eR.bottom-eR.top+1)-height)/2;
	} else {
	    height -= leading+desc;
	    bp->ty = ((eR.bottom-eR.top+1)-height)/2;
	} /* multiLine else */

	if (bp->ty < 0) bp->ty = 0;
	TUTORset_abs_clip_rect((TRect FAR *)&savClip); /* restore clip */

    } else { /* plain text */
 	
	/* figure out where text should be */

    	switch (kind) {
    	case RADIOBUTTON:
    	case CHECKBOXBUTTON:    
    	case THREEDBUTTON:
	    insx = 16; /* adjustment for inset */
	    break;
    	default:
	    break;
    	} /* switch */  
    	
	/* measure text */

	if (kind == NORMALBUTTON) {
	    TUTORinq_abs_string_width((unsigned char FAR *) title, strlen(title),&ii);
	    bp->tx = ((((tr->right-insx)-(tr->left+insx))+1) - ii) >> 1;
	} else bp->tx = 25;
    	TUTORinq_font_info(&asc,&desc,NEARNULL,NEARNULL);
    	bp->ty = asc + ((tr->bottom - tr->top+1) - (asc+desc))/2;
    }
    bp->kind = kind;
    ReleasePtr(bH);

    /* draw the button */

    TUTORdraw_button(bH);
    TUTORset_view(cv); /* restore the view */

    return(bH);

} /* TUTORnew_button */

/* ******************************************************************* */

int TUTORset_button_font(bH) /* set to button font */
Memh bH; /* handle on button info */

{	ButtonDat FAR *bp;
	int tFont;
 
	bp = (ButtonDat FAR *) GetPtr(bH);
	tFont = bp->bFont;
	ReleasePtr(bH);
	TUTORset_textfont(tFont);
	return(tFont);
	
} /* TUTORset_button_font */

/* ******************************************************************* */

TUTORreset_button(bH, value, aFlag, eraseF)
Memh bH;
/* each flag can be -1: (ignore) 0,1: new value */
int value;
int aFlag;
int eraseF;
    
{   REGISTER ButtonDat FAR *bp;
    int redraw;
    
    redraw =  FALSE;
    bp = (ButtonDat FAR *) GetPtr(bH);
    bp->button_is_up = 0;
    if (value != -1) {
	bp->value = bp->exValue = (value == 1);
        redraw = TRUE;
    }
    if (aFlag != -1) {
        bp->state = (aFlag == 1);
        redraw = TRUE;
    }
    if (eraseF != -1)
        bp->eraseF = (eraseF == 1);
    
    ReleasePtr(bH);
    KillPtr(bp);
    
    if (redraw)
        TUTORdraw_button(bH);  
    return(0);

} /* TUTORreset_button */

/* ******************************************************************* */

int TUTORinq_button_value(bH) /* get current value of button */
Memh bH;
    
{   ButtonDat FAR *bp;
    int value;
    
    bp = (ButtonDat FAR *) GetPtr(bH);
    if (bp->ebshdrH)
    	value = bp->exValue; /* use executor's copy of value */
    else
    	value = bp->value;
    ReleasePtr(bH);
    return(value);
    
} /* TUTORinq_button_value */

/* ******************************************************************* */
    
int TUTORupdate_button_value(objH) /* update executor value of button */
Memh objH; /* handle on cT object header */

/* executor keeps a separate copy of the button value which is */
/* updated when the EVENT_SIGNAL reaches the executor - this way */
/* zvalue(..) stays in synch with button unit execution */

{	struct ebshdr FAR *objP; /* pointer to cT object header */
    Memh bH; /* handle on button info */
    ButtonDat FAR *bp; 

    if (!objH) return(0);
    objP = (struct ebshdr FAR *)GetPtr(objH);
    bH = objP->objectH; /* handle on button data */
    ReleasePtr(objH);
    if (!bH) return(0);
    bp = (ButtonDat FAR *)GetPtr(bH);
    bp->exValue = bp->value; /* update executor's copy of value */
    ReleasePtr(bH);
    return(1);
    
} /* TUTORupdate_button_value */

/* ******************************************************************* */

struct tutorview FAR *TUTORinq_button_view(bH)
Memh bH; /* handle on button info */

{   ButtonDat FAR *bP;
    struct tutorview FAR *bV;

    if (!bH)
		return((struct tutorview FAR *)FARNULL);
    bP = (ButtonDat FAR *)GetPtr(bH);
    bV = bP->view;
    ReleasePtr(bH);
    return(bV);

} /* TUTORinq_button_view */

/* ******************************************************************* */

TUTORmove_button(bH, left, top, right, bottom) /* change button position, don't redraw */
Memh bH;
int left;
int top;
int right;
int bottom;
    {
    ButtonDat FAR *bp;
    struct tutorview FAR *cv;
    TRect rect;

    rect.bottom = bottom;
    rect.top = top;
    rect.left = left;
    rect.right = right;
    
    bp = (ButtonDat FAR *) GetPtr(bH);
    bp->lastDraw = 0;
    cv = TUTORinq_view();
    TUTORset_view(bp->view);
    TUTORset_abs_clip_rect((TRect FAR *)&rect);
    TUTORset_abs_view_rect(left,top,right-left,bottom-top);
    TUTORset_view(cv);
    ReleasePtr(bH);

    TUTORdraw_button(bH);
    return(0);
    }

TUTORclose_button(bH) /* close button */
Memh bH;
    {
    ButtonDat FAR *bp;
    struct tutorview FAR *bv;

    bp = (ButtonDat FAR *) GetPtr(bH);
    bv = bp->view;
    ReleasePtr(bH);

    TUTORclose_view(bv); /* this will call procbutton with destroy message */
    return(0);
    }



/* these are the routines to show the various buttons being pressed. */

CThighlight_button (bH)
Memh bH;
{
    ButtonDat FAR *bp;

    bp = (ButtonDat FAR *) GetPtr(bH);
/*    if (bp->button_is_up == 1) {  */
        bp->button_is_up = 0;
        switch (bp->kind) {
            case NORMALBUTTON:
                CThighlight_normal_button(bp);
                break;
            case RADIOBUTTON:
                CThighlight_radio_button(bp);
                break;
            case CHECKBOXBUTTON:
                CThighlight_checkbox_button(bp);
                break;
            case THREEDBUTTON:
                CThighlight_3D_button(bp);
                break;
        }
 /* }  */
    ReleasePtr (bH); 
    return(0);
}

procbutton(bH,event)    /* event processor buttons */
Memh bH;
struct tutorevent *event; /* event to process */
    {
    ButtonDat FAR *bp;
    struct tutorevent cev;
    int sendHit;
    TRect tr;
    struct tutorColor svColor;

    sendHit = FALSE;
    switch(event->type)
        {
	case EVENT_REDRAW:
	    bp = (ButtonDat FAR *) GetPtr(bH);
	    bp->lastDraw = 0;
	    ReleasePtr(bH);
            TUTORdraw_button(bH);
            break;

        case EVENT_DOWNMOVE:
            bp = (ButtonDat FAR *) GetPtr(bH);
            tr = bp->view->rr;
            /* are we still in the button rectangle? */
            if (!(event->x >= tr.left && event->x <= tr.right &&
                event->y >= tr.top && event->y <= tr.bottom))
            /* no, so redraw the button up if need be */
                TUTORdraw_button(bH);
            else
                CThighlight_button (bH);
            ReleasePtr (bH);
            break;

        case EVENT_LEFTUP:
            bp = (ButtonDat FAR *) GetPtr (bH);
            tr = bp->view->rr;
            if (event->x >= tr.left && event->x <= tr.right &&
                event->y >= tr.top && event->y <= tr.bottom)
                    sendHit = TRUE;
            ReleasePtr (bH);
            TUTORdraw_button(bH);
            break;

        case EVENT_LEFTDOWN:
            CThighlight_button(bH);
            break;

        case EVENT_DESTROY:
            bp = (ButtonDat FAR *) GetPtr(bH);
            if (bp->eraseF) { /* erase the button */
                tr = bp->view->rr;
		svColor = bgndColor; /* save background color */
		TUTORset_color(1,&bp->eColor);
                TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
		TUTORset_color(1,&svColor);
            }
            ReleasePtr(bH);
            KillPtr(bp);
            TUTORfree_handle(bH);
            break;
            
        default:
            break;
        }
    
    if (sendHit)
        { /* tell destination that button has been hit */
        bp = (ButtonDat FAR *) GetPtr(bH);
        if (bp->state)
            { /* enabled button */
			TUTORzero((char FAR *)&cev,(long)sizeof(struct tutorevent));
            cev.type = EVENT_SIGNAL;
            cev.window = -1; /* not sent to a window */
            cev.a5 = (long) bp->destH;
            cev.timestamp = 0;
	    cev.eDataP = FARNULL;
            cev.vproc = bp->DestProc;
            cev.a1 = bp->destMsg;
            cev.a2 = bp->ebshdrH;
			cev.a6 = bp->ebsref;
            cev.a3 = bp->destMsg2;
            cev.value = bp->destMsg1;
            TUTORpost_event(&cev);
            bp->value = !bp->value;
            TUTORdraw_button(bH);
            }
        ReleasePtr(bH);
        }

    return(0);
    }

/* ******************************************************************* */

static void draw_button_text(bp)
ButtonDat FAR *bp;

{   long docLen;
    int maxX,maxY;
    TRect tr;
   
    TUTORset_textfont(bp->bFont);
    tr = bp->view->rr;
    TUTORabs_move_to(tr.left+bp->tx,tr.top+bp->ty);
    if (bp->titleDoc) {
    	docLen = TUTORget_len_doc(bp->titleDoc);
    	write_abs_text(bp->titleDoc,0L,docLen,tr.left+bp->tx,tr.top+bp->ty,&bp->view->rr,TRUE,&maxX,&maxY);
    } else {
    	TUTORdraw_text((unsigned char FAR *) bp->title,strlenf((char FAR *) bp->title));
    }

} /* draw_button_text */

/* ******************************************************************* */

/* determine what kind of button it is, and dispatch
 * the pointer to the appropriate drawing routine.
 */
TUTORdraw_button(bH)
Memh bH;
    {
    ButtonDat FAR *bp;

    bp = (ButtonDat FAR *) GetPtr(bH);
/*    if (bp->button_is_up == 0) {  */
        bp->button_is_up = 1;
        switch (bp->kind) {
            case NORMALBUTTON:
                TUTORdraw_normal_button(bp);
                break;
            case RADIOBUTTON:
                TUTORdraw_radio_button(bp);
                break;
            case CHECKBOXBUTTON:
                TUTORdraw_checkbox_button(bp);
                break;
            case THREEDBUTTON:
                TUTORdraw_3D_button(bp);
                break;
        }
/*    }  */
    ReleasePtr (bH);  
    return(0);
}


/* ******************************************************************* */

TUTORdraw_normal_button(bp)
ButtonDat FAR *bp;

{   TRect tr;
    struct tutorColor hWhite;

    if (bp->lastDraw == 1)
		return(0); /* nothing to do */
    bp->lastDraw = 1;

    hWhite.palette = color_white;

    tr = bp->view->rr;
    TUTORset_color(0,&bp->bodyColor);
    TUTORset_color(1,&bp->bColor);

    /* erase what's currently there */
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_BLACK);
/*    TUTORinset_rect((TRect FAR *) &tr,2,2);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_BLACK);
    TUTORinset_rect((TRect FAR *) &tr,-2,-2);	*/

    /* outer frame of button */

/*  TUTORset_color(0,&bp->fColor);  */
    TUTORset_color(0,&bp->ltGrey);
    TUTORabs_move_to(tr.left,tr.top+1);
    TUTORabs_line_to(tr.left,tr.bottom-1);
    TUTORabs_move_to(tr.left+1,tr.top+1);
    TUTORabs_line_to(tr.left+1,tr.bottom-1);
    TUTORabs_move_to(tr.left+1,tr.top);
    TUTORabs_line_to(tr.right-1,tr.top);
    TUTORabs_move_to(tr.left+1,tr.top+1);
    TUTORabs_line_to(tr.right-1,tr.top+1);
    TUTORabs_move_to(tr.right,tr.top+1);
    TUTORabs_line_to(tr.right,tr.bottom-1);
    TUTORabs_move_to(tr.right-1,tr.top+1);
    TUTORabs_line_to(tr.right-1,tr.bottom-1);
    TUTORabs_move_to(tr.left+1,tr.bottom-1);
    TUTORabs_line_to(tr.right-1,tr.bottom-1);
    TUTORabs_move_to(tr.left+1,tr.bottom);
    TUTORabs_line_to(tr.right-1,tr.bottom);

    /* left, top of 3-d highlight */

    TUTORset_color(0,(struct tutorColor FAR *)&hWhite);
    TUTORabs_move_to(tr.left+2,tr.top+2);
    TUTORabs_line_to(tr.left+2,tr.bottom-2);
    TUTORabs_move_to(tr.left+3,tr.top+2);
    TUTORabs_line_to(tr.left+3,tr.bottom-3);
    TUTORabs_move_to(tr.left+3,tr.top+2);
    TUTORabs_line_to(tr.right-2,tr.top+2);
    TUTORabs_move_to(tr.left+3,tr.top+3);
    TUTORabs_line_to(tr.right-2,tr.top+3);

    /* bottom, right of 3-d highlight */

    TUTORset_color(0,&bp->dkGrey);
    TUTORabs_move_to(tr.right-3,tr.top+3);
    TUTORabs_line_to(tr.right-3,tr.bottom-2);
    TUTORabs_move_to(tr.right-2,tr.top+2);
    TUTORabs_line_to(tr.right-2,tr.bottom-2);
    TUTORabs_move_to(tr.left+3,tr.bottom-3);
    TUTORabs_line_to(tr.right-2,tr.bottom-3);
    TUTORabs_move_to(tr.left+2,tr.bottom-2);
    TUTORabs_line_to(tr.right-2,tr.bottom-2);

    TUTORset_color(0,&bp->fColor);
    draw_button_text(bp); 
    return(0);
	
} /* TUTORdraw_normal_button */

/* ******************************************************************* */

TUTORdraw_3D_button(bp)
ButtonDat FAR *bp;
{	TRect tr;

    tr = bp->view->rr;
    /* erase what's currently there */
/*  TUTORinset_rect((TRect FAR *) &tr,-3,-3); */
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
    TUTORinset_rect((TRect FAR *) &tr,3,3);
    CTset_foreground_color (0);
    TUTORfill_abs_rect ((TRect FAR *) &tr, patternFont0, 8);


    /* 3-D style button. */
    TUTORframe_abs_rect((TRect FAR *) &tr);
    tr.top += 3;
    tr.left += 3;
/*    TUTORdraw_abs_solid_rect((TRect FAR *) &tr, PAT_BLACK);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_BLACK);
/*  TUTORfill_abs_rect ((TRect FAR *) &tr, patternFont0, 16);
    CTset_foreground_color (bp->view->fgndColor.palette);
    tr.top -= 3;
    tr.left -= 3;
    for (ii = 0; ii < 3; ii++) {
        TUTORabs_move_to (tr.left + ii, tr.bottom - ii);
        TUTORabs_line_to (tr.right - ii, tr.bottom - ii);
        TUTORabs_line_to (tr.right - ii, tr.top + ii);
    }


    /* draw "shadow" */
/*  TUTORmove_rect((TRect FAR *) &tr,3,3);
    TUTORfill_abs_rect((TRect FAR *) &tr,patternFont0,8);
    TUTORmove_rect((TRect FAR *) &tr,-3,-3);
    TUTORfill_abs_rect((TRect FAR *) &tr,patternFont0,8);*/
    
    TUTORabs_move_to(tr.left+bp->tx,tr.top+bp->ty);
    TUTORset_textfont(bp->bFont);
    TUTORdraw_text((unsigned char FAR *) bp->title,strlenf((char FAR *) bp->title));
 /* for (ii=0; ii<bp->thick; ii++)
        {
        TUTORframe_abs_rect((TRect FAR *) &tr);
        TUTORinset_rect((TRect FAR *) &tr,-1,-1);
        }
 */
    if (!bp->state)
        { /* grey out button by erasing with grey */
        TUTORabs_erase_rect(&tr, patternFont0, 8);
        }  
    return(0);
}

TUTORdraw_radio_button(bp)
ButtonDat FAR *bp;
{
    int fontindex;
	long fontid;
    TRect tr;

    tr = bp->view->rr;
    /* erase what's currently there */
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
    TUTORinset_rect((TRect FAR *) &tr,3,3);

    TUTORabs_move_to(tr.left + 10, tr.top + (tr.bottom - tr.top) / 2);
    fontid = TUTORinq_symbolic_font_id(ziconsStr);
    fontindex = TUTORget_font2(fontid, 0, 0,102);
    if (bp->value)
        TUTORdraw_graphic_icons(fontindex, "TB", 2);
    else
        TUTORdraw_graphic_icons(fontindex, "T", 2);
/*    TUTORabs_move_to(tr.left + 23,tr.top+bp->ty - 3);
    TUTORset_textfont(bp->bFont);
    TUTORdraw_text((unsigned char FAR *) bp->title,strlenf((char FAR *) bp->title));
*/
	draw_button_text(bp);

    if (!bp->state)
        { /* grey out button by erasing with grey */
        TUTORabs_erase_rect(&tr, patternFont0, 8);
        } 
    return(0);
}

TUTORdraw_checkbox_button(bp)
ButtonDat FAR *bp;
{
    int fset = 2, ascent, descent, w, leading, height;
    TRect tr;
    TRect cbx;

    tr = bp->view->rr;
    /* erase what's currently there */
/*  TUTORinset_rect((TRect FAR *) &tr,-3,-3); */
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
    TUTORinset_rect((TRect FAR *) &tr,3,3);

    /* draw the rectangle frame (just for me) */
    /* TUTORframe_abs_rect((TRect FAR *) &tr);     */

    /* draw the check box */
    TUTORinq_font_info (&ascent, &descent, &w, &leading);
    height = ascent; /* + descent + leading;    */
    cbx.top = (tr.bottom + tr.top) / 2 - height / 2;
    cbx.bottom = (tr.bottom + tr.top) / 2 + height / 2;
    cbx.left = tr.left + height / 4;
    cbx.right = cbx.left + height;

/*  cbx.top = tr.top + fset;
    cbx.bottom = tr.bottom - fset;
    cbx.left = tr.left + fset;
    cbx.right = cbx.left + (cbx.bottom - cbx.top); */
    TUTORframe_abs_rect((TRect FAR *) &cbx);

    if (bp->value) {
        /* draw the X in the box */
        TUTORabs_move_to (cbx.left, cbx.top);
        TUTORabs_line_to (cbx.right, cbx.bottom);
        TUTORabs_move_to (cbx.right, cbx.top);
        TUTORabs_line_to (cbx.left, cbx.bottom);
    }

 /*   TUTORabs_move_to(cbx.right + fset + 3, tr.top+bp->ty - 3);
    TUTORset_textfont(bp->bFont);
    TUTORdraw_text((unsigned char FAR *) bp->title,strlenf((char FAR *) bp->title));
*/
	draw_button_text(bp);
	
    if (!bp->state)
        { /* grey out button by erasing with grey */
        TUTORabs_erase_rect(&tr, patternFont0, 8);
        }  
    return(0);
    }

/* ******************************************************************* */

CThighlight_normal_button(bp)
ButtonDat FAR *bp;

{   TRect tr;

    if (bp->lastDraw == 2)
		return(0); /* nothing to do */
    bp->lastDraw = 2;

    tr = bp->view->rr;
    TUTORset_color(0,&bp->bodyColor);
    TUTORset_color(1,&bp->bColor);

    /* erase what's currently there */
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_BLACK);
/*  TUTORinset_rect((TRect FAR *) &tr,2,2);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_BLACK);
    TUTORinset_rect((TRect FAR *) &tr,-2,-2);	*/

    /* outer frame of button */

    TUTORset_color(0,&bp->fColor);
    TUTORabs_move_to(tr.left,tr.top+1);
    TUTORabs_line_to(tr.left,tr.bottom-1);
    TUTORabs_move_to(tr.left+1,tr.top+1);
    TUTORabs_line_to(tr.left+1,tr.bottom-1);
    TUTORabs_move_to(tr.left+1,tr.top);
    TUTORabs_line_to(tr.right-1,tr.top);
    TUTORabs_move_to(tr.left+1,tr.top+1);
    TUTORabs_line_to(tr.right-1,tr.top+1);
    TUTORabs_move_to(tr.right,tr.top+1);
    TUTORabs_line_to(tr.right,tr.bottom-1);
    TUTORabs_move_to(tr.right-1,tr.top+1);
    TUTORabs_line_to(tr.right-1,tr.bottom-1);
    TUTORabs_move_to(tr.left+1,tr.bottom-1);
    TUTORabs_line_to(tr.right-1,tr.bottom-1);
    TUTORabs_move_to(tr.left+1,tr.bottom);
    TUTORabs_line_to(tr.right-1,tr.bottom);

    /* left, top of 3-d highlight */

    TUTORset_color(0,&bp->fColor);
    TUTORabs_move_to(tr.left+2,tr.top+2);
    TUTORabs_line_to(tr.left+2,tr.bottom-2);
    TUTORabs_move_to(tr.left+3,tr.top+2);
    TUTORabs_line_to(tr.left+3,tr.bottom-3);
    TUTORabs_move_to(tr.left+3,tr.top+2);
    TUTORabs_line_to(tr.right-2,tr.top+2);
    TUTORabs_move_to(tr.left+3,tr.top+3);
    TUTORabs_line_to(tr.right-2,tr.top+3);

    TUTORset_color(0,&bp->fColor);
    bp->ty += 2; /* shift text down */
    bp->tx += 2; /* shift text right */
    draw_button_text(bp);
    bp->ty -= 2;
    bp->tx -= 2;  
    return(0);

} /* CThightlight_normal_button */

/* ******************************************************************* */



CThighlight_checkbox_button(bp)
ButtonDat FAR *bp;
{
  return(0);
}

CThighlight_radio_button(bp)
ButtonDat FAR *bp;
{
  return(0);
}

CThighlight_3D_button(bp)
ButtonDat FAR *bp;
{
 return(0);
}


/* ******************************************************************* */

int get_button_ref(objH) /* get reference count from button */
Memh objH; /* handle on cT object header */

{   struct ebshdr FAR *objP; /* pointer to cT object header */
    Memh bH; /* handle on button info */
    ButtonDat FAR *bp;
    int refcnt;

    if (!objH) return(0);
    objP = (struct ebshdr FAR *)GetPtr(objH);
    bH = objP->objectH; /* handle on button data */
    ReleasePtr(objH);
    if (!bH) return(0);
    bp = (ButtonDat FAR *)GetPtr(bH);
    refcnt = bp->ebsref; /* get reference count (unique id) */
    ReleasePtr(bH);
    return(refcnt);
    
} /* get_button_ref */

/* ******************************************************************* */
