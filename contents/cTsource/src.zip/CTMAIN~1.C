/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Version history

Until May 1987 there were no version numbers.  At that time Dave Andersen
created Version 1.0 involving automatic conversions of existing (non-version)
source files to change "s" to zk(s), associated with the new string markers.

There was no version 1.1.

Version 1.2 (August 1987) made a further change related to generalizing all literal text
to permit embeds:  "font  andy16" was converted to "font  andy,16", and the -menu-
command was converted from "menu  card~n1,item~n2:unit" to the form
"menu  card,n1;item,n2:unit".

Version 1.3 had to do with font rescaling.

In July 1988 we changed to $syntaxlevel 1 for Mac version 1.0.
*/

#include "baseenv.h"
#include <stdio.h>

#ifdef ANDREW
#ifndef sys_typesh
#include <sys/types.h>
#define sys_typesh
#endif
#ifdef SYSV
#include <dirent.h>
#else
#include <sys/dir.h>
#endif
#endif /* andrew */

#include "kglobals.h"
#include "ecglobal.h"
#include "tglobals.h"
#include "tfiledef.h"
#include "compute.h"
#include "commands.h"
#include "prefs.h"

#ifdef ctproto
extern int TUTORfiles_init(void);
int TUTORset_dir(FileRef FAR  *path);
extern char *skip_white(char *sptr);
extern int uplow(char FAR *str);
extern int ParseTF(char *str);
int  NopCommand(void);
int  ctmain1(int  argc,char  * *argv);
int  ctmain2(void);
int  InitCMUT(void);
int  initviews(void);
int  InitPrefs(void);
extern int  ParseColor(char  *cp);
int  myexit(void);
int  versstats(void);
int  TUTORinit_sockets(void);
int  AllocUnits(int  unl);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  initexec0(void);
int  TUTORget_zfont(char  *famS,int  size);
int  TUTORtrace(char  *s);
int  TUTORinit_doc(void);
void  TUTORinit_swap(void);
int  TUTORinit_graf(void);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  StopProgram(char  *s);
int  icompile(void);
int  InitHandles(void);
extern void exit(int status);
int  fork(void);
int  TUTORdone_startup(void);
int  ictcomp(void);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  log_init(struct  _fref FAR *filename);
int  assoc_name(struct  _fref FAR *fn,struct  _fref FAR *bfilen,char  *extnNew);
int  setexectitle(char  *fname);
int  TUTORget_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
int  TUTORstartup(int  argc,char  * *argv,struct  _fref FAR *filenameR);
int  TUTORseed_random(int  value);
long  TUTORinq_msec_clock(void);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  ctconfig(void);
int  TUTORpost_event(struct  tutorevent *event);
char  *parse_env(void);
int  TMessage(char FAR  *s);
int  settitles(char  *filename);
int  initedit(int  wid,unsigned int  eDat1,unsigned int  doc);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
int  readbinary(struct  _fref FAR *fn, int sourceName);
int  insertversion(void);
int  initeditviews(int  eview,struct  _fref FAR *filen,int  *ro);
int  TUTORset_window(int  wid);
int  TUTORset_view(struct  tutorview FAR *vp);
int  initexec(void);
int  initexecw(void);
int  TUTORcreate_window(int  top,int  left,int  xSize,int  ySize,int  type);
int  TUTORset_program_name(char  *pname);
int  TUTORdump(char  *s);
int  initedit0(void);
int  TUTORbad_binary(struct  _fref FAR *filen);
int  setmainfile(struct  _fref FAR *filename);
int  _TUTORinternal_marker(struct  markvar FAR *mp,unsigned int  stackH,long  rloc);
int  initsourcet(int  i);
int  TUTORinq_font_descr(int  fontN,long *fam,int  *siz,int  *fac);
int  TUTORget_font2(long  fam,int  size,unsigned int  face);
int  TUTORround_font_size(int  size);
int  TUTORclose(int  findx);
int  TUTORread_string(unsigned char  *str,int  length,int  findx);
int  SetHiliteColor(int  hc);
long TUTORadd_ffamily(struct  _fref *famName,int  isSys,int  isSwitch);
int  TUTORsymbolic_fileref(struct  _fref FAR *fRef,char  FAR *syms);
long  TUTORinq_symbolic_font_id(char  *fontName);
int  TUTORcopy_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  TUTORcopy_fileref_dir(struct  _fref FAR *dirname,struct  _fref FAR *fullname);
int  TUTORexit(void);
int  log_close(void);
int init_mvar_cache(void);
extern char FAR *strncpyf(char FAR *aa,char FAR *bb,int len);
#ifdef IBMPROTO
int _CDECL sscanf(const char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
extern int lcfinita(void);
#ifndef THINKC5
#ifndef WERKS
extern  int TUTORmodify_menu(unsigned int barh,char *card,char *item,int enableFlag,int checkFlag,int style);
extern int sprintf(char *ss, char *form,...);
extern int sscanf(char *ss, char *form,...);
#endif
#endif
#endif

#ifndef	AUTHOR
#ifndef EXECUTE
#ifndef CTEDIT
what the heck?
#endif
#endif
#endif

NopCommand () {}

extern char *skip_white();
extern long TUTORget_len_doc();
extern char *TUTORgetenv();
extern  int procexecstub();
long TUTORwrite(), TUTORread();
char *strf2n();
extern Memh TUTORnew_doc();
extern char *parse_env();
extern long TUTORinq_msec_clock();

extern char binaryFileCurrent; /* TRUE if current binary matches binary file */

#ifdef ANDREW
extern long getpid();
#endif
extern char *nxtkword();
extern char *machinename();
extern long lowcore();  /* low-memory routines */
extern long lcftoi();   
extern double lcitof();
extern double lcfadd();
extern double lcfsub();
extern double lcfmult();
extern double lcfdiv();
extern double lcfumin();

#ifdef sunV3
extern etext();     /* end of program text */
#endif

struct tempfars {
    char tempFarS[64];
    long tempFarL;
    int tempFari;
    unsigned int tempFarUi;
    TRect tempFarR;
}; 

/* ******************************************************************* */

ctmain1(argc,argv)
int argc;
char **argv; 

{   struct tempfars FAR *tempfp;
    struct tutorfile FAR *tfp;
    FileRef filer;
    int si;
    char filename[FILEL+1];

si = sizeof(int);
si = sizeof(double);
si = sizeof(size_t);
si = sizeof(struct unitinfo);
si = sizeof(FileRef);
si = sizeof(struct defvar);
si = sizeof(struct defset);
si = sizeof(struct sourcefile);
si = sizeof(struct srbimap);
si = sizeof(struct array_desc);
si = sizeof(struct arg_desc);
si = sizeof(struct mark_desc);
si = sizeof(struct txtype_desc);
si = sizeof(struct dim_desc);
si = sizeof(struct argdef);
si = sizeof(struct markvar);
si = sizeof(struct PrefRec);
	
    ctconfig(); /* set ctedit, ctcomp, ctexec */
#ifdef ANDREW
    wm_init_mem();
#endif
#ifdef X11
    wm_init_mem();
#endif
    InitHandles(); 
    init_mvar_cache();
    ctDirP = (FileRef FAR *)TUTORalloc((long)(sizeof(FileRef)),
		  TRUE,"ctdir");
    sourceDirP = (FileRef FAR *)TUTORalloc((long)(sizeof(FileRef)),
		  TRUE,"srdir");
    currentDirP = (FileRef FAR *)TUTORalloc((long)(sizeof(FileRef)),
		  TRUE,"cudir");
    TUTORfiles_init();
    
    tempfp = (struct tempfars FAR *)
	     TUTORalloc((long)sizeof(struct tempfars),TRUE,"tfar");
    if (!tempfp || ! currentDirP) StopProgram(NEARNULL);
    tempFarS = tempfp->tempFarS;
    tempFarL = &(tempfp->tempFarL);
    tempFari = &(tempfp->tempFari);
    tempFarUi = &(tempfp->tempFarUi);
    tempFarR = &(tempfp->tempFarR);
    DictWn = HelpWn = ExecWn = TraceWn = MsgWn = -1; /* no windows yet */
    MsgVp = FARNULL;
    MsgPanelH = MsgDocH = HNULL;
    for(si=0; si<EDITWINDOWLIMIT; si++) {
        EditWn[si] = -1; /* no edit windows/views yet */
        EditVp[si] = FARNULL;
    }
    unitmalloc = 0; /* no unit table yet */
    unittabH = 0;
    unittab = FARNULL;
    unitNames = 0;
    nunits = -1; /* no units yet */
    binaryOnly = FALSE;
    sourcemalloc = 1;
    sourcetable = (struct sourcefile FAR *) 
              TUTORalloc((long)(sourcemalloc*sizeof(struct sourcefile)),TRUE,"srctable");
    if (sourcetable == FARNULL) StopProgram(NEARNULL);

    seedrand = (TUTORinq_msec_clock() & 0xfe)+1;
    TUTORseed_random(seedrand); /* seed random number generator */
    TUTORstartup(argc,argv,(FileRef FAR *) &filer); /* read arguments */
    TUTORcopy_fileref(&sourcetable[0].fRef,(FileRef FAR *) &filer);

	if (strlen(filer.path)) {
    	TUTORcopy_fileref_dir((FileRef FAR *) currentDirP,(FileRef FAR *)&sourcetable[0].fRef);
    	TUTORset_dir(currentDirP);
    }

 /*   if (strlen(filer.path) == 0)
	StopProgram("You must specify a file name."); */

    TUTORget_fileref_name(&sourcetable[0].fRef,(char FAR *) filename);
    setexectitle(filename);
    InitCMUT();
 
    if (logevents || playevents) { /* set up event log or replay */
        assoc_name(&sourcetable[0].fRef,(FileRef FAR *) &filer,".log");
        if (logevents) log_init(&filer);
        if (playevents) {
        evplayfi = TUTORopen((FileRef FAR *) &filer,TRUE,FALSE,FALSE);
        } /* playevents if */
    } /* logevents if */
 
} /* end of ctmain1 */

/* ******************************************************************* */

ctmain2() /* finish initializations */
    
{
    if (ctcomp)
        ictcomp(); /* initializations for compiler (including cmpBuf alloc) */
    TUTORdone_startup();

} /* ctmain2 */

/* ******************************************************************* */

InitCMUT()  /* global and primary initializations */
    
{   struct markvar tempM;
    unsigned char *cp;

    /* general initializations */
 
    if (lforkf) if (fork ())
        exit (0); 
 
    icompile(); /* initializations for expression analyzer */


    /* defines, array/argument descriptors */

    descH = TUTORhandle("descrip",0L,TRUE);
    descP = NULL;
    oldSetH = globalSetH = userSetH = firstSetH = lastSetH = HNULL;
    wkSetH = localSetH = HNULL;
    wkSetP = FARNULL;
    oldDescH = HNULL;
    TUTORinit_graf();
    InitPrefs();

    TUTORinit_swap();

#ifdef DOSPC
    mem_msg(); /* display memory/swap statistics */
#endif

    TUTORinit_sockets();
    TUTORinit_doc();

    pcodeh = 0; /* no unit binary yet */

    /* set up floating infinite/indefinite */
    /* (computed at run time to suit Mac compiler) */
  
    Indefinite = Infinite = 0.0;
#ifdef vax
    Infinite = 1.7976931348623158e308;
    Indefinite = Infinite;
#else
#ifdef IBMPC
    _clear87();
    if (sizeof(double) == 8) {
		cp = (unsigned char *)&Infinite;
		*(cp+6) = 0xf0;
		*(cp+7) = 0x7f;
		cp = (unsigned char *)&Indefinite;
		*(cp+6) = 0xf8;
		*(cp+7) = 0xff;
    } else { /* this doesn't work on Compaq ? */
	     /* get underflow error under Windows despite */
	     /* _control87() settings */
		Infinite = 1.0/Infinite;
		Indefinite = 0.0/Indefinite;
    }
    _clear87();
#else
#ifdef MAC
if (macCoPr && (sizeof(double) == 12)) { /* computation gets exception on Mac Powerbook 165c */
	cp = (unsigned char *)&Infinite;
	*cp = 0x7f;
	*(cp+1) = 0xff;
	*(cp+2) = 0x7f;
	*(cp+3) = 0xff;
	cp = (unsigned char *)&Indefinite;
	*cp = 0x7f;
	*(cp+1) = 0xff;
	*(cp+2) = 0x7f;
	*(cp+3) = 0xff;
	*(cp+4) = 0x40;
	*(cp+5) = 0x04;
} else if (macCoPr && (sizeof(double) == 8)) { /* computation gets exception on Mac Powerbook 165c */
	cp = (unsigned char *)&Infinite;
	*cp = 0x7f;
	*(cp+1) = 0xf0;
	cp = (unsigned char *)&Indefinite;
	*cp = 0x7f;
	*(cp+1) = 0xf0;
} else {
    Infinite = 1.0/Infinite; 
    Indefinite = 0.0/Indefinite;
}
#else
    Infinite = 1.0/Infinite; 
    Indefinite = 0.0/Indefinite;
#endif
#endif
#endif

#ifdef X11

    CTinit_default_palette();

#endif

if ((!ctedit) && (!ctcomp) && ctexec) {

    /* executor-only initializations */

    source = HNULL;
    cmpbuf = FARNULL;
    nosourcelayout = TRUE;
} else {

    /* compiler or editor initializations */

    versstats();    /* keep cmututor version statistics */
    source = TUTORnew_doc(TRUE,TRUE);
} /* config else */

csourcen = 0;       /* initialize index of source file */
allcompiled = FALSE; /* program not all compiled yet */
binaryFileCurrent = FALSE;

/* some global graphics initializations */
    iconFont0 = textFont0;
    cursorFont0 = TUTORget_zfont("zcursors",-1); /* default cursor font */
    cursorChar0 = 'a'; /* default cursor character */
    patternFont0 = TUTORget_zfont("zpatterns",-1); /* default fill pattern font */
    patternChar0 = 16; /* default fill character - black */
    
initexec0(); /* all-executor variables */

/* initialize text pool for string literals */

textpool = TUTORnew_doc(TRUE,FALSE); /* text/string literals */

/* initialize variables set by $ commands */

ctutv = CURRENTV;   /* default cmututor version */

binaryFile.path[0] = '\0'; /* no valid binary file yet */
AllocUnits(1); /* insure unit table present */
nunits = -1; /* force setup */
usesColor = 0; /* not known to be color program yet */

initsourcet(0);

if (!unittab || !sourcetable)
        StopProgram(NEARNULL);

compunit = 0;   /* not compiling, set to safe value */
initviews(); /* initialize window(s), view(s), source/binary files */

if (source) {
    tempM.doc = source;
    tempM.pos = 0L;
    tempM.len = TUTORget_len_doc(source);
    tempM.alteredF = 0x10; /* sticky */
    mkall = _TUTORinternal_marker((struct markvar SHUGE *) &tempM,HNULL,0L);
} else
    mkall = -1;

waitflag = rerunflag = runflag = halt;

if (!ctedit) {
    if (newsrfile && nosourcelayout) {
	TUTORtrace("empty file");
        myexit();
    } /* empty file if */
} 

if (ctedit) {
    sourcetable[0].ctutv = CURRENTV; /* pre-set version */
    if (EditWn[0] >= 0) {
        TUTORset_view(EditVp[0]);  /* set for editor view */
        sourcetable[0].editI = 0; /* set editor index */
    } /* editor if */
} /* else-if */

#ifdef sunV3
    if (spyf) monstartup(0x8000,etext);
#endif

} /* InitCMUT */

/*********************************************************/

initviews() /* initialize executor window */

{   FileRef filen; /* source/binary file name */
    int i, ro;  /* work variables */
    char *pmsg; /* parse_env message */
    struct tutorevent cvtev; /* source conversion event */
    char filename[FILEL+1];

if ((!ctedit) && (ctexec)) { /* executor only */
    TUTORcopy_fileref((FileRef FAR *) &filen,&sourcetable[0].fRef);
    initeditviews(0,(FileRef FAR *) &filen,&ro);
    codegen = FALSE; /* no compiled code */
    EditVp[0] = DictVp = FARNULL;
    
    /* set up author directory and file names */

    setmainfile((FileRef FAR *) &filen); /* set main file name */
    TUTORget_fileref_name((FileRef FAR *) &filen, filename);

    /* read binary file */

   if (fileSpecified) {
        binaryOnly = TRUE;
    	if (!readbinary((FileRef FAR *) &filen,FALSE)) {
        	if (!ctcomp) TUTORbad_binary((FileRef FAR *) &filen);
    	} /* readbinary if */
    }
    
    /* initialize executor window */
    
    initexecw();
    initexec();
    
    settitles(filename);
    
} else { /* editor or authoring environment (including -x) */
    DictVp = FARNULL; /* no dict view till called for */

    /* editor window initializations */

    TUTORset_view(FARNULL); /* no view at present */
    initedit0();

    if (nosourcelayout) {
        if (!ctexec)
            TUTORdump("No source for editor?");
        EditVp[0] = FARNULL;
    } else {
        EditWn[0] = TUTORcreate_window(-1,-1,0,0,EDITW);
        TUTORset_program_name("ctedit");
    } /* nosourcelayout else */

    /* initialize trace window */
    if (twf)
        TraceWn = TUTORcreate_window(-1,-1,0,0,TRACEW);

    /* set up author directory and file names */

    if (EditWn[0] >= 0) {
        TUTORset_view(FARNULL); /* no view at the moment */
        TUTORset_window(EditWn[0]);
    }
    i = initeditviews(1,(FileRef FAR *) &filen,&ro);
    newsrfile = FALSE; /* pre-set not new file */
    if ((i == FALSE) || (TUTORget_len_doc(source) <= 0)) {
        InsertString(source,0L,(char FAR *) NEWLINES,1L);
        newsrfile = TRUE;
    }
    if (fileSpecified && newsrfile && (EditWn[0] < 0))
        binaryOnly = TRUE; /* executor with binary file only */

    /* insure $syntaxlevel statement present */

    if (newsrfile) {
        insertversion();
    } /* newsrfile */

    /* read binary file if possible */

    if (fileSpecified) {
        if (!readbinary((FileRef FAR *) &filen,TRUE)) {
            nunits = -1; /* force setup */
        } /* readbinary if */
    } /* newsrfile if */

    /* insure newline at end of file */

    if (TUTORcharat_doc(source,(TUTORget_len_doc(source)-1)) != NEWLINE) 
        InsertString(source,TUTORget_len_doc(source),(char FAR *) NEWLINES,(long) 1);       

    /* editor+dictionary initializations */

    if (EditWn[0] >= 0)
        initedit(EditWn[0],ed1H,source);
    
    TUTORget_fileref_name(&sourcetable[0].fRef,filename);
    settitles(filename);

    if ((EditWn[0] >= 0) && ro)
        TMessage((char FAR *)"Read only program; use Save As ... to modify.");

    /* check if source conversion required */

    pmsg = parse_env();
    if ((pmsg == NULL) && (ctutv != CURRENTV) && (EditWn[0] >= 0)) { 
        cvtev.window = EditWn[0];
        cvtev.view = FARNULL; /* message sent to window */
        cvtev.type = EVENT_TIME;
        cvtev.value = time_convert;
        cvtev.timestamp = 1000L;
        cvtev.eDataP = FARNULL;
        TUTORpost_event(&cvtev);
    }

    /* initialize executor window */

    if (ctexec) {
        initexecw();
        initexec();
    }

} /* config else */

} /* initviews */

/* ******************************************************************* */

myexit() /* final exit processing */

{
    log_close(); /* finish up event log */
    TUTORexit();

} /* myexit */

/* ******************************************************************* */

#ifdef ANDREW

extern char *TUTORgetenv();

versstats()     /* keep cmututor version statistics */

{   char *penv; /* pointer to BVERS environment var string */
    char *pmstr;    /* pointer to machine name string */
    char *pvstr;    /* pointer to version name string */
    char *dirn;  /* directory name string */
    char filen[64]; /* file name string */

    /* determine machine type */

    pmstr = machinename();

    /* determine version */

    penv = TUTORgetenv("CMU_VERSION");
    if (penv == NULL) {
        pvstr = "unrec.";
    } else {
        switch (*penv) {
        case '0':
            pvstr = "prod.edu.";
            break;
        case '1':
            pvstr = "prod.pub.";
            break;
        case '2':
            pvstr = "expr.";
            break;

        case '3':
            return; /* no stats - remote sites */

        default:
            pvstr = "unrec.";
            break;
        } /* switch */
    } /* else */

    /* build file and directory names */
    
    strcpy(filen,pvstr);
    strcat(filen,pmstr);    /* append machine name */
    dirn = TUTORgetenv("CMU_STATS");

    if (penv && dirn)
        IncrementLogCount(dirn,filen);  /* increment count */

} /* versstats */

/* ******************************************************************* */

IncrementLogCount(dir, inkey)   /* increment statistics count */
                            /* return < 0  = error */
                            /* return >=0 = count */

/* maintains statistics counters by incorporating the count in the specified */
/* file name/directory - this is fast on vice */
/* routine originally supplied by Nathaniel Borenstein */

char *dir;      /* pointer to directory name string */
char *inkey;    /* pointer to file name string */

{   FILE *fp;
    DIR *dp;
    struct direct *dirent;
    int keylen, counter;
    char Name[256], From[256], To[256], key[256];
    FileRef fromRef, toRef;

    strcpy(key, inkey);
    strcat(key, ".");
    keylen = strlen(key);
    if ((dp = opendir(dir)) == NULL) {
        return(-1);
    } else {
        while (((dirent = readdir(dp)) != NULL) && strncmp(dirent->d_name, key, keylen)) {
            continue;
        } /* while */
        if (dirent == NULL) {
            sprintf(Name, "%s/%s1", dir, key);
            if ((fp=fopen(Name,"w")) == NULL) {
                return(-2);
            } else {
                fputc(' ', fp);
                fclose(fp);
            } /* fopen else */
        } else {
            strcpy(Name, dirent->d_name);
            counter = atoi(&Name[keylen]);
            counter++;
            sprintf(From, "%s/%s", dir, dirent->d_name);
            sprintf(To, "%s/%s%d", dir, key, counter);
            fromRef.nameInd = 0;
            fromRef.path[0] = '\0';
            TUTORcopy_fileref_name((FileRef FAR *) &fromRef, (char FAR *) From);
            toRef.nameInd = 0;
            toRef.path[0] = '\0';
            TUTORcopy_fileref_name((FileRef FAR *) &toRef, (char FAR *) To);
            if (!TUTORrename_file(&fromRef,&toRef)) return(-3);
        } /* dirent else */
    } /* opendir else */
    return(counter);

} /* IncrementLogCount */
#else
versstats(){ return 0;}
#endif /* ANDREW */

#ifdef DOSPC
/* this routine is here to fix overlay problems.  It really ought to be in sockpc */
TUTORinit_sockets()
    {;}
#endif
