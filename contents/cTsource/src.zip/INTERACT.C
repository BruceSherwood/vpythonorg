
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "baseenv.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "editmenu.h"
#include "editor.h"
#include "kglobals.h"
#include "tfiledef.h"
#ifndef CTEDIT
#include "eglobals.h"
#endif

#ifdef ctproto
extern int strncmpf(char FAR *aa,char FAR *bb,int nn);
extern int TUTORlog(char *s);
int  TUTORtrace(char  *s);
int  Halt(void);
extern int DefDel(void);
int  TUTORdealloc(char  FAR *ptr);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  interact(int  block);
extern int  nextevent(int  ind);
int  TUTORevent_side_effects(struct  tutorevent FAR *cevp);
extern int  process_mouse_event(struct  tutorevent FAR *cev);
struct  tutorview FAR *findview(int  ww,int  xx,int  yy);
int  log_init(struct  _fref FAR *filename);
int  log_close(void);
int  log_event(struct  tutorevent *ev);
extern int  log_write(char  *str);
int  log_flush(void);
int  TUTORfree_event_memory(struct  tutorevent FAR *event);
int  TUTORmouse_on(void);
int  TUTORpoll_events(int  block);
int  preexec(void);
int  FullHalt(void);
int  TUTORinq_wmg_busy(int  window);
int  TUTORsystem_tasks(void);
int  TUTORunlock_code(void);
int  TUTORflush(void);
int  wmg_arrange(int  focus);
int  wmg_wipe(void);
int  wmg_on(void);
int  TUTORset_view(struct  tutorview FAR *vp);
int  TUTORresize_window(int  wid,int  newX,int  newY);
int  TUTORdump(char  *s);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
int  TUTORclose(int  findx);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
long  TUTORwrite(char  FAR *ptr,int  pSize,long  count,int  findx);
char  FAR *GetPtr(unsigned int  mm);
long  TUTORinq_msec_clock(void);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
int  MenuNames(unsigned int  mbar,int  item,char  *cardName,char  *itemName);
int  strcmpf(char  FAR *aa,char  FAR *bb);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
extern int WindowFocus(long theW);
/* extern int sprintf(char *ss, char *form, ...); */
#endif

extern long TUTORget_len_doc();
extern long TUTORinq_msec_clock();
extern struct tutorview FAR *findview();


#ifndef MAC
extern int wmg_obscured[WINDOWLIMIT];
extern int pd_menualt[WINDOWLIMIT]; /* menus altered table */
#endif

unsigned char interactDepth=0; /* # of times interact is called recursively */


/* ******************************************************************* */

interact(block) /* interaction processor */
int block;

{   int np;     /* number events to process */
    int i, j;   /* work variables */
    register struct tutorevent FAR *cevp; /* pointer to event we want to process */
    struct tutorview FAR *eventV;   /* view of the event */
    int nskipped;   /* # of events we have skipped */

    interactDepth++;
    if (interactDepth == 1) /* only do system work on topmost call */
        TUTORsystem_tasks(); /* let code float, check i/o, etc. */

    /* check for incoming events */

    do {
        i = nevents;
		TUTORpoll_events(FALSE);  /* queue up incoming events */
    } while (i != nevents); /* queue up all pending events */

    if ((nevents == 0) && (interactDepth == 1)) 
        DefDel(); /* purge objects */
        
    if (!TUTORinq_wmg_busy(-1)) {
        np = 16; /* process at most 16 events */
        nskipped = 0;
        while (np-- && nevents > nskipped) {
            cevp = eventque+nskipped;
            if (waitflag != atinterrupt || cevp->window != ExecWn)
                nextevent(nskipped); /* normal case, process next event */
#ifndef CTEDIT
            else
            { /* interrupt state in executor window.  We process all events that
                are not in the executor base view.  Only REDRAW, MENU and their
                associated events (ENDLAY & BEGINLAY) in base view.  The base
                view includes the current arrow view, if any */

                /* we have to figure out the view of the event */
                switch (cevp->type)
                {
                    case EVENT_LEFTDOWN:
                    case EVENT_RIGHTDOWN:
                    case EVENT_UPMOVE:
                        eventV = cevp->pressed ? cevp->view : findview(ExecWn,cevp->x,cevp->y);
                        break;
                    case EVENT_LEFTUP:
                    case EVENT_RIGHTUP:
                    case EVENT_DOWNMOVE:
                        eventV = cevp->pressed ? cevp->view : windowsP[ExecWn].MouseFocus;
                        break;
                    case EVENT_KEY:
                    case EVENT_FKEY:
                    case EVENT_PASTE:
                        eventV = cevp->pressed ? cevp->view : windowsP[ExecWn].KeyFocus;
                        break;
                    case EVENT_MENU:
                    case EVENT_MSG:
                        eventV = windowsP[ExecWn].MenuFocus;
                        break;
                    default:
                        eventV = cevp->view;
                        break;
                }
                
                if (eventV != exS.baseView && eventV != exS.arr.aView) /* not in executor view */
                    nextevent(nskipped); /* process non-executor view events */
                else if (cevp->type == EVENT_REDRAW || cevp->type == EVENT_FWD ||
                        cevp->type == EVENT_MENU || cevp->type == EVENT_BEGINLAY ||
                        cevp->type == EVENT_SIGNAL || cevp->type == EVENT_HOT ||
                        cevp->type == EVENT_ENDLAY)
                    nextevent(nskipped); /* process interrupt events for executor */
                else
                {
                    nskipped++; /* skip this event */
                    np++; /* we didn't process this event, so fix up "# of events processed" count */
                }
            } /* interrupt else */
#endif /* CTEDIT */
                
        } /* end of ile np-- && nevents */
    
    } /* menu state if */

    log_flush(); /* flush event log if neccessary */

    /* start executor if we were just getting a key and didn't find anything */

    if ((waitflag == atgetkey || waitflag == atinterrupt) && 
		!TUTORinq_wmg_busy(-1) && (modalW == -1)) {
#ifdef DOSPC
        if (wmg_obscured[ExecWn])
            FullHalt();
        else
#endif
            preexec();
    }
    else if (!nevents) {
        TUTORmouse_on(); /* re-enable mouse if disabled */
        TUTORpoll_events((waitflag != atinterrupt && waitflag != atgetkey) ? block : FALSE);
    }
    TUTORmouse_on(); /* re-enable mouse cursor if disabled */

    interactDepth--;
    return(0);

} /* interact */

/* ******************************************************************* */

static nextevent(ind)   /* process next event from event queue */
int ind;
{   struct tutorevent cev;  /* current event */
    struct tutorevent rev;  /* redraw event */
    int wclr;   /* cleared window flag */
    int i;  /* work variables */
    struct tutorview FAR *vp;
    int newInd;     /* index of event to replace event we were passed (for move & redraw) */
    char FAR *memP; /* pointer to dummy memory block allocated for print */
 
    if (ind >= nevents)
        return(FALSE); /* nothing to process */
 
    /* process event ind */
    cev = eventque[ind];

    if (cev.type != -1)
    { /* normal event */
        if (cev.window < 0)
        { /* no window specified */
            if (cev.type != EVENT_SIGNAL)
            {
                TUTORfree_event_memory((struct tutorevent FAR *) &cev);
                cev.type = -1; /* kill event */
            }
            /* EVENT_SIGNALs aren't neccesarily going to windows... */
        }
        else if (!windowsP[cev.window].eventMask[cev.type]) 
        {
            TUTORfree_event_memory((struct tutorevent FAR *) &cev);
            cev.type = -1; /* kill event if mask not set */
        }
    }
    
    /* suppress duplicate redraw and mouse move events */
    /* combine key events */

    if (cev.type == EVENT_DOWNMOVE || cev.type == EVENT_KEY ||
            cev.type == EVENT_REDRAW || cev.type == EVENT_UPMOVE || cev.type == -1)
    {
    /* suppress duplicate redraw and mouse move events */
    /* combine key events */
    /* scan thru deleted events (cev.type == -1) so we can throw them all out at once */
        newInd = ind+1; /* possible index of new event */
        while (newInd < nevents && eventque[newInd].type == cev.type &&
                eventque[newInd].window == cev.window) {
            if (cev.type == EVENT_KEY) { /* EVENT_KEY needs to be combined */
                if ((cev.nkeys+eventque[newInd].nkeys) <= 16 && cev.view == eventque[newInd].view) {
                    for (i=0; i<eventque[newInd].nkeys; i++)
                        cev.keys[cev.nkeys++] = eventque[newInd].keys[i];
                } else
                    break; /* can't collect any more keys to this event */
            } /* all others just replace cev with event at newInd */
            newInd++;
        }  /* ile */
        /* newInd now refers to event AFTER the last one we used */
        
        if (newInd != ind+1 && cev.type != EVENT_KEY && cev.type != -1)
            { /* copy event we really want into cev */
            cev = eventque[newInd-1];
            }
    }
    else
        newInd = ind+1; /* no combining.  Just make bookkeeping come out right for cleanup of eventque */

    /* clean up event queue to account for used events */
    /* we want to delete the events ind thru newInd */
    if (newInd < nevents)
        { /* there are events following the events we're deleting, shift them */
        TUTORblock_move((char SHUGE *) (eventque+newInd),
                (char SHUGE *) (eventque+ind), (long) sizeof(struct tutorevent)*(nevents-newInd));
        }
    nevents -= (newInd - ind);
    
    if (cev.type == -1)
        return(FALSE); /* all done with deleted event */
    
    /* write event to file if logging events */

    if (evlogfi && !cev.pressed)
        log_event(&cev);

   /* take care of side effects & some processing of events */
    TUTORevent_side_effects((struct tutorevent FAR *) &cev);
    
    /* handle some event types here */
    switch(cev.type) {

    case 0:
        TUTORdump("event type = zero");

    case EVENT_RESIZE:
        TUTORresize_window(cev.window,cev.x,cev.y);
        cev.type = -1; /* we've done the work here */
        break;
    
    case EVENT_PROC:    /* process execute-routine event */
        /* this kind of event is executed directly (not sent to window) */
        TUTORset_view(cev.view);
        (*cev.vproc)(); /* execute specifed routine */
        cev.type = -1; /* no more processing */
        break;

    case EVENT_SIGNAL: /* process signal event */
        /* this kind of event is sent directly to recipient */
        (*cev.vproc)((Memh) cev.a5,&cev); /* execute routine with proper data */
        /* note that there was no TUTORset_view */
        cev.type = -1; /* no more processing */
        break;

#ifdef DOSPC
    case EVENT_BEGINLAY:    /* begin window re-layout */
        if ((cev.window != ExecWn) && (runflag != halt)) {
            TUTORset_view(ExecVp); /* set to executor view */
            FullHalt(); /* stop execution */
        } /* runflag if */
        for(i=0; i<WINDOWLIMIT; i++)
            if (windowsP[i].wp) {
                pd_menualt[i] = TRUE;
                wmg_obscured[i] = FALSE; /* un-obscure to allow redraw */
            } /* wp if */
        wmg_on(); /* enable output */
        wmg_wipe();
        cev.type = -1; /* no more processing */
        break;
        
    case EVENT_ENDLAY:  /* windows re-arranged */
        wmg_arrange(cev.window);
        cev.type = -1; /* no more processing */
        break;
#endif

    /* Mac special events for playback */
#ifdef MAC
    case EVENT_WFOCUS:
        WindowFocus(windowsP[cev.window].wp);
        cev.type = -1;
        break;
        
    case EVENT_SCROLL:
        if (cev.view) {
            TUTORset_view(cev.view);
            (*(cev.view->vproc)) (cev.view->vh,&cev);
        }
        cev.type = -1;
        break;
#endif

    case EVENT_PRINT:
        TUTORsystem_tasks(); /* let code float, check i/o, etc. */
        /* force memory manager to clean up */
        memP = TUTORalloc(64L*1024L,FALSE,"print");
        TUTORdealloc(memP);
        break;
        
    case EVENT_KEY:
    case EVENT_FKEY:
        cev.type = cev.type;
        break;

    } /* switch */

    /* send events that are still valid to the window */
    if (cev.type > 0) {
        (*(windowsP[cev.window].wproc)) (windowsP[cev.window].wH,&cev);
    }
    TUTORflush();   
    if (cev.type == EVENT_HOT || cev.type == EVENT_PASTE)
        TUTORfree_event_memory((struct tutorevent FAR *) &cev);

    return(TRUE);

} /* nextevent */

/* ******************************************************************* */

TUTORevent_side_effects(cevp)
struct tutorevent FAR *cevp;
    {
    /* special handling for some event types (set view, etc.) */
    
    switch(cevp->type) {

    case EVENT_REDRAW:
        windowsP[cevp->window].wxsize = cevp->x;
        windowsP[cevp->window].wysize = cevp->y;
        if ((cevp->x == 0) && (cevp->y == 0))
            cevp->type = -1; /* suppress redraws to closed windows */
        break;
        
    case EVENT_MSG: /* internally generated (so doesn't get logged) menu event */
    case EVENT_MENU:    /* process menu event */
        if (modalW != -1 && modalW != cevp->window) {
            /* menu for wrong window when we are in a modal state */
            cevp->type = -1; /* cancel event */
            break;
        }
        cevp->view = windowsP[cevp->window].MenuFocus;
        if (cevp->type == EVENT_MSG && cevp->window == ExecWn && cevp->a1 == edit_toexec)
            TUTORunlock_code(); /* unlock code, we are done with editor/compiler */
        break;

    case EVENT_LEFTDOWN:
    case EVENT_LEFTUP:
    case EVENT_RIGHTDOWN:
    case EVENT_RIGHTUP:
    case EVENT_DOWNMOVE:
    case EVENT_UPMOVE:
        if (!process_mouse_event(cevp))
            cevp->type = -1; /* event isn't wanted, cancel it */
        break;
    
    case EVENT_KEY:
    case EVENT_FKEY:
    case EVENT_PASTE:
        if (modalW != -1 && modalW != cevp->window) {
            /* key for wrong window when we are in a modal state */
            cevp->type = -1; /* cancel event */
            break;
        }
        if (!cevp->pressed)
            cevp->view = windowsP[cevp->window].KeyFocus;
        break;
 
    } /* switch */

} /* TUTORevent_side_effects */

static process_mouse_event(cev)
struct tutorevent FAR *cev;
/* returns TRUE if event should be used */
{
    struct tutorview FAR *vp;
    
    if (cev->type == EVENT_LEFTDOWN || cev->type == EVENT_RIGHTDOWN || cev->type == EVENT_UPMOVE) {
        /* find view for event */
        if (!cev->pressed)
            vp = findview(cev->window,cev->x,cev->y);
        else
            vp = cev->view; /* pressed events already have view set */
        if (modalW != -1 && (!vp || !vp->dialogV))
            return(FALSE); /* click in non-dialog view when dialog is active */
    }
    
    windowsP[cev->window].mousex = cev->x;
    windowsP[cev->window].mousey = cev->y;
    
    if (cev->type != EVENT_DOWNMOVE){
        if (cev->type == EVENT_LEFTDOWN || cev->type == EVENT_RIGHTDOWN || cev->type == EVENT_UPMOVE) {
            /* note: vp calculated above */
            if (vp && !vp->canclick)
                { /* this view doesn't want mouse clicks */
                return(FALSE); /* cancel event */
                }
            windowsP[cev->window].MouseFocus = vp;
            if (vp && vp->caninput)
                TUTORset_key_focus(cev->window,vp,TRUE);
            if (cev->type == EVENT_LEFTDOWN) {
        /*    	windowsP[cev->window].ldowntime2 = windowsP[cev->window].ldowntime1;
                windowsP[cev->window].ldowntime1 = cev->timestamp; */
            } else {
         /*       windowsP[cev->window].rdowntime2 = windowsP[cev->window].rdowntime1;
                windowsP[cev->window].rdowntime1 = cev->timestamp; */
            }
        } /* end of down events */
        else { /* for up events */
            windowsP[cev->window].upx = cev->x;
            windowsP[cev->window].upy = cev->y;
            if (cev->type == EVENT_LEFTUP)
                windowsP[cev->window].luptime = cev->timestamp;
            else
                windowsP[cev->window].ruptime = cev->timestamp;
        } /* end of up events */
    } /* end of non-move clicks */
    
    cev->view = windowsP[cev->window].MouseFocus;
#ifndef CTEDIT
    if ((cev->window == ExecWn) && !cev->view) /* executor reverts to base view */
    cev->view = windowsP[cev->window].MouseFocus = exS.baseView;
#endif
    if (!cev->view) {
        return(FALSE);
    }

    return(TRUE); /* this is a valid mouse event */
}

/* ******************************************************************* */

struct tutorview FAR *findview(ww,xx,yy) /* find view enclosing point */
int ww; /* index of window */
int xx; /* x co-ordinate */
int yy; /* y co-ordinate */

{   int i;  /* index in view table */
    register struct tutorview FAR *vp;
    struct tutorview FAR *bestv;
    long bestdim,dim,prior,bestprior;

    vp = windowsP[ww].firstView;
    bestdim = 0x3fffffffL; /* size of enclosing view */
    bestv = FARNULL;
    bestprior = 0;
    while (vp) {
        if (xx >= vp->rr.left && xx <= vp->rr.right && 
                    yy >= vp->rr.top && yy <= vp->rr.bottom) {
            /* if any intersecting view has priority set, search by priority */
            if (bestprior || vp->priority) {
            	if (!vp->inhibitF && (vp->priority > bestprior)) {
            		bestprior = vp->priority;
            		bestv = vp;
            	}
            } else { /* else search by area */
            	dim = vp->rr.bottom-vp->rr.top;
            	dim = dim*(vp->rr.right-vp->rr.left);
            	if (!vp->inhibitF && (dim < bestdim)) { /* pick smallest enclosing view */
                	bestdim = dim;
                	bestv = vp;
            	} /* bestdim if */
            } /* priority else */
        } /* xx if */
        vp = vp->nextView;
    } /* ile */
    return(bestv);  /* smallest enclosing view (or NULL) */

} /* findview */

/* ******************************************************************* */

static Memh evlogh; /* handle on event log buffer */
static int evlogl; /* amount of data currently in log buffer */

int log_init(filename) /* initialize event log */
struct _fref FAR *filename; /* log file name */

{   long starttim; /* time log started */
    char startmsg[20];

    if (evlogfi) return(TRUE); /* log file already opened */

    /* allocate buffer for event log */

    evlogh = TUTORhandle("eventl",(long)1000,TRUE);
    if (!evlogh) return(FALSE);
    evlogl = 0; /* no data yet */

    /* open event log file */

    evlogfi = TUTORopen(filename,FALSE,TRUE,FALSE);
    if (evlogfi == 0) return(FALSE);

    /* write out log start time and random number seed */

    starttim = TUTORinq_msec_clock();
    sprintf(startmsg,"%ld %d",starttim,seedrand);
    strcat(startmsg,NEWLINES);
    log_write(startmsg);

    return(TRUE);
    
} /* log_init */

/* ******************************************************************* */

log_close() /* close log file */

{   char FAR *logp; /* pointer to log buffer */

    if (evlogfi == 0)
        return(0);
    logp = GetPtr(evlogh);
    if (evlogl) { /* flush any data in buffer */
        TUTORwrite(logp,1,(long)evlogl,evlogfi);
        evlogl = 0;
    } /* evlogl if */
    ReleasePtr(evlogh);
    KillPtr(logp);
    TUTORclose(evlogfi); /* close log file */
    evlogfi = 0;

    return(0);
} /* log_write */
    
/* ******************************************************************* */

log_event(ev) /* write event to log file */
struct tutorevent *ev; /* pointer to event */

{   char wstr[100]; /* work string for log entry */
    char logmsg[160]; /* log entry building */
    char *wlabel; /* window name */
    int ml; /* length of entry building */
    int wix; /* index of window */
    double xs,ys; /* size of window */
    int ii, wType;
    struct tutorview FAR *viewp;

    if (evlogfi == 0)
        return(0); /* not logging events */

    wix = ev->window;
    if (wix >= 0)
        {
        wType = windowsP[wix].type;
        if (wType == EDITW) wlabel = "edit";
        else if (wType == EXECW) wlabel = "exec";
        else if (wType == DICTW) wlabel = "cmds";
        else if (wType == HELPW) wlabel = "help";
        else if (wType == SEARCHW) wlabel = "search";
        else wlabel = "xxxx";
        }
    else
        wlabel = "xxxx";
    
    sprintf(wstr,"%ld",ev->timestamp);  /* get time of event */
    ml = strlen(wstr);
    if (ml < 8) { /* fill time out to eight digits */
        TUTORblock_move((char SHUGE *)wstr,(char SHUGE *)(wstr+(8-ml)),
                (long)(ml+1));
        for(ii=0; ii<(8-ml); ii++)
        wstr[ii] = '0';  /* insert leading zeros */
    }
    strcpy(logmsg,wstr); /* build log entry header */
    strcat(logmsg," ");
    strcat(logmsg,wlabel);
    strcat(logmsg," ");
    if (wix >= 0) {
        xs = windowsP[wix].wxsize;
        ys = windowsP[wix].wysize;
    } else { /* to non-ct windows */
        xs = 1;
        ys = 1;
    }
    wstr[0] = '\0'; /* no log entry yet */

    switch (ev->type) {

    case EVENT_RIGHTDOWN:   /* process mouse right-button down event */
        sprintf(wstr,"rdwn %G %G",ev->x/xs,ev->y/ys);
        break;

    case EVENT_LEFTDOWN:    /* process mouse left-button down event */
        sprintf(wstr,"ldwn %G %G",ev->x/xs,ev->y/ys);
        break;

    case EVENT_RIGHTUP: /* process mouse right-button up event */
        sprintf(wstr,"rup  %G %G",ev->x/xs,ev->y/ys);
        break;

    case EVENT_LEFTUP:  /* process mouse left-button up event */
        sprintf(wstr,"lup  %G %G",ev->x/xs,ev->y/ys);
        break;

    case EVENT_DOWNMOVE:
        sprintf(wstr,"move %G %G",ev->x/xs,ev->y/ys);
        break;

    case EVENT_WFOCUS:
        sprintf(wstr,"wfocus");
        break;

    case EVENT_WMKILL:
        sprintf(wstr,"wmkill");
        break;

    case EVENT_SCROLL:
        /* set ii to the "index" of the view */
        viewp = windowsP[wix].firstView;
        ii = 0;
        while (viewp && viewp != ev->view) {
            ii++;
            viewp = viewp->nextView;
        }
        sprintf(wstr,"scroll %g %d",ev->a3,ii);
        break;

    case EVENT_PASTE:   /* process paste event */   
        break;

    case EVENT_FKEY:
        sprintf(wstr,"fkey %d",ev->value);
        break;

    case EVENT_KEY:     /* process keyboard event */
        ml = strlen(logmsg); /* get length of header */
        for (ii=0; ii<ev->nkeys; ii++) {
            if (ev->keys[ii] > 32 && ev->keys[ii] < 127)
            sprintf(wstr,"key %d %c",ev->keys[ii],ev->keys[ii]);
            else
            sprintf(wstr,"key  %d",ev->keys[ii]);
            strcat(logmsg,wstr); /* append event-specific info */
            strcat(logmsg,NEWLINES);
            log_write(logmsg);
            logmsg[ml] = '\0'; /* truncate back to header */
        } /* for */
        wstr[0] = '\0'; /* log entries already written */
        break;

    case EVENT_MSG:
        wstr[0] = 0; /* don't log internally generated event */
        break;

    case EVENT_MENU:    /* process menu event */
        {
        char cardName[STRINGLEN], itemName[STRINGLEN];
        
        MenuNames((Memh) ev->a4,ev->value,cardName,itemName);
        sprintf(wstr,"menu %d %d %G %s;%s",ev->a1,ev->a2,ev->a3, cardName,itemName);
        }
        break;

    case EVENT_TIME:    /* process timing event */
        break;

    case EVENT_PROC:    /* process execute-routine event */
        break;

    case EVENT_REDRAW:
    case EVENT_RESIZE: /* resize a window */
        sprintf(wstr,"resize %d %d",ev->x,ev->y);
        break;
    
#ifndef MAC
    case EVENT_BEGINLAY:    /* begin window re-layout */
        break;
        
    case EVENT_ENDLAY:  /* windows re-arranged */
        break;
#endif

    default:
        break;  /* no action taken */

    } /* switch */

    if (wstr[0]) {
        strcat(logmsg,wstr); /* append event-specific info */
        strcat(logmsg,NEWLINES);
        log_write(logmsg);
    } /* wstr if */

} /* log_event */

/* ******************************************************************* */

static log_write(str) /* write string to log file */
char *str;

{   char FAR *logp; /* pointer to log buffer */

    if (str[0] == 0)
        return(0); /* exit if no string */
    logp = GetPtr(evlogh);
    TUTORblock_move((char SHUGE *)str,logp+evlogl,(long)strlen(str));
    evlogl += strlen(str);
    if (evlogl > 850) { /* flush log if nearly full */
        TUTORwrite(logp,1,(long)evlogl,evlogfi);
        evlogl = 0;
    } /* evlogl if */

    ReleasePtr(evlogh);
    KillPtr(logp);

    return(0);
} /* log_write */

/* ******************************************************************* */

log_flush() /* flush event log if buffer filling up */

{   char FAR *logp; /* pointer to log buffer */

    if (evlogl > 600) { /* flush log if nearly full */
    logp = GetPtr(evlogh);
    TUTORwrite(logp,1,(long)evlogl,evlogfi);
    evlogl = 0;
    ReleasePtr(evlogh);
    KillPtr(logp);
    } /* evlogl if */

} /* log_flush */

/* ******************************************************************* */
