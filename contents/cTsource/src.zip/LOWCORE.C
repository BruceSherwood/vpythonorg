

/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* low-core variables and routines referenced by compiled code */


#ifdef MAC
#ifdef THINKC5
#include <math.h>
#include <ToolUtils.h>
void x80tox96(void *x80, void *x96);
void x96tox80(void *x96, void *x80);
#else
#ifdef WERKS
#include <math.h>
#include <ToolUtils.h>
void x80tox96(void *x80, void *x96);
void x96tox80(void *x96, void *x80);
#else
#include <ToolboxUtil.h>
#endif
#endif
#endif

#include "execdefs.h"
#include "eglobals.h"
#include "tglobals.h"
#include "commands.h"

#ifdef ctproto
extern int checkRadians(void);
extern double pow(double xx,double yy);
long  lowcore(void);
double  lcfdiv(double  av,double  bv);
long  lcint(double  av);
double  lcfrac(double  av);
int  jzjcount(void);
int  lcerr(long  ii);
int  fuzzyne(double  x,double  y);
int  fuzzygt(double  x,double  y);
int  fuzzylt(double  x,double  y);
int  fuzzyge(double  x,double  y);
int  fuzzyle(double  x,double  y);
int  graph_to_fine(double  gx,double  gy,long  *cx,long  *cy);
int  relative_to_fine(double  rx,double  ry,long  *cx,long  *cy);
int  lclocx(long  q);
int  lclocy(long  q);
int  fuzzyeq(double  x,double  y);
double  CoordToFloat(long  xx);
long  FloatToCoord(double  zz);
long  DivCoord(long  xx,long  yy);
int  RoundCoord(long  xx);
long  HalveCoord(long  xx);
long  AbsCoord(long  xx);
long  DoubleCoord(long  xx);
extern double log10(double x);
extern double sin(double x);
extern double cos(double x);
int  matherror(int  errnum,char  *s);
extern double floor(double x);
long  lcftoi(double  dv);
extern double fabs(double x);
extern long MulCoord(long xx,long yy);
double power10(int arg);
#endif /* ctproto */

#define abstolerance 0.000000001
#define reltolerance 0.00000000001
#define onep 1.0

#define IHUGE 0x7fffffffL


#ifndef ANDREW  /* gamma not available on small machines */
#ifndef __MC68K__
extern double gamma();
#endif
#endif

#ifdef ANDREW  /* gamma available on big machines */
extern int signgam; /* sign of gamma function */
#ifdef romp
#define ibm032 1
#endif  /* romp */
#ifdef ibm032
/*name was changed in math library to reflect logarithmic value returned (log of gamma).*/
#define gamma lgamma 
#endif  /* ibm032 */
#endif  /* andrew */

#ifndef WERKS
extern double pow();
#endif

extern int fuzzyeq();
extern int fuzzyne();
extern int fuzzygt();
extern int fuzzylt();
extern int fuzzyge();
extern int fuzzyle();
extern long TUTORinq_msec_clock();
extern double lcfdiv();
extern double fabs();

/* ******************************************************************* */

long lowcore()
{ return(0); }  

/* ******************************************************************* */

double lcfdiv(av,bv)                /* floating divide */
double av,bv;

{
#ifdef vax
    if (av == 0.0) {
        return(Infinite);
    }
#endif
#ifdef IBMPC
    if (av == 0.0) {
        if (bv == 0.0) return(Indefinite);
        else return(Infinite);
    }
#endif
    return(bv/av);

} /* lcfdiv */

/* ******************************************************************* */

long lcint(av)              /* integer part */
double av;

{   long    ix;

    ix = ( (av>=0) ? floor(av+abstolerance) : floor(av-abstolerance)+onep );
    return(ix);

} /* lcint */

/* ******************************************************************* */

double lcfrac(av)           /* fractional part */
double av;

{   double x;

    x = ( (av>=0) ? av -floor(av+abstolerance) : av -floor(av-abstolerance)-onep );
    return(x);

} /* lcfrac */

/* ******************************************************************* */

jzjcount()      /* return currrent *zjcount* value */

{   return (exS.arr.jbuffer->len); }

/* ******************************************************************* */

lcerr(ii)   /* expression error exit */
long ii;    /* error code */

{

    matherror(USERERR,"Array index out of bounds.");

} /* lcaerr */

/* ******************************************************************* */

fuzzyne(x, y) double x, y; {
return(!fuzzyeq(x,y));
}

fuzzygt(x, y) double x, y; {
if (fuzzyeq(x,y) || x<y) return(FALSE);
return(TRUE);
}

fuzzylt(x, y) double x, y; {
if (fuzzyeq(x,y) || x>y) return(FALSE);
return(TRUE);
}

fuzzyge(x, y) double x, y; {
return(!fuzzylt(x,y));
}

fuzzyle(x, y) double x, y; {
return(!fuzzygt(x,y));
}

/* ******************************************************************* */

double power10(pv) /* return 10**pv */
int pv;

{   
    if ((pv >= -4) && (pv <= 4)) {
        switch(pv) {
        
        case -4:
            return(0.0001);
        case -3:
            return(0.001);
        case -2:
            return(0.01);
        case -1:
            return(0.1);
        case 0:
            return(1);
        case 1:
            return(10.0);
        case 2:
            return(100.0);
        case 3:
            return(1000.0);
        case 4:
            return(10000.0);
            
        } /* switch */
    } else 
        return(pow(10.0,(double)pv));
    
} /* power10 */

/* ******************************************************************* */

graph_to_fine(gx,gy,cx,cy) /* convert graph coordinates to fine coordinates */
double  gx, gy; /* graph in */
Coord *cx, *cy; /* coord out */
 
{   double hx;
    double fv;

    if (exS.GPolar) {
    	if (checkRadians()) { /* radians */
    		hx = gx*cos(gy);
    		gy = gx*sin(gy);
    	} else { /* degrees */
        	hx = gx*cos(gy * RDN);
        	gy = gx*sin(gy * RDN);
        }
        gx = hx; 
    } /* exS.GPolar if */

    if (exS.GLogXflag)
        fv = (log10(gx)-exS.GXoffset)*exS.GXscale;
    else
        fv = (gx-exS.GXoffset)*exS.GXscale;
    if (fabs(fv) > 16383.0) {
        if (fv > 0.0) fv = 16383.0;
        else fv = -16383.0;
    }
    *cx = exS.GXorigin+ FloatToCoord(fv);
    
    if (exS.GLogYflag)
        fv = (log10(gy)-exS.GYoffset)*exS.GYscale;
    else
        fv = (gy-exS.GYoffset)*exS.GYscale;
    if (fabs(fv) > 16383.0) {
        if (fv > 0.0) fv = 16383.0;
        else fv = -16383.0;
    }
    *cy = exS.GYorigin-FloatToCoord(fv);


} /* graph_to_fine */

/* ******************************************************************* */

relative_to_fine(rx,ry,cx,cy)   /* convert r-coordinates to fine */
double rx, ry ; /* relative in */
Coord *cx, *cy; /* Coord out */
    {
    double tx, ty;
    
    if (exS.RXsizeFlag)  rx *= exS.RXsize ;
    if (exS.RYsizeFlag)  ry *= exS.RYsize ;
    if (exS.RAngleFlag)
        {
        tx = rx*exS.RcosAngle - ry*exS.RsinAngle;
        ty = rx*exS.RsinAngle + ry*exS.RcosAngle;
        rx = tx;
        ry = ty;
        }
    *cx = exS.RXorigin+FloatToCoord(rx);
    *cy = exS.RYorigin+FloatToCoord(ry);

} /* relative_to_fine */

/* ******************************************************************* */

int lclocx(q)  /* scale x co-ordinate */
Coord q;
{
    q -= exS.RegionXmin;
    if (exS.RescaleX)
        q = MulCoord(exS.ScaleX,q);
    return(RoundCoord(q));

} /* lclocx */

/* ******************************************************************* */

int lclocy(q) /* scale y co-ordinate */
Coord q;
{
    q -= exS.RegionYmin;
    if (exS.RescaleY)
        q = MulCoord(exS.ScaleY,q);
    return(RoundCoord(q));

} /* lclocy */

/* ******************************************************************* */

int fuzzyeq(x, y) 
double x, y; 

{   

	if (exS.inhibbits & (1L << INHFUZZY)) {
		return(x == y);
	}

    if (fabs(x-y) <= abstolerance) return(TRUE);
    if ((fabs(x) > abstolerance) && (fabs(1.0-y/x) < reltolerance)) 
        return(TRUE);
    return(FALSE);

} /* fuzzyeq */

/* ******************************************************************* */


/* ***************************************** Coord variable type handling ******************* */

/* at present we have: typedef long Coord; */
/* the long is used to represent a fixed point number (as on the mac) */

#ifdef MACzz
#ifdef THINKC5
#include <FixMath.h>
/* extern pascal double Fix2X(Coord xx);
extern pascal long X2Fix(double *zz);
extern pascal long FixDiv(long xx,long yy); */
#endif

/* uses toolbox calls for fixed point machinery */
double CoordToFloat(xx)
Coord xx;
    {
    double zz;
    /* extended temp; */
    long double temp;
#ifdef THINKC5
	temp = Fix2X((Fixed)xx);
	x80tox96(&temp,&zz);
#else
    zz = Fix2X(xx);
#endif
    return(zz);
    }

pascal long X2Fix();

Coord FloatToCoord(zz)
double zz;
    {
    Coord xx;
/*    extended temp; */
	long double temp;
#ifdef THINKC5
	x96tox80(&zz,&temp);
    xx = X2Fix(temp);
#else
	xx = X2Fix(&zz);
#endif
    return(xx);
    }

Coord MulCoord(xx,yy)
Coord xx,yy;
    {
    return(FixMul(xx,yy));
    }

Coord DivCoord(xx,yy)
Coord xx,yy;
    {
    return(FixDiv(xx,yy));
    }

int RoundCoord(xx)
Coord xx;
    {
    return(FixRound(xx));
    }
#else

double CoordToFloat(xx)
Coord xx;
    {
    double zz;
    
    zz = xx;
    zz /= 0x10000;
    
    return(zz);
    }

Coord FloatToCoord(zz)
double zz;
    {
    Coord xx;

    zz *= 0x10000;
    xx = lcftoi(zz);
    
    return(xx);
    }

Coord MulCoord(xx,yy)
Coord xx,yy;
    {
    return(FloatToCoord(CoordToFloat(xx)*CoordToFloat(yy)));
    }

Coord DivCoord(xx,yy)
Coord xx,yy;
    {
    return(FloatToCoord(lcfdiv(CoordToFloat(yy),CoordToFloat(xx))));
    }

RoundCoord(xx)
register Coord xx;
    
{   register int roundup;
    
    if (xx >= 0) {
        roundup = (xx & 0x00008000) ? 1 : 0; /* add one if 1/2 bit set */
        return((int) (xx >> 16) + roundup);
    } else {
        roundup = (xx & 0x00008000) ? 0 : -1;
        xx = -((-xx) >> 16);
        return(xx+roundup);
    }

} /* RoundCoord */

#endif


Coord HalveCoord(xx)
Coord xx;

{
    if (xx >= 0)
    return(xx >> 1);
    return(xx/2);

} /* HalveCoord */

Coord AbsCoord(xx)
register Coord xx;
    {
    if (xx < 0)
        xx = -xx;
    return(xx);
    }

Coord DoubleCoord(xx)
Coord xx;

{
    return(xx << 1); 

} /* DoubleCoord */


/* ******************************************************************* */

#ifdef vax

extern double lgamma();

double gamma(dv)

{
    return(lgamma(dv));
    
} /* gamma */

#endif  

/* ******************************************************************* */
