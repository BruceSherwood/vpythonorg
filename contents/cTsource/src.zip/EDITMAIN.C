#include "baseenv.h"
#include "tutor.h"
#include "tglobals.h"
#include "tfiledef.h"
#include "commands.h"
#include "editor.h"
#include "ecglobal.h"
#include "kglobals.h"
#ifdef ctproto
extern int init_mvar_cache(void);
long  TUTORadd_ffamily(struct  _fref *famName,int  isSys,int  isSwitch);
long TUTORinq_symbolic_font_id(char  *fontName);
int procdialogwstub(Memh dh, struct tutorevent *event);
double  PanelScrollstub(struct  tutorview FAR *tview,int  hv,double  nn,int  type);
double  PanelScroll(struct  tutorview FAR *tview,int  hv,double  nn,int  type);
int  TUTORinq_font_descr(int  fontN,long *fam,int  *siz,int  *fac);
#endif /* ctproto */
extern Memh TUTORnew_doc();
extern double PanelScrollstub();
extern double PanelScroll();
extern long TUTORinq_symbolic_font();
extern long  TUTORadd_ffamily();
struct tempfars {
    char tempFarS[64];
    long tempFarL;
    int tempFari;
    unsigned int tempFarUi;
    TRect tempFarR;
}; 
ctmain1(argc,argv)
int argc;
char **argv;
    {
    struct tempfars FAR *tempfp;
    struct tutorfile FAR *tfp;
    FileRef filename;
	int si;
    
    /* initialize */
#ifdef ANDREW
    wm_init_mem();
#endif
    ctedit = TRUE;
    ctcomp = ctexec = FALSE;
    DictWn = HelpWn = ExecWn = TraceWn = SelectWn = -1; /* no windows yet */
    for(si=0; si<EDITWINDOWLIMIT; si++) {
        EditWn[si] = -1; /* no edit windows/views yet */
        EditVp[si] = FARNULL;
    }
    ctDirP = (FileRef FAR *)TUTORalloc((long)(sizeof(FileRef)),
		  TRUE,"ctdir");
    sourceDirP = (FileRef FAR *)TUTORalloc((long)(sizeof(FileRef)),
		  TRUE,"srdir");
    currentDirP = (FileRef FAR *)TUTORalloc((long)(sizeof(FileRef)),
		    TRUE,"dir");
    tempfp = (struct tempfars FAR *)
	     TUTORalloc((long)sizeof(struct tempfars),TRUE,"tmp");
    tempFarS = tempfp->tempFarS;
    tempFarL = &(tempfp->tempFarL);
    tempFari = &(tempfp->tempFari);
    tempFarUi = &(tempfp->tempFarUi);
    tempFarR = &(tempfp->tempFarR);
    InitHandles();
    /* file table */
    if (filesmalloc == 0)  { /* allocate file table if not present */
        filesmalloc = 2;
        filesopen = TUTORhandle("files  ",(long)(filesmalloc*sizeof(struct tutorfile)),TRUE);
        if (!filesopen)
            StopProgram(NEARNULL);
        tfp = (struct tutorfile FAR *) GetPtr(filesopen);
        tfp->inuse = (tfp+1)->inuse = FALSE;
        ReleasePtr(filesopen);
    }
    sourcemalloc = 1;
    sourcetable = (struct sourcefile FAR *) 
              TUTORalloc((long)(sourcemalloc*sizeof(struct sourcefile)),TRUE,"srctable");
    initsourcet(0);
    TUTORstartup(argc,argv,(FileRef FAR *) &filename);
    if (lforkf && fork ())
        exit (0);  /* let unix shell get back to work */
    TUTORinit_graf();
    InitPrefs();
    TUTORinit_swap();
    TUTORinit_doc();
    init_mvar_cache();
    iconFont0 = textFont0;
    cursorFont0 = TUTORget_zfont("zcursors",-1); /* default cursor font */
    cursorChar0 = 'a'; /* default cursor character */
    patternFont0 = TUTORget_zfont("zpatterns",-1); /* default fill pattern font */
    patternChar0 = 16; /* default fill character - black */
    initedit0(); /* initialize all editors */
    /* start window */
    TestPanel(&filename);
    
} /* ctmain1 */
ctmain2() { return; } 
/* ------------------------------------------------------------------- */
static TestPanel(filename)
FileRef *filename;
    {
    Memh theDoc, NewKDoc(), eDat1;
    char FAR *linest;
    int jj;
    int wid;
    EditDat FAR *ep;
    char tempS[FILEL+1];
    
    /* create window */
    wid = TUTORcreate_window(-1,-1,0,0,EDITW);
    EditWn[0] = wid;
    TUTORget_fileref_name((FileRef FAR *) filename,(char FAR *) tempS);
    settitles(tempS);
#ifdef WM
    if (isx11) { /* establish menu bar */
	pd_enter(EditWn[0]);
        pd_restore();
    }
#endif
#ifdef DOSPC
    pd_enter(EditWn[0]); /* establish menu bar */
    pd_restore();
#endif
    
    /* read source file */
    theDoc = TUTORnew_doc(TRUE,TRUE);
    EditorDefaultStyles(theDoc);
    readdoc(theDoc,(FileRef FAR *) filename,&jj,(char FAR * FAR *) &linest);
    
    /* start editor */
    eDat1 = TUTORhandle("editdata",(long) sizeof(EditDat),TRUE);
    ed1H = eDat1; /* global handle on editor */
    ep = (EditDat FAR *) GetPtr(eDat1);
    TUTORcopy_fileref(&ep->filename,(FileRef FAR *) filename);
    ReleasePtr(eDat1);
    initedit(wid,eDat1,theDoc,FALSE);   /* start editor */
    }
#ifndef MAC
OpenFileDialogstub(dialog)
Memh dialog;
{
    return(OpenFileDialog(dialog));
}
ESTextSelectstub(dialog, edH, event)
Memh dialog, edH;
register struct tutorevent *event;
{
    return(ESTextSelect(dialog, edH, event));
}
#endif
int proceditstub(wn,event)  /* event processor for help */
int wn;
struct tutorevent *event; /* event to process */
{
    return(procedit(wn,event));
} /* proceditstub */
/* ------------------------------------------------------------------- */
int procdialogstub(hv,event)
Memh hv;
struct tutorevent *event;
    {
    return(procdialog(hv,event));
    }
double PanelScrollstub(tview,hv,nn,type)
struct  tutorview FAR *tview;
int  hv;
double  nn;
int  type;
    {
    return(PanelScroll(tview,hv,nn,type));
    }
int procexecwstub(wh,event) /* window event processor for executor */
Memh wh;
struct tutorevent *event; /* event to process */
    {;}
/* ******************************************************************* */
myexit()
    {
    TUTORexit();
    }
PanelEventStub(ph,event)
Memh ph;
struct tutorevent *event;
    {
    return(PanelEvent(ph,event));
    }
/* ------------------------------------------------------------------- */
int procbuttonstub(hv,event)
Memh hv;
struct tutorevent *event;
    {
    return(procbutton(hv,event));
    }
/* ------------------------------------------------------------------- */
int procdialogwstub(dh, event)
Memh dh;
struct tutorevent *event;
    {
    return(procdialogw(dh,event));
    }
/* ******************************************************************* */
setmainfile(filename)   /* set main (editing/executing) file */
FileRef FAR *filename;
{   long modtim; /* time file last modified */
    EditDat FAR *ep;
    if (TUTORcmp_fileref(filename,&sourcetable[0].fRef) != 0) {
        TUTORcopy_fileref(&sourcetable[0].fRef,filename);
    }
    TUTORcopy_fileref_dir(sourceDirP, filename); /* reset sourceDir */
    TUTORcopy_fileref_dir(currentDirP, filename);
    if (ctedit) {
        ep = (EditDat FAR *) GetPtr(ed1H);
        TUTORcopy_fileref(&ep->filename,filename);
        ReleasePtr(ed1H);
    } /* ctedit if */
    TUTORinq_file_info(&sourcetable[0].fRef,NEARNULL,NEARNULL,
             &modtim,NEARNULL,NEARNULL);
    sourcetable[0].mtime = modtim;
	sourcetable[0].editI = 0; /* set index of editor */
} /* setmainfile */
/* ******************************************************************* */
settitles(filename) /* set editor/executor window titles */
char *filename;
{   int l;  /* length of title string */
    char wt[CTPATHLEN]; /* title string */
    l = strlen(filename);
    if (l > 35) strcpy(wt,filename+(l-35));
    else strcpy(wt,filename);
    if (EditVp[0])
	TUTORset_window_title(EditWn[0],wt);
} /* settitles */
#ifdef KSWnomore
RestoreTextStub(textH,tp,tLen,theDoc) /* restore text from disk */
Memh textH; /* handle being restored */
char FAR *tp; /* destination of recovered text */
long tLen; /* length of text to recover */
Memh theDoc; /* document which owns this text block */
    {
    RestoreText(textH,tp,tLen,theDoc);
    }
#endif
int procscrollstub(scrH,event)  /* event processor for scroll bar */
Memh scrH;
struct tutorevent *event; /* event to process */
{
    return(procscroll(scrH,event));
} /* procscrollstub */
/* ******************************************************************* */
double CoordToFloat(xx)
Coord xx;
{   double zz;
    
    zz = xx;
    zz /= 0x10000;
    return(zz);
} /* CoordToFloat */
    
/* ******************************************************************* */
Coord FloatToCoord(zz)
double zz;
{   Coord xx;
    zz *= 0x10000;
    xx = lcftoi(zz);
    return(xx);
} /* FloatToCoord */
/* ******************************************************************* */
TUTORwrite_socket() {;}
TUTORread_socket() {;}
TUTORungetc_socket() {;}
TUTORgetchar_socket() {;}
TUTORclose_socket() {;}
IdleSockets() {;}
StdioDummy() {;}
compile1() {;}
compile() {;}
axes() {;}
evalscore() {;}
extsetup() {;}
AuthorSplash() {;}
DecodeText() {;}
RunUnitStub() {;}
RestoreBinaryStub() {;}
StopProgram() {;}
setbasesrc() {;}
TellUser() {;}
yyerror();
#ifndef WINPC
double log(vv) double vv; {;}
double log10(vv) double vv; {;}
#endif
execerr() {;}
#ifndef SYSV
#ifdef mips
int pgen; 
#else
machcod() {;}
#endif
#endif
#ifdef ibm032
/* ------------------------------------------------------------------------------ */
#include <machine/float.h>
int fpastat()   /* returns TRUE if FPA hardware present */
{   int fpacc;
    struct floatstate fpstat;
    int fpsize;
    fpsize = sizeof(struct floatstate);
    fpacc = getfloatstate(&fpstat,&fpsize);
    fpacc = float_has_fpa(fpstat.process_state); 
    if (fpacc) fpacc = 1;
    setfpaf(fpacc);
    return(fpacc);
} /* fpastat */
/* ------------------------------------------------------------------------------ */
#endif
#ifdef IBMPC
/* ------------------------------------------------------------------------------ */
long lcftoic(dv)
double dv; 
{ 
    return((long)(floor(dv+0.5))); 
} /* lcftoic */
/* ------------------------------------------------------------------------------ */
#endif
/* ******************************************************************* */
int procmsgstub(wh,event)  /* event processor for message window */
Memh wh;
struct tutorevent *event; /* event to process */
{
    return(procmsg(wh,event));
} /* procmsgstub */
/* ------------------------------------------------------------------- */
#ifdef WINPC
post_toedit()  /* generate event to focus on editor */
{   struct tutorevent ev;
    ev.window = EditWn[0];
    ev.view = FARNULL;
    ev.type = EVENT_MSG;
    ev.timestamp = 20;
    ev.a1 = exec_toedit;
    windowsP[EditWn[0]].MenuFocus = EditVp[0];
    TUTORpost_event(&ev); /* send event to editor */
} /* post_toedit */
#endif
/* ******************************************************************* */
