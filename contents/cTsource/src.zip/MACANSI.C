
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* file with ansi-only includes */

/* ******************************************************************* */

#include <time.h>

extern double TUTORjdate(void);

/* ******************************************************************* */

double TUTORjdate() /* return julian date */

{	time_t timeV;
	double timeD;

	time(&timeV);
	timeD = timeV;
	timeD -= 24107.0*60L*60L*24L; /* base is 00:00:00 GMT, Jan 1, 1970 */
	timeD += 4L*60L*60L; /* duh, time-zone anyone? */
	return(timeD);
	
} /* TUTORjdate */

/* ******************************************************************* */

#ifdef __MC68K__
/* #define CONSOLESTUB */
#endif

#ifdef CONSOLESTUB

/* MetroWerks library problem? */
/* define these to avoid having to bring in the SUIOX library */

extern int ReadCharsFromConsole(void);
extern int WriteCharsToConsole(void);
extern int RemoveConsole(void);
extern int InstallConsole(void);

ReadCharsFromConsole() { return(0); }
WriteCharsToConsole() { return(0); }
RemoveConsole() { return(0); }
InstallConsole() { return(0); }

#endif

/* ******************************************************************* */
