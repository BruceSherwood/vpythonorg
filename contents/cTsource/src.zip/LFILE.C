
/* ******************************************************************* */

#include <io.h>
#include <stdio.h>
#include <stdlib.h>
#include <dos.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <sys/stat.h>

/* ******************************************************************* */

#define TRUE 1
#define FALSE 0

extern long l_write();
extern long l_read();
extern int l_block_move(char far *p1,char far *p2,long len);
extern int l_zero(char far *ptr,long len);
extern char far *l_alloc(long size);
extern int l_free(char far *ptr);
extern char far *l_lp(long addr);

static long flrdwr();

/* ******************************************************************* */

long l_write(ptr,pSize,count,fp) /* long write */
char far *ptr; /* buffer to write out */
int pSize; /* size of item */
long count; /* # of items to write out */
FILE *fp;
/* returns # of bytes written */
    
{
    return(flrdwr(ptr,pSize,count,fp,FALSE));

} /* l_write */

/* ******************************************************************* */

long l_read(ptr,pSize,count,fp) /* long read */
char far *ptr; /* buffer to fill */
int pSize; /* size of item */
long count; /* # of items to write out */
FILE *fp;
/* returns # of bytes read */
    
{
    return(flrdwr(ptr,pSize,count,fp,TRUE));

} /* l_read */

/* ******************************************************************* */

#define CHUNKSZE 1024

static long flrdwr(rwptr,pSize,count,fp,rwFlag) /* long read or write */
char far *rwptr; /* where the read is going */
int pSize; /* size of object */
long count; /* # of objects */
FILE *fp; /* file to read/write */
int rwFlag; /* TRUE: read, FALSE: write */
    
{   int nReads,ii, nNew, toRead;
    long nIn;
    char far *fbuf; /* long pointer to local buffer */
    char buf[CHUNKSZE]; /* local buffer for read/write */
    char huge *ptr; /* pointer to data read/written */

    nIn = 0;
    ptr = rwptr; /* use huge ptr so arithmetic works */
    count *= pSize; /* now just working in bytes */

    if (!count)
	return(nIn);
    
    nReads = (int)((count-1)/CHUNKSZE);
    for (ii=0; ii<=nReads; ii++) {
	toRead = ((ii == nReads) ? ((int)(count-nReads*CHUNKSZE)) : CHUNKSZE);
	if (rwFlag) {
	    nNew = fread(buf,1,toRead,fp);
	    fbuf = buf; /* far pointer to local buffer */
	    l_block_move(fbuf,ptr,(long)toRead);
	} else {
	    fbuf = buf; /* far pointer to local buffer */
	    l_block_move(ptr,fbuf,(long)toRead);
	    nNew = fwrite(buf,1,toRead,fp);
	} /* else */
	if (nNew == 0) {
	    if (feof(fp))
		return(nIn); /* read to end of file */
	    return(0L); /* error */
	} /* nNew if */
	nIn += nNew;
	ptr += toRead;
	if (nNew < toRead)
	    break;
    } /* for */

    if (!rwFlag)
	fflush(fp);

    return(nIn);

} /* flrdwr */

/* ******************************************************************* */

char far *l_alloc(size) /* allocate block of memory */
long size; /* number bytes to allocate */

{   unsigned int nBlocks; /* number 64 byte blocks to allocate */
    union REGS inr; /* input registers for DOS system call */
    union REGS outr; /* output registers for DOS system call */
    long memA; /* address as long integer */
    char far *memP; /* pointer to memory block */

    nBlocks = (unsigned int)((size+15L) >> 4); /* size in paragraphs */
    inr.h.ah = 0x48; /* allocate memory */
    inr.x.bx = nBlocks; /* number blocks to allocate */
    intdos(&inr,&outr); /* allocate memory */
    if (outr.x.cflag)
	return(NULL); /* failed */
    memA = ((long)(outr.x.ax)) << 4; /* convert segment to address */
    memP = l_lp(memA); /* convert address to far pointer */
    return(memP);

} /* l_alloc */

/* ******************************************************************* */

int l_free(ptr) /* release memory */
char far *ptr; /* pointer to memory block to release */

{   union REGS iregs; /* input registers for DOS system call */
    union REGS oregs; /* output registers for DOS system call */
    struct SREGS sregs; /* segment (input) registers for DOS call */

    segread(&sregs); /* get segment registers */
    iregs.h.ah = 0x49; /* deallocate memory */
    sregs.es = FP_SEG(ptr); /* get segment (offset must be zero) */
    intdosx(&iregs,&oregs,&sregs); /* deallocate memory */
    if (oregs.x.cflag) {
	printf("memory dealloc failed\n");
	exit(1);
    }
    return(0);

} /* l_free */

/* ******************************************************************* */
