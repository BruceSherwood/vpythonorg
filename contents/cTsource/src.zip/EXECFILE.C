
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "baseenv.h"
#include "tfiledef.h"
#include "execdefs.h"
#include "eglobals.h"
#include "tglobals.h"

#ifdef ANDREW
#include <sys/errno.h>
#include "file.h"

#endif /* ANDREW */

#ifdef MAC
#ifdef THINKC5
#include <Files.h>
#else
#ifdef WERKS
#include <Files.h>
#else
#include <FileMgr.h>
#endif
#endif
#endif /* MAC */

#ifdef ctproto
extern int FilePath(int findex,char *path);
extern double lcitof(long vv);
int  FinishFileOpen(long SHUGE *loc,int  findx);
int  DeleteFile(long SHUGE *loc);
int  FileIsOpen(long fid);
int  FileWriteOK(long  findx);
int  CloseFile(long SHUGE  *loc);
int  CloseAllFiles(void);
int  CloseLocalFiles(void);
int CloseUnitLocalFiles(void);
int  FlushAllFiles(void);
int  ReadNumber(int  findx,double  *value);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORclose(int  findx);
int  killptr(char  FAR * FAR *ptr);
long  TUTORinq_file_pos(int  findx);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
int  TUTORdelete_file(struct  _fref FAR *fRef);
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
int  TUTORungetc(int  findx,int  cc);
int  TUTORget_char(int  findx,int  tryHard);
int  getnum(char  *s,int  *floatf,long  *i,double  *d,char  * *errm,int  *errn);
int  CloseMMotionVideo(void);
int  CloseExternalVideo(void);
#ifdef IBMPROTO
int _CDECL fflush(FILE *);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
extern int MacFilePath(FileRef *fR,char *str,int len);
extern int strcatf(char *dd,char *ss);
#ifndef THINKC5
extern int fileno(FILE *);
extern int fflush(FILE *);
#ifndef LSC4
#ifndef WERKS
extern int feof(FILE *);
#endif
#endif
#endif
#endif

extern FILE *TUTOR_serial();

/* ******************************************************************* */
FinishFileOpen(loc,findx)
long SHUGE *loc; /* loc is address of author variable */
int findx; /* index returned by "file" opening routine */

{  struct tutorfile FAR *fptr;

    exS.zreturn = tfilerr; /* pick up error return */
    if (exS.zreturn >= 0 || findx == 0)
        return(0); /* exit if error */
    *loc = findx; /* set up author variable */
    fptr = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    fptr->vloc = (unsigned char SHUGE *)(loc)-exS.stackP; /* save rel addr of author var */
    ReleasePtr(filesopen);
    KillPtr(fptr);

} /* FinishFileOpen */

/* ******************************************************************* */

DeleteFile(loc)     /* delete file specified at loc in author variables */
long SHUGE *loc;

{   int findx; /* index of file in table */
    struct tutorfile FAR *fptr; /* pointer to table entry */
    FileRef fRef;
    int fkind; /* file type */

    exS.zreturn = -1; /* pre-set no error */
    if ((long)(loc) == -1) return(0); /* nothing to do */
    findx = *(loc);
    *(loc) = -1;
    if ((findx < 0) || (findx > filesmalloc)) return(0); /* nothing to do */
    fptr = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    TUTORcopy_fileref((FileRef FAR *) &fRef,&fptr->fRef);
    fkind = fptr->kind; /* save file type */
    ReleasePtr(filesopen);
    KillPtr(fptr);
    TUTORclose(findx); /* close file before destroying */
    if (fkind != 0) exS.zreturn = FILEPERMIT; /* must be normal file */
    else {
        if (!TUTORdelete_file((FileRef FAR *) &fRef)) /* attempt to destroy file */
            exS.zreturn = FILEPERMIT;
    } /* else */

} /* DeleteFile */

/* ******************************************************************* */

FileIsOpen(fid) /* return TRUE if fid does represent an open file */
long fid; /* index of filesopen entry */

{   int i;
    struct tutorfile FAR *fptr;

    if (fid < 0 || fid >= filesmalloc) return(FALSE);
    fptr = fid+(struct tutorfile FAR *)GetPtr(filesopen);
#ifdef X11
    if (fptr->kind == 0 || fptr->kind == 1 || fptr->kind == 3)
	 i = (fptr->fp != NULL);  /* file or serial port */
#endif
#ifdef DOSPC
    if (fptr->kind == 0 || fptr->kind == 1 || fptr->kind == 3)
	 i = (fptr->fp != NULL);  /* file or serial port */
#endif
#ifdef WINPC
    if (fptr->kind == 0)
	 i = (fptr->fp != NULL);  /* file */
    else if (fptr->kind == 1)
	i = (fptr->stream >= 0); /* serial port */
#endif
#ifdef MAC
    if (fptr->kind == 0 || fptr->kind == 3)
         i = (fptr->fp != NULL);  /* file or serial port */
    else if (fptr->kind == 1)
        i = fptr->stream != 0;
#endif
    else if ((fptr->kind == 2) || (fptr->kind == 6))
        i = (fptr->stream != -1);  /* socket */

    if (!fptr->inuse) i = FALSE;
    ReleasePtr(filesopen);
    KillPtr(fptr);
    return(i);

} /* FileIsOpen */

/* ******************************************************************* */

int FileWriteOK(findx) /* return -1 if ok to write file, +n = zreturn value */
long findx; /* index of filesopen entry */

{   int wok; /* -1 if ok to write */
    struct tutorfile FAR *fptr;
    long flen; /* file length */
    long fpos; /* file position */

    /* check file open with write permission */

    wok = -1; /* pre-set all ok */
    if (findx < 0 || findx >= filesmalloc) return(FALSE);
    fptr = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    if ((fptr->kind == 1) || (fptr->kind == 2) || (fptr->kind == 6)) {
        /* serial, socket, always writeable */
        ReleasePtr(filesopen);
        KillPtr(fptr);
        return(-1);
    }
    if (!fptr->inuse || !fptr->fp) wok = FILENOTOPEN;
    if (fptr->ro) wok = FILEPERMIT;

    /* check if write at end of file */

    if ((wok < 0) && (fptr->lastop != fop_new) && (fptr->lastop != fop_end) &&
       (fptr->lastop != fop_empty) && (fptr->lastop != fop_write)) {
        TUTORinq_file_info(&fptr->fRef,NEARNULL,&flen,NEARNULL,NEARNULL,NEARNULL);
        fpos = TUTORinq_file_pos((int)findx);
        if ((fpos < flen) && !feof(fptr->fp))
            wok = FILERANGE; /* write not at end of file */
    } /* wok/lastop if */
    ReleasePtr(filesopen);
    KillPtr(fptr);
    return(wok);

} /* FileWriteOK */

/* ******************************************************************* */

CloseFile(loc)  /* close file specified at loc in author variables */
long SHUGE *loc;

{   int findx; /* index of file in table */
    struct tutorfile FAR *fptr; /* pointer to table entry */

    if ((long)loc == -1) return(0);
    if ((long)loc == 0) return(0);
    findx = *(loc);
    if (!FileIsOpen(findx)) 
        return(0);
    *loc = -1; /* clear author variable */
    TUTORclose(findx); /* close file */

} /* CloseFile */

/* ******************************************************************* */

CloseAllFiles()     /* close all files in filesopen list */
{   int  i;
    struct tutorfile FAR *theF;

    theF = (struct tutorfile FAR *) GetPtr(filesopen);
    for (i = 0; i < filesmalloc; i++, theF++)
        if ((theF->inuse) && (theF->vloc != -1))
            CloseFile((long SHUGE *)(theF->vloc+exS.stackP));
    ReleasePtr(filesopen);
    KillPtr(theF);
    CloseExternalVideo(); /* close any (serial) video port */
    CloseMMotionVideo(); /* close m-motion video */
    return(0);

} /* CloseAllFiles */

/* ******************************************************************* */

CloseLocalFiles() /* close all local files in filesopen list */

{   int i;
    struct tutorfile FAR *theF;
	long SHUGE *cp;

    theF = (struct tutorfile FAR *) GetPtr(filesopen);
    for (i = 0; i < filesmalloc; i++, theF++) {
        if (theF->inuse) { 
            if ((theF->vloc >= gvaraddr) && (theF->vloc < exS.stackmalloc)) {
                cp = (long SHUGE *)(theF->vloc+exS.stackP); /* pointer to variable */
                CloseFile(cp);
                theF->vloc = -1; /* no variable */
            }
        }
    } /* for */
    ReleasePtr(filesopen);
    KillPtr(theF);

} /* CloseLocalFiles */

/* ******************************************************************* */

CloseUnitLocalFiles() /* close local files for current unit */

{   int i;
    struct tutorfile FAR *theF;
	long SHUGE *cp;

    theF = (struct tutorfile FAR *) GetPtr(filesopen);
    for (i = 0; i < filesmalloc; i++, theF++) {
        if (theF->inuse && (theF->vloc >= exS.lvars)) { 
            if ((theF->vloc >= gvaraddr) && (theF->vloc < exS.stackmalloc)) {
                cp = (long SHUGE *)(theF->vloc+exS.stackP); /* pointer to variable */
                CloseFile(cp);
                theF->vloc = -1; /* no variable */
            }
        }
    } /* for */
    ReleasePtr(filesopen);
    KillPtr(theF);

} /* CloseLocalFiles */

/* ******************************************************************* */

FlushAllFiles()     /* flush all files in filesopen list */

{   int  i;
    struct tutorfile FAR *theF;

    theF = (struct tutorfile FAR *) GetPtr(filesopen);
    for (i = 0; i < filesmalloc; i++, theF++) {
        if (theF->inuse && (theF->vloc != -1)) {
            if (theF->kind == 0)
                fflush(theF->fp);
        } /* inuse if */
    } /* for */
    ReleasePtr(filesopen);
    KillPtr(theF);

} /* FlushAllFiles */

/* *********************************************************** */

ReadNumber(findx,value) /* read next number from file */
/* return FALSE if reach end of file, or if illegal chars */
/* if there are illegal chars, set zreturn to FILECHAR */
int findx;
double *value;
    
{   char s[STRINGLEN];
    char *errM;
    int cc;
    int errN, ii, floatf;
    int isComplex, isNum, isLeading, havePeriod, haveExp;
    int quickRead;
    double fValue,retFV;
    long iValue,retIV;
    int tryHard;
    struct tutorfile FAR *tfp;	/* pointer to file table entry */
    int lastChar; /* previous character read */

    /* once we have 1 character, we will try hard to get a complete number */
    /* (we could be reading from a serial port or socket which doesn't have */
    /* data ready at the moment) */
    
    tryHard = FALSE;
   
    quickRead = FALSE;
    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);
#ifdef MAC
    if (tfp->kind == 0) {
    	quickRead = TRUE;
    	tfp->lastop = fop_read;
    }
#endif
    	
    /* attempt to build simple numeric string */
    
    isComplex = floatf = havePeriod = haveExp = FALSE;
    retIV = 0;
    isLeading = TRUE; /* potential leading space */
    ii = 0; /* index in string */
    do {
	lastChar = tfp->lastC;
    	if (quickRead) {
	    cc = fgetc(tfp->fp);
	    tfp->lastC = cc;
    	} else {
	    cc = TUTORget_char(findx,tryHard);
    	}
    	tryHard = TRUE; /* from now on, try hard for character */
    	if ((cc >= '0') && (cc <= '9')) {
	    s[ii++] = cc;
	    if (ii > (STRINGLEN-4)) {
		isComplex = TRUE;
		break; /* too long, can't handle here */
	    }
	} else if (cc == 0x0a) {
	    if (lastChar == 0x0d) {
		if ((tfp->crKind == -1) || (tfp->crKind == 1))
		    tfp->crKind = 2;
	    } else if (tfp->crKind == -1)
		tfp->crKind = 0;
	    if (!isLeading)
		break; /* legal terminating character */
	} else if (cc == 0x0d) {
	    if (tfp->crKind == -1)
		tfp->crKind = 1;
	    if ((tfp->crKind != 2) && (!isLeading))
		break; /* legal terminating character */
	} else if ((cc == ' ') || (cc == '\t')) {
	    if (!isLeading)
		break; /* legal terminating character */
    	} else if (cc == '.') {
	    if (havePeriod) {
		isComplex = TRUE; /* something is wrong */
		break;
	    }
	    havePeriod = TRUE;
	    s[ii++] = cc;
    	} else if ((cc == 'e') || (cc == 'E')) {
	    if (isLeading || haveExp) {
		isComplex = TRUE; /* suspicious */
		break;
	    }
	    haveExp = TRUE;
	    s[ii++] = cc;
    	} else if (cc == EOF) {
	    if (isLeading) {
		if (quickRead)
		    ReleasePtr(filesopen);
		    return(FALSE); /* nothing to process */
    		} else 
		    break; /* legal terminating character */
    	} else {
	    isComplex = TRUE; /* something we can't handle here */
	    break;
    	}
    	if (ii) 
	    isLeading = FALSE; /* now have some string */
    } while (TRUE);
    	
    s[ii] = 0; /* ensure terminating zero */
    
    if (!isComplex) { /* simple value */
	isNum = getnum(s, &floatf, &retIV, &retFV, &errM,&errN);
	if (!isNum) return(FALSE);
    } else {

	/* complex form, perform entire evaluation one character */
	/* at a time */
		
	s[ii] = cc; /* pick up first character */
    	retIV = 0;
    	retFV = 0.;
    	while (TRUE) {
	    /* as long as string is still a number, keep reading */
	    s[++ii] = 0;
	    if (!(isNum = getnum(s, &floatf, &iValue, &fValue, &errM,&errN)))
            	break; /* hit end of number for some reason */
	    retIV = iValue; /* remember valid return */
	    retFV = fValue;
	    if (ii > STRINGLEN-2)
		break; /* too many chars to read anymore */
	    lastChar = tfp->lastC;
	    s[ii] = TUTORget_char(findx,tryHard);
	    if (s[ii] == 0x0d) {
		if (tfp->crKind == 2)
		    s[ii] = TUTORget_char(findx,tryHard); /* ignore 0x0d */
		else if (tfp->crKind == -1)
		    tfp->crKind = 1; /* 0x0d is terminator (for now) */
	    } else if (s[ii] == 0x0a) {
		if (lastChar == 0x0d)
		    tfp->crKind = 2; /* 0x0d, 0x0a is terminator */
		else if (tfp->crKind == -1)
		    tfp->crKind = 0; /* 0x0a is terminator */
	    }
	    if (s[ii] == ' ' || s[ii] == '\t' || s[ii] == 0x0d || s[ii] == 0x0a) {
		/* seperator, stop */
            	ii++; /* so test below (if (!isNum &&...)) will work ok */
            	break;
	    }
	    if (s[ii] == EOF)
            	return(FALSE);
    	} /* while */
	if (!isNum && s[ii-1] != ' ' && s[ii-1] != '\t' &&
	    s[ii-1] != 0x0d && s[ii-1] != 0x0a)
	    TUTORungetc(findx,s[ii-1]); /* last char (not seperator) was bad */
    	/* else if ii > STRINGLEN-2 we must have stopped because number was too long */
    	if (ii <= 1) {
	    exS.zreturn = FILECHAR;
	    return(FALSE); /* very first char was bad */
    	}
    } /* isComplex else */

    ReleasePtr(filesopen);
    KillPtr(tfp);

    *value = floatf ? retFV : retIV;
    return(TRUE);

} /* ReadNumber */

/* *********************************************************** */

#ifdef NoSuch
ReadNumber(findx,value) /* read next number from file */
/* return FALSE if reach end of file, or if illegal chars */
/* if there are illegal chars, set zreturn to FILECHAR */
int findx;
double *value;
    
{   char s[STRINGLEN];
    char *errM, cc;
    int errN, ii, floatf, isNum;
    double xx, newX;
    long nn, newN;
    int tryHard;

    /* once we have 1 character, we will try hard to get a complete number */

    /* skip initial white space */
    tryHard = FALSE; /* on very first get_char, don't try hard */
    while(TRUE) {
        cc = TUTORget_char(findx,tryHard);
        if (cc == EOF)
            return(FALSE);
        tryHard = TRUE; /* on all subsequent reads, we may try hard to get chars */
        if (cc != ' ' && cc != '\t' && cc != NEWLINE)
            break;
    } /* while */

    /* use first non-white character */
    s[0] = cc;
    ii = 0;

    newN = 0;
    newX = 0.;
    while (TRUE) {
    /* as long as string is still a number, keep reading */
        s[++ii] = 0;
        if (!(isNum = getnum(s, &floatf, &newN, &newX, &errM,&errN)))
            break; /* hit end of number for some reason */
        xx = newX; /* remember valid return */
        nn = newN;
        if (ii > STRINGLEN-2)
            break; /* too many chars to read anymore */
    s[ii] = TUTORget_char(findx,tryHard);
#ifdef IBMPC
    if (s[ii] == RETURN) /* swallow and ignore cr of crlf */
        s[ii] = TUTORget_char(findx,tryHard);
#endif
    if (s[ii] == ' ' || s[ii] == '\t' || s[ii] == NEWLINE) {
        /* seperator, stop */
            ii++; /* so test below (if (!isNum &&...)) will work ok */
            break;
    }
        if (s[ii] == EOF)
            return(FALSE);
    } /* while */
    if (!isNum && s[ii-1] != ' ' && s[ii-1] != '\t' && s[ii-1] != NEWLINE)
        TUTORungetc(findx,s[ii-1]); /* last char (not seperator) was bad */
    /* else if ii > STRINGLEN-2 we must have stopped because number was too long */

    if (ii <= 1) {
        exS.zreturn = FILECHAR;
        return(FALSE); /* very first char was bad */
    }

    *value = floatf ? xx : nn;
    return(TRUE);

} /* ReadNumber */
#endif

/* ********************************************************* */

int FilePath(findex,path) /* return full file path (+name) */
int findex; /* index in file table */
char *path; /* returned */

{	struct tutorfile FAR *tfp; /* pointer in file table */
   
	path[0] = 0; /* pre-set no return */
	tfp = findex+(struct tutorfile FAR *)GetPtr(filesopen);
#ifdef MAC
	MacFilePath(&tfp->fRef,path,CTPATHLEN);
	strcatf(path,tfp->fRef.path);
#else
#ifdef IBMPC
	if ((tfp->fRef.path[0] == '\\') || (tfp->fRef.path[0] == '/')) {
		if (tfp->fRef.drive > 0) {
			path[0] = tfp->fRef.drive+'a'-1; /* attach drive specifier */
			path[1] = ':';
			path[2] = '\0';
		}
		strcat(path,tfp->fRef.path); /* append path to drive */
	} else {
		if (tfp->fRef.path[1] == ':') {
			strcpy(path,tfp->fRef.path); /* full path, with drive */
		} else { /* partial path */
			strcpy(path,currentDirP); /* get current directory */
			strcat(path,tfp->fRef.path); /* append partial path */
		}
	}
#else 
    strcpyf((char FAR *)path,tfp->fRef.path);
#endif /* IBMPC else */
#endif /* MAC else */
    ReleasePtr(filesopen);
  
    return(0);

} /* FilePath */

/* ********************************************************* */
