/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.  */

#include <stdio.h>
#include "execdefs.h"
#include "yacc.h"
#include "eglobals.h"
#include "tglobals.h"
#include "txtv.h"
#include "tfiledef.h"
#include "editor.h"
#include "exprdefs.h"
#include "fkeys.h"
#include "commands.h"

#ifdef ctproto
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,
 int ebsref,struct  _trect *theR,int  relInfo,int  mintw,int  wrap,
 unsigned int  doc,long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),
 int  ro,int  corner,int  erase,int  frame,int tabsz,int lm,int rm,int inhss,int type);
int  TUTORforce_redraw(int  wix);
int arrow_enabled_event(void);
int  cmd_arrow(void);
int  cmd_rarrow(void);
int  cmd_garrow(void);
int  argarrow(int  type);
int  cmd_arrow1(void);
int  cmd_arrow2(void);
int  cmd_arrow3(void);
int  cmd_endarrow(void);
int  cmd_preans(void);
int  cmd_endans(void);
int  cmd_specs(void);
int  cmd_okcmd(void);
int  cmd_nocmd(void);
int  cmd_exact(void);
int  cmd_exactw(void);
int  xexact(int  type);
int  cmd_answer(void);
int  cmd_wrong(void);
int  xanswer(int  type);
int  cmd_ansv(void);
int  cmd_wrongv(void);
int  xansv(int  type);
int  cmd_ifmatch(void);
int  cmd_judge(void);
extern int  arr_undo(int  unitn,unsigned char SHUGE *stackP);
extern int  CreateArrowView(void);
extern int  FindArrowEnd(void);
int  DisplayMarkedArrow(void);
int  ReshowArrow(int  clearF,int  wclear);
int  JudgingInit(void);
int  rejudge(void);
int  showarrow(void);
int  showokno(void);
int  ActivateArrow(int  aFlag);
int  CloseArrow(int  eFlag);
int  ResizeArrowView(int  nc);
int  lclocy(long  q);
int  lclocx(long  q);
long  IntToCoord(int  xx);
int  graph_to_fine(double  gx,double  gy,long  *cx,long  *cy);
int  relative_to_fine(double  rx,double  ry,long  *cx,long  *cy);
unsigned int  TUTORnew_doc(int  string,int  honorP);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int TUTORset_color_rgb(int select,int SysOrPal,double red,double green,double blue);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
int  stacks(long  lvalue);
int  mvar_unref_doc(unsigned int  docH);
int  mvar_assign(struct markvar SHUGE *vaddr,struct  markvar SHUGE *mx);
int  mvar_init(struct  markvar FAR *mp);
int  stackblock(unsigned char  *addr,int  length);
int  ReallocStack(long  newl);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORdealloc(char  FAR *ptr);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
int  markup(struct  sline *ip);
struct  sline *o_pm(unsigned char  FAR *inputst,unsigned char  *pat);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  TUTORclear_doc(unsigned int  doc);
int  DeleteExecMenus(void);
int  set_exec_pt(unsigned int  uloc);
long  get_exec_pt(void);
int  ArrowMenus(void);
int ArrowOkNoMenus(void);
int  dounit(int  unitn,int  loc);
int  ExecMenus(void);
int  TUTORdefault_styles_font_doc(int  font,unsigned int  doc);
int  o_setwordzvars(struct  sline *match);
int  execerr(char  *msgstr);
long  unstacks(void);
int  unstackblock(unsigned char  *addr,int  length);
int  fuzzyle(double  x,double  y);
int  fuzzyge(double  x,double  y);
double  evalduser(struct  markvar FAR *mx);
extern double fabs(double x);
int  evalscore(struct  sline *ip);
int  ReleasePtr(unsigned int  mm);
int  _TUTORmeasure_text_tview(unsigned int  doc,long  pos,struct  _linelay FAR *liLay,int  newP,int  flag,int  info,int  *wUsed,int  *whichSide);
char  FAR *GetPtr(unsigned int  mm);
int  killptr(char  FAR * FAR *ptr);
int  SetSelectPanel(struct  _tvdat FAR *vp,long  pos,long  len);
int  TUTORupdate_tview(unsigned int  theV);
int  TUTORinq_font_info(int  *ascent,int  *descent,int  *maxwidth,int  *leading);
int  TUTORset_textfont(int  jj);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,int ebsref,
 struct  _trect *theR,int  relInfo,int  mintw,int  wrap,unsigned int  doc,
 long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),int  ro,int  corner,
 int  erase,int  frame,int tabsz,int lm,int rm,int inhss,int type);
int  InsureUnit(int  unitn);
int  TUTORdump(char  *s);
int  assign_pfun(long  addr,long  pfunct);
int  items_close(int  unitn,long  stacki,int  vars,int  graphics);
long  FloatToCoord(double  zz);
int  TUTORmove_to(long  x,long  y);
int  RefreshPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  cpos,long  clen,long  newC,long  selStart,long  selLen,int  scroll,int force);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
int  write_abs_text(unsigned int  textDoc,long  startSel,long  endSel,int  xstart,int  ystart,struct  _trect FAR *marginR,int  wrap,int  *maxX,int  *maxY);
int  mvar_temp_cleanup(void);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
int  TUTORset_view(struct  tutorview FAR *vp);
int  TUTORclose_panel(unsigned int  theV);
int  setmode(int  m);
struct  tutorview FAR *TUTORinq_view(void);
int  EncloseRange(unsigned int  doc,long  pl,long  len,unsigned int  style);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
int  TUTORend_line(long  x,long  y);
int  TUTORline_to(long  x,long  y);
#endif /* ctproto */

#ifdef IBMPC
extern char *strcpy(char *aa, char *bb);
#endif

extern long TUTORget_len_doc();
extern Memh TUTORnew_doc();

extern char *strf2n();
extern long l_bin();
extern long l_read();
extern double f_bin();
extern double f_read();
extern long array_addr();
extern  double lcfsysv();
extern  long lcmsysa();
extern  long lcbitcnt();
extern double CoordToFloat();
extern long pass_addr();
extern long get_exec_pt();
extern  int TimedPauseStub();
extern double evalduser();
extern struct sline *o_pm();
extern Memh darrowv(); /* handle on arrow text */
extern Memh dtextv();	/* handle on displayed text */
extern  Coord IntToCoord();
extern  Coord FloatToCoord();
extern  Coord DivCoord();
extern  long TUTORwrite();
extern  long TUTORread();
extern long lcftoi();
extern Memh MakeTextPanel();
extern struct tutorview FAR *TUTORinq_view();
extern long unstacks();

/* ******************************************************************* */

extern int execrun; /* executor run/return flag */

#ifndef long_align
#define long_read(addr) (*(long SHUGE *)(addr))
#define flt_read(addr) (*(double SHUGE *)(addr))
#else
#define long_read(addr) (l_read(addr))
#define flt_read(addr) (f_read(addr))
#endif

/* ------------------------------------------------------------------- */

#define TXT_LTH 1000

extern long txt_count;
extern unsigned char txt_buffer[TXT_LTH];

/* --------------------------------------------------------- */


cmd_arrow() { argarrow(0); } /* -arrow-  command execution */
cmd_rarrow() { argarrow(1); } /* -rarrow- command execution */
cmd_garrow() { argarrow(2); } /* -garrow- command execution */

argarrow(type) /* arrow, rarrow, garrow */
int type; /* 0 = arrow, 1 = rarrow, 2 = garrow */
	
{   int ni, nf;
	long sdepth; /* current stack depth */
	long sinc; /* amount to add to stack */
	int pairf; /* TRUE if pair of co-ordinates, FALSE if single */
	Coord x1,y1,x2,y2,swapc; /* arrow region */
	Memh oldj; /* old judge document */
	struct markvar newj; /* new jbuffer marker */
	struct markvar SHUGE  *mvadr; /* address of marker variable */
	short slop; /* extra margin for arrow when ClipText is FALSE */
	long topuloc; /* uloc of top of arrow */
	int stackc; 
	register struct arrows *arrp;
	
	ni = iresP-istack;
	nf = fresP-fstack;
	iresP = istack; /* void stacks */
	fresP = fstack;
	
    exS.proc_obj_unit = exS.hold_objectH = 0; /* allow button/slider/hot interrupt */
	arrp = &exS.arr;
	exS.uloc = topuloc = get_exec_pt();
	mvadr = (struct markvar SHUGE *)(exS.stackP+sizeof(struct markvar));
	mvar_assign(mvadr,FARNULL); /* pre-clear zarrrowsel */
    if (exS.needredraw) {
        /* force the redraw that the ieu buffered */
        TUTORforce_redraw(exS.baseView->window);
        exS.needredraw = FALSE;
    } 

	/* handle loop back to same arrow */

	if ((exS.execunit == exS.arr.arrowunit) &&
	   (exS.stackpntr == (exS.arr.arrowstack+exS.stackP)) &&
	   (topuloc == exS.arr.arrtopuloc)) {
		stackc = unstacks(); /* look at top item on stack */
		if (stackc == STACK_ARROW) {
#ifdef IBMPC
			exS.stackpntr -= 60; /* remove filler from stack */
#endif
			exS.arr.arrowunit = -1;
			CloseArrow(FALSE); 
		} else stacks((long)stackc); /* restore stack item */
	} /* execunit if */
	
	/* handle nested -arrow-s */

	if (arrp->arrowunit >= 0) { /* stack previous arrow */

		/* compute stack increase needed */
		sinc = sizeof(struct arrows)+4*sizeof(long);
		sdepth = (exS.stackpntr-exS.stackP)+sinc+64L+64L;
		if (sdepth >= exS.stackmalloc) 
			ReallocStack(sdepth); /* insure adequate space */

		/* stack current arrow status */
		oldj = arrp->jbuffer->doc;
#ifdef IBMPC
		exS.arrExtra = ((sinc & (~0x3fL))+0x40)-sinc;
		exS.stackpntr += exS.arrExtra; /* work in multiples of 64 bytes */
#endif
		stacks((long) oldj);
		stacks(arrp->jbuffer->pos);
		stacks(arrp->jbuffer->len);
		stackblock((unsigned char *)&exS.arr,(int)sizeof(struct arrows));
		stacks((long)STACK_ARROW_NEST); 
		ActivateArrow(FALSE); /* make sure previous arrow won't take input */

		/* set up new markers/documents for judge/display buffers */
		mvar_init((struct markvar SHUGE *)&newj);
		mvadr = (struct markvar SHUGE *)exS.stackP;
		mvar_assign(mvadr,(struct markvar SHUGE *)&newj);

		/* prevent clean-up of previous judge/display documents */
		mvar_unref_doc(oldj);
	} else {
#ifdef IBMPC
		exS.stackpntr += 60; /* work in multiples of 64 bytes */
#endif
		stacks((long)STACK_ARROW); /* signal no nesting of arrows */
	}

	/* initialize arr struct */
	arrp->lthand = TUTORhandle("answer ",(long)(256 * sizeof(struct anslist)),TRUE);
	arrp->keyDoc = TUTORnew_doc(TRUE,TRUE);

	arrp->aPanel = 0; /* no arrow text panel yet */
	arrp->aView = FARNULL; /* no arrow view yet */

	arrp->arrowunit = exS.execunit;
	arrp->arrtopuloc = topuloc;
	arrp->arrowstack = exS.stackpntr-exS.stackP;
	arrp->arrowState = 0; /* arrow just starting */

	/* get arrow region co-ordinates */

	x2 = exS.RegionXmax; /* default right/bottom margins */
	y2 = exS.RegionYmax;

	pairf = (ni > 2) || (nf > 2); /* TRUE if region */
	
	if (!pairf && x2 == exS.RegionXmax && y2 == exS.RegionYmax)
		arrp->resizing = TRUE; /* we want resizing view */
	else
		arrp->resizing = FALSE; /* normal case */

	if (type == 0) {
		x1 = istack[0];
		y1 = istack[1];
		if (pairf) {
			x2 = istack[2];
			y2 = istack[3];
		}
	} else if (type == 1) {
		relative_to_fine(fstack[0],fstack[1],&x1,&y1);
		if (pairf)
			relative_to_fine(fstack[2],fstack[3],&x2,&y2);
	} else if (type == 2) {
		graph_to_fine(fstack[0],fstack[1],&x1,&y1);
		if (pairf)
			graph_to_fine(fstack[2],fstack[3],&x2,&y2);
	}

	/* normalize region so x1 < x2, y1 < y2 */
	if (x1 > x2) {
		swapc = x2;
		x2 = x1;
		x1 = swapc;
	}
	if (y1 > y2) {
		swapc = y2;
		y2 = y1;
		y1 = swapc;
	}

	/* -arrow- sets the margins to upper left of arrow & lower right of WINDOW */
	/* it sets current position to upper left of arrow */
	exS.ScreenX = exS.MarginBeginX = arrp->arrowx = x1;  
	exS.ScreenY = exS.MarginBeginY = arrp->arrowy = y1;
	exS.MarginEndX = exS.RegionXmax;
	exS.MarginEndY = exS.RegionYmax;

	arrp->arrowR.left = exS.OffsetX + lclocx(arrp->arrowx+IntToCoord(ARROWOFFSET));
	arrp->arrowR.top = exS.OffsetY + lclocy(arrp->arrowy);
	arrp->arrowR.right = exS.OffsetX + lclocx(x2);
	slop = exS.ClipText ? 0 : (5 + exS.CharHeight);
	arrp->arrowR.bottom = exS.OffsetY + lclocy(y2+IntToCoord(slop));

	arrp->arrowsizex = exS.RXsize;
	arrp->arrowsizey = exS.RYsize;

	arrp->doNormalInput = TRUE;

	/* initialize judge buffer, referred to by author as zarrowm */
	mvar_assign(arrp->jbuffer,FARNULL); /* set zarrowm to zempty */
	mvar_init((struct markvar SHUGE *)&newj);
	mvar_assign(arrp->jbuffer,(struct markvar SHUGE *)&newj);
	
	arrp->arrowFont = exS.baseFont; /* font for arrow is current textfont */
	
	arrp->jbuffer->alteredF = 0;	/* mark judge buffer not altered */
	
	arrp->zntries = 0;
	arrp->bestmatch = NEARNULL;
	o_setwordzvars(arrp->bestmatch); /* initialize zspell etc. */
	if (arrp->iarrowunit > 0)
		dounit(arrp->iarrowunit, 0); /* do -iarrow- unit */

	return(0);
	
} /* argarrow */

/* ------------------------------------------------------------------- */

cmd_arrow1() /* end of post-arrow indents (1st time only) */
	
{	struct arrows *arrp;
	long extraPos;
	
	showarrow();
	arrp = &exS.arr;
	arrp->zjudged = 2;

	TUTORclear_doc(arrp->keyDoc);
	TUTORdefault_styles_font_doc(arrp->arrowFont,arrp->keyDoc);

	/* copy -calc-ed zarrowm */
	if (arrp->jbuffer->len)
		TUTORchange_doc_doc(arrp->keyDoc,0L,0L,0L,0L,arrp->jbuffer->doc,
					arrp->jbuffer->pos,arrp->jbuffer->len,&extraPos,FALSE);

	CreateArrowView();

} /* cmd_arrow1 */

/* ------------------------------------------------------------------- */

cmd_arrow2() /* wait for input at arrow */
	
{	register struct arrows *arrp;
	int eraseuf; /* TRUE if triggered -eraseu- unit */
	
	iresP = istack; /* void stack */
	
	/* we get here on first time thru arrow
		and AFTER ok/no state is cleared */

	eraseuf = FALSE;
	arrp = &exS.arr;
	if (arrp->arrowState == 0) { /* very first time thru indented code */
		/* this code should be in cmd_arrow1, but we want safe get_exec_pt call */
		/* -ifmatch- and -endarrow- locations are on stack.  */
		arrp->arrowuloc = get_exec_pt()-2;
		arrp->ifmatchuloci = istack[0];
		arrp->endarrowuloci = istack[1];
	} else if (arrp->arrowState == 4) {
		/* special handling after a menu unit done while in an ok/no state */
		arrp->arrowState = 3; /* leave in ok/no */
		/* go back and get input to clear ok/no */
		waitflag = atarrow;
		execrun = FALSE; /* exit back to interrupt loop */
		set_exec_pt(exS.arr.arrowuloc); /* when we restart it will be at cmd_arrow2 */
		return(0);
	}

	arrp->ifmatchuloc = arrp->ifmatchuloci; /* initial ifmatch/endarrow settings */
	arrp->endarrowuloc = arrp->endarrowuloci;
	arrp->arrowState = 1; /* accepting normal input */

	if (arrp->zjudged != 2) { /* we're redoing arrow */
		if (exS.arr.eraseuunit) { /* execute -eraseu- unit */
			ExecMenus();
			dounit(exS.arr.eraseuunit,0);
			eraseuf = TRUE; /* triggered eraseu unit */
		}
		arrp->zjudged = 2;
	}
	
	arrp->arrowLastR.left = -1; /* indicates that we have no answer-contingent writing yet */
	
	arrp->aView->caninput = FALSE; /* so it looks like arrow is not active */
	ActivateArrow(TRUE); /* let user enter input */

	if (arrp->doNormalInput) {
		/* stop executing and go back to interrupt loop for input */
		/* this is the usual case */
		waitflag = atarrow;
		if (!eraseuf) /* if eraseu unit, continue execution */
			execrun = FALSE; /* exit back to interrupt loop */
	} else { /* we are handling a click outside the
			arrow view, with touch enabled, that happened when we were in
			an ok/no state (ugh).  Don't get input (by stopping execution),
			just go on to judging */
		arrp->doNormalInput = TRUE; /* put flag back */
	}

	ArrowMenus();
	
} /* cmd_arrow2 */

/* ------------------------------------------------------------------- */

cmd_arrow3()  /* user has finished input, start judging */
	
{
	exS.uloc = get_exec_pt(); /* update execution address */
	
	/* if there aren't any characters and we don't allow blanks, we're not done yet */
	/* but if exS.zkey == KTOUCH, we had enable touch => go on to handle touch */
	if ((TUTORget_len_doc(exS.arr.keyDoc) == 0 && checkbit(exS.inhibbits, INHBLANKS))
			&& !arrow_enabled_event()) {
		/* go back and get some keys */
		execrun = FALSE;
		waitflag = atarrow;
		exS.inOver = TRUE; /* suppress stepping thru this */
		set_exec_pt((unsigned int)(get_exec_pt() - 2)); /* we'll come back here */
		return(0);
	}
	
	exS.inOver = FALSE; /* resume stepping */
	FindArrowEnd();
	ActivateArrow(FALSE); /* don't want any more input */
	exS.arr.arrowState = 2; /* start of judging */
	
	/* get rid of arrow menus */
	ArrowOkNoMenus();

	/* inactivate the arrow view... */

	JudgingInit();
	
	exS.arr.arrowLastR.left = 30000; /* indicates that answer write boundaries not set yet */
	
} /* cmd_arrow3 */

/* ------------------------------------------------------------------- */
static arrow_enabled_event() /* returns TRUE if zkey is an enabled "key" */
{
	int bit;	/* which bit to check */
	
	bit = 1 << (1+exS.zkey-KTOUCH);
	return((exS.enabled & bit) ? TRUE : FALSE);
}

/* ------------------------------------------------------------------- */

cmd_endarrow() /* -endarrow- command execution */
	
{	Memh ddoc;
	long dLen;
	long oldPos, oldLen;
	char FAR *dp;
	struct sline *markdata;
	struct markvar mtmp;
	struct markvar SHUGE *mvadr;
	long extraPos;

	mvadr = (struct markvar SHUGE *)(exS.stackP+sizeof(struct markvar));
	mvar_assign(mvadr,FARNULL); /* decouple zarrrowsel */

	/* clear the arrow view and construct a display document which has answer markup
		and ok/no.  Display it.  The key doc (which is in the view) will be redisplayed
		int cmd_arrow3.
	*/

	/* set up display document */
	TUTORclear_doc(exS.dTextLayout);
	if (exS.arr.bestmatch != 0 && exS.arr.bestscore != 0
			&& exS.arr.zjudged != -1 && !checkbit(exS.arr.specsbits, NOMARK) &&
			!(exS.arr.jbuffer->alteredF & 1)) {
		
		/* do answer markup */
		
		exS.arr.specsbits = exS.arr.bestspecsbits;
		strcpy((char *) exS.arr.Abuffer,(char *) exS.arr.beststring);
		ddoc = exS.arr.jbuffer->doc;
		dLen = TUTORget_len_doc(ddoc);
		if (dLen > 5000)
			dLen = 5000; /* don't judge more than 5000 chars */
		dp = TUTORalloc(dLen+1,TRUE,"pmbuff");
		TUTORget_string_doc(ddoc,0L,dLen,(unsigned char FAR *) dp);
		markdata = o_pm((unsigned char FAR *) dp, exS.arr.Abuffer);
		if (markdata->manfound > 0) /* if some mandatory words found */
			markup(markdata);
		else
			TUTORchange_doc_doc(exS.dTextLayout,0L,0L,0L,0L,exS.arr.keyDoc,
						0L,TUTORget_len_doc(exS.arr.keyDoc),&extraPos,FALSE);
		TUTORdealloc(dp);
	} else
		TUTORchange_doc_doc(exS.dTextLayout,0L,0L,0L,0L,exS.arr.keyDoc,
						0L,TUTORget_len_doc(exS.arr.keyDoc),&extraPos,FALSE);
	
	/* if (exS.arr.zjudged < 2) */
		showokno();

	/* display the display document */
	DisplayMarkedArrow();
	/* restore screen position to where it belongs */
	exS.ScreenX = exS.arr.arrowx + IntToCoord(ARROWOFFSET);
	exS.ScreenY = exS.arr.arrowy+ IntToCoord(3*exS.CharHeight);
	
	if (exS.arr.zjudged == -1 || exS.arr.judged == judgequit) {
	
		/* leave the arrow structure */
		
		CloseArrow(TRUE);

		if (unstacks() == STACK_ARROW_NEST) {
			/* unstack status for nested arrows */
			unstackblock((unsigned char *)&exS.arr,(int)sizeof(struct arrows));

			/* restore zarrowm markers */
			mtmp.len = unstacks();
			mtmp.pos = unstacks();
			mtmp.doc = unstacks();
			mtmp.alteredF = 0;
			mtmp.nextm = mtmp.prevm = -1;
			mtmp.attached = FALSE;
			mtmp.vaddr = -1; /* no variable address */
			mvadr = (struct markvar SHUGE *)exS.stackP;
			mvar_assign(mvadr,(struct markvar SHUGE *)&mtmp);
#ifdef IBMPC
			exS.stackpntr -= exS.arrExtra; /* remove filler */
#endif
			if (exS.arr.arrowState == 1)
				ActivateArrow(TRUE); /* turn the unstacked arrow back on */
		} else {
#ifdef IBMPC
			exS.stackpntr -= 60; /* remove filler */
#endif
			exS.arr.arrowunit = -1; /* popped out of top arrow */
		}
		
		return(0); /* done with -arrow- */
	} /* zjudged if */

	set_exec_pt(exS.arr.arrowuloc); /* when we restart it will be at cmd_arrow2 */
	exS.arr.aView->canclick = TRUE; /* so this view will accept clicks */
	
	exS.arr.arrowState = 3; /* we are in ok/no state */
	waitflag = atarrow;
	execrun = FALSE; /* exit back to interrupt loop */
	return(0);
	
} /* cmd_endarrow */

/* ------------------------------------------------------------------- */

cmd_preans() /* -preans- psuedo command */

{
	iresP = istack; /* void stack */
	if (exS.arr.arrowunit < 0) 
		execerr( "Judging commands need an -arrow-.");
	exS.arr.zanscnt++;
	/* get forward reference to next ans/ifmatch */
	exS.arr.exdentuloc = istack[0]; 
	exS.arr.exdentunit = exS.execunit;
	exS.arr.exdentstack = exS.stackpntr-exS.stackP;

} /* cmd_preans */

/* ------------------------------------------------------------------- */

cmd_endans() /* -endans- psuedo command */

{
	exS.arr.exdentuloc = 0;
	if (exS.arr.zjudged == 2) return(0);

	/* must un-do into arrow unit */

	arr_undo(exS.arr.arrowunit,(exS.arr.arrowstack+exS.stackP));
	set_exec_pt(exS.arr.ifmatchuloc);

} /* cmd_endans */

/* ------------------------------------------------------------------- */

cmd_specs() /* -specs- command execution */

{	int nn;
	int ii;
	int option; /* current inhibit/allow option */

	nn = iresP-istack; /* number items on stack */
	iresP = istack; /* pop stack */

	if (nn == 0) { /* blank tag form */
		exS.arr.specsbits = 0; 
		return(0); /* done with blank tag form */
	} /* nn if */

	ii = 0; /* index in arguments */
	while (ii < nn) { /* loop thru arguments */
		option = istack[ii++];
		if (option == CLEAR) 
			exS.arr.specsbits = 0; 
		 exS.arr.specsbits |= 1 << option;
	} /* while */

} /* cmd_specs */

/* ------------------------------------------------------------------- */

cmd_okcmd() /* -ok- command execution */

{ 	int nn;
	int trvth; /* ct truth value = -1 = true */

	nn = iresP-istack; /* number items on stack */
	iresP = istack; /* pop stack */

	trvth = (nn ? istack[0]: -1);
	if (trvth >= 0) {
		exS.condt_uloc = 0; /* clear conditional command */
		set_exec_pt(exS.arr.exdentuloc); /* ok = false */
	}
	else exS.arr.zjudged = -1; /* ok */

} /* cmd_okcmd */

/* ------------------------------------------------------------------- */

cmd_nocmd() /* -no- command execution */

{ 	int nn;
	int trvth; /* ct truth value = -1 = true */

	nn = iresP-istack; /* number items on stack */
	iresP = istack; /* pop stack */

	trvth = (nn ? istack[0]: -1);
	if (trvth >= 0) {
		exS.condt_uloc = 0; /* clear conditional command */
		set_exec_pt(exS.arr.exdentuloc); /* no = false */
	}
	else exS.arr.zjudged = 1; /* no */

} /* cmd_nocmd */

/* ------------------------------------------------------------------- */

cmd_exact()  { xexact(0); } /* -exact- command execution */
cmd_exactw() { xexact(1); } /* -exactw- command execution */

xexact(type) /* exact and exactw commands */
int type; /* = 0 = exact */
          /* = 1 = exactw */

{	long pos; /* position in arrow input document */
	long len; /* length in arrow input document */
	unsigned char ss[ARROWLIMIT+2]; /* student input */

	if (txt_count >= ARROWLIMIT) txt_count = ARROWLIMIT-1;
	pos = exS.arr.jbuffer->pos;
	len = exS.arr.jbuffer->len;
	if (len >= ARROWLIMIT) len = ARROWLIMIT-1;
	TUTORget_string_doc(exS.arr.jbuffer->doc,pos,len,(unsigned char FAR *) ss);
	if (strcmp((char *) ss,(char *) txt_buffer) == 0) {
		exS.arr.zjudged = (type) ? 0 : -1; 
	} else {
		exS.condt_uloc = 0; /* clear conditional command */
		set_exec_pt(exS.arr.exdentuloc);
	}

} /* xexact */

/* ------------------------------------------------------------------- */

cmd_answer() { xanswer(0); } /* -answer- command execution */
cmd_wrong() { xanswer(1); } /* -wrong- command execution */

xanswer(type) /* answer and wrong commands */
int type; /* = 0 = answer */
          /*   1 = wrong */

{	long pos; /* position in arrow input document */
	long len; /* length in arrow input document */
	struct sline *currmatch; /* status of this match */
	int score; /* score assigned current match */
	char ss[ARROWLIMIT+2]; /* student input */

	if (txt_count >= ARROWLIMIT) {
		txt_count = ARROWLIMIT-1;
		txt_buffer[txt_count] = '\0'; /* insure trailing 0 */
	}
	pos = exS.arr.jbuffer->pos;
	len = exS.arr.jbuffer->len;
	if (len >= ARROWLIMIT) len = ARROWLIMIT-1;
	TUTORget_string_doc(exS.arr.jbuffer->doc,pos,len,(unsigned char FAR *)ss);

 	currmatch = o_pm((unsigned char FAR *) ss,txt_buffer); /* evaluate answer */
	if (currmatch->result) { 

		/* perfect match, as conditioned by -specs- */

		exS.arr.zjudged = (type == 0) ? -1 : 0;
		o_setwordzvars(currmatch);
		exS.arr.bestmatch = currmatch;
		exS.arr.bestspecsbits = exS.arr.specsbits;
		exS.arr.bestscore = 0; 
	} else {
		if ((score = evalscore(currmatch)) < exS.arr.bestscore) { 

			/* imperfect but better match */

			o_setwordzvars(currmatch);
			exS.arr.bestscore = score;
			exS.arr.bestmatch = currmatch;
			exS.arr.bestspecsbits = exS.arr.specsbits;
			exS.arr.bestunit = exS.execunit;
			strcpy((char *) exS.arr.beststring,(char *) txt_buffer); 
		}
		exS.condt_uloc = 0; /* clear conditional command */
        	set_exec_pt(exS.arr.exdentuloc); 
	} /* result else */
     
} /* xanswer */

/* ------------------------------------------------------------------- */

cmd_ansv() { xansv(0); } /* -ansv- command execution */
cmd_wrongv() { xansv(1); } /* -wrongv- command execution */

xansv(type) /* ansv and wrongv commands */
int type; /* = 0 = ansv */
          /*   1 = wrongv */

{	int nn;
	double studentv; /* value of student expression */
	double authorv; /* value of author expression */
	double toler; /* tolerance on author value */

	nn = fresP-fstack; /* number items on stack */
	fresP = fstack; /* pop stacks */
	iresP = istack;

	/* pick up desired result and tolerance */

	authorv = fstack[0];
	if (nn == 1) toler = 0.0;
	else {
		toler = fstack[1];
		if (istack[0]) /* percent tolerance */
			toler = fabs(0.01*authorv*toler);
	}

	/* evaluate student input */

	studentv = evalduser(exS.arr.jbuffer);
	if (exS.zreturn > -1) { /* compute failed */
		exS.condt_uloc = 0; /* clear conditional command */
		set_exec_pt(exS.arr.exdentuloc);
		return(0);
	}

	if (fuzzyge(studentv,authorv-toler) && fuzzyle(studentv,authorv+toler)) {
		exS.arr.zjudged = (type == 0) ? -1 : 0; 
	} else {
		exS.condt_uloc = 0; /* clear conditional command */
		set_exec_pt(exS.arr.exdentuloc);
	}

} /* xansv */

/* ------------------------------------------------------------------- */

cmd_ifmatch() /* -ifmatch- command execution */

{
	iresP = istack; /* void stack */

	/* set so ifmatch branch in body of ifmatch goes to endarrow */
	exS.arr.ifmatchuloc = exS.arr.endarrowuloc; 

	if (exS.arr.zjudged > 1)
		set_exec_pt((unsigned int)istack[0]);

} /* cmd_ifmatch */

/* ------------------------------------------------------------------- */

cmd_judge() /* -judge- command execution */

{
	if (exS.arr.arrowunit < 0) 
		execerr( "Judging commands need an -arrow-.");

	exS.arr.judged = *(--iresP);
	switch (exS.arr.judged) {

	case judgeok: 
		exS.arr.zjudged = -1; 
		break;

	case judgewrong: 
		exS.arr.zjudged = 0; 
		break;

	case judgeno: 
		exS.arr.zjudged = 1; 
		break;

	case judgeunjudge: 
		exS.arr.zjudged = 2; 
		break;

	case judgeexit: 
		exS.arr.zjudged = 2;
		exS.arr.exdentuloc = 0;
		arr_undo(exS.arr.arrowunit,(exS.arr.arrowstack+exS.stackP));
		set_exec_pt(exS.arr.arrowuloc);
		break;

	case judgeignore:
		exS.arr.exdentuloc = 0;
		exS.arr.zjudged = 2; /* unjudged yet */
		ReshowArrow(TRUE,FALSE);
		arr_undo(exS.arr.arrowunit,(exS.arr.arrowstack+exS.stackP));
		set_exec_pt(exS.arr.arrowuloc);
		break;

	case judgequit:
		exS.arr.exdentuloc = 0;
		arr_undo(exS.arr.arrowunit,(exS.arr.arrowstack+exS.stackP));
		set_exec_pt(exS.arr.ifmatchuloc);
		break;

	case judgeokquit: 
		exS.arr.zjudged = -1;
		exS.arr.exdentuloc = 0;
		arr_undo(exS.arr.arrowunit,(exS.arr.arrowstack+exS.stackP));
		set_exec_pt(exS.arr.ifmatchuloc);
		break;

	case judgenoquit: 
		exS.arr.zjudged = 1;
		exS.arr.exdentuloc = 0;
		arr_undo(exS.arr.arrowunit,(exS.arr.arrowstack+exS.stackP));
		set_exec_pt(exS.arr.ifmatchuloc);
		break;

	case judgeexdent: 
		exS.arr.zjudged = 2;
		if (exS.arr.exdentuloc == 0) break;
		arr_undo(exS.arr.exdentunit,(exS.arr.exdentstack+exS.stackP));
		set_exec_pt(exS.arr.exdentuloc);
		exS.arr.exdentuloc = 0;
		break;

	case judgerejudge:
		rejudge(); /* re-initialize judging state */
		exS.arr.zntries = 0;
		if (exS.arr.exdentuloc == 0) break;
		arr_undo(exS.arr.exdentunit,(exS.arr.exdentstack+exS.stackP));
		set_exec_pt(exS.arr.exdentuloc);
		exS.arr.exdentuloc = 0;
		break;

	} /* switch */

} /* cmd_judge */


/* ******************************************************************* */

static arr_undo(unitn, stackP) /* un-do into specified (arrow-related) unit */
int unitn; /* unit number to pop up to */
unsigned char SHUGE *stackP;	/* stack position we want to back up to */

{	int stackc;
        long blockRel; /* relative base of block */

	if (exS.execunit == unitn && exS.stackpntr == stackP) return(0);
	while (exS.execunit != unitn && exS.stackpntr != stackP) {
		stackc = unstacks();
		switch (stackc) {

		case STACK_UNIT:
			unstacks(); /* unit number */
			unstacks(); /* base of lvars */
#ifdef IBMPC
			exS.stackpntr -= 52; /* unit status is 64 bytes on stack */
#endif
			/* close markers, buttons, etc */
			items_close(exS.execunit,exS.lvars,TRUE,TRUE); 
			exS.stackpntr = exS.stackP+exS.lvars; /* unstack locals */
			break;

		case STACK_DO:
			/* close buttons, etc. for current unit */
			items_close(exS.execunit,exS.lvars,TRUE,TRUE); 
			/* unstack previous unit */
			exS.lvars = unstacks(); /* base of lvars for new top unit */
			exS.condt_uloc = unstacks(); /* conditional cmd exit */
			exS.uloc = unstacks(); /* uloc */
			exS.execunit = unstacks(); /* new top unit */
#ifdef IBMPC
			exS.stackpntr -= 44; /* -do- status is 64 bytes on stack */
#endif
			exS.lvarP = exS.stackP+exS.lvars;
			assign_pfun((long)&exs_addr[EXS_LOCALP],(long)exS.lvarP);
			break;	

		default:
			TUTORdump("unexpected stack code in undo");

		} /* switch */
	} /* while */
	if (pcodeh)
		{
		ReleasePtr(pcodeh);
		KillPtr(pcodep);
		}
	pcodeh = 0;
	InsureUnit(exS.execunit); /* insure unit in memory */
	/* set_exec_pt(exS.uloc); -- since all calls to arr_undo do a set_exec_pt */

} /* arr_undo */

/* ******************************************************************* */

static CreateArrowView()  /* set up arrow text panel */
	{
	TRect aRect;
	register struct arrows *arrp;
	TextVDat FAR *vp;
	
	arrp = &exS.arr;
	
	/* make text panel for arrow interaction */
	aRect = arrp->arrowR;
	/* adjust aRect to compensate for margins that MakeTextPanel will introduce */
	aRect.left -= 4;
	aRect.top -= 3;
	aRect.bottom += 3;
	arrp->aPanel = MakeTextPanel(ExecWn,(long) ExecWn,0,0,&aRect,0,0,TRUE,
			arrp->keyDoc,0L, -1L, FALSE,FALSE,FARNULL,FALSE,FALSE,FALSE,FALSE,
			-1,-1,-1,FALSE,2);

	vp = (TextVDat FAR *) GetPtr(arrp->aPanel);
	arrp->aView = vp->view;
	
	if (arrp->resizing)
		{ /* finish setup for resizing */
		int ascent, descent,leading, maxwidth;
		TViewP tvp;
		
		TUTORset_textfont(arrp->arrowFont);
		TUTORinq_font_info(&ascent,&descent,&maxwidth,&leading);
		arrp->charH = ascent + descent + leading;
		if (arrp->charH < exS.newLine)
			arrp->charH = exS.newLine;
		arrp->charW = maxwidth;
		
		tvp = (TViewP) GetPtr(vp->textv);
		tvp->viewRect.right = tvp->viewRect.left; /* no chars yet */
		tvp->viewRect.bottom = tvp->viewRect.top + arrp->charH;
		/* tvp->ld[0].extraInfo = 0; /* no space left, no wrap */
		
		ReleasePtr(vp->textv);
		KillPtr(tvp);
		}

	/* copy mode & color info from executor base view */
	
	TUTORblock_move((char FAR *)&exS.baseView->fgndColor,(char FAR *)&arrp->aView->fgndColor,
					(long)sizeof(struct tutorColor));
	TUTORblock_move((char FAR *)&exS.baseView->bgndColor,(char FAR *)&arrp->aView->bgndColor,
					(long)sizeof(struct tutorColor));
	arrp->aView->CurrentMode = exS.baseView->CurrentMode;
	
	if (arrp->jbuffer->len)
		{ /* there are already characters, show view & set selection */
		if (arrp->resizing)
			ResizeArrowView((int)arrp->jbuffer->len);
		TUTORupdate_tview(vp->textv);
		SetSelectPanel(vp,arrp->jbuffer->len,0L);
		}
	
	ReleasePtr(arrp->aPanel);
	KillPtr(vp);
	
	/* set caninput for baseView to FALSE so that clicks in the base view will
		not change the key focus away from the arrow */
	exS.baseView->caninput = FALSE;

	return(0);
	}

static FindArrowEnd()
	{
	int yy, yline;
	int maxH,lastAsc;
	TextVDat FAR *vp;
	REGISTER TViewP tvp;
	int ii;
	
	vp = (TextVDat FAR *) GetPtr(exS.arr.aPanel);
	tvp = (TViewP) GetPtr(vp->textv);
	/* find top of last line */
	yy = exS.arr.arrowR.top;
	for (ii=tvp->topLine; ii<tvp->botLine; ii++)
		yy += tvp->ld[ii].lineHeight;
	if (tvp->botLine >= 0)
		yline = tvp->ld[tvp->botLine].lineHeight; /* height of last line */
	else
		yline = 10; /* "virtual" line height (see txtv1 - VLINEHEIGHT) */

	/* what is the maximum horizontal extent of view? */
	if (tvp->botLine > 0) /* we have more than 1 line */
		maxH = tvp->destWidth; /* full layout width */
	else if (tvp->botLine == 0) /* we have 1 line */
		maxH = _TUTORmeasure_text_tview(tvp->doc,tvp->layoutTop,&tvp->ld[tvp->topLine],
							TRUE,TRUE,tvp->ld[tvp->topLine].nDraw,NEARNULL,NEARNULL);
	else /* we have no lines */
		maxH = 0;
	
	maxH += tvp->viewRect.left;
	ReleasePtr(vp->textv);
	KillPtr(tvp);
	
	ReleasePtr(exS.arr.aPanel);
	KillPtr(vp);
	
	exS.arr.arrowendx = maxH;
	exS.arr.arrowbottom = yy+yline;
	if (exS.arr.arrowbottom > exS.arr.arrowR.bottom)
		exS.arr.arrowbottom = exS.arr.arrowR.bottom;

	return(0);
	}

DisplayMarkedArrow()	/* display marked up & okno-ed user input */
	{
	register struct arrows *arrp;
	long textLen;
	TRect tr;
	
	arrp = &exS.arr;
	
	/* deactivate arrow view */

	/* erase arrow view */
	tr.left = arrp->arrowR.left;
	tr.top = arrp->arrowR.top+1;
	tr.right = arrp->arrowendx;
	tr.bottom = arrp->arrowbottom;
	TUTORdraw_abs_solid_rect((TRect FAR *) &tr,-1);
	
	textLen = TUTORget_len_doc(exS.dTextLayout);
	if (textLen)
		{ /* we have marked-up text to show */
		
		/* change display document font defaults */
		TUTORdefault_styles_font_doc(arrp->arrowFont,exS.dTextLayout);
		
		write_abs_text(exS.dTextLayout,0L,textLen,arrp->arrowR.left,arrp->arrowR.top+1,&arrp->arrowR,
				TRUE,&arrp->arrowendx,&arrp->arrowbottom);
				/* the top+1 is to match the drawn text to the arrow
						(which is drawn with margins...) */

		/* restore display document font defaults */
		TUTORdefault_styles_font_doc(exS.baseFont,exS.dTextLayout);
		}
	
	return(0);
	}

ReshowArrow(clearF,wclear)
int clearF; /* TRUE if want to clear previous user input */
int wclear;	/* TRUE if we want to clear answer-contingent writing */
	{
	TextVDat FAR *vp;
	register struct arrows *arrp;
	TRect tr;
	long docLen;
	
	arrp = &exS.arr;
	if (clearF)
		{
		docLen = TUTORget_len_doc(arrp->keyDoc); /* remember doc length */
		TUTORclear_doc(arrp->keyDoc);
		}
	
	/* erase arrow view */
	tr.left = arrp->arrowR.left;
	tr.top = arrp->arrowR.top+1;
	tr.right = arrp->arrowendx;
	tr.bottom = arrp->arrowbottom;
	TUTORdraw_abs_solid_rect((TRect FAR *) &tr,-1);

	/* erase answer-contingent writing */
	if (wclear && arrp->arrowLastR.left >= 0 && !checkbit(exS.inhibbits, INHANSERASE) )
		{
		TUTORdraw_abs_solid_rect(&arrp->arrowLastR,PAT_BACKGROUND);
		}

	/* redraw exS.arr.aPanel */
	vp = (TextVDat FAR *) GetPtr(arrp->aPanel);
	if (clearF)
		RefreshPanel(vp,0L,docLen,0L,docLen,0L,0L,0L,FALSE,FALSE);
	else
		TUTORupdate_tview(vp->textv);
	ReleasePtr(arrp->aPanel);
	KillPtr(vp);

	return(0);
	}

/* ******************************************************************* */

JudgingInit() 

{	exS.arr.zntries++;
	exS.arr.arrowLastR.left = -1; /* indicate no text output yet */
	exS.ScreenX = exS.MarginBeginX = exS.arr.arrowx + IntToCoord(ARROWOFFSET);
	exS.ScreenY = exS.MarginBeginY = exS.arr.arrowy+ IntToCoord(3*exS.CharHeight);
	exS.arr.exdentuloc = 0;
	rejudge();
	if (exS.arr.ijudgeunit > 0) dounit(exS.arr.ijudgeunit, 0);
	return(0);

} /* JudgingInit */

/* ******************************************************************* */

rejudge()		/* driven by -judge rejudge- */

{	Memh jdoc;	/* pointer to judge buffer BE document */
	long sl;	/* length of arrow string */
	long extraPos;

	exS.arr.judged = judgeunjudge;
	exS.arr.zjudged = 2; /* unjudged yet */
	exS.arr.zanscnt = 0;
	
	/* replace zarrowm with the contents of keyDoc */
	jdoc = exS.arr.jbuffer->doc;   /* ptrs to judge, display buffs */
	sl = TUTORget_len_doc(exS.arr.keyDoc);
	TUTORchange_doc_doc(jdoc,exS.arr.jbuffer->pos,exS.arr.jbuffer->len,
				exS.arr.jbuffer->pos,exS.arr.jbuffer->len,
				exS.arr.keyDoc,0L,sl,&extraPos,FALSE);
	exS.arr.jbuffer->alteredF = 0;	/* mark judge buffer not altered */
	
	exS.arr.specsbits = 0;
	exS.arr.bestunit = -1;  /* no answer match yet */
	exS.arr.bestmatch = 0;
	exS.arr.bestscore = 100;  /* lower score is better */
	return(0);

} /* rejudge */

/*********************************************/
showarrow() /* draw -arrow- at arrowx, arrowy */
	{
	static int ax[9] = { 0, 1, 6, 1, 0, 0, 3, 0, 0 };
	static int ay[9] = { 2, 2, 7, 12, 12, 10, 7, 4, 2 };
	int i;
	double scale;
	double tempC;
	
	if (checkbit(exS.inhibbits, INHARROW))
		return(0);
	
	scale = exS.CharHeight/12.0;
	tempC = ARROWOFFSET/10.0;

	TUTORmove_to(exS.arr.arrowx+FloatToCoord(ax[0]*tempC), exS.arr.arrowy+FloatToCoord(ay[0]*scale));
	for (i=1; i<=7; i++)
		TUTORline_to(exS.arr.arrowx+FloatToCoord(ax[i]*tempC), exS.arr.arrowy+FloatToCoord(ay[i]*scale));
	TUTORend_line(exS.arr.arrowx+FloatToCoord(ax[8]*tempC), exS.arr.arrowy+FloatToCoord(ay[8]*scale));
	}

/* ******************************************************************* */

showokno() 

{	int x1, y1, x2, y2;
	long pos; /* position of ok/no in document */
	Memh doc;	/* pointer to arrow document */
	char *s;

	if (checkbit(exS.arr.specsbits, NOOKNO)) return(0);
	doc = exS.dTextLayout;

	/* insert ok/no at end of arrow document */

	s = (exS.arr.zjudged == -1) ? "  ok" : "  no";
	pos = TUTORget_len_doc(doc);
	InsertString(doc,pos,(char FAR *) s,4L);
	EncloseRange(doc,pos,4L,0); /* ensure that okno is plain */

} /* showokno */

/* ******************************************************************* */
ActivateArrow(aFlag)	/* make the current arrow active or inactive (don't take any input) */
int aFlag; /* if TRUE make arrow active, FALSE deactivate it */
/* returns arrow state BEFORE call (so restoration can be done properly) */
	{
	register struct arrows *arrp;
	int retVal;
	struct tutorview FAR *curView;

	arrp = &exS.arr;
	if (arrp->aView)
		{ /* we really have arrow */
		retVal = arrp->aView->caninput; /* caninput is TRUE if and only if active */
		if (aFlag != retVal)
			{ /* need to change arrow state */
			curView = TUTORinq_view();
			TUTORset_view(arrp->aView);
			arrp->aView->caninput = aFlag;
			arrp->aView->canclick = aFlag;
			TUTORset_key_focus(ExecWn,aFlag ? arrp->aView : exS.baseView,FALSE);
			if (!aFlag)
				windowsP[ExecWn].MouseFocus = exS.baseView; /* cancel focus on arrow */
			TUTORset_view(curView);
			}
		}
	else
		retVal = FALSE; /* doesn't really mean anything */
	
	return(retVal);
	}

/* ******************************************************************* */

CloseArrow(eFlag)	/* shut down the current arrow */
int eFlag;	/* if TRUE, erase arrow */
	{
	int savemode;
	Coord savex, savey;
	struct tutorwindow FAR *wp;
	struct markvar SHUGE *mvadr;

	mvadr = (struct markvar SHUGE *)(exS.stackP+sizeof(struct markvar));
	mvar_assign(mvadr,FARNULL); /* decouple zarrrowsel */

	if (eFlag)
		{ /* erase the arrow */
		savex = exS.ScreenX; 
		savey = exS.ScreenY;
		savemode = exS.mode;
		setmode(exS.mode = erasemode);
		showarrow();
		exS.ScreenX = savex; 
		exS.ScreenY = savey;
		setmode(exS.mode = savemode);
		}

	/* get rid of arrow text panel */
	if (exS.arr.aView)
		TUTORclose_panel(exS.arr.aPanel); /* close text panel */
	
	exS.baseView->caninput = TRUE; /* so baseView can grab key focus */
	
	TUTORset_view(exS.baseView);
	exS.arr.aPanel = 0;
	exS.arr.aView = FARNULL;
	
	/* make events go to base view */
	wp = windowsP + exS.baseView->window;
	wp->MenuFocus = exS.baseView;
	TUTORset_key_focus(ExecWn,exS.baseView,FALSE);
	wp->MouseFocus = exS.baseView;
	
	/* clean up the other data structures */
	TUTORfree_handle(exS.arr.lthand);
	exS.arr.lthand = 0;
/* 	TUTORclose_doc(exS.arr.keyDoc); */
	mvar_temp_cleanup();
	exS.arr.keyDoc = 0;

	return(0);
	}

ResizeArrowView(nc)
int nc; /* # of additional chars we expect to see */
	{
	TViewP tvp;
	register struct arrows *arrp;
	TextVDat FAR *vp;
	int newH, newV;
	
	/* we want to make sure the view is big enough to handle nc additional chars */
	
	arrp = &exS.arr;
	
	/* figure out where we are now (in arrp->arrowendx & arrowbottom) */
	FindArrowEnd();
	
	/* now figure out what we want bottom-right to be */
	if (arrp->arrowbottom > arrp->arrowR.top + arrp->charH)
		{ /* already below first line */
		newH = arrp->arrowR.right; /* all the way to the right */
		newV = arrp->arrowbottom + arrp->charH;
		}
	else
		{ /* in first line */
		newH = arrp->arrowendx + nc * arrp->charW;
		newV = arrp->arrowR.top + 1 + arrp->charH;
		if (newH > arrp->arrowR.right)
			{ /* we expect to wrap */
			newH = arrp->arrowR.right;
			newV += arrp->charH;
			}
		}
	if (newV > arrp->arrowR.bottom)
		newV = arrp->arrowR.bottom; /* don't go too far */
	
	/* now adjust text view to match our requirements */
	vp = (TextVDat FAR *) GetPtr(arrp->aPanel);
	tvp = (TViewP) GetPtr(vp->textv);
	if (tvp->viewRect.bottom < newV)
		tvp->viewRect.bottom = newV;
	if (tvp->viewRect.right < newH)
		{ /* should only happen when we are working on first line */
		tvp->viewRect.right = newH;
		}
	ReleasePtr(vp->textv);
	KillPtr(tvp);
	ReleasePtr(arrp->aPanel);
	KillPtr(vp);
	
	return(0);
	}
