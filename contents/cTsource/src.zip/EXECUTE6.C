
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University. */

/* graphing & relative coordinate routines */

#include "execdefs.h"
#include "eglobals.h"
#include "tglobals.h"
#include "exprdefs.h"
#include "kglobals.h"

/* ******************************************************************* */

#ifdef ctproto
int  TUTORfill_disk(int type,long xc,long yc,long  x1,long  y1,long  x2,long  y2);
int  TUTORdraw_arc(int  calledby,long xc, long yc, double radius, long  x1,long  y1,
    long  x2,long  y2,double  startAngle,double  stopAngle,int  unbroken);
int cmd_thick(void);
int  cmd_rorigin(void);
extern int checkRadians(void);
int  cmd_size(void);
int  cmd_rotate(void);
int  cmd_gorigin(void);
int  cmd_axes(void);
int  cmd_bounds(void);
int  cmd_rat(void);
int  cmd_gat(void);
int  rgat(int  type);
int  cmd_ratnm(void);
int  cmd_gatnm(void);
int  cmd_rdot(void);
int  cmd_gdot(void);
extern int  rgdot(int  type);
int  cmd_rdraw(void);
int  cmd_gdraw(void);
extern int  rgdraw(int  type);
int  cmd_rfill(void);
int  cmd_gfill(void);
extern int  rgfill(int  type);
int  cmd_rbox(void);
int  cmd_gbox(void);
int  rgbox(int  type);
int  cmd_rvector(void);
int  cmd_gvector(void);
int  rgvector(int  type);
int  cmd_rerase(void);
int  cmd_gerase(void);
int  cmd_rcircle(void);
int  cmd_rcircleb(void);
int  rbcircle(int  type);
int  cmd_gcircle(void);
int  cmd_gcircleb(void);
int  gbcircle(int  type);
int  cmd_gdisk(void);
int  cmd_rdisk(void);
int  cmd_hbar(void);
int  cmd_vbar(void);
int  cmd_scalex(void);
int  cmd_scaley(void);
int  cmd_lscalex(void);
int  cmd_lscaley(void);
int  cmd_labelx(void);
int  cmd_labely(void);
int  cmd_markx(void);
int  cmd_marky(void);
int  cmd_delta(void);
int  cmd_polar(void);
int  relative_to_fine(double  rx,double  ry,long  *cx,long  *cy);
int  graph_to_fine(double  gx,double  gy,long  *cx,long  *cy);
int  execerr(char  *msgstr);
int  axes(void);
extern double cos(double x);
extern double sin(double x);
int  TUTORmove_to(long  x,long  y);
int  TUTORline_to(long  x,long  y);
int  flush(void);
int  TUTORdraw_dot(long  x1,long  y1);
int  rbox(int  tgiven,double  x1,double  y1,double  x2,double  y2,double  thick,int  scaleFirst);
int  gbox(int  tgiven,double  x1,double  y1,double  x2,double  y2,double  thick,int  scaleFirst);
int  TUTORdraw_rectangle(long  x1,long  y1,long  x2,long  y2);
long  IntToCoord(int  xx);
int  rfill(int  npoints,long  *fx,long  *fy);
int  TUTORfill_polygon(int  npoints,long  *fx,long  *fy);
int  TUTORfill_rectangle(long  x1,long  y1,long  x2,long  y2);
int  garc(int  type,long  xcenter,long  ycenter,double  radius,double  angle1,double  angle2,int  unbroken);
int  rarc(int  type,long  xcenter,long  ycenter,double  radius,double  angle1,double  angle2,int  unbroken);
int  setmode(int  m);
int  makevector(long  xtail0,long  ytail0,long  xpoint0,long  ypoint0,double  type);
int  gscale(int  plus,int  neg,double  offset,double  max,double  *scale);
int  vbar(long  tx,long  ty,long  width);
long  FloatToCoord(double  zz);
int  gset_delta(int  axis,int  logflag,int  decades,double  tminor,double  scale,double  delta,double  *width);
int  getlog_maxmin(int  plus,int  neg,double  scale,double  offset,int  *maxlog,int  *minlog);
int  hbar(long  tx,long  ty,long  width);
extern double fabs(double x);
int  glabely(double  majormk,double  minormk,int  ticks,int  precise,int  Ldigits,int  Rdigits,int  labelflag);
int  logmarky(double  majormk,double  minormk,int  ticks,int  precise,int  Ldigits,int  Rdigits,int  labelflag);
int  TUTORset_textfont(int  jj);
int  glabelx(double  majormk,double  minormk,int  ticks,int  precise,int  Ldigits,int  Rdigits,int  labelflag);
int  logmarkx(double  majormk,double  minormk,int  ticks,int  precise,int  Ldigits,int  Rdigits,int  labelflag);
int  glscale(int  plus,int  neg,double  *offset,double  max,double  *scale);
int  gmarky(double  majormk,double  minormk,int  ticks,int  precise,int  Ldigits,int  Rdigits,int  labelflag);
int  gmarkx(double  majormk,double  minormk,int  ticks,int  precise,int  Ldigits,int  Rdigits,int  labelflag);
extern int TUTORline_thick(int thickV);
#endif /* ctproto */

#ifdef macproto
extern int sprintf(char *ss, char *form, ...);
extern int printf(char *form, ...);
#endif

extern long TUTORget_len_doc();
extern long l_bin();
extern long l_read();
extern double f_bin();
extern double f_read();
extern long array_addr();
extern  double lcfsysv();
extern  long lcmsysa();
extern  long lcbitcnt();
extern double CoordToFloat();
extern long pass_addr();
extern long get_exec_pt();
extern  int TimedPauseStub();
extern double evalduser();
extern Memh darrowv(); /* handle on arrow text */
extern Memh dtextv();   /* handle on displayed text */
extern  Coord IntToCoord();
extern  Coord FloatToCoord();
extern  Coord DivCoord();
extern  long TUTORwrite();
extern char FAR *GetPtr();
extern  long TUTORread();
extern long lcftoi();
extern Memh TUTORcopy_handle();
extern long TUTORinq_msec_clock();

/* ******************************************************************* */

extern int execrun; /* executor run/return flag */

/* ------------------------------------------------------------------- */

cmd_thick() /* -thick- command */

{	int nn;

	nn = iresP-istack; /* number arguments */
	iresP = istack; /* void stack */
	
	if (nn == 0) exS.Thick = 0;
	else exS.Thick = istack[0];
	if (exS.Thick <= 1) exS.Thick = 0;
	
	TUTORline_thick(exS.Thick);
	
} /* cmd_thick */

/* ------------------------------------------------------------------- */

cmd_rorigin() /* -rorigin- command */

{
    exS.RYorigin = exS.ScreenY = *(--iresP);
    exS.RXorigin = exS.ScreenX = *(--iresP);

} /* cmd_rorigin */
 
/* ------------------------------------------------------------------- */

cmd_size() /* -size- command execution */

{   register int nn;
    double osize;
    double angle;

    nn = fresP-fstack; /* number items on stack */
    fresP = fstack; /* pop stack */

    osize = exS.RYsize; /* save old y size */
    if (nn == 0) { /* blank tag */
        exS.RXsize = exS.RYsize = 1.0;
    } else if (nn == 1) { /* one-argument */
        exS.RXsize = exS.RYsize = fstack[0];
    } else {
        exS.RXsize = fstack[0];
        exS.RYsize = fstack[1];
    } /* nn else */
    exS.RXsizeFlag = (exS.RXsize != 1.0);
    exS.RYsizeFlag = (exS.RYsize != 1.0);
    if (osize*exS.RYsize < 0.0) { /* y axis flipped */
        exS.RAngle = -exS.RAngle;
        angle = exS.RAngle*RDN;
        exS.RsinAngle = sin(angle);
        exS.RcosAngle = cos(angle); 
    } /* axis flipped if */

} /* cmd_size */

/* ------------------------------------------------------------------- */

cmd_rotate() /* -rotate- command execution */

{   register int nn;
    double angle;

    nn = fresP-fstack; /* number items on stack */
    fresP = fstack; /* pop stack */

    if (nn == 0) { /* no tag */
        exS.RAngle = 0.0;
    } else {
    	if (checkRadians())
    		fstack[0] = fstack[0]/RDN; /* convert to degrees */
        exS.RAngle = fstack[0];
        if (exS.RYsize < 0.0) exS.RAngle = -exS.RAngle;
    } /* nn else */
 
    exS.RAngleFlag = (exS.RAngle != 0.0);
    angle = exS.RAngle*RDN;
    exS.RsinAngle = sin(angle);
    exS.RcosAngle = cos(angle);

} /* cmd_rotate */

/* ------------------------------------------------------------------- */

cmd_gorigin() /* -gorigin- command execution */

{
    exS.GYorigin = exS.ScreenY = *(--iresP);
    exS.GXorigin = exS.ScreenX = *(--iresP);
 
} /* cmd_gorigin */

/* ------------------------------------------------------------------- */

cmd_rat() { rgat(0); } /* -rat- command execution */
cmd_gat() { rgat(1); } /* -gat- command execution */

rgat(type) /* -rat- and -gat- command execution */
int type; /* 0 = rat, 1 = gat */

{   long x1,y1,x2,y2;
    register long tt;
    int ii,nn;

    nn = fresP-fstack; /* number items on stack */
    fresP = fstack; /* pop stack */

    if (type)
        graph_to_fine(fstack[0],fstack[1],&x1,&y1);
    else
        relative_to_fine(fstack[0],fstack[1],&x1,&y1);

    exS.ScreenX = x1; /* set position/left margin */
    exS.ScreenY = y1;
    if (nn == 4) {
        if (type) graph_to_fine(fstack[2],fstack[3],&x2,&y2);
        else relative_to_fine(fstack[2],fstack[3],&x2,&y2);     
    } else {
        x2 = exS.RegionXmax; /* get default right margin */
        y2 = exS.RegionYmax;
    } /* nn else */

    /* adjust so that x1,y1 is upper left of area */

    if (x1 > x2) {
        tt = x1; /* swap x1,x2 */
        x1 = x2;
        x2 = tt;
    }
    if (y1 > y2) {
        tt = y1; /* swap y1,y2 */
        y1 = y2;
        y2 = tt;
    }

    /* set margins */

    exS.MarginBeginX = x1;
    exS.MarginEndX = x2;
    exS.MarginBeginY = y1;
    exS.MarginEndY = y2;
        
} /* rgat */

/* ------------------------------------------------------------------- */

cmd_ratnm() /* -ratnm- command execution */

{
    fresP = fstack; /* pop stack */
    relative_to_fine(fstack[0],fstack[1],&exS.ScreenX,&exS.ScreenY);

} /* cmd_ratnm */

/* ------------------------------------------------------------------- */

cmd_gatnm() /* -gatnm- command execution */

{
    fresP = fstack; /* pop stack */
    graph_to_fine(fstack[0],fstack[1],&exS.ScreenX,&exS.ScreenY);

} /* cmd_gatnm */

/* ------------------------------------------------------------------- */

cmd_rdot() { rgdot(0); } /* -rdot- command execution */
cmd_gdot() { rgdot(1); } /* -gdot- command execution */

static rgdot(type) /* -rdot- and -gdot- command execution */
int type; /* 0 = rdot, 1 = gdot */

{   double xx,yy;
    Coord ix,iy;
    register int ii,nn;

    nn = fresP-fstack; /* number items on stack */
    fresP = fstack; /* pop stack */
    
    for(ii=0; ii<nn; ii += 2) {
        xx = (fstack[ii]);
        yy = (fstack[ii+1]);
        if (!type) relative_to_fine(xx,yy,&ix,&iy);
        else graph_to_fine(xx,yy,&ix,&iy);
        TUTORdraw_dot(ix,iy);
    } /* for */
    exS.ScreenX  = ix;
    exS.ScreenY = iy;
    exS.outcnt += nn;
    OUTGO;

} /* rgdot */

/* ------------------------------------------------------------------- */

cmd_rdraw() { rgdraw(0); } /* -rdraw- command execution */
cmd_gdraw() { rgdraw(1); } /* -gdraw- command execution */

static rgdraw(type) /* -rdraw- and -gdraw- command execution */
int type; /* 0 = rdraw, 1 = gdraw */

{   double xx,yy;
    Coord ix,iy;
    long ox,oy;
    int opt, lastop;
    register int ii,fi,nn;

    nn = (fresP-fstack); /* number items on floating stack */
    fresP = fstack; /* pop floating stack */
    iresP = istack; /* pop integer stack */
    
    ii = fi = lastop = 0;
    while(fi < nn) {
        xx = fstack[fi++];
        yy = fstack[fi++];
        opt = istack[ii++];
        if (!type) relative_to_fine(xx,yy,&ix,&iy);
        else graph_to_fine(xx,yy,&ix,&iy);
        if (opt == TPOINT) {
            if (ii == 1) TUTORmove_to(ix,iy);
            else  {
                if (exS.startdrawcnt > 0) { /* -inhibit startdraw- */
                    exS.startdrawcnt--;
                    TUTORmove_to(ix,iy);
                    opt = -1;
                } else TUTORline_to(ix,iy);
            }
        } else if (opt == TDOT) {
            if (exS.startdrawcnt > 0) { /* -inhibit startdraw- */
                exS.startdrawcnt--;
                TUTORmove_to(ix,iy);
            } else TUTORdraw_dot(ix,iy);
        } else { /* skip */
            if ((exS.mode == xormode) && (lastop == TPOINT)){
                TUTORdraw_dot(ox,oy);
            } /* xor if */
            TUTORmove_to(ix,iy);
        }
        lastop = opt;
        ox = ix;
        oy = iy;
    } /* while */
    if ((exS.mode == xormode) && (lastop == TPOINT)){
        TUTORdraw_dot(ix,iy);
    } /* xor if */
        exS.ScreenX  = ix;
        exS.ScreenY = iy;
        exS.outcnt += nn;
    OUTGO;

} /* rgdraw */

/* ------------------------------------------------------------------- */

cmd_rfill() { rgfill(0); } /* -rfill- command execution */
cmd_gfill() { rgfill(1); } /* -gfill- command execution */

static rgfill(type) /* -rfill- and -gfill- execution */
int type; /* 0 = rfill, 1 = gfill */

{   double xx,yy;
    register int ii,jj,nn;
    Coord fxarray[FILLPOINTS+2]; /* arrays for -fill- */
    Coord fyarray[FILLPOINTS+2];

    nn = fresP-fstack; /* number items on stack */
    fresP = fstack; /* pop stack */
    ii = 0;
    jj = 1;
    while (ii < nn) {
        xx = fstack[ii++];
        yy = fstack[ii++];
        if (type) graph_to_fine(xx,yy,&fxarray[jj],&fyarray[jj]);
        else relative_to_fine(xx,yy,&fxarray[jj],&fyarray[jj]); 
        jj++;
    } /* while */

    if (type) { /* -gfill- */
        if (nn == 4) 
            TUTORfill_rectangle(fxarray[1],fyarray[1],fxarray[2],fyarray[2]);
        else TUTORfill_polygon(jj-1,fxarray,fyarray);
    } else rfill(jj-1,fxarray,fyarray); /* -rfill- */

    exS.ScreenX = fxarray[1];
    exS.ScreenY = fyarray[1];
    exS.outcnt += nn;
    OUTGO;

} /* rgfill */

/* ------------------------------------------------------------------- */

cmd_rbox() { rgbox(0); } /* -rbox- command execution */
cmd_gbox() { rgbox(1); } /* -gbox- command execution */

rgbox(type) /* rbox, gbox command execution */
int type; /* 0 = rbox, 1 = gbox */

{   register int nn;
    double x1,y1,x2,y2;
    double thick;
    int thicks;
    
    nn = fresP-fstack; /* number items on stack */
    fresP = fstack; /* pop stack */

    exS.outcnt += 5;
    if (nn == 0) { /* blank tag form of -gbox-  */
        TUTORdraw_rectangle(exS.GXorigin+IntToCoord(exS.DXneg),
                            exS.GYorigin-IntToCoord(exS.DYneg),
                            exS.GXorigin+IntToCoord(exS.DXplus), 
                            exS.GYorigin-IntToCoord(exS.DYplus));
        return(0);
    } /* nn if */

    x1 = fstack[0];
    y1 = fstack[1];
    x2 = fstack[2];
    y2 = fstack[3];
    if (nn > 4) {
        thick = fstack[4];
        thicks = TRUE; /* thickness explicitly specified */
    } else {
        thick = 1.0;
        thicks = FALSE; /* not explicitly specified */
    }

    if (type) gbox(thicks,x1,y1,x2,y2,thick,1);
    else rbox(thicks,x1,y1,x2,y2,thick,1) ;

    OUTGO;

} /* rgbox */

/* ------------------------------------------------------------------- */

cmd_rvector() { rgvector(0); } /* -rvector- command */
cmd_gvector() { rgvector(1); } /* -gvector- command */

rgvector(type) /* rvector and gvector command execution */
int type; /* 0 = rvector, 1 = gvector */

{   register int nn;
    Coord x1,y1,x2,y2;
    double headsz;

    nn = fresP-fstack; /* number items on stack */
    fresP = fstack; /* pop stack */

    if (nn > 4) headsz = fstack[4];
    else headsz = 0.0;
    
    if (type) {
        graph_to_fine(fstack[0],fstack[1],&x1,&y1);
        graph_to_fine(fstack[2],fstack[3],&x2,&y2);
    } else {
        relative_to_fine(fstack[0],fstack[1],&x1,&y1);
        relative_to_fine(fstack[2],fstack[3],&x2,&y2);
    }
    exS.ScreenX = x1;
    exS.ScreenY = y1;
        
    makevector(x1,y1,x2,y2,headsz);

    exS.outcnt += 5;
    OUTGO;

} /* rgvector */

/* ------------------------------------------------------------------- */

cmd_rerase() /* -rerase- command execution */

{   register int oldmode; /* saved write/erase mode */

    oldmode = exS.mode;
    setmode(erasemode);
    rgfill(0);
    setmode(oldmode);

} /* cmd_rerase */

/* ------------------------------------------------------------------- */

cmd_gerase() /* -gerase- command execution */

{   register int oldmode; /* saved write/erase mode */

    oldmode = exS.mode;
    setmode(erasemode);
    rgfill(1);
    setmode(oldmode);

} /* cmd_gerase */

/* ------------------------------------------------------------------- */

cmd_rcircle()  { rbcircle(1); } /* -rcircle-  command execution */
cmd_rcircleb() { rbcircle(0); } /* -rcircleb- command execution */

rbcircle(type) /* rcircle, rcircleb command execution */
int type; /* 1 = rcircle, 0 = rcircleb */

{   double radius;
    double sangle; /* starting angle */
    double eangle; /* ending angle */
    Coord x1,y1,x2,y2,tt,xradius,yradius;
    int ni; /* number items on integer stack */
    int nf; /* number items on floating stack */

	ni = iresP-istack; /* number items on integer stack */
	iresP = istack;
    nf = fresP-fstack; /* number items on floating stack */
    fresP = fstack; 

	if (istack[0] == 0) { /* radius form */
	
		/* handle radius form */
		
    	radius = fstack[0];
    	if (nf == 1) { /* complete circle */
        	rarc(1,exS.ScreenX,exS.ScreenY,radius,0.0,360.0,type); 
    	} else { /* arc (partial circle) */
    		if (checkRadians()) {
    			fstack[1] = fstack[1]/RDN;
    			fstack[2] = fstack[2]/RDN;
    		}
        	sangle = fstack[1];
        	eangle = fstack[2];
        	rarc(2,exS.ScreenX,exS.ScreenY,radius,sangle,eangle,type); 
    	} /* arc else */
    } else {
    
    	/* handle rectangle form */
  	
        relative_to_fine(fstack[0],fstack[1],&x1,&y1);
        relative_to_fine(fstack[2],fstack[3],&x2,&y2);
    
    	/* adjust so that x1,y1 is upper left of area */

    	if (x1 > x2) {
        	tt = x1; /* swap x1,x2 */
        	x1 = x2;
        	x2 = tt;
    	}
    	if (y1 > y2) {
        	tt = y1; /* swap y1,y2 */
        	y1 = y2;
        	y2 = tt;
    	}
    	xradius = ((x2-x1)/2);
    	yradius = ((y2-y1)/2);
		if ((xradius != yradius) && (exS.RAngle != 0)) 
            execerr("cannot rotate this command");
		exS.ScreenX = x1+xradius;
        exS.ScreenY = y1+yradius;
		TUTORdraw_arc(6,coordZero,coordZero,0.0, 
	              x1, y1, x2, y2, 
		          0.0,0.0,type); 
    }
                
} /* rbcircle */

/* ------------------------------------------------------------------- */

cmd_gcircle() { gbcircle(1); }  /* -gcircle-  command execution */
cmd_gcircleb() { gbcircle(0); } /* -gcircleb- command execution */

gbcircle(type) /* gcircle, gcircleb command execution */
int type; /* 0 = gcircleb, 1 = gcircle */
{   double radius;
    double sangle; /* starting angle */
    double eangle; /* ending angle */
    Coord x1,y1,x2,y2,tt; /* enclosing rectangle */
    int ni;
    int nf; 

	ni = iresP-istack; /* number items on integer stack */
	iresP = istack;
    nf = fresP-fstack; /* number items on floating stack */
    fresP = fstack; 

	if (istack[0] == 0) { /* radius form */
	
		/* handle radius form of command */
		
    	radius = fstack[0];
    	if (nf == 1) { /* complete circle */
        	garc(1,exS.ScreenX,exS.ScreenY,radius,0.0,360.0,type); 
    	} else { /* arc (partial circle) */
    	    if (checkRadians()) {
    			fstack[1] = fstack[1]/RDN;
    			fstack[2] = fstack[2]/RDN;
    		}
        	sangle = fstack[1];
        	eangle = fstack[2];
        	garc(2,exS.ScreenX,exS.ScreenY,radius,sangle,eangle,type); 
    	} /* arc else */
    } else {
    
    	/* handle rectangle form of command */

        graph_to_fine(fstack[0],fstack[1],&x1,&y1);
        graph_to_fine(fstack[2],fstack[3],&x2,&y2);
    
    	/* adjust so that x1,y1 is upper left of area */

    	if (x1 > x2) {
        	tt = x1; /* swap x1,x2 */
        	x1 = x2;
        	x2 = tt;
    	}
    	if (y1 > y2) {
        	tt = y1; /* swap y1,y2 */
        	y1 = y2;
        	y2 = tt;
    	}

		exS.ScreenX = x1+((x2-x1)/2);
        exS.ScreenY = y1+((y2-y1)/2);
		TUTORdraw_arc(5,coordZero,coordZero,0.0, 
	              x1, y1, x2, y2, 
		          0.0,0.0,type); 
    }

} /* gbcircle */

/* ------------------------------------------------------------------- */

cmd_gdisk() /* -gdisk- command execution */

{	Coord x1,y1,x2,y2,tt;

	iresP = istack; /* pop stacks */
	fresP = fstack;
	if (istack[0] == 0) {
    	garc(3,exS.ScreenX,exS.ScreenY,fstack[0],0.0,360.0,1);
    } else { /* rectangle form */
    
    	/* handle rectangle form of command */

        graph_to_fine(fstack[0],fstack[1],&x1,&y1);
        graph_to_fine(fstack[2],fstack[3],&x2,&y2);
    
    	/* adjust so that x1,y1 is upper left of area */

    	if (x1 > x2) {
        	tt = x1; /* swap x1,x2 */
        	x1 = x2;
        	x2 = tt;
    	}
    	if (y1 > y2) {
        	tt = y1; /* swap y1,y2 */
        	y1 = y2;
        	y2 = tt;
    	}

		exS.ScreenX = x1+((x2-x1)/2);
        exS.ScreenY = y1+((y2-y1)/2);
        TUTORfill_disk(1,0,0,x1, y1, x2, y2);
    }
    flush();

} /* cmd_gdisk */

/* ------------------------------------------------------------------- */

cmd_rdisk() /* -rdisk- command execution */

{	Coord x1,y1,x2,y2,tt,xradius,yradius;

	iresP = istack; /* pop stacks */
	fresP = fstack;
	if (istack[0] == 0) { /* radius form */
    	rarc(3,exS.ScreenX,exS.ScreenY,fstack[0],0.0,360.0,1);
    } else { /* rectangle form */
    
       	/* handle rectangle form */
  	
        relative_to_fine(fstack[0],fstack[1],&x1,&y1);
        relative_to_fine(fstack[2],fstack[3],&x2,&y2);
    
    	/* adjust so that x1,y1 is upper left of area */

    	if (x1 > x2) {
        	tt = x1; /* swap x1,x2 */
        	x1 = x2;
        	x2 = tt;
    	}
    	if (y1 > y2) {
        	tt = y1; /* swap y1,y2 */
        	y1 = y2;
        	y2 = tt;
    	}
    	xradius = ((x2-x1)/2);
    	yradius = ((y2-y1)/2);
		if ((xradius != yradius) && (exS.RAngle != 0)) 
            execerr("cannot rotate this command");
		exS.ScreenX = x1+xradius;
        exS.ScreenY = y1+yradius;
    	TUTORfill_disk(1,0,0,x1, y1, x2, y2);
    }
    flush();

} /* cmd_rdisk */

/* ------------------------------------------------------------------- */

cmd_hbar() /* -hbar- command execution */

{   double xx,yy;
    Coord ix,iy,iwidth;
    register int ii,nn;
    int maxlog,minlog;
    double fwidth;

    nn = fresP-fstack; /* number items on stack */
    fresP = fstack; /* pop stack */

    if (exS.GLogYflag)
        getlog_maxmin(exS.DYplus,exS.DYneg,exS.GYscale,exS.GYoffset,
                      &maxlog,&minlog);
    gset_delta(exS.DYplus-exS.DYneg,exS.GLogYflag,maxlog-minlog,
               exS.GminorY,exS.GYscale,exS.GDelta,&fwidth);
    iwidth = FloatToCoord(fwidth);

    ii = 0;
    while(ii < nn) {
        xx = fstack[ii++];
        yy = fstack[ii++];
        graph_to_fine(xx,yy,&ix,&iy);
        hbar(ix,iy,iwidth);
    } /* while */

    exS.ScreenX  = ix;
    exS.ScreenY = iy;
    exS.outcnt += nn;
    OUTGO;

} /* cmd_hbar */

/* ------------------------------------------------------------------- */

cmd_vbar() /* -vbar- command execution */

{   double xx,yy;
    Coord ix,iy,iwidth;
    register int ii,nn;
    int maxlog,minlog;
    double fwidth;

    nn = fresP-fstack; /* number items on stack */
    fresP = fstack; /* pop stack */

    if (exS.GLogXflag)
        getlog_maxmin(exS.DXplus,exS.DXneg,exS.GXscale,exS.GXoffset,
                      &maxlog,&minlog);
    gset_delta(exS.DXplus-exS.DXneg,exS.GLogXflag,maxlog-minlog,
               exS.GminorX,exS.GXscale, exS.GDelta,&fwidth) ;
    iwidth = FloatToCoord(fwidth);

    ii = 0;
    while(ii < nn) {
        xx = fstack[ii++];
        yy = fstack[ii++];
        graph_to_fine(xx,yy,&ix,&iy);
        vbar(ix,iy,iwidth);
    } /* while */

    exS.ScreenX  = ix;
    exS.ScreenY = iy;
    exS.outcnt += nn;
    OUTGO;

} /* cmd_vbar */

/* ------------------------------------------------------------------- */

cmd_scalex() /* -scalex- command execution */

{   register int nn;
    double xmax;

    nn = fresP-fstack; /* number items on stack */
    fresP = fstack; /* pop stack */
    exS.GLogXflag = FALSE;
    xmax = fstack[0];
    exS.GXoffset = ((nn == 2) ? fstack[1] : 0.0);
    gscale(exS.DXplus,exS.DXneg,exS.GXoffset,xmax,&exS.GXscale);

} /* cmd_scalex */

/* ------------------------------------------------------------------- */

cmd_scaley() /* -scaley- command execution */

{   register int nn;
    double ymax;

    nn = fresP-fstack; /* number items on stack */
    fresP = fstack; /* pop stack */
    exS.GLogYflag = FALSE;
    ymax = fstack[0]; 
    exS.GYoffset = ((nn == 2) ? fstack[1] : 0.0);
    gscale(exS.DYplus,exS.DYneg,exS.GYoffset,ymax,&exS.GYscale);

} /* cmd_yscale */

/* ------------------------------------------------------------------- */

cmd_lscalex() /* -lscalex- command execution */

{   register int nn;
    double xmax;

    nn = fresP-fstack; /* number items on stack */
    fresP = fstack; /* pop stack */ 
    exS.GLogXflag = TRUE;
    xmax = fstack[0];
    exS.GXoffset = ((nn == 2) ? fstack[1] : 1.0);
    glscale(exS.DXplus,exS.DXneg,&exS.GXoffset,xmax,&exS.GXscale);

} /* cmd_lscalex */

/* ------------------------------------------------------------------- */

cmd_lscaley() /* -lscaley- command execution */

{   register int nn;
    double ymax;

    nn = fresP-fstack; /* number items on stack */
    fresP = fstack; /* pop stack */
    exS.GLogYflag = TRUE;
    ymax = fstack[0];
    exS.GYoffset = ((nn == 2) ? fstack[1] : 1.0);
    glscale(exS.DYplus,exS.DYneg,&exS.GYoffset,ymax,&exS.GYscale);

} /* cmd_lscaley */

/* ------------------------------------------------------------------- */

cmd_labelx() /* -labelx- command execution */

{   register int inn,fnn;
    double majorx,minorx;
    int ticks,rndoff,dleft,dright;

    inn = iresP-istack; /* number items on integer stack */
    fnn = fresP-fstack; /* number items on floating stack */
    iresP = istack; /* pop stack */
    fresP = fstack;

    minorx = 0.0; /* set defaults */
    ticks = rndoff = dleft = dright = 0;

    majorx = fabs(fstack[0]);
    if (fnn > 1) minorx = fabs(fstack[1]);
    if (inn > 0) ticks = istack[0];
    if (inn > 1) rndoff = istack[1];
    if (inn > 2) dleft = istack[2];
    if (inn > 3) dright = istack[3];

    TUTORset_textfont(exS.baseFont);
    if ((majorx != 0) && ((exS.DXplus != 0) || (exS.DXneg != 0))) {
        if (exS.GLogXflag) {
            logmarkx(majorx,minorx,ticks,rndoff,dleft,dright,1);
            exS.GminorX = 0.0;  
        } else {
            glabelx(majorx,minorx,ticks,rndoff,dleft,dright,1);
            exS.GminorX = minorx;    
        } /* GLogXflag else */
        flush(); 
    } /* majorx if */

} /* cmd_labelx */

/* ------------------------------------------------------------------- */

cmd_labely() /* -labely- command execution */

{   register int inn,fnn;
    double majory,minory;
    int ticks,rndoff,dleft,dright;

    inn = iresP-istack; /* number items on integer stack */
    fnn = fresP-fstack; /* number items on floating stack */
    iresP = istack; /* pop stack */
    fresP = fstack;

    minory = 0.0; /* set defaults */
    ticks = rndoff = dleft = dright = 0;

    majory = fabs(fstack[0]);
    if (fnn > 1) minory = fabs(fstack[1]);
    if (inn > 0) ticks = istack[0];
    if (inn > 1) rndoff = istack[1];
    if (inn > 2) dleft = istack[2];
    if (inn > 3) dright = istack[3];

    TUTORset_textfont(exS.baseFont);
    if ((majory != 0) &&((exS.DYplus != 0) || (exS.DYneg != 0))) {
        if (exS.GLogYflag) {
            logmarky(majory,minory,ticks,rndoff,dleft,dright,1);
            exS.GminorY = 0.0;  
        } else {
            glabely(majory,minory,ticks,rndoff,dleft,dright,1);
            exS.GminorY = minory;   
        } /* GLogYlag */
    } /* majory */

} /* cmd_labely */

/* ------------------------------------------------------------------- */

cmd_markx() /* -markx- command execution */

{   register int inn,fnn;
    double majorx,minorx;
    int ticks,precise;

    inn = iresP-istack; /* number items on integer stack */
    fnn = fresP-fstack; /* number items on floating stack */
    iresP = istack; /* pop stack */
    fresP = fstack;

    minorx = 0.0; /* set defaults */
    ticks = precise = 0;

    majorx = fabs(fstack[0]);
    if (fnn > 1) minorx = fabs(fstack[1]);
    if (inn > 0) ticks = istack[0];
    if (inn > 1) precise = istack[1];
    if ((majorx != 0.0) &&((exS.DYplus != 0) || (exS.DYneg != 0))) {
        if (exS.GLogYflag) {
            logmarkx(majorx,minorx,ticks,precise,0,0,0);
                        /* 0's in positions 5 & 6 are placeholders only */
            exS.GminorX = 0.0 ;  
        } else {
            gmarkx(majorx,minorx,ticks,precise,0,0,0);  
            exS.GminorX = minorx;   
        } /* GLogYflag else */
    } /* majorx if */

} /* cmd_markx */

/* ------------------------------------------------------------------- */

cmd_marky() /* -marky- command execution */

{   register int inn,fnn;
    double majory,minory;
    int ticks,precise;

    inn = iresP-istack; /* number items on integer stack */
    fnn = fresP-fstack; /* number items on floating stack */
    iresP = istack; /* pop stack */
    fresP = fstack;

    minory = 0.0; /* set defaults */
    ticks = precise = 0;

    majory = fabs(fstack[0]);
    if (fnn > 1) minory = fabs(fstack[1]);
    if (inn > 0) ticks = istack[0];
    if (inn > 1) precise = istack[1];
    if ((majory != 0) &&((exS.DXplus != 0) || (exS.DXneg != 0))) {
        if (exS.GLogXflag) { 
            logmarky(majory,minory,ticks,precise,0,0,0);
            exS.GminorY = 0.0 ;  
        } else {
            gmarky(majory,minory,ticks,precise,0,0,0); 
            exS.GminorY = minory;  
        } /* GLogXflag else */
    } /* majory if */

} /* cmd_marky */

/* ------------------------------------------------------------------- */

cmd_delta() /* -delta- command execution */

{
    exS.GDelta = *(--fresP);

} /* cmd_delta */

/* ------------------------------------------------------------------- */

cmd_polar() /* -polar- command execution */

{   register int nn;
    
    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* pop stack */

    if (nn == 0) { /* blank tag form */
        exS.GPolar = FALSE;
        return(0);
    } /* nn if */

    if (istack[0] >= 0 ) {
        exS.GPolar = FALSE; 
    } else {
        exS.GPolar = TRUE;
        exS.GLogXflag = exS.GLogYflag = FALSE; 
        exS.GXoffset = exS.GYoffset = 0; 
    } /* else */

} /* cmd_polar */

