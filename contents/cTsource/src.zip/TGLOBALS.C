
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Declarations for general globals
KSW 9/88
*/

#include "baseenv.h"
#include "tglobals.h"
#ifndef _computeh
#include "compute.h"
#endif

#ifdef ctproto
#endif /* ctproto */

Coord coordZero, coordOne; /* frequently used constants */
double Infinite; /* 1/0 */
double Indefinite; /* 0/0 */
Memh filesopen = 0; /* info about open files */
unsigned filesmalloc; /* number of items malloc-ed */
int ctedit; /* TRUE if editor present */
int ctcomp; /* TRUE if compiler present */
struct tutorwindow FAR *windowsP = FARNULL;    /* table of windows */
Memh fontsH; /* table of active fonts */
int ExactMatchFont; /* TRUE if font matched exactly */
int isx11;  /* TRUE if running on X11 */
int nosourcelayout; /* TRUE if source not displayed */
int binaryOnly; /* TRUE if executor with binary file only */
int logevents; /* TRUE if logging events */
int playevents; /* TRUE if re-playing logged events */
int CompileAndExit; /* TRUE if should compile program and exit */

#ifdef DOPSCRIPT
char pscript;   /* TRUE if generating PostScript */
char *PSbuff;  /* buffer for postscript output */
char PostscriptFlag; /* TRUE if -p option active */
#endif

int pictur_id = 0; /* unique id for picture */

char NewFontSize; /* TRUE if font size means newline.y, else top of Y to bottom of y */
int nevents;    /* number events currently queued */

int ctmouse;    /* TRUE if mouse present */
int ctexec; /* TRUE if executor present */

/* scratch FAR variables: (tempS & tempR needed by executor) */
char FAR *tempFarS;
long FAR *tempFarL;
int FAR *tempFari;
unsigned int FAR *tempFarUi;
TRect FAR *tempFarR;

short textFont0; /* index to default textFONT */
short cursorFont0, cursorChar0; /* default cursor */
short patternFont0, patternChar0; /* default fill */
short iconFont0; /* default icon font */

long gvaraddr; /* location of end of global vars */
int gvarzero;   /* TRUE if global variables must be zeroed */

Memh firstSetH; /* handle on first define set in chain */
Memh lastSetH; /* handle on last define set in chain */
Memh oldSetH; /* handle on old chain of define sets */
Memh globalSetH; /* handle on current global define set  */
Memh userSetH; /* handle on current local define set */
Memh localSetH; /* handle on local define set */
Memh wkSetH; /* handle on define set being compiled */
struct defset FAR *wkSetP; /* pointer to currently compiling */
Memh oldDescH; /* handle on previous array descriptors */

int userdefstart, ndefuservars; /* delimit user defs in gvar table */
struct sourcefile FAR *sourcetable; /* table of source file names/pointers */

short modalW;   /* index of window that has modal state, or -1 if we are not in a modal state */

int ExecWn; /* executor window number */
struct tutorview FAR *ExecVp;   /* executor main view pointer */
int CurEditWi = -1; /* index of currently active editor window */
int EditWn[EDITWINDOWLIMIT];    /* edit window number */
struct tutorview FAR *EditVp[EDITWINDOWLIMIT];  /* edit main view pointer */
int timeflag; /* TRUE if timing in effect (timed pause or EnqueueEvent */
int tfilerr; /* >0 if error in file operation */
int ctutv;      /* cmututor version number */
Memh xtH; /* handle on operators/operands description table */
struct exprt FAR *xtP; /* ptr to operators/operands description table */
unsigned char FAR *cmd_err_tab; /* TRUE if command can generate exec err */
int userExp; /*  0 = regular run-time author expression */
             /*  1 = -compute- or debug */
             /* -1 = compile-time phase of -compute- or debug */

FileRef FAR *sourceDirP;  /* directory where source file (either main .t file, or main binary) is found */
FileRef FAR *ctDirP = FARNULL;  /* directory where cT files can be found */
FileRef FAR *currentDirP = FARNULL; /* current working directory */

Memh descH; /* array/argument descriptors */
char FAR *descP; /* pointer to array/argument descriptors */
Memh textpool;  /* styled text and strings */
int allcompiled;    /* true if program completely compiled */
int compunit;  /* unit now being compiled */
long srcPos; /* position in current source document */
int seekcmd;    /* last command found by Seekunit */
/* variables set in FillBuffer */
Memh lastBufferDoc = 0;
long nextBufferPos = -1L;
/* runflag is current run state, rerunflag is how we started running */
/* waitflag is current wait state (or equal to runflag if running) */
char runflag, rerunflag, waitflag;
Memh unittabH; /* handle on unit table */
struct unitinfo FAR *unittab; /* info and binaries for the units */
int nunits;  /* current number of units */
Memh cmpH; /* handle on unit compilation buffer */
char cmpLocked; /* flag indicating whether cmpH is believed locked */
Memh pcodeh;    /* handle on pcodes for current unit */
unsigned char FAR *pcodep; /* pointer to pcodes */
jmp_buf uenv; /* expression/compute error longjmp */
unsigned char FAR *cbody;   /* pointer to base of expression */
unsigned char FAR *bin;  /* byte address in binary document */
unsigned char FAR *cbase;   /* pointer to first byte of expression */
unsigned char FAR *cmpbuf;  /* pointer to unit compilation buffer */
unsigned int cmpl;  /* position within compilation buffer */
int seedrand; /* seed for random number generator */
Memh refhead; /* head of (marker) document-referenced chain */
int refnum; /* number entries in document-referenced chain */

long maxSwapLen = 1000L * 1000L; /* size of swap file */
char useXMS = 0; /* use XMS memory on PC */
char useEMS = 0; /* use EMS memory on PC */
char pcoldcolor = 0; /* use old color defaults on PC */
char color_pref = 0; /* TRUE if color preferences in effect */
char useNativeChars = 0; /* TRUE if no character code conversions */

int SysFontHeight = 0; /* height of default (system) font */
int SysFontWidth = 0; /* width of default (system) font */
int SysPal; /* size of hardware display palette (0 = TrueColor/no color) */
int SysColors; /* number colors set up by system */
