
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/


/* Part of the TUTORgraphics package for cT */

#include "baseenv.h"
#include "tglobals.h"
#include "kglobals.h"
#include "txt.h"
#include "kdefs.h"
#include "ct_ctype.h"
#include "compute.h"
#include "eglobals.h"


#ifdef ctproto
extern int PaletteMatch(struct CTcolorentry FAR *paletteP,int nColors,
           unsigned int redC,unsigned int greenC,unsigned int blueC);
extern int TUTORfree_palette(Memh palH);
extern Memh TUTORalloc_palette(int pSlots);
long  TUTORget_hsize(unsigned int  mm);
extern int TUTORpalettize_rgb(int type,unsigned char FAR *pixelsP,long inRow,
	   unsigned char FAR *outP,long outRow,Memh paletteH,int width,int height);
extern void TUTORset_color(int select,struct tutorColor FAR *newColor);
extern double TUTORdouble_click_time(void);
extern int TUTORset_sub_new(int sub,int new);
int TUTORset_color_rgb(int select,int SysOrPal,double red,double green,double blue);
extern int TUTORzero(char SHUGE *ptr,long len);
extern int TUTORdeferred_dealloc(char FAR *ptr);
extern int TUTORline_thick(int thickV);
extern int DummyFontID(void);
extern int TUTORrelease_font(int findx,long fam,int size,unsigned int face,int forget);
int TUTORinq_icon_code_size(int famN);
long  IntToCoord(int  xx);
int  TUTORset_window(int  wid);
int  TUTORclear_window(int  wid);
int  FindWindowByType(int  type);
struct  tutorview FAR *TUTORinit_view(int  sW,unsigned int  vDat,int  (*vProc)());
int  TUTORset_view(struct  tutorview FAR *vp);
int  TUTORclose_view(struct  tutorview FAR *vp);
int  TUTORuse_rel_rect(struct  _trect FAR *rRect,int  inf,struct  tutorview FAR *viewP,struct  _trect *sRect);
int  TUTORmake_rel_rect(struct  tutorview FAR *viewP,struct  _trect *theR,int  inf,struct  _trect *relR);
int  TUTORintersect_rect(struct  _trect FAR *r1,struct  _trect FAR *r2,struct  _trect FAR *rdest);
int  TUTORdouble_click(short  *hh,short  *vv);
int  TUTORcompose_char(unsigned char  *cCompose);
int  GetCompose(int  code,char  *tempS);
int  CancelTrigger(int  id);
int  ClearExecTiming(void);
int  OrderRect(struct  _trect FAR *rp);
int  TUTORset_fill(int  fInd,int  fChar);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
int  TUTORset_abs_view_rect(int  x1,int  y1,int  w,int  h);
int  TUTORpost_event(struct  tutorevent *event);
int  TUTORpush_event(struct  tutorevent *event);
int  TUTORcompress_events(void);
int  TUTORmessage(struct  tutorview FAR *vp,int  eKind,int  eVal);
int  TUTORcancel_all_events(void);
int  TUTORget_font2(long  fam,int  size,unsigned int  face,int cid);
int  FontFamilyIndex(long id);
int  TUTORinq_font_descr(int  fontN,long *fam,int  *siz,int  *fac);
int  TUTORcvt_text_size(int  fid,int  defSz,int  sz);
int  TUTORabs_line(int  hh,int  vv);
int  TUTORunset_clip_rectangle(void);
int  TUTORinq_window(void);
struct  tutorview FAR *TUTORinq_view(void);
int  TUTORinq_event_mask(int  wid,int  eventc);
int  TUTORinq_abs_clip_rect(struct  _trect *cr);
int  TUTORclip_window(int  wid);
int  TUTORinq_comb_rule(void);
int  CTmap_color(int  wn,int  cn,int  foreFlag);
int  CTset_window_color(int  cn);
int  TUTORget_colors(struct tutorColor *fcx,struct tutorColor *bcx,struct tutorColor *wcx);
extern int TUTORinq_foreground_color(struct tutorColor *fc);
int  TUTORinq_background_color(struct tutorColor *bc);
int  CTisascii(int  cc);
int  CTislower(int  cc);
int  CTisupper(int  cc);
int  CTtolower(int  cc);
int  CTtoupper(int  cc);
double  lcitof(long  iv);
long  lcftoi(double  dv);
double  lcfcoord(double  dv);
int  postscript_header(void);
int  PostscriptDefaultScreen(void);
int  PostSriptOutput(char  *PSbuff);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  TUTORframe_window(int  wid);
int  TUTORset_abs_clip_rect(struct  _trect FAR *cr);
int  TUTORclear_screen(void);
int  TUTORselect_window(int  wix);
int  TUTORdump(char  *s);
int  TUTORflush(void);
int  TUTORdealloc(char  FAR *ptr);
int  CTset_background_color(int  color);
int  CTset_foreground_color(int  color);
int  TUTORset_comb_rule(int  rule);
int  TUTORabs_move_to(int  x,int  y);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORfree_event_memory(struct  tutorevent FAR *event);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
long  TUTORinq_msec_clock(void);
int  CTmap_default_color(int  cn);
int  TUTORabs_line_to(int  x,int  y);
int  TUTORfont_ptr(int  fInd,int  size,unsigned int  face,int cid);
extern double floor(double x);
#endif /* ctproto */

#ifdef macproto
extern int printf(char *, ...);
extern int sprintf(char *, char *, ...);
extern int sscanf(char *ss, char *form, ...);
extern int MacMinColors(void);
#endif

#ifdef WINPC
extern double win_double_click(void);
#endif

extern long lcftoi();
extern double lcitof();
extern long TUTORget_hsize();
extern double floor();
extern double TUTORdouble_click_time();
extern void TUTORset_color();

struct keywdinf *GetComposeFKey();
extern struct tutorview FAR *TUTORinq_view();
extern  struct tutorview FAR *TUTORinit_view();
extern int DummyFontID();

int eventid;    /* unique (incrementing) id */

static long repbase = 0; /* base time for event replay option */
static long repstart;  /* time replay began */
static struct tutorevent playev; /* event currently waiting to replay */

char *kZsans   = "zsans";
char *kZserif  = "zserif";
char *kZfixed  = "zfixed";
char *kZsymbol = "zsymbol";

/* ******************************************************************* */

Coord IntToCoord(xx)
int xx;

{
    return(((long) xx) << 16);
}

/* ******************************************************* */

TUTORset_window(wid)    /* set to specified window */
int wid;    /* index of window */

{   register struct tutorwindow FAR *wp;

    if (CurrentWindow == wid) return 0;

    /* save status for present window */

    if (CurrentWindow >= 0) {
        wp = &windowsP[CurrentWindow];
        if (wp->type != EXECW)
            TUTORflush(); /* flush output to current window */
        wp->FontIndex = textFont;
    } /* CurrentWindow if */
    CurrentWindow = wid;
	if (CurrentWindow < 0)
		return;
		
    if (windowsP[wid].wp == 0) /* windows need to be created with TUTORcreate_window */
	TUTORdump("ctgraph 1");

    /* set up for this window */
  
    CurrentPaletteSize = windowsP[wid].paletteSize;
    TUTORselect_window(wid);

} /* TUTORset_window */

/* ****************************************************** */

int TUTORclear_window(wid)
int wid;

{   struct tutorview FAR *cv;
    int cx1, cy1, cx2, cy2;
    TRect cr;

    cv = TUTORinq_view(); /* get current view */
    TUTORset_view(windowsP[wid].firstView); /* some view in window */

    /* want to temporarily reset clip region to take up whole window */
    TUTORinq_abs_clip_rect(&cr);
    TUTORclip_window(wid);

    /* clear window */
    TUTORclear_screen();

    /* restore clip region & view */
    TUTORset_abs_clip_rect((TRect FAR *) &cr);
    TUTORframe_window(wid); /* draw exterior frame */
    TUTORset_view(cv);

    return 0;

} /* TUTORclear_window */

/* ****************************************************** */

int FindWindowByType(type) /* get window index based on window type */
int type; /* type we are looking for */
    {
    int ii;

    for (ii=0; ii < WINDOWLIMIT; ii++)
        if (windowsP[ii].type == type && windowsP[ii].wp)
            return(ii);

    return(-1); /* failure! */
    }

/* ********************************************************* */

static int vrefc = 0; /* unique identifier for view */

struct tutorview FAR *TUTORinit_view(sW,vDat,vProc) /* create and initialize a view */
int sW; /* window index of view */
Memh vDat; /* data structure of view */
#ifdef THINKC5
int (*vProc)(...); /* procedure for new view */
#else
int (*vProc)(); /* procedure for new view */
#endif

/* returns view pointer, or FARNULL for failure */
    
{   int newView; /* index of the new view */
    register struct tutorview FAR *nv;
    register struct tutorwindow FAR *wp;

    nv = (struct tutorview FAR *) TUTORalloc((long) sizeof(struct tutorview),TRUE,"tutrview");
    TUTORzero((char SHUGE *)nv,(long)sizeof(struct tutorview));
    wp = windowsP + sW;
    if (!wp->firstView) { /* this is first view */
        wp->firstView = nv;
        wp->lastView = nv;
        nv->nextView = FARNULL;
    }
    else { /* additional view, put it in front */
        nv->nextView = wp->firstView;
        (wp->firstView)->prevView = nv;
        wp->firstView = nv;
    }
    nv->prevView = FARNULL; /* no previous view */
    nv->objectH = nv->objectT = 0; /* no edit/slider/button object */
    nv->refc = ++vrefc;
    nv->window = sW;
    nv->caninput = TRUE; /* the usual case */
    nv->canclick = TRUE;
    nv->dialogV = FALSE;
    nv->vh = vDat;
    nv->vproc = vProc;
    nv->rr.left = nv->clipr.left = nv->rr.top = nv->clipr.top = 0;
    nv->rr.right = nv->clipr.right = wp->wxsize-1;
    nv->rr.bottom = nv->clipr.bottom = wp->wysize-1;
    nv->RealX = nv->RealY = 0;
    nv->CurrentMode = SRC_OR;
    nv->SpaceShim = nv->lineThick = 0;
    nv->tabSize = -1; /* default, probably from document */
    nv->SupSub = -1; /* default */
    nv->newlineH = 0;
    if (windowsP[nv->window].type != EXECW)
        { /* honor user preferences */
        nv->fgndColor.palette = prfP->fcolor; /* default foreground color */
        nv->bgndColor.palette = prfP->bcolor; /* default background color */
        nv->winColor.palette = prfP->bcolor; /* default background color */
        }
    else
        { /* for executor window cT sets colors */
        nv->fgndColor.palette = color_defaultf;
        nv->bgndColor.palette = nv->winColor.palette = color_defaultb;
        }
    
    return(nv);

} /* TUTORinit_view */

/* ******************************************************** */

TUTORset_view(vp)   /* set to specified view */
register struct tutorview FAR *vp;  /* pointer to view */

{   int i;
    register struct tutorview FAR *cvp;

    if (vp) {
        if ((CurrentView == vp) && (vp->window == CurrentWindow)) {
        return 0; /* exit if nothing to do */
        } /* CurrentView if */
    } /* vid if */

    if (CurrentView) { /* save status for present view */
        cvp = CurrentView;
        cvp->RealX = RealX;
        cvp->RealY = RealY;
        cvp->CurrentMode = CurrentMode;     
        cvp->SpaceShim = SpaceShim;
        cvp->clipr.left = tgclipx;
        cvp->clipr.top = tgclipy;
        cvp->clipr.right = tgclipx+tgclipw - 1;
        cvp->clipr.bottom = tgclipy+tgcliph - 1;
        TUTORblock_move((char FAR *)&fgndColor,(char FAR *)&cvp->fgndColor,
                        (long)sizeof(struct tutorColor));
        TUTORblock_move((char FAR *)&bgndColor,(char FAR *)&cvp->bgndColor,
                        (long)sizeof(struct tutorColor));
        TUTORblock_move((char FAR *)&winColor,(char FAR *)&cvp->winColor,
                        (long)sizeof(struct tutorColor));
        cvp->lineThick = lineThick;
    } /* CurrentView if */

    /* handle switch to no-view */

    CurrentView = vp; 
    if (!vp) {    
    	CurrentMode = -1; /* unset mode */
    	textFont = -1; /* unset font */
    	return 0; /* exit if not changing to new view */      
    }

    /* set to correct window for this view */

    if (CurrentWindow != vp->window)
        TUTORset_window(vp->window);

    /* set up general status for this view */

    if ((RealX != vp->RealX) || (RealY != vp->RealY))
        TUTORabs_move_to(vp->RealX,vp->RealY);
    TUTORset_abs_clip_rect(&vp->clipr);
    if (CurrentMode != vp->CurrentMode)
        TUTORset_comb_rule(vp->CurrentMode);
    /* guarantee that colors are set */
    fgndColor.palette = bgndColor.palette = winColor.palette = -4; 
    TUTORset_color(0,&vp->fgndColor);
    TUTORset_color(1,&vp->bgndColor);
    TUTORset_color(2,&vp->winColor);
    TUTORline_thick(vp->lineThick); /* set line thickness */
    TUTORset_sub_new(vp->SupSub,vp->newlineH);
    
} /* TUTORset_view */

/* ********************************************************* */

TUTORclose_view(vp)
register struct tutorview FAR *vp; /* pointer to view to close */
    {
    struct tutorevent cev;
    register struct tutorwindow FAR *wp;
    struct tutorevent FAR *evp;
    int wix;
    int ii;

    /* tell view it should shut down */
    
    cev.view = vp;
    cev.window = wix = vp->window;
    cev.type = EVENT_DESTROY;
    TUTORset_view(vp);
    (*vp->vproc) (vp->vh,&cev);

    wp = windowsP + vp->window;

    /* take view out of view chain in window */
    /* because of this code views shouldn't depend on the window's view chain when
        they are closed */
    if (!vp->prevView) /* this is the first view in window */
        wp->firstView= vp->nextView;
    else
        vp->prevView->nextView = vp->nextView;
    if (vp->nextView)
        vp->nextView->prevView = vp->prevView;
    if (wp->lastView == vp)
        wp->lastView = vp->prevView;

    /* destroy any events in the event queue bound for the closed view */
    evp = eventque;
    for (ii=0; ii<nevents; ii++, evp++) {
        if (evp->view == vp) {
            evp->type = -1; /* kill event */
        }
    }
    evp = (struct tutorevent FAR *) GetPtr(timeque);
    for(ii = 0; ii < ntiming; ii++, evp++) {
        if (evp->view == vp) {
            evp->type = -1; /* kill event */
        }
    }
    ReleasePtr(timeque);
    KillPtr(evp);
    
    /* vp is gone, set view to nothing */
    CurrentView = FARNULL;
    TUTORset_view(FARNULL);
    if (wp->MenuFocus == vp)
        wp->MenuFocus = FARNULL;
    if (wp->KeyFocus == vp)
        wp->KeyFocus = FARNULL;
    if (wp->MouseFocus == vp)
        wp->MouseFocus = FARNULL;
#ifndef CTEDIT
    if ((wix == ExecWn) && (vp != ExecVp) && (wp->MouseFocus == FARNULL)) /* executor reverts to base view */
        wp->MouseFocus = exS.baseView;
#endif      
    TUTORdeferred_dealloc((char FAR *)vp); /* get rid of memory */
    return 0;
    }

/* ********************************************************* */

TUTORuse_rel_rect(rRect,inf,viewP,sRect)
TRect FAR *rRect;
int inf;
struct tutorview FAR *viewP; /* view index */
TRect *sRect;
    {
    int sright, sbottom;

    sright = windowsP[viewP->window].wxsize;
    sbottom = windowsP[viewP->window].wysize;

    /* left */
    if (inf & LEFTSTICK)
        sRect->left = rRect->left;
    else
        sRect->left = sright - rRect->left;
    
    /* top */
    if (inf & TOPSTICK)
        sRect->top = rRect->top;
    else
        sRect->top =sbottom - rRect->top;
    
    /* right */
    if (inf & RIGHTSTICK)
        sRect->right = sright - rRect->right;
    else
        sRect->right = rRect->right;
    
    /* bottom */
    if (inf & BOTTOMSTICK)
        sRect->bottom = sbottom - rRect->bottom;
    else
        sRect->bottom = rRect->bottom;
    
    return(0);
    }

TUTORmake_rel_rect(viewP,theR,inf,relR)
struct tutorview FAR *viewP;
TRect *theR; /* where item currently is */
int inf; /* resizing info */
TRect *relR; /* to be set to relRect */
    {
    int sright, sbottom; /* left & top of window are both 0 */

    sright = windowsP[viewP->window].wxsize;
    sbottom = windowsP[viewP->window].wysize;

    /* left */
    if (inf & LEFTSTICK)
        relR->left = theR->left;
    else
        relR->left = sright - theR->left;
    /* top */
    if (inf & TOPSTICK)
        relR->top = theR->top;
    else
        relR->top = sbottom - theR->top;
    /* right */
    if (inf & RIGHTSTICK)
        relR->right = sright - theR->right;
    else
        relR->right = theR->right;
    /* bottom */
    if (inf & BOTTOMSTICK)
        relR->bottom = sbottom - theR->bottom;
    else
        relR->bottom = theR->bottom;

    return(0);
    }

/* ********************************************** */

TUTORintersect_rect(r1,r2,rdest)
register TRect FAR *r1, FAR *r2, FAR *rdest;
/* returns TRUE if rectangles have non-zero intersection */
    {
    if (r1->left > r2->right || r2->left > r1->right ||
            r1->top > r2->bottom || r2->top > r1->bottom)
        {
        /* null intersection -- put rectangle off screen */
        rdest->left = rdest->right = -32000;
        rdest->top = rdest->bottom = -32000;
        return(FALSE);
        }
    
    rdest->left = (r1->left > r2->left) ? r1->left : r2->left;
    rdest->top = (r1->top > r2->top) ? r1->top : r2->top;
    rdest->right = (r1->right < r2->right) ? r1->right : r2->right;
    rdest->bottom = (r1->bottom < r2->bottom) ? r1->bottom : r2->bottom;
    
    return(TRUE);
    }

/* ********************************************************* */

double TUTORdouble_click_time() /* returns double click time in msec */

{	double doubleTime;
#ifdef MAC
    doubleTime = (*((long *) 0x2f0) * 1000) / 60; /* use user-set machine global */
#else
#ifdef WINPC
    doubleTime = win_double_click();
#else
    doubleTime = 700;
#endif
#endif
	return(doubleTime);
	
} /* TUTORdouble_click_time */

/* ********************************************************* */

TUTORdouble_click(hh,vv)    /* return TRUE if double-click */
short *hh, *vv;

{   register struct tutorwindow FAR *wp;
    int ii,dx,dy;
    long doubleTime;

	doubleTime = TUTORdouble_click_time();
    wp = windowsP + CurrentWindow;
    *vv = wp->upy;
    *hh = wp->upx;
    dx = wp->upx-wp->mousex;
    dy = wp->upy-wp->mousey;
    if (dx < 0) dx = -dx;
    if (dy < 0) dy = -dy;
    if ((dx > 2) || (dy > 2))
    	return(FALSE);
    if (wp->ldowntime1 < wp->rdowntime1) 
        ii = wp->rdowntime1-wp->rdowntime2;
    else
        ii = wp->ldowntime1-wp->ldowntime2;

    if (ii < 0 || ii > doubleTime)
        return(FALSE);
    return(TRUE);

} /* CheckDouble */

/* ******************************************************************* */

/* latin-1 character composition table */
static unsigned char composeTable[] = 
    {
    /* each entry in this table consists of 2 characters, which are the compose
        sequence.  The result character is table index + 0xa0 */
    
    ' ',' ',  '!','!',  'c','/',  'L','-',  'X','O',  'Y','-',  '|','|',  'S','O',
    '"','"',  'c','o',  'a','_',  '<','<',  '-',',',  '-','-',  'R','O',  '-','^',

    '0','^',  '+','-',  '2','^',  '3','^',  0x27,0x27,  '/','u',  'P','!',  '.','^',
    ',',',',  '1','^',  'o','_',  '>','>',  '1','4',  '1','2',  '3','4',  '?','?',

    'A',0x60,  'A',0x27,  'A','^',  'A','~',  'A','"',  'A','*',  'A','E',  'C',',',
    'E',0x60,  'E',0x27,  'E','^',  'E','"',  'I',0x60,  'I',0x27,  'I','^',  'I','"',

    'D','-',  'N','~',  'O',0x60,  'O',0x27,  'O','^',  'O','~',  'O','"',  'x','x',
    'O','/',  'U',0x60,  'U',0x27,  'U','^',  'U','"',  'Y',0x27,  'T','H',  's','s',

    'a',0x60,  'a',0x27,  'a','^',  'a','~',  'a','"',  'a','*',  'a','e',  'c',',',
    'e',0x60,  'e',0x27,  'e','^',  'e','"',  'i',0x60,  'i',0x27,  'i','^',  'i','"',

    'd','-',  'n','~',  'o',0x60,  'o',0x27,  'o','^',  'o','~',  'o','"',  '-',':',
    'o','/',  'u',0x60,  'u',0x27,  'u','^',  'u','"',  'y',0x27,  't','h',  'y','"'
    };

TUTORcompose_char(cCompose)
unsigned char *cCompose; /* array of chars, two for latin-1, 4 for fkey */
/* returns the cT char which is the result of composing the two chars in cCompose */
    {
    register unsigned char *ctb; /* pointer at table */
    register int ii;
    register unsigned char c1, c2;
    
    ctb = &composeTable[0];
    c1 = *cCompose;
    c2 = *(cCompose+1);
    
    /* look thru compose table */
    for (ii=0xa0; ii<= 0xff; ii++)
        {
        if ((c1 == *ctb && c2 == *(ctb+1)) ||
                (c2 == *ctb && c1 == *(ctb+1)))
            return(ii);
        ctb += 2;
        }
    
    /* didn't find, return '?' */
    
    return('?');
    }

GetCompose(code,tempS)
int code;
char *tempS;
/* puts string containing compose sequence into tempS */
    {
    char *seq;
    
    if (code < 0xa0 || code > 0xff)
        *tempS = '\0';
    else
        {
        seq = (char *) composeTable+2*(code - 0xa0);
        tempS[0] = seq[0];
        tempS[1] = seq[1];
        tempS[2] = '\0';
        }
    return(0);
    }

/* ******************************************************************* */

CancelTrigger(id)   /* cancel specified event */
int id; /* unique event id */
  
{   int i;  /* index in event/timing queue */
    int ti; /* index in event/timing queue */
    struct tutorevent FAR *timeQ, FAR *timeP; /* pointers to time queue */

    if (id <= 0) return 0;
    for (i=0; i<nevents; i++) { /* search and destroy event */
        if (eventque[i].id == id) { /* remove from timing que */
            for (ti = i; ti < (nevents-1); ti++) 
                eventque[ti] = eventque[ti+1];
            nevents--;
        } /* if */
    } /* for */
    timeQ = (struct tutorevent FAR *) GetPtr(timeque);
    for(i = 0; i < ntiming; i++, timeQ++) {
        if (timeQ->id == id) { /* remove from timing que */
            for (ti = i, timeP = timeQ; ti < (ntiming-1); ti++, timeP++)
                *timeP = *(timeP+1);
            ntiming--;
        } /* if */
    } /* for */
    ReleasePtr(timeque);
    KillPtr(timeQ);
    return 0;

} /* CancelTrigger */

ClearExecTiming()
    {
    ntiming = 0; /* is this right?!?  It kills ALL timing events */
    }

/* ********************************************************** */

OrderRect(rp)       /* order rectangle corners correctly */
register TRect FAR *rp;
{
    register short x1;

    if (rp->left > rp->right) {
    x1 = rp->left;
    rp->left = rp->right;
    rp->right = x1;
    }
    if (rp->top > rp->bottom) {
    x1 = rp->top;
    rp->top = rp->bottom;
    rp->bottom = x1;
    }
}

/* ********************************************************** */

TUTORset_fill(fInd,fChar) /* set fill pattern */
int fInd, fChar; /* parameters of new fill, index and char */
    {
    patternFont = fInd;
    patternChar = fChar;

#ifdef ANDREW
    if (isx11) {
	SetXFill();
	return;
    }
#endif
#ifdef GENERICSYS
    if (isx11) {
	SetXFill();
        return;
    }
#endif
#ifdef X11
    SetXFill();
    return;
#endif
#ifdef WINPC
    SetWinFill();
#endif
    }

/* ********************************************************* */

TUTORset_key_focus(wid,vp,fromClick) /* set key focus to specified view */
int wid; /* which window */
struct tutorview FAR *vp;   /* pointer to view */
int fromClick;  /* TRUE if this focus change is due to a click */
                /* some views handle click focus changes differently than
                    non-click focus changes */

    {
    register struct tutorwindow FAR *wp;
    struct tutorview FAR *cv;
    
    wp = windowsP + wid;
    if (wp->KeyFocus != vp)
        { /* change the key focus */
        cv = TUTORinq_view();
        
        /* tell previous view it no longer has focus */
        if (wp->KeyFocus)
            {
            TUTORset_view(wp->KeyFocus);
            TUTORmessage(wp->KeyFocus,EVENT_VFOCUS,0); /* deactivate old */
            }
        wp->KeyFocus = vp;
        wp->MenuFocus = vp;
        if (wp->KeyFocus)
            {
            TUTORset_view(wp->KeyFocus);
            TUTORmessage(wp->KeyFocus,EVENT_VFOCUS,1+(fromClick<<1)); /* activate new */
            }
        
        TUTORset_view(cv);
        }

    } /* TUTORset_key_focus */

/* ******************************************************** */

TUTORset_abs_view_rect(x1,y1,w,h) /* set display rectangle for current view */
int x1,y1;  /* upper left corner of rectangle */
int w,h;    /* width/height */

{
    register struct tutorview FAR *vp;

    if (!CurrentView) return 0; /* no view selected */
    vp = CurrentView;
    vp->rr.left = x1;
    vp->rr.top = y1;
    vp->rr.right = x1 + w - 1;
    vp->rr.bottom = y1 + h - 1;

} /* TUTORset_abs_view_rect */

/* ********************************************************* */

int TUTORpost_event(event)  /* add event to event or timing queue */
struct tutorevent *event;   /* pointer to event */

{   int ti; /* index of new event in timing queue */
    int tmi; /* move loop index in timing queue */
    struct tutorevent FAR *timeQ; /* pointer to time queue */

    event->pressed = TRUE; /* posted events are pressed */
	if (event->type <= 0)
		return(0); /* not a valid event */
		
    /* process normal event or zero-length timing event */

    if (nevents >= EVENTLIMIT-5)
        TUTORcompress_events(); /* try to free up space in the event queue */

    if (!event->timestamp) {
        if (nevents >= EVENTLIMIT) {
            return(0); /* exit if queue full */
        } /* queue length if */
        event->timestamp = TUTORinq_msec_clock();
        event->id = eventid++;
        eventque[nevents++] = *event;
        return(event->id);
    } /* event type if */
        
    if (ntiming >= TIMINGLIMIT) {
        return(0); /* exit if queue full */
    } /* queue length if */

    event->id = eventid++;
    event->timestamp += TUTORinq_msec_clock(); /* set time due */

    /* find proper slot for this timing event */
    
    timeQ = (struct tutorevent FAR *) GetPtr(timeque);
    for(ti = 0; ti < ntiming; ti++) {
        if (event->timestamp < timeQ[ti].timestamp)
            break;
    } /* for */

    /* move following events in queue to make room */

    for(tmi = ntiming; tmi > ti; tmi--) {
        timeQ[tmi] = timeQ[tmi-1]; /* shove queue down */
    } /* for */

    timeQ[ti] = *event;
    ReleasePtr(timeque);
    KillPtr(timeQ);

    ntiming++;
    return(event->id);

} /* TUTORpost_event */


/* ********************************************************* */

int TUTORpush_event(event)  /* push event to top of event queue */
struct tutorevent *event;   /* pointer to event */
    {
    long nshove;
    
    if (nevents >= EVENTLIMIT-5)
        TUTORcompress_events(); /* try to free up space in the event queue */

    if (nevents)
        { /* shove existing events down in stack */
        nshove = nevents;
        if (nshove == EVENTLIMIT)
            nshove--; /* we will lose 1 event */
        TUTORblock_move((char SHUGE *) eventque,(char SHUGE *)(eventque+1),
                nshove*sizeof(struct tutorevent));
        }
    
    /* put in new event */
    *eventque = *event;
    nevents++;
    }

/* ********************************************************* */
TUTORcompress_events() /* compress the event queue (getting rid of canceled events) */
    {
    register struct tutorevent FAR *evp, FAR *evp0;
    register int ii;
    int nLeft;
    long nMove;
    
    evp = eventque;
    ii = 0;
    while (ii < nevents)
        { /* compress out each sequence of cancelled events */

        /* skip over the valid events */
        while (ii<nevents && evp->type != -1)
            {
            ii++;
            evp++;
            }
        if (ii >= nevents)
            break; /* didn't find anything to compress */
        
        evp0 = evp; /* start of a sequence of cancelled events */
        
        /* find all the events in this sequence of cancelled events */
        while(ii < nevents && evp->type == -1)
            {
            ii++;
            evp++;
            }
        
        /* compress out the cancelled events */
        nLeft = nevents - ii;   /* # of events following cancelled events */
        nMove = sizeof(struct tutorevent) * nLeft; /* bytes to move */
        if (nMove)
            TUTORblock_move((char SHUGE *) evp, (char SHUGE *) evp0, nMove);
        nevents -= (evp - evp0);
        ii -= (evp - evp0);
        evp = evp0;
        
        }
    
    return(0);
    }

/* ********************************************************* */
TUTORmessage(vp,eKind,eVal)  /* send a message to a view */
struct tutorview FAR *vp;
int eKind;
int eVal;
    {
    struct tutorevent cev;

    cev.view = vp;
    cev.window = vp->window;
    cev.type = eKind;
    cev.value = eVal;
    cev.timestamp = 0;
    (*vp->vproc) (vp->vh,&cev); /* message sent immediately */

    return 0;
    }

/* ********************************************************* */

TUTORcancel_all_events() /* cancel all events for this window */

{   int ii; /* index in event/timing queues */
    struct tutorevent FAR *timeQ; /* pointer to time queue */

    for(ii=0; ii<nevents; ii++)
        if (eventque[ii].window == CurrentWindow) 
            if (eventque[ii].type != EVENT_REDRAW)
            {
                TUTORfree_event_memory(eventque+ii);
                eventque[ii].type = -1; /* cancel event */
            }

    timeQ = (struct tutorevent FAR *) GetPtr(timeque);
    for(ii=0; ii<ntiming; ii++, timeQ++)
        if (timeQ->window == CurrentWindow) {
            timeQ->type = -1;
        }
    ReleasePtr(timeque);
    KillPtr(timeQ);

    return 0;

} /* TUTORcancel_all_events */

/* ********************************************************** */

TUTORget_font2(fam,size,face,cid) /* get possibly unknown font by characteristics */
long fam; /* font family id (not index) */
int size; /* system size */
unsigned int face;
int cid; /* caller id */
/* returns font index */
    {
    REGISTER struct tutorfont FAR *fp;
    int ii, fInd;

    /* look for font in table */
    
    fp = (struct tutorfont FAR *) GetPtr(fontsH);
    for (ii=0; ii<nfonts; ii++,fp++) {
        if (fp->fID == fam && fp->size == size && fp->textface == face)
            break; /* found it */
	} /* for */
    ReleasePtr(fontsH);
    KillPtr(fp);

    if (ii >= nfonts)
        { /* didn't find font, have to load it */
	fInd = FontFamilyIndex(fam); /* get font family index */
        ii = TUTORfont_ptr(fInd,size,face,cid); /* get font pointer for this item */
        }

    fp = ii+((struct tutorfont FAR *)GetPtr(fontsH));
    fp->nusers++; /* increment num users of this entry */
    /* this count won't be accurate as there are many places that */
    /* don't decrement the counter when the font is no longer in use */
    /* but it does suffice to identify user fonts that are no longer */
    /* needed */
    ReleasePtr(fontsH);
    return(ii);
    }

/* ********************************************************** */

FontFamilyIndex(id) /* return index in font family table based on id */
long id;
/* returns -1 for error */
    {
    FontFamily FAR *ffp;
    int ii;

    ffp = (FontFamily FAR *) GetPtr(fontFamilies);
    for (ii=0; ii<nFamilies; ii++, ffp++)
        if (ffp->fID == id)
            break;
    ReleasePtr(fontFamilies);
    KillPtr(ffp);
    return((ii<nFamilies) ? ii : -1);
    }

/***********************************************************/

TUTORinq_font_descr(fontN,fam,siz,fac)
int fontN;  /* index of font we want description of */
long *fam; 
int *siz, *fac;

{   struct tutorfont FAR *tf;

#ifdef long_align
    if (fam) 
	if ((long)(fam) & 3) TUTORdump("ctgraph 2");
    if (siz)
	if ((long)(siz) & 3) TUTORdump("ctgraph 3");
    if (fac)
	if ((long)(fac) & 3) TUTORdump("ctgraph 4");
#endif

    tf = fontN + ((struct tutorfont FAR *) GetPtr(fontsH));
    if (fam)
        *fam = tf->fID;
    if (siz)
        *siz = tf->size;
    if (fac)
        *fac = tf->textface;
    ReleasePtr(fontsH);
    KillPtr(tf);
    return 0;

} /* TUTORinq_font_descr */
/***********************************************************/

int TUTORinq_icon_code_size(fontN)
/* returns 0 for 8-bit chars, 1 for 16-bit chars */
int fontN;  /* index of font we want character code size for */

{   struct tutorfont FAR *tf;
    int rsize; /* size to return */

#ifdef WM
    tf = fontN + ((struct tutorfont FAR *) GetPtr(fontsH));
    rsize = tf->codeSize;
    ReleasePtr(fontsH);
    return(rsize);
#endif

#ifdef MAC
    rsize = 0; /* pre-set 8 bit font */
    tf = fontN + ((struct tutorfont FAR *) GetPtr(fontsH));
    if ((tf->basicType == ICONSF) && (tf->iconType == 4))
        rsize = 1;
    ReleasePtr(fontsH);
    return(rsize);
#endif

#ifdef WINPC
    tf = fontN + ((struct tutorfont FAR *) GetPtr(fontsH));
    rsize = tf->codeSize;
    ReleasePtr(fontsH);
    return(rsize);
#endif

#ifdef DOSPC
    return(0);
#endif

#ifdef X11
    tf = fontN + ((struct tutorfont FAR *) GetPtr(fontsH));
    rsize = tf->codeSize;
    ReleasePtr(fontsH);
    return(rsize);
#endif

} /* TUTORinq_icon_code_size */

/* ********************************************************** */

/* TUTORcvt_text_size converts font sizes based on POINT size, not on actual
    height.  This works out ok assumming that there is a roughly linear relationship
    between point size and height */

TUTORcvt_text_size(fid,defSz,sz)
int fid;    /* font family id */
int defSz;
int sz; /* offset from default */
/* returns the converted size (which will be a "real" size) */
    {
    int newSize, ii, retVal;
    FontFamily FAR *ffp;

    if (sz == DEFSTYLE)
        newSize = defSz;
    else if (sz <= ABSSIZE)
        newSize = -(sz - ABSSIZE);
    else
        { /* sz is relative size, in percent */
        /* we will multiply things by 256 to get higher precision */
        newSize = defSz + (((long) sz*256L * defSz)/100L)/256;
        }
    
    ffp = (FontFamily FAR *) GetPtr(fontFamilies);

    /* find the right font family entry */
    for (ii=0; ii<nFamilies; ii++, ffp++)
        if (ffp->fID == fid)
            break;
    
    if (ii < nFamilies) { /* found family, look thru table of real sizes */
        if (!ffp->knownFont) { /* don't know sizes */
        	retVal = newSize;
        } else {
        	for (ii=0; ii<NFSIZES; ii++) {
            	if (ffp->famSizes[0][ii] == -1 || ffp->famSizes[0][ii] > newSize)
            		break; /* this size too big, or we ran out of sizes */
            }
        	if (ii == 0) ii = 1;
        	retVal = ffp->famSizes[0][ii-1];
        	if (retVal == -1) retVal = newSize;
        }
    } else
        retVal = 12; /* a reasonable size for all machines */
    
    ReleasePtr(fontFamilies);
    KillPtr(ffp);
    return(retVal);
    }

/* *************     line  based  routines     ************* */

/* ******************************************************** */

TUTORabs_line(hh,vv) /* draw line to x+hh, y+vv */
register int hh, vv;

{
    TUTORabs_line_to(RealX+hh,RealY+vv);

} /* TUTORabs_line */

/* *********************************************************** */

TUTORunset_clip_rectangle() 
 { 
    TRect cr;
    
    cr.left = cr.top = 0;
    cr.right = cr.bottom = 20000;
    TUTORset_abs_clip_rect((TRect FAR *) &cr);
#ifdef DOPSCRIPT
    if (pscript)  
        {sprintf( PSbuff, "SetDefaultClipRegion\n") ;
         PostScriptOutput( PSbuff ) ;
        }
#endif
 }

/* ******************************************************* */

int TUTORinq_window()   /* return current window number */ /* machine independent */

{
    return(CurrentWindow);

} /* TUTORinq_window */

/* ********************************************************** */

struct tutorview FAR *TUTORinq_view()   /* return current view number */ /* machine independent */

{
    return(CurrentView);

} /* TUTORinq_view */

/* ********************************************************* */

int TUTORinq_event_mask(wid,eventc) /* get specified event enable status */ /* machine independent */
int wid;
int eventc; /* event type to return status of */

{
    return(windowsP[wid].eventMask[eventc]);

} /* TUTORinq_event_mask */

/* ********************************************************* */

TUTORinq_abs_clip_rect(cr) /* get clip rectangle */
TRect *cr;
{
    cr->left = tgclipx;
    cr->top = tgclipy;
    cr->right = tgclipx+tgclipw - 1;
    cr->bottom = tgclipy+tgcliph - 1;

} /* TUTORinq_abs_clip_rect */

/* ********************************************************* */
TUTORclip_window(wid)   /* set clip to entire window */
int wid;
    {
    TRect cr;
    
    cr.left = cr.top = 0;
    cr.right = windowsP[wid].wxsize - 1;
    cr.bottom = windowsP[wid].wysize - 1;
    
    TUTORset_abs_clip_rect((TRect FAR *) &cr);
    }

/* ********************************************************* */

int TUTORinq_comb_rule()    /* return current mode */

{
    return(CurrentMode); /* return mode */

} /* TUTORinq_comb_rule */

/* character functions */

/* ********************************************************* */

CTmap_color(wn,cn,foreFlag) /* map a color to a really existing slot */
int wn; /* window where we are mapping color */
register int cn;    /* the desired color */
int foreFlag;   /* TRUE if this is for a foreground color */
/* returns the color index to use */
    
{	struct CTcolorentry FAR *cep;
    Memh palette;
    int nReal;
    register int ii;

    if (cn == color_rgb)
    	return(cn); /* do nothing if RGB color */
    nReal = CurrentPaletteSize;
#ifdef MAC
    if (nReal > MacMinColors()) 
        nReal = MacMinColors();
#endif
	if (cn == color_defaultb)
		; /* default background is negative but legal */
    else if (cn < 0)
        cn = color_defaultf;
    else if (cn > 255)
        cn = 255;
    if (cn < 0)
        return(CTmap_default_color(cn));    
    if (cn >= windowsP[wn].paletteSize) {
        /* bring cn within palette */
        cn = windowsP[wn].paletteSize-1;
    }

    if (cn >= nReal) {
        /* we need to use fallbacks to map color to a real color */
        palette = windowsP[wn].paletteH;
        if (!palette)
            palette = defaultPalette;
        cep = (struct CTcolorentry FAR *) GetPtr(palette);
        for (ii=0; ii<256; ii++) { /* try 256 times only, to avoid loops */
            if (foreFlag) {
                cn = cep[cn].foreFall;
            } else
                cn = cep[cn].backFall;
            
            if (cn < nReal)
                break; /* we found a usable color */
        } /* for */
        if (cn >= nReal)
            cn = color_defaultf; /* we couldn't find a usable color */
        ReleasePtr(palette);
        KillPtr(cep);
    } /* cn if */
    
    if (cn < 0)
        cn = CTmap_default_color(cn);

    return(cn);

} /* CTmap_color */

/* ********************************************************* */

CTset_window_color(cn)
int cn; /* the color */
    
{
    winColor.palette = cn;
    
} /* CTset_window_color */

/* ********************************************************* */

void TUTORset_color(select,newColor) /* general set color */
int select; /* 0 = foreground, 1 = background, 2 = window */
struct tutorColor FAR *newColor; /* pointer to color to set */

{	
	if (newColor->palette == color_rgb) {
		TUTORset_color_rgb(select,0,
		                   newColor->red,newColor->green,newColor->blue);
	} else {
		switch (select) {
	
		case 0:
			CTset_foreground_color(newColor->palette);
			break;
			
		case 1:
			CTset_background_color(newColor->palette);
			break;
			
		case 2:
			CTset_window_color(newColor->palette);
			break;
			
		} /* switch */
	} /* else */
		
} /* TUTORset_color */

/* ********************************************************* */

TUTORget_colors(fcx,bcx,wcx)
struct tutorColor *fcx, *bcx, *wcx;
    
{
    TUTORblock_move((char FAR *)&fgndColor,(char FAR *)fcx,
                    (long)sizeof(struct tutorColor));
    TUTORblock_move((char FAR *)&bgndColor,(char FAR *)bcx,
                    (long)sizeof(struct tutorColor));
    TUTORblock_move((char FAR *)&winColor,(char FAR *)wcx,
                    (long)sizeof(struct tutorColor));
    return 0;
    
} /* TUTORget_colors */

/* ********************************************************* */

int TUTORinq_foreground_color(fc) /* return current fgnd color */
struct tutorColor *fc;
{
	TUTORblock_move((char FAR *)&fgndColor,(char FAR *)fc,
	                (long)sizeof(struct tutorColor));
    return(fgndColor.palette);

} /* TUTORinq_foreground_color */
    
/* ********************************************************* */

int TUTORinq_background_color(bc) /* return current bgnd color */
struct tutorColor *bc;

{
	TUTORblock_move((char FAR *)&bgndColor,(char FAR *)bc,
	                (long)sizeof(struct tutorColor));
    return(bgndColor.palette);

} /* TUTORinq_background_color */

/* ******************************************************************* */

struct hashTab {
	unsigned char red,green,blue; /* rgb color value */
	unsigned char ddUnused;
	int palSlot; /* palette slot assigned */
	int nextI; /* index of next slot in chain */
}; /* keywdinf */

int TUTORpalettize_rgb(type,pixelsP,inRow,outPixP,outRow,paletteH,width,height)
/* convert rgb->palette */
int type; /* = 1 = 3 byte r,g,b (array form) */
          /* = 2 = native r,g,b */
unsigned char SHUGE *pixelsP; /* pointer to r,g,b pixels */
long inRow; /* bytes/row in input */
unsigned char SHUGE *outPixP; /* pointer to palette-index pixels */
long outRow; /* bytes/row in output */
Memh paletteH; /* handle on palette to use */
int width; /* width of image */
int height; /* height of image */

{   struct CTcolorentry FAR *paletteP; /* pointer to cT palette */
    int paletteN; /* size of palette */
    int palI; /* index in palette */
    struct CTcolorentry FAR *palP; /* pointer in palette */
    int rowI,colI; /* row-column indexes in pixels */
    unsigned int rr,gg,bb; /* rgb pixel value */
    long pixelV; /* pixel value */
    long bestDist,curDist,dist; /* for shortest-distance search */
    struct CTcolorentry FAR *searchP; /* for search */
    int nHash; /* number entries in hash table */
    int hii; /* index in hash table */
    struct hashTab FAR *hashP; /* pointer to hash table */
    struct hashTab FAR *hP; /* pointer in hash table */
    struct hashTab FAR *newhP; /* pointer to new table entry */
    int freeI; /* index of first free slot in hash chain */
    int thisI; 
    long hashV; /* r,g,b value to hash */
    unsigned char SHUGE *inP; /* pointer to next pixel to convert */
    long inRowExtra,outRowExtra;
    unsigned char SHUGE *outP; /* pointer in output pixels */
    long len;
    int slotFound; /* palette slot pixel mapped to */
   	int bias; /* used to bias to red or green or blue section of hash table */
   	
    paletteN = TUTORget_hsize(paletteH)/sizeof(struct CTcolorentry);

    inRowExtra = outRowExtra = 0;
#ifdef MAC
    if (type == 2)
	inRowExtra = inRow-(4L*width);
#endif
#ifdef WINPC
    if (type == 2)
	inRowExtra = inRow-(3L*width);
#endif
    outRowExtra = outRow-width;

    /* allocate hash table */
	
    nHash = 4096+256+2;
    len = (long)(nHash)*sizeof(struct hashTab);
    hashP = (struct hashTab FAR *)TUTORalloc(len,FALSE,"hash");
    if (!hashP)
		return(FALSE);
		
    outP = outPixP;
    paletteP = (struct CTcolorentry FAR *)GetPtr(paletteH);
    
    /* check for never-realized palette (picture native palette) */
    
    for(palI = 0; palI < 256; palI++) {
    	if ((paletteP+palI)->realV == -1)
    		(paletteP+palI)->realV = palI;
    }

    /* initialize hash table for rgb -> palette conversion */

    TUTORzero((char FAR *)hashP,len);
    for(hii = 0; hii < nHash; hii++)
		(hashP+hii)->palSlot = -1; /* no palette slot assigned yet */
    for(hii=4096; hii<(nHash-1); hii++)
		(hashP+hii)->nextI = hii+1; /* initialize free list */
    freeI = 4096; /* first free entry */
		
    /* fill hash table from palette */
	
    for(palI=0; palI<paletteN; palI++) {
		rr = (paletteP+palI)->red;
		gg = (paletteP+palI)->green;
		bb = (paletteP+palI)->blue;
		if (rr >= gg && rr >= bb) {
			hashV = ((rr >> 5) & 0x7c0) + ((gg >> 10) & 0x38) + ((bb >> 13) & 0x7);
			if (hashV > 1365)
				hashV = hashV-1365;
    	} else if (gg >= rr && gg >= bb) {
			hashV = ((gg >> 5) & 0x7c0) + ((rr >> 10) & 0x38) + ((bb >> 13) & 0x7);
			if (hashV > 1365)
				hashV -= 1365;
			hashV += 1365;
		} else {
	   		hashV = ((bb >> 5) & 0x7c0) + ((rr >> 10) & 0x38) + ((gg >> 13) & 0x7);
	   		if (hashV > 1365)
	   			hashV -= 1365;
	   		hashV += 2730;
    	}
		rr = (rr >> 8) & 0xff;
		gg = (gg >> 8) & 0xff;
		bb = (bb >> 8) & 0xff;
		newhP = FARNULL; /* don't need new table slot yet */
		hP = hashP+hashV;
		if (hP->palSlot < 0) { /* this hash table slot is free */
	    	newhP = hP;
		} else if ((hP->red == rr) && (hP->green == gg) && (hP->blue == bb)) {
	    	; /* color matched */
		} else { /* need to add at end of use chain */
	    	while (hP->nextI)
				hP = hashP+hP->nextI; /* loop to end of used chain */
	    	thisI = freeI; /* take next entry off free list */
	    	newhP = hashP+thisI;
	    	freeI = newhP->nextI;
	    	newhP->nextI = 0; /* this is currently end of used chain */
	    	hP->nextI = thisI; /* add to use chain */
		}
		if (newhP) {
			newhP->red = rr;
			newhP->green = gg;
			newhP->blue = bb;
			newhP->palSlot = palI;
		}
    } /* palI for */
	
    /* convert pixels via hash table look-up */
	
    inP = pixelsP;
    for(rowI=0; rowI<height; rowI++) {
		for(colI=0; colI<width; colI++) {
		
	    	/* pick up next pixel value */
			
	    	if (type == 1) {
				rr = *inP++;
				gg = *inP++;
				bb = *inP++;
	    	} else  if (type == 2) {
#ifdef MAC
				rr = *(inP+1);
				gg = *(inP+2);
				bb = *(inP+3);
				inP += 4;
#endif
#ifdef X11
				rr = *inP++;
				gg = *inP++;
				bb = *inP++;
#endif
#ifdef WINPC
				bb = *inP++;
				gg = *inP++;
				rr = *inP++;
#endif
	    	} /* type if */


			if (rr >= gg && rr >= bb) {
				hashV = ((rr << 3) & 0x7c0) + ((gg >> 2) & 0x38) + ((bb >> 5) & 0x7);
				if (hashV > 1365)
					hashV -= 1365;
    		} else if (gg >= rr && gg >= bb) {
				hashV = ((gg << 3) & 0x7c0) + ((rr >> 2) & 0x38) + ((bb >> 5) & 0x7);
				if (hashV > 1365)
					hashV -= 1365;
				hashV += 1365;
			} else {
	   			hashV = ((bb << 3) & 0x7c0) + ((rr >> 2) & 0x38) + ((gg >> 5) & 0x7);
	   			if (hashV > 1365)
	   				hashV -= 1365;
	   			hashV += 2730;
    		}
				
	    	/* search for matching hash table entry */
			
	    	hP = hashP+hashV;
	    	if (hP->palSlot < 0) { /* empty slot, add to hash table */
				hP->palSlot = slotFound = PaletteMatch(paletteP,paletteN,rr << 8,gg << 8,bb << 8);
				hP->red = rr;
				hP->green = gg;
				hP->blue = bb;
	    	} else { /* search hash table */
	    	
	    		/* check if in hash chain, linked behind current */
	    		
				slotFound = -1;
				while (TRUE) {
		    		if ((hP->red == rr) && (hP->green == gg) && (hP->blue == bb)) {
						slotFound = hP->palSlot;
						break; /* found a perfect match */
		    		}
		    		if (hP->nextI) hP = hashP+hP->nextI; /* advance to next */
		    		else break;
				};
				
				/* link behind current end of chain */
				
				if (freeI && slotFound < 0) {
					thisI = freeI; /* take next entry off free list */
	    			newhP = hashP+thisI;
	    			freeI = newhP->nextI;
	    			newhP->nextI = 0; /* this is currently end of used chain */
	    			hP->nextI = thisI; /* add to use chain */
					newhP->red = rr;
					newhP->green = gg;
					newhP->blue = bb;
					newhP->palSlot = slotFound = PaletteMatch(paletteP,paletteN,rr << 8,gg << 8,bb << 8);
				}
	
				if (slotFound < 0) {
		    	
		    		/* look for best match within links following this slot */
		    		
		    		hP = hashP+hashV;
		    		bestDist = 0x7fffffffL;
		    		while (TRUE) {
						curDist = rr-hP->red;
						if (curDist < 0) curDist = -curDist;
						dist = gg-hP->green;
						if (dist < 0) dist = -dist;
						curDist += dist;
						dist = bb-hP->blue;
						if (dist < 0) dist = -dist;
						curDist += dist;
						if (curDist < bestDist) {
			    			bestDist = curDist; /* best match so far */
			    			slotFound = hP->palSlot;
						} /* if */
						if (hP->nextI) hP = hashP+hP->nextI; /* advance to next */
						else break;
		    		} /* while */
				} /* slotFound if */
	    	} /* search else */
	    	*outP++ = (paletteP+slotFound)->realV; /* add next pixel */
		} /* colI for */
		inP += inRowExtra;
		outP += outRowExtra;
    } /* rowI for */
    
    ReleasePtr(paletteH);

    TUTORdealloc((char FAR *)hashP);
    return(TRUE);
	
} /* TUTORpalettize_rgb */

/* **************************************************** */

CTisascii(cc)
register int cc;
    {
    return(((cc & 0x7f) >= 32) && cc != 127);
    }

CTislower(cc)
register unsigned char cc;
    {
    return (CTisalpha(cc) && ((cc & 0x20) || cc == 0xdf));
    }

CTisupper(cc)
register unsigned char cc;
    {
    return(CTisalpha(cc) && ((cc & 0xdf) && cc != 0xdf));
    }

CTtolower(cc)
register unsigned char cc;
    {
    return(CTisupper(cc) ? (cc | 0x20) : cc);
    }

CTtoupper(cc)
register unsigned char cc;
    {
    if (CTisalpha(cc) && (cc & 0x20) && (cc != 0xff))
        return(cc & 0xdf);
    else
        return(cc);
    }
    
/* ******************************************************************* */

#ifndef THINKC5 /* assembly language routine on 68K macintosh */

double lcitof(iv)           /* integer to floating conversion */
long iv;    /* integer value to convert */

{   
    return(iv);     /* convert to floating and return */

} /* lcitof */

#endif

/* ******************************************************************* */

#ifdef SYSV
long lcftoi(dv) double dv; { return((long)floor(dv+0.5)); }
#endif

#ifdef ibm032
long lcftoic(dv)
double dv; 

{ 
    return((long)(floor(dv+0.5))); 

} /* lcftoic */
#endif

#ifdef IBMPC
long lcftoi(dv)
double dv; 

{ 
    return((long)(floor(dv+0.5))); 

} /* lcftoi */
#endif

#ifdef sunV3
long lcftoi(dv) double dv; { return((long)(floor(dv+0.5))); }
#endif

#ifdef vax
long lcftoi(dv) double dv; { return((long)(floor(dv+0.5))); }
#endif

#ifdef mips
long lcftoi(dv) double dv; { return((long)(floor(dv+0.5))); }
#endif

#ifdef sparc
#ifndef SOLARIS
long lcftoi(dv) double dv; { return((long)(floor(dv+0.5))); }
#endif
#endif

/* ******************************************************************* */

#ifndef THINKC5 /* assembly language routine on 68K macintosh */

double lcfcoord(dv)  /* float to float, rounding to nearest integer */
double dv;  /* floating value to round */

{   
    return( lcitof(lcftoi(dv)) );

} /* lcfcoord */

#endif

/* ******************************************************************* */

/* ************   postscript  output  header   ************* */

postscript_header()
/* sets up necessary information for printing a copy of the screen */

/* variables not yet in qtransX, Y, etc */

/* display is addressed from upper-left, so code will correspond */
/* more naturally to CMU Tutor code; requires scale 1,-1         */

/*    calculates font size needed  */
/*    calculates display size, for insertion in document */

{
#ifdef DOPSCRIPT
#ifndef IBMPC

sprintf( PSbuff, "\n%%!\n\n%% The first line of the file must be \"%%!\".  Delete everything before the %%! .\n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "%% Postscript file made from a CMU Tutor display\n\n%%    don't forget \"showpage\" at the end !!\n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "%% ----------- definitions ---------- \n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "/inches {72 mul} def  %% 72 printing units / inch \n/defaultscale 1 def \n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "/qfontsize 13 def %% global font size \n/qlinewidth 0.5 def   %% default line width \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "/nstr 7 string def    %% 7-character null string \n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "/qscaleX defaultscale def \n /qscaleY defaultscale neg def    %% global X,Y scales \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "/qrotation 0 def  %% portrait \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "/textscaleX defaultscale def  %% make text be right-side up \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "/textscaleY defaultscale neg def \n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "%% If you want landscape (longways of the paper) use: \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "%% /qtransX 540 def  /qtransY 720 def   \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "%% /qscaleX defaultscale neg def    /qscaleY defaultscale neg def  \n%%/qrotation 90 def  %% landscape \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "%% /textscaleX defaultscale neg def   /textscaleY defaultscale neg def \n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "%% For a Scribe document, change qtransX to 0 & qtransX to the display height\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "%% Use: @Center(@Graphic(Height=YY, Width=XX, Postscript=\"thisfilename\")) \n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "%% ----------- procedures ---------- \n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "/MainFont  {/Times-Roman findfont qfontsize scalefont} def \n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "/SetDefaultScreen \n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "  {qscreenW 6.5 inches lt  qscreenH 9.5 inches lt and\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "      {%% if small enough, place in upper left of 8.5 x 11 with 1 inch margins \n") ;

PostScriptOutput(PSbuff);
sprintf( PSbuff, "        /qtransX 1 inches def /qtransY 10 inches def} \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "       {%% else, center display on page, allow spillover \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "         /qtransX 8.5 inches qscreenW sub 2 div def \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "         /qtransY qscreenH 11 inches sub 2 div 11 inches add def}  ifelse \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "  %% to change display positioning, modify next line: \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "   qtransX qtransY translate \n  qscaleX qscaleY scale \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "   0 0 qscreenW qscreenH BoxPath clip \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "   qlinewidth setlinewidth  MainFont setfont} def \n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "/CenterString     %% stack:  string format x y\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "  {moveto  pop    %% vertical center -- not used yet\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "    dup stringwidth pop 2 idiv neg 0 rmoveto showtext} def \n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "/LabelYAxis   %% center string vertically; left or right adjusted   \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, " %% stack: string format x y \n") ;
PostScriptOutput(PSbuff);
/* why 3 ? */
sprintf( PSbuff, " {moveto  3 eq    %% relative x position:  right flush, left flush \n") ;  
PostScriptOutput(PSbuff);
sprintf( PSbuff, "       {dup stringwidth pop neg} {0}  ifelse\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "   qfontsize 2 idiv neg   %% center y\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "   rmoveto showtext } def\n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "/showtext %% since basic coordinates are flipped, must flip text\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "  {0 qfontsize rmoveto    %% move to bottom of text \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "   gsave  textscaleX textscaleY scale show  grestore} def \n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "/Box  {BoxPath stroke} def \n/SetClipRectangle  {BoxPath clip} def\n/FillRectangle  {BoxPath fill} def\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "/BoxPath  %% specify a rectangular path; expects diagonally opposite corners\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "{newpath dup 5 1 roll        %% put 1st y at bottom of stack\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, " exch dup 3 -1 roll moveto    %% duplicate 1st x, bring y back to top\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "  exch dup 3 1 roll lineto    %% duplicate 2nd y\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "  exch dup 3 -1 roll lineto   %% duplicate 2nd x, y back top\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "  exch lineto closepath} def\n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "/DrawLine  {newpath moveto lineto stroke} def  %% draw single line\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "/Dot    {newpath qlinewidth 0 360 arc fill} def\n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "/DrawArc  %% draw full or partial circle, solid or dashed\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "%% on stack: x, y, radius, startangle, endangle, ratio, rotation, unbroken\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "%% unbroken = 0 for dashed lines\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "{dup 9 1 roll %% repeat unbroken on bottom of stack\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "  0 eq {[10 10] 0 setdash} if     %% change to dashed line\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "  /rotation exch def  /ratio exch def \n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "  ratio 1 eq rotation 0 eq and    %% are ratio=1 & rotation=0?\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "  {newpath arc stroke}\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "  {gsave  5 -2 roll translate   rotation rotate  1 ratio scale\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "       newpath 0 0 5 2 roll arc stroke  grestore} ifelse\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "  0 eq {[] 0 setdash} if  %% restore solid line\n} def\n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "/FillDisk %% stack: x, y, radius, ratio, rotation\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "{/Rotation exch def  /Ratio exch def      %% save value of ratio\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "  /DiskRadius exch def  /DiskY exch def  /DiskX exch def  \n\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "  Ratio 1 eq Rotation 0 eq and    %% are ratio=1 & rotation=0?\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "  {newpath DiskX DiskY DiskRadius 0 360 arc fill}\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "  {gsave\n    DiskX DiskY translate  Rotation rotate 1 Ratio scale\n") ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "       newpath 0 0 DiskRadius 0 360 arc fill   grestore} \nifelse} def\n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "/SetDefaultClipRegion {} def   %% need to fix these outputs\n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "%%---------- make display ------------ \n\n") ;
PostScriptOutput(PSbuff);

sprintf( PSbuff, "%%---- now erase down to GOOD STUFF ------ \n\n") ;
PostScriptOutput(PSbuff);

fflush(stdout) ;
#endif /* DOPSCRIPT */
#endif /* not IBMPC */
}

PostscriptDefaultScreen() {

#ifdef DOPSCRIPT
sprintf( PSbuff, "%%---- this is GOOD STUFF ------ \n") ;
PostScriptOutput(PSbuff);
/* get information about actual display size in pixels */
sprintf( PSbuff, "%%\n/qscreenW %d def  /qscreenH %d def \nSetDefaultScreen\n%%\n\n",
               windowsP[CurrentWindow].wxsize, windowsP[CurrentWindow].wysize) ;
PostScriptOutput(PSbuff);
sprintf( PSbuff, "%%---- end of GOOD STUFF; erase to start of your display ------ \n\n") ;
PostScriptOutput(PSbuff);
#endif
}


PostSriptOutput(PSbuff)
char *PSbuff;
{
#ifdef DOPSCRIPT
printf( "%s", PSbuff ) ;
#endif
}
