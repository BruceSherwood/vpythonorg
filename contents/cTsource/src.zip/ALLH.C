
/* dummy routine dependant on disk copies of all include files */

int allh() { return(0); }
