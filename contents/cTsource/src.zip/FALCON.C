
#define FAR

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <X11/Xatom.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <X11/cursorfont.h>

#include "chardef.h"

Display *display;
Window window;
XGCValues gcv;
GC gc;
char imsg[1000];
char *imsgp;
struct pcfont *fontptr = NULL;
int falconw = 0;
int falconh = 0;
char *falconp = NULL;

/* ******************************************************************* */

main(argc,argv)
    int argc;
    char *argv[];

{	XSetWindowAttributes attributes;
    Cursor cursor;
    struct cmenu *menu;

	imsg[0] = '\0';
	imsgp = &imsg[0];
	
    if ((display = XOpenDisplay(NULL)) == NULL) {
        fprintf(stderr, "Couln't open display.\n");
        exit(-1);
    }

    if ((cursor = XCreateFontCursor(display, XC_arrow)) == NULL) {
        fprintf(stderr, "Couln't create cursor.\n");
        exit(-1);
    }

    attributes.background_pixel = WhitePixel(display, DefaultScreen(display));
    attributes.border_pixel = BlackPixel(display, DefaultScreen(display));
    attributes.event_mask = ButtonPressMask | ButtonReleaseMask | ExposureMask;
    attributes.cursor = cursor;

    if ((window = XCreateWindow(display, RootWindow(display, DefaultScreen(display)), 50, 50, 600, 600, 2, CopyFromParent, CopyFromParent, CopyFromParent, CWBackPixel | CWBorderPixel | CWEventMask | CWCursor, &attributes)) == NULL) {
        fprintf(stderr, "Couln't open window.\n");
        exit(-1);
    }

    gcv.foreground = BlackPixel(display, DefaultScreen(display));
    gcv.background = WhitePixel(display, DefaultScreen(display));
    gcv.font = XLoadFont(display, "variable");

    gc = XCreateGC(display, window, GCForeground | GCBackground | GCFont, &gcv);

    XMapRaised(display, window);

	read_falcon();
	
    Interact();

} /* main */

/* ******************************************************************* */

Interact() 

{	XEvent event;
	int atx = 50, aty = 150;
	Window wind;
	Pixmap falconpix;
	XGCValues gcval;

	while (1) {
	
		XNextEvent(display, &event);

		switch (event.type) {

			case Expose: {
				XExposeEvent *exp_event = (XExposeEvent *) &event;

				XClearArea(display,window,exp_event->x,
					    exp_event->y,exp_event->width,
					    exp_event->height,False);
				if (*imsgp) {
					XDrawString(display, window, gc, atx, aty,imsgp,strlen(imsgp));
				} else {
					falconpix = XCreateBitmapFromData(display,window,falconp,falconw,falconh);
					gcval.function = GXxor;
					XChangeGC(display,gc,GCFunction,&gcval); 
					XCopyPlane(display,falconpix,window,gc,0,0,falconw,falconh,atx,aty,1L);																																																				
				}
				break;
			}

			case ButtonPress: {
				XButtonPressedEvent *but_event = (XButtonPressedEvent *) &event;
				if ((but_event->button & 0xff) == Button1) {
    				XSetForeground(display,gc,
					WhitePixel(display, DefaultScreen(display)));
					XDrawString(display, window, gc, atx, aty, "Hello world.", sizeof("Hello world.") - 1);
					atx = but_event->x;
					aty = but_event->y;
    				XSetForeground(display,gc,BlackPixel(display, DefaultScreen(display)));
					XDrawString(display, window, gc, atx, aty, "Hello world.", sizeof("Hello world.") - 1);
				}
				else XBell(display, 0);
				break;
			}

			case ButtonRelease: {
				break;
			}

			default:  {
				break;
			}

		}  /* switch */
	}  /* while loop */

} /* Interact */

/* ******************************************************************* */

read_falcon() /* read falcon logo icon */

{	FILE *fp;
	struct stat statb;
	int ret;
	long fsize;
	char *cp;
	struct pcfont *fontp;
	struct pccharl *cdefp;
	char msg[80];

	fp = fopen("falcon10.fpc","r");
	if (fp == NULL) {
		strcat(imsgp,"file open failed.");
		return;
	}
	ret = stat("falcon10.fpc",&statb);
	if (ret) {
		strcat(imsgp,"file stat failed");
		return;
	}
	fsize = statb.st_size;
	fontp = (struct pcfont *)malloc(fsize);
	ret = fread(fontp,sizeof(char),fsize,fp);
	if (ret != fsize) {
		strcat(imsgp,"file read failed");
		return;
	}
	fontptr = fontp; /* font read */
	cp = (char *)fontptr;
	cp += sizeof(struct pcfont);
	cdefp = (struct pccharl *)cp;
	falconw = cdefp->bnw;
	falconh = cdefp->bnh;
	falconp = (char *)fontptr;
	falconp += fontptr->dmap+cdefp->map;
	fclose(fp);
	
} /* read_falcon */

/* ******************************************************************* */
