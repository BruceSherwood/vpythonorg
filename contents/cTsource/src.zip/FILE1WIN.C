
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989, 1992 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* ******************************************************************* */

#include <io.h>
#include <stdio.h>
#include <dos.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <sys/stat.h>

#define STRICT
#include <windows.h>

#include "baseenv.h"
#include "compute.h"
#include "ecglobal.h"
#include "tfiledef.h"
#include "tglobals.h"

/* ******************************************************************* */
  
extern int TUTORdump(char *ss);
extern int TUTORset_dir(FileRef FAR *path);
extern int TUTORset_file_dir(FileRef FAR *path);
extern char FAR *strcatf(char FAR *aa,char FAR *bb);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
extern int ClearAuthorFile(long vloc);
extern int TUTORclose_socket(struct tutorfile FAR *tp);
char  FAR *GetPtr(unsigned int  mm);
int  ReleasePtr(unsigned int  mm);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
char  *strf2n(char  FAR *strp);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int  killptr(char  FAR * FAR *ptr);
extern TUTORblock_move(char FAR *sp, char FAR *dp, long lth);
char  FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
int  strlenf(char  FAR *aa);
int  strcmpf(char  FAR *aa,char  FAR *bb);
long  TUTORwrite_socket(int  ss,char  FAR *buf,long  len);
long  TUTORread_socket(int  ss,char  FAR *buf,long  maxLen);
int TUTORcopy_fileref(FileRef FAR *fDest,FileRef FAR *fSource);
int TUTORcmp_fileref(FileRef FAR *f1,FileRef FAR *f2);
int TUTORcopy_fileref_name(FileRef FAR *fRef,char FAR *name); 
int TUTORcopy_fileref_dir(FileRef FAR *dirname,FileRef FAR *fullname);
int TUTORinq_fref(int findx,FileRef FAR *fref);
int TUTORsymbolic_fileref(FileRef FAR *fRef,char FAR *syms); 
int TUTORget_fileref_name(FileRef FAR *fRef,char FAR *name);
int TUTORopen(FileRef FAR *fRef,int rf,int wf,int af);
int file_slot(void);
int TUTORclose(int findx);
int TUTORflush_file(int findx);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
long  TUTORwrite(char  FAR *ptr,int  pSize,long  count,int  findx);
long  flrdwr(char  FAR *ptr,int  pSize,long  count,int  findx,int  rwFlag);
int TUTORfile_at_eof(int findx);
int TUTORstat(FileRef FAR *fRef,struct stat *buff);
long TUTORinq_file_pos(int findx); 
int TUTORinq_file_err(int findx);
int TUTORset_file_type(FileRef FAR *fRef,int findx,int type,int xx,int yy);
int TUTORreset_file(int findx,int option); 
int TUTORtemp_file_name(FileRef FAR *baseN,FileRef FAR *tempN); 
int TUTORungetc(int findx,int cc);
int TUTORget_char(int findx,int tryHard);
int TUTORread_char(unsigned char *cc,int findx);
int TUTORread_string(unsigned char *str,int length,int findx); 
int TUTORread_short(short *ss,int findx);
int TUTORread_int(int *ii,int findx);
int TUTORfile_exists(FileRef FAR *fRef);
int TUTORdelete_file(FileRef FAR *fRef);

/* ******************************************************************* */

#define RMODE "rb"
#define RMODEB "rb"
#define WMODE "wb"
#define WMODEB "wb"
#define WRMODE "wb+"
#define RWMODE "rb+"
#define AMODE "ab"
#define AMODEB "ab"

extern FileRef swapRef;

/* ******************************************************************* */

void ftime(timeptr) /* supply ftime for ANSI C */
struct timeb *timeptr;
{
    _ftime((struct _timeb *)timeptr);

} /* ftime */

/* ******************************************************************* */

TUTORcopy_fileref(fDest,fSource)
FileRef FAR *fDest, FAR *fSource;

{
    strcpyf(fDest->path,fSource->path);
    fDest->nameInd = fSource->nameInd;
    fDest->drive = fSource->drive;  
    return(0);

} /* TUTORcopy_fileref */

/* ******************************************************************* */

TUTORcmp_fileref(f1,f2) /* returns 0 if FileRefs are the same */
FileRef FAR *f1;
FileRef FAR *f2;

{	char FAR *sp1;
	char FAR *sp2;
	int cc1,cc2;
	
    if (f1->drive == f2->drive && f1->nameInd == f2->nameInd) {
		sp1 = f1->path;
		sp2 = f2->path;
		while (TRUE) {
			if (*sp1 == *sp2) {
				if (*sp1 == 0)
					return(0); /* end of string */
				sp1++; 
				sp2++;
			} else {
				cc1 = *sp1;
				cc2 = *sp2;
				if ((cc1 >= 'A') && (cc1 <= 'Z'))
					cc1 = cc1-'A'+'a'; /* convert to lower case */
				if ((cc2 >= 'A') && (cc2 <= 'Z'))
					cc2 = cc2-'A'+'a'; /* convert to lower case */
				if (cc1 == cc2) {
					sp1++; /* advance to next character */
					sp2++;
				} else
					return(1); /* doesn't match */
			} /* else */
		} /* while */
    } else
    	return(1); /* they are not the same */

} /* TUTORcmp_fileref */

/* ******************************************************************* */

TUTORcopy_fileref_name(fRef,name)
FileRef FAR *fRef; /* use directory reference from here */
char FAR *name; /* use this as file name */

{
    if (fRef->nameInd + strlenf(name) > FILEL)
        TUTORdump("file path too long in TUTORcopy_fileref_name");
    strcpyf(fRef->path + fRef->nameInd,name); 
    return(0);

} /* TUTORcopy_fileref_name */

/* ******************************************************************* */

TUTORcopy_fileref_dir(dirname, fullname) /* copy directory path */
FileRef FAR *dirname;    /* path to have only directory set */
FileRef FAR *fullname;    /* full path */ 
    
{   int len;
     
    len = strlenf(fullname->path)-1;
    while (len >= 0) { /* be sure name index correct */
    	if ((fullname->path[len] == '/') ||
    		(fullname->path[len] == '\\') ||
    		(fullname->path[len] == ':')) {
    			fullname->nameInd = len+1; 
    			break; /* exit while */
    		} 
    		len--;
    } /* while */
    dirname->drive = fullname->drive;
    len = fullname->nameInd;
    strncpyf(dirname->path,fullname->path,len);
    dirname->path[len] = '\0'; /* null terminate, we have no name */
    dirname->nameInd = len;  
    return(0);

} /* TUTORcopy_fileref_dir */

/* ******************************************************************* */

TUTORinq_fref(findx,fref)
int findx;  /* file index */
FileRef FAR *fref;  /* to be filled with fileref of file whose index is find */
    
{   struct tutorfile FAR *tfp;
    
    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to file table entry */

    TUTORblock_move((char FAR *) &(tfp->fRef),(char FAR *) fref,
                    (long) sizeof(FileRef));
    ReleasePtr(filesopen);
    KillPtr(tfp);
    
    return(TRUE);

} /* TUTORinq_fref */

/* ******************************************************************* */

#ifdef NOSUCH

int  TUTORget _fileref _dir(fRef,name) /* get the directory of an fRef */
FileRef FAR *fRef;
char FAR *name;

{    char FAR *cp;
    
    strcpyf(name,fRef->path);
    cp = name+strlenf(name)-1;
    while ((cp != name) && (*cp != '\\') && (*cp != '/'))
        cp--;
    if (*cp == '\\' || *cp == '/') {
        *cp = '\0';
    } else {
        name[0] = '\0';
    }

} /* TUTORget_ fileref_ dir */

#endif

/* ******************************************************************* */

TUTORsymbolic_fileref(fRef,syms)
FileRef FAR *fRef; /* to be set up for symbolic fRef */
char FAR *syms; /* symbolic string */

{
    /* a symbolic string on the pc can be detected by noting that the */
    /* first char of path is NOT \ */
    strcpyf(fRef->path,syms);
    fRef->nameInd = 0;
    fRef->drive = ctDirP->drive; /* use drive cT is on */  
    return(0);

} /* TUTORsymbolic_fileref */

/* ******************************************************************* */

TUTORget_fileref_name(fRef,name) /* return the name of an fRef */
FileRef FAR *fRef;
char FAR *name;

{
    strcpyf(name,fRef->path+fRef->nameInd); 
    return(0);

} /* TUTORget_fileref_name */

/* ******************************************************************* */

int file_slot() /* locate free file table slot */

{   struct tutorfile FAR *tfp;
    int ii;

    /* search for unused slot */

    tfp = ((struct tutorfile FAR *)GetPtr(filesopen))+1;
    for (ii = 1; ii < (int)filesmalloc; ii++, tfp++) /* skip slot 0 */
    if (!tfp->inuse)
        break;

    /* allocate new slot */

    if (ii >= (int)filesmalloc) {
    	ReleasePtr(filesopen);
    	filesmalloc++;
    	TUTORset_hsize(filesopen,(long)(filesmalloc*sizeof(struct tutorfile)),TRUE);
    	tfp = (struct tutorfile FAR *) GetPtr(filesopen);
    	ii = filesmalloc-1; /* index of empty slot */
    	tfp += ii; /* point to empty slot */
    	tfp->inuse = FALSE;
    } /* ii if */
    tfp->vloc = -1;
    tfp->styles_allowed = FALSE;
    tfp->format = -1;
    tfp->crKind = -1;
    tfp->fp = 0L;
    tfp->stream = -1;
    tfp->buffer = FARNULL;
    ReleasePtr(filesopen);
    return(ii); /* always slot 1 or above */

} /* file_slot */

/* ******************************************************************* */

TUTORfile_exists(fRef) /* return TRUE if file "s" exists */
FileRef FAR *fRef;

{   long length;

    if (fRef->path[0] == 0)
    	return(FALSE);
    TUTORinq_file_info(fRef,NEARNULL,&length,NEARNULL,NEARNULL,NEARNULL);
    if (length >= 0)
    	return(TRUE);
    else
    	return(FALSE);

} /* TUTORfile_exists */

/* ******************************************************************* */

TUTORset_file_type(fRef,findx,type,xx,yy)  /* set file's operating system type */
FileRef FAR *fRef;
int findx; /* file index */
int type; /* 1: AUTHOR, 2: EXECUTOR */
int xx, yy; /* file icon location (-10000 if not to be used) */
    
{
    return 0; /* dos doesn't support file types... */

} /* TUTORset_file_type */

/* ******************************************************************* */

int TUTORopen(fRef,rf,wf,af) /* open file */
FileRef FAR *fRef;
int rf; /* TRUE if read access */
int wf; /* TRUE if write access */
int af; /* TRUE if append */

{   struct tutorfile FAR *tfp; /* pointer to file table entry */
    int ii;
    char *fstr; /* pointer to r/w/a string */
    UINT curErrorMode;
	FileRef svRef; /* saved current directory */
	char openStr[CTPATHLEN]; /* string for fopen */

    /* set up file table entry */

    tfilerr = -1; /* no error yet */
    ii = file_slot(); /* locate free file table slot */
    tfp = ii+(struct tutorfile FAR *) GetPtr(filesopen);
    tfp->inuse = TRUE; /* mark file table entry in use */
    tfp->lastop = fop_open; /* no operations yet */
    tfp->ro = ((!wf) && (!af)); /* set read-only flag */
    tfp->styles_allowed = FALSE;
    tfp->format = -1;
    tfp->crKind = -1;
    tfp->kind = 0; /* normal file */
    TUTORcopy_fileref(&tfp->fRef,fRef);

    /* set up read / write info */

    if (af && rf) fstr = "ab+"; /* build file access type */
    else if (af) fstr = "ab";
    else if (wf && (!rf)) fstr = "wb";
    else if (wf) fstr = "rb+";
    else fstr = "rb";
	
	/* open file */

	openStr[0] = 0;
	if ((fRef->path[0] == '\\') || (fRef->path[0] == '/')) {
		if (fRef->drive > 0) { /* attach drive specifier */
			openStr[0] = fRef->drive+'A'-1;
			openStr[1] = ':';
			openStr[2] = 0;
		}
		strcatf((char FAR *)openStr,fRef->path);
	} else strcpyf((char FAR *)openStr,fRef->path);
	if (currentDirP) {
		svRef = *currentDirP; /* save current directory */
		TUTORset_file_dir((FileRef FAR *)fRef);
	}
    curErrorMode = SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOOPENFILEERRORBOX);
    tfp->fp = fopen(openStr,fstr);
	if (currentDirP)
		TUTORset_dir((FileRef FAR *)&svRef); /* restore directory */
    SetErrorMode(curErrorMode);
    if (tfp->fp == NULL) {
    	tfp->inuse = FALSE;
    	tfilerr = FILEPERMIT; /* permission not granted */
    	ReleasePtr(filesopen);
    	return(0);
    } /* fp if */

    ReleasePtr(filesopen);

    return(ii); /* return index in file table */

} /* TUTORopen */

/* ******************************************************************* */

TUTORclose(findx) /* close file */
int findx; /* index in file table (returned by TUTORopen) */

{   struct tutorfile FAR *tfp;    
    FILE *ffp;

    if (findx <= 0)
	return(0);

    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    ffp = tfp->fp;

    if (tfp->vloc >= 0)
        ClearAuthorFile(tfp->vloc); /* author file, clear variable */

    switch (tfp->kind) {
    case 0: /* normal file */
        if (ffp) fclose(ffp);
        break;
    case 1: /* serial port */
/*	CloseComm(tfp->stream); */
        break;
    case 2: /* socket */
	TUTORclose_socket(tfp);
        break;
    case 4: /* EMS */
        break;
    case 5: /* XMS */
        break;
    default:
        TUTORdump("Unknown type of file in TUTORclose");
        break;
    } /* switch */

    tfp->inuse = FALSE;
    tfp->fRef.path[0] = '\0';
    tfp->vloc = -1;
    tfp->fp = NULL;
    tfp->stream = 0;
    ReleasePtr(filesopen); 
    return(0);

} /* TUTORclose */

/* ******************************************************************* */

TUTORinq_file_info(fRef,waccess,length,modtim,posx,posy)
FileRef FAR *fRef;
int *waccess; /* TRUE if have write access to file */
long *length; /* length of file */
    /* -1 if file does not exist */
long *modtim; /* time of last modification */
int *posx; /* x position of file icon */
int *posy; /* y position of file icon */

{   struct stat fst; /* file status block */  
    int sr; /* stat return */ 

    /* get file status if neccessary */

    if (waccess || length || modtim) {
    sr = TUTORstat(fRef,&fst);
    if (sr) {
        fst.st_size = -1; /* clear fields if stat failed */
        fst.st_mode = 0;
        fst.st_mtime = 0;
    } /* sr if */
    } /* access if */

    /* return write permission status if requested */

    if (waccess) *waccess = TRUE;

    /* return file length if requested */

    if (length) *length = fst.st_size;

    /* return time of last modification if requested */

    if (modtim) *modtim = fst.st_mtime;

    /* return file icon position if requested */

    if (posx) *posx = -10000; /* no position for wm */
    if (posy) *posy = -10000;   
    return(0);

} /* TUTORinq_file_info */

/* ******************************************************************* */

long TUTORinq_file_pos(findx) /* get current read/write position */
int findx; /* index of file */

{   struct tutorfile FAR *tfp; /* pointer to file table entry */
    long pos; /* file position */

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to file table entry */
    switch (tfp->kind) {
    case 0:
        pos = ftell(tfp->fp);
        break;
    default:
	pos = 0;
        break;
    } /* switch */
    
    ReleasePtr(filesopen);
    return pos;

} /* TUTORinq_file_pos */

/* ******************************************************************* */

int TUTORinq_file_err(findx) /* returns TRUE if error has occurred */
int findx;

{   struct tutorfile FAR *tfp; /* pointer to file table entry */
    int fret; /* error return */

    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    switch (tfp->kind) {
    case 0:
        fret = ferror(tfp->fp);
        break;
    default:
	fret = 0;
        break;
    }
    ReleasePtr(filesopen);
    return(fret ? TRUE: FALSE);

} /* TUTORinq_file_err */

/* ******************************************************************* */

TUTORstat(fRef,buff)
FileRef FAR *fRef;
struct stat *buff;

{   int sr;
    UINT curErrorMode;
	FileRef svRef;

	if (currentDirP) {
		svRef = *currentDirP; /* save current directory */
		TUTORset_file_dir(fRef);
	}
    curErrorMode = SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOOPENFILEERRORBOX);
    sr = _stat(strf2n(fRef->path),(struct _stat *)buff); /* get file status info */
	if (currentDirP)
		TUTORset_dir((FileRef FAR *)&svRef); /* restore directory */
    SetErrorMode(curErrorMode);
    return(sr);
}

/* ******************************************************************* */

TUTORseek(findx,pos) /* seek to specified position in file */
int findx; /* index of file in file table */
long pos; /* position */

{   struct tutorfile FAR *tfp; /* pointer to file table entry */

    tfp = findx + (struct tutorfile FAR *)GetPtr(filesopen);
    switch (tfp->kind) {
    case 0:        /* plain file */
        fseek(tfp->fp, pos,0);
        break;
    case 4:        /* EMS */
        break;
    case 5:        /* XMS */
        break;
    } /* switch */
    
    ReleasePtr(filesopen);  
    return(0);

} /* TUTORseek */

/* ******************************************************************* */

long TUTORwrite(ptr,pSize,count,findx)
char FAR *ptr; /* buffer to write out */
int pSize; /* size of item */
long count; /* # of items to write out */
int findx;
/* returns # of bytes written */
    
{
    return(flrdwr(ptr,pSize,count,findx,FALSE));

} /* TUTORwrite */

/* ******************************************************************* */

long TUTORread(ptr,pSize,count,findx)
char FAR *ptr; /* buffer to fill */
int pSize; /* size of item */
long count; /* # of items to write out */
int findx;
/* returns # of bytes read */
    
{
    return(flrdwr(ptr,pSize,count,findx,TRUE));

} /* TUTORread */

/* ******************************************************************* */

TUTORwrite_int(ii,findx)
int ii;
int findx;

{   struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */

    switch (tfp->kind) {

    case 0: /* plain file */
        tfp->lastop = fop_write;
        fwrite(&ii,sizeof(int),1,tfp->fp);
	break;

    case 1: /* serial port */
	TUTORwrite((char FAR *)&ii,1,(long)sizeof(int),findx);
	break;

    default:
        break;
    }

    ReleasePtr(filesopen);   
    return(ii);

} /* TUTORwrite_int */

/* ******************************************************************* */

TUTORread_int(ii,findx)
int *ii;
int findx;
    
{   struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *) GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    switch (tfp->kind) {

    case 0:
        tfp->lastop = fop_read;
        fread(ii,sizeof(int),1,tfp->fp);
	break;

    case 1: /* serial port */
	ii = 0;
	TUTORread((char FAR *)ii,1,(long)sizeof(int),findx);
	break;

    default:
        break;
    }
    ReleasePtr(filesopen);    
    return(*ii);

} /* TUTORread_int */

/* ******************************************************************* */

TUTORwrite_short(ss,findx)
short ss;
int findx;
    
{
    struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */

    switch (tfp->kind) {

    case 0:
        tfp->lastop = fop_write;
        fwrite(&ss,sizeof(short),1,tfp->fp);
	break;

    case 1:
	TUTORwrite((char FAR *)&ss,1,(long)sizeof(short),findx);
	break;

    default:
        break;
    }
    ReleasePtr(filesopen); 
    return(ss);

} /* TUTORwrite_short */

/* ******************************************************************* */

TUTORread_short(ss,findx)
short *ss;
int findx;
    
{
    struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */

    switch (tfp->kind) {

    case 0:
        tfp->lastop = fop_read;
        fread(ss,sizeof(short),1,tfp->fp);
	break;

    case 1:
	*ss = 0;
	TUTORread((char FAR *)ss,1,(long)sizeof(short),findx);
	break;

    default:
        break;
    }
    ReleasePtr(filesopen);   
    return(*ss);

} /* TUTORread_short */

/* ******************************************************************* */

TUTORwrite_char(cc,findx)
unsigned char cc;
int findx;
    
{   struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */

    switch (tfp->kind) {

    case 0:
        tfp->lastop = fop_write;
        fwrite(&cc,sizeof(unsigned char),1,tfp->fp);
	break;

    case 1:
	TUTORwrite((char FAR *)&cc,1,(long)sizeof(char),findx);
	break;

    default:
        break;
    }

    ReleasePtr(filesopen);    
    return(cc);

} /* TUTORwrite_char */

/* ******************************************************************* */

TUTORread_char(cc,findx)
unsigned char *cc;
int findx;
    
{   struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */

    switch (tfp->kind) {
    case 0: /* normal file */
        tfp->lastop = fop_read;
	fread(cc,sizeof(unsigned char),1,tfp->fp);
	tfp->lastC = *cc;
	break;

    case 1: /* serial */
	TUTORread((char FAR *)cc,1,(long)sizeof(char),findx);
	tfp->lastC = *cc;
	break;

    default:
        break;
    }
    ReleasePtr(filesopen);  
    return(*cc);

} /* TUTORread_char */

/* ******************************************************************* */

int TUTORget_char(findx, tryHard) /* read+return character or EOF */
int findx;
int tryHard; /* if TRUE, try hard (retry io port) to get character */

{   struct tutorfile FAR *tfp;
    int cc = EOF, ii;

    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);

    switch (tfp->kind) {

    case 0: /* normal file */
        tfp->lastop = fop_read;
        cc = fgetc(tfp->fp); /* file */
	break;

    case 1: /* serial port */
	ii = (int)TUTORread((char FAR *)&cc,1,(long)sizeof(char),findx);
	if (ii <= 0) cc = EOF;
	break;

    default:
	break;

    } /* switch */

    tfp->lastC = cc; /* remember last char read */
    ReleasePtr(filesopen);
    return(cc);

} /* TUTORget_char */

/* ******************************************************************* */

int TUTORread_string(str,length,findx) /* read newline-terminated string */
unsigned char *str; /* pointer to buffer to read into */
int length; /* maximum length to read */
int findx; /* file index */
    
{   struct tutorfile FAR *tfp; /* pointer to ct file table entry */
    int nc; /* number characters read */
    int cc; /* last character read */

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */

    switch (tfp->kind) {

    case 0: /* normal file */
    case 1: /* serial */
	tfp->lastop = fop_read;
	if (tfp->kind == 0) {
	    if ((feof(tfp->fp)) || (length <= 0)) {
		ReleasePtr(filesopen);
		return(0); /* nothing read */
	    } /* feof if */
	} /* kind if */
        nc = 0;
        cc = 0; /* for top of while test */
	do {
	    cc = TUTORget_char(findx,TRUE);
	    if (cc == EOF) cc = NEWLINE;
	    str[nc++] = cc;
        } while (cc != NEWLINE && nc < length);
	break;

    default:
        TUTORdump("Invalid file type in TUTORread_string");
        break;
    } /* switch */
    ReleasePtr(filesopen);
    return(nc);

} /* TUTORread_string */

/* ******************************************************************* */

long TUTORread_number(findx)
int findx;
    
{   struct tutorfile FAR *tfp;
    long lret;

    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);

    switch (tfp->kind) {

    case 0:
        tfp->lastop = fop_read;
        fscanf(tfp->fp,"%ld",&lret);
	break;

    default:
	lret = 0;
        break;
    }
    ReleasePtr(filesopen);
    return lret;

} /* TUTORread_number */

/* ******************************************************************* */

TUTORungetc(findx,cc)
int findx;
int cc;

{   struct tutorfile FAR *tfp;
    int ret;

    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    switch (tfp->kind) {
    case 0:
        ret = ungetc(cc,tfp->fp);
        break;
    case 1:
	ret = 0;
        break;
    default:
        break;
    }
    ReleasePtr(filesopen);

    return ret;
}

/* ******************************************************************* */

#define CHUNKSZE 1024

static long flrdwr(rwptr,pSize,count,findx,rwFlag) /* long read or write */
char FAR *rwptr;    /* where the read is going */
int pSize;    /* size of object */
long count;    /* # of objects */
int findx;    /* index in file table */
int rwFlag;    /* TRUE: read, FALSE: write */
    
{   int nReads,ii, nNew, toRead;
    long nIn;
    char FAR *fbuf; /* long pointer to local buffer */
    long chunkSize; /* size of chunk to read/write */
    char buf[CHUNKSZE+2]; /* local buffer for read/write */
    FILE *fp; /* file stream */
    struct tutorfile FAR *tfp;
    int kind, stream;
    char SHUGE *ptr; /* pointer to data read/written */

    nIn = 0;
    ptr = rwptr; /* use huge ptr so arithmetic works */
    chunkSize = CHUNKSZE;
    tfp = (struct tutorfile FAR *) GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    fp = tfp->fp; /* get FILE pointer */
    tfp->lastop = (rwFlag ? fop_read: fop_write);
    kind = tfp->kind;
    stream = tfp->stream;
    count *= pSize; /* now just working in bytes */

    ReleasePtr(filesopen);
    if (!count)
	return(nIn);
    
    if (ptr == NULL)
	TUTORdump("flrdwr bad pointer");
    if (kind == 4)
        return(0);
    if (kind == 5)
        return(0);
    if (kind == 0) {
	if (fp == NULL)
	    TUTORdump("flrdwr bad file pointer");
    }

    nReads = (int)((count-1)/chunkSize);
    for (ii=0; ii<=nReads; ii++) {
	toRead = (int)((ii == nReads) ? (count - nReads*chunkSize) : chunkSize);
	if (rwFlag) {
	    if (kind == 0) { /* normal file */
		nNew = fread(buf,1,toRead,fp);
		fbuf = buf; /* far pointer to local buffer */
		TUTORblock_move(fbuf,ptr,(long)nNew);
	    } else if (kind == 1) { /* serial */
/*		nNew = ReadComm(stream,ptr,(int)toRead); */
		if (nNew < 0) nNew = 0;
		return(nNew); /* however much we read */
	    } else if (kind == 2) {
		nNew = (int)TUTORread_socket(findx,(char FAR *)buf,(long)toRead);
		fbuf = buf; /* far pointer to local buffer */
		TUTORblock_move(fbuf,ptr,(long)toRead);
	    }
	} else {
	    fbuf = buf; /* far pointer to local buffer */
	    TUTORblock_move(ptr,fbuf,(long)toRead);
	    if (kind == 0) {
		nNew = fwrite(buf,1,toRead,fp);
	    } else if (kind == 1) { /* serial */
/*		nNew = WriteComm(stream,ptr,(int)toRead); */
		if (nNew < 0) nNew = 0;
		return(nNew); /* however much we wrote */
	    } else if (kind == 2) {
		buf[toRead] = 0;
		TUTORwrite_socket(findx,(char FAR *)buf,(long)toRead);
	    }
	} /* else */
	if (nNew == 0) {
	    if (feof(fp))
			return(nIn); /* read to end of file */
	    return(0L); /* error */
	} /* nNew if */
	nIn += nNew;
	ptr += toRead;
	if (nNew < toRead)
	    break;
    } /* for */
    if (!rwFlag && kind == 1) {
		ii = fflush(fp);
		if (ii) 
			nIn = -1; /* something went wrong */
	}
    return(nIn);

} /* flrdwr */

/* ******************************************************************* */

TUTORreset_file(findx,option) /* reset to begin, end, or empty */
int findx; /* index in file table */
int option; /* option = 0 for start, 1 for end, 2 for empty */

{   struct tutorfile FAR *tfp;
	FileRef svRef;

    tfilerr = -1; /* no error yet */
    tfp = findx+(struct tutorfile FAR *) GetPtr(filesopen);

    switch (option) {

    case 0: /* start of file */
    if (tfp->kind == 0) { /* this only makes sense for normal file */
		fseek(tfp->fp, 0L, 0);
		tfp->lastop = fop_begin;
    }
    break;

    case 1: /* end of file */
    if (!tfp->ro) 
		fflush(tfp->fp); /* flush if write-able */
    if (tfp->kind == 0)
		fseek(tfp->fp,0L,2); /* seek to end if real file */
    tfp->lastop = fop_end;
    break;

    case 2: /* empty the file */
    if (tfp->ro) { /* read only */
		tfilerr = FILEPERMIT;
		ReleasePtr(filesopen);
		return(0);
    } /* filesopen if */
    if (tfp->kind == 1) { /* not meaningful for serial port */
		ReleasePtr(filesopen);
		return(0); 
    } /* serial port if */
    fclose(tfp->fp);
	svRef = *currentDirP; /* save current directory */
    TUTORset_file_dir(&tfp->fRef);
    tfp->fp = fopen(strf2n(tfp->fRef.path),WRMODE); /* truncate the file */
    TUTORset_dir((FileRef FAR *)&svRef); /* restore directory */
    if (tfp->fp == NULL) {
		TUTORclose(findx); /* close file if re-open failed */
		tfilerr = FILEPERMIT;
		ReleasePtr(filesopen);
		return(0);
    } /* open failed if */
    tfp->lastop = fop_empty;
	break;

    } /* switch */

    ReleasePtr(filesopen);
    return(0);

} /* TUTORreset_file */

/* ******************************************************************* */

TUTORtemp_file_name(baseN,tempN)    /* create a temporary file name */
FileRef FAR *baseN; /* base name, used for directory path */
FileRef FAR *tempN; /* to be filled with a currently unused file name */
/* returns TRUE for success */

{   char tnm[FILEL];
    char FAR *result;
    int ret;

    /* we are creating a file name which will not overwrite any other file */

    if (baseN)
	TUTORcopy_fileref(tempN,baseN);
    else
	TUTORcopy_fileref(tempN,(FileRef FAR *)&swapRef);

    TUTORcopy_fileref_name(tempN, (char FAR *) "cTXXXXXX");
    strcpyf((char FAR *)tnm,tempN->path);
    result = _mktemp(tnm);
    ret = !(result == NULL);
    strcpyf(tempN->path,result);
    return (ret);

} /* TUTORtemp_file_name */

/* ******************************************************************* */
