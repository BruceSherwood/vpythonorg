
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Declarations for editor (& compiler)
KSW 9/88
*/

#include "baseenv.h"
#include "edglobal.h"

#ifdef ctproto
#endif /* ctproto */

Memh vsource;	/* pointer to view on source */

Memh editmenus;	/* editor menu definitions */
Memh dictH; /* dictionary info */

Memh searchH; /* search window */
char FAR *curSelUnit; /* currently selected unit */
int curSelEdit; /* index of editor on currently selected unit */

char binaryFileCurrent; /* TRUE if current binary matches binary file */

