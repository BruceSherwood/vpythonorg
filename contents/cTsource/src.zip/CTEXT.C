
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>
#include "baseenv.h"
#include "txt.h"
#include "chardef.h"
#include "kglobals.h"
#include "tglobals.h"

#ifdef WINPC
#include <windows.h>
#include "ctmsw.h"
#endif

#ifdef MAC
#include <Quickdraw.h>
#ifdef THINKC5
#include <Windows.h>
#include <Quickdraw.h>
#include <Palettes.h>
#include <QDOffscreen.h>
#else
#ifdef WERKS
#include <Windows.h>
#include <Quickdraw.h>
#include <Palettes.h>
#include <QDOffscreen.h>
#else
#include <WindowMgr.h>
#include <Color.h>
#endif
#endif
extern int systemVersion; /* Macintosh system version */
#endif /* mac */

/* handling of special text - insets and multi-byte text */

#ifdef ctproto
extern Memh TUTORalloc_palette(int pSlots);
extern long TUTORcopy_region(long regid);
extern TUTORfree_region(long regid);
static Memh TUTORcopy_stext(int type,Memh srcH);
extern TUTORabs_restore_region(long id,int x1,int y1);
int  AllowHandlePurge(unsigned int  mm);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
extern char FAR *fpc_char(struct pcfont FAR *fpcP,long charI,
              struct pccharl *charDef);
extern int fpc_draw_char(Memh ftH,struct pcfont FAR *ftP,int cc);
int  TUTORabs_move_to(int  x,int  y);
extern int TUTORinq_abs_pen_pos(int *xx,int *yy);
int TUTORinq_icon_size(int fontid,int iconN,int *dx,int *dasc,int *ddes);
int  TUTORget_font2(long  fam,int  size,unsigned int  face,int cid);
long  TUTORparse_font_family(struct  _fref *fontTag,struct  _fref *familyName,int  isFont,int  oneTag,int  *fontSize);
int  TUTORsymbolic_fileref(struct  _fref FAR *fRef,char  FAR *syms);
int  TUTORis_symbolic(char  *ss);
int  TUTORcvt_path(char  *ssx,struct  _fref FAR *fRef,struct  _fref FAR *baseRef,int fileF);
int cvt_font_name(char *nstr);
int  TUTORinq_abs_string_width(unsigned char  FAR *s,int  lth,int *dx);
int  TUTORinq_abs_string_width16(unsigned char  FAR *s,int  lth,int *dx);
int  TUTORinq_font_info(int  *ascent,int  *descent,int  *maxwidth,int  *leading);
int  TUTORset_textfont(int  jj);
int  TUTORdraw_graphic_icons(int  iconFont,char  *s,int  len);
int  TUTORdraw_alpha_icons(int  iconFont,char  *s,int  len);
int TUTORinq_icon_code_size(int famN);
int DrawStextPixmap(Memh pixH);
int DrawStextIcons(Memh iconDatH); 
unsigned int  TUTORnew_stext(void);
int  TUTORclose_stext(unsigned int  st);
int  TUTORadd_stext(unsigned int  st,long  pos,int  type,unsigned int  dat);
int  TUTORdelete_stext(unsigned int  st,long  pos,long  len);
int  TUTORinsert_stext(unsigned int  st,long  pos,long  newLen);
int  TUTORsplice_stext(unsigned int  st,unsigned int  fromSt,long  pos,long  fromPos,long  fromLen);
int  TUTORdraw_stext(struct  _stxt2 FAR *st1p);
int  TUTORmeasure_stext(struct  _stxt2 FAR *st1p,int  *asc,int  *desc,int  *lead);
extern int  DeleteSText(struct  _spt2 FAR *stp,int  ind,long  pos,long  len);
int  TUTORfind_stext(struct  _spt2 FAR *stp,long  pos);
int  TUTORdraw_pcchar(unsigned int  pch,int  cc);
unsigned int  TUTORcopy_handle(unsigned int  mm);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORinsert_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nIns);
int  TUTORfree_handle(unsigned int  mm);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORabs_move(int  x,int  y);
int  wmg_font(long  fonth);
int  TUTORdraw_text(unsigned char  FAR *buf,int  count);
unsigned int  wmg_inq_current_font(void);
int  TUTORdelete_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nDel);
int  TUTORdump(char  *s);
#endif /* ctproto */

#ifdef macproto
#ifndef THINKC5
#ifndef WERKS
extern int sprintf(char *ss, char *form,...);
#endif
#endif
PicHandle MakePict_stext(Memh pch);
extern Memh TUTORclip_copy_stext(Memh specialT, long pos, long len, PicHandle *ph);
extern Memh TUTORclip_uncopy_stext(Handle sh);
extern Memh TUTORpict_to_char(PicHandle pictH);
extern int TUTORset_hsize(Memh mm,long newSize, int abort);
extern int TUTORblock_move(char SHUGE *s1,char SHUGE *s2,long nn);
extern Memh TUTORaffix_handle(Handle theH, char *name,int tMem);
extern int TUTORzero(char SHUGE *zp, long len);
long  TUTORget_hsize(unsigned int  mm);
#endif

extern char FAR *GetPtr();
extern Memh TUTORhandle();
extern Memh TUTORcopy_handle();
extern long TUTORget_hsize();
extern Memh wmg_inq_current_font();
extern Memh TUTORcopy_stext();

/* ksw-documentation
Every inset gets a seperate SText block.
For the time being, every character of multi-byte text gets a seperate block
also.  This will do while there are only a few characters.  When there are
many such characters, a better scheme (storing all the multi-bytes for a
continuous section of text in a single handle) will be needed.

As a result of this, every SText block has a length of 1
*/

Memh TUTORnew_stext()   /* create a new special text structure */
    {
    Memh st;    /* the special text structure being created */
    REGISTER SpecialTP stp; /* pointer to st */
    
    st = TUTORhandle("SpecialT",(long) sizeof(SpecialT),TRUE);
    stp = (SpecialTP) GetPtr(st);
    stp->self = st;
    
    /* set up dynamic array */
    stp->nArrays = 1;
    stp->totalSize = sizeof(SpecialT);
    stp->offsets = ((char FAR *) &stp->head.dAnn) - ((char FAR *) &stp->self);
    stp->head.dAnn = 0;   /* no items currently in use */
    stp->head.dAnAlloc = 1;   /* but we have already allocated space for 1 item */
    stp->head.nBuff = 3;
    stp->head.itemSize = sizeof(SText);
    
    ReleasePtr(st);
    KillPtr(stp);
    
    return(st);
    }

TUTORclose_stext(st)    /* get rid of the entire special text structure */
Memh st;    /* special text structure to dispose */
    {
    REGISTER SpecialTP stp; /* pointer to special text */
    register int ii;
    register SText FAR *st1p;   /* pointer to insets in special text dynamic array */
    
    stp = (SpecialTP) GetPtr(st);
    
    /* free the data for each inset */
    st1p = (SText FAR *) stp->text; /* get pointer to first inset */
    for (ii=0; ii < stp->head.dAnn; ii++, st1p++)
        { /* for all existing insets, just free the data */
        if (st1p->type == PIXMAPSPECIAL)
        	TUTORfree_region(st1p->dat);
        else
        	TUTORfree_handle(st1p->dat);
        }
    
    ReleasePtr(st);
    KillPtr(stp);
    
    TUTORfree_handle(st);   /* free the special text structure */
    
    return(0);
    }

TUTORadd_stext(st,pos,type,dat) /* insert stext at some position */
Memh st;    /* the special text structure we are adding to */
long pos;   /* position (in document) where the new inset goes */
int type;   /* type of inset */
Memh dat;   /* the data for the inset */
    {
    REGISTER SpecialTP stp; /* pointer to special text */
    register SText FAR *st1p;   /* pointer to insets in special text dynamic array */
    register int ind;   /* index of st1p in the dynamic array */
    
    /* written assumming all stexts have len of 1 (insets only) */
    
    stp = (SpecialTP) GetPtr(st);
    
    /* get index of block at, or after, pos */
    ind = TUTORfind_stext(stp,pos);
    if (ind < 0)
        ind = stp->head.dAnn; /* we are past last item */
    
    /* add new stext */
    ReleasePtr(st);
    KillPtr(stp);
    TUTORinsert_darray(st,FARNULL,STOFFSET,0,ind,1); /* expand st darray at position ind */

    stp = (SpecialTP) GetPtr(st);
    
    /* fill out fields of dynamic array element at ind (the new one) */
    st1p = stp->text + ind;
    st1p->type = type;
    st1p->dat = dat;
    st1p->pos = pos;
    st1p->len = 1L;
    
    ReleasePtr(st);
    KillPtr(stp);
    
    return(0);
    }

TUTORdelete_stext(st,pos,len)
Memh st;    /* the special text structure we are deleting from */
register long pos,len;  /* the bounds (in document positions) where text is being deleted */
/* returns TRUE if there are special styles left after deletion */
    {
    REGISTER SpecialTP stp; /* pointer to special text */
    register SText FAR *st1p;   /* pointer to insets in special text dynamic array */
    register int ind;   /* index of st1p in dynamic array */
    int retVal; /* the return value */
    
    /* written assumming all stexts have len of 1
        this means we don't have to worry about some inset being partially deleted */
    
    stp = (SpecialTP) GetPtr(st);
    
    /* find index of item at or after pos */
    ind = TUTORfind_stext(stp,pos);
    if (ind < 0) { /* no items found at/after pos */
        ReleasePtr(st);
        return(TRUE);
    }

    /* delete all the items in the range */
    DeleteSText(stp,ind,pos,len);
    
    /* items following pos need their positions shifted back */
    st1p = ((SText FAR *) stp->text) + ind;
    for (;ind < stp->head.dAnn; ind++,st1p++)
        st1p->pos -= len;
    
    retVal = stp->head.dAnn > 0; /* check if there are any items left */
    ReleasePtr(st);
    KillPtr(stp);
    
    return(retVal);
    }

/* when a document that has special text is changed, either TUTORinsert_stext will be
    called (no special text being added), or TUTORsplice_stext will be called (special
    text is added in the change) */

TUTORinsert_stext(st,pos,newLen) /* adjust special text for insertions in document */
Memh st;    /* the special text structure needing to be updated */
long pos;   /* where (in the document) new text was added */
long newLen;    /* how many characters were added to the document */
    {
    REGISTER SpecialTP stp; /* pointer to special text */
    register SText FAR *st1p;   /* pointer to insets in special text dynamic array */
    register int ind, ii;
    
    /* written assumming all stexts have len of 1
        so we don't have to worry about an item being split by an insertion
        interior to it */
    
    stp = (SpecialTP) GetPtr(st);
    
    /* get index of block at or after pos */
    ind = TUTORfind_stext(stp,pos);
    
    if (ind >= 0)
        { /* there are blocks at or after pos, update their positions */
        st1p = ((SText FAR *) stp->text) + ind;
        for (ii=ind; ii<stp->head.dAnn ; ii++, st1p++)
            st1p->pos += newLen;
        }
    ReleasePtr(st);
    KillPtr(stp);
    
    return(0);
    }

/* when a document that has special text is changed, either TUTORinsert_stext will be
    called (no special text being added), or TUTORsplice_stext will be called (special
    text is added in the change) */

/* copy special text from one structure into another special text structure */
TUTORsplice_stext(st,fromSt,pos,fromPos,fromLen)
Memh st;    /* getting new insets */
Memh fromSt;    /* copy insets from here */
long pos;   /* splice at this position */
long fromPos, fromLen;  /* copy from this region */
/* returns TRUE if anything was added to st */
    {
    Memh tempH; /* copy of an inset */
    REGISTER SpecialTP fromStp; /* pointer to special text we are copying from */
    register SText FAR *st1p;   /* pointer to insets in special text (fromSt) dynamic array */
    register int ind;   /* index (in dynamic array of fromSt) of st1p */
    int retVal; /* the return value */
    
    /* written assumming all stexts have len of 1 (insets only) */
    
    /* adjust st to account for the # of characters being added: */
    TUTORinsert_stext(st,pos,fromLen);
    
    /* now see if any special text items must be copied from fromSt to st */
    
    fromStp = (SpecialTP) GetPtr(fromSt);
    ind = TUTORfind_stext(fromStp,fromPos);
    if (ind < 0) /* fromPos must be after the last item in fromSt */
        { /* nothing to splice in, we're done */
        ReleasePtr(fromSt);
        KillPtr(fromStp);
        return(FALSE);
        }
    
    retVal = FALSE;
    st1p = ((SText FAR *) fromStp->text) + ind; /* pointer to item at or after pos */
    for (;ind < fromStp->head.dAnn; ind++, st1p++)
        {
        if (st1p->pos + st1p->len > fromPos+fromLen)
            break; /* we're past the copy region, all done */
        
        /* the st1p item is in copy region, copy it and put it into st */
        tempH = TUTORcopy_stext((int)st1p->type,(Memh)st1p->dat);
        TUTORadd_stext(st,pos+st1p->pos - fromPos,st1p->type,tempH);
        retVal = TRUE;
        }
    ReleasePtr(fromSt);
    KillPtr(fromStp);
    
    return(retVal);
    }
    
/* ******************************************************************* */

static Memh TUTORcopy_stext(type,srcH) /* copy special text handle */
int type; /* type of special text to copy */
Memh srcH; /* handle to copy */

{	Memh destH; /* destination handle */

	if (type == PIXMAPSPECIAL) {
		destH = TUTORcopy_region(srcH);
		if (!destH)
			TxtMemErr++; /* remember failure */
	} else {
		destH = TUTORcopy_handle(srcH); /* simple object, copy handle */
	}
	return(destH);
	
} /* TUTORcopy_stext */

/* ******************************************************************* */

TUTORdraw_stext(st1p)
register SText FAR *st1p;   /* pointer to insets in special text dynamic array */

{   
    if (st1p->type == BITMAPSPECIAL) {
        TUTORdraw_pcchar(st1p->dat,-1);
    } else if (st1p->type == PIXMAPSPECIAL) {
        DrawStextPixmap(st1p->dat);
    } else if (st1p->type == ICONSPECIAL) {
        DrawStextIcons(st1p->dat);
    }
    
    /* this should be a case statement handling all kinds of special text */
    
    return(0);
    
} /* TUTORdraw_stext */

/* ******************************************************************* */

static DrawStextIcons(iconDatH) /* draw special text icons */
Memh iconDatH; /* handle on icon data */

{   int FAR *iconDatP; /* pointer to icon data */
    int ix; /* index in icons */
    int nIcons; /* number icons to plot */
    int iconN; /* index of icon to plot */
    int fontid; /* font id of icons */
    int is16bit; /* TRUE if 16-bit font */
    int len; /* 1 for 8-bit font, 2 for 16-bit font */
    char istr[4];
    int xx,yy,dumyy;
    
    /* get starting x,y - y will be held constant */
    /* on mac, RealX/RealY are not up to date, this corrects them */
    TUTORinq_abs_pen_pos(&xx,&yy);
    iconDatP = (int FAR *)GetPtr(iconDatH);
    nIcons = *iconDatP; /* get number icons to plot */
    fontid = *(iconDatP+nIcons+1);
    is16bit = TUTORinq_icon_code_size(fontid);
    len = (is16bit ? 2: 1);
    istr[1] = istr[2] = 0; /* terminate for both 8/16 bit icons */
    for (ix = 0; ix < nIcons; ix++) {
        iconN = *(iconDatP+ix+1); 
        if (is16bit) {
            istr[0] = (iconN >> 8) & 0xff;
            istr[1] = iconN & 0xff;
        } else {
            istr[0] = iconN;
        }
        TUTORdraw_graphic_icons(fontid,istr,len);   
        TUTORinq_abs_pen_pos(&xx,&dumyy);
        TUTORabs_move_to(xx,yy); /* keep y constant */
    } /* for */
    ReleasePtr(iconDatH);

} /* DrawStextIcons */

/* ******************************************************************* */

TUTORmeasure_stext(st1p,asc,desc,lead) /* return size of a special text character */
SText FAR *st1p;   /* pointer to insets in special text dynamic array */
int *asc, *desc, *lead; /* ascent, descent and leading returns (only set if asc != NULL) */
/* returns character width */
    
{   struct pccharl FAR *cp; /* pointer to character data of BITMAPSPECIAL */
    int width;  /* (total) width of special char */
    int dx; /* width of current character */
    Memh iconDatH; /* handle on icon data */
    int FAR *iconDatP; /* pointer to icon data */
    int ix; /* index in icons */
    int nIcons; /* number icons to plot */
    int iconN; /* index of icon to plot */
    int fontid; /* font id of icons */
    int ascent,descent,leading;
    int dasc,ddes; /* ascent, descent of current character */
    Memh headerH; /* handle on region header info */
    struct saved_region FAR *headerP; /* pointer to saved region header */
    
    if (st1p->type == BITMAPSPECIAL) { 
    
        /* measure BITMAPSPECIAL character */
            
        cp = (struct pccharl FAR *) (GetPtr(st1p->dat) + sizeof(struct pcfont));
                
        /* width is how much pen moves (in x direction) after drawing */
        width = cp->pdx;
    
        /* ascent is how much of char is above origin, descent is below, */
        /* leading is 0 */
        
        if (asc) {
            *asc = -cp->bndy;
            if (*asc < 0)
                *asc = 0; /* to be sensible */
            *desc = cp->bnh + cp->bndy +1;
            if (*desc < 0)
                *desc = 0;
            *lead = 0;
        } /* asc if */
        ReleasePtr(st1p->dat);
        return(width);
    } else if (st1p->type == PIXMAPSPECIAL) {
        headerH = (Memh)st1p->dat; 
        headerP = (struct saved_region FAR *)GetPtr(headerH);
        TUTORinq_font_info(&ascent,&descent,&ix,&leading);
        width = headerP->width;
        if (asc) {
            *desc = headerP->height-ascent;
        	*asc = ascent; 
        	*lead = 0;
        }
	ReleasePtr(headerH);
        return(width);
    } else if (st1p->type == ICONSPECIAL) {
    
        /* measure ICONSPECIAL character */
    
        iconDatH = st1p->dat; /* get handle on icons */
        iconDatP = (int FAR *)GetPtr(iconDatH);
        nIcons = *iconDatP; /* get number icons to plot */
        fontid = *(iconDatP+nIcons+1);
        ascent = descent = width = leading = 0;
        for (ix = 0; ix < nIcons; ix++) {
            iconN = *(iconDatP+ix+1); 
            TUTORinq_icon_size(fontid,iconN,&dx,&dasc,&ddes);
            if (dx < 0) dx = 0;
            if (ascent < dasc) ascent = dasc;
            if (descent < ddes) descent = ddes;
            width += dx;
        } /* for */
        ReleasePtr(iconDatH);
        if (asc)
            *asc = ascent;
        if (desc)
            *desc = descent;
        if (lead)
            *lead = leading;
        return(width);
    } else { /* shouldn't get here */
        if (asc) {
            *asc = 0;
            *desc = 0;
            *lead = 0;
        }
    } /* else */
    return(0);
    
} /* TUTORmeasure_stext */

/* ******************************************************************* */

static DeleteSText(stp,ind,pos,len) /* handle deletions from special text dynamic array */
SpecialTP stp;  /* pointer to special text we are deleting from */
int ind;    /* index of first block at or after pos */
register long pos, len; /* range of positions we want to delete items from */
    {
    register SText FAR *st1p;   /* pointer to insets in special text dynamic array */
    register SText FAR *st1End; /* pointer to last inset */
    int nDel;   /* number of items in dynamic array we want to delete */
    
    /* written assumming all stexts have len of 1 (insets only) */
    
    if (ind < 0) /* deletion is past the last block */
        return 0;

    st1p = ((SText FAR *) stp->text) + ind;
    st1End = ((SText FAR *) stp->text) + (stp->head.dAnn - 1);
    
    nDel = 0;
    while (st1p <= st1End && st1p->pos < pos+len)
        { /* st1p is in deletion range */
        if (st1p->type == PIXMAPSPECIAL) {
			TUTORfree_region(st1p->dat);
			st1p->dat = HNULL;
        }
		if (st1p->dat)
        	TUTORfree_handle(st1p->dat);
        st1p++;
        nDel++;
        }
    
    /* delete dynamic array blocks corresponding to deleted items */
    if (nDel)
        TUTORdelete_darray(stp->self,(char FAR *) stp,STOFFSET,0,ind,nDel);
    
    return 0;
    }

TUTORfind_stext(stp,pos)
register SpecialTP stp; /* pointer to special text we are searching */
register long pos;  /* position (in document) we are searching for */
/* returns index of block at or after pos, or -1 if no such */
    {
    register SText FAR *st1p;   /* pointer to insets in special text dynamic array */
    register ii;
    
    /* simple linear search through the special text array */
    
    st1p = ((SText FAR *) stp->text);
    for (ii=0; ii<stp->head.dAnn; ii++,st1p++)
        if (st1p->pos >= pos)
            return(ii);

    return(-1); /* we didn't find a block at or after pos */
    }
    
/* ******************************************************************* */

DrawStextPixmap(regionH) /* draw PIXMAPSPECIAL character */
Memh regionH;

{   int xx,yy; /* pen position */
	struct saved_region FAR *headerP;
	int ascent,dummy;
	
    TUTORinq_abs_pen_pos(&xx,&yy);
    TUTORinq_font_info(&ascent,&dummy,&dummy,&dummy);
    TUTORabs_move_to(xx,yy-ascent);
    TUTORabs_restore_region((long)regionH,xx,yy-ascent); 
    headerP = (struct saved_region FAR *)GetPtr(regionH);
    xx += headerP->width;
    ReleasePtr(regionH);
    TUTORabs_move_to(xx,yy); /* update pen */
    
} /* DrawStextPixmap */

/* ******************************************************************* */

#ifdef MAC
#ifdef THINKC5
#include <Memory.h>
#endif

/* routines to support special text on the Mac clipboard */

/* when we cut & paste special text on the mac we want to take all the special
    text and create a copy of it in a single handle, so it can be put onto the clipboard
    in one piece.  We do this by creating a new special text structure that has just
    the items in the correct range, and then appending the data for each of them
    to the end of the handle */
/* in addition, when we copy, we want to turn the first BITMAPSPECIAL into a PICT */

Memh TUTORclip_copy_stext(specialT,pos,len,ph) /* turn special data into single handle */
Memh specialT;  /* the special text structure */
register long pos, len; /* where we are copying from */
PicHandle *ph;  /* to be set to a PICT of first graphic char, if any */
    {
    SpecialTP stp;  /* pointer to special text */
    register SText FAR *st1p;   /* pointer to insets in special text dynamic array */
    register SText FAR *st1End; /* pointer to last inset */
    long totData;   /* sum of lengths of all the data */
    Memh pieceH;    /* the single handle which is the return value */
    long tempL,wL;
    long pictL; /* length of picture data */
    Memh pictH; /* handle on picture data */
    Memh palH; /* handle on palette data */
    char FAR *pp;   /* pointer to inside of pieceH */
    char FAR *p1;   /* pointer to inset data */
    register int ii;
    int nItems; /* number of items in pos-len range */
    int baseInd; /* index of first item at or after pos */
    int firstGraphic;   /* index of first graphic char */
    struct saved_region FAR *regionP; /* pointer to region header */
    struct saved_region FAR *nRegionP; /* pointer to new region header */
    
    /* this code assummes that special text all has length of 1 */
    
    pieceH = HNULL; /* by default we return nothing */
    *ph = 0L;   /* no PICT yet */
    
    /* first find out the total length of data */
    totData = 0L;
    stp = (SpecialTP) GetPtr(specialT);
    baseInd = TUTORfind_stext(stp,pos);
    firstGraphic = -1; /* no graphics char yet */
    if (baseInd >= 0)
        { /* there are items after pos */
        st1p = ((SText FAR *) stp->text) + baseInd;
        st1End = ((SText FAR *) stp->text) + (stp->head.dAnn-1);
        nItems = 0;
        while (st1p <= st1End && st1p->pos < pos+len)
            {
            totData += TUTORget_hsize(st1p->dat);
            if (st1p->type == PIXMAPSPECIAL) {
            	regionP = (struct saved_region FAR *)GetPtr(st1p->dat);
            	if (regionP->rformat == 1)
            		regionP->pictLen = TUTORget_hsize(regionP->pictureH);
            	else if (regionP->rgbpixH)
  					regionP->pictLen = TUTORget_hsize(regionP->rgbpixH);
            	else
            		regionP->pictLen = 0;
            	totData += regionP->pictLen;
            	ReleasePtr(st1p->dat);
            }
            nItems++;
            if (firstGraphic < 0 && st1p->type == BITMAPSPECIAL)
                firstGraphic = st1p - ((SText FAR *) stp->text); /* found first graphic */
            st1p++;
            }
        
        if (nItems)
            { /* there are items in range */
            pieceH = TUTORnew_stext();
            
            if (firstGraphic >= 0) /* make a PICT of the first graphics char */
                *ph = MakePict_stext(stp->text[firstGraphic].dat);
            
            /* add all special text items to pieceH (but with no data) */
            st1p = ((SText FAR *) stp->text)+baseInd;
            for (ii=0; ii<nItems;ii++,st1p++)
                {
                TUTORadd_stext(pieceH,st1p->pos - pos,st1p->type,HNULL);
                }
            
            /* now append all the data directly to pieceH */
            tempL = TUTORget_hsize(pieceH); /* original size of pieceH */
            if (!TUTORset_hsize(pieceH,tempL+totData+4L*nItems,FALSE))
                { /* failed resize - just forget special text */
                TUTORfree_handle(pieceH); /* not TUTORclose_stext, or it will free handles! */
                pieceH = HNULL;
                }
            else
                {
                pp = GetPtr(pieceH) + tempL; /* point just past normal data */
                st1p = ((SText FAR *) stp->text) + baseInd;
                for (ii=0; ii<nItems; ii++,st1p++)
                    {
                    /* append length of next data */
                    wL = tempL = TUTORget_hsize(st1p->dat);
                    pictH = 0;
                    if (st1p->type == PIXMAPSPECIAL) {
                    	regionP = (struct saved_region FAR *)GetPtr(st1p->dat);
                    	if (regionP->rformat == 1)
                    		pictH = regionP->pictureH;
                    	else
                    		pictH = regionP->rgbpixH;
                    	palH = 0;
                    	pictL = regionP->pictLen;
                    	wL += pictL;
                    	ReleasePtr(st1p->dat);
                    	KillPtr(regionP);
                    }
                    TUTORblock_move((char SHUGE *) &wL,pp,(long) sizeof(long));
                    pp += sizeof(long);
                    
                    /* append data */
                    p1 = GetPtr(st1p->dat);
                    TUTORblock_move(p1,pp,tempL);
                    ReleasePtr(st1p->dat);
                    KillPtr(p1);
                    pp += tempL;
                    if (pictH) {
                    	p1 = GetPtr(pictH);
                    	TUTORblock_move(p1,pp,pictL);
                    	pp += pictL;
                    	ReleasePtr(pictH);
                    /*	p1 = GetPtr(palH);
                    	TUTORblock_move(p1,pp,palL);
                    	pp += palL;
                    	ReleasePtr(palH); */
                    }
                    }
                ReleasePtr(pieceH);
                KillPtr(pp);
                }
            } /* end of if (nItems) */
        }
    
    ReleasePtr(specialT);
    KillPtr(stp);
    
    return(pieceH);
    }

/* read the agglomerated special text handle from the Mac clipboard & turn it
    into a normal special text structure, with seperate data handles */
Memh TUTORclip_uncopy_stext(sh)
Handle sh;  /* handle as read from Mac clipboard */
    {
    Memh specialT;  /* the special text structure we will return */
    SpecialTP stp;  /* pointer to special text */
    register SText FAR *st1p;   /* pointer to insets in special text dynamic array */
    long tempL,wL;
    long pictL; /* length of picture data */
    register int ii;
    char FAR *pp;   /* pointer to inside of specialT */
    char FAR *p1;   /* pointer to inside of new data */
    struct saved_region FAR *regionP; /* pointer to saved region header */
    Memh pixH; /* handle on picture or pixmap */
    
    /* convert Mac handle to cT handle */
    specialT = TUTORaffix_handle(sh,"tempspcl",FALSE);
    
    stp = (SpecialTP) GetPtr(specialT);
    stp->self = specialT;   /* fix up the "self" field */
    /* note that the rest of the fields (except for "data" in the dynamic array)
        are correct */
    
    /* create data handles */
    pp = (char FAR *) stp + stp->totalSize; /* points at trailing data */
    
    st1p = ((SText FAR *) stp->text);
    for (ii=0; ii<stp->head.dAnn; ii++, st1p++)
        {
        /* read size && set up data handle */
        TUTORblock_move(pp,(char SHUGE *) &wL,(long) sizeof(long));
        tempL = wL;
        pp += sizeof(long);
        pictL = 0;
        if (st1p->type == PIXMAPSPECIAL) {
        	tempL = sizeof(struct saved_region);
        	regionP = (struct saved_region FAR *)pp;
        	pictL = regionP->pictLen;
        }
        st1p->dat = TUTORhandle("clippict",tempL,TRUE); /* create data handle */
  
        /* read data into new handle */
        p1 = GetPtr(st1p->dat);
        TUTORblock_move(pp,p1,tempL);
        pp += tempL;
        if (pictL) {
        	regionP = (struct saved_region FAR *)p1;
        	regionP->rgbDataH = regionP->palDataH = regionP->nativePal = HNULL;
        	regionP->pictureH = regionP->rgbpixH = regionP->palpixH = HNULL;
        	pixH = TUTORhandle("pictt",pictL,TRUE); /* create picture handle */
        	if (!pixH)
        		TUTORdump("Out of memory");
        	if (regionP->rformat == 1) regionP->pictureH = pixH;
        	else regionP->rgbpixH = pixH;

        	p1 = GetPtr(pixH);
        	TUTORblock_move(pp,p1,pictL);
        	pp += pictL;
        	ReleasePtr(pixH);
        }
        ReleasePtr(st1p->dat);
        }
    
    /* resize special text handle to its proper size */
    tempL = stp->totalSize;
    ReleasePtr(specialT);
    KillPtr(stp);
    TUTORset_hsize(specialT,tempL,TRUE);
    
    return(specialT);
    }

/* very Mac-specific code: */

Memh TUTORpict_to_char(pictH) /* change a PICT into a BITMAPSPECIAL special text character */
PicHandle pictH;    /* handle to PICT we want to convert (usually from clipboard) */
    {
    PicPtr pp;  /* pointer to pictH */
    GrafPort tempPort;  /* temporary port we use to draw the pict */
    BitMap bm;  /* bitmap for temporary port */
    long tempL;
    Memh charH; /* the special character we are creating */
    REGISTER struct pccharl FAR *charP; /* pointer to character data of BITMAPSPECIAL */
    GrafPtr curPort;    /* to save & restore the current port */
    char FAR *tempP;    /* pointer to charH */
    struct pcfont FAR *fontp;   /* pointer to font data of BITMAPSPECIAL */
    
    /* we create a temporary grafport whose bitmap is the character image at the
        end of a BITMAPSPECIAL character.  Then we draw the pict into that port,
        which creates the graphic image */
    
    pp = *pictH; /* not locked... */
    
    /* what size bitmap is required? (big enough for entire picture) */
    SetRect(&bm.bounds,0,0,pp->picFrame.right - pp->picFrame.left,
        pp->picFrame.bottom - pp->picFrame.top);
    bm.rowBytes = 2*((bm.bounds.right - 1)/16 + 1);
    
    /* figure total handle size && allocate handle */
    tempL = sizeof(struct pcfont) + sizeof(struct pccharl) + bm.rowBytes * (long) bm.bounds.bottom;
    charH = TUTORhandle("spclchar",tempL,TRUE);
    
    /* clear the character structure (which also clears the bitmap) */
    tempP = GetPtr(charH);
    TUTORzero((char SHUGE *) tempP,tempL);
    
    fontp = (struct pcfont FAR *) tempP;
    /* most fields of fontp can just be left 0 */
    fontp->nchars8 = 1;
    fontp->dmap = sizeof(struct pcfont) + sizeof(struct pccharl);
    fontp->format = 1; /* large format character definitions */
    
    /* fill out character fields */
    charP = (struct pccharl FAR *) (tempP + sizeof(struct pcfont));
    charP->map = 0;
    charP->pdy = 0;
    charP->pdx = bm.bounds.right;
    charP->bnw = charP->mapw = bm.bounds.right;
    charP->bnh = charP->maph = bm.bounds.bottom;
    charP->bndx = 0;
    charP->bndy = -bm.bounds.bottom;
    charP->mapdx = charP->mapdy = 0;
    
    /* draw the pict into the bitmap at the end of the character */
    bm.baseAddr = (Ptr) (((char FAR *) charP) + sizeof(struct pccharl));
    
    GetPort(&curPort); /* remember current port */
    OpenPort(&tempPort);
    SetPortBits(&bm);
    PortSize(bm.bounds.right,bm.bounds.bottom);
    
    /* draw the picture */
    DrawPicture(pictH,&bm.bounds);
    
    SetPort(curPort);
    ClosePort(&tempPort);
    
    ReleasePtr(charH);
    KillPtr(charP);
    
    return(charH);
    }

/* ******************************************************************* */

PicHandle MakePict_stext(pch) /* make a PICT from a BITMAPSPECIAL */
Memh pch;   /* the BITMAPSPECIAL character */
    {
    GrafPort tempPort;  /* temporary grafport */
    BitMap bm;  /* bitmap for temporary port */
    long tempL;
    REGISTER struct pccharl FAR *cp;    /* character data for pch */
    GrafPtr curPort;    /* to save & restore the current port */
    int offx, offy, bnw, bnh; /* to remember character characteristics */
    PicHandle pic;  /* the PICT we are creating */
    
    /* we create a temporary grafport, start a PICT, draw the special character
        and then clean up */
    /* note that we make a PICT only of the character map, not the whole bounding box */
    
    /* note that we assume only 1 character in the font */
    
    /* get information from character */
    cp = (struct pccharl FAR *) (GetPtr(pch) + sizeof(struct pcfont));
    offx = -(cp->mapdx+cp->bndx);
    offy = -(cp->mapdy+cp->bndy);
    bnw = cp->bnw;
    bnh = cp->bnh;
    ReleasePtr(pch);
    KillPtr(cp);

    /* set up bitmap for safe drawing of PICT */
    SetRect(&bm.bounds,0,0,bnw,bnh);
    bm.rowBytes = 2*((bm.bounds.right - 1)/16 + 1);
    tempL = bm.rowBytes * 8 * bnh;
    bm.baseAddr = NewPtr(tempL);
    if (!bm.baseAddr)
        return(0L); /* couldn't allocate memory */

    /* set up temporary port */
    GetPort(&curPort); /* remember current port */
    OpenPort(&tempPort);
    SetPortBits(&bm);
    PortSize(bm.bounds.right,bm.bounds.bottom);
    ClipRect(&bm.bounds);   /* so PICT is handled correctly */
    MoveTo(offx,offy); /* to counteract OffsetRect in TUTORdraw_pcchar */
    
    /* create picture */
    pic = OpenPicture(&bm.bounds);
    TUTORdraw_pcchar(pch,-1);
    ClosePicture();
    
    /* clean up */
    SetPort(curPort);
    ClosePort(&tempPort);
    DisposePtr(bm.baseAddr);
    
    return(pic);
    }

/* TUTORdraw_pcchar is a general routine, it will work with any pcfont, not
    just a BITMAPSPECIAL */

static TUTORdraw_pcchar(pch,cc) /* draw a cT format character */
Memh pch; /* pc font handle */
int cc; /* which char to draw (-1 forces first character) */
    {
    BitMap bm;  /* bitmap to be put on cT character for copybits */
    Point where;    /* where the pen is (which is where we draw character) */
    GrafPtr curPort;    /* the current port, where we draw the character */
    Rect tempR;     /* where in curPort we CopyBits our image */
    struct pccharl FAR *cpl;    /* pointer data of character we want */
    struct pcchars FAR *cps;    /* pointer data of character we want */
    struct pccharl tempCL;  /* temporary large format data */
    int xx, yy; /* amount to move pen after drawing char */
    struct pcfont816 FAR *fontp;   /* pointer to font structure */
    int mode;   /* mode we want to draw the character in */
    int first,nchars; /* first character, number characters */
    
    fontp = (struct pcfont816 FAR *) GetPtr(pch);
    if (fontp->format & 4) { /* 16-bit encoding */
        first = fontp->first16;
        nchars = fontp->nchars16;
    } else {
        first = fontp->first8;
        nchars = fontp->nchars8;
    }
	if (cc == -1)
		cc = first; /* pick first character */
    if (cc < first || cc >= first + nchars)
        { /* invalid character */
        ReleasePtr(pch);
        KillPtr(fontp);
        return(0);
        }
    
    if (fontp->format & 1)
        { /* large character format */
        cpl = (struct pccharl FAR *) ((char FAR *) fontp + sizeof(struct pcfont));
        cpl += (cc - first); /* refer to the right character */
        }
    else
        { /* small character format */
        cps = (struct pcchars FAR *) ((char FAR *) fontp + sizeof(struct pcfont));
        cps += (cc - first); /* refer to the right character */
        
        /* copy small format data to a temporary large format */
        cpl = &tempCL;
        cpl->map = cps->map;
        cpl->pdx = cps->pdx;
        cpl->pdy = cps->pdy;
        cpl->bndx = cps->bndx;
        cpl->bndy = cps->bndy;
        cpl->mapdx = cps->mapdx;
        cpl->mapdy = cps->mapdy;
        cpl->bnw = cps->bnw;
        cpl->bnh = cps->bnh;
        cpl->mapw = cps->mapw;
        cpl->maph = cps->maph;
        }
    
    /* set up bitmap referencing the cT character */
    SetRect(&bm.bounds,0,0,cpl->mapw,cpl->maph);
    bm.rowBytes = 2*((cpl->mapw - 1)/16 + 1);
    bm.baseAddr = (Ptr) ((char FAR *) fontp + fontp->dmap + cpl->map);
    
    GetPen(&where); /* where to draw */
    
    /* draw bounding box */
    SetRect(&tempR,where.h,where.v,where.h+cpl->bnw,where.v+cpl->bnh);
    GetPort(&curPort);
    mode = curPort->pnMode & 7; /* make sure it is a src transfer mode */
    if (mode == srcCopy)
        { /* mode rewrite, clear the bounding box */
        EraseRect(&tempR);
        mode = srcOr; /* change to write since background already cleared */
        }
    else if ((curPort->pnMode & 7) == notSrcCopy)
        { /* mode inverse, fill bounding box */
        PaintRect(&tempR);
        mode = notSrcOr; /* change to erase since background already filled */
        }
    
    /* copybits the character map */
    tempR = bm.bounds;  /* same size as character map */
    OffsetRect(&tempR,where.h+cpl->bndx+cpl->mapdx,where.v+cpl->bndy+cpl->mapdy);
    xx = cpl->pdx;
    yy = cpl->pdy;
    ReleasePtr(pch);
    KillPtr(fontp);
    
    CopyBits(&bm,&curPort->portBits,&bm.bounds,&tempR,mode,0L);
    
    if (xx || yy) /* move pen */
        MoveTo(where.h+xx,where.v+yy);
    
    return(0);
    }
#endif /* MAC */

/* ******************************************************************* */

#ifdef WINPCz

DrawStextPixmap(pixH) /* draw PIXMAPSPECIAL character */
Memh pixH;

{   int xx,yy;
    struct saved_region FAR *headerP; /* pointer to saved region header */
    Memh dibH; /* handle on DIB bitmap */
    char FAR *dibP; /* pointer to DIB bitmap */
    LPBITMAPINFO biP; /* pointer to DIB bitmap header */

    /* get pen position, draw pixmap */
    
    TUTORinq_abs_pen_pos(&xx,&yy);
    TUTORabs_move_to(xx,yy);
    TUTORabs_restore_region((long)pixH,xx,yy);
    
    /* update pen position */
    
    headerP = (struct saved_region FAR *)GetPtr(pixH);
    dibH = headerP->dibH; /* pick up handle on DIB bitmap */
    ReleasePtr(pixH);
    dibP = GetPtr(dibH); /* get pointer to DIB data */
    biP = (LPBITMAPINFO)(dibP+sizeof(BITMAPFILEHEADER));    
    xx += biP->bmiHeader.biWidth;
    ReleasePtr(dibH);
    TUTORabs_move_to(xx,yy); /* update pen */
    return(0);
    
} /* DrawStextPixmap */
    
#endif
/* ******************************************************************* */

#ifdef X11z

DrawStextPixmap(pixH) /* draw PIXMAPSPECIAL character */
Memh pixH;

{   int xx,yy;
    struct saved_region FAR *headerP; /* pointer to saved region header */

    /* get pen position, draw pixmap */
    
    TUTORinq_abs_pen_pos(&xx,&yy);
    TUTORabs_move_to(xx,yy);
    TUTORabs_restore_region((long)pixH,xx,yy);
    
    /* update pen position */
    
    headerP = (struct saved_region FAR *)GetPtr(pixH);
    xx += headerP->width;
    ReleasePtr(pixH);
    TUTORabs_move_to(xx,yy); /* update pen */
    return(0);
    
} /* DrawStextPixmap */
    
#endif

/* ******************************************************************* */

#ifdef DOSPC

/* this routine is written for drawing BITMAPSPECIAL characters
    so it is not general */

TUTORdraw_pcchar(pch,cc) /* routine to draw graphic char */
Memh pch;   /* font */
int cc;     /* which character to draw */
    {
    int xx, yy; /* amount to move pen after drawing */
    struct pccharl FAR *cp; /* pointer to large character format */
    struct pcfont FAR *fontp;   /* pointer to font data */
    Memh wmFont; /* current font */
    unsigned char tempS[2];
    int drawChar;   /* the character we will draw */
    
    fontp = (struct pcfont FAR *) GetPtr(pch);
    cp = (struct pccharl FAR *) (((char FAR *) fontp) + sizeof(struct pcfont));
    
    /* remember how much the char plotter thinks pen should move */
    xx = cp->pdx;
    yy = cp->pdy;
	drawChar = cc;
	if (drawChar == -1)
    	drawChar = fontp->first8;   /* draw the first char */
    ReleasePtr(pch);
    KillPtr(fontp);
    
    /* set to font, draw char, restore font */
    wmFont = wmg_inq_current_font();
    wmg_font(pch);
    tempS[0] = drawChar;
    TUTORdraw_text((unsigned char FAR *) tempS,1);
    if (wmFont)
        wmg_font(wmFont);
    
    /* the character plotter moved the pen xx,yy.  We don't want
        any negative motion of x and no motion of y at all */
    if (xx >= 0)
        xx = 0; /* no compensation needed */
    TUTORabs_move(-xx,-yy); /* make a compensating move */

    return(0);
    }

#endif /* DOSPC */

/* ******************************************************************* */

#ifdef WINPC

TUTORdraw_pcchar(pch,cc) /* routine to draw graphic char */
Memh pch;   /* font */
int cc;     /* which character to draw */
    
{   int oldX,oldY; /* original pen position */
    int xx, yy; /* amount to move pen after drawing */
	struct pcfont FAR *fontp;
   
    oldX = RealX; /* remember pen position */
    oldY = RealY;
	
	if (cc == -1) { /* get first character */
		fontp = (struct pcfont FAR *) GetPtr(pch);
   		cc = fontp->first8;
    	ReleasePtr(pch);
	}
    fpc_draw_char(pch,FARNULL,cc); /* draw fpc-format character */
   
    /* remember how much the char plotter thinks pen should move */
   
    xx = RealX-oldX;
    yy = RealY-oldY;
    
    /* the character plotter moved the pen xx,yy.  We don't want
        any negative motion of x and no motion of y at all */

    if (xx >= 0)
        xx = 0; /* no compensation needed */
    TUTORabs_move(-xx,-yy); /* make a compensating move */

    return(0);

} /* TUTORdraw_pcchar */

#endif /* WINPC */

/* ******************************************************************* */

int cvt_font_name(nstr) /* convert font/file name to font index */
char *nstr; /* font name string */

{   FileRef filename; /* font file name */
    FileRef famName; /* font family name */
    long famiD;
    int fsize,findex;

    if (TUTORis_symbolic(nstr)) { /* it is a symbolic name */
        TUTORsymbolic_fileref((FileRef FAR *)&filename,(char FAR *)nstr);
    } else {
	TUTORcvt_path(nstr,(FileRef FAR *)&filename,currentDirP,TRUE);
    }
    famiD = TUTORparse_font_family(&filename,&famName,0,TRUE,&fsize);
    findex = TUTORget_font2(famiD,fsize,0,110);
    return(findex); /* index of font in font table */

} /* cvt_font_name */           
    
/* ******************************************************************* */
