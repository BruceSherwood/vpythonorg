/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/


/* This file contains "service" routines for execution: initializations, 
    general routines, menu treatment, etc.
*/
#include "execdefs.h"
#include "eglobals.h"
#include "ecglobal.h"
#include "tglobals.h"
#include "exprdefs.h"
#include "yacc.h"
#include "ct_ctype.h"
#include "fkeys.h"
#include "kglobals.h"
#include "commands.h"
#include "editor.h"

#ifdef THINKC5
#include <Quickdraw.h>
#endif

#ifdef ctproto
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
extern int TMessage(char FAR *s);
extern int  Refresh1Panel(struct  _tvdat FAR *vp,long  pos,long  len,long  cpos,long  clen,long  newC,long  selStart,long  selLen,int  scroll,int force);
int  RefreshPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  cpos,long  clen,long  newC,long  selStart,long  selLen,int  scroll,int force);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
extern int inhibit_objects(int type);
extern int inhibit_editdraw(int type);
extern int InitialStack(void);
extern void TUTORsystem_palette(void);
extern int TellExecInt(void);
extern int iexec_option_menu(void);
int TUTORset_dir(FileRef FAR  *path);
int  TUTORcopy_fileref_dir(struct  _fref FAR *dirname,struct  _fref FAR *fullname);
extern int MovieClose(int type);
extern int MovieSound(double volume);
extern int TUTORset_sub_new(int sub,int new);
extern int  FullHalt(void);
int  CTpalette(int  wn,unsigned int  newPal,int  newFlag,unsigned int  defPal);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
int  TUTORnormal_cursor(void);
extern int TUTORsize_exec_window(int wX,int wY);
int  readbinary(struct  _fref FAR *fn,int issource);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  settitles(char  *filename);
int  TUTORget_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  setmainfile(struct  _fref FAR *filename);
int  TUTORclose_doc(unsigned int  doc);
extern int exec_switch_fixup(void);
extern int TUTORflush(void);
extern int TUTORwait_cursor(void);
extern int ExecJumpout(struct tutorevent FAR *ev);
extern int TUTORclose_touch(Memh hh);
extern int TUTORclose_dde(Memh hh);
extern int TUTORline_thick(int thickv);
extern int get_button_ref(Memh bh);
extern int get_slider_ref(Memh sh);
extern int get_edit_ref(Memh eh);
int  AllowHandlePurge(unsigned int  mm);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
extern int FinishPicture(void);
extern int release_dyn_arrays(void);
extern int trace_thru_stack(int type);
extern int set_array_addresses(void);
extern int trace_thru_descriptors(int type,int unitn, long stacki);
extern int TUTORfree_handle(Memh hhh);
extern int sprintf(char *ss, char *form,...);
int  stacks(long  lvalue);
long  unstacks(void);
int  stackblock(unsigned char  *addr,int  length);
int  unstackblock(unsigned char  *addr,int  length);
int  InitExecution(void);
int  InitMainUnit(int  reshape,int  ieu);
int  init_array_desc(int  unitn,long  stacki);
int  items_close(int  unitn,long  stacki,int  vars,int  graphics);
int  txtype_close(long  SHUGE *vaddr,long  vtype);
int  object_var_close(long  SHUGE *vaddr);
int object_close(unsigned int  objH);
unsigned int find_free_object(int type);
int  unstack_all_units(void);
int  set_last_edit(unsigned int  objH,int ref);
int  set_last_button(unsigned int  objH,int ref);
int  set_last_slider(unsigned int  objH,int ref);
int  defaultinhibit(void);
int  ReallocStack(long  newl);
int  dounit(int  unitn,int  loc);
int  marker_file_name(struct  markvar SHUGE *mx,struct  _fref FAR *fullRef,int  symbolic);
int  translate_ct_string(unsigned char  *s0);
int  executeit(char  *ss);
int  marker_to_string(struct  markvar FAR *mx,char  *s,int  limit);
int  EndUnitMenus(void);
int  PauseMenus(void);
int  ArrowMenus(void);
int ArrowOkNoMenus(void);
int  ExecMenus(void);
int  DeleteExecMenus(void);
int  DeleteAllAuthorMenus(void);
int  DoMenuUnit(int inexec,int  unitn,int  paramf,double  param);
int  Randum(int  begin,int  end);
int  execerr(char  *msgstr);
extern int  FindErrorLine(int  *unitr,long  *srcloc,long xloc);
char  FAR *GetPtr(unsigned int  mm);
int  mvar_assign(struct markvar SHUGE *vaddr,struct  markvar SHUGE *mx);
int  mvar_init(struct  markvar FAR *mp);
unsigned char  SHUGE *LockStack(void);
long  IntToCoord(int  xx);
int  TUTORset_cursor(int  cInd,int  cChar);
int  TUTORset_fill(int  fInd,int  fChar);
int  clearkeys(void);
int  TUTORinq_abs_screen_size(int  *x,int  *y,int  *dx,int  *dy);
int  set_exec_pt(unsigned int  uloc);
int  InsureUnit(int  unitn);
int  enable(int  bits);
int  FullScreenErase(void);
int  setmode(int  m);
int  CancelTrigger(int  id);
extern int TUTORzero(char SHUGE *ptr,long lth);
int  assign_pfun(long  addr,long  pfunct);
int  CloseLocalFiles(void);
int CloseUnitLocalFiles(void);
int  DefaultFine(void);
int  TUTORreset_sockets(void);
int  TUTORdump(char  *s);
int  TUTORset_view(struct  tutorview FAR *vp);
int  TUTORclose_button(unsigned int  bH);
struct  tutorview FAR *TUTORinq_view(void);
int  ReleasePtr(unsigned int  mm);
int  mvar_ref_doc(unsigned int  docH);
int  CloseArrow(int  eFlag);
int  killptr(char  FAR * FAR *ptr);
int  TUTORtrace(char  *s);
int  TUTORfree_region(long  id);
int  TUTORclose_sbar(unsigned int  theSBar);
int  TUTORclose_panel(unsigned int  theV);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
int  ReleaseStack(void);
int  flush(void);
int  TUTORadd_menu(unsigned int  barh,char  *card,int  cp,char  *item,int  ip,int  keyBind,int  type,int  unit,double  unitArg,int  eType);
int  TUTORset_event_mask(int  eventc,int  value);
int  MakeMenus(void);
int  checkkey(int  key);
int  TUTORcvt_ct_chars(unsigned char  FAR *cp,long  clen);
int  TUTORcvt_path(char  *ssx,struct  _fref FAR *fRef,struct  _fref FAR *baseRef,int fileF);
int  TUTORsymbolic_fileref(struct  _fref FAR *fRef,char  FAR *syms);
int  TUTORis_symbolic(char  *ss);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
long  TUTOR_random(void);
int  ActivateArrow(int  aFlag);
int  executor(void);
int  fputvar(unsigned char SHUGE *vaddr,int  vkind,double  fvalue);
int  rejudge(void);
int  TUTORdelete_author_menus(unsigned int  barh);
int  TUTORdelete_menu(unsigned int  barh,char  *card,char  *item);
long  get_exec_pt(void);
extern void longjmp(jmp_buf env, int value);
int  Halt(void);
int  TUTORmulti_line_dialog(int  wn,char  FAR * *msg,int  nmsg);
int  TUTORdealloc(char  FAR *ptr);
int  TUTORpost_event(struct  tutorevent *event);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
int  _TUTORinq_state_internal_marker(int  ind,long  *pos,long  *len,int  *altered);
char  FAR *strcatf(char  FAR *aa,char  FAR *bb);
int  GetUnitName(int  unitn,unsigned char  *name);
int  strlenf(char  FAR *aa);
extern long FindSourceLine(int unit,long ploc);
#endif /* ctproto */

#ifdef IBMPC
extern char *strcpy(char *aa, char *bb);
#endif


extern Memh dtextv();   /* return pointer to text layout document */
extern double usereval();
extern char *FullName();
extern double lcitof();
extern  struct tutorview FAR *TUTORinq_view();
extern long get_exec_pt();
extern int object_close();
extern int object_var_close();
extern Memh find_free_object();
extern long FindSourceLine();

extern int movieInhibitF; 

/*********************************************/
stacks(lvalue)  /* stack a long */
long lvalue; {
if (exS.stackpntr>=(exS.stackP+exS.stackmalloc)) 
  execerr( "Stack overflow -- may be too many -do-s.");
*(long SHUGE *)exS.stackpntr = lvalue;
exS.stackpntr += sizeof(long); }

/*********************************************/
long unstacks() { /* unstack a long */
if (exS.stackpntr<(exS.stackP+gvaraddr)) 
  execerr( "System error -- stack underflow.");
exS.stackpntr -= sizeof(long);
return( *(long SHUGE *)exS.stackpntr ); }

/*********************************************/
stackblock(addrF, length)  /* stack a block of bytes */
unsigned char *addrF; 
int length; 

{   unsigned char SHUGE *addrH;

    addrH = addrF;
    if (exS.stackpntr+length>=(exS.stackP+exS.stackmalloc)) 
        execerr( "Stack overflow -- may be too many -do-s.");
    while (length--) *(exS.stackpntr++) = *(addrH++);
}

/*********************************************/
unstackblock(addrF, length)  /* unstack a block of bytes */
unsigned char *addrF; 

int length; 

{   unsigned char SHUGE *addrH;

    addrH = addrF;
    if (exS.stackpntr-length<(exS.stackP+gvaraddr)) 
        execerr( "System error -- stack underflow.");
    addrH += length;
    while (length--) *(--addrH) = *(--exS.stackpntr);
}

/* ******************************************************************* */

int ExecJumpout(ev) /* executor-only jumpout to specified file */
struct tutorevent FAR *ev; /* pointer to jumpout event info */
    
{   FileRef fileName; /* fileref for new program */
    int cwX,cwY; /* current (desired) executor window size */
    struct tutorevent switchEv; /* switch event for executor */
    int assocNam; /* TRUE if should use *.ctb file name */
    char tempS[FILEL+1];

    TUTORwait_cursor();
    TUTORflush();
    gvarzero = TRUE; /* zero global vars on execute */
    exS.startunit = -1;
    cwX = ExecWinX; /* current (desired) window size */
    cwY = ExecWinY;
    exec_switch_fixup(); /* shorten executor stack */
    pictur_id = 0; /* re-set unique id for picture */
    CTpalette(ExecWn, HNULL,TRUE,HNULL); /* set executor's palette to default */

    /* pick up new file name */
                
    if (ev->eDataP == FARNULL)
        return(FALSE); /* no file, no can do */
    fileName = *(FileRef FAR *)ev->eDataP;
    TUTORdealloc(ev->eDataP);
    ev->eDataP = FARNULL;

    /* empty textpool */
 
    if (textpool)  /* get rid of existing text/string literals */
        TUTORclose_doc(textpool); /* dump document */
    textpool = TUTORnew_doc(TRUE,FALSE); /* text/string literals */

    setmainfile(&fileName);
    TUTORget_fileref_name(&fileName,(char FAR *) tempS);
    settitles(tempS);

    /* read binary file if possible */
  
  	assocNam = (fileSpecified == 1);
    if (!readbinary(&fileName,assocNam)) 
        return(FALSE);
 
    /* re-size executor window if neccessary */

    if ((cwX != ExecWinX) || (cwY != ExecWinY)) 
        TUTORsize_exec_window(ExecWinX,ExecWinY);

    /* send switch event to executor window */
   
    ev->type = EVENT_MSG;
    ev->window = ExecWn;
    ev->value = ev->id = ev->timestamp = 0;
    ev->view = FARNULL;
    ev->a1 = exec_switch;
    ev->eDataP = FARNULL;
    TUTORblock_move((char FAR *)ev,(char FAR *)&switchEv,(long)sizeof(struct tutorevent));
    TUTORpost_event(&switchEv);
   
    TUTORflush();
    TUTORnormal_cursor();

    return(TRUE);

} /* ExecJumpout */

/* ******************************************************************* */

InitExecution() /* begin of execution initializations */

{   struct markvar SHUGE *mxp;
    struct markvar mxt;
    int sw, sh;
    long zerlen; /* length to zero on stack */
    int unitn;
 
	exS.ExecQuit = exS.didPalette = FALSE;
	exS.inhibbits = 0; /* pre-clear */
    unitn = exS.execunit;
    exS.yfudge = IntToCoord(1); /* no ega rescale yet */
    TUTORinq_abs_screen_size(&exS.ScreenX0, &exS.ScreenY0, &sw, &sh);
    exS.ScreenW = IntToCoord(sw);
    exS.ScreenH = IntToCoord(sh);
    TUTORline_thick(0);
    DeleteAllAuthorMenus();
    iexec_option_menu();
    clearkeys();
    exS.needredraw = exS.inieu = FALSE;
    defaultinhibit();
    exS.do_errunit = -1; 
    exS.ExecInit = 1; /* initializations done */
    exS.pausetimer = 0;
    exS.imainunit = 0;
    exS.zkey = exS.zdevice = 0;
    exS.zreturn = -1;
    exS.ztouchx = exS.ztouchy = coordZero;
    exS.zrtouchx = exS.zrtouchy = exS.zgtouchx = exS.zgtouchy = 0.;
    exS.FineDone = FALSE; /* no -fine- executed yet */
    exS.CoarseW = 8; exS.CoarseH = 16;
    exS.RescaleX = exS.RescaleY = exS.RescaleT = FALSE;
    exS.ScaleX = exS.ScaleY = coordOne;
    exS.RoundCircles = TRUE;
    exS.ConstrainScale =  TRUE ;
    exS.ClipText = TRUE;
    exS.wrapWrite = exS.inText = exS.inOver = FALSE;
    exS.exactMatch = TRUE;
    exS.sortTable = HNULL;
    exS.imPalF = 8;
    exS.imPalL = 255;
    exS.video_kind = 0; /* no video recognized yet */
    exS.vidX1 = exS.vidX2 = exS.vidY1 = exS.vidY2 = exS.vidMode = 0;
    MovieSound(-1.0); /* default volume level */
    
    TUTORcopy_fileref_dir((FileRef FAR *) currentDirP,(FileRef FAR *)&sourcetable[0].fRef);
    TUTORset_dir(currentDirP);
    
    /* reset fonts */
    /* initialize default fonts etc. */
    /* textFont0, iconFont0, exS.textFont, exS.iconFont, useNativeChars and exS.CharHeight are all
        set in cmd_svers */
    exS.cursorFont = cursorFont0;
    exS.cursorChar = cursorChar0;
    exS.patternFont = patternFont0;
    exS.patternChar = patternChar0;
    TUTORset_fill(exS.patternFont,exS.patternChar);
    TUTORset_cursor(exS.cursorFont,exS.cursorChar);
    exS.SupSub = -1;
    exS.newLine = 0;
    TUTORset_sub_new(exS.SupSub,exS.newLine);
    CTpalette(ExecWn,HNULL,2,HNULL); /* set palette to default colors */

	exS.unClip = TRUE;
    exS.ClipX = exS.ClipY = coordZero;
    exS.ClipX2 = exS.ClipY2 = IntToCoord(10000); 
    exS.GXorigin = exS.GYorigin = coordZero;
    exS.DXneg = exS.DYneg = 0;
    exS.DXplus = exS.DYplus = 100;
    exS.GXoffset = exS.GYoffset = 0.;
    exS.GDelta = 0.0;
    exS.GminorX = exS.GminorY = 0.0;
    exS.GXscale = 1.;
    exS.GYscale = -1.;
    exS.GPolar = FALSE;
    exS.GLogXflag=FALSE;   /* flags for log scales */
    exS.GLogYflag=FALSE;
    exS.RXorigin = exS.RYorigin = coordZero;
    exS.RXsize = exS.RYsize = 1.;
    exS.RAngle = 0.;
    exS.RsinAngle = 0.; 
    exS.RcosAngle = 1.;
    exS.RXsizeFlag = exS.RYsizeFlag = exS.RAngleFlag = FALSE;
    exS.startdrawcnt = 0;
    exS.condt_uloc = 0; /* no conditional command yet */

    if (runflag != halt) {
        /* initialize run-time stack */
        exS.lvars = exS.LockStackRel = 0; /* init relative ptrs */
        ReallocStack(gvaraddr+1000); /* insure enough stack present */

        /* initialize marker variable for judge buffer */

        LockStack(); /* lock stack in memory */
        exS.stackpntr = exS.stackP+gvaraddr;
        exS.lvars = gvaraddr; 
        exS.lvarP = exS.stackpntr;

        mxp = (struct markvar SHUGE *)(exS.stackP); 
        if (mxp->doc == 0) {
            mxp->nextm = mxp->prevm = mxp->vaddr = -1;
            mxp->attached = FALSE; /* not attached to doc update chain */
            mxp->ctvar = TRUE;
            mvar_init((struct markvar SHUGE *)&mxt);
            exS.arr.jbuffer = &mxp[0]; /* judge buffer */
            mvar_assign((struct markvar SHUGE *)&mxp[0],(struct markvar SHUGE *)&mxt);
            mvar_assign((struct markvar SHUGE *)&mxp[1],(struct markvar SHUGE *)&mxt);
            mvar_init((struct markvar SHUGE *)&mxt);
            mvar_assign((struct markvar SHUGE *)&mxp[2],(struct markvar SHUGE *)&mxt);
        } /* mxp->doc if */
    
        if (descP == NULL) 
            descP = GetPtr(descH); /* descriptors locked in memory */
    
        /* zero global variables if defines changed */
    
        if (gvarzero) {
            gvarzero = FALSE;
            zerlen = gvaraddr-3*sizeof(struct markvar); /* zarrowm,zarrowsel, zclipboard */
            TUTORzero((char SHUGE *)(exS.stackP+3*sizeof(struct markvar)),zerlen);
        }
        init_array_desc(0,0L); /* set up global array descriptors */
        
        (*exs_addr[EXS_FLOATINIT])(); /* initialize math co-processor */
    
        /* reset socket information */
        TUTORreset_sockets();
  
        InitMainUnit(FALSE,TRUE); /* not reshape, execute IEU */
        
        if (unittab[unitn].nvargs || unittab[unitn].naargs) {
            if (unitn != sourcetable[0].firstunit) {
                exS.do_errunit = unitn; /* pre-set for execution error */
                exS.do_errpos = 0;
                execerr("Unit has arguments.");
            }
        }
    } /* runflag if */

} /* InitExecution */

/* ******************************************************************* */

InitMainUnit(reshape,ieu) /* main-unit initializations */
int reshape; /* TRUE if reshape event */
int ieu; /* TRUE if should execute IEU */

{   long zerlen; /* length to zero */
    long newl; /* new stack length */
    long varl; /* length of local variables */
    long stackRel; /* relative location in stack */
    int graphicsClose; /* TRUE if should close graphic objects */

    LockStack(); /* insure stack pinned */
    if (!exS.FineDone) DefaultFine();
    graphicsClose = !checkbit(exS.inhibbits,INHOBJDEL);
    items_close(0,0L,FALSE,graphicsClose); /* close graphics items */
    CloseLocalFiles();

    /* set up stack frame for unit */
    /* this does not alter contents of main unit's local */
    /* variables when driven by reshape */

    varl = unittab[exS.execunit].nlvars;
    exS.stackpntr = exS.stackP+gvaraddr;
    stackRel = exS.stackpntr-exS.stackP;
    ReallocStack(stackRel+varl+1000); /* insure enough stack present */
    exS.lvars = exS.mainlvars = exS.stackpntr-exS.stackP; 
    exS.lvarP = exS.stackpntr;
    assign_pfun((long)&exs_addr[EXS_LOCALP],(long)exS.lvarP);
    assign_pfun((long)&exs_addr[EXS_GLOBALP],(long)exS.stackP);
    exS.stackpntr += varl; /* advance stack pointer */
#ifdef IBMPC
    exS.stackpntr += 52; /* round unit status up to 64 byte chunk */
#endif 
    stacks(exS.lvars);
    stacks((long)exS.execunit);
    stacks((long)STACK_MAIN_UNIT);

    /* zero main unit local vars and set up local array descriptors if */
    /* not reshape */

    if (!reshape) {
        TUTORzero((char SHUGE *) (exS.lvarP),unittab[exS.execunit].nlvars);
        /* set local array descriptors */
        init_array_desc(exS.execunit,(long)exS.lvars);
    }
    
    exS.uloc = 0;
    exS.condt_uloc = 0; /* clear cond command */
    exS.proc_obj_unit = 0; /* allow button/slider/hot interrupt */
    exS.hold_objectH = 0; /* no pending post-event unit */
    exS.hold_event.type = -1;
    exS.nextunit = exS.backunit = 0;
    exS.mainunit = exS.execunit;
    exS.arr.iarrowunit = exS.arr.ijudgeunit = exS.arr.eraseuunit = 0;
    exS.arr.arrowunit = -1; /* no arrow exists currently */
    exS.zreshape = reshape;
    exS.pausetype = -1; /* not waiting at a pause */
    if (exS.pausetimer != 0)
    { /* cancel timed pause */
        CancelTrigger(exS.pausetimer);
        exS.pausetimer = 0;
    }
    exS.last_edit = exS.last_button = exS.last_slider = HNULL;
    if (exS.pictF) {
        /* menu sets pictF = 2 and issues redraw */
        if (exS.pictF == 2) 
            exS.pictF = 1;
        else FinishPicture();
    }
    if (!checkbit(exS.inhibbits, INHERASE) && runflag != halt) {
    	MovieClose(1); /* close any open movie/controller */
        setmode(exS.mode = writemode);
        FullScreenErase();
        exS.enablebits = 0; /* touch/ext not enabled */
        enable(exS.enablebits);
        exS.MarginBeginX = exS.MarginBeginY = coordZero;
        exS.ScreenX = exS.ScreenY = coordZero;
        exS.MarginEndX = exS.FineW- coordOne; /* no margins set */
        exS.MarginEndY = exS.FineH - coordOne;
        defaultinhibit();
        TUTORset_event_mask(EVENT_UPMOVE,FALSE);
#ifdef DOPSCRIPT
        if ( pscript )  PostscriptDefaultScreen() ; 
#endif
    } /* checkbit if */
    exS.inhibbits = exS.inhibbits & ~(1L << INHERASE);  /* clear inhibit erase */
    exS.inhibbits = exS.inhibbits & ~(1L << INHOBJDEL); /* clear inhibit objdelete */
	
	if (exS.stepMode == 2) {
		exS.stepMode = 1; /* done stepping over -do- */
		exS.stepStackTarget = 0; /* clear target */
	} /* stepMode if */
	
    /* set to execute main unit */

    InsureUnit(exS.execunit); /* insure unit in memory */
    set_exec_pt(exS.uloc); /* update execution pointer */

    /* generate a -do- of IEU if requested and if IEU is not main unit */

    if (ieu && exS.mainunit) {
        exS.inieu = TRUE; /* flag in ieu */
        dounit(0,0); /* -do- IEU */
    }

    /* generate a -do- of -imain- unit */

    if (exS.imainunit && (exS.imainunit != exS.mainunit)) {
        dounit(exS.imainunit,0);
    }
    
} /* InitMainUnit */

/* ******************************************************************* */

init_array_desc(unitn,stacki) /* initialize array descriptors for current unit */
int unitn; /* unit number to initialize for */
long stacki; /* base of unit in stack */

{   struct unitinfo FAR *uinfo; /* pointer to table entry for this unit */
    struct array_desc FAR *dsp; /* pointer to array descriptor */
    unsigned char FAR *dinfo; /* pointer in array descriptors */
    unsigned char SHUGE *usp; /* pointer to stack base of this unit */
    long dsend; /* end-test on descriptors */
    long SHUGE *lptr; /* pointer in stack */
    long uii;

    dsend = unittab[unitn].descl;
    if (dsend == 0) return(0); /* nothing to do */

    if ((unitn == 0) && stacki) 
        return(0); /* IEU has no local variables */

    usp = exS.stackP+stacki;
    uinfo = &unittab[unitn];
    uii = uinfo->descp; /* index in array/argument descriptors */
    dsend += uii; /* end test */

    /* loop thru array descriptors, initialize index of */
    /* descriptor in long preceding each array */

    while (uii < dsend) {
        dsp = (struct array_desc FAR *)(descP+uii);
        switch (dsp->dtype) {
        
        case 1: /* array descriptor */
            lptr = (long SHUGE *)(usp+dsp->addr);
            if (!dsp->passa) {
                *(lptr) = uii;
                *(lptr+1) = (long)(((char SHUGE *)lptr)+ARRAYHDR); /* array follows */
                *(lptr+2) = -1; /* handle = -1 = on stack */
            }
            uii += sizeof(struct array_desc);
            uii += dsp->ndim*sizeof(struct dim_desc);
            break;
            
        case 2: /* pass-by-value */
        case 3: /* pass-by-address */
            uii += sizeof(struct arg_desc);
            break;
            
        case 4: /* single marker variable */
            uii += sizeof(struct mark_desc);
            break;

        case 5: /* file/bitmap/etc */
            uii += sizeof(struct txtype_desc);
            break;
            
        case 6: /* dynamic array */
            lptr = (long SHUGE *)(usp+dsp->addr);
            if (!dsp->passa) {
                *lptr = uii;
                *(lptr+1) = *(lptr+2) = 0; /* clear ptr, handle */
                dsp->length = 0; /* insure descriptor clear also */
            }
            uii += sizeof(struct array_desc);
            uii += dsp->ndim*sizeof(struct dim_desc);
            
        } /* switch */
    } /* while */

} /* init_array_desc */

/* ******************************************************************* */

items_close(unitn,stacki,vars,graphics) 
/* close marker/bitmap/etc variables for unit */
int unitn; /* unit number */
long stacki; /* base of unit in stack */
int vars; /* TRUE if should close marker vars */
int graphics; /* TRUE if should close graphics items */

{   struct unitinfo FAR *uinfo; /* pointer to table entry for this unit */
    struct array_desc FAR *dsp; /* pointer to array descriptor */
    struct dim_desc FAR *dimp; /* pointer to dimension descriptor */
    struct mark_desc FAR *msp; /* pointer to marker descriptor */
    struct txtype_desc FAR *typ; /* pointer to file/bitmap/etc descriptor */
    unsigned char FAR *dinfo; /* pointer in array descriptors */
    unsigned char SHUGE *usp; /* pointer to stack base of this unit */
    struct markvar SHUGE *mvp; /* pointer to marker variable */
    long SHUGE *lvp; /* pointer to int/float/file/bitmap/etc variable */
    long SHUGE *staktst; /* end of stack test */
    long dsend; /* end-test on descriptors */
    long uii; /* index in descriptors */
    long aii; /* index in array */
    long txscreent; /* TXSCREEN type */
    long txddet; /* TXDDE type */
    Memh dyH; /* handle on dynamic array */

    dsend = unittab[unitn].descl;
    if (dsend == 0) return(0); /* nothing to do */

    if ((unitn == 0) && stacki) 
        return(0); /* IEU has no local variables */

    LockStack(); /* insure stack pinned, pointers set up */
    if (descP == NULL) 
        descP = GetPtr(descH); /* descriptors locked in memory */
    usp = exS.stackP+stacki;
    uinfo = &unittab[unitn];
    uii = uinfo->descp; /* index in array/argument descriptors */
    dsend += uii; /* end test */
    txscreent = ((long)TXSCREEN << 16)+(long)TXTYPE;
    txddet = ((long)TXDDE << 16)+(long)TXTYPE;
    staktst = (long SHUGE *)(exS.stackP+exS.stackmalloc);

    /* loop thru array/marker descriptors, close markers, buttons etc */

    while (uii < dsend) {
        dsp = (struct array_desc FAR *)(descP+uii);
        switch (dsp->dtype) {

        case 1: /* array descriptor */
            if (!dsp->passa) {
                if (dsp->ltype == TMARK) {
                    lvp = (long SHUGE *)(usp+dsp->addr+ARRAYHDR);
                    mvp = (struct markvar SHUGE *)lvp;
                    for(aii=0; aii<dsp->length; aii++) {
                        /* clear next marker variable */
                         if ((long SHUGE *)mvp < staktst) {
                            if (mvp->doc && vars) 
                                mvar_assign((struct markvar SHUGE *)mvp,FARNULL); 
                            mvp++;
                        } /* staktst if */
                     } /* for */
		 } else if ((dsp->ltype == txscreent) || (dsp->ltype == txddet)) {
                    lvp = (long SHUGE *)(usp+dsp->addr+ARRAYHDR);
                    for(aii=0; aii<dsp->length; aii++) {
                        /* clear screen variable */
                        if ((lvp < staktst) && *lvp && vars) 
                            txtype_close(lvp,dsp->ltype);
                        lvp++;
                    } /* for */
                 } else if ((dsp->ltype & 0xffff) == TXTYPE) {
                    lvp = (long SHUGE *)(usp+dsp->addr+ARRAYHDR);
                    for(aii=0; aii<dsp->length; aii++) {
                        /* clear next button/etc variable */
                        if ((lvp < staktst) && *lvp && graphics) 
                            txtype_close(lvp,dsp->ltype);
                        lvp++;
                    } /* for */
                } /* ltype elseif */
            } /* not pass-by-address if */
            uii += sizeof(struct array_desc);
            uii += dsp->ndim*sizeof(struct dim_desc);
            break;

        case 2: /* pass-by-value */
        case 3: /* pass-by-address */
            uii += sizeof(struct arg_desc);
            break;

        case 4: /* single marker variable */
            msp = (struct mark_desc FAR *)dsp;
            lvp = (long SHUGE *)(usp+msp->addr);
            mvp = (struct markvar SHUGE *)lvp;    
            if ((lvp < staktst) && mvp->doc && vars) /* clear next marker variable */
                mvar_assign(mvp,FARNULL); 
            uii += sizeof(struct mark_desc);
            break;

        case 5: /* single button/bitmap/etc variable */
            typ = (struct txtype_desc FAR *)dsp;
            lvp = (long SHUGE *)(usp+typ->addr);  
            if ((lvp < staktst) && *lvp) { /* clear next file/bitmap/etc variable */
		if ((typ->ltype == txscreent) || (typ->ltype == txddet)) {
                    if (vars)
                        txtype_close(lvp,typ->ltype); 
                } else if (graphics)
                    txtype_close(lvp,typ->ltype);
            }
            uii += sizeof(struct txtype_desc);
            break;

        case 6: /* dynamic array */
            if ((!dsp->passa) && vars) {
                lvp = (long SHUGE *)(usp+dsp->addr+sizeof(long));
                dyH = *(lvp+1); /* get handle */
                if (*lvp) { /* handle locked */
                    ReleasePtr(dyH); /* unlock */
                    *lvp = 0; /* clear pointer */
                    exS.dynLocked--;
                } /* lvp if */
                if (dyH) {
                    TUTORfree_handle(dyH); /* release handle */
                    *(lvp+1) = 0; /* clear handle */
                    dimp = (struct dim_desc FAR *)(dsp+1);
                    dsp->length = 0; /* clear descriptor */
                    for(aii=0; aii<dsp->ndim; aii++) {
                        dimp->lower = dimp->length = dimp->multiplier = 0;
                        dimp++; /* advance to next dimension descriptor */
                    }
                } /* dyH if */
                dimp = (struct dim_desc FAR *)(dsp+1);
                dsp->length = 0; /* clear descriptor */
                for(aii=0; aii<dsp->ndim; aii++) {
                    dimp->lower = dimp->length = dimp->multiplier = 0;
                    dimp++; /* advance to next dimension descriptor */
                } /* for */
            } /* not-pass if */
            uii += sizeof(struct array_desc);
            uii += dsp->ndim*sizeof(struct dim_desc);
            break;

        default:
            TUTORdump("Unrecognized array descriptor type");

        } /* switch */
    } /* while */

} /* items_close */

/* ******************************************************************* */

int txtype_close(vaddr,vtype) /* close bitmap/text/etc variable */
long SHUGE *vaddr; /* pointer to variable */
long vtype; /* type of variable */

{   int subtype; /* TXFILE, TXBITMAP, etc */
    Memh objH; /* handle on object header */
    struct ebshdr FAR *objP; /* pointer to object header */

    subtype = (vtype >> 16) & 0xffff;

    switch(subtype) {

    case TXFILE:
        /* do nothing for file - CloseLocal files works differently */
        /* (this should be changed at some point) */
        break;

    case TXEDIT:
        if (exS.last_edit == *vaddr) 
            exS.last_edit = HNULL;
        object_var_close(vaddr); /* close edit object */
        break;

    case TXSLIDER:
        if (exS.last_slider == *vaddr) 
            exS.last_slider = HNULL;
        object_var_close(vaddr); /* close slider object */
        break;

    case TXBUTTON:
        if (exS.last_button == *vaddr)
            exS.last_button = HNULL;
        object_var_close(vaddr); /* close button object */
        break;

    case TXTOUCH:
        if (exS.last_touch == *vaddr)
            exS.last_touch = HNULL;
        object_var_close(vaddr); /* close touch region object */
        break;
        
    case TXSCREEN:
        TUTORfree_region(*vaddr);
        *vaddr = 0;
	break;

    case TXDDE:
	if (exS.last_dde == *vaddr)
	    exS.last_dde = HNULL;
	object_var_close(vaddr); /* close dde object */
	break;

    } /* switch */

    TUTORset_view(ExecVp); /* restore view to executor */
    
} /* txtype_close */

/* ******************************************************************* */

object_var_close(vaddr) /* detach from object header */
long SHUGE *vaddr;

{   Memh objH; /* handle on object header */

    if (vaddr == FARNULL) 
        return(0);
    objH = (Memh)(*vaddr);
    object_close(objH);
    *vaddr = 0;

} /* object_var_close */

/* ******************************************************************* */

object_close(objH) /* detach from object header */
/* returns handle on object data if needs to be closed */
Memh objH; /* handle on object header */

{   struct ebshdr FAR *objP; /* pointer to object header */
    int objT; /* object type */
    Memh basicH; /* handle on underlying object */

    if (!objH) 
        return(0);
    objP = (struct ebshdr FAR *)GetPtr(objH);
    basicH = objP->objectH; /* handle on underlying object */
    objT = objP->type; /* get object type */
    objP->objectH = 0;
    objP->refcnt++;
    ReleasePtr(objH);
    KillPtr(objP);
    
    if (basicH) { /* close underlying button, text, etc */
        exS.nobjects--; /* dec number active objects */
        
        switch (objT) {

        case TXEDIT:
            if (basicH == exS.hold_objectH) {
                exS.hold_event.type = -1; /* cancel pending event */
                exS.hold_objectH = HNULL; /* forget text panel too */
            }
            TUTORclose_panel(basicH);
            break;
                    
        case TXBUTTON:
            TUTORclose_button(basicH);
            break;
                    
        case TXSLIDER:
            TUTORclose_sbar(basicH);
            break;
            
        case TXTOUCH:
            TUTORclose_touch(basicH);
	    break;

	case TXDDE:
	    TUTORclose_dde(basicH);
	    break;
                    
        default: 
            TUTORdump("don't know how to close object");
                
        }; /* switch */
    } /* basicH if */
    
} /* object_close */

/* ******************************************************************* */

inhibit_objects(type)
int type; /* 0 = inhibit, 1 = allow */

{	Memh nextObjH;
	Memh tmpH;
	struct ebshdr FAR *nextObjP;
	
	movieInhibitF = (type == 0);
    nextObjH = exS.next_objH; /* handle on first object header */
    while (nextObjH) {
        nextObjP = (struct ebshdr FAR *)GetPtr(nextObjH);
        tmpH = nextObjP->nextebsH;
        nextObjP->inhibitF = (type == 0); /* TRUE if inhibited */
        if (nextObjP->viewP) {
        	nextObjP->viewP->inhibitF = (type == 0); /* set flag in view also */
        }
        ReleasePtr(nextObjH);
        nextObjH = tmpH;
    } /* while */
    TUTORset_key_focus(ExecWn,ExecVp,FALSE);
    
} /* inhibit_objects */

/* ******************************************************************* */

inhibit_editdraw(type)
int type; /* 0 = inhibit, 1 = allow */

{	Memh nextObjH;
	Memh tmpH;
	Memh basicH; /* handle on underlying object (text panel) */
	struct ebshdr FAR *nextObjP;
	TextVDat FAR *vp; /* pointer to text panel data */
	int uState; 
	struct tutorview FAR *cv; /* current view */
	
    nextObjH = exS.next_objH; /* handle on first object header */
    cv = TUTORinq_view(); /* save current view */

    while (nextObjH) {
        nextObjP = (struct ebshdr FAR *)GetPtr(nextObjH);
        tmpH = nextObjP->nextebsH;
        basicH = nextObjP->objectH;
        if (basicH && nextObjP->type == TXEDIT) {
    		vp = (TextVDat FAR *) GetPtr(basicH); 
    		if (type == 0) { /* inhibit */
    			if (vp->inhibitState == 0)
    				vp->inhibitState = 1;  
    		} else { /* allow */
    			uState = vp->inhibitState;
    			vp->inhibitState = 0;
    		
    			if (uState == 2) {
    				TUTORset_view(vp->view); /* set to text view */
					Refresh1Panel(vp,vp->ihPos,vp->ihLen,vp->ihCpos,vp->ihClen,vp->ihNewC,
				             vp->ihSelStart,vp->ihSelLen,vp->ihScroll,vp->ihForce);
					TUTORset_view(cv); /* restore view */
				}
    		}  
    		ReleasePtr(basicH);  
		}
        ReleasePtr(nextObjH);
        nextObjH = tmpH;
    } /* while */
    
} /* inhibit_editdraw */

/* ******************************************************************* */

unstack_all_units() /* remove all units from stack */
/* used by -jump- and similar operations which begin a new main unit */

{   int sunit; /* current unit number */
    long lvarb; /* current base of lvars */
    long blockRel; /* relative location of block begin */
    int sloop; /* TRUE if should continue loop */
    int stackc; /* current type of stacked item */
    Memh arrdoc; /* handle on arrow-related document */

    if (exS.stackpntr <= (exS.stackP+gvaraddr)) 
        return(0); /* nothing to unstack */

    /* back out of -do-/-arrow- stack */

    sloop = TRUE; /* not at top of stack yet */
    sunit = lvarb = -1; /* dont know unit/lvars yet */
    do {
        stackc = unstacks();
        switch (stackc) {

        case STACK_MAIN_UNIT:
            sloop = FALSE; /* stop at top of local stack */
        case STACK_UNIT:
            sunit = unstacks(); /* unit number */
            lvarb = unstacks(); /* get base of lvars */
            items_close(sunit,lvarb,TRUE,TRUE); /* close local markers */
            exS.stackpntr = exS.stackP+lvarb; /* unstack locals */
            break;

        case STACK_DO:
            lvarb = unstacks(); /* base of lvars for new top unit */
            unstacks(); /* condt_uloc */
            unstacks(); /* uloc */
            sunit = unstacks(); /* new top unit */
#ifdef IBMPC
            exS.stackpntr -= 44; /* -do- status is 64 bytes on PC */
#endif
            break;  
            
        case STACK_ARROW:
#ifdef IBMPC
            exS.stackpntr -= 60; /* -arrow- status is 64 bytes on PC */
#endif
            CloseArrow(FALSE);
            break;

        case STACK_ARROW_NEST:
            CloseArrow(FALSE);
            unstackblock((unsigned char *)&exS.arr,(int)sizeof(struct arrows));
            unstacks(); /* len */
            unstacks(); /* pos */
            arrdoc = unstacks(); /* jbuffer doc */
#ifdef IBMPC
            exS.stackpntr -= exS.arrExtra; /* status is multiple of 64 bytes*/
#endif
            mvar_ref_doc(arrdoc); /* allow clean-up of document */
            break;

        default:
            TUTORdump("unrecognized stack code");

        } /* switch */
    } while (sloop);

} /* unstack_all_units */

/* ******************************************************************* */

release_dyn_arrays() /* release all dynamic arrays */

{
    if (!exS.dynLocked) 
        return(0); /* nothing to unlock */
        
    trace_thru_stack(1); /* release dynamic arrays */
    trace_thru_descriptors(1,0,0L); /* release global dynamic arrays */
    
} /* release_dyn_arrays */

/* ******************************************************************* */

set_array_addresses() /* set addresses of global/local arrays */

{
    trace_thru_stack(2); /* set addresses of local arrays */
    trace_thru_descriptors(2,0,0L); /* set addresses of global arrays */
    
} /* set_array_addresses */

/* ******************************************************************* */

static int trace_thru_stack(type) /* trace thru all items on stack */
int type; /* type of operation to perform */
          /* = 1 = release (allow to move) dynamic arrays */
          /* = 2 = set addresses of global/local arrays */
          /* = 3 = no-op */
          
{   int sunit; /* current unit number */
    long lvarb; /* current base of lvars */
    int sloop; /* TRUE if should continue loop */
    int stackc; /* current type of stacked item */
    Memh arrdoc; /* handle on arrow-related document */
    long blockRel; /* relative location of start of block */
    char SHUGE *stackP; /* pointer in do/unit stack */

    if (exS.stackpntr <= (exS.stackP+gvaraddr)) 
        return(0); /* nothing on stack */

    /* loop backwards thru -do-/-arrow- stack */

    sloop = TRUE; /* not at top of stack yet */
    sunit = lvarb = -1; /* dont know unit/lvars yet */
    stackP = (char SHUGE *)exS.stackpntr;
    do {
        stackP -= sizeof(long);
        stackc = *(long SHUGE *)stackP;

        switch (stackc) {

        case STACK_MAIN_UNIT:
            sloop = FALSE; /* stop at top of local stack */
        case STACK_UNIT:
            stackP -= sizeof(long);
            sunit = *(long SHUGE *)stackP; /* unit number */
            stackP -= sizeof(long);
            lvarb = *(long SHUGE *)stackP; /* get base of lvars */
            if (type != 3)
                trace_thru_descriptors(type,sunit,lvarb); /* do descriptors */
            stackP = (char SHUGE *)(exS.stackP+lvarb); /* back over locals */
            break;

        case STACK_DO:
            stackP -= sizeof(long);
            lvarb = *(long SHUGE *)stackP; /* base of lvars for new top unit */
            stackP -= 3*sizeof(long);
            sunit = *(long SHUGE *)stackP; /* new top unit */
#ifdef IBMPC
            stackP -= 44; /* -do- status is 64 bytes on PC */
#endif
            break;  
            
        case STACK_ARROW:
#ifdef IBMPC
            stackP -= 60; /* -arrow- status is 64 bytes on PC */
#endif
            break;

        case STACK_ARROW_NEST:
            stackP -= (sizeof(struct arrows)+3*sizeof(long));
#ifdef IBMPC
            stackP -= exS.arrExtra; /* remove modulo 64 byte filler on PC */
#endif
            break;

        default:
            TUTORdump("unrecognized stack code");

        } /* switch */
    } while (sloop);

} /* trace_thru_stack */

/* ******************************************************************* */

static trace_thru_descriptors(type,unitn,stacki) 
/* trace thru array descriptors for unit */
int type; /* type of operation to perform */
          /* = 1 = release dynamic arrays for unit */
          /* = 2 = set addresses of global/local arrays */
int unitn; /* unit number */
long stacki; /* base of unit in stack */

{   struct unitinfo FAR *uinfo; /* pointer to table entry for this unit */
    struct array_desc FAR *dsp; /* pointer to array descriptor */
    unsigned char FAR *dinfo; /* pointer in array descriptors */
    unsigned char SHUGE *usp; /* pointer to stack base of this unit */
    struct markvar SHUGE *mvp; /* pointer to marker variable */
    long SHUGE *lvp; /* pointer to int/float/file/bitmap/etc variable */
    long dsend; /* end-test on descriptors */
    long uii; /* index in descriptors */
    long aii; /* index in array */
    Memh dyH; /* handle on dynamic array */

    dsend = unittab[unitn].descl;
    if (dsend == 0) return(0); /* nothing to do */

    if ((unitn == 0) && stacki) 
        return(0); /* IEU has no local variables */

    if (!exS.stackLocked)
        return(0); /* no can do - stack not locked */
        
    if (descP == NULL) 
        descP = GetPtr(descH); /* descriptors locked in memory */
    usp = exS.stackP+stacki;
    uinfo = &unittab[unitn];
    uii = uinfo->descp; /* index in array/argument descriptors */
    dsend += uii; /* end test */

    /* loop thru array/marker descriptors, close markers, buttons etc */

    while (uii < dsend) {
        dsp = (struct array_desc FAR *)(descP+uii);
        switch (dsp->dtype) {

        case 1: /* array descriptor */
            if ((type == 2) && (!dsp->passa)) {
                lvp = (long SHUGE *)(usp+dsp->addr);
                *(lvp+1) = (long)(((char SHUGE *)lvp)+ARRAYHDR); /* array follows */
            }
            uii += sizeof(struct array_desc);
            uii += dsp->ndim*sizeof(struct dim_desc);
            break;

        case 2: /* pass-by-value */
        case 3: /* pass-by-address */
            uii += sizeof(struct arg_desc);
            break;

        case 4: /* single marker variable */
            uii += sizeof(struct mark_desc);
            break;

        case 5: /* single button/bitmap/etc variable */
            uii += sizeof(struct txtype_desc);
            break;

        case 6: /* dynamic array */
            if ((type == 1) && (!dsp->passa)) {
            
                /* release dynamic array */
                
                lvp = (long SHUGE *)(usp+dsp->addr+sizeof(long));
                dyH = *(lvp+1); /* get handle */
                if (*lvp) { /* handle locked */
                    ReleasePtr(dyH); /* unlock */
                    *lvp = 0; /* clear pointer */
                    exS.dynLocked--;
                }
            } /* not-pass if */
            uii += sizeof(struct array_desc);
            uii += dsp->ndim*sizeof(struct dim_desc);
            break;

        default:
            TUTORdump("Unrecognized array descriptor type");

        } /* switch */
    } /* while */

} /* trace_thru_descriptors */

/* ******************************************************************* */

set_last_edit(objH,objref) /* set zedit */
Memh objH; /* handle on object header */
int objref; /* reference count on object header */

{   struct ebshdr FAR *objP;
    int hdrrefc; /* reference count from header */

    hdrrefc = -1; 
    if (objH) {
        objP = (struct ebshdr FAR *)GetPtr(objH);
        hdrrefc = objP->refcnt; /* get reference count from header */
        ReleasePtr(objH);
        KillPtr(objP);
    }
    if ((objref != get_edit_ref(objH)) || (objref != hdrrefc) || (!objref))
        objH = objref = 0; /* edit object no longer valid */
    exS.last_edit = objH;
    exS.last_edit_ref = objref;
    return(0);

} /* set_last_edit */

/* ******************************************************************* */

set_last_button(objH,objref) /* set zbutton */
Memh objH; /* handle on object header */
int objref; /* reference count on object header */

{   struct ebshdr FAR *objP;
    int hdrrefc; /* reference count from header */
     
    hdrrefc = -1; 
    if (objH) {
        objP = (struct ebshdr FAR *)GetPtr(objH);
        hdrrefc = objP->refcnt; /* get reference count from header */
        ReleasePtr(objH);
        KillPtr(objP);
    }
    if ((objref != get_button_ref(objH)) || (objref != hdrrefc) || (!objref))
        objH = objref = 0; /* object is no longer valid */
    exS.last_button = objH;
    exS.last_button_ref = objref;
    return(0);

} /* set_last_button */

/* ******************************************************************* */

set_last_slider(objH,objref) /* set zslider */
Memh objH; /* handle on object header */
int objref; /* reference count on object header */

{   struct ebshdr FAR *objP;
    int hdrrefc; /* reference count from header */

    hdrrefc = -1; 
    if (objH) {
        objP = (struct ebshdr FAR *)GetPtr(objH);
        hdrrefc = objP->refcnt; /* get reference count from header */
        ReleasePtr(objH);
        KillPtr(objP);
    }
    if ((objref != get_slider_ref(objH)) || (objref != hdrrefc) || (!objref))
        objH = objref = 0; /* object is no longer valid */
    exS.last_slider = objH;
    exS.last_slider_ref = objref;
    return(0);

} /* set_last_slider */

/* ******************************************************************* */

Memh find_free_object(type) /* find free object header */
int type; /* type of object */

{   Memh ObjH; /* handle on object */
    struct ebshdr FAR *ObjP; /* pointer to object */
    Memh nextH; /* handle on next object */
    
    ObjH = exS.next_objH; /* handle on 1st object in chain */
    while (ObjH) {
        ObjP = (struct ebshdr FAR *)GetPtr(ObjH);
        if (ObjP->objectH == HNULL)
            break; /* found free header, exit while */
        nextH = ObjP->nextebsH;
        ReleasePtr(ObjH);
        KillPtr(ObjP);
        ObjH = nextH; /* forwards to next object */
    }
    if (ObjH == HNULL) { /* create a new header */
        ObjH = TUTORhandle("ebshdr",(long)sizeof(struct ebshdr),TRUE);
        ObjP = (struct ebshdr FAR *)GetPtr(ObjH);
        ObjP->nextebsH = exS.next_objH;
        exS.next_objH = ObjH;
        ObjP->refcnt = 0;
        TUTORpurge_info(ObjH,M_WMRM,FARNULL,0);
        AllowHandlePurge(ObjH);
    }   
 
    ObjP->refcnt++; /* unique id for instance of object */
    ObjP->inhibitF = FALSE; /* not inhibited */
    ObjP->type = type; /* set object type */
    ObjP->viewP = FARNULL; /* no view yet */
    ReleasePtr(ObjH);
    return(ObjH); /* return handle on object header */
    
} /* find_free_object */

/* ******************************************************************* */

defaultinhibit() /* set default inhibit bits */

{	long saveBits;

	saveBits = exS.inhibbits & ((1L << INHDEGREE) | (1L >> INHFUZZY));
    exS.inhibbits = 1L << INHBLANKS;
    exS.inhibbits |= saveBits;

} /* defaultinhibit */
/* ******************************************************************* */

int InitialStack()

{	int ri;
	long target;
	char SHUGE *sP;
	
	target = gvaraddr+1500L;
	if (exS.stackmalloc >= target)
		return(TRUE);
	ri = TUTORset_hsize(exS.stackH,target,FALSE);
	if (ri) {
		sP = (char SHUGE *)GetPtr(exS.stackH);
		TUTORzero(sP,target-exS.stackmalloc);
		ReleasePtr(exS.stackH);
		exS.stackmalloc = target;
	}
	return(ri);
}

/* ******************************************************************* */

ReallocStack(newl) /* increase the size of the stack */
long newl;
    
{   long oldl;
    long rptr; /* relative location of stackptr */
    long lptr; /* relative location of lvarp */
    struct markvar SHUGE *mvp;

    oldl = exS.stackmalloc;
    if (oldl > (newl+100L))
        return(0);

    /* get relative values of stack pointers */

    rptr = exS.stackpntr-exS.stackP;
    lptr = exS.lvarP-exS.stackP;

    exS.stackmalloc = newl+1000;
    ReleaseStack(); /* allow memory move */
    
    if (!TUTORset_hsize(exS.stackH,exS.stackmalloc,FALSE)) {
    	char memMsg[80];
    	
        exS.stackmalloc = oldl;
        sprintf(memMsg,"Out of memory, failed to get %ld bytes",newl);
        execerr(memMsg);
    } 
    LockStack(); /* get pointer on stack */
    TUTORzero((char SHUGE *) (exS.stackP+oldl),(long)(exS.stackmalloc-oldl)); 

    /* restore stack pointers */

    exS.stackpntr = exS.stackP+rptr;
    exS.lvarP = exS.stackP+lptr;

    assign_pfun((long)&exs_addr[EXS_LOCALP],(long)exS.lvarP);
    assign_pfun((long)&exs_addr[EXS_GLOBALP],(long)exS.stackP);
    
    mvp = (struct markvar SHUGE *)(exS.stackP);
    exS.arr.jbuffer = mvp;
    return(0);
    
} /* ReallocStack */

/* ******************************************************************* */

dounit(unitn,loc) 
int unitn; /* unit to -do- */
int loc; /* starting position in unit */

{   long stackrel;

    /* be sure there is adequate space on the stack */

    stackrel = exS.stackpntr-exS.stackP;
    ReallocStack((long)(stackrel+unittab[unitn].nlvars+64L+64L));

    /* stack status for current unit */

#ifdef IBMPC
    exS.stackpntr += 44; /* -do- status is 64 bytes on PC */
#endif
    stacks((long)exS.execunit);
    stacks((long)exS.uloc);
    stacks((long)exS.condt_uloc);
    stacks(exS.lvars);
    stacks((long)STACK_DO);

    /* set to new unit */

    exS.execunit = unitn;
    exS.uloc = loc;

    /* set up stack frame for new unit */

    stackrel = exS.stackpntr-exS.stackP;
    exS.stackpntr = exS.stackP+stackrel; /* stack may have moved */
    exS.lvarP = exS.stackpntr;
    exS.lvars = stackrel;
    assign_pfun((long)&exs_addr[EXS_LOCALP],(long)exS.lvarP);
    exS.stackpntr += unittab[unitn].nlvars; /* advance past local vars */
#ifdef IBMPC
    exS.stackpntr += 52; /* round unit status up to 64 byte chunk */
#endif 
    stacks(exS.lvars);
    stacks((long)unitn);
    stacks((long)STACK_UNIT);
    TUTORzero((char SHUGE *)(exS.lvarP),unittab[unitn].nlvars);

    /* set local array descriptors */
    init_array_desc(unitn,(long)exS.lvars);
    InsureUnit(exS.execunit); /* insure unit in memory */
    set_exec_pt(exS.uloc); /* update execution pointer */

    if (unittab[unitn].nvargs || unittab[unitn].naargs) {
        exS.do_errunit = unitn; /* pre-set for execution error */
        exS.do_errpos = 0;
        if (unittab[unitn].nvargs)
            execerr("Incorrect number of pass-by-value arguments.");
        if (unittab[unitn].naargs)
        execerr("Incorrect number of pass-by-address arguments.");
    }
    
} /* dounit */

/* ******************************************************************* */

int marker_file_name(mx,fullRef,symbolic)
struct markvar SHUGE *mx; /* pointer to marker status block */
struct _fref FAR *fullRef;
int symbolic;  /* TRUE if file name may be symbolic rather than pathname */

{   char wfn[CTPATHLEN+1]; /* scratch */
    char FAR *sp;
    int mlen; /* marker length */
    int ret;

    mlen = mx->len;
    if (mlen <= 0) {
        execerr("Illegal file name");
    }
    if (mlen > CTPATHLEN) {
        execerr("File name too long.");
    }
    
    TUTORget_string_doc(mx->doc,mx->pos,(long) mlen,(unsigned char FAR *) wfn);
    if (!translate_ct_string((unsigned char *) wfn))
        execerr("Illegal character in file name.");
    
    if (symbolic)
        { /* check for symbolic name first */
        /* checks for archaic font names */
        if (strcmp(wfn,"shape10") == 0)
            strcpy(wfn,"zpatterns");
        else if (strcmp(wfn,"icon12") == 0)
            strcpy(wfn, "zicons");
        if (TUTORis_symbolic(wfn))
            { /* it is a symbolic name */
            TUTORsymbolic_fileref(fullRef, (char FAR *) wfn);
            return(0);
            }
        }

    /* at this point we know wfn must be a pathname */
    TUTORcvt_path(wfn,fullRef,currentDirP,TRUE);

    return(0);

} /* marker_file_name */


/* ******************************************************************* */
translate_ct_string(s0)
unsigned char *s0;
/* returns FALSE for a string with an illegal character */
    {
    register unsigned char cc, *ss;
    register int len;
    
    if (!s0)
        return(TRUE); /* no string to check */
    
    /* first check for illegal characters */
    ss = s0;
    while (TRUE)
        {
        cc = *ss;
        if (!cc)
            break;
        if (cc == 127 || (cc & 0x7f) < 32)
            return(FALSE);
        ss++;
        }
    len = ss - s0;
    
    /* now translate characters */
    TUTORcvt_ct_chars((unsigned char FAR *) s0,(long) len);

    return(TRUE);
    }

/*********************************************/

#ifdef ANDREW
#define UNIX_EXEC
#endif

#ifdef X11
#define UNIX_EXEC
#endif

#ifdef UNIX_EXEC
executeit(xstr)  /* execute UNIX command */
char *xstr; /* pointer to UNIX command string */
/*
  For every file name beginning with alpha (e.g., not slash)
  in the tag of the -execute- command,
  see whether it is in the author directory,
  in which case add the prefix sourceDir
  before driving the execution.
*/
{
#define LINELIMIT 300
char tag[LINELIMIT+3], line[LINELIMIT+3], new[CTPATHLEN];
FileRef sfull;
char *from, *to, *p;
char FAR *pFar;
int along, count, hastilde, tocnt;

strncpy(tag,xstr,LINELIMIT); /* copy command string */
tag[LINELIMIT] = '\0'; /* insure terminated */
TUTORcopy_fileref((FileRef FAR *)&sfull,sourceDirP);
along = strlen(sfull.path);
from = tag;
to = line;
tocnt = 0; /* count number of chars added to output line */
count = 0; /* count of files and flags in tag */
while (*from != '\0') {
   while (*from == ' ') {
    if (++tocnt > LINELIMIT) execiterr();
    *(to++) = *(from++); /* leading spaces */
    }
   if (*from == '\0') break;
   if (!(CTisalpha(*from) || *from == '~'))
      while (!(*from == ' ' || *from == '\0')) {
    if (++tocnt > LINELIMIT) execiterr();
    *(to++) = *(from++);
    }
   else {
      hastilde = (*from == '~');
      p = new;
      while (!(*from == ' ' || *from == '\0')) *(p++) = *(from++);
      *p = '\0';
      if (hastilde) p = FullName(new, FARNULL); /* convert ~file to full path name */
      else {  /* starts with alpha, file may be in author directory */
         TUTORcopy_fileref_name(&sfull,(char FAR *) new);
         p = new;
         if (TUTORfile_exists(&sfull)) p = sfull.path; /* if in author directory */
         }
       while (*p != '\0') {
    if (++tocnt > LINELIMIT) execiterr();
    *(to++) = *(p++);
    }
       }
       count++;
   }
*to = '\0';

/* if just filename.t, make it ct -x filename.t */
if (count == 1 && strlen(line) > 2 && (strlen(line)+6) < LINELIMIT &&
      *(to-2) == '.' && *(to-1) == 't') {
   strcpy(sfull.path, "ct -x ");
   strcat(sfull.path, line);
   strcpy(line, sfull.path); 
}
   
/* now we can execute the contents of line[] */

FlushAllFiles();    /* flush authors files */
system2(line,FALSE);
}

execiterr() {
    execerr("-execute- string too long to handle.") ;
}

#else
#ifndef WINPC
executeit(ss) char * ss; {;}
#endif
#endif /* UNIX_EXEC */


/* ******************************************************************* */

marker_to_string(mx,s,limit) /* extract string from marker */
struct markvar SHUGE *mx; /* addr of marker status */
char *s; /* destination string */
int limit; /* number characters to extract */

{   long mlen; /* marker length */

    mlen = mx->len;
    if (mlen >= limit)
        mlen = limit; /* clip */

    TUTORget_string_doc(mx->doc,0L,(long) mlen,(unsigned char FAR *) s);
    s[mlen] = 0; /* zero pad */

} /* marker_to_string */

/* ******************************************************************* */

EndUnitMenus() 

{
    MakeMenus();
    DeleteExecMenus();
    if (!checkbit(exS.inhibbits,INHOPTION)) {
    	if (exS.nextunit != 0) {
        	if (!checkbit(exS.inhibbits, INHERASE))
            	TUTORadd_menu(exS.execmenus,NEARNULL,0,"(Next Page)",96,0,exec_next,0,0.0,EVENT_MENU);
        	else
            	TUTORadd_menu(exS.execmenus,NEARNULL,0,"(Proceed)",97,0,exec_next,0,0.0,EVENT_MENU);
    	} /* exS.nextunit if */
    	if (exS.backunit != 0) 
        	TUTORadd_menu(exS.execmenus,NEARNULL,0,"(Back)",98,0,exec_back,0,0.0,EVENT_MENU);
	}
	
} /* EndUnitMenus */

/* ******************************************************************* */

PauseMenus() 

{   int loc;

    MakeMenus();
    DeleteExecMenus();
    
    if (!checkbit(exS.inhibbits,INHOPTION)) {
    	loc = exS.uloc;
    	if (checkkey(KNEXT)) 
        	TUTORadd_menu(exS.execmenus,NEARNULL,0,"(Proceed)",97,0,exec_next,0,0.0,EVENT_MENU);
    	exS.uloc = loc; /* checkkey can change uloc */
    	if (checkkey(KBACK) && exS.backunit != 0)
        	TUTORadd_menu(exS.execmenus,NEARNULL,0,"(Back)",98,0,exec_back,0,0.0,EVENT_MENU);
		exS.uloc = loc; /* checkkey can change uloc */
	}

} /* PauseMenus */

/* ******************************************************************* */

ArrowMenus() 

{
    MakeMenus();
    DeleteExecMenus();
    if (!checkbit(exS.inhibbits,INHOPTION)) {
	    TUTORset_event_mask(EVENT_PASTE,TRUE);
#ifdef MAC
	    TUTORadd_menu(exS.execmenus,NEARNULL,0,"Cut",25,'X',exec_cut,2,0.0,EVENT_MENU);
	    TUTORadd_menu(exS.execmenus,NEARNULL,0,"Copy",30,'C',exec_copy,3,0.0,EVENT_MENU);
	    TUTORadd_menu(exS.execmenus,NEARNULL,0,"Paste",35,'V',exec_paste,0,0.0,EVENT_MENU);
#else
	    TUTORadd_menu(exS.execmenus,NEARNULL,0,"Paste",20,0,exec_paste,0,0.0,EVENT_MENU);
	    TUTORadd_menu(exS.execmenus,NEARNULL,0,"Cut",25,0,exec_cut,2,0.0,EVENT_MENU);
	    TUTORadd_menu(exS.execmenus,NEARNULL,0,"Copy",30,0,exec_copy,3,0.0,EVENT_MENU);
#endif
	    TUTORadd_menu(exS.execmenus,NEARNULL,0,"(Enter Response)",40,0,exec_response,0,0.0,EVENT_MENU);
	    if (exS.backunit != 0) 
	        TUTORadd_menu(exS.execmenus,NEARNULL,0,"(Back)",45,0,exec_back,0,0.0,EVENT_MENU);
	}
	
} /* ArrowMenus */

/* ******************************************************************* */

ArrowOkNoMenus() /* menus for ok/no state */

{
    DeleteExecMenus();
    if (!checkbit(exS.inhibbits,INHOPTION)) {
    	if (exS.backunit != 0) 
        	TUTORadd_menu(exS.execmenus,NEARNULL,0,"(Back)",45,0,exec_back,0,0.0,EVENT_MENU);
	}
	
} /* ArrowOkNoMenus */

/*********************************************/
ExecMenus() { /* used while executing */

DeleteExecMenus();
flush(); /* make sure altered menus appear */
}

/* ******************************************************************* */

DeleteExecMenus() 

{   struct tutorview FAR *cv;   /* current view number */

    cv = TUTORinq_view();
    TUTORset_view(ExecVp); /* insure executor view */
    TUTORdelete_menu(exS.execmenus,NEARNULL,"(Proceed)");
    TUTORdelete_menu(exS.execmenus,NEARNULL,"(Next Page)");
    TUTORdelete_menu(exS.execmenus,NEARNULL,"(Enter Response)");
    TUTORdelete_menu(exS.execmenus,NEARNULL,"(Back)");
    TUTORdelete_menu(exS.execmenus,NEARNULL,"Paste");
    TUTORdelete_menu(exS.execmenus,NEARNULL,"Cut");
    TUTORdelete_menu(exS.execmenus,NEARNULL,"Copy");
    TUTORdelete_menu(exS.execmenus,NEARNULL,"Replace");
    TUTORset_view(cv); /* restore previous view */

} /* DeleteExecMenus */

/* ******************************************************************* */

DeleteAllAuthorMenus()  /* delete all author menus */

{   struct tutorview FAR *cvn; /* current view number */

    cvn = TUTORinq_view();
    TUTORset_view(ExecVp);  /* set to executor main view */
    TUTORdelete_author_menus(exS.execmenus);
    TUTORset_view(cvn); /* restore view */

} /* DeleteAllAuthorMenus */

/* ******************************************************************* */

DoMenuUnit(inexec,unitn,paramf,param)
int inexec; /* TRUE if already in executor (executing commands) */
int unitn; /* unit number to -do- */ 
int paramf; /* TRUE if argument to unit */
double param; /* value of argument to unit */

{   struct arg_desc FAR *argp; /* pointer to argument descriptor */
    unsigned char SHUGE *vaddr; /* address of variable */
    long stackrel;
    int restoreArrow; /* TRUE if we want to reactivate arrow */

    if (unitn == UNITX)
        return; /* nothing to do if unit "x" */
    LockStack(); /* insure stack pinned, pointers set up */
    restoreArrow = FALSE; /* assumme that no arrow is running */
    if (!inexec) { /* if not currently executing commands */
        if (exS.pausetimer) {
            CancelTrigger(exS.pausetimer); /* stop timing */
            exS.pausetimer = 0; 
        }
        if (waitflag == atpause)
            exS.uloc = exS.pauseuloc;
        else if (waitflag == atarrow) { /* we want to come back to arrow */
            if (exS.arr.arrowState == 3)
                exS.arr.arrowState = 4; /* special handling for menu when in arrow ok/no state */
            rejudge();
            restoreArrow = ActivateArrow(FALSE); /* turn off the current arrow */
            exS.uloc = exS.arr.arrowuloc;
        }
    } /* inexec if */

    /* be sure there is adequate space on the stack */

    stackrel = exS.stackpntr-exS.stackP;
    ReallocStack((long)(stackrel+unittab[unitn].nlvars+64L+64L));

#ifdef IBMPC
    exS.stackpntr += 44; /* -do- status is 64 bytes on PC */
#endif
    stacks((long)exS.execunit);
    stacks((long)exS.uloc);
    stacks((long)exS.condt_uloc);
    stacks(exS.lvars);
    stacks((long)STACK_DO);
    exS.execunit = unitn;
    exS.uloc = 0;
    waitflag = runflag;

    /* set up stack frame for menu unit */

    stackrel = exS.stackpntr-exS.stackP;
    exS.stackpntr = exS.stackP+stackrel; 
    exS.lvarP = exS.stackpntr;
    assign_pfun((long)&exs_addr[EXS_LOCALP],(long)exS.lvarP);
    exS.lvars = exS.stackpntr-exS.stackP;
    exS.stackpntr += unittab[unitn].nlvars;
#ifdef IBMPC
    exS.stackpntr += 52; /* make unit status a 64 byte chunk */
#endif
    stacks(exS.lvars);
    stacks((long)unitn);
    stacks((long)STACK_UNIT);
    TUTORzero((char SHUGE *)(exS.lvarP),unittab[unitn].nlvars);

    /* set local array descriptors */
    init_array_desc(unitn,(long)exS.lvars);
    
    /* check correct number of arguments */
    
    if ((paramf && (unittab[unitn].nvargs != 1)) ||
        ((!paramf) && unittab[unitn].nvargs) ||
        unittab[unitn].naargs) {
        exS.do_errunit = unitn; /* set for execution error */
        exS.do_errpos = 0;
        execerr("unit has incorrect number of arguments");
    }

    /* pass value arg if present */

    if (paramf) {
        argp = (struct arg_desc FAR *)
              (descP+unittab[unitn].descp+unittab[unitn].argdesc);
        if (argp->ltype == TMARK) {
            exS.do_errunit = unitn; /* set for execution error */
            exS.do_errpos = 0;
            execerr("unit has wrong argument type.");
        }
        if (argp->global) vaddr = exS.stackP+argp->addr;
        else vaddr = exS.lvarP+argp->addr; 
        fputvar(vaddr,(int)argp->ltype,param); /* set value */
    } /* paramf if */
	
    if (inexec) {
        if (pcodeh) {
            ReleasePtr(pcodeh);
            KillPtr(pcodep);
        }
        pcodeh = 0;
        InsureUnit(exS.execunit); /* insure unit is in memory */
        set_exec_pt(exS.uloc);
    } else
        executor(); /* execute unit */

    if (restoreArrow)
        ActivateArrow(TRUE); /* turn current arrow back on */

} /* DoMenuUnit */

/* ******************************************************************* */

int TellExecInt() /* tell executor to interrupt */

{
	exS.shouldint = TRUE;
	
} /* TellExecInt */

/* ******************************************************************* */

Randum(begin,end) /* return integer between begin and end */
int begin, end ; {
#ifdef MAC
  int rand;
  rand = begin + (((long)Random()+32767L) % (end+1-begin));
  return ( rand ) ;
#else
  return ( begin + (TUTOR_random() % (end+1-begin)) ) ;
#endif
}

/* ******************************************************************* */

execerr(msgstr) /* execution error exit */
char *msgstr;

{   int unitn; /* unit number of error */
    long srcloc; /* starting location of error line in source */
    int nchars; /* number chars in error line */
    long eventid; /* id of editor error event */
    int ilin; /* index of message line */
    struct tutorevent errevent; /* event for editor */
    unsigned char SHUGE *sptr; /* pointer in exS.stackP */
    int stackc; /* current stack item type */
    int sunit; /* current unit number while unstacking */
    long slvars; /* current base of lvars while unstacking */
    long blockRel; /* relative loc of block on stack */
    int ovlf; /* TRUE if too deep in -do- for display */
    int fileI; /* index of file error is in */
    long tempL;
    char unitname[NAMEL+1];

    /* set up error messages - 1st line is error type */

	errevent.eDataP = FARNULL;
	errevent.type = 0; /* set harmlessly in case we don't generate event */
    if (exec_err_msg == NULL)
        exec_err_msg = TUTORalloc(1000L,TRUE,"errmsg"); /* allocate msg buffer */
    ilin = 1;
    strcpyf(exec_err_msg,(char FAR *)msgstr);
   
    /* 2nd line is unit in which error occurred */

	strcatf(exec_err_msg,NEWLINES);
    strcatf(exec_err_msg,"in unit: ");
    GetUnitName(exS.execunit,(unsigned char *) unitname);
    strcatf(exec_err_msg,(char FAR *) unitname);
	ilin++;
    
    /* trace backwards thru stack */

    ovlf = FALSE; /* not too deep in -do- yet */
    if (exS.stackpntr > (exS.stackP+gvaraddr)) {
        sptr = exS.stackpntr;
        sunit = -1; /* dont know unit yet */
        do {
            sptr -= sizeof(long);
            stackc = *(long SHUGE *)sptr; /* pop next item from stack */

            switch (stackc) {

            case STACK_MAIN_UNIT:
                break; /* back at top of stack */
        
            case STACK_UNIT:
                sptr -= sizeof(long);
                sunit = *(long SHUGE *)sptr; /* pop next unit # */
                sptr -= sizeof(long);
                slvars = *(long SHUGE *)sptr; /* pop base of lvars */
                sptr = exS.stackP+slvars; /* pop local variables */
                break;

            case STACK_DO:
                sptr -= 4*sizeof(long); /* pop lvars, condt, uloc, unit */
                sunit = *(long SHUGE *)sptr; 
#ifdef IBMPC
                sptr -= 44; /* -do- status is 64 bytes on PC */
#endif

                /* nth line is calling unit */
    
                if (ilin < 12) { /* check if too many lines */
					strcatf(exec_err_msg,NEWLINES);
                    strcatf(exec_err_msg,"from unit: ");
                    GetUnitName(sunit,(unsigned char *) unitname);
                    strcatf(exec_err_msg,(char FAR *) unitname);
					ilin++;
                } else ovlf = TRUE; /* too deep in -do- */
                break;  
            
            case STACK_ARROW:
#ifdef IBMPC
                sptr -= 60; /* -arrow- status is 64 bytes on PC */
#endif
                break;

            case STACK_ARROW_NEST:
                sptr -= (sizeof(struct arrows)+3*sizeof(long));
#ifdef IBMPC
                sptr -= exS.arrExtra; /* remove modulo 64 bytes filler */
#endif
                break;

            default:
                TUTORdump("unrecognized stack code");

            } /* switch */
        } while (stackc != STACK_MAIN_UNIT);
    } /* stackpntr if */

    if (ovlf) {
		strcatf(exec_err_msg,NEWLINES);
        strcatf(exec_err_msg,"began in unit: ");
        GetUnitName(exS.mainunit,(unsigned char *) unitname);
        strcatf(exec_err_msg,(char FAR *) unitname);
    }

    srcloc = -1;
    if (EditVp[0]) 
        FindErrorLine(&unitn,&srcloc,-1L); /* locate source line of error */
        
    if (pcodeh) {
        ReleasePtr(pcodeh); /* no locked unit binary */
        KillPtr(pcodep);
    }
    pcodeh = 0;

    if (srcloc >= 0) {
        fileI = unittab[unitn].beginfile; /* index of file */
        if ((fileI < 0) || (fileI > sourcemalloc))
            fileI = 0;
        source = sourcetable[fileI].doc;

        /* find end of error line */

        _TUTORinq_state_internal_marker(unittab[unitn].marki,&tempL,NEARNULL,NEARNULL);
        srcloc += tempL;
        nchars = 0;
        while ((nchars < 128) && 
               (TUTORcharat_doc(source,(long)(srcloc+nchars)) != NEWLINE))
            nchars++;
        if (nchars <= 0) nchars = 1; /* always highlight something */

        /* set up event for editor */

        errevent.window = EditWn[0];
        errevent.view = FARNULL; /* message sent to window */
        errevent.type = EVENT_TIME;
        errevent.value = time_err;
        /* delay this message a bit */
        /* halt will transfer control to editor, time event will then */
        /* come thru and transfer control to message window */
        errevent.timestamp = 500L;
        errevent.a1 = FALSE; /* general error */
        errevent.a2 = fileI; /* index in sourcetable */
        errevent.a4 = srcloc; /* pass position+length */
        errevent.a5 = nchars;
        errevent.eDataP = exec_err_msg;
    	eventid = TUTORpost_event(&errevent); /* send event to editor */
    } /* edit view if */

    /* be sure executor dead */

    exS.errexit = TRUE; /* flag halted on execution error */
    rerunflag = halt;
    Halt();

	/* display message directly if didn't send event */

	if (!eventid) { /* failed to send event */
		TMessage(exec_err_msg); /* display message since didn't send event */
		TUTORdealloc(exec_err_msg); /* don't need memory any more */
	}   
	exec_err_msg = FARNULL; /* message sent to editor or TMessage called */

    longjmp(errjmpbuff,1);

} /* execerr */

/* ******************************************************************* */

static int FindErrorLine(unitr,srcloc,xloc) /* find source line of exec error point */
int *unitr; /* returned with unit number */
long *srcloc; /* returned with position in source (relative to unit) */
long xloc; /* execution location (not used) */

{   int unitn; /* unit number */
    long ploc; /* location in pcode */
    long sloc; /* location in source */
    int nmap; /* number entries in map for this unit */
    Memh mapH; /* handle on source <-> binary map */
    struct srbimap FAR *map; /* pointer to source/binary map */
    int mii;

    ploc = 0; /* unknown location at present */
    sloc = -1;
    unitn = exS.execunit; /* assume current unit */
   
    if (exS.do_errunit >= 0) {
       	unitn = exS.do_errunit;
        ploc = exS.do_errpos;
    } else if (pcodep) {
        ploc = get_exec_pt(); /* get current execution pos */
    }
    
    sloc = FindSourceLine(unitn,ploc); /* look up source line */
    
    *unitr = unitn; /* return unit and position */
    *srcloc = sloc; 
    return(0);
   
}  /* FindErrorLine */
   
/* ******************************************************************* */

long FindSourceLine(unitn,ploc) /* find source line of binary position */
int unitn; /* unit number */
long ploc; /* position in p-code of unit */

{	long sloc; /* location in source */
    int nmap; /* number entries in map for this unit */
	Memh mapH; /* handle on source <-> binary map */
    struct srbimap FAR *map; /* pointer to source/binary map */
    int mii;
    
    if (unitn < 0) return(-1);
    
    nmap = unittab[unitn].nmap; /* number entries in map */

    /* check if possible to locate execution point in source */

	if (exS.useCompiled && unittab[unitn].pcodeBetaH && unittab[unitn].srcmapBetaH)
		mapH = unittab[unitn].srcmapBetaH;
	else
		mapH = unittab[unitn].srcmapAlphaH; 
	
    if ((ctedit || ctcomp) && mapH && nmap) {

        /* search for p-code position of execution point */

        map = (struct srbimap FAR *)GetPtr(mapH);
        for (mii=0; mii<nmap; mii++) {
            if (ploc <= (map+mii)->binr) {
                if (mii) mii--; /* back up to previous entry */
                break; /* found line containing current exec point */
            }
        } /* for */
        if (mii >= nmap) mii = nmap-1;
        sloc = (map+mii)->srcr;/* relative loc in source of unit */
        ReleasePtr(mapH);
        KillPtr(map);
    } else
    	sloc = -1;

	return(sloc); /* return position of source line (or -1) */

} /* FindSourceLine */

/* ******************************************************************* */
