
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* arithmetic expression analyzer */

#include "compile.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "exprdefs.h"
#include "yacc.h"

/* ******************************************************************* */
/* WARNING: obsolete comments (left in as a model for a later rewrite) */
/* dma 4/27/90                                                         */
/* ******************************************************************* */

/* files which must be updated when a new function is added: */

/* compute.h - adtype and function codes */
/* a new function or variable type must be defined here */
/* operators are defined in prec.y */

/* compile.c - main p-code or compiled code driver */
/* constants-reduction case statement must recognize */
/* new operator/function */

/* ibm032g.c - code generator for ibm032 */
/* sun3g.c   - code generator for sun2/sun3 */
/* macg.c    - code generator for macintosh */
/* lowcore.c function must be declared as external */
/* initialization section must declare operator/function or */
/* variable type as subroutine, register, or not compiled */
/* code generation case statement must recognize new */
/* operator/adtype code */
/* special tailoring of register assignment section and */
/* code generation section will be required if operator */
/* or operand requires non-standard registers */

/* icompile.c - table initializations for compile.c */
/* if operator is not binary, all-integer, table initialization */
/* section must be modified */

/* comp.c - p-code executor */
/* main p-code case statement, reserved word and/or */
/* function case statements must recognize new code */

/* lowcore.c - routines called from compiled code */
/* routine to be called from compiled code for machines */
/* which cannot provide function in-line must be provided */
/* if compiled code is to be generated */

/* prec.y -yacc input - operator definitions */
/* an operator requires an entry here to recognize the */
/* operator code.  an adtype may not */

/* lex3.l - lex input - recognition of operator/function name */

/* ******************************************************************* */

/* compiling is presently a 7 step process resulting in either p-code or */
/* machine code */

/*  1)  the yacc-based parser prec.y drives the lexical scanner lex3.l */
/*      to convert the input english form expression to an array of polish */
/*      ordered tokens, backwards and forwards linked */
/*      most syntax errors are detected at this point */
/*  2)  compile.c translates the tokens to differentiate between integer, */
/*      byte and floating variables */
/*      whole-array, file variable and SKIP references are detected and */
/*      terminate at this point */
/*  3)  compile.c resolves integer/floating mode conflicts by inserting */
/*      ITOF and FTOI operators as required */
/*  4)  compile.c reduces expressions or operators involving constants */
/*  5)  compile.c calls the appropriate code generator if appropriate */
/*      compile.c terminates at this point if machine code is produced */
/*  6)  compile.c computes relative addresses for logical operator and */
/*      relational operator branches for p-code output */
/*  7)  compile.c outputs the final form of the p-codes, filling in array */
/*      references and internal branches */

/* ******************************************************************* */

#ifdef ctproto
int  compile(struct  expra *exap);
int  getnum(char  *s,int  *floatf,long  *i,double  *d,char  * *errm,int  *errn);
int  sizetv(int  opc);
int  tstaa(int  opc);
int  tstga(int  opc);
int  tstpa(int  opc);
int tstda(int opc);
int  siza(int  opc);
int  tstnum(int  ty);
int  efunctna(int  cd);
int  genitof(int  t);
int  genftoi(int  t);
int  pushw(int  t);
int  popw(void);
int  genadda(int  op,long  var,int  indices);
int  genarray(int  op,long  var);
int  n_addtoken(struct  xtoken *t);
int  n_addop(int  op);
int  n_yaddop(int  op);
int  addad(int  ad,long  dp,long  addr);
extern int  add_byte(int b);
extern int  add_word(int  n);
extern int  add_long(long  n);
extern int  add_flt(double  n);
extern int  badtype(void);
int  n_myinput(void);
int  matherror(int  errnum,char  *s);
int  initlex(struct  expra *initcmp);
char  FAR *GetPtr(unsigned int  mm);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
extern void longjmp(jmp_buf env, int value);
int  yyparse(void);
double  lcitof(long  iv);
long  lcftoi(double  dv);
long  IntToCoord(int  xx);
long  FloatToCoord(double  zz);
int  dmpexpr(void);
int  exprmsg(char  *pstr);
extern double fabs(double x);
extern double cos(double x);
extern double sin(double x);
long  lcint(double  av);
extern double acos(double x);
extern double asin(double x);
double  lcfexpon(double  y,double  x);
extern double log(double x);
extern double pow(double x,double y);
extern double log10(double x);
extern double exp(double x);
extern double sqrt(double x);
extern double tan(double x);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
int  add_dest(int  type,int  label,unsigned int  pos);
int  add_xref(int  kind,int  label,unsigned int  aref,unsigned int  adest);
int  TUTORtrace_n(char  *s,long  nn);
char  FAR *TUTORrealloc(char  FAR *ptr,long  oldsize,long  newsize,int  abort);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  yyerror(char  *str);
#endif /* ctproto */

#ifdef MAC
extern int setjmp(jmp_buf env);
#endif

/* ******************************************************************* */

jmp_buf cenv;   /* saved enviornment for longjmp */

#ifndef WERKS
extern double sin(),cos(),tan();
extern double sqrt(),fabs(),exp();
extern double asin(), acos();
extern double pow(),log10(),log(),alog();
extern double sinh(),cosh(),tanh(),gamma();
#endif

extern double lcitof();
extern double lcfexpon();

/* ******************************************************************* */

compile(exap) 
struct expra *exap;

{ /* compile */

register int is;    /* index in token stack */
register struct xtoken FAR *t;  /* pointer to current token */
int ia,ib;  /* index of argument tokens */
int opc, iac, ibc;  /* op, arg1, arg2 codes */
int opt, at, bt;        /* op, arg1, arg2 types */
int nt, pt;     /* index of next/previous tokens */
int aaf;        /* array assign flag */
int iaa;        /* index of token being assigned */
int ploc;   /* current location within pcodes */
int dim;        /* number array dimensions */
long abase; /* base address of array */
int asize;  /* size of array elements */
int afirst; /* token index of first array dimension */
int alast;  /* token index of last array dimension */
long amaxl; /* maximum length of array */
long alength;   /* array length (by dimension) */
long alower;    /* array lower bound (by dimension) */
long aindex;    /* current (accumulated) index in array */
long aiw;   /* array index */
int aopc;   /* replacement op code for array */
int acheck; /* compile-time bounds check of array index possible */
int uii; /* unit index */
struct array_desc FAR *pda; /* pointer to array description info */
struct dim_desc FAR *pdd; /* pointer to dimension description info */
long stkind; /* type of storeable variable */
int stglobal; /* TRUE if last storeable variable is global */
long sloc,slen;
long staddr; /* address of last storeable variable */
int constr; /* TRUE if result of operation constant */
long resultt; /* desired expression result type */
long ipos;  /* initial position in input string */
int typeok; /* TRUE if operation types already known correct */
char nstr[16];  /* buffer for simple numeric string */
int i,j; /* work variables */
unsigned char FAR *ucp;
long lwk;
double fwk,fwk1;

/* ------------------------------------------------------------------------------ */

    /* initializations */

    if (xtokmalloc == 0) { /* allocate expression analyzer stack */
        xtokmalloc = (userExp ? 20: 100);
        xtokd = (struct xtoken FAR *)
            TUTORalloc((long)(xtokmalloc*sizeof(struct xtoken)),FALSE,"xtoken");
    }
    if (!xtokd) {
        xtokmalloc = 0;
        matherror(NOMEM,"not enough memory");
    }
    if (!xtP)
        xtP = (struct exprt FAR *) GetPtr(xtH);

    initlex(exap);
    exa->errmess = 0;
    exa->errnum = 0;
    exa->assigned = FALSE;
    exa->canstore = TRUE;
    exa->exprtype = TFLOAT;
    exa->opcnt = 0;
    exa->varcnt = 0;
    exa->isconst = FALSE;
    exa->warray = 0;
    resultt = exa->rtype;
    if (resultt == TCOORD) /* treat co-ord as generic numeric */
        resultt = 0;
    else if (resultt == TMARK) 
        exa->allowm = TRUE; /* must allow marker if marker result */
    else if ((resultt & 0xffff) == TXTYPE) {
        i = (resultt >> 16) & 0xffff;
        if (i == TXFILE)
            exa->allowf = TRUE; /* must allow file */
        else if (i == TXSCREEN)
            exa->allowscrn = TRUE; /* must allow pixmap */
        else if (i == TXBUTTON)
            exa->allowbutn = TRUE; /* must allow button */
        else if (i == TXSLIDER)
            exa->allowslid = TRUE; /* must allow slider */
        else if (i == TXEDIT)
            exa->allowedit = TRUE; /* must allow edit */
        else if (i == TXTOUCH)
	    exa->allowtouch = TRUE; /* must allow touch */
	else if (i == TXDDE)
	    exa->allowdde = TRUE; /* must allow dde */
    } /* txtype else-if */
    ibranf = FALSE;
    parencnt = embedcnt = 0;
    indexcnt = 0;
    topw = 0;
    staddr = -1;    /* no storeable variable yet */
    narrayi = -1;   /* no storeable array yet */
    ntokd = -1;
    n_addop(0); /* put dummy at beginning */

    /* longjmp error recovery */

    if (setjmp(cenv)) { matherror(exa->errnum,exa->errmess); return(0);}

    /* check for simple, single numeric tag */

    ipos = *exa->srcpos;
    i = n_myinput();    /* get first non-blank character */
    j = (resultt == 0) || (resultt == TINT) || (resultt == TFLOAT);
    j = j && (!exa->calc) && (!exa->reqstore);
    if (j && ((i >= '0') && (i <= '9'))) {
        *exa->srcpos = ipos;

        /* assemble short string containing numeric value */

        i = 0;  /* index in string */
        ib = TRUE; /* valid number flag */
        j = FALSE; /* hex constant flag */
        do {
            /* check 0-9 # or a-f after # encountered */

            nstr[i] = is = n_myinput();
            i++;
            if ((is >= '0') && (is <= '9')) ia = TRUE;
            else if (is == '#') ia = j = TRUE;
            else if (j && ((is >= 'a') && (is <= 'f'))) ia = TRUE;
            else if (j && ((is >= 'A') && (is <= 'F'))) ia = TRUE;
            else if ((is == ',') || (is == ';') || (is == NEWLINE))
                ia = FALSE;
            else ib = FALSE;
            if (i > 15) ib = FALSE;
        } while (ia && ib);

        /* process numeric value if all legal */

        if (ib) {
            nstr[i-1] = '\0';
            if (getnum(nstr,&j,&lwk,&fwk,&exa->errmess,&exa->errnum)) {
                exa->canstore = FALSE;
                exa->lastchar = is;
                if (resultt == TINT) i = ILITERAL;
                else if (exa->rtype == TCOORD) i = ILITERAL;
                else if ((resultt == 0) && (j == FALSE)) i = ILITERAL;
                else i = FLITERAL;
                if (i == ILITERAL) {
                    exa->exprtype  = TINT;
                        if (exa->rtype == TCOORD) {
                        exa->exprtype = TCOORD;
                        if (j) { /* convert int/flt to coord */
                            lwk = FloatToCoord(fwk);
                            j = FALSE;
                        } else lwk = IntToCoord((int)lwk);
                    } /* rtype if */
                    if (j) lwk = lcftoi(fwk);
                    if (!exa->nogen) {
                        if (lwk & 0xffff8000L) {
                            add_word(ILITERAL); 
                            add_long(lwk);
                        } else {
                            add_word(TKEYWORD); 
                            add_word((int)lwk);
                        }
                    }
                    exa->iconst = lwk;
                } else {
                    if (!j) fwk = lcitof(lwk);
                    exa->exprtype = TFLOAT;
                    if (!exa->nogen) {
                        add_word(FLITERAL);
                        add_flt(fwk);
                    }
                    exa->fconst = fwk;
                } /* ILITERAL else */
                prevend = *exa->pcodepos;

                /* check terminator legal */

                if (((exa->lastchar == NEWLINE) && !exa->teol) ||
                    ((exa->lastchar == ',') && !exa->tcomma) ||
                    ((exa->lastchar == ';') && !exa->tsemic) ||
                    ((exa->lastchar == ':') && !exa->tcolon))
                    matherror(FORMERR,
                      "Expression ended with wrong separator.");
                exa->isconst = TRUE;
                return(0);
            } /* getnum if */
        } /* ib if */
    } /* calc if */
    *exa->srcpos = ipos; /* re-set back to starting position */

    /* perform lexical and precedence analysis */

    yyparse();
    if (exa->errnum != 0) { 
        matherror(exa->errnum,exa->errmess); 
        return(0); 
    } /* errnum if */
    if ((exa->calc) && (!exa->assigned)) {
        matherror(FORMERR,"-calc- must assign a value to a variable.");
        return(0);
    } /* exa->calc if */

    /* check terminator legal */

    if (((exa->lastchar == NEWLINE) && !exa->teol) ||
        ((exa->lastchar == ',') && !exa->tcomma) ||
        ((exa->lastchar == ';') && !exa->tsemic) ||
        ((exa->lastchar == ':') && !exa->tcolon)) 
        matherror(FORMERR,"Expression ended with wrong separator.");

    /* set token order links, set relational operator/branch links */

    for (is=1; is<=ntokd; is++) { 
        xtokd[is-1].nextt = is; 
        xtokd[is].prevt = is-1; 
    } 

    /* special treatment for SKIP and unsubscripted arrays */

    if (ntokd <= 2) {
        i = xtokd[1].code; /* get 1st (only) token */
        t = &xtokd[1];

        /* special treatment for SKIP - exit immediately */

        if (i == SKIP) { 
            if (!exa->allowsk)
                matherror(FORMERR,"SKIP not allowed here.");
            exa->exprtype = SKIP;
            return(0);  
        } /* SKIP */

        /* process un-indexed array */

        if ((i == GARRAY) || (i == PARRAY) || (i == LARRAY) || 
            (i == GDYARRAY) || (i == PDYARRAY) || (i == LDYARRAY)) {
            if (!exa->arrayok) {
                exa->errnum = FORMERR;
                exa->errmess = "Cannot use array name without indices here."; 
                if (exa->allowf)
                    exa->errmess = "Need file descriptor, not array.";
                longjmp(cenv,1);
            }
            exa->exprtype = FARRAY;
            if (tstda(i)) exa->warray = 2;
            else exa->warray = 1;

            /* flag operand as integer if neccessary */

            if (((t->type == TINT) || (t->type == IARRAY)) && (xtP[t->code].iad)) {
                exa->exprtype = IARRAY;
                t->code = xtP[t->code].iad;
            } /* integer array if */

            /* flag operand as byte if neccessary */

            if (((t->type == TBYTE) || (t->type == BARRAY)) && (xtP[t->code].bad)) {
                exa->exprtype = BARRAY;
                t->code = xtP[t->code].bad;
            } /* byte array if */

            /* flag operand as string if neccessary */

            if (((t->type == TMARK) || (t->type == MARRAY)) && (xtP[t->code].sad)) {
                exa->exprtype = MARRAY;
                t->code = xtP[t->code].sad;
            } /* string array if */

            /* flag operand as TXTYPE if neccessary */

            i = t->type & 0xffff;
            if ((i == TXTYPE) || (i == XARRAY)) {
                i = (t->type >> 16) & 0xffff;
                exa->exprtype = (long)XARRAY+((long)(i) << 16);
                t->code = xtP[t->code].xad;
                if (t->code == 0) 
                    badtype();
                if ((i == TXFILE) && (!exa->allowf))
                    matherror(FORMERR,"File variable not allowed here.");
                else if ((i == TXSCREEN) && (!exa->allowscrn))
                    matherror(FORMERR,"Pixmap variable not allowed here.");
                else if ((i == TXBUTTON) && (!exa->allowbutn))
                    matherror(FORMERR,"Button variable not allowed here.");
                else if ((i == TXSLIDER) && (!exa->allowslid))
                    matherror(FORMERR,"Slider variable not allowed here.");
                else if ((i == TXEDIT) && (!exa->allowedit))
                    matherror(FORMERR,"Edit variable not allowed here.");
                else if ((i == TXTOUCH) && (!exa->allowtouch))
		    		matherror(FORMERR,"Touch variable not allowed here.");
		    	else if ((i == TXDDE) && (!exa->allowdde))
					matherror(FORMERR,"DDE variable not allowed here.");
		else if ((i == TXDDE) && (!exa->allowdde))
		    matherror(FORMERR,"DDE variable not allowed here.");
            }

            /* generate p-code for unindexed array */

            if (!exa->nogen) {
                i = t->code;
                add_word(i);
                add_long(exa->exprtype); /* expression type */
                if ((i == GARRAY) || (i == IGARRAY) || (i == BGARRAY) ||
                   (i == MGARRAY) || (i == XGARRAY) || (i == GDYARRAY) ||
                   (i == IGDYARRAY) || (i == BGDYARRAY)) 
                    uii = 0; /* globals in unit 0 */
                else uii = compunit; 
                pda = (struct array_desc FAR *)(descP+unittab[uii].descp+t->ivalue);
                add_long(pda->addr); /* relative address of array */
                add_long(pda->length); /* total length of array */
            }
            return(0);
        } /* array if */
    } /* ntokd if */

    /* convert operands */
    /* (for simplicity, yacc deals with floating operands only) */

    is = 0; /* initialize index */
    do {

        /* chain forward to next operator/operand */

        is = xtokd[is].nextt;   /* link to next token in chain */
        t = &xtokd[is];

        /* process operand */

        if (!xtP[t->code].op) {

            /* flag operand as integer if neccessary */

            if (((t->type == TINT) || (t->type == IARRAY)) && (xtP[t->code].iad))
                t->code = xtP[t->code].iad;

            /* flag operand as byte if neccessary */

            if (((t->type == TBYTE) || (t->type == BARRAY)) && (xtP[t->code].bad)) 
                 t->code = xtP[t->code].bad;

            /* flag operand as string if neccessary */

            if (((t->type == TMARK)||(t->type == MARRAY)) && (xtP[t->code].sad)) 
                 t->code = xtP[t->code].sad;

            /* flag operand as TXTYPE if neccessary */

            i = t->type & 0xffff;
            if (((i == TXTYPE)||(i == XARRAY)) && (xtP[t->code].xad)) {
                t->code = xtP[t->code].xad;
            } /* txtype if */

        /* process operator */

        } else {

            /* process function operator - convert to individual function */

            if (t->code == FUNCT) t->code = t->ivalue;
    
            /* process end-of-expression operator - set desired result */

            if (t->code == 0) {
                if (resultt == TINT) t->code = ENDI; /* end int expr */
                else if (resultt == TMARK) 
                    t->code = ENDM;/* end string expr */
                else t->code = ENDF;    /* end floating expr */
            } /* end-of-expr if */
        } /* operator else */
    } while (!xtP[t->code].endop);

    exprmsg("after prec\n"); dmpexpr();

/* ------------------------------------------------------------------------------ */

    /* perform integer, floating, marker type conversions */

    is = 0; /* initialize index */
    topw = 0;   /* initialize stack */
    t = &xtokd[is];
    while (!xtP[t->code].endop) {

        /* chain forward to next operator/operand */

        is = xtokd[is].nextt;   /* link to next token in chain */
        t = &xtokd[is];
        opc = t->code;      /* get operator code */
        opt = xtP[opc].targ;    /* operator type */
        typeok = FALSE; /* don't know about types yet */

        /* process operand */

        if (!xtP[opc].op)  {

            /* process indexed array */

            if (xtP[opc].array == 1) {
                
                /* pick up array dimensions */

                uii = (tstga(opc) ? 0: compunit);
                pda = (struct array_desc FAR *)(descP+unittab[uii].descp+t->ivalue);
                dim = pda->ndim; /* get number dimensions */
                aaf = tstaa(opc);   /* check for assignment to array */
                if (aaf) iaa = popw(); /* pop operand */

                /* convert array indexes to integer */

                for (i=1; i<=dim; i++){
                    ia = popw(); /* pop operand from working stack */
                    iac = xtokd[ia].code; /* get operand code */
                    at = xtP[iac].trel;
                    if (!tstnum(at)) 
                        matherror(FORMERR,"Array index must be numeric");
                    if (at == TBYTE) at = TINT; /* treat byte as int */
                    if (at !=TINT) genftoi(ia); /* index must be integer */
                    t = &xtokd[is]; /* genitof/genftoi can move table */
                } /* for */

                if (aaf) pushw(iaa); /* push assigned operand back on stack */

            } /* array if */

            pushw(is);  /* push result operand on stack */

        }  /* operand if */

        /* process unary operator */

        else if (xtP[opc].unary) {
            ia = popw();        /* pop operand from working stack */
            iac = xtokd[ia].code;   /* get operand code */
            at = xtP[iac].trel; /* get int, float, byte, mark type */

            /* check for end of expression - determine result type */
            
            if (xtP[opc].endop) {

                /* check for end of calc - no conversion required */

                if (exa->calc) {
                    if (at == TINT) t->code = ENDI;
                    else if (at == TBYTE) t->code = ENDI;
                    else if (at == TMARK) t->code = ENDM;
                    else t->code = ENDF;
                    opc = t->code;
                } /* calc if */

                /* check for general numeric result - no conversion required */

                else if (resultt == 0) {
                    if (at == TINT) t->code = ENDI;
                    else if (at == TBYTE) t->code = ENDI;
                    else if (at == TFLOAT) t->code = ENDF; 
                    opc = t->code;

                    /* convert int or float to coord if required */

                    if (exa->rtype == TCOORD) {
                        i = ((opc == ENDI) ? ITOC: FTOC);
                        n_addop(i); /* add conversion operator */
                        t = &xtokd[is]; /* addop can move table */
                        nt = xtokd[ia].nextt;
                        xtokd[ntokd].nextt = nt; /* chain i/ftoc to next */
                        xtokd[nt].prevt = ntokd; /* chain next to itof */
                        xtokd[ia].nextt = ntokd; /* chain previous to itof */
                        xtokd[ntokd].prevt = ia; /* chain i/ftoc to previous */
                    } /* TCOORD if */
                } /* rtype if */

                /* check if string result allowed */

                if (at == TMARK) {
                    if ((exa->allowm)  || (resultt == TMARK)) {
                        t->code = ENDM;
                        opc = t->code;
                    } /* allowm if */
                    else {
                        exa->errnum = FORMERR;
                        exa->errmess = "Result may not be string."; 
                        longjmp(cenv,1);
                    } /* else */
                } /* at if */
                
                /* check if result is special type */
                
                if (at == TXTYPE) {
                    /* treat all special types as integer */
                    t->code = endopc = opc = ENDI; 
                    i = (xtokd[ia].type >> 16) & 0xffff;
                    exa->exprtype = ((long)(i) << 16)+TXTYPE;
                    if ((i == TXFILE) && (!exa->allowf))
                        matherror(FORMERR,"File variable not allowed here.");
                    else if ((i == TXSCREEN) && (!exa->allowscrn))
                        matherror(FORMERR,"Screen variable not allowed here.");
                    else if ((i == TXBUTTON) && (!exa->allowbutn))
                        matherror(FORMERR,"Button variable not allowed here.");
                    else if ((i == TXSLIDER) && (!exa->allowslid))
                        matherror(FORMERR,"Slider variable not allowed here.");
                    else if ((i == TXEDIT) && (!exa->allowedit))
                        matherror(FORMERR,"Edit variable not allowed here.");
                    else if ((i == TXTOUCH) && (!exa->allowtouch))
						matherror(FORMERR,"Touch variable not allowed here.");
		    		else if ((i == TXDDE) && (!exa->allowdde))
						matherror(FORMERR,"DDE variable not allowed here.");
                    typeok = TRUE; /* now know type is ok */
                } else {
                    /* set numeric/string expression result type */
            
                    endopc = opc;
                    if (exa->canstore && exa->reqstore) 
                        exa->exprtype = at;
                    else exa->exprtype = xtP[opc].trel;
                }
            } /* end-expr if */
            
            /* check for zlength function */
            /* zlength(array type), zlength(marker) or zlength(file) */

            if (opc == ZLENGTH) {
                at = TINT;
                if (xtP[iac].array)
                    typeok = TRUE;
                else badtype();
            } else if (opc == ZLENGTHM) {
                i = (xtokd[ia].type >> 16) & 0xffff;
                if (i == TXFILE) { /* convert from marker to file */
                    opc = t->code = ZLENGTHF;
                } /* TXFILE if */
            }

			/* check for zhotinfo function */
			/* zhotinfo(edit), zhotinfo(marker) */
			
			if (opc == ZHOTINFOE) {
				if (xtokd[ia].type == TMARK) { /* convert from edit to mark */
					opc = t->code = ZHOTINFOM;
				}
			}

            /* check for operation on special (non numeric/string) type */

            if (!typeok && (at == TXTYPE)) { 
                if (!xtP[opc].txop)
                    badtype();
                i = (xtokd[ia].type >> 16) & 0xffff;
                if ((opc == ZTEXTSEL) ||
                    (opc == ZTEXTVIS) ||
                    (opc == ZHOTINFOE) ||
                    (opc == ZHOTSEL) ||
                    (opc == ZEDITBASE)) {
                    if (i != TXEDIT) badtype();
                } else if (opc == ZVALUEB) {
		    		if (i == TXSLIDER) { /* zvalues if slider */
						opc = t->code = ZVALUES;
		    		} else if (i == TXDDE) { /* zvaluedde if dde */
						opc = t->code = ZVALUEDDE;
                	} else if (i != TXBUTTON) badtype();
                } else if ((opc == ZFILENAME) || (opc == ZFILEPATH)) {
                    if (i != TXFILE) badtype();
                } else if (opc == ZLENGTHF) {
                    if (i != TXFILE) badtype();
                } else if ((opc == ZSWIDTH) || (opc == ZSHEIGHT)) {
                	if (i != TXSCREEN) badtype();
                } else if (opc != ENDI) badtype();
            } /* at == TXTYPE if */

            /* check for type mis-match */

            if (at == TBYTE) at = TINT;
            if (!typeok && (xtP[opc].targ != at)) {
                opt = xtP[opc].targ; /* operator type */

                /* process numeric types */

                if (tstnum(opt) && tstnum(at)) { /* numeric types */
                    if (opt == TFLOAT) { /* floating op, integer arg */
                        if (xtP[opc].eop) t->code = xtP[opc].eop; /* convert op to int */
                        else genitof(ia); /* convert arg to float */
                    } else { /* integer op, floating arg */
                        /* convert op to float */
                        if (xtP[opc].eop) t->code = xtP[opc].eop;
                        else genftoi(ia); /* convert arg to int */
                    } /* integer else  */
                    t = &xtokd[is]; /* genitof/genftoi can move table */
                } /* numeric if */

                /* process non-numeric types */

                else {

                    /* string operand */

                    if (at == TMARK) {
                        /* convert op to string */
                        if (xtP[opc].seop) t->code = xtP[opc].seop;
                    } /* string arg if */

                    /* check type conflict resolved */

                    opt = xtP[t->code].targ;
                    if (opt != at) badtype();
                } /* non-numeric else */
            } /* type miss-match if */

            pushw(is);  /* put result on working stack */

        } /* unary if */

        /* process EFUNCT - unary, binary, or trinary, floating arguments */

        else if (opc == EFUNCT) {
            i = t->ivalue;
            if ((i == 9) || (i == 12) || (i == 15) || (i == 18) || (i == 21))
                matherror(FORMERR,"embedded show has too many arguments");
            for(i=1; i<=efunctna((int)(t->ivalue)); i++) {
                ia = popw(); /* pop operand from working stack */
                iac = xtokd[ia].code; 
                at = xtP[iac].trel; /* get int, float, byte, mark type */
                if (tstnum(at)) { /* numeric */
                    if (at != TFLOAT) {
                        /* convert to float */
                        if (xtP[opc].eop) t->code = xtP[opc].eop; 
                        else genitof(ia); 
                    } /* type if */
                } else if (at == TMARK) {
                    if (t->ivalue != 1) badtype();
                    t->ivalue = 22; /* convert to show(marker) */
                } else badtype();
                t = &xtokd[is]; /* genitof/genftoi can move table */
            } /* for */
            pushw(is);  /* put result on working stack */
        } /* EFUNCT else-if */

        /* process ZSETMARK/ZTEXTAT - trinary operators */

        else if ((opc == ZSETMARK) || (opc == ZTEXTAT)){
            for(i=1; i<=3; i++) {
                ia = popw(); /* pop operand from working stack */
                iac = xtokd[ia].code; 
                at = xtP[iac].trel; /* get int, float, byte, mark type */
                if (i == 3) {
                    if (opc == ZSETMARK) {
                        if (at != TMARK) badtype();
                    } else {
                        if (xtokd[ia].type != ((long)TXTYPE | ((long)TXEDIT << 16)))
                            badtype();
                    }
                } else if (tstnum(at)) { /* numeric */
                    if (at != TINT) {
                        /* convert to integer */
                        genftoi(ia); 
                    } /* type if */
                } else badtype();
                t = &xtokd[is]; /* genitof/genftoi can move table */
            } /* for */
            pushw(is);  /* put result on working stack */
        } /* ZSETMARK else-if */

        /* process zhasstyle, ziconcode, ziconfile - 1st arg marker, 2nd arg int */
        
        else if ((opc == ZHASSTYLE) || (opc == ZICONCODE) || (opc == ZICONFILE)) {
            ia = popw(); /* pop operand from working stack */
            iac = xtokd[ia].code; 
            at = xtP[iac].trel; /* get int, float, byte, mark type */
            if (!tstnum(at)) badtype();
            if (at != TINT)
                genftoi(ia); /* convert to integer */
            ia = popw(); /* pop operand from working stack */
            iac = xtokd[ia].code; 
            at = xtP[iac].trel; /* get int, float, byte, mark type */
            if (at != TMARK) badtype();
            pushw(is); /* push result on working stack */
        }
        
        /* process zrgbn, zhsvn - trinary operators */

        else if ((opc == ZRGBN) || (opc == ZHSVN)) {
            for(i=1; i<=3; i++) {
                ia = popw(); /* pop operand from working stack */
                iac = xtokd[ia].code; 
                at = xtP[iac].trel; /* get int, float, byte, mark type */
                if (!tstnum(at)) badtype();
                if (at != TFLOAT) {
                    /* convert to float */
                    if (xtP[opc].eop) t->code = xtP[opc].eop; 
                    else genitof(ia); 
                } /* type if */
                t = &xtokd[is]; /* genitof/genftoi can move table */
            } /* for */
            pushw(is);  /* put result on working stack */
        } /* ZRGBN else-if */


        /* process binary operator */

        else {
            ib = popw();    /* pop 2nd operand from working stack */
            ia = popw();    /* pop 1st operand from working stack */
            iac = xtokd[ia].code;   /* get 1st operand code */
            ibc = xtokd[ib].code;   /* get 2nd operand code */
            opt = xtP[opc].targ;    /* operator type */
            if (opt == TBYTE) opt = TINT;
            at = xtP[iac].trel;     /* 1st operand type */
            if (at == TBYTE) at = TINT;
            bt = xtP[ibc].trel;     /* 2nd operand type */
            if (bt == TBYTE) bt = TINT;

            /* special check for assign  - convert operator to match */
            /* operand being assigned to */

            if (opc == ASSIGN) {
                if (bt == TINT) {
                    if ((ibc == BGLOBALADDR) || (ibc == BLOCALADDR) ||
                        (ibc == BPASSADDR) || (ibc == BGARRAYADDR) ||
                        (ibc == BGDYARRAYADDR) || (ibc == BLDYARRAYADDR) ||
                        (ibc == BPDYARRAYADDR) ||
                        (ibc == BLARRAYADDR) || (ibc == BPARRAYADDR)) {
                        t->code = BASSIGN;
                        opc = BASSIGN;
                        opt = TINT;
                    } else {
                        t->code = IASSIGN;
                        opc = IASSIGN;
                        opt = TINT;
                    } /* byte else */
                } else if (bt == TMARK) {
                    t->code = MASSIGN;
                    opc = MASSIGN;
                    opt = TMARK;
                } /* string else if */
            } /* assign if */

            /* process numeric (integer, floating) types */

            if (tstnum(at) && tstnum(bt) && tstnum(opt)) {

                /* same operands, different operator, can convert op */

                if ((at == bt) && tstnum(at) && (opt != at) && (xtP[opc].eop)) {
                    t->code = xtP[opc].eop;
                    opc = t->code;
                    opt = xtP[opc].targ;
                } /* op convert if */

                /* single-mode operator, force operands */

                if (xtP[opc].eop == 0) {
                    if (opt ==TINT) {
                        if (at != TINT) {genftoi(ia); ia = ntokd;}
                        if (bt != TINT) {genftoi(ib); ib = ntokd;}
                    } else {
                        if (at != TFLOAT) {genitof(ia); ia = ntokd;}
                        if (bt != TFLOAT) {genitof(ib); ib = ntokd;}
                    } /* floating else */
                    t = &xtokd[is]; /* genitof/genftoi can move table */
                } /* single mode operator */

                /* check for type miss-match - float everything */

                iac = xtokd[ia].code;   /* get 1st operand code */
                ibc = xtokd[ib].code;   /* get 2nd operand code */
                at = xtP[iac].trel;     /* 1st operand type */
                if (at == TBYTE) at = TINT;
                bt = xtP[ibc].trel;     /* 2nd operand type */
                if (bt == TBYTE) bt = TINT;
                if ((at != bt) || (xtP[opc].targ != at)) {
                    if (xtP[opc].targ != TFLOAT) t->code = xtP[opc].eop;
                    if (at != TFLOAT) genitof(ia);
                    if (bt != TFLOAT) genitof(ib);
                } /* type mismatch if */
                t = &xtokd[is]; /* genitof/genftoi can move table */
            } /* numeric if */

            /* process non-numeric types */

            else {

                /* process string type */

                if ((at == TMARK) || (bt == TMARK) || (opt == TMARK)) {
                    if (opt != TMARK) {
                        if (xtP[opc].seop) {
                            opc = xtP[opc].seop;
                            t->code = opc;
                            opt = TMARK;
                        } /* equiv op if */
                    } /* opt if */
                } /* string if */

                /* process TXTYPE */

                if ((at == TXTYPE) || (bt == TXTYPE) || (opt == TXTYPE)) {
                    if ((xtokd[ia].type >> 16) != (xtokd[ib].type >> 16))
                        badtype();
                    if (opt != TXTYPE) {
                        if (xtP[opc].xeop) {
                            opc = xtP[opc].xeop;
                            t->code = opc;
                            opt = TXTYPE;
                        } /* equiv op it */
                    } /* opt if */
                } /* TXTYPE if */

                /* check type conflict resolved */

                if ((at != opt) || (bt != opt)) {
                    badtype();
                } /* mismatch if */
            } /* non-numeric else */

            pushw(is); /* put result on working stack */
        } /* binary op else */
    };  /* while */

    exprmsg("after i/f\n"); dmpexpr();

/* ------------------------------------------------------------------------------ */

    /* perform operations on constants */

    is = 0; /* initialize index */
    topw = 0;   /* initialize stack */
    t = &xtokd[is];
    while (!xtP[t->code].endop) {

        /* chain forward to next operator/operand */

        is = xtokd[is].nextt;   /* link to next token in chain */
        t = &xtokd[is];
        opc = t->code;      /* get operator code */

        /* process operand */

        if (!xtP[opc].op)  {

            /* process indexed array */

            if (xtP[opc].array == 1) {

                /* determine array element size, pass-by-address */

                acheck = !tstpa(opc);   /* cant handle pass-by-address */
                if (acheck) 
                    acheck = !tstda(opc); /* cant handle dynamic array */
                constr = acheck;
                asize = siza(opc);  /* determine size of elements */
                
                /* determine corresponding scalar op code */

                aopc = 0;
                if (opc == GARRAYVAL) aopc = GLOBALVAL;
                else if (opc == GARRAYADDR) aopc = GLOBALADDR;
                else if (opc == LARRAYVAL) aopc = LOCALVAL;
                else if (opc == LARRAYADDR) aopc = LOCALADDR;
                else if (opc == IGARRAYVAL) aopc = IGLOBALVAL;
                else if (opc == IGARRAYADDR) aopc = IGLOBALADDR;
                else if (opc == ILARRAYVAL) aopc = ILOCALVAL;
                else if (opc == ILARRAYADDR) aopc = ILOCALADDR;
                else if (opc == BGARRAYVAL) aopc = BGLOBALVAL;
                else if (opc == BGARRAYADDR) aopc = BGLOBALADDR;
                else if (opc == BLARRAYVAL) aopc = BLOCALVAL;
                else if (opc == BLARRAYADDR) aopc = BLOCALADDR;
                else if (opc == MGARRAYVAL) aopc = MGLOBALVAL;
                else if (opc == MGARRAYADDR) aopc = MGLOBALADDR;
                else if (opc == MLARRAYVAL) aopc = MLOCALVAL;
                else if (opc == MLARRAYADDR) aopc = MLOCALADDR;
                else if (opc == XGARRAYVAL) aopc = XGLOBALVAL;
                else if (opc == XLARRAYVAL) aopc = XLOCALVAL;
                
                /* pick up array dimensions */

                uii = (tstga(opc) ? 0: compunit);
                pda = (struct array_desc FAR *)(descP+unittab[uii].descp+t->ivalue);
                pdd = (struct dim_desc FAR *)(pda+1);
                abase = pda->addr+ARRAYHDR; /* base address of array */
                amaxl = pda->length; /* total length of array */
                dim = pda->ndim;    /* get number dimensions */

                /* check for assignment to array */

                aaf = tstaa(opc);

                /* pop operand being assigned to indexed array */

                if (aaf) iaa = popw();      /* pop operand */

                /* pop array indexes - check constant */

                aindex = 0; /* initialize index */
                alast = popw();     /* get last array index */
                pushw(alast);
                for (i=1; i<=dim; i++) {
                    ia = popw();    /* pop indexes in reverse order */
                    if (!xtokd[ia].constf) constr = FALSE;
                    alower = (pdd+dim-i)->lower; /* lower bound */
                    alength = (pdd+dim-i)->length; /* lth of dim */

                    /* accumulate index, check in bounds if constant */

                    if (acheck && xtokd[ia].constf) {
                        aiw = xtokd[ia].ivalue-alower;
                        if ((aiw<0) || (aiw >= alength)) {
                            exa->errnum = FORMERR;
                            exa->errmess = "Array index out of bounds.";
                            longjmp(cenv,1);
                        } /* out of bounmds if */
                        aindex = aindex+aiw*((pdd+dim-i)->multiplier);
                    } /* constant if */
                } /* for */
                afirst = ia;        /* get index of 1st array index */

                /* restore operand being assigned to indexed array */

                if (aaf) pushw(iaa);    /* push operand back on stack */

                /* if constant indexes, translate to simple variable */

                if (aopc) stglobal = tstga(aopc); /* save global/local */
                else {
                    constr = FALSE; /* didn't find scalar equivalent */
                    stglobal = tstga(opc); /* save global/local */
                }
                if (constr) {
                    narrayi = amaxl-aindex; /* num items store-able */
                    aindex = abase+asize*aindex;
                    i = xtokd[afirst].prevt; /* drop indexes */
                    xtokd[i].nextt = xtokd[alast].nextt; 
                    j = xtokd[i].nextt;
                    xtokd[j].prevt = i;
                    xtokd[is].code = aopc;  /* translate code */
                    xtokd[is].ivalue = aindex; /* address */
                    staddr = aindex; /* store-able address */
                } else {
                    narrayi = -1; /* not constant, no length */
                    staddr = -1; /* not constant, no address */
                } /* constr else */
            } else {
                stglobal = FALSE; /* assume local */
                if ((opc == GLOBALVAL) || (opc == IGLOBALVAL) ||
                    (opc == BGLOBALVAL) || (opc == MGLOBALVAL) ||
                    (opc == GLOBALADDR) || (opc == IGLOBALADDR) ||
                    (opc == XGLOBALVAL) ||
                    (opc == BGLOBALADDR) || (opc == MGLOBALADDR)) {
                    stglobal = TRUE; /* save store-ability info */
                    staddr = xtokd[is].ivalue;
                    narrayi = 1;
                } else if ((opc == LOCALVAL) || (opc == ILOCALVAL) ||
                           (opc == BLOCALVAL) || (opc == MLOCALVAL) ||
                           (opc == LOCALADDR) || (opc == ILOCALADDR) ||
                           (opc == XLOCALVAL) || 
                           (opc == BLOCALADDR) || (opc == MLOCALADDR)) {
                    staddr = xtokd[is].ivalue;
                    narrayi = 1;
                } else staddr = narrayi = -1;
            } /* array else */

            /* process scalar operand */

            pushw(is);  /* push result operand on working stack */

        } /* operand if */
 
        /* process operator */

        else {
            constr = FALSE; /* pre-set not constant result */

            /* process unary operator */

            if (xtP[opc].unary) {
                ia = popw();        /* pop operand from working stack */
                if (xtokd[ia].constf) constr = TRUE;
            } /* unary if */

            /* process EFUNCT - unary, binary, or trinary */

            else if (opc == EFUNCT) {
                for(i=1; i<=efunctna((int)(t->ivalue)); i++) {
                    ia = popw(); /* pop operand from working stack */
                } /* for */
            } /* EFUNCT else-if */

            /* process ZSETMARK, ZRGBN, ZHSVN, ZTEXTAT - trinary */

            else if ((opc == ZSETMARK) || (opc == ZTEXTAT) ||
                     (opc == ZRGBN) || (opc == ZHSVN))  {
                for (i=1; i<=3; i++) ia = popw(); /* pop operands */
            } /* ZSETMARK else-if */

            /* process ZHASSTYLE, binary, different types */
            
            else if (opc == ZHASSTYLE) {
                ib = popw(); /* pop operands */
                ia = popw();
            } /* ZHASSTYLE else-if */
            
            /* process binary operator */

            else {
                ib = popw();    /* pop 2nd operand from working stack */
                ia = popw();    /* pop 1st operand from working stack */
                if ((xtokd[ia].constf) && (xtokd[ib].constf)) constr = TRUE;

                /* check for special case of (v+1) or (v-1) */

                else if ((xtokd[ib].constf) && (xtokd[ib].ivalue == 1) &&
                          ((opc == IPLUS) ||  (opc == IMINUS))) {
                    if (opc == IPLUS) opc = IINC;
                    else opc = IDEC;
                    t->code = opc;      /* convert operator */
                    nt = xtokd[ib].nextt;
                    pt = xtokd[ib].prevt;
                    xtokd[pt].nextt = nt;   /* drop const 1 from chain */
                    xtokd[nt].prevt = pt;
                } /* inc/dec if */

                /* check for special case of v**constant */

                else if ((xtokd[ib].constf) && (opc == EXPONENT)) {
                    if ((xtokd[ib].fvalue >= 2.0) && (xtokd[ib].fvalue <= 4.0)) {
                        fwk = lcftoi(xtokd[ib].fvalue); /* round to nearest integer */
                        if (fabs(xtokd[ib].fvalue-fwk) < abstolerance) { /* integer power */
                            opc = EXPONIC;  /* convert op */
                            t->code = opc;
                            t->ivalue = xtokd[ib].fvalue;
                            nt = xtokd[ib].nextt;
                            pt = xtokd[ib].prevt;
                            xtokd[pt].nextt = nt;   /* drop const from chain */
                            xtokd[nt].prevt = pt;
                        } /* integer power if */
                    } /* value range if */
                } /* constant exponent if */
            } /* binary else */

            /* attempt to perform operations on constants */

            if (constr) switch (opc) {

            case ENDF:
                exa->fconst = xtokd[ia].fvalue; /* return literal value */
                break;

            case ENDI:
                exa->iconst = xtokd[ia].ivalue; /* return literal value */
                if ((exa->iconst & 0xffff8000L) == 0)
                    xtokd[ia].code = TKEYWORD; /* 16-bit literal */
                break;

            case PLUS:
                xtokd[ia].fvalue = xtokd[ia].fvalue+xtokd[ib].fvalue;
                break;

            case IPLUS:
                xtokd[ia].ivalue = xtokd[ia].ivalue+xtokd[ib].ivalue;
                break;

            case MINUS:
                xtokd[ia].fvalue = xtokd[ia].fvalue-xtokd[ib].fvalue;
                break;

            case IMINUS:
                xtokd[ia].ivalue = xtokd[ia].ivalue-xtokd[ib].ivalue;
                break;

            case UMINUS:
                xtokd[ia].fvalue = 0.0-xtokd[ia].fvalue;
                break;

            case IUMINUS:
                xtokd[ia].ivalue = 0-xtokd[ia].ivalue;
                break;

            case TIMES:
                xtokd[ia].fvalue = xtokd[ia].fvalue*xtokd[ib].fvalue;
                break;

            case ITIMES:
                xtokd[ia].ivalue = xtokd[ia].ivalue*xtokd[ib].ivalue;
                break;

            case DIVIDE:
                if (xtokd[ib].fvalue == 0.0) constr = FALSE;
		else {
		    xtokd[ia].fvalue = xtokd[ia].fvalue/xtokd[ib].fvalue;
		}
                break;

            case IDIVT:
                if (xtokd[ib].ivalue == 0) xtokd[ia].ivalue = IHUGE;
                else xtokd[ia].ivalue = xtokd[ia].ivalue/xtokd[ib].ivalue;
                break;

            case IDIVR:
                if (xtokd[ib].ivalue == 0) xtokd[ia].ivalue = IHUGE;
                else {
                    fwk = xtokd[ia].ivalue; /* float operands */
                    fwk1 = xtokd[ib].ivalue;
                    xtokd[ia].ivalue = lcftoi(fwk/fwk1);
                } /* divide-by-zero else */
                break;

            case LSHIFT:
                xtokd[ib].ivalue = xtokd[ib].ivalue & 0x1f; /* 0-31 */
                xtokd[ia].ivalue = xtokd[ia].ivalue << xtokd[ib].ivalue;
                break;

            case RSHIFT:
                xtokd[ib].ivalue = xtokd[ib].ivalue & 0x1f; /* 0-31 */
                xtokd[ia].ivalue = xtokd[ia].ivalue >> xtokd[ib].ivalue;
                break;

            case LUNION:
                xtokd[ia].ivalue = xtokd[ia].ivalue | xtokd[ib].ivalue;
                break;

            case LMASK:
                xtokd[ia].ivalue = xtokd[ia].ivalue & xtokd[ib].ivalue;
                break;

            case LDIFF:
                xtokd[ia].ivalue = xtokd[ia].ivalue ^ xtokd[ib].ivalue;
                break;

            case COMP:
                xtokd[ia].ivalue = ~(xtokd[ia].ivalue);
                break;

            case BITCNT:
                j = 0;
                for(i=0; i<=31; i++)        /* count bits set */
                    if (xtokd[ia].ivalue & (1 << i)) j++;
                xtokd[ia].ivalue = j;
                break;

            case INT:
                xtokd[ia].fvalue = lcint(xtokd[ia].fvalue);
                xtokd[ia].code = FLITERAL;
                break;

            case ITOF:
                xtokd[ia].fvalue = lcitof(xtokd[ia].ivalue);
                xtokd[ia].code = FLITERAL;
                break;

            case FTOI:
                xtokd[ia].ivalue = lcftoi(xtokd[ia].fvalue);
                xtokd[ia].code = ILITERAL;
                break;

            case FTOC:
                xtokd[ia].ivalue = FloatToCoord(xtokd[ia].fvalue);
                xtokd[ia].code = ILITERAL;
                break;

            case ITOC:
                xtokd[ia].ivalue = IntToCoord((int)xtokd[ia].ivalue);
                break;

            case SIN:
                xtokd[ia].fvalue = sin(xtokd[ia].fvalue); 
                xtokd[ia].code = FLITERAL;  
                break;
            
            case COS:               
                xtokd[ia].fvalue = cos(xtokd[ia].fvalue); 
                xtokd[ia].code = FLITERAL;  
                break;  
            
            case TAN:
                xtokd[ia].fvalue = tan(xtokd[ia].fvalue);
                xtokd[ia].code = FLITERAL;
                break;

            case SQRT:
                if (xtokd[ia].fvalue <= 0.0) { 
                    constr = FALSE;
                    break;
                }
                xtokd[ia].fvalue = sqrt(xtokd[ia].fvalue);
                xtokd[ia].code = FLITERAL;
                break; 

            case ABS:
                xtokd[ia].fvalue = fabs(xtokd[ia].fvalue); 
                xtokd[ia].code = FLITERAL;
                break; 
    
            case EXP:
                xtokd[ia].fvalue = exp(xtokd[ia].fvalue); 
                xtokd[ia].code = FLITERAL;
                break; 

            case LOG:
                if (xtokd[ia].fvalue <= 0.00) { 
                    constr = FALSE;
                    break;
                }
                xtokd[ia].fvalue = log10(xtokd[ia].fvalue); 
                xtokd[ia].code = FLITERAL;
                break; 

            case ALOG:
                xtokd[ia].fvalue = pow(10.0,xtokd[ia].fvalue); 
                xtokd[ia].code = FLITERAL;
                break; 

            case LN:
                if (xtokd[ia].fvalue <= 0.0) {
                    constr = FALSE;
                    break;
                }
                xtokd[ia].fvalue = log(xtokd[ia].fvalue); 
                xtokd[ia].code = FLITERAL;
                break; 
                
            case EXPONENT:
                if (xtokd[ia].fvalue < 0.0) {
                    constr = FALSE;
                    break;
                }
                xtokd[ia].fvalue = lcfexpon(xtokd[ib].fvalue,xtokd[ia].fvalue);
                break;

            case ARCSIN:
            case ARCCOS:
                if (fabs(xtokd[ia].fvalue) > 1.0) {
                    constr = FALSE;
                    break;
                }
                if (opc == ARCSIN)
                    xtokd[ia].fvalue = asin(xtokd[ia].fvalue);
                else
                    xtokd[ia].fvalue = acos(xtokd[ia].fvalue);
                break;

            /* process un-evaluable operator */

            default:
                constr = FALSE;
                break;
            } /* end if/switch */

            /* remove operator/operand if constant */

            if (constr && (!xtP[t->code].endop)) { /* result is constant */
                xtokd[ia].nextr = t->nextr; /* preserve logic/rel ptrs */
                xtokd[ia].nextb = t->nextb;
                xtokd[ia].nextt = t->nextt;  /* drop from token chain */
                xtokd[t->nextt].prevt = ia;
            } else  xtokd[ia].constf = FALSE;

            pushw(ia);  /* push result on working stack */

        } /* operator else */

    }; /* while */

    exa->isconst = constr; /* TRUE if constant */

    exprmsg("after const\n"); dmpexpr();

/* ------------------------------------------------------------------------------ */

    /* generate internal branches for logical and relational operations */

    /* compute addresses of tokens in pcode */

    if (ibranf) { /* check if any internal branches present */
        is = 0; /* initialize index */
        ploc = *exa->pcodepos; /* initialize address in pcodes */
        do {

            /* chain forward to next operator/operand */

            is = xtokd[is].nextt;   /* link to next token in chain */
            i = xtokd[is].code;

            /* compute address */

            xtokd[is].loc = ploc; /* set address of token */
            j = xtP[i].sgenv; /* get number additional bytes */
            if (j < 0) {
                if (j == -1) 
                    j = 6; /* array */
                else if (j == -2) 
                    j = 12; /* unindexed array */
                else if (j == -3) 
                    j = sizeof(double); /* floating value */
                else if (j == -6) {
                    j = (xtokd[is].ivalue >> 24) & 0xff;
                    if (j & 1) j++; /* round to word */
                    j += 2; /* length field */
                }
            } /* j if */
            ploc = ploc+j+2; /* advance addr */

            /* add internal branch for linked relational ops */

            if (xtokd[is].nextr) {
                n_addop(IBRANCHF);
                j = xtokd[is].nextt;
                xtokd[ntokd].nextt = j; /* chain branch to next */
                xtokd[j].prevt = ntokd; /* chain next to branch */
                xtokd[is].nextt = ntokd; /* chain previous to branch */
                xtokd[ntokd].prevt = is; /* chain branch to previous */
                xtokd[ntokd].ivalue = xtokd[is].nextr; /* set target */
            } /* linked relational if */

            /* add internal branch for logical op */

            else if (xtokd[is].nextb) {
                j = xtokd[is].nextb;
                j = xtokd[ j ].code;    /* logical operator code */
                if ((j == AND) || (j == OR)) {
                    if (j == AND) n_addop(IBRANCHF);
                    else n_addop(IBRANCHT);
                    j = xtokd[is].nextt;
                    xtokd[ntokd].nextt = j; /* chain branch to next */
                    xtokd[ j ].prevt = ntokd; /* chain next to branch */
                    xtokd[is].nextt = ntokd; /* chain previous to branch */
                    xtokd[ntokd].prevt = is; /* chain branch to previous */
                    xtokd[ntokd].ivalue = xtokd[is].nextb; /* set target */
                } /* and/or if */
            } /* linked op else if */

        } while (!xtP[i].endop); /* address loop */

        /* fill in branch addresses for internal branches */

        is = 0; /* initialize index */
        do {

            /* chain forward to next operator/operand */

            is = xtokd[is].nextt;   /* link to next token in chain */
            i = xtokd[is].code;

            /* fill in target address for branches */

            if ((i == IBRANCHT) || (i == IBRANCHF)) { 
                j = is;
                do { /* loop thru branch-to-branch sequence */
                    j = xtokd[ j ].ivalue;
                    j = xtokd[ j ].nextt;   /* advance to token after relational op */
                } while (xtokd[ j ].code == i); /* branch loop */
                j = xtokd[ j ].loc; /* address to branch to */
                xtokd[is].ivalue = j;
                /* add new entry to relocation table */
                if (!exa->nogen) {
                    add_xref(R_EXPRES,labelID,(unsigned int)(xtokd[is].loc+2),j);
                    add_dest(RD_EXPRES,labelID,(unsigned int)j);
                }
            } /* branch if */

        } while (!xtP[i].endop);  /* address loop */

    } /* internal branches if */

/* ------------------------------------------------------------------------------ */

    /* generate final form of pcodes */

    if (!exa->nogen) {
        is = 0; /* initialze index */

        /* process expression */

        do {

            /* chain forward to next operator/operand */

            is = xtokd[is].nextt;   /* link to next token in chain */
            t = &xtokd[is];
            opc = t->code;

            /* process terminating operator */

            if (xtP[opc].endop) {

                /* insert storeability data if requested */

                if (exa->reqstore) {
                    if (!exa->canstore) { 
                        stglobal = staddr = narrayi = -1;
                    }

                    /* insert storeablity info */

                stkind = exa->exprtype;
                add_word(STORINF);
                add_word(stglobal); /* add global/local flag */
                add_long(stkind); /* add variable/expression type */
                i = ((stkind == TINT) || (stkind == IARRAY) ||
                    (stkind == TBYTE) || (stkind == BARRAY) ||
                    ((stkind & 0xffff) == TXTYPE) ||
                    ((stkind & 0xffff) == XARRAY));
                add_word(i); /* TRUE if result on integer stack */
                add_word(exa->canstore); /* storeable flag */
                add_long(staddr); /* add address of variable */
                add_long(narrayi); /* add num store-able items */
                } /* reqstore if */
                break;  /* exit while */
            } /* endi if */

            /* convert long integer literal to short if possible */

            if (opc == ILITERAL) {
#ifdef Nosuchz
                if ((t->ivalue & 0xffff8000L) == 0)
                    t->code = opc = TKEYWORD;
#endif
            }

            /* output bytes for next operator/operand */

            add_word(opc);
            if (xtP[opc].sgenv) { /* check if additional bytes */
                i = xtP[opc].sgenv;
                switch (i) {

                case -1: /* array */
                    uii = (tstga(opc)? 0: compunit);
                    pda = (struct array_desc FAR *)
                          (descP+unittab[uii].descp+t->ivalue);
                    add_long(pda->addr);
                    add_word((unsigned int)t->ivalue);
                    break;
                    
                case -2: /* whole (unsubscripted) array */
                    uii = (tstga(opc)? 0: compunit);
                    pda = (struct array_desc FAR *)
                          (descP+unittab[uii].descp+t->ivalue);
                    add_long(pda->ltype);
                    add_long(pda->addr);
                    add_long(pda->length);
                    break;

                case -3: /* output floating value */
                    add_flt(t->fvalue); 
                    break;

                case -6: /* in-line text */
                    sloc = t->ivalue & 0xffffffL;
                    slen = (t->ivalue >> 24) & 0xff;
                    add_word((int)slen);
                    ucp = (unsigned char FAR *)exa->pcode;
                    ucp += *exa->pcodepos;
                    TUTORget_string_doc(exa->srcH,sloc,slen,ucp);
                    ucp += slen;
                    if (slen & 1) {
                        *ucp = '\0'; /* fill to word */
                        slen++;
                    }
                    *exa->pcodepos += slen;
                    break;

                case 0: /* no additional bytes */
                    break;

                case 1:
                    add_word((int)t->ivalue); /* output single byte field */
                    break;

                case 2: 
                    add_word((int)t->ivalue); /* output 16 bit field */
                    break;

                case 4:
                    add_long(t->ivalue); /* output 32 bit field */
                    break;

                } /* switch */
            } /* sgenv if */

        } while (TRUE);  /* pcode loop */
    } /* nogen if */

    return(0);

} /* compile */

/* ******************************************************************* */
