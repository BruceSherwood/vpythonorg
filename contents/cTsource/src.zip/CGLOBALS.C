
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Declarations for compilation portion of cT.
*/

#include "compute.h"
#include "tutor.h"
#include "cglobals.h"
#include "exprdefs.h"

#ifdef ctproto
#endif /* ctproto */

/* from ecglobal */

long curvbytes; /* number bytes (global or local) var storage allocated */
struct xtoken FAR *xtokd;	/* pointer to expression analyzer destination stack */
int ntokd;		/* number tokens in destination stack */
int xtokmalloc;	/* current size of expression analyzer stacks */
/* input preprocessing variables */
unsigned char cB[CBUFFSIZE+2];	/* input buffer */
int nBuffChars;	/* # of characters in buffer */
int cI;			/* current position in buffer */
int ciStart;	/* start of current line in buffer */
char buffFull;		/* TRUE if buffer filled without finishing line */
char refillBuff;	/* TRUE if need to refill buffer to finish compiling command */
char continFlag;	/* TRUE if command is a continuation */
char nocliptext;	/* TRUE if old scheme of not clipping at bottom margin */
char oldfontsize;	/* TRUE if old font size meaning top of Y to bottom of y */
char wrapwrite;	/* TRUE if -write- commands (& show family) should wrap */
char oldcolor; /* TRUE if old -rgb- and color scheme */
char nostylemarkf; /* TRUE if no styles in markers */
char allowcoarse; /* TRUE if coarse-grid co-ordinates allowed */
long srcEnd;	/* end position of current compile (usually unit end) */

Memh condTh;
short condTalloc;
int nCondTag;

Memh xrefH = 0; /* handle on cross-reference table for this unit */
struct locref FAR *xrefP; /* address of reference table */
int xrefL; /* current length of reference table */

Memh srbimapH; /* handle on source/binary map for this unit */
struct srbimap FAR *srbimapP; /* pointer to map */
int srbimapL; /* current length of source/binary map */

int nconvert;	/* number of times conversion attempted */

/* regular variables */
int pgen;	/* TRUE if should generate p-code */
unsigned int cstartcommand; /* start of conditional command binary */
int condref1; /* index of address of end of command */
int condref2; /* index of address of table */
unsigned int condref3; /* address of maximum integer value */

int condcount; /* number of tags in conditional command */

int global_def_fin; /* TRUE if compile of global defines completed */
int local_def_fin; /* TRUE if compile of local defines completed */
int npass_by_value; /* number pass-by-value arguments of this unit */
int npass_by_addr; /* number pass-by_address arguments of this unit */
Memh uargH; /* handle on unit arguments table */
struct argdef FAR *uargP; /* pointer to unit arguments */

struct expra *exa; /* ptr to expr analyzer input/output params */
struct expra defexp; /* default expr analyzer params */

long startofline; /* start of source line */
long startcommand; /* pcode loc of command */
int newcmd; /* current command being compiled */
int addcmd; /* command code to add to pcodes */
int lastcmd;
int chkeol; /* TRUE if should check for NEWLINE at end of command */
long countloc;
int argcount;
char condFlag;  /* on a command, 0: not conditional, 1: started, 2: expression, 3: tags */

struct indenter indent[MAXINDENTS];
struct caseopt caseod[MAXINDENTS]; /* -case- command optimization */
int indentlevel;
int breaklevel; /* indent level of OUTLOOP, RELOOP, OUTIF, OUTCASE */

long prevend;	/* index of end of previous expression */
unsigned char appendok;	/* TRUE if ok to append to previous expression */
long loopexit;	/* index of -loop- exit code */
int topw;	/* index of current top of working stack */
int endopc;	/* ENDF/ENDI/ENDM code */
long narrayi;	/* number items in store-able array */
int multei;	/* index of multiple expression */
long multeic[NMULTE];	/* index to p-code type byte of multiple expression */

int parencnt;  /* no. of left parens minus right parens */
int embedcnt;  /* no. of left embeds minus right embeds */
int ibranf;	/* internal branch(es) present flag */
int indexcnt;  /* number of indices in an array */

int oldcmd; /* previous command */
int thislevel;  /* indent level of this command */
int cmd; /* command found by lex */
long cmdsourceloc; /* start of source statement */
long currentkind; /* current -define- type (TFLOAT, TBYTE, etc.) */
int haslocalfiles; /* TRUE if setfile/addfile local file */
long startgetcmd;	/* position at start of command line */
int keyword_counter; /* count of keywords processed in this command */

/* YYSTYPE yylval; -- actually defined in prec.c */
int previous;	/* previous state */
