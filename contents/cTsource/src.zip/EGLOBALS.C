
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Declarations for cT execution.
*/

#include <stdio.h>
#include "compute.h"
#include "setjmp.h"
#include "tfiledef.h"
#include "tutor.h"
#include "eglobals.h"

#ifdef ctproto
#endif /* ctproto */

long *iresP; /* pointer to current top of integer stack */
long istack[EX_STACKL]; /* stack of intermediate integer results */
double *fresP; /* pointer to current top of floating stack */
double fstack[EX_STACKL]; /* stack of intermediate floating results */
struct markvar FAR *markP; /* pointer to current top of marker stack */
struct markvar FAR *markstack; /* stack of intermediate marker results */

int execrun; /* continue execution/return flag */

ExecuteState exS; /* data for each executor */

/* we need only one of these for all executors: */
Memh grapheditmenus; /* pointer to graph edit menus */

char FAR *exec_err_msg; /* execution error message buffer */


#ifdef THINKC5
int (FAR * FAR *exs_addr)(...); /* routines to process commands/expression elements */
#else
int (FAR * FAR *exs_addr)(); /* routines to process commands/expression elements */
#endif

short FAR *ex_binP; /* execution pointer */

int store_kind; /* type of storeable item */
long store_addr; /* address of storeable item */
long store_items; /* number of storeable items */

