
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* display of documents  */

#include "baseenv.h"
#include "txt.h"
#include "ct_ctype.h"
#include "tutor.h"
#include "compute.h"
#include "kglobals.h"
#include "tglobals.h"
#include "eglobals.h"

#ifdef ctproto
extern int DocBuffer(Memh dh);
extern void TUTORset_color(int select,struct tutorColor FAR *newColor);
int TUTORset_sub_new(int sub,int newl);
char FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
extern int sprintf(char *ss, char *form,...);
int  TUTORdraw_doc(unsigned int  doc,long  pos,long  len,
		   struct tutorColor FAR *fc,int  left,
                   int  width,int  height,int  wordB,int  nLines,char  FAR *cliLay,
                    int  pStart,int  *lastHeight,int  *maxH,int SupSubAdj);
int  TUTORdraw0_doc(unsigned int  doc,long  pos,long  len,int  left,struct  _linelay FAR *liLay);
int  TUTORword_bounds2_doc(unsigned int  doc,long  pos,long  *wordSp,long  *wordEp,int  wSide);
extern int  _TUTORdraw_line(struct  _ktd FAR *dp,long  pos,long  len,
int  left,int  pStart,struct  _paral *pLay,long  fracShim,struct  _pdt FAR *sp,
int  *styleInd,short  *curStyles,int  *supersub,struct	_spt2 FAR *stp,
int  *stind,int  curY,int  lineHeight,int  mDraw,int  maxLines,int  *maxH);
extern int  InvisibleSkip(struct  _ktd FAR *dp,long  pos,long  len,struct  _paral *pLay,struct  _pdt FAR *sp,int  *styleInd,short  *curStyles,int  *supersub,struct  _spt2 FAR *stp,int  *stind);
int  _TUTORlayout_lines(struct  _ktd FAR *dp,long  pos,long  len,int  width,int  wordB,int  curX,struct  _pdt FAR *sp,int  styleInd,struct  _linelay FAR *liLay,short  *curStyles,struct  _paral *pLay,struct  _spt2 FAR *stp,int  stind);
extern int  TUTORline_layout0(struct  _ktd FAR *dp,long  pos,long  len,struct  _pdt FAR *sp,int  *styleInd,struct  _linelay FAR *li,short  *curStyles,struct  _paral *pLay);
extern int  TUTORline_layout(struct  _ktd FAR *dp,long  pos,long  len,int  curX0,int  wordB,int  spaceA,struct  _pdt FAR *sp,int  *styleInd,struct  _linelay FAR *li,short  *curStyles,struct  _paral *pLay,struct  _spt2 FAR *stp,int  *stind);
extern int  InvisibleLayout(struct  _ktd FAR *dp,long  pos,long  len,struct  _pdt FAR *sp,int  *styleInd,struct  _linelay FAR *li,short  *curStyles,struct  _paral *pLay,struct  _spt2 FAR *stp,int  *stind);
extern int  WordBreakLine(int  c0,int  c1);
struct  tutorview FAR *TUTORinq_view(void);
extern int  DrawTab(struct  _paral *pLay,int  left,int vtab);
int  _TUTORtab_width_doc(struct  _paral *pLay,int  curX);
extern int  AdjustHeight(int  faceS,int  *desc,int  *asc);
int  _TUTORsetup_layout(struct  _ktd FAR *dp,long  pos,long  len,int  *styleInd,struct  _pdt FAR * *styleP,short  *curStyles,struct  _paral *pLay,int  *stind,struct  _spt2 FAR * *stp,int  fillDef);
int  _TUTORget_styles_doc(struct  _ktd FAR *dp,long  pos,short  *curStyles);
int  _TUTORset_textfont_doc(struct  _ktd FAR *dp,short  *curStyles);
int  _TUTORset_curstyles_doc(struct  _ktd FAR *dp,struct  _sty1 FAR *s1p,short  *curStyles);
int  TUTORcount_bytes(unsigned char  FAR *tp,unsigned char  FAR *te,int  cc);
int  TUTORinq_comb_rule(void);
int  CTset_foreground_color(int  color);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  TUTORabs_move(int  x,int  y);
int  TUTORabs_move_to(int  x,int  y);
int  TUTORinq_font_info(int  *ascent,int  *descent,int  *maxwidth,int  *leading);
unsigned char  FAR *TUTORscan_bytes(unsigned char  FAR *bp,unsigned char  FAR *be,unsigned char  *tp,int  nTab);
int  TUTORinq_abs_pen_pos(int  *x,int  *y);
int  TUTORinq_foreground_color(struct tutorColor *fc);
int  _TUTORload_buffer_doc(struct  _ktd FAR *dp,long  pos);
char  FAR *GetPtr(unsigned int  mm);
int  _TUTORmeasure_text_tview(unsigned int  doc,long  pos,struct  _linelay FAR *liLay,int  newP,int  flag,int  info,int  *wUsed,int  *whichSide);
int  TUTORabs_line_to(int  x,int  y);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
int  TUTORset_comb_rule(int  rule);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORdraw_stext(struct  _stxt2 FAR *st1p);
int  TUTORdraw_text(unsigned char  FAR *buf,int  count);
int  GetParaLayout(int  ii,struct  _paral *pl);
int  TUTORdump(char  *s);
int  TUTORmeasure_stext(struct  _stxt2 FAR *st1p,int  *asc,int  *desc,int  *lead);
int  TUTORinq_abs_string_width(unsigned char  FAR *s,int  lth,int  *dx);
int  TUTORfind_stext(struct  _spt2 FAR *stp,long  pos);
int  AtTStyle(unsigned int  pd,long  pos,short  *styles);
int  TUTORset_textfont2(long  family,int  size,int  face);
int  TUTORcvt_text_size(int  fid,int  defSz,int  sz);
#endif /* ctproto */

#ifdef macproto
extern long TUTORprint_doc(Memh doc, long pos, long len, int pageX, int pageY,
	int left, int *pStart, int pFlag);
#endif

extern TextBlock FAR *FindTBlock();
extern unsigned char FAR *TUTORscan_bytes();
extern char FAR *GetPtr();
extern struct tutorview FAR *TUTORinq_view();

/* default displacement for super/subscript */
#define DEFSUPERSUB 5

/* size of layout array we will try to use */
#define NFASTLAYOUT 15

/* height of invisible line (which is a line with 0 ascent) */
#define INVISLINEH 4

int SupSubOff = FALSE; /* TRUE if should suppress sup/sub adjust */

static TRect backFillR; /* rectangle used last to fill background
							(for inverse & rewrite) */
static Memh staticLay = HNULL; /* scratch layout, minimize allocs */
static int txt_newlineH = 0; /* (minimum) newline height */
static int txt_supsubH = DEFSUPERSUB; /* superscript/subscript height */

TUTORdraw_doc(doc,pos,len,fgndC,left,width,height, wordB,nLines,cliLay,pStart, lastHeight, maxH,noSupSub)
Memh doc;	/* document we are drawing */
long pos, len;	/* the portion of the document to be drawn */
struct tutorColor FAR *fgndC;
int left,width;	/* defines horizontal space where text is drawn */
int height;	/* maximum height that drawing can use */
int wordB;		/* TRUE if lines can break on word boundaries (used only if !liLay) */
int nLines;		/* # of lines to draw with lineLayout info, or -1 if no layout info known */
char FAR *cliLay;	/* line layout info for at least nLines lines */
int pStart;		/* TRUE if we are starting at beginning of paragraph */
int *lastHeight;	/* to be set to height of last line (without leading) */
int *maxH;		/* to be set to maximum horizontal position reached while drawing text */
int noSupSub; /* TRUE if should suppress adjustment of text position for super/subscript */
	{
	REGISTER DocP dp;	/* pointer to doc */
	short curStyles[NSTYLES]; /* current styles */
	int styleInd;	/* index of current style (in style structure) */
	StyleDatP styleP;	/* pointer to current style block */
	int stind;	/* index of current special text block */
	SpecialTP stp;	/* pointer to current special text block */
	ParagraphLayout curPara;	/* current paragraph layout */
	int justif;	/* current justification */
	int maxA, maxD, maxL; /* max ascent, descent, leading of line */
	int lineHeight;	/* total line height */
	int curX;	/* pen's horizontal position before we start drawing */
	int curY;	/* current vertical position of pen */
	unsigned int maxY;	/* bottom of line we are drawing */
	ParagraphLayout para0;	/* to save & restore current paragraph layout */
	short styles0[NSTYLES];	/* to save & restore current styles */
	long tempL;
	register int ii, jj;
	int kk;
	int maxLines;	/* maximum # of lines we might have to lay out */
/*	LineLayout tempLay[NFASTLAYOUT]; */ /* line layout space, allocated on stack */
	Memh memLay;	/* handle containing line layouts (as tempLay but in heap) */
	int spaceA;	/* space available on line */
	int curXTab;	/* current pen position relative to tab origin */
	unsigned char FAR *tp;	/* pointer to relevant text in document buffer */
	unsigned char scanS[2];	/* scan target characters */
	int supersub;	/* super/sub state: -1 superscript, 0 normal, 1 subscript */
	REGISTER LineLayout FAR *liLay;	/* pointer to line layout structure */
	struct tutorColor saveColor;	/* foreground color before we start drawing */
	int newMaxH;	/* maximum horizontal position attained by each line */
	int needFill;	/* flag: 0 no fill needed, 1 rewrite fill, -1 inverse fill */
	int twidth;	/* text width of portion of line */
	int saveMode;	/* to save & restore the mode */
	int visf; /* TRUE if text visible */
	TRect tr;	/* rectangle used for background fill */
	int startH;	/* where (horizontally) we start drawing */
	int smuli; /* super/subscript */
	
	SupSubOff = noSupSub; /* turn off sup/sub adjust if required */
	
	liLay = (LineLayout FAR *) cliLay;
	dp = (DocP) GetPtr(doc);
	if ((dp->totLen > (dp->txtH.dAnAlloc-10)) && (dp->txtH.dAnAlloc < TBUFFLEN)) {
		/* make sure buffer is big enough to lay out longest line */
		ReleasePtr(doc);
		DocBuffer(doc);
		dp = (DocP) GetPtr(doc);
	}

	/* if text isn't already in dp->text, get it there
		note that this assummes that dp->text always holds at least a line */
	if (!dp->shortText && (pos+len > dp->buffEnd || pos < dp->buffStart))
		_TUTORload_buffer_doc(dp,pos);
	
	_TUTORsetup_layout(dp,pos,len,&styleInd,&styleP,curStyles,&curPara,&stind,&stp,TRUE);
	justif = curStyles[PARASTYLE] & JUSTMASK;
	_TUTORset_textfont_doc(dp,curStyles);
	TUTORinq_foreground_color(&saveColor);
	txtFgndColor = *fgndC;
	TUTORset_color(0,(struct tutorColor FAR *)fgndC); /* set to default */
	if ((curStyles[COLORSTYLE] != DEFSTYLE) &&
	    (curStyles[COLORSTYLE] != color_rgb))
	    CTset_foreground_color(curStyles[COLORSTYLE]);
	
	/* where are we now */
	TUTORinq_abs_pen_pos(&curX,&curY);
	
	/* most -write- commands can be done very fast: */
	
	visf = !(curStyles[PARASTYLE] & VISMASK);

#ifndef MAC
	ii = TUTORinq_comb_rule();
#endif
	if (visf && justif == LEFTJUST && !styleP && !stp && !wordB &&
#ifndef MAC
			/* non-mac systems don't draw inverse & rewrite chars properly,
				they need the explicit background fill that is done
				in the more general case */
			(ii != SRC_COPY && ii != NOT_SRC_COPY) &&
#endif
			(dp->shortText || dp->buffEnd >= pos+len))
		{ /* important special case - do it fast */
		tp = ((unsigned char FAR *) dp->text) + (pos-dp->buffStart);
		scanS[0] = NEWLINE;
		if (TUTORscan_bytes(tp,tp+len-1,scanS,1) || lastHeight)
			{ /* more than 1 line, we need line height info */
			TUTORinq_font_info(&maxA,&maxD,NEARNULL,&maxL);
			lineHeight = maxA+maxD+maxL;
			if (lineHeight < txt_newlineH)
				lineHeight = txt_newlineH;
			if (lastHeight)
				*lastHeight = maxA + maxD + maxL;
			maxLines = (height-1)/lineHeight + 1;
			}
		else
			{
			TUTORinq_font_info(&maxA,&maxD,NEARNULL,NEARNULL);
			if ((maxA+maxD) < txt_newlineH)
				maxA += txt_newlineH-(maxA+maxD);
			lineHeight = 0;
			maxLines = 1;
			}
		curY += maxA; /* compensate for ascent */
		ii = curStyles[FACESTYLE];

		if (SupSubOff) {
			if (ii & SUBSTYLE && !(ii & SUPERSTYLE)) { /* subscript */
				curY += txt_supsubH;
			} else if (ii & SUPERSTYLE && !(ii & SUBSTYLE)) { /* superscript */
				curY -= txt_supsubH;
			}
		} else {
			if (ii & SUBSTYLE && !(ii & SUPERSTYLE)) { /* subscript */
				curY += txt_supsubH;
				if (lineHeight)
					lineHeight += txt_supsubH;
				if (lastHeight)
					*lastHeight += txt_supsubH;
			} else if (ii & SUPERSTYLE && !(ii & SUBSTYLE)) { /* superscript */
				curY -= txt_supsubH;
				if (lineHeight)
					lineHeight += txt_supsubH;
				if (lastHeight)
					*lastHeight += txt_supsubH;
			}
		} /* SupSubOff else */

		TUTORabs_move_to(curX+curPara.leftMar+(pStart ? curPara.paraIndent : 0),curY);
		_TUTORdraw_line(dp,pos,len,left,pStart,&curPara,0L,FARNULL,NEARNULL,NEARNULL,NEARNULL,
				FARNULL, NEARNULL, curY,lineHeight,TRUE,maxLines,maxH);
		TUTORabs_move(0,-maxA); /* move pen to top of line */
		
		ReleasePtr(doc);
		KillPtr(dp);
		TUTORset_color(0,&saveColor);
		SupSubOff = FALSE;
		return(0); /* all done */
		}

	/* mode rewrite & inverse need to fill background */
	ii = TUTORinq_comb_rule();
	if (ii == SRC_COPY)
		needFill = 1;
	else if (ii == NOT_SRC_COPY)
		needFill = -1;
	else
		needFill = 0;
	
	if (!liLay)
		{ /* we need to do layout here */
		
		/* save current state, so we can recover after doing layout */
		if (styleP)
			{
			para0 = curPara;
			for (ii=0; ii<NSTYLES; ii++)
				styles0[ii] = curStyles[ii];
			}
		
		if (!wordB)
			{ /* breaking only on NEWLINEs */
			
			/* count the # of lines */
			
			tp = ((unsigned char FAR *) dp->text) + (pos-dp->buffStart);
			if (dp->shortText || ((pos+len) <= dp->buffEnd))
				{
				nLines = TUTORcount_bytes(tp,tp+(len-1),NEWLINE);
				if (*(tp+(len-1)) != NEWLINE)
					nLines++; /* to account for chars after last newline */
				}
			else
				{ /* text will have to be reloaded into buffer during layout... */
					 /* assumme absolute worst case - all newlines */
				nLines = (len > MAXLAYOUTLINES) ? MAXLAYOUTLINES : len;
				}
			}
		else
			{ /* not breaking on newlines, can't easily figure out how many lines */
			 /* assumme absolute worst case - all newlines */
			nLines = (len > MAXLAYOUTLINES) ? MAXLAYOUTLINES : len;
			}
		
		/* make sure we have enough line layout space */
		if (/* nLines <= NFASTLAYOUT */ FALSE)
			{
		/*	liLay = (LineLayout FAR *) tempLay; */
			memLay = 0; /* we didn't allocate line layout memory */
			}
		else
			{ /* allocate space */
			if (nLines > MAXLAYOUTLINES)
				nLines = MAXLAYOUTLINES; /* maximum # of lines we will lay out */
/*			memLay = TUTORhandle("tempLayt",(long) (sizeof(LineLayout)*nLines),FALSE); */
			if (staticLay) {
				memLay = staticLay; /* use scratch layout */
				staticLay = HNULL;
			} else
				memLay = TUTORhandle("tempLayt",(long) (sizeof(LineLayout)*MAXLAYOUTLINES),FALSE); 
			if (!memLay)
				{
				TUTORset_color(0,&saveColor);
				if (styleP)
					{
					ReleasePtr(dp->styles);
					KillPtr(styleP);
					}
				if (stp)
					{
					ReleasePtr(dp->specialT);
					KillPtr(stp);
					}
				ReleasePtr(doc);
				KillPtr(dp);
				SupSubOff = FALSE;
				return(0); /* we can't do anything! */
				}
			liLay = (LineLayout FAR *) GetPtr(memLay);
			}
		
		nLines = _TUTORlayout_lines(dp,pos,len,width,wordB,curX-left,styleP,styleInd,
						liLay,curStyles,&curPara,stp,stind);

		/* return styles to state at pos */
		if (styleP)
			{
			for (ii=0; ii<NSTYLES; ii++)
				curStyles[ii] = styles0[ii];
			curPara = para0;
			_TUTORset_textfont_doc(dp,curStyles);
			}
		} /* end of (!liLay) */
	else
		memLay = 0;
	
	/* now we can finally draw the text */
	
	/* position pen */
	maxY = curY + height;
	curY += liLay->lineAsc; /* compensate for ascent of line */
	/* calculate super/sub state */
	supersub = 0;
	ii = curStyles[FACESTYLE];
	if (ii & SUPERSTYLE)
		supersub--;
	if (ii & SUBSTYLE)
		supersub++;
	startH = curX+curPara.leftMar+(pStart ? curPara.paraIndent : 0);
/*	if (SupSubOff) 
		TUTORabs_move_to(startH,curY);
	else */
		TUTORabs_move_to(startH,curY+supersub*txt_supsubH);
	
	if (needFill)
		{ /* change mode so that text draws a bit faster */
		saveMode = (needFill == 1) ? SRC_COPY : NOT_SRC_COPY;
		TUTORset_comb_rule((needFill == 1) ? SRC_OR : SRC_BIC);
		}
	else
		backFillR.left = -10000; /* indicates that we aren't filling */

	if (maxH)
		*maxH = 0;
	if (lastHeight) {
	    if (nLines > 0)
		*lastHeight = liLay[nLines-1].lineHeight; /* has leading... */
	    else *lastHeight = 0;
	}

	for (ii=0; ii<nLines; ii++)
		{
		if (!liLay->lineAsc)
			{ /* invisible line */
			TUTORabs_move(10,2); /* move over a bit */
			jj = startH + width - 10; /* end of line */
			if (jj > 60)
				jj = 60;

			if (needFill)
				{ /* fill in background */
				backFillR.left = startH;
				backFillR.top = curY;
				backFillR.right = startH + jj-1;
				backFillR.bottom = curY + liLay->lineHeight - 1;
				TUTORdraw_abs_solid_rect((TRect FAR *) &backFillR, (needFill == 1) ? PAT_WHITE : PAT_BLACK);
				}

			TUTORabs_line_to(startH+jj,curY+2);
			if (maxH && startH+jj > *maxH)
				*maxH = startH+jj;
			/* keep styles current */
			InvisibleSkip(dp,pos,(long) liLay->nc,&curPara,styleP,&styleInd,curStyles,&supersub,stp,&stind);
			}
		else
			{ /* visible line */
			if (!dp->shortText && pos+liLay->nDraw > dp->buffEnd)
				{ /* we need to reload buffer */
				_TUTORload_buffer_doc(dp,pos);
				jj = 2;
				}
			
			if (needFill)
				{ /* fill in the background */
				backFillR.top = curY - liLay->lineAsc;
				backFillR.bottom = curY - liLay->lineAsc + liLay->lineHeight - 1;
				if (liLay->justif == FULLJUST && !liLay->endNewline && ii < nLines-1)
					{
					backFillR.left = startH;
					backFillR.right = left + width - 1;
					}
				else
					{
					jj = liLay->justWidth; /* to restore justwidth */
					liLay->justWidth = 0; /* so justification doesn't ruin measurement */
					twidth = _TUTORmeasure_text_tview(doc,pos,liLay,pStart,TRUE,liLay->nDraw,NEARNULL,NEARNULL);
					liLay->justWidth = jj; /* restore */
					if (liLay->justif == LEFTJUST || liLay->justif == FULLJUST)
						{
						backFillR.left = startH;
						backFillR.right = backFillR.left + twidth - 1;
						}
					else if (liLay->justif == CENTERJUST)
						{
						backFillR.left = startH + (width - (startH-left) - twidth)/2;
						backFillR.right = backFillR.left + twidth - 1;
						}
					else
						{ /* right justified */
						backFillR.right = left + width - 1;
						backFillR.left = backFillR.right - twidth -1;
						}
					}
				TUTORdraw_abs_solid_rect((TRect FAR *) &backFillR,  (needFill == 1) ? PAT_WHITE : PAT_BLACK);				
				}
			
			if (liLay->justif == LEFTJUST)
				jj = liLay->nDraw;
			else /* first part isn't justified but has tabs */
				jj = liLay->lastTab+1; /* # of chars to draw, including tab */
			if (jj)
				{
				_TUTORdraw_line(dp,pos,(long) jj,left,pStart,&curPara,0L,styleP,&styleInd,
							curStyles,&supersub,stp,&stind,0,0,FALSE,0,maxH ? &newMaxH : NEARNULL);
				if (maxH && newMaxH > *maxH)
					*maxH = newMaxH;
				}
			/* now justify & draw second part of line, if there is one */
			kk = liLay->nDraw - jj;	/* # of chars in second part of line */
			if (kk)
				{ /* there is something to draw */
				TUTORabs_move(liLay->justWidth,0);
				_TUTORdraw_line(dp,pos+jj,(long) kk,left,pStart,&curPara,liLay->fracShim,styleP,
							&styleInd,curStyles,&supersub,stp,&stind,0,0,FALSE,0,maxH ? &newMaxH : NEARNULL);
				if (maxH && newMaxH > *maxH)
					*maxH = newMaxH;
				}
			}
		
		/* setup for next line (or finish) */
		
		pStart = liLay->endNewline; /* set pStart for next line */
	/* 	if (SupSubOff) smuli = 0;
		else  */ smuli = supersub;
		if ((ii >= (nLines-1) && !pStart) || (curY + liLay->lineHeight-liLay->lineAsc > maxY))
			{ /* we are done drawing without a newline.  Put pen at top of current line */
			TUTORabs_move(0,-((int) liLay->lineAsc + smuli*txt_supsubH));
			break;
			}
		else if (ii >= (nLines-1))
			{ /* done drawing, last line ended in newline */
			TUTORabs_move_to(left+curPara.leftMar,
					curY+liLay->lineHeight-liLay->lineAsc - smuli*txt_supsubH);
			break;
			}
		else
			{ /* we will draw more */
			curY += liLay->lineHeight  - liLay->lineAsc + (liLay+1)->lineAsc;
			TUTORabs_move_to(left+curPara.leftMar+(liLay->endNewline ? curPara.paraIndent : 0),
							curY+supersub*txt_supsubH);
			pos += liLay->nc;
			startH = left+curPara.leftMar+(liLay->endNewline ? curPara.paraIndent : 0);
			liLay++;
			}
		}
	
	if (memLay)
		{ /* layout info in handle, get rid of it */
		ReleasePtr(memLay);
		KillPtr(liLay);
		if (!staticLay)
			staticLay = memLay; /* keep one scratch layout */
		else
			TUTORfree_handle(memLay);
		}
	
	if (styleP)
		{
		ReleasePtr(dp->styles);
		KillPtr(styleP);
		}
	if (stp)
		{
		KillPtr(stp);
		ReleasePtr(dp->specialT);
		}
	
	ReleasePtr(doc);
	KillPtr(dp);
	TUTORset_color(0,&saveColor);
	
	if (needFill)
		{ /* restore the mode */
		TUTORset_comb_rule(saveMode);
		}
			
	SupSubOff = FALSE;
	return(0);
	}

TUTORdraw0_doc(doc,pos,len,left,liLay)	/* draw part of line from where we are (no paragraph stuff) */
Memh doc;	/* document we are drawing */
long pos, len;	/* what portion of the document is to be drawn */
int left;	/* left edge of text (tab origin) */
LineLayout FAR *liLay;	/* pointer to line layouts for this part of document */
	{
	REGISTER DocP dp;	/* pointer to doc */
	short curStyles[NSTYLES];	/* current styles */
	ParagraphLayout curPara;	/* current paragraph layout */
	StyleDatP styleP;	/* pointer to current style block */
	int styleInd;	/* index to current style block */
	struct tutorColor saveColor;	/* to save & restore the foreground color */
	int ii;
	SpecialTP stp;	/* pointer to current special text block */
	int stind;	/* index of current special text block */
	
	dp = (DocP) GetPtr(doc);

	/* if text isn't already in dp->text, get it there
		note that this assummes that dp->text always holds at least a line */
	if (!dp->shortText && (pos+len > dp->buffEnd || pos < dp->buffStart))
		_TUTORload_buffer_doc(dp,pos);
	
	_TUTORsetup_layout(dp,pos,len,&styleInd,&styleP,curStyles,&curPara,&stind,&stp,TRUE);
	_TUTORset_textfont_doc(dp,curStyles);
	TUTORinq_foreground_color(&saveColor);
	if (curStyles[COLORSTYLE] != color_rgb)
	    CTset_foreground_color(curStyles[COLORSTYLE]);
	else
	    TUTORset_color(0,(struct tutorColor FAR *)&txtFgndColor);

	/* handle super/subscripts */
	ii = curStyles[FACESTYLE];
	if (ii & SUBSTYLE && !(ii & SUPERSTYLE))
		{ /* subscript */
		ii = 1;
		}
	else if (ii & SUPERSTYLE && !(ii & SUBSTYLE))
		{ /* superscript */
		ii = -1;
		}
	else
		ii = 0;
		
	_TUTORdraw_line(dp,pos,len,left,FALSE,&curPara,0L,styleP,&styleInd,curStyles,&ii,stp,&stind,
			0,1,FALSE,0,NEARNULL);
	
	if (styleP)
		{
		ReleasePtr(dp->styles);
		KillPtr(styleP);
		}
	if (stp)
		{
		ReleasePtr(dp->specialT);
		KillPtr(stp);
		}
	ReleasePtr(doc);
	KillPtr(dp);
	TUTORset_color(0,&saveColor);

	return(0);
	}

TUTORword_bounds2_doc(doc,pos,wordSp,wordEp,wSide) /* find word boundaries for click */
Memh doc;	/* document we are looking at */
long pos;	/* position (in characters) of click */
long *wordSp; /* to be set to position at start of word */
long *wordEp; /* to be set to position at end of word */
int wSide;	/* 1 if click was to right of pos, -1 if to left */
	{
	REGISTER DocP dp;	/* pointer to doc */
	register unsigned char FAR *tp;	/* pointer to current character */
	register unsigned char FAR *te;	/* pointer to last character (don't scan past te) */
	unsigned char FAR *t0;	/* pointer to character at (namely just after) pos */
	long tempL, tempL2;
	unsigned char cc;	/* the character actually clicked on (which may be on either
							side of pos) */
	int ii;
	
	dp = (DocP) GetPtr(doc);
	
	if (!dp->shortText)
		{ /* load buffer, if neccesary */
		tempL = pos-30;
		if (tempL < 0)
			tempL = 0;
		tempL2 = pos+30;
		if (tempL < dp->buffStart || tempL2 > dp->buffEnd)
			_TUTORload_buffer_doc(dp,tempL);
		}

	/* look at character that was clicked on */
	t0 = tp = ((unsigned char FAR *) dp->text) + (pos - dp->buffStart);
	if (pos >= dp->totLen && wSide == 1)
		cc = ' '; /* make psuedo-char after doc end so that behaviour is correct
						at end of document */
	else /* normal case */
		cc = (wSide == 1) ? *tp : *(tp-1);
	if (!CTisalnum(cc))
		{ /* that character isn't alphanumeric */
		if ((cc == BITMAPSPECIAL) || (cc == PIXMAPSPECIAL) || (cc == ICONSPECIAL))
			{ /* the clicked-on char is a graphic character, it is a "word" by itself */
			ii = (wSide == -1) ? -1 : 0;
			*wordSp = pos + ii;
			*wordEp = pos+1 + ii;
			}
		else /* just some white space or punctuation */
			*wordSp = *wordEp = pos;
		ReleasePtr(doc);
		KillPtr(dp);
		return(0);
		}
	
	/* find end of word */
	te = ((unsigned char FAR *) dp->text) + (dp->txtH.dAnn-1); /* last char in buffer */
	while (tp <= te && CTisalnum(*tp))
		tp++;
	*wordEp = (tp - (unsigned char FAR *) dp->text) + dp->buffStart;
	
	/* find begin of word */
	tp = t0;
	te = (unsigned char FAR *) dp->text;
	while (tp > te && CTisalnum(*(tp-1)))
		tp--;
	
	*wordSp = (tp - (unsigned char FAR *) dp->text) + dp->buffStart;
	
	ReleasePtr(doc);
	KillPtr(dp);
	return 0;
	}

/* draw a line of text: */
static _TUTORdraw_line(dp,pos,len,left,pStart,pLay,fracShim,sp,styleInd,curStyles,supersub,
			stp,stind,curY,lineHeight,mDraw,maxLines,maxH)
DocP dp;	/* document we are drawing */
long pos, len;	/* what part of the document we are drawing */
int left;	/* horizontal origin of text */
int pStart;	/* TRUE if this line is beginning of paragraph */
ParagraphLayout *pLay;	/* current paragraph layout */
long fracShim;	/* if non-zero, fractional shimming we want to use */
				/* note that if fracShim is non-zero we won't look for tabs & newlines */
StyleDatP sp;	/* if exists, pointer to style data */
int *styleInd;	/* index of next style */
short *curStyles;	/* current styles */
int *supersub;	/* super/sub state: -1 superscript, 0 normal, 1 subscript */
SpecialTP stp;	/* pointer to special text data */
int *stind;		/* index of next special text block */
int curY,lineHeight;	/* vertical positioning.  Only used when drawing multiple lines,
							which should only be left justified, newline broken, unstyled. */
int mDraw;	/* TRUE if drawing multiple lines (which then does fill, if needed) */
int maxLines;	/* only used when drawing multiple lines */
int *maxH;		/* to be set to maximum horizontal position reached during draw */
	{
	register unsigned char FAR *tp;	/* pointer to next part of text to draw */
	unsigned char FAR *te;	/* pointer just past end of text */
	unsigned char FAR *t0;	/* pointer to start of text */
	int nBlanks;	/* when shimming, keeps track of # of blanks passed in this line */
	int lastBlankP; /* total # of pixels shimmed after previous blank */
	int curBlankP;	/* how many pixels we currently need shimmed */
	register Style1 SHUGE *s1p;	/* pointer to current style block */
	Style1 SHUGE *s1End;	/* pointer to last style block for document */
	SText FAR *st1p, FAR *st1End;	/* pointer to current & last special text blocks */
	long curPos;	/* our current position */
	long nextCharPos;	/* next position of a character break (tab or shimmed space) */
	long nextStylePos;	/* next position where there is a style change */
	long nextSTextPos;	/* next position where there is special text */
	int setFont;	/* set to TRUE when style change requires a font change */
	int set1Font;	/* TRUE if the current style needs a font change */
	int drawChar; /* text kind flag, 0: normal text, 1: shimmed space, 2: tab, 3: newline, 4: special */
	int nc;	/* a character count */
	unsigned char scans[4];	/* characters we can scan for */
	register int ii, jj;
	int lineN;	/* count of # of lines we've drawn */
	int newX, newY;		/* new pen position */
	int currentMode;	/* the current drawing mode */
	int needFill;	/* TRUE if we need to do background fill due to mode */
	int penX, penY;	/* current pen position */
	int descent, leading;	/* characteristics of current font */
	int startH; /* x where current line starts (used for fill) */
	int viewTab; /* tab size from view */
	TRect tr;	/* rectangle used for background fill */
	struct tutorview FAR *tvp; /* pointer to current view */
	
	viewTab = -1; /* pre-set no tabSize from view */
	tvp = TUTORinq_view(); /* get current view */
	if (tvp)
		viewTab = tvp->tabSize;
	
	/* mode rewrite & inverse need to fill background */
	currentMode = TUTORinq_comb_rule();
	needFill = (currentMode == SRC_COPY || currentMode == NOT_SRC_COPY) ? TRUE : FALSE;
	if (needFill && mDraw)
		{ /* we need some font height info */
		TUTORinq_font_info(NEARNULL,&descent,NEARNULL,&leading);
		TUTORinq_abs_pen_pos(&startH,&penY);
		}
	
	if (maxH)
		*maxH = 0;
	
	tp = t0 = ((unsigned char FAR *) dp->text) + (pos-dp->buffStart);
	te = tp+len;
	if (fracShim)
		{
		nBlanks = 0;
		lastBlankP = 0;
		}

	if (sp)
		{
		s1p = ((Style1 SHUGE *) sp->styles) + *styleInd;
		s1End = ((Style1 SHUGE *) sp->styles) + (sp->sHead.dAnn - 1); /* pointer to last style */
		if (s1p > s1End)
			sp = FARNULL; /* we have no styles */
		}
	if (sp)
		nextStylePos = s1p->pos;
	else
		nextStylePos = pos+len+10;
	
	if (stp)
		{
		st1p = ((SText FAR *) stp->text) + *stind;
		st1End = ((SText FAR *) stp->text) + (stp->head.dAnn - 1);
		if (st1p > st1End || st1p->pos >= pos+len)
			stp = FARNULL; /* no more special text */
		}
	if (stp)
		nextSTextPos = st1p->pos;
	else
		nextSTextPos = pos+len+10; /* we never get there */
	
	nextCharPos = curPos = pos;

	scans[0] = '\t';
	scans[1] = NEWLINE;
	scans[2] = ' ';
	lineN = 0;
	
	/* we will keep tp always pointing just after what has been considered */
	while (curPos < pos+len)
		{
		if (nextCharPos <= curPos)
			{ /* find next character break */
			if (stp && nextSTextPos <= curPos)
				{ /* next character is special text */
				drawChar = 4; /* indicates special text */
				tp += st1p->len; /* skip over special characters */
					/* note that all special chars are "chunked" together */
				nextCharPos = nextSTextPos + st1p->len; /* look at chars following special text */
				}
			else
				{ /* normal case */
				drawChar = 0; /* indicates we expect normal draw */
				if (fracShim)
					{
					if (*tp == ' ')
						{
						drawChar = 1; /* we want to draw shimmed space */
						tp++;
						}
					else
						{ /* scan until end, or we hit a space */
						tp = TUTORscan_bytes(tp,te-1,scans+2,1);
						if (!tp)
							tp = te;
						}
					}
				else if (mDraw)
					{ /* multiple left-justified lines, we need to look for newlines */
					if (*tp == NEWLINE)
						{
						drawChar = 3;
						tp++;
						}
					else if (*tp == '\t')
						{ /* draw a tab */
						drawChar = 2;
						tp++;
						}
					else
						{ /* scan for tab or newline */
						tp = TUTORscan_bytes(tp,te-1,scans,2);
						if (!tp) tp = te;
						}
					}
				else
					{ /* normal case */
					if (*tp == '\t')
						{
						drawChar = 2; /* we want to draw tab */
						tp++;
						}
					else
						{ /* scan until end, or we hit a tab */
						tp = TUTORscan_bytes(tp,te-1,scans,1);
						if (!tp) tp = te;
						}
					}
				nextCharPos = (tp - t0) + pos;
				if (stp && nextCharPos > nextSTextPos)
					{ /* don't let charPos go over special text */
					tp -= (nextCharPos - nextSTextPos);
					nextCharPos = nextSTextPos;
					}
				
				} /* end of normal (not special text) case */
			} /* end of nextCharPos <= curPos) */
		
		if (nextStylePos <= curPos)
			{ /* take care of styles */
			setFont = FALSE;
			while (s1p <= s1End && s1p->pos <= curPos)
				{
				set1Font = _TUTORset_curstyles_doc(dp,s1p,curStyles);
				if (set1Font)
					{
					setFont = TRUE;
					if (s1p->type == FACESTYLE)
						{ /* check for change in super/sub state */
						ii = 0;
						if (curStyles[FACESTYLE] & SUPERSTYLE)
							ii--;
						if (curStyles[FACESTYLE] & SUBSTYLE)
							ii++;
						if (ii != *supersub)
							{ /* change in state */
							TUTORabs_move(0,(ii - *supersub)*txt_supsubH);
							*supersub = ii;
							}
						}
					}
				else if (s1p->type == COLORSTYLE)
					{
					if (curStyles[COLORSTYLE] != color_rgb)
					    CTset_foreground_color(curStyles[COLORSTYLE]);
					else
					    TUTORset_color(0,(struct tutorColor FAR *)&txtFgndColor);
					if (currentMode == SRC_BIC && backFillR.left > -10000)
						{ /* mode inverse, we need to refill background */
						/* note that TUTORdraw_doc changed mode from NOT_SRC_COPY
							to NOT_SRC_BIC.  When mode is erase, backFillR.left
							is -10000 */
						TUTORinq_abs_pen_pos(&newX,&newY);
						backFillR.left = newX;
						TUTORdraw_abs_solid_rect((TRect FAR *) &backFillR, PAT_BLACK);
						}
					}
				else if (s1p->type == PARASTYLE)
					{ /* get new paragraph layout */
						/* note that justification is handled by caller */
					ii = curStyles[PARASTYLE] & PARALMASK;
					if (ii == PARADEFAULT)
						ii = dp->defStyles[PARASTYLE] & PARALMASK;
					jj = pLay->leftMar + (pStart ? pLay->paraIndent : 0); /* old left margin */
					GetParaLayout(ii,pLay);
					/* now calculate offset due to change in paragraph layout */
					jj -= pLay->leftMar + (pStart ? pLay->paraIndent : 0);
					if (jj)
						TUTORabs_move(-jj,0); /* move pen to account for layout change */
					}
				s1p++;
				}
			if (setFont)
				_TUTORset_textfont_doc(dp,curStyles);
			if (s1p <= s1End)
				nextStylePos = s1p->pos;
			else
				nextStylePos = pos+len+10;
			}

		nc = ((nextStylePos < nextCharPos) ? nextStylePos : nextCharPos) - curPos;
		if (drawChar == 0) /* normal text */
			TUTORdraw_text(t0+(curPos-pos),nc);
		else if (drawChar == 1)
			{ /* shimmed space */
			TUTORdraw_text((unsigned char FAR *) " ",1);
			nBlanks++;
			curBlankP = (fracShim * nBlanks)>>16;
			if (curBlankP > lastBlankP)
				{ /* we need to do some shimming */
				TUTORabs_move(curBlankP - lastBlankP,0);
				lastBlankP = curBlankP;
				}
			}
		else if (drawChar == 2) /* tab */
			DrawTab(pLay,left,viewTab);
		else if (drawChar == 3) /* newline */
			{ /* we only get here if there are no styles on the text */
			if (needFill)
				{ /* fill in leading of last line drawn */
				TUTORinq_abs_pen_pos(&penX,&penY);
				tr.left = startH;
				tr.right = penX-1;
				tr.top = penY + descent;
				tr.bottom = tr.top + leading - 1;
				TUTORdraw_abs_solid_rect((TRect FAR *) &tr, -1);
				}
			curY += lineHeight;
			lineN++;
			if (maxH)
				{
				TUTORinq_abs_pen_pos(&newX,&newY);
				if (newX > *maxH)
					*maxH = newX;
				}
			startH = left+pLay->leftMar+pLay->paraIndent;
			TUTORabs_move_to(startH,curY);
			if (lineN >= maxLines)
				break;
			}
		else /* special text */
			{
			/* for now, we are assumming that we draw all special text at once,
				and that there are no style changes within a chunk of special text */
			TUTORdraw_stext(st1p);
			st1p++;
			if (st1p > st1End)
				nextSTextPos = pos+len+10;
			else
				nextSTextPos = st1p->pos;
			}
	
		curPos += nc;
		}
	
	if (maxH)
		{
		TUTORinq_abs_pen_pos(&newX,&newY);
		if (newX > *maxH)
			*maxH = newX;
		}
	
	if (sp)
		*styleInd = s1p - (Style1 SHUGE *) sp->styles;
	if (stp)
		*stind = st1p - (SText FAR *) stp->text;
	
	return 0;
	}

 /* skip styles in invisible region: */
static InvisibleSkip(dp,pos,len,pLay,sp,styleInd,curStyles,supersub,stp,stind)
DocP dp;	/* document we are working with */
long pos, len;	/* the region we are skipping thru */
ParagraphLayout *pLay;	/* current paragraph layout */
StyleDatP sp;	/* pointer to styles */
int *styleInd;	/* index of current style block */
short *curStyles;	/* array of current styles */
int *supersub;	/* super/subscript state */
SpecialTP stp;	/* pointer to special text info */
int *stind;		/* index of current special text block */
	{
	register Style1 SHUGE *s1p, SHUGE *s1End;	/* pointers to current & last style block */
	SText FAR *st1p, FAR *st1End;	/* pointers to current & last special text block */
	register int ii;
	register long end;	/* position of end of skip */
	
	end = pos + len;
	if (sp)
		{ /* keep styles current */
		s1p = ((Style1 SHUGE *) sp->styles) + *styleInd;
		s1End = ((Style1 SHUGE *) sp->styles) + (sp->sHead.dAnn - 1);
		while (s1p <= s1End && s1p->pos < end)
			{
			_TUTORset_curstyles_doc(dp,s1p,curStyles);
			s1p++;
			}
	
		/* make styles current */
		ii = curStyles[PARASTYLE] & PARALMASK;
		if (ii == PARADEFAULT)
			ii = dp->defStyles[PARASTYLE] & PARALMASK;
		GetParaLayout(ii,pLay);
		_TUTORset_textfont_doc(dp,curStyles);
		if (curStyles[COLORSTYLE] != color_rgb)
		    CTset_foreground_color(curStyles[COLORSTYLE]);
		else
		    TUTORset_color(0,(struct tutorColor FAR *)&txtFgndColor);
		*styleInd = s1p - (Style1 SHUGE *) sp->styles;
		*supersub = 0;
		if (curStyles[FACESTYLE] & SUPERSTYLE)
			(*supersub)--;
		if (curStyles[FACESTYLE] & SUBSTYLE)
			(*supersub)++;
		}
	
	if (stp)
		{ /* keep special text index current */
		st1p = ((SText FAR *) stp->text) + *stind;
		st1End = ((SText FAR *) stp->text) + (stp->head.dAnn - 1);
		while (st1p <= st1End && st1p->pos < end)
			st1p++;
		
		*stind = st1p - (SText FAR *) stp->text;
		}
	
	return(0);
	}


/* figure out how many characters fit per line: */
_TUTORlayout_lines(dp,pos,len,width,wordB,curX,sp,styleInd,liLay,curStyles,pLay,stp,stind)
register DocP dp;	/* document we are laying out */
long pos,len;	/* portion of document we are laying out */
int width;	/* the horizontal space we can use */
int wordB;	/* TRUE if lines can break on word boundaries */
int curX;	/* current position relative to left edge of layout */
StyleDatP sp;	/* pointer to styles */
int styleInd;	/* index of current style block */
register LineLayout FAR *liLay;	/* to be filled with the line layouts */
short *curStyles;	/* array of current styles */
ParagraphLayout *pLay;	/* current paragraph layout */
SpecialTP stp;	/* pointer to special text info */
int stind;	/* index of current special text block */
/* returns # of lines actually laid out */
	{
	int lineN;	/* line count (return value) */
	int spaceA;	/* space available */
	long curPos;	/* current position in doc */
	long curLen;	/* current amount left to be laid out */
	int maxA, maxD, maxL; /* maximum ascent, descent & leading for line */
	unsigned char FAR *tp;	/* pointer to relevant characters */
	int nBufferLines;	/* # of lines in the document text buffer */
	int bufferLoad;	/* TRUE if we need to worry about reloading the buffer */
	int wbf; /* word wrap flag for current line */
	register int ii;
	long tempL;
	
	if (pos + len > dp->totLen)
		len = dp->totLen-pos; /* force length legal */
		/* TUTORdump("Laying out too much in _TUTORlayout_lines"); */

	if (len == 0)
		return(0); /* nothing laid out (Note: if len is 0, liLay probably doesn't point
						at anything) */

	curPos = pos;
	curLen = len;
	lineN = 0;

	if (!dp->shortText && dp->buffEnd < pos+len)
		{ /* text isn't all in buffer, count # of lines in buffer */
		tp = ((unsigned char FAR *) dp->text) + (curPos - dp->buffStart);
		nBufferLines = TUTORcount_bytes(tp,((unsigned char FAR *) dp->text) + (dp->txtH.dAnn-1),NEWLINE);
		bufferLoad = TRUE; /* we will be changing buffer */
		}
	else
		{
		nBufferLines = 32767; /* infinity (close enough) */
		bufferLoad = FALSE;
		}
	
	/* set first paragraph data in liLay */
	liLay->justif = curStyles[PARASTYLE] & JUSTMASK;
	liLay->paraN = curStyles[PARASTYLE] & PARALMASK;
		
	while (curLen > 0)
		{
		/* take care of styles at start of line */
		/* note that before each line is laid out, the styles are set for the
				beginning of the line */
		if (curStyles[PARASTYLE] & VISMASK)
			{ /* we have invisible line */
			InvisibleLayout(dp,curPos,curLen,sp,&styleInd,liLay,curStyles,pLay,stp,&stind);
			tempL = curPos + liLay->nc; /* end of invis */
			if (bufferLoad && tempL < pos+len)
				{ /* worry about whether buffer is still valid */
				if (tempL > dp->buffEnd)
					nBufferLines = 0; /* we have run past buffer */
				else
					{ /* recount lines remaining in buffer */
					tp = ((unsigned char FAR *) dp->text) + (tempL - dp->buffStart);
					nBufferLines = TUTORcount_bytes(tp,((unsigned char FAR *) dp->text) + (dp->txtH.dAnn-1),NEWLINE);
					nBufferLines++; /* because of decrement below */
					}
				}
			}
		else
			{ /* visible line, normal case */
			TUTORinq_font_info(&maxA,&maxD,NEARNULL,&maxL);
			if ((maxA+maxD+maxL) < txt_newlineH)
				maxA += txt_newlineH-(maxA+maxD+maxL);
			AdjustHeight(curStyles[FACESTYLE],&maxD,&maxA);
			maxD += maxA+maxL; /* line height */
			liLay->lineAsc = maxA;
			liLay->lineHeight = maxD;
			liLay->justif = curStyles[PARASTYLE] & JUSTMASK;
			liLay->paraN = curStyles[PARASTYLE] & PARALMASK;
	/* supposed optimization removed as it is actually slower than
	the general case???   dma */	
	/*		if (!wordB && liLay->justif == LEFTJUST && !stp)
				TUTORline_layout0(dp,curPos,curLen,sp,&styleInd,liLay,curStyles,pLay);
			else  */
				{ /* non-left, or complicated, text */
				/* calculate possible paragraph indent offset */
				ii = (!lineN || (liLay-1)->endNewline) ? pLay->paraIndent : 0;
				spaceA = width - pLay->rightMar - (curX+pLay->leftMar+ii);
/* scroll-change */
				if (!wordB && (liLay->justif == LEFTJUST))
					wbf = 0; /* don't wrap if left justified */
				else wbf = 1; /* else wrap on word boundary */
				liLay->endNewline = TUTORline_layout(dp,curPos,curLen,ii,wbf,
						spaceA,sp,&styleInd,liLay,curStyles,pLay,stp,&stind);
				}
			if (liLay->nc <= 0)
				{ /* we insist that we get at least 1 char in line */
				liLay->nc = liLay->nDraw = 1;
				}
			} /* end of visible line */
		curLen -= liLay->nc;
		curPos += liLay->nc;
		curX = 0;
		liLay++;
		nBufferLines--;
		if (nBufferLines <= 0)
			{ /* we need to reload buffer */
			_TUTORload_buffer_doc(dp,curPos);
			/* count lines in this new buffer */
			tp = ((unsigned char FAR *) dp->text) + (curPos - dp->buffStart);
			nBufferLines = TUTORcount_bytes(tp,((unsigned char FAR *) dp->text) + (dp->txtH.dAnn-1),NEWLINE);
			}
		lineN++;
		if (lineN >= MAXLAYOUTLINES)
			break; /* we've laid out as much as is possible */
		}

	if (bufferLoad)
		{ /* get buffer back where it belongs */
		_TUTORload_buffer_doc(dp,pos);
		}
	
	return(lineN);
	}

static TUTORline_layout0(dp,pos,len,sp,styleInd,li,curStyles,pLay) /* simple line layout */
DocP dp;	/* document we are laying out */
long pos,len;	/* portion of document to be laid out */
StyleDatP sp;	/* pointer to styles */
int *styleInd; /* index of next style change */
register LineLayout FAR *li;	/* to be filled with line layouts */
short *curStyles; /* current styles (we only modify FONT, SIZE, FACE) */
ParagraphLayout *pLay;	/* current paragraph style */
/* returns FALSE if found a non-left justification */
	{
	register unsigned char FAR *tp;	/* pointer to current text */
	unsigned char FAR *te;	/* points just past end of text */
	unsigned char FAR *t0;	/* points to beginning of text */
	register Style1 SHUGE *s1p;	/* points to current style block */
	Style1 SHUGE *s1End;	/* points to last style block */
	long curPos;	/* our current position in document */
	int setFont;	/* TRUE if style change requires font change */
	int ii, jj;
	int asc, desc, lead;	/* font characteristics */
	int maxAsc, maxDL;	/* maximum ascent & descent+leading found */
	unsigned char scanS[2];	/* scan target */
	
	/* this routine handles left justified, newline broken, lines */
	
	/* if there are no styles, all we care about is finding the newline */
	/* if there are styles, we also have to calculate the lineHeight and ascent */
	
	/* don't look at more characters than there are in buffer */
	if (pos+len > dp->buffStart+dp->txtH.dAnn)
		len = dp->buffStart + dp->txtH.dAnn - pos;
	
	/* scan line for newline */
	tp = t0 = ((unsigned char FAR *) dp->text) + (pos - dp->buffStart);
	te = tp+len;	/* but don't go further than we've been asked */
	li->lastTab = -1; /* assumme that no tabs are found */
	scanS[0] = NEWLINE;
	scanS[1] = ' ';
	tp = TUTORscan_bytes(tp,te-1,scanS,1);
	if (!tp)
		{ /* didn't find NEWLINE */
		tp = te;
		li->endNewline = FALSE;
		}
	else
		{ /* NEWLINE is included in line */
		tp++;
		li->endNewline = TRUE;
		}
	li->nc = tp - t0;
	
	/* newlines at the end of the line aren't drawable */
	tp--; /* point at last character */
	li->nDraw = li->nc - (*tp == NEWLINE);
	
	/* find last tab */
	scanS[0] = '\t';
	tp = TUTORscan_bytes(tp,t0,scanS,1);
	if (tp)
		li->lastTab = (int) (tp - t0);
	
	if (!sp || *styleInd < 0)
		return(TRUE); /* we are all done */
	
	len = li->nc; /* actual # of chars in line */
	
	/* scan to calculate lineHeight & ascent */
	/* we assumme that li->lineHeight & li->lineAsc have correct current values */
	maxAsc = li->lineAsc;
	maxDL = li->lineHeight - li->lineAsc;
	
	s1p = ((Style1 SHUGE *) sp->styles) + *styleInd;
	s1End = ((Style1 SHUGE *) sp->styles) + (sp->sHead.dAnn -1); /* points at last style */
	curPos = s1p->pos; 

	while (s1p <= s1End && (s1p->pos <= pos+len))
		{
		setFont = FALSE;
		while (s1p <= s1End && s1p->pos == curPos)
			{
			setFont |= _TUTORset_curstyles_doc(dp,s1p,curStyles);
			if (s1p->type == PARASTYLE)
				{ /* this should only happen at the end of the line */
				ii = curStyles[PARASTYLE] & PARALMASK;
				if (ii == PARADEFAULT)
					ii = dp->defStyles[PARASTYLE] & PARALMASK;
				GetParaLayout(ii,pLay);
				}
			s1p++;
			}
		if (setFont)
			{ /* analyze new font */
			_TUTORset_textfont_doc(dp,curStyles);
			if ((curPos >= pos) && (curPos < pos+len))
				{ /* we only need to do this work when in our line */
				TUTORinq_font_info(&asc,&desc,NEARNULL,&lead);
				if ((asc+desc+lead) < txt_newlineH)
					asc += txt_newlineH-(asc+desc+lead);
				AdjustHeight(curStyles[FACESTYLE],&desc,&asc);
				if (asc > maxAsc)
					maxAsc = asc;
				if (desc+lead > maxDL)
					maxDL = desc + lead;
				}
			}
		if (s1p <= s1End)
			curPos = s1p->pos;
		}
	
	li->lineAsc = maxAsc;
	li->lineHeight = maxAsc + maxDL;
	
	return(TRUE);
	}

/* layout a complex line */
static TUTORline_layout(dp,pos,len,curX0,wordB,spaceA,sp,styleInd,li,curStyles,pLay,stp,stind) /* complete line layout */
DocP dp;	/* pointer to document we are laying out */
long pos,len;	/* portion of document being laid out */
int curX0;	/* current position, relative to tab origin */
int wordB; /* 1 if we can break due to length of line, 0 if we break only
			on NEWLINE, -1 if we can break on every char (special case for recursive call) */
int spaceA;	/* space available on line, used for word break & justification */
StyleDatP sp;	/* pointer to styles */
int *styleInd; /* index of next style change */
register LineLayout FAR *li;	/* to be filled with line layout */
short *curStyles; /* array of current styles */
ParagraphLayout *pLay;	/* current paragraph layout */
SpecialTP stp;	/* pointer to special text info */
int *stind;		/* index of next special text block */
/* returns TRUE if line ended on NEWLINE */
	{
	register unsigned char FAR *tp;	/* pointer to current text */
	unsigned char FAR *te;	/* just past end of relevant text */
	unsigned char FAR *t0;	/* pointer to char at pos */
	unsigned char FAR *oldTp;	/* used to remember a value of tp */
	unsigned char lastC;		/* last character seen, for word breaking */
	char justBroke;		/* TRUE if just found word-break boundary */
	long nextWordPos;	/* next position where there is a word boundary */
	long nextStylePos;	/* next position where we have style change */
	long nextSTextPos;	/* next position where there is special text */
	register Style1 SHUGE *s1p;	/* pointer to next style block */
	Style1 SHUGE *s1End;	/* pointer to last style block */
	Style1 SHUGE *oldS;	/* used to save state of s1p */
	long curPos;	/* current position */
	int nc;	/* # of characters to measure next */
	register int ii;
	int jj;
	int curX;		/* copy of curX0 */
	char setFont;	/* TRUE if font needs to be set (when we are looking at styles) */
	int asc, desc, lead;	/* font characteristics */
	int maxAscent, maxDL;	/* maximum font characteristics in this line */
	int oldAsc, oldDL;	/* copies of ascent & dl */
	int width, newW;	/* calculated width of line */
	int endNewline;		/* TRUE if line ends in newline */
	unsigned char scanS[2];
	short justif;	/* justification of the line */
	int measureType;	/* 0: normal chars, 1: a tab */
	SText FAR *st1p, FAR *st1End;	/* next & last special text blocks */
	SText FAR *oldSt;	/* used to save state of st1p */

	/* we will scan chars in chunks, each chunk delimited by either a style change
		or a possible word end (if wordB is TRUE).  We measure the line width,
		stopping & backing up if we have too much (if wordB is TRUE).  All through
		the scan we keep track of lineAsc & lineDescent as well as index
		of the last tab */

	/* don't look at more characters than there are in buffer */
	if (pos+len > dp->buffStart+dp->txtH.dAnn)
		len = dp->buffStart + dp->txtH.dAnn - pos;
	
	tp = ((unsigned char FAR *) dp->text) + (pos - dp->buffStart);
	t0 = tp;
	te = tp + len;
	justBroke = TRUE;	/* so we won't break right away */
	width = 0;	/* total space used so far */
	if (sp)
		{
		s1p = ((Style1 SHUGE *) sp->styles) + *styleInd; /* next style */
		s1End = ((Style1 SHUGE *) sp->styles) + (sp->sHead.dAnn-1); /* last style */
		nextStylePos = (s1p <= s1End) ? s1p->pos : pos+len+10;
		}
	else
		nextStylePos = pos+len+10; /* never get to a style change */
	
	if (stp)
		{
		st1p = ((SText FAR *) stp->text) + *stind; /* next special text */
		st1End = ((SText FAR *) stp->text) + (stp->head.dAnn-1); /* last stext */
		nextSTextPos = (st1p <= st1End) ? st1p->pos : pos+len+10;
		}
	else
		nextSTextPos = pos+len+10; /* never get to a special text */
	
	nextWordPos = curPos = pos;
	curX = curX0;
	li->lastTab = -1;	/* we haven't seen any tabs yet */
	
	maxAscent = li->lineAsc;
	maxDL = li->lineHeight - li->lineAsc;
	
	scanS[0] = '\t';
	scanS[1] = NEWLINE;
	while (curPos < pos+len)
		{
		if (curPos >= nextWordPos)
			{ /* scan chars for next character chunk */
			if (*tp == NEWLINE)
				break; /* we're done */
			
			/* remember current characteristics, in case we back up to here
				because the next word is too long to fit on the line */
			oldAsc = maxAscent;
			oldDL = maxDL;
			oldTp = tp;
			if (sp)
				oldS = s1p;
			if (stp)
				oldSt = st1p;
			
			if (stp && curPos >= nextSTextPos)
				{ /* next char is special text */
				measureType = 2; /* indicates special text */
				tp += st1p->len;
				}
			else if (*tp == '\t')
				{
				measureType = 1;
				tp++;
				}
			else
				{
				measureType = 0;
				if (!wordB)
					{ /* we only break lines on newlines */
					tp = TUTORscan_bytes(tp,te-1,scanS,2);
					if (!tp)
						tp = te;
					}
				else if (wordB == 1)
					{ /* can break on word break, too complicated for TUTORscan_bytes */
					while (tp < te)
						{
						if (*tp == '\t' || *tp == NEWLINE)
							break;
						else
							{ /* check for possible break on word boundary */
							if (!justBroke && WordBreakLine(lastC,*tp))
								{
								justBroke = TRUE;
								break;
								}
							else
								justBroke = FALSE;
							lastC = *tp;
							}
						tp++;
						}
					}
				else
					{ /* can break on every char */
					tp++;
					}
				}
			if (tp - t0 > 32767)
				tp = t0+32767; /* don't try to put too many chars on a line */
			nextWordPos = (tp - t0) + pos;
			if (stp && measureType != 2 && nextWordPos > nextSTextPos)
				{ /* we don't want to attempt to measure over special text chars */
				tp -= (nextWordPos - nextSTextPos);
				nextWordPos = nextSTextPos;
				}
			}
		
		if (curPos == nextStylePos)
			{ /* process all styles at this position */
			setFont = FALSE;
			while (s1p <= s1End && s1p->pos == nextStylePos)
				{
				setFont |= _TUTORset_curstyles_doc(dp,s1p,curStyles);
				s1p++;
				}
			nextStylePos = (s1p <= s1End) ? s1p->pos : pos+len+10;
			if (setFont)
				{
				_TUTORset_textfont_doc(dp,curStyles);
				TUTORinq_font_info(&asc,&desc,NEARNULL,&lead);
				if ((asc+desc+lead) < txt_newlineH)
					asc += txt_newlineH-(asc+desc+lead);
				AdjustHeight(curStyles[FACESTYLE],&desc,&asc);
				if (asc > maxAscent)
					maxAscent = asc;
				if (desc+lead > maxDL)
					maxDL = desc + lead;
				}
			}
		
		/* measure next piece */
		if (measureType == 0)
			{ /* normal text */
			if (nextStylePos > curPos) /* dma kludge */
				nc = ((nextStylePos > nextWordPos) ? nextWordPos : nextStylePos) - curPos;
			else nc = nextWordPos-curPos;
			TUTORinq_abs_string_width(t0+(curPos-pos),nc,&newW);
			}
		else if (measureType == 1)
			{ /* tab */
			nc = 1;
			newW = _TUTORtab_width_doc(pLay,curX);
			li->lastTab = curPos - pos;
			}
		else /* special text */
			{ /* we are going to force all of special text into 1 chunk... */
			nc = st1p->len;
			newW = TUTORmeasure_stext(st1p,&asc,&desc,&lead);
			if ((asc+desc+lead) < txt_newlineH)
				asc += txt_newlineH-(asc+desc+lead);
			AdjustHeight(curStyles[FACESTYLE],&desc,&asc);
			if (asc > maxAscent)
				maxAscent = asc;
			if (desc + lead > maxDL)
				maxDL = desc + lead;
			
			st1p++;
			if (st1p <= st1End)
				nextSTextPos = st1p->pos;
			else
				nextSTextPos = pos+len+10;
			}
		curX += newW;
		width += newW;
		curPos += nc;

		if (wordB && width > spaceA)
			{ /* we've put too much stuff on this line */
			if (wordB == 1 || oldTp != t0)
				{ /* restore values from the beginning of the last "word" */
				maxAscent = oldAsc;
				maxDL = oldDL;
				tp = oldTp;
				
				if (sp)
					{ /* restore styles */
					s1p = oldS;
					_TUTORget_styles_doc(dp,(s1p-1)->pos,curStyles); /* restore curStyles */
							/* note that since there was some text on this line (oldTp != t0)
								we can't be at document start, so s1p-1 is valid */
					_TUTORset_textfont_doc(dp,curStyles);
					}
				st1p = oldSt;
				
				width -= newW;
				
				if (wordB == 1 && oldTp == t0)
					{ /* first real word was too long.  Do recursive call with breaking
							on every character to properly lay out line */
					if (sp)
						*styleInd = s1p - (Style1 SHUGE *) sp->styles;
					if (stp)
						*stind = st1p - (SText FAR *) stp->text;
					return(TUTORline_layout(dp,pos,len,curX,-1,spaceA,sp,styleInd,li,
								curStyles,pLay,stp,stind));
					}
				}
			/* else first char is too long, just leave it */
			
			/* note that curPos is no longer valid (as well as other things, probably) */
			break;
			}
		}
	
	/* figure out the number of characters in line, and the # of drawable characters */
	if (tp < te)
		endNewline = (*tp == NEWLINE);
	else
		endNewline = FALSE; /* we ended because we went through all the characters */

	justif = curStyles[PARASTYLE] & JUSTMASK;
	if (justif == FULLJUST && (endNewline || tp >= te))
		justif = LEFTJUST; /* last line of fulljust paragraph is left-justified */

	if (endNewline)
		{ /* broke on NEWLINE */
		li->nc = (tp - t0) + 1; /* include NEWLINE */
		if (justif != LEFTJUST)
			{ /* spaces at end aren't drawable */
			oldTp = tp;	/* in case we need it later */
			/* we need to back up over spaces to find # drawable */
			te = t0;
			while (tp > te && *(tp-1) == ' ')
				tp--;
			if (tp > te)
				li->nDraw = tp - t0;
			else
				li->nDraw = oldTp - t0; /* line is all spaces so the spaces are drawable */
			}
		else
			{ /* left-justified, don't draw NEWLINE */
			li->nDraw = li->nc-1;
			}
		}
	else
		{ /* we broke because we ran out of space, or out of doc */
		li->nDraw = tp - t0;
		/* scan forward over spaces to include them in line */
		/* note that this means we will ignore ascent/lineheight changes due to
			super/subscript on these non-drawn spaces, although if line is broken by
			NEWLINE we don't ignore them.  Probably not a problem */
		while (tp < te && *tp == ' ')
			tp++;
		if (tp < te && *tp == NEWLINE)
			{
			tp++; /* also include newline if we happened to get it */
			endNewline = TRUE; /* we broke on a newline after all */
			}
		li->nc = tp - t0;
		if (justif == LEFTJUST)
			li->nDraw = li->nc - (endNewline ? 1 : 0); /* include spaces in drawables */
		}
	
	li->fracShim = 0;
	if (justif == LEFTJUST)
		li->justWidth = 0;
	else if (justif == RIGHTJUST)
		li->justWidth = spaceA - width;
	else if (justif == CENTERJUST)
		li->justWidth = (spaceA - width)/2;
	else
		{ /* full justification */
		li->justWidth = 0;
		/* count the spaces after the last tab */
		tp = t0 + ((li->lastTab >= 0) ? li->lastTab : 0);
		nc = TUTORcount_bytes(tp,t0+li->nDraw-1,' ');
		if (nc > 0)
			{
			li->fracShim = (((long) (spaceA - width)) << 16) / nc;
			li->fracShim += nc - 1; /* to compensate for roundoff */
			}
		/* else nothing to shim so fracShim left as 0 */
		}
	
	li->lineAsc = maxAscent;
	li->lineHeight = maxAscent + maxDL;
	
	if (sp)
		{
		/* process the styles that start the next line */
		setFont = FALSE;
		while (s1p <= s1End && s1p->pos <= (pos + li->nc))
			{
			setFont |= _TUTORset_curstyles_doc(dp,s1p,curStyles);
			if (s1p->type == PARASTYLE)
				{
				ii = curStyles[PARASTYLE] & PARALMASK;
				if (ii == PARADEFAULT)
					ii = dp->defStyles[PARASTYLE] & PARALMASK;
				GetParaLayout(ii,pLay);
				}
			s1p++;
			}
		if (setFont)
			_TUTORset_textfont_doc(dp,curStyles);
	
		/* make styleInd indicate the next style */
		if (sp)
			*styleInd = s1p - (Style1 SHUGE *) sp->styles;
		}
	
	if (stp) /* make stind indicate the next special style */
		*stind = st1p - (SText FAR *) stp->text;

	return(endNewline);
	}

/* do layout of chunk of document that is invisible: */
static InvisibleLayout(dp,pos,len,sp,styleInd,li,curStyles,pLay,stp,stind)
DocP dp;	/* pointer to document */
long pos,len;	/* position where invisibility starts, and maximum length */
StyleDatP sp;	/* pointer to styles */
int *styleInd;	/* index of next style to look at */
register LineLayout FAR *li;	/* to be filled with invisible line layout */
short *curStyles;	/* to be updated to styles at end of invis */
ParagraphLayout *pLay;	/* to be updated to layout at end of invis */
SpecialTP stp;	/* pointer to special text info */
int *stind;	/* index of next special text block */
	{
	register Style1 SHUGE *s1p, SHUGE *s1End;	/* current & last style blocks */
	int ii;
	long finalPos;	/* position at which we find visible style */
	char foundVis;	/* set to true when we find visible style */
	SText FAR *st1p, FAR *st1End;	/* current & last special text blocks */
	
	li->lineAsc = 0; /* indicates invisible line */
	li->nDraw = 0;
	li->lineHeight = INVISLINEH;
	li->endNewline = TRUE; /* invisible style always ends on newline or end
								of document */

	if (!sp)
		{ /* must be that the rest of the document is invisible */
		li->nc = len;
		return(0);
		}
	
	s1p = ((Style1 SHUGE *) sp->styles) + *styleInd;
	s1End = ((Style1 SHUGE *) sp->styles) + (sp->sHead.dAnn - 1);
	foundVis = FALSE;
	while (s1p <= s1End && s1p->pos < pos+len)
		{ /* scan till we find end of invisibility */
		_TUTORset_curstyles_doc(dp,s1p,curStyles);
		if (s1p->type == PARASTYLE && !(s1p->dat & VISMASK))
			{ /* found visible style, process styles at this position */
			foundVis = TRUE;
			li->nc = s1p->pos - pos;
			finalPos = s1p->pos;
			s1p++; /* since we've already taken care of paragraph style */
			while (s1p <= s1End && s1p->pos == finalPos)
				{
				_TUTORset_curstyles_doc(dp,s1p,curStyles);
				s1p++;
				}
			break; /* we're done */
			}
		s1p++;
		}
	
	if (!foundVis)
		{ /* we ran thru all styles without finding visible, rest of doc must be invis */
		li->nc = len;
		}

	/* make styles current */
	ii = curStyles[PARASTYLE] & PARALMASK;
	if (ii == PARADEFAULT)
		ii = dp->defStyles[PARASTYLE] & PARALMASK;
	GetParaLayout(ii,pLay);
	_TUTORset_textfont_doc(dp,curStyles);
	
	*styleInd = s1p - (Style1 SHUGE *) sp->styles;
	
	if (stp)
		{ /* keep special text index current */
		st1p = ((SText FAR *) stp->text) + *stind;
		st1End = ((SText FAR *) stp->text) + (stp->head.dAnn - 1);
		while (st1p <= st1End && st1p->pos < pos+len)
			st1p++;
		
		*stind = st1p - (SText FAR *) stp->text;
		}
	
	return(0);
	}

static WordBreakLine(c0,c1)		/* word break for line wrap */
register int c0; /* previous character */
register int c1; /* current character */
	{
	if (c0 == ' ')
		return(FALSE); /* always aglommerate leading spaces */
	if (c1 == ' ')
		return(TRUE); /* break when we first encounter spaces */
	if (c0 == '-' && CTisalpha(c1))
		return(TRUE); /* so "aa-bb" is broken after -, but "-99" doesn't get broken */
	return(FALSE); /* all other cases are left together */
	}

static DrawTab(pLay,left,viewTab) /* draw a tab */
register ParagraphLayout *pLay;	/* current paragraph layout */
int left; /* left edge of paragraph layout */
int viewTab; /* tab size from view (-1 = use size from document layout) */
	{
	register short nPassed;	/* # of tab stops already passed */
	int penH, penV;	/* current pen position */
	unsigned char cc;	/* character to be drawn */
	int tabSize; /* tab size used */

	if (viewTab < 0)
		tabSize = pLay->tabSize; /* use tab size from document */
	else
		tabSize = viewTab; /* use tab size from view */
	if (tabSize > 0)
		{
		TUTORinq_abs_pen_pos(&penH,&penV);
		penH -= (left + pLay->leftMar); /* adjust for tab origin */
		nPassed = penH/tabSize;
		TUTORabs_move((nPassed+1)*tabSize - penH,0);
		}
	else
		{ /* draw space instead of tab */
		cc = ' ';
		TUTORdraw_text(&cc,1);
		}
	}

_TUTORtab_width_doc(pLay,curX)	/* measure a tab's width */
register ParagraphLayout *pLay;	/* current paragraph layout */
int curX;	/* where we are in line, relative to tab origin */
	{
	unsigned char ss[2];	/* used to ask for width of space */
	int nPassed;	/* # of tab stops already passed */
	int sWidth;	/* width of space */
	int tabSize;
	
	if (CurrentView && (CurrentView->tabSize >= 0))
		tabSize = CurrentView->tabSize;
	else tabSize = pLay->tabSize;
	if (tabSize > 0)
		{
		nPassed = curX/tabSize;
		return((nPassed+1)*tabSize - curX);
		}
	else
		{ /* no tab stops, let tab be same as space */
		ss[0] = ' ';
		TUTORinq_abs_string_width((unsigned char FAR *) ss,1,&sWidth);
		return(sWidth);
		}
	}

/* adjust ascent & descent for super/subscripts */
static AdjustHeight(faceS,desc,asc)
register int faceS;	/* current face style */
int *desc;	/* line descent to be adjusted */
int *asc;		/* line ascent to be adjusted */
	{
	if (SupSubOff)
		return(0);
	if (faceS & SUPERSTYLE && !(faceS & SUBSTYLE))
		*asc += txt_supsubH; /* superscript adjustment */
	else if ((faceS & SUBSTYLE) && !(faceS & SUPERSTYLE))
		*desc += txt_supsubH; /* subscript adjustment */
	
	return(0);
	}

/* general routine for starting scan thru document */
_TUTORsetup_layout(dp,pos,len,styleInd,styleP,curStyles,pLay,stind,stp,fillDef)
register DocP dp;	/* pointer to document */
long pos, len;	/* the region of the document that will be looked at */
int *styleInd;	/* to be set to index of next style block */
REGISTER StyleDatP *styleP; /* if *styleP is returned != FARNULL, styles are locked! */
short *curStyles;	/* array to be filled with the current styles */
ParagraphLayout *pLay;	/* to be set to current paragraph layout */
int *stind;	/* index of next special text */
SpecialTP *stp;	/* set to point at LOCKED special text handle */
int fillDef;	/* TRUE if want defaults filled with defStyles from doc */
	{
	register int ii;
	
	if (dp->styles)
		{ /* we need to find what the current styles are */
		if (fillDef)
			*styleInd = _TUTORget_styles_doc(dp,pos,curStyles);
		else
			*styleInd = AtTStyle(dp->styles, pos, curStyles);
		if (*styleInd == -1)
			*styleP = FARNULL; /* no more styles */
		else
			{ /* there are style changes in the doc after pos */
			*styleP = (StyleDatP) GetPtr(dp->styles);
			if ((*styleP)->styles[*styleInd].pos >= pos+len)
				{ /* no style change in range of draw */
				*styleP = FARNULL;
				ReleasePtr(dp->styles);
				}
			}
		}
	else
		{ /* use defaults */
		for (ii=0; ii<NSTYLES; ii++)
			curStyles[ii] = fillDef ? dp->defStyles[ii] : DEFSTYLE;
		curStyles[SIZESTYLE] = DEFSTYLE; /* size style is relative... */
		*styleP = FARNULL;
		}
	
	if (pLay)
		{ /* fill out paragraph style */
		/* fillDef should be TRUE, or else we might take DEFSTYLE & PARALMASK (which is wrong) */
		ii = curStyles[PARASTYLE] & PARALMASK;
		if (ii == PARADEFAULT)
			ii = dp->defStyles[PARASTYLE] & PARALMASK;
		GetParaLayout(ii,pLay);
		}
	
	if (dp->specialT)
		{ /* figure out the current special text */
		*stp = (SpecialTP) GetPtr(dp->specialT);
		*stind = TUTORfind_stext(*stp,pos);
		if (*stind == -1 || (*stp)->text[*stind].pos >= pos+len)
			{ /* no special text in our area */
			ReleasePtr(dp->specialT);
			KillPtr(*stp);
			*stp = FARNULL;
			}
		}
	else
		*stp = FARNULL;
	
	return(0);
	}

_TUTORget_styles_doc(dp,pos,curStyles) /* get styles from document */
register DocP dp;	/* pointer to document */
long pos;	/* position where we want styles */
register short *curStyles; /* assummed of length NSTYLES! */
/* returns index of next style, or -1 if none */
	{
	int nextStyle;	/* index of next style (return value) */
	register int ii;
	
	if (dp->styles)
		{
		nextStyle = AtTStyle(dp->styles, pos, curStyles); /* get styles at pos */
		/* now convert default styles */
		for (ii=0; ii<NSTYLES; ii++)
			if (curStyles[ii] == DEFSTYLE && ii != SIZESTYLE)
				curStyles[ii] = dp->defStyles[ii];
		}
	else
		{
		nextStyle = -1;
		for (ii=0; ii<NSTYLES; ii++)
			curStyles[ii] = dp->defStyles[ii];
		curStyles[SIZESTYLE] = DEFSTYLE;
		}
	
	return(nextStyle);
	}

_TUTORset_textfont_doc(dp,curStyles) /* set font based on styles */
register DocP dp;	/* pointer to document */
register short *curStyles;	/* current styles */
	{
	int fSize;	/* the actual font size desired */
	
	/* convert font size from relative to absolute */
	fSize = TUTORcvt_text_size(curStyles[FONTSTYLE],dp->defStyles[SIZESTYLE],
				curStyles[SIZESTYLE]);
	
	/* set the font */
	TUTORset_textfont2((long)curStyles[FONTSTYLE],fSize,curStyles[FACESTYLE]);
	}

_TUTORset_curstyles_doc(dp,s1p,curStyles) /* modify curStyles array */
register DocP dp;	/* pointer to document */
register Style1 SHUGE *s1p;	/* pointer to style block to be processed */
register short *curStyles;	/* array of current styles to be modified */
/* returns TRUE if type was FONTSTYLE, SIZESTYLE or FACESTYLE (want to reset font) */
	{
	if (s1p->dat == DEFSTYLE && s1p->type != SIZESTYLE)
		curStyles[s1p->type] = dp->defStyles[s1p->type];
	else
		{
		if (s1p->type == PARASTYLE && (s1p->dat & PARALMASK) == PARADEFAULT)
			curStyles[PARASTYLE] = (dp->defStyles[PARASTYLE] & PARALMASK) | (s1p->dat & (JUSTMASK | VISMASK));
		else
			curStyles[s1p->type] = s1p->dat;					
		}
	
	return(s1p->type == FONTSTYLE || s1p->type == SIZESTYLE || s1p->type == FACESTYLE);
	}

int TUTORset_sub_new(supsubH,newlineH) /* set newline/subscript values */
int supsubH; /* superscript/subscript height */
int newlineH; /* newline height */

{
	if (supsubH < 0)
		supsubH = DEFSUPERSUB;
	txt_supsubH = supsubH;
	txt_newlineH = newlineH;
	if (CurrentView) {
		CurrentView->SupSub = supsubH;
		CurrentView->newlineH = newlineH;
	}
	return(0);
	
} /* TUTORset_sub_new */

	
