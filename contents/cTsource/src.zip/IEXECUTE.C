/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* initializations for executor */

#include <stdio.h>
#include "yacc.h"
#include "compute.h"  
#include "tglobals.h"
#include "eglobals.h"
#include "tfiledef.h"
#include "commands.h"  /* for CURSOR and PATTERN defs */
#include "exprdefs.h"
#include "ecglobal.h"

#ifdef THINKC5
#define ANYARGS ...
#else
#define ANYARGS
#endif

#ifdef ctproto
int  TUTORflush(void);
int  TUTORdelete_menu(unsigned int  barh,char  *card,char  *item);
extern int iexec_option_menu(void);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
int  initexec0(void);
int  initexecw(void);
int  initexec(void);
int  exec_iprocs(void);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
int  TUTORset_view(struct  tutorview FAR *vp);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  procexecwstub(unsigned int  wh,struct  tutorevent *event);
struct  tutorview FAR *TUTORinit_view(int  sW,unsigned int  vDat,int  (*vProc)());
int  procexecstub(unsigned int  viewH,struct  tutorevent *event);
int  TUTORnormal_cursor(void);
int  TUTORset_event_mask(int  eventc,int  value);
int  TUTORadd_menu(unsigned int  barh,char  *card,int  cp,char  *item,int  ip,int  keyBind,int  type,int  unit,double  unitArg,int  eType);
int  TUTORset_menubar(unsigned int  barh,struct  tutorview FAR *newMenuView);
unsigned int  TUTORinit_menubar(int  nItems);
int  sync(void);
int  TUTORset_program_name(char  *pname);
int  TUTORcreate_window(int  top,int  left,int  xSize,int  ySize,int  type);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
extern int TUTORzero(char SHUGE *ptr,long lth);
extern int FAR *InitMIDITab(void);
int cmd_alloc(void);
int  cmd_rvector(void);
int  cmd_ratnm(void);
int  cmd_gatnm(void);
int  cmd_rat(void);
int  cmd_gat(void);
int  cmd_gcircleb(void);
int  cmd_gcircle(void);
int  cmd_rcircleb(void);
int  cmd_rcircle(void);
int  cmd_gerase(void);
int  cmd_rerase(void);
int  cmd_gfill(void);
int  cmd_rfill(void);
int  cmd_gorigin(void);
int  cmd_rorigin(void);
int  cmd_vector(void);
int  cmd_box(void);
int  cmd_circleb(void);
int  cmd_circle(void);
int  cmd_erasep(void);
int  cmd_erase(void);
int  cmd_fill(void);
int  cmd_gdraw(void);
int  cmd_gdot(void);
int  cmd_rdraw(void);
int  cmd_rdot(void);
int  cmd_draw(void);
int  cmd_dot(void);
int  cmd_atnm(void);
int  cmd_at(void);
int  cmd_gethsv(void);
int  cmd_getrgb(void);
int  cmd_hsv(void);
int  cmd_rgb(void);
int  cmd_newpal(void);
int  cmd_palette(void); 
int cmd_fpalette(void);
int cmd_webpal(void);
int  cmd_coarse(void);
int  cmd_rescale(void);
int  cmd_fine(void);
int  cmd_branchf(void);
int  cmd_brancht(void);
int  cmd_branch(void);
int  ex_nofun(void);
int  TriggerEvent(int  (*routine)());
int  Run(void);
int  ReleaseStack(void);
unsigned char SHUGE *LockStack(void);
int  StopProgram(char  *s);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  cmd_showb(void);
int  cmd_showo(void);
int  cmd_showh(void);
int  cmd_showt(void);
int  cmd_show(void);
int cmd_showe(void);
int cmd_showz(void);
int  cmd_wrapstyle(void);
int  cmd_write(void);
int  cmd_endtext(void);
int  cmd_begintext(void);
int  cmd_disable(void);
int  cmd_enable(void);
int  cmd_nocmd(void);
int  cmd_okcmd(void);
int  cmd_vshow(void);
int  cmd_vplay(void);
int  cmd_vstep(void);
int  cmd_vset(void);
int  cmd_video(void);   
int cmd_vclose(void);
int cmd_sticky(void);
int cmd_vwait(void);
int  cmd_sound(void);
int cmd_pict(void);
int cmd_dma(void);
int cmd_sysinfo(void);
int cmd_dialog(void);
int cmd_print(void);
int cmd_step(void);
int cmd_stepover(void);
int  cmd_mode(void);
int  cmd_judge(void);
int  cmd_specs(void);
int  cmd_allow(void);
int  cmd_inhibit(void);
int  cmd_randu(void);
int  cmd_focus(void);
int  cmd_getkey(void);
int  cmd_clrkey(void);
int  cmd_press(void);
int  cmd_gclip(void);
int  cmd_rclip(void);
int  cmd_clip(void);
int  cmd_gdisk(void);
int  cmd_rdisk(void);
int  cmd_disk(void);
int  cmd_rotate(void);
int cmd_thick(void);
int  cmd_size(void);
int  cmd_polar(void);
int  cmd_delta(void);
int  cmd_marky(void);
int  cmd_markx(void);
int  cmd_labely(void);
int  cmd_labelx(void);
int  cmd_lscaley(void);
int  cmd_lscalex(void);
int  cmd_scaley(void);
int  cmd_scalex(void);
int  cmd_bounds(void);
int  cmd_axes(void);
int  cmd_vbar(void);
int  cmd_hbar(void);
int  cmd_gbox(void);
int  cmd_rbox(void);
int  cmd_gmove(void);
int  cmd_rmove(void);
int  cmd_move(void);
int  cmd_gvector(void);
int  cmd_clause(void);
int  cmd_casem(void);
int  cmd_caset(void);
int  cmd_case(void);
int  cmd_condout(void);
int  cmd_cond(void);
int  cmd_execute(void);
int  cmd_pause(void);
int  cmd_markpt(void);
int  cmd_compute(void);
int  cmd_beep(void);
int  cmd_serial(void);
int  cmd_setc(void);
int  cmd_set(void);
int  cmd_zerom(void);
int cmd_block(void);
int  cmd_zero(void);
int cmd_dde(void);
int  cmd_getserv(void);
int  cmd_server(void);
int  cmd_socket(void);
int cmd_sockwait(void);
int  cmd_readln(void);
int  cmd_numout(void);
int  cmd_xout(void);
int  cmd_xin(void);
int  cmd_dataout(void);
int  cmd_datain(void);
int  cmd_reset(void);
int  cmd_delfile(void);
int  cmd_setfile(void);
int  cmd_addfile(void);
int cmd_setdir(void);
int cmd_adddir(void);
int cmd_deldir(void);
int cmd_getdir(void);
int cmd_style(void);
int  cmd_cursor(void);
int  cmd_pattern(void);
int  cmd_icons(void);
int  cmd_font(void);
int cmd_fontp(void);
int cmd_newline(void);
int cmd_supsub(void);
int cmd_cancel(void);
int cmd_forget(void);
int  cmd_wcolor(void);
int cmd_wtitle(void);
int  cmd_color(void);
int  cmd_menu(void);
int  cmd_wrongv(void);
int  cmd_ansv(void);
int  cmd_wrong(void);
int  cmd_answer(void);
int  cmd_exactw(void);
int  cmd_exact(void);
int  cmd_begintext4(void);
int  cmd_begintext3(void);
int  cmd_endtext2(void);
int  cmd_begintext2(void);
int  cmd_write2(void);
int  cmd_write1(void);
int  cmd_endtext1(void);
int  cmd_begintext1(void);
int  cmd_replace(void);
int  cmd_append(void);
int  cmd_string(void);
int  cmd_gtext(void);
int  cmd_rtext(void);
int  cmd_text(void);
int cmd_textm(void);
int cmd_rtextm(void);
int cmd_gtextm(void);
int  cmd_plot(void);
int cmd_ploti(void);
int  cmd_touch(void);
int  cmd_gslider(void);
int  cmd_rslider(void);
int  cmd_slider(void);
int  cmd_gbutton(void);
int  cmd_rbutton(void);
int  cmd_button(void);
int  cmd_gedit(void);
int  cmd_redit(void);
int  cmd_edit(void);
int  cmd_gsliderr(void);
int  cmd_rsliderr(void);
int  cmd_sliderr(void);
int  cmd_gbuttonr(void);
int  cmd_rbuttonr(void);
int  cmd_buttonr(void);
int  cmd_geditr(void);
int  cmd_reditr(void);
int  cmd_editr(void);
int  cmd_gput(void);
int  cmd_gget(void);
int  cmd_rput(void);
int  cmd_rget(void);
int  cmd_put(void);
int  cmd_get(void);
int  cmd_slice(void);
int  cmd_null(void);
int  cmd_cmds(void);
int  cmd_dmp(void);
int  cmd_endans(void);
int  cmd_preans(void);
int  cmd_endarrow(void);
int  cmd_ifmatch(void);
int  cmd_garrow(void);
int  cmd_rarrow(void);
int  cmd_arrow3(void);
int  cmd_arrow2(void);
int  cmd_arrow1(void);
int  cmd_arrow(void);
int  cmd_jumpout(void);
int  cmd_outunit(void);
int  cmd_back(void);
int  cmd_next(void);
int  cmd_finishu(void);
int  cmd_reshape(void);
int  cmd_eraseu(void);
int  cmd_iarrow(void);
int  cmd_ijudge(void);
int  cmd_imain(void);
int cmd_objw(void);
int  cmd_jump(void);
int  cmd_do(void);
int  cmd_endunit(void);
int  cmd_svers(void);
int  cmd_floopinc(void);
int  cmd_floopinit(void);
int  cmd_iloopinc(void);
int  cmd_iloop1(void);
int  cmd_icloopinit(void);
int  cmd_iloop1init(void);
int  cmd_iloopinit(void);
int  cmd_calc(void);
int  cmd_endcase(void);
int ex_gdyarrayval(void);
int exs_gdyarrayval(void);
int ex_gdyarrayaddr(void);
int exs_gdyarrayaddr(void);
int ex_igdyarrayval(void);
int exs_igdyarrayval(void);
int ex_igdyarrayaddr(void);
int exs_igdyarrayaddr(void); 
int ex_bgdyarrayval(void);
int exs_bgdyarrayval(void);
int ex_gdyarray(void);
int exs_gdyarray(void);

int ex_ldyarrayval(void);
int exs_ldyarrayval(void);
int ex_ldyarrayaddr(void);
int exs_ldyarrayaddr(void);
int ex_ildyarrayval(void);
int exs_ildyarrayval(void);
int ex_ildyarrayaddr(void);
int exs_ildyarrayaddr(void); 
int ex_bldyarrayval(void);
int exs_bldyarrayval(void);
int ex_ldyarray(void);
int exs_ldyarray(void);

int ex_pdyarrayval(void);
int exs_pdyarrayval(void);
int ex_pdyarrayaddr(void);
int exs_pdyarrayaddr(void);
int ex_ipdyarrayval(void);
int exs_ipdyarrayval(void);
int ex_ipdyarrayaddr(void);
int exs_ipdyarrayaddr(void); 
int ex_bpdyarrayval(void);
int exs_bpdyarrayval(void);
int ex_pdyarray(void);
int pdy_array_inf(void);

int  ex_passval(void);
int  ex_mlarrayaddr(void);
int  ex_blarrayaddr(void);
int  ex_ilarrayaddr(void);
int  ex_larrayaddr(void);
int  ex_mlarrayval(void);
int  ex_blarrayval(void);
int  ex_ilarrayval(void);
int  ex_larrayval(void);
int  ex_localaddr(void);
int  ex_mlocalval(void);
int  ex_blocalval(void);
int  ex_ilocalval(void);
int  ex_localval(void);
int  ex_mgarrayaddr(void);
int  ex_bgarrayaddr(void);
int  ex_igarrayaddr(void);
int  ex_garrayaddr(void);
int  ex_mgarrayval(void);
int  ex_bgarrayval(void);
int  ex_igarrayval(void);
int  ex_garrayval(void);
int  ex_globaladdr(void);
int  ex_mglobalval(void);
int  ex_bglobalval(void);
int  ex_iglobalval(void);
int  ex_globalval(void);
int  ex_xparray(void);
int  ex_iparrayval(void);
int  ex_ipassval(void);
int  ex_mlitc(void);
int  ex_mliteral(void);
int  ex_fliteral(void);
int  ex_iliteral(void);
int  ex_ftoc(void);
int  ex_itoc(void);
int  ex_val(void);
int  ex_zxyg(void);
int  ex_zxyr(void);
int  ex_zxya(void);
int  ex_zxyi(void);
int  ex_cotofn(void);
int  cmd_gtouch(void);
int  cmd_rtouch(void);
int  ex_exponic(void);
int  ex_mod(void);
int  ex_or(void);
int  ex_and(void);
int  ex_not(void);
int  ex_munit(void);
int  ex_ftoi(void);
int  ex_itof(void);
int  ex_rshift(void);
int  ex_lshift(void);
int  ex_ldiff(void);
int  ex_lmask(void);
int  ex_lunion(void);
int  ex_idivt(void);
int  ex_idivr(void);
int  ex_divide(void);
int  ex_itimes(void);
int  ex_times(void);
int  ex_iuminus(void);
int  ex_uminus(void);
int  ex_idec(void);
int  ex_iminus(void);
int  ex_minus(void);
int  ex_iinc(void);
int  ex_iplus(void);
int  ex_plus(void);
int  ex_massign(void);
int  ex_bassign(void);
int  ex_iassign(void);
int  ex_assign(void);
int  ex_mparray(void);
int  ex_bparray(void);
int  ex_iparray(void);
int  ex_parray(void);
int  ex_larray(void);
int  ex_garray(void);
int  ex_mparrayaddr(void);
int  ex_bparrayaddr(void);
int  ex_iparrayaddr(void);
int  ex_parrayaddr(void);
int  ex_mparrayval(void);
int  ex_bparrayval(void);
int  ex_parrayval(void);
int  ex_mpassaddr(void);
int  ex_bpassaddr(void);
int  ex_ipassaddr(void);
int  ex_passaddr(void);
int  ex_mpassval(void);
int  ex_bpassval(void);
int  ex_ige(void);
int  ex_ile(void);
int  ex_igt(void);
int  ex_ilt(void);
int  ex_spne(void);
int  ex_speq(void);
int  ex_spge(void);
int  ex_sple(void);
int  ex_spgt(void);
int  ex_splt(void);
int  ex_ne(void);
int  ex_eq(void);
int  ex_ge(void);
int  ex_le(void);
int  ex_gt(void);
int  ex_lt(void);
int  ex_znextword(void);
int ex_znextexpr(void);
int ex_znextnum(void);
int ex_zfilename(void);
int ex_zfilepath(void);
int ex_znicons(void);
int ex_znextline(void);
int  ex_zks(void);
int  ex_zvalues(void);
int  ex_zvalueb(void);
int  ex_zhotsel(void);
int  ex_zhotinfoe(void);
int ex_zhotinfom(void);
int ex_zddetext(void);
int ex_zswidth(void);
int ex_zsheight(void);
int  ex_zeditbase(void);
int  ex_ztextvis(void);
int  ex_ztextsel(void);
int  ex_zprecede(void);
int  ex_zsetmark(void);
int ex_ztextat(void);
int  ex_zsearch(void);
int  ex_zsamemark(void);
int ex_zhasstyle(void);
int ex_ziconcode(void);
int ex_ziconfile(void);
int  ex_zextent(void);
int  ex_zaltered(void);
int  ex_zcopy(void);
int  ex_zend(void);
int  ex_zstart(void);
int  ex_zprevious(void);
int  ex_znext(void);
int  ex_zbase(void);
int  ex_zlast(void);
int  ex_zfirst(void);
int  ex_zchar(void);
int  ex_zcode(void);
int  ex_mcat(void);
int  ex_zposition(void);
int  ex_zlengthm(void);
int ex_zlengthf(void);
int  ex_zlength(void);
int  ex_zhsvn(void);
int  ex_zrgbn(void);
int  ex_bitcnt(void);
int  ex_comp(void);
int  ex_isign(void);
int  ex_sign(void);
int  ex_round(void);
int  ex_frac(void);
int  ex_int(void);
int  ex_arctan2(void);
int  ex_arctan(void);
int  ex_exponent(void);
int  ex_efunct(void);
int  ex_msysvara(void);
int  ex_msysvar(void);
int  ex_tsysvar(void);
int  ex_isysvar(void);
int  ex_sysvar(void);
int  ex_ibranchf(void);
int  ex_ibrancht(void);
int  ex_gamma(void);
int  ex_tanh(void);
int  ex_cosh(void);
int  ex_sinh(void);
int  ex_ln(void);
int  ex_alog(void);
int  ex_log(void);
int  ex_exp(void);
int  ex_abs(void);
int  ex_sqrt(void);
int  ex_arccot(void);
int  ex_arcsec(void);
int  ex_arccsc(void);
int  ex_arccos(void);
int  ex_arcsin(void);
int  ex_cot(void);
int  ex_sec(void);
int  ex_csc(void);
int  ex_tan(void);
int  ex_cos(void);
int  ex_sin(void);
int  ex_mspne(void);
int  ex_mspeq(void);
int  ex_mspge(void);
int  ex_msple(void);
int  ex_mspgt(void);
int  ex_msplt(void);
int  ex_mne(void);
int  ex_meq(void);
int  ex_mge(void);
int  ex_mle(void);
int  ex_mgt(void);
int  ex_mlt(void);
int  exs_ispne(void);
int  exs_ispeq(void);
int  exs_ispge(void);
int  exs_isple(void);
int  exs_ispgt(void);
int  exs_isplt(void);
int  ex_ispne(void);
int  ex_ispeq(void);
int  ex_ispge(void);
int  ex_isple(void);
int  ex_ispgt(void);
int  ex_isplt(void);
int  ex_ine(void);
int  ex_ieq(void);
int ex_txne(void);
int ex_txeq(void);
int  exs_mspne(void);
int  exs_mspeq(void);
int  exs_mspge(void);
int  exs_msple(void);
int  exs_mspgt(void);
int  exs_msplt(void);
int  exs_spne(void);
int  exs_speq(void);
int  exs_spge(void);
int  exs_sple(void);
int  exs_spgt(void);
int  exs_splt(void);
int  exs_efunct(void);
int  exs_mparrayaddr(void);
int  exs_iparrayaddr(void);
int  exs_parrayaddr(void);
int  exs_mparrayval(void);
int  exs_bparrayval(void);
int  exs_iparrayval(void);
int  exs_parrayval(void);
int  exs_storinf(void);
int  exs_mlitc(void);
int  exs_mliteral(void);
int  exs_mlarrayaddr(void);
int  exs_mlarrayval(void);
int  exs_blarrayaddr(void);
int  exs_blarrayval(void);
int  exs_ilarrayaddr(void);
int  exs_ilarrayval(void);
int  exs_larrayaddr(void);
int  exs_larrayval(void);
int  exs_mgarrayaddr(void);
int  exs_mgarrayval(void);
int  exs_bgarrayaddr(void);
int  exs_bgarrayval(void);
int  exs_igarrayaddr(void);
int  exs_igarrayval(void);
int  exs_garrayaddr(void);
int  exs_garrayval(void);
int  exs_pass_array_inf(void);
int  exs_mlocalval(void);
int  exs_mglobalval(void);
int  exs_msysvara(void);
int  exs_msysvar(void);
int  exs_tsysvar(void);
int  exs_isysvar(void);
int  exs_sysvar(void);
int  exs_exponic(void);
int  ex_arrayerr(void);
int  ex_ccode(void);
int ex_dcode(void);
int  ex_loopchk(void);
int  ex_ulocaddr(void);
int  ex_textarg1(void);
int  ex_textarg(void);
int  ex_tkeyword(void);
int  ex_storinf(void);
int  assign_pfun(long  addr,long  pfunct);
int  exs_xpassval(void);
int  exs_xlocalval(void);
int  exs_xglobalval(void);
int  exs_floatinit(void);
int  exs_storeaddr(void);
int  exs_mpassaddr(void);
int  exs_mpassval(void);
int ex_zcomb(void);
int ex_zfactorial(void);
#endif /* ctproto */


extern int FAR ex_gdyarrayval();
extern int FAR exs_gdyarrayval();
extern int FAR ex_gdyarrayaddr();
extern int FAR exs_gdyarrayaddr();
extern int FAR ex_igdyarrayval();
extern int FAR exs_igdyarrayval();
extern int FAR ex_igdyarrayaddr();
extern int FAR exs_igdyarrayaddr(); 
extern int FAR ex_bgdyarrayval();
extern int FAR exs_bgdyarrayval();
extern int FAR ex_gdyarray();
extern int FAR exs_gdyarray();

extern int FAR ex_ldyarrayval();
extern int FAR exs_ldyarrayval();
extern int FAR ex_ldyarrayaddr();
extern int FAR exs_ldyarrayaddr();
extern int FAR ex_ildyarrayval();
extern int FAR exs_ildyarrayval();
extern int FAR ex_ildyarrayaddr();
extern int FAR exs_ildyarrayaddr(); 
extern int FAR ex_bldyarrayval();
extern int FAR exs_bldyarrayval();
extern int FAR ex_ldyarray();
extern int FAR exs_ldyarray();

extern int FAR ex_pdyarrayval();
extern int FAR exs_pdyarrayval();
extern int FAR ex_pdyarrayaddr();
extern int FAR exs_pdyarrayaddr();
extern int FAR ex_ipdyarrayval();
extern int FAR exs_ipdyarrayval();
extern int FAR ex_ipdyarrayaddr();
extern int FAR exs_ipdyarrayaddr(); 
extern int FAR ex_bpdyarrayval();
extern int FAR exs_bpdyarrayval();
extern int FAR ex_pdyarray();
extern int FAR pdy_array_inf();

extern  int FAR ex_val();
extern  int FAR ex_zxyi();
extern  int FAR ex_zxya();
extern  int FAR ex_zxyr();
extern  int FAR ex_zxyg();
extern  int FAR ex_cotofn();
extern  int FAR ex_ftoc();
extern  int FAR ex_itoc();
extern  int FAR ex_iliteral();
extern  int FAR ex_fliteral();
extern  int FAR ex_mliteral();
extern  int FAR ex_mlitc();
extern  int FAR ex_globalval();
extern  int FAR ex_iglobalval();
extern  int FAR ex_bglobalval();
extern  int FAR ex_mglobalval();
extern  int FAR ex_globaladdr();
extern  int FAR ex_garrayval();
extern  int FAR ex_igarrayval();
extern  int FAR ex_bgarrayval();
extern  int FAR ex_mgarrayval();
extern  int FAR ex_garrayaddr();
extern  int FAR ex_igarrayaddr();
extern  int FAR ex_bgarrayaddr();
extern  int FAR ex_mgarrayaddr();
extern  int FAR ex_localval();
extern  int FAR ex_ilocalval();
extern  int FAR ex_blocalval();
extern  int FAR ex_mlocalval();
extern  int FAR ex_localaddr();
extern  int FAR ex_larrayval();
extern  int FAR ex_ilarrayval();
extern  int FAR ex_blarrayval();
extern  int FAR ex_mlarrayval();
extern  int FAR ex_larrayaddr();
extern  int FAR ex_ilarrayaddr();
extern  int FAR ex_blarrayaddr();
extern  int FAR ex_mlarrayaddr();
extern  int FAR ex_passval();
extern  int FAR ex_ipassval();
extern  int FAR ex_bpassval();
extern  int FAR ex_mpassval();
extern  int FAR ex_passaddr();
extern  int FAR ex_ipassaddr();
extern  int FAR ex_bpassaddr();
extern  int FAR ex_mpassaddr();
extern  int FAR ex_parrayval();
extern  int FAR ex_iparrayval();
extern  int FAR ex_bparrayval();
extern  int FAR ex_mparrayval();
extern  int FAR ex_parrayaddr();
extern  int FAR ex_iparrayaddr();
extern  int FAR ex_bparrayaddr();
extern  int FAR ex_mparrayaddr();
extern int FAR ex_xparray();
extern  int FAR ex_garray();
extern  int FAR ex_larray();
extern  int FAR ex_parray();
extern  int FAR ex_iparray();
extern  int FAR ex_bparray();
extern  int FAR ex_mparray();
extern  int FAR ex_assign();
extern  int FAR ex_iassign();
extern  int FAR ex_bassign();
extern  int FAR ex_massign();
extern  int FAR ex_plus();
extern  int FAR ex_minus();
extern  int FAR ex_uminus();
extern  int FAR ex_iplus();
extern  int FAR ex_iminus();
extern  int FAR ex_iuminus();
extern  int FAR ex_iinc();
extern  int FAR ex_idec();
extern  int FAR ex_times();
extern  int FAR ex_itimes();
extern  int FAR ex_divide();
extern  int FAR ex_idivr();
extern  int FAR ex_idivt();
extern  int FAR ex_lunion();
extern  int FAR ex_lmask();
extern  int FAR ex_ldiff();
extern  int FAR ex_lshift();
extern  int FAR ex_rshift();
extern  int FAR ex_itof();
extern  int FAR ex_ftoi();
extern int FAR ex_munit();
extern  int FAR ex_not();
extern  int FAR ex_and();
extern  int FAR ex_or();
extern  int FAR ex_mod();
extern  int FAR ex_exponic();
extern  int FAR ex_exponent();
extern  int FAR ex_arctan();
extern  int FAR ex_arctan2();
extern  int FAR ex_int();
extern  int FAR ex_frac();
extern  int FAR ex_round();
extern  int FAR ex_sign();
extern int FAR ex_isign();
extern  int FAR ex_comp();
extern  int FAR ex_bitcnt();
extern  int FAR ex_zrgbn();
extern  int FAR ex_zhsvn();
extern  int FAR ex_zlength();
extern int FAR ex_zlengthm();
extern int FAR ex_zlengthf();
extern  int FAR ex_zposition();
extern  int FAR ex_mcat();
extern  int FAR ex_zcode();
extern  int FAR ex_zchar();
extern  int FAR ex_zfirst();
extern  int FAR ex_zlast();
extern  int FAR ex_zbase();
extern  int FAR ex_znext();
extern  int FAR ex_zprevious();
extern  int FAR ex_zstart();
extern  int FAR ex_zend();
extern  int FAR ex_zcopy();
extern  int FAR ex_zaltered();
extern  int FAR ex_zextent();
extern  int FAR ex_zsamemark();
extern  int FAR ex_zsearch();
extern int FAR ex_zhasstyle();
extern int FAR ex_ziconcode();
extern int FAR ex_ziconfile();
extern  int FAR ex_zsetmark();
extern int FAR ex_ztextat();
extern  int FAR ex_zprecede();
extern int FAR ex_ztextsel();
extern int FAR ex_ztextvis();
extern int FAR ex_zeditbase();
extern int FAR ex_zhotinfoe();
extern int FAR ex_zhotinfom();
extern int FAR ex_zddetext();
extern int FAR ex_zswidth();
extern int FAR ex_zsheight();
extern int FAR ex_zhotsel();
extern int FAR ex_zvalueb();
extern int FAR ex_zvalues();
extern  int FAR ex_zks();
extern int FAR ex_znextword();
extern int FAR ex_znextexpr();
extern int FAR ex_znextnum();
extern int FAR ex_zfilename();
extern int FAR ex_zfilepath();
extern int FAR ex_znicons();
extern int FAR ex_znextline();
extern  int FAR ex_lt();
extern  int FAR ex_gt();
extern  int FAR ex_le();
extern  int FAR ex_ge();
extern  int FAR ex_eq();
extern  int FAR ex_ne();
extern  int FAR ex_splt();
extern  int FAR ex_spgt();
extern  int FAR ex_sple();
extern  int FAR ex_spge();
extern  int FAR ex_speq();
extern  int FAR ex_spne();
extern  int FAR ex_ilt();
extern  int FAR ex_igt();
extern  int FAR ex_ile();
extern  int FAR ex_ige();
extern  int FAR ex_ieq();
extern  int FAR ex_ine();
extern  int FAR ex_txeq();
extern  int FAR ex_txne();
extern  int FAR ex_isplt();
extern  int FAR ex_ispgt();
extern  int FAR ex_isple();
extern  int FAR ex_ispge();
extern  int FAR ex_ispeq();
extern  int FAR ex_ispne();
extern  int FAR exs_isplt();
extern  int FAR exs_ispgt();
extern  int FAR exs_isple();
extern  int FAR exs_ispge();
extern  int FAR exs_ispeq();
extern  int FAR exs_ispne();
extern  int FAR ex_mlt();
extern  int FAR ex_mgt();
extern  int FAR ex_mle();
extern  int FAR ex_mge();
extern  int FAR ex_meq();
extern  int FAR ex_mne();
extern  int FAR ex_msplt();
extern  int FAR ex_mspgt();
extern  int FAR ex_msple();
extern  int FAR ex_mspge();
extern  int FAR ex_mspeq();
extern  int FAR ex_mspne();
extern  int FAR ex_ibrancht();
extern  int FAR ex_ibranchf();
extern  int FAR ex_sysvar();
extern int FAR ex_isysvar();
extern int FAR ex_tsysvar();
extern  int FAR ex_msysvar();
extern  int FAR ex_msysvara();
extern  int FAR ex_efunct();
extern  int FAR ex_storinf();
extern  int FAR ex_tkeyword();
extern  int FAR ex_textarg();
extern  int FAR ex_textarg1();
extern  int FAR ex_ulocaddr();
extern int FAR ex_loopchk();
extern  int FAR ex_ccode();
extern int FAR ex_dcode();
extern int FAR ex_arrayerr();
extern int FAR ex_nofun();      
extern int FAR ex_sin();
extern int FAR ex_cos();
extern int FAR ex_tan();
extern int FAR ex_csc();
extern int FAR ex_sec();
extern int FAR ex_cot();
extern int FAR ex_arcsin();
extern int FAR ex_arccos();
extern int FAR ex_arccsc();
extern int FAR ex_arcsec();
extern int FAR ex_arccot();
extern int FAR ex_sqrt();
extern int FAR ex_abs();
extern int FAR ex_exp();
extern int FAR ex_log(); 
extern int FAR ex_alog();
extern int FAR ex_ln();
extern int FAR ex_sinh();   
extern int FAR ex_cosh();   
extern int FAR ex_tanh(); 
extern int FAR ex_gamma();
extern int FAR ex_zcomb();
extern int FAR ex_zfactorial();

extern int FAR exs_exponic();
extern int FAR exs_pass_array_inf();
extern int FAR exs_mglobalval();
extern int FAR exs_mlocalval();
extern int FAR exs_garrayval();
extern int FAR exs_garrayaddr();
extern int FAR exs_igarrayval();
extern int FAR exs_igarrayaddr();
extern int FAR exs_bgarrayval();
extern int FAR exs_bgarrayaddr();
extern int FAR exs_mgarrayval();
extern int FAR exs_mgarrayaddr();
extern int FAR exs_larrayval(); 
extern int FAR exs_larrayaddr();
extern int FAR exs_ilarrayval();
extern int FAR exs_ilarrayaddr();
extern int FAR exs_blarrayval();
extern int FAR exs_blarrayaddr();
extern int FAR exs_mlarrayval();
extern int FAR exs_mlarrayaddr();
extern int FAR exs_mliteral();
extern int FAR exs_mlitc();
extern int FAR exs_storinf();
extern int FAR exs_parrayval();
extern int FAR exs_iparrayval();
extern int FAR exs_bparrayval();
extern int FAR exs_mparrayval();
extern int FAR exs_parrayaddr();
extern int FAR exs_iparrayaddr();
extern int FAR exs_bparrayaddr();
extern int FAR exs_mparrayaddr();
extern int FAR exs_sysvar();
extern int FAR exs_isysvar();
extern int FAR exs_tsysvar();
extern int FAR exs_msysvar();
extern int FAR exs_msysvara();
extern int FAR exs_efunct();
extern  int FAR exs_speq();
extern  int FAR exs_spge();
extern  int FAR exs_spgt();
extern  int FAR exs_sple();
extern  int FAR exs_splt();
extern  int FAR exs_spne();
extern  int FAR exs_mspeq();
extern  int FAR exs_mspge();
extern  int FAR exs_mspgt();
extern  int FAR exs_msple();
extern  int FAR exs_msplt();
extern  int FAR exs_mspne();
extern int FAR exs_mpassval();
extern int FAR exs_mpassaddr();
extern int FAR exs_storeaddr();
extern int FAR exs_floatinit();
extern int FAR exs_xglobalval();
extern int FAR exs_xlocalval();
extern int FAR exs_xpassval();

#ifdef macproto
extern  int TUTORmodify_menu(unsigned int barh,char *card,char *item,int enableFlag,int checkFlag,int style);
#endif

extern Memh TUTORnew_doc();
extern  char FAR *TUTORalloc();
extern int (FAR * FAR *exs_addr)(ANYARGS); /* routines to process commands/expression elements */
extern  struct tutorview FAR *TUTORinit_view();
int procexecstub();
int procexecwstub();

/* ******************************************************************* */

initexec0() /* one-time initializations for all executors */
    
{
    /* this doesn't belong here! (should be in initialization of each execstate) */
    TUTORzero((char SHUGE *) &exS, (long) sizeof(ExecuteState));
    
    /* initialize default fonts etc. */
    exS.textFont = textFont0;
    exS.baseFont = textFont0;
    exS.iconFont = iconFont0;
    exS.cursorFont = cursorFont0;
    exS.cursorChar = cursorChar0;
    exS.patternFont = patternFont0;
    exS.patternChar = patternChar0;
    exS.hold_event.type = -1;

    exec_err_msg = FARNULL;
    
    exec_iprocs(); /* initialize executor proc table */
    markstack = (struct markvar FAR *)TUTORalloc((long)(EX_MSTACKL*sizeof(struct markvar)),
                 TRUE,"markvar");
    return(0);

} /* initexec0 */

/* ******************************************************************* */

initexecw() /* create an executor window */

{   int fie,fib,wi; /* indexs in file, window names */
    char wname[FILEL+1]; /* window name */
    
    /* open executor window */
    ExecWn = TUTORcreate_window(-1,-1,0,0,EXECW);

#ifdef DOPSCRIPT
    if (PostscriptFlag) {
        windowsP[ExecWn].postscript = TRUE;
        postscript_header();   /* procedure definitions */  
    } /* postscript if */
#endif

    /* set executor window name (= ct program name for andrew) */

    strcpy(wname,"ctexec"); /* default name */
#ifdef ANDREW
    if (EditWn[0] < 0) {
        TUTORget_fileref_name(&sourcetable[0].fRef,wname);
    } /* EditWn if */
#endif
    TUTORset_program_name(wname);
    sync();

    /* menu bar for this execution window */
    exS.execmenus = TUTORinit_menubar(64);
    TUTORset_menubar(exS.execmenus,ExecVp);
    exS.optionInhib = TRUE; /* force reset */
	iexec_option_menu();
    /* graphedit menu bar */
    grapheditmenus = TUTORinit_menubar(10);
    TUTORset_menubar(grapheditmenus,ExecVp); /* start menus */
#ifdef WINPC
   TUTORadd_menu(grapheditmenus,NEARNULL,0,"Run from beginning\tF5",15,'A',exec_run,0,0.0,EVENT_MENU);
#else
    TUTORadd_menu(grapheditmenus,NEARNULL,0,"Run from beginning",15,'A',exec_run,0,0.0,EVENT_MENU);
#endif
    TUTORadd_menu(grapheditmenus,NEARNULL,0,"Execute current unit",15,0,exec_execcur,0,0.0,EVENT_MENU);
    TUTORadd_menu(grapheditmenus,NEARNULL,0,"Run from selected unit",20,'K',exec_runsel,0,0.0,EVENT_MENU);
    TUTORadd_menu(grapheditmenus,NEARNULL,0,"Execute selected unit",25,'E',exec_execsel,0,0.0,EVENT_MENU);
#ifdef IBMPC
    if (EditWn[0] >= 0)
        TUTORadd_menu(grapheditmenus,NEARNULL,0,"Edit program",25,'Q',exec_toedit,0,0.0,EVENT_MENU);
#endif
#ifdef MAC
    TUTORadd_menu(grapheditmenus,NEARNULL,0,"-",26,0,0,0,0.0,EVENT_MENU);
    TUTORmodify_menu(grapheditmenus,NEARNULL,"-",0,-1,-1);
    TUTORadd_menu(grapheditmenus,NEARNULL,0,"Edit program",30,0,exec_toedit,0,0.0,EVENT_MENU);
#endif

    /* initialize executor event mask */
    TUTORset_event_mask(EVENT_KEY,TRUE);
    TUTORset_event_mask(EVENT_FKEY,TRUE);
    TUTORset_event_mask(EVENT_MENU,TRUE);
    TUTORset_event_mask(EVENT_MSG,TRUE);
    TUTORset_event_mask(EVENT_LEFTDOWN,TRUE);
    TUTORset_event_mask(EVENT_RIGHTDOWN,TRUE);
    TUTORset_event_mask(EVENT_LEFTUP,TRUE);
    TUTORset_event_mask(EVENT_RIGHTUP,TRUE);
    TUTORset_event_mask(EVENT_DOWNMOVE,TRUE);
    TUTORset_event_mask(EVENT_UPMOVE,FALSE);
    TUTORset_event_mask(EVENT_WFOCUS,TRUE);
    TUTORset_event_mask(EVENT_FWD,TRUE);
    TUTORset_event_mask(EVENT_HOT,TRUE);

    TUTORnormal_cursor();
    
} /* initexecw */

/* ******************************************************************* */

int iexec_option_menu() 

{
	if (!exS.optionInhib)
		return(0); /* nothing to do */
	
	exS.optionInhib = FALSE;
	TUTORdelete_menu(exS.execmenus,NEARNULL,"Option"); /* delete Option card */
    if (nosourcelayout) {
        TUTORadd_menu(exS.execmenus,NEARNULL,0,"Quit",99,0,exec_quit,0,0.0,EVENT_MENU);
        TUTORflush();
        return(0);
    }
        
    TUTORadd_menu(exS.execmenus,NEARNULL,0,"Quit running",99,0,exec_quit,0,0.0,EVENT_MENU);
#ifdef AUTHOR
#ifdef MAC
        TUTORadd_menu(exS.execmenus,NEARNULL,0,"Make PICT",98,0,exec_print,0,0.0,EVENT_MENU);
#endif /* mac */

#ifdef DOSPC
    TUTORadd_menu(exS.execmenus,NEARNULL,0,"Make PCX",98,0,exec_print,0,0.0,EVENT_MENU);
#endif /* ibmpc */
#ifdef WINPC
    TUTORadd_menu(exS.execmenus,NEARNULL,0,"Make BMP",98,0,exec_print,0,0.0,EVENT_MENU);
#endif /* ibmpc */

#ifdef X11
    TUTORadd_menu(exS.execmenus,NEARNULL,0,"Make PPM",98,0,exec_print,0,0.0,EVENT_MENU);
#endif /* X11 */
#endif /* AUTHOR */
	TUTORflush();
	return(0);

} /* iexec_option_menu */

/* ******************************************************************* */

#ifdef WINPC
#ifdef EXECUTE
static int wOneShot = TRUE;
#endif
#endif

initexec() /* one-time initializations for an executor */
    
{   Memh execH;
    ExecuteDat FAR *execP;
    char FAR *sP; 

    ExecVp = TUTORinit_view(ExecWn,(Memh) 0,procexecstub);
    exS.baseView = ExecVp;
    windowsP[ExecWn].wproc = (int(*)(ANYARGS))(procexecwstub);
    execH = TUTORhandle("execdat ",(long) sizeof(ExecuteDat),TRUE);
    execP = (ExecuteDat FAR *) GetPtr(execH);
    execP->wid = ExecWn;
    ReleasePtr(execH);
    KillPtr(execP);
    windowsP[ExecWn].wH = execH;

    TUTORset_view(ExecVp); /* insure executor view */
    TUTORset_key_focus(ExecWn,ExecVp,FALSE);
    windowsP[ExecWn].MenuFocus = ExecVp; /* set menu focus */

    exS.dTextLayout = TUTORnew_doc(TRUE,TRUE); /* set up executor text view */

    /* allocate stack and set to pre-zero */
    
    ((gvaraddr < 1000) ? exS.stackmalloc = 1000: gvaraddr);
    exS.stackH = TUTORhandle("stack  ",exS.stackmalloc,TRUE);
    if (!exS.stackH)
        StopProgram(NEARNULL);
    sP = (char FAR *)GetPtr(exS.stackH); /* get pointer on stack */
    /* pre-zero to insure 1st two marker vars cleared */
    TUTORzero(sP,exS.stackmalloc);
    gvarzero = TRUE;
    ReleasePtr(exS.stackH); /* allow stack memory move */
    KillPtr(sP);

    exS.condt_uloc = 0; /* no conditional command yet */
    exS.arr.jbuffer = FARNULL;  /* no judge buffer (zarrowm) yet */
    exS.arr.aPanel = 0; /* no arrow text panel */
    
    /* no sort table, matches are exact */
    exS.exactMatch = TRUE;
    exS.sortTable = HNULL;
    exS.desX = ExecWinX; /* desired window size */
    exS.desY = ExecWinY;

#ifdef WINPC
#ifdef EXECUTE
    /* special handling for windows executor - first */
    /* window is created before desired size is known */
    if (wOneShot && ExecWinX) {
	TUTORsize_exec_window(ExecWinX,ExecWinY);
	wOneShot = FALSE;
    }
#endif
#endif

#ifdef MAC
#ifdef __MC68K__
	exS.useCompiled = TRUE; /* use compiled code on 68K Macintosh */
#endif
#endif
    
    return(0);
    
} /* initexec */


/* ******************************************************************* */

extern int FAR cmd_old(), FAR cmd_coarse(), FAR cmd_rescale(), FAR cmd_rgb(), FAR cmd_hsv();
extern int FAR cmd_branch(); 
extern int FAR cmd_branchf(); 
extern int FAR cmd_brancht();
extern int FAR cmd_fine(), FAR cmd_at(), FAR cmd_atnm(), FAR cmd_dot();
extern int FAR cmd_draw(), FAR cmd_rdot(), FAR cmd_rdraw(), FAR cmd_gdot(), FAR cmd_gdraw();
extern int FAR cmd_fill(), FAR cmd_rfill(), FAR cmd_gfill(), FAR cmd_rerase(), FAR cmd_gerase();
extern int FAR cmd_hbar(), FAR cmd_vbar(), FAR cmd_gat(), FAR cmd_rat(), FAR cmd_gatnm(), FAR cmd_ratnm();
extern int FAR cmd_delta(), FAR cmd_polar();
extern int FAR cmd_size(), FAR cmd_rotate(), FAR cmd_scalex(), FAR cmd_scaley();
extern int FAR cmd_thick();
extern int FAR cmd_lscalex(), FAR cmd_lscaley(), FAR cmd_markx(), FAR cmd_marky();
extern int FAR cmd_labelx(), FAR cmd_labely(), FAR cmd_circle(), FAR cmd_circleb();
extern int FAR cmd_rcircle(), FAR cmd_rcircleb(), FAR cmd_gcircle(), FAR cmd_gcircleb(), FAR cmd_box();
extern int FAR cmd_vector(), FAR cmd_rbox(), FAR cmd_gbox(), FAR cmd_rvector(), FAR cmd_gvector();
extern int FAR cmd_rorigin(), FAR cmd_gorigin(), FAR cmd_erase(), FAR cmd_erasep();
extern int FAR cmd_bounds(), FAR cmd_axes(), FAR cmd_clip(), FAR cmd_rclip(), FAR cmd_gclip();
extern int FAR cmd_disk(), FAR cmd_rdisk(), FAR cmd_gdisk();
extern int FAR cmd_press(), FAR cmd_clrkey(), FAR cmd_getkey(), FAR cmd_randu();
extern int FAR cmd_inhibit(), FAR cmd_allow(), FAR cmd_specs(), FAR cmd_judge(), FAR cmd_mode();
extern int FAR cmd_video(), FAR cmd_vset(), FAR cmd_vstep(), FAR cmd_vplay(), FAR cmd_vwait();
extern int FAR cmd_vclose();
extern int FAR cmd_vshow();
extern int FAR cmd_sound();
extern int FAR cmd_pict(), FAR cmd_dma(), FAR cmd_sysinfo(), FAR cmd_dialog(), FAR cmd_print();
extern int FAR cmd_step(), cmd_stepover();
extern int FAR cmd_okcmd(), FAR cmd_nocmd(), FAR cmd_enable(), FAR cmd_disable();
extern int FAR cmd_showz(), FAR cmd_showe();
extern int FAR cmd_begintext(), FAR cmd_endtext(), FAR cmd_write(), FAR cmd_show(), FAR cmd_showt();
extern int FAR cmd_showb(), FAR cmd_showo(), FAR cmd_showh(), FAR cmd_wrapstyle();
extern int FAR cmd_plot(), FAR cmd_ploti(), FAR cmd_text(), FAR cmd_rtext(), FAR cmd_gtext();
extern int FAR cmd_textm(), FAR cmd_rtextm(), FAR cmd_gtextm();
extern int FAR cmd_string(), FAR cmd_replace(), FAR cmd_append();
extern int FAR cmd_sticky();
extern int FAR cmd_begintext1(), FAR cmd_endtext1(), FAR cmd_write1(), FAR cmd_write2();
extern int FAR cmd_begintext2(), FAR cmd_endtext2(), FAR cmd_begintext3(), FAR cmd_begintext4();
extern int FAR cmd_exact(), FAR cmd_exactw(), FAR cmd_answer(), FAR cmd_wrong();
extern int FAR cmd_ansv(), FAR cmd_wrongv();
extern int FAR cmd_menu(), FAR cmd_color(), FAR cmd_wcolor(), FAR cmd_getrgb(), FAR cmd_gethsv();
extern int FAR cmd_wtitle();
extern int FAR cmd_font(), FAR cmd_icons(), FAR cmd_pattern(), FAR cmd_cursor();
extern int FAR cmd_addfile(), FAR cmd_setfile(), FAR cmd_delfile(), FAR cmd_reset();
extern int FAR cmd_setdir(),FAR cmd_adddir(),FAR cmd_deldir(), FAR cmd_getdir();
extern int FAR cmd_fontp();
extern int FAR cmd_newline();
extern int FAR cmd_supsub();
extern int FAR cmd_style();
extern int FAR cmd_forget();
extern int FAR cmd_cancel();
extern int FAR cmd_zero(), FAR cmd_set(), FAR cmd_setc(), FAR cmd_datain(), FAR cmd_dataout();
extern int FAR cmd_zerom();
extern int FAR cmd_block();
extern int FAR cmd_xin(), FAR cmd_xout(), FAR cmd_numout(), FAR cmd_readln(), FAR cmd_compute();
extern int FAR cmd_dde();
extern int FAR cmd_socket(), FAR cmd_server(), FAR cmd_getserv(), FAR cmd_serial(), FAR cmd_beep();
extern int FAR cmd_sockwait();
extern int FAR cmd_move(), FAR cmd_rmove(), FAR cmd_gmove(), FAR cmd_markpt(), FAR cmd_pause();
extern int FAR cmd_execute(), FAR cmd_cond(), FAR cmd_condout();
extern int FAR cmd_case(), FAR cmd_casem(), FAR cmd_clause(), FAR cmd_endcase();
extern int FAR cmd_caset(), FAR cmd_calc();
extern int FAR cmd_iloopinit(), FAR cmd_iloop1init(), FAR cmd_iloop1(), FAR cmd_iloopinc();
extern int FAR cmd_icloopinit();
extern int FAR cmd_floopinit(), FAR cmd_floopinc(), FAR cmd_svers();
extern int FAR cmd_endunit(),FAR cmd_alloc();
extern int FAR cmd_do(), FAR cmd_jump(), FAR cmd_objw();
extern int FAR cmd_imain(), FAR cmd_ijudge(), FAR cmd_iarrow();
extern int FAR cmd_eraseu(), FAR cmd_reshape(), FAR cmd_finishu();
extern int FAR cmd_next(), FAR cmd_back(), FAR cmd_outunit(), FAR cmd_jumpout();
extern int FAR cmd_arrow(), FAR cmd_arrow1(), FAR cmd_arrow2(), FAR cmd_arrow3(), FAR cmd_rarrow(), FAR cmd_garrow();
extern int FAR cmd_ifmatch(), FAR cmd_endarrow(), FAR cmd_preans(), FAR cmd_endans();
extern int FAR cmd_slice(), FAR cmd_dmp(), FAR cmd_cmds(), FAR cmd_null();
extern int FAR cmd_get(), FAR cmd_put();
extern int FAR cmd_rget(), FAR cmd_gget(), FAR cmd_rput(), FAR cmd_gput();
extern int FAR cmd_edit(), FAR cmd_redit(), FAR cmd_gedit();
extern int FAR cmd_button(), FAR cmd_rbutton(), FAR cmd_gbutton();
extern int FAR cmd_slider(), FAR cmd_rslider(), FAR cmd_gslider();
extern int FAR cmd_editr(), FAR cmd_reditr(), FAR cmd_geditr();
extern int FAR cmd_buttonr(), FAR cmd_rbuttonr(), FAR cmd_gbuttonr();
extern int FAR cmd_sliderr(), FAR cmd_rsliderr(), FAR cmd_gsliderr();
extern int FAR cmd_focus();
extern int FAR cmd_palette(), FAR cmd_webpal();
extern int FAR cmd_newpal();
extern int FAR cmd_fpalette();
extern int FAR cmd_touch(), FAR cmd_rtouch(), FAR cmd_gtouch();

#ifdef MAC
    extern int FAR lcfinita();
    extern int FAR lcfumina();
    extern int FAR lcfabsa();
    extern int FAR lcfadda();
    extern int FAR lcfsuba();
    extern int FAR lcfmulta();
    extern int FAR lcfdiva();
    extern int FAR lcfsqrta();
    extern int FAR lcfsina();
    extern int FAR lcfcosa();
    extern int FAR lcftana();
#endif

exec_iprocs() /* initialize tables for compiled code */

{   int i;

    exs_addr = (int (FAR * FAR *)(ANYARGS))
	      TUTORalloc(sizeof(int (*)(ANYARGS))*(long)C_MAX,TRUE,"exs_adr");
    
    for(i=0; i<C_MAX; i++) {
	exs_addr[i] = (int(*)(ANYARGS))ex_nofun;
    } /* for */
    
    /* table of routine addresses - used by interpretation loop and */
    /* by compiled code */
    
    exs_addr[C_BRANCH] = (int(*)(ANYARGS))cmd_branch;
    exs_addr[C_BRANCHT] = (int(*)(ANYARGS))cmd_brancht;
    exs_addr[C_BRANCHF] = (int(*)(ANYARGS))cmd_branchf;
    exs_addr[C_FINE] = (int(*)(ANYARGS))cmd_fine;
    exs_addr[C_RESCALE] = (int(*)(ANYARGS))cmd_rescale;
    exs_addr[C_COARSE] = (int(*)(ANYARGS))cmd_coarse;
    exs_addr[C_PALETTE] = (int(*)(ANYARGS))cmd_palette;
    exs_addr[C_NEWPAL] = (int(*)(ANYARGS))cmd_newpal;
    exs_addr[C_FPALETTE] = (int(*)(ANYARGS))cmd_fpalette;
	exs_addr[C_WEBPAL] = (int(*)(ANYARGS))cmd_webpal;
    exs_addr[C_RGB] = (int(*)(ANYARGS))cmd_rgb;
    exs_addr[C_HSV] = (int(*)(ANYARGS))cmd_hsv;
    exs_addr[C_GETRGB] = (int(*)(ANYARGS))cmd_getrgb;
    exs_addr[C_GETHSV] = (int(*)(ANYARGS))cmd_gethsv;
    exs_addr[C_AT] = (int(*)(ANYARGS))cmd_at;
    exs_addr[C_ATNM] = (int(*)(ANYARGS))cmd_atnm;
    exs_addr[C_DOT] = (int(*)(ANYARGS))cmd_dot;
    exs_addr[C_DRAW] = (int(*)(ANYARGS))cmd_draw;
    exs_addr[C_RDOT] = (int(*)(ANYARGS))cmd_rdot;
    exs_addr[C_RDRAW] = (int(*)(ANYARGS))cmd_rdraw;
    exs_addr[C_GDOT] = (int(*)(ANYARGS))cmd_gdot;
    exs_addr[C_GDRAW] = (int(*)(ANYARGS))cmd_gdraw;
    exs_addr[C_FILL] = (int(*)(ANYARGS))cmd_fill;
    exs_addr[C_ERASE] = (int(*)(ANYARGS))cmd_erase;
    exs_addr[C_ERASEP] = (int(*)(ANYARGS))cmd_erasep;
    exs_addr[C_CIRCLE] = (int(*)(ANYARGS))cmd_circle;
    exs_addr[C_CIRCLEB] = (int(*)(ANYARGS))cmd_circleb;
    exs_addr[C_BOX] = (int(*)(ANYARGS))cmd_box;
    exs_addr[C_VECTOR] = (int(*)(ANYARGS))cmd_vector;
    exs_addr[C_RORIGIN] = (int(*)(ANYARGS))cmd_rorigin;
    exs_addr[C_GORIGIN] = (int(*)(ANYARGS))cmd_gorigin;
    exs_addr[C_RFILL] = (int(*)(ANYARGS))cmd_rfill;
    exs_addr[C_GFILL] = (int(*)(ANYARGS))cmd_gfill;
    exs_addr[C_RERASE] = (int(*)(ANYARGS))cmd_rerase;
    exs_addr[C_GERASE] = (int(*)(ANYARGS))cmd_gerase;
    exs_addr[C_RCIRCLE] = (int(*)(ANYARGS))cmd_rcircle;
    exs_addr[C_RCIRCLEB] = (int(*)(ANYARGS))cmd_rcircleb;
    exs_addr[C_GCIRCLE] = (int(*)(ANYARGS))cmd_gcircle;
    exs_addr[C_GCIRCLEB] = (int(*)(ANYARGS))cmd_gcircleb;
    exs_addr[C_GAT] = (int(*)(ANYARGS))cmd_gat;
    exs_addr[C_RAT] = (int(*)(ANYARGS))cmd_rat;
    exs_addr[C_GATNM] = (int(*)(ANYARGS))cmd_gatnm;
    exs_addr[C_RATNM] = (int(*)(ANYARGS))cmd_ratnm;
    exs_addr[C_RVECTOR] = (int(*)(ANYARGS))cmd_rvector;
    exs_addr[C_GVECTOR] = (int(*)(ANYARGS))cmd_gvector;
    exs_addr[C_MOVE] = (int(*)(ANYARGS))cmd_move;
    exs_addr[C_RMOVE] = (int(*)(ANYARGS))cmd_rmove;
    exs_addr[C_GMOVE] = (int(*)(ANYARGS))cmd_gmove;
    exs_addr[C_RBOX] = (int(*)(ANYARGS))cmd_rbox;
    exs_addr[C_GBOX] = (int(*)(ANYARGS))cmd_gbox;
    exs_addr[C_HBAR] = (int(*)(ANYARGS))cmd_hbar;
    exs_addr[C_VBAR] = (int(*)(ANYARGS))cmd_vbar;
    exs_addr[C_AXES] = (int(*)(ANYARGS))cmd_axes;
    exs_addr[C_BOUNDS] = (int(*)(ANYARGS))cmd_bounds;
    exs_addr[C_SCALEX] = (int(*)(ANYARGS))cmd_scalex;
    exs_addr[C_SCALEY] = (int(*)(ANYARGS))cmd_scaley;
    exs_addr[C_LSCALEX] = (int(*)(ANYARGS))cmd_lscalex;
    exs_addr[C_LSCALEY] = (int(*)(ANYARGS))cmd_lscaley;
    exs_addr[C_LABELX] = (int(*)(ANYARGS))cmd_labelx;
    exs_addr[C_LABELY] = (int(*)(ANYARGS))cmd_labely;
    exs_addr[C_MARKX] = (int(*)(ANYARGS))cmd_markx;
    exs_addr[C_MARKY] = (int(*)(ANYARGS))cmd_marky;
    exs_addr[C_DELTA] = (int(*)(ANYARGS))cmd_delta;
    exs_addr[C_POLAR] = (int(*)(ANYARGS))cmd_polar;
    exs_addr[C_SIZE] = (int(*)(ANYARGS))cmd_size;
    exs_addr[C_ROTATE] = (int(*)(ANYARGS))cmd_rotate;
    exs_addr[C_THICK] = (int(*)(ANYARGS))cmd_thick;
    exs_addr[C_DISK] = (int(*)(ANYARGS))cmd_disk;
    exs_addr[C_RDISK] = (int(*)(ANYARGS))cmd_rdisk;
    exs_addr[C_GDISK] = (int(*)(ANYARGS))cmd_gdisk;
    exs_addr[C_CLIP] = (int(*)(ANYARGS))cmd_clip;
    exs_addr[C_RCLIP] = (int(*)(ANYARGS))cmd_rclip;
    exs_addr[C_GCLIP] = (int(*)(ANYARGS))cmd_gclip;
    exs_addr[C_PRESS] = (int(*)(ANYARGS))cmd_press;
    exs_addr[C_CLRKEY] = (int(*)(ANYARGS))cmd_clrkey;
    exs_addr[C_GETKEY] = (int(*)(ANYARGS))cmd_getkey;
    exs_addr[C_FOCUS] = (int(*)(ANYARGS))cmd_focus;
    exs_addr[C_RANDU] = (int(*)(ANYARGS))cmd_randu;
    exs_addr[C_INHIBIT] = (int(*)(ANYARGS))cmd_inhibit;
    exs_addr[C_ALLOW] = (int(*)(ANYARGS))cmd_allow;
    exs_addr[C_SPECS] = (int(*)(ANYARGS))cmd_specs;
    exs_addr[C_JUDGE] = (int(*)(ANYARGS))cmd_judge;
    exs_addr[C_MODE] = (int(*)(ANYARGS))cmd_mode;
    exs_addr[C_SOUND] = (int(*)(ANYARGS))cmd_sound;
    exs_addr[C_PICT] = (int(*)(ANYARGS))cmd_pict;
    exs_addr[C_SYSINFO] = (int(*)(ANYARGS))cmd_sysinfo;
    exs_addr[C_DIALOG] = (int(*)(ANYARGS))cmd_dialog;
    exs_addr[C_PRINT] = (int(*)(ANYARGS))cmd_print;
	exs_addr[C_STEP] = (int(*)(ANYARGS))cmd_step;
	exs_addr[C_STEPOVER] = (int(*)(ANYARGS))cmd_stepover;
	exs_addr[C_BEGINUNIT] = (int(*)(ANYARGS))cmd_null;
	exs_addr[C_STEPNULL] = (int(*)(ANYARGS))cmd_null;
    exs_addr[C_VIDEO] = (int(*)(ANYARGS))cmd_video;
    exs_addr[C_DMA] = (int(*)(ANYARGS))cmd_dma;
    exs_addr[C_VSET] = (int(*)(ANYARGS))cmd_vset;
    exs_addr[C_VSTEP] = (int(*)(ANYARGS))cmd_vstep;
    exs_addr[C_VPLAY] = (int(*)(ANYARGS))cmd_vplay;
    exs_addr[C_VSHOW] = (int(*)(ANYARGS))cmd_vshow;
    exs_addr[C_VWAIT] = (int(*)(ANYARGS))cmd_vwait; 
    exs_addr[C_VCLOSE] = (int(*)(ANYARGS))cmd_vclose;
    exs_addr[C_OKCMD] = (int(*)(ANYARGS))cmd_okcmd;
    exs_addr[C_NOCMD] = (int(*)(ANYARGS))cmd_nocmd;
    exs_addr[C_ENABLE] = (int(*)(ANYARGS))cmd_enable;
    exs_addr[C_DISABLE] = (int(*)(ANYARGS))cmd_disable;
    exs_addr[C_BEGINTEXT] = (int(*)(ANYARGS))cmd_begintext;
    exs_addr[C_ENDTEXT] = (int(*)(ANYARGS))cmd_endtext;
    exs_addr[C_WRITE] = (int(*)(ANYARGS))cmd_write;
    exs_addr[C_WRAPSTYLE] = (int(*)(ANYARGS))cmd_wrapstyle;
    exs_addr[C_SHOW] = (int(*)(ANYARGS))cmd_show;
    exs_addr[C_SHOWT] = (int(*)(ANYARGS))cmd_showt;
    exs_addr[C_SHOWH] = (int(*)(ANYARGS))cmd_showh;
    exs_addr[C_SHOWO] = (int(*)(ANYARGS))cmd_showo;
    exs_addr[C_SHOWB] = (int(*)(ANYARGS))cmd_showb;
    exs_addr[C_SHOWZ] = (int(*)(ANYARGS))cmd_showz;
    exs_addr[C_SHOWE] = (int(*)(ANYARGS))cmd_showe;
    exs_addr[C_PLOT] = (int(*)(ANYARGS))cmd_plot;
    exs_addr[C_PLOTI] = (int(*)(ANYARGS))cmd_ploti;
    exs_addr[C_TEXT] = (int(*)(ANYARGS))cmd_text;
    exs_addr[C_RTEXT] = (int(*)(ANYARGS))cmd_rtext;
    exs_addr[C_GTEXT] = (int(*)(ANYARGS))cmd_gtext;
    exs_addr[C_TEXTM] = (int(*)(ANYARGS))cmd_textm;
    exs_addr[C_RTEXTM] = (int(*)(ANYARGS))cmd_rtextm;
    exs_addr[C_GTEXTM] = (int(*)(ANYARGS))cmd_gtextm;
    exs_addr[C_STRING] = (int(*)(ANYARGS))cmd_string;
    exs_addr[C_APPEND] = (int(*)(ANYARGS))cmd_append;
    exs_addr[C_REPLACE] = (int(*)(ANYARGS))cmd_replace;
    exs_addr[C_STICKY] = (int(*)(ANYARGS))cmd_sticky;
    exs_addr[C_BEGINTEXT1] = (int(*)(ANYARGS))cmd_begintext1;
    exs_addr[C_ENDTEXT1] = (int(*)(ANYARGS))cmd_endtext1;
    exs_addr[C_WRITE1] = (int(*)(ANYARGS))cmd_write1;
    exs_addr[C_WRITE2] = (int(*)(ANYARGS))cmd_write2;
    exs_addr[C_BEGINTEXT2] = (int(*)(ANYARGS))cmd_begintext2;
    exs_addr[C_ENDTEXT2] = (int(*)(ANYARGS))cmd_endtext2;
    exs_addr[C_BEGINTEXT3] = (int(*)(ANYARGS))cmd_begintext3;
    exs_addr[C_BEGINTEXT4] = (int(*)(ANYARGS))cmd_begintext4;
    exs_addr[C_EXACT] = (int(*)(ANYARGS))cmd_exact;
    exs_addr[C_EXACTW] = (int(*)(ANYARGS))cmd_exactw;
    exs_addr[C_ANSWER] = (int(*)(ANYARGS))cmd_answer;
    exs_addr[C_WRONG] = (int(*)(ANYARGS))cmd_wrong;
    exs_addr[C_ANSV] = (int(*)(ANYARGS))cmd_ansv;
    exs_addr[C_WRONGV] = (int(*)(ANYARGS))cmd_wrongv;
    exs_addr[C_MENU] = (int(*)(ANYARGS))cmd_menu;
    exs_addr[C_COLOR] = (int(*)(ANYARGS))cmd_color;
    exs_addr[C_WCOLOR] = (int(*)(ANYARGS))cmd_wcolor;
    exs_addr[C_WTITLE] = (int(*)(ANYARGS))cmd_wtitle;
    exs_addr[C_NEWLINE] = (int(*)(ANYARGS))cmd_newline;
    exs_addr[C_SUPSUB] = (int(*)(ANYARGS))cmd_supsub;
    exs_addr[C_FONT] = (int(*)(ANYARGS))cmd_font;
    exs_addr[C_FONTP] = (int(*)(ANYARGS))cmd_fontp;
    exs_addr[C_ICONS] = (int(*)(ANYARGS))cmd_icons;
    exs_addr[C_PATTERN] = (int(*)(ANYARGS))cmd_pattern;
    exs_addr[C_CURSOR] = (int(*)(ANYARGS))cmd_cursor;
    exs_addr[C_ADDFILE] = (int(*)(ANYARGS))cmd_addfile;
    exs_addr[C_SETFILE] = (int(*)(ANYARGS))cmd_setfile;
    exs_addr[C_SETDIR] = (int(*)(ANYARGS))cmd_setdir;
    exs_addr[C_ADDDIR] = (int(*)(ANYARGS))cmd_adddir;
    exs_addr[C_DELDIR] = (int(*)(ANYARGS))cmd_deldir;
    exs_addr[C_GETDIR] = (int(*)(ANYARGS))cmd_getdir;
    exs_addr[C_DELFILE] = (int(*)(ANYARGS))cmd_delfile;
    exs_addr[C_RESET] = (int(*)(ANYARGS))cmd_reset;
    exs_addr[C_DATAIN] = (int(*)(ANYARGS))cmd_datain;
    exs_addr[C_DATAOUT] = (int(*)(ANYARGS))cmd_dataout;
    exs_addr[C_XIN] = (int(*)(ANYARGS))cmd_xin;
    exs_addr[C_XOUT] = (int(*)(ANYARGS))cmd_xout;
    exs_addr[C_NUMOUT] = (int(*)(ANYARGS))cmd_numout;
    exs_addr[C_READLN] = (int(*)(ANYARGS))cmd_readln;
    exs_addr[C_SOCKET] = (int(*)(ANYARGS))cmd_socket;
    exs_addr[C_SERVER] = (int(*)(ANYARGS))cmd_server;
    exs_addr[C_SOCKWAIT] = (int(*)(ANYARGS))cmd_sockwait;
    exs_addr[C_GETSERV] = (int(*)(ANYARGS))cmd_getserv;
    exs_addr[C_DDE] = (int(*)(ANYARGS))cmd_dde;
    exs_addr[C_STYLE] = (int(*)(ANYARGS))cmd_style;
    exs_addr[C_ZERO] = (int(*)(ANYARGS))cmd_zero;
    exs_addr[C_ZEROM] = (int(*)(ANYARGS))cmd_zerom;
    exs_addr[C_BLOCK] = (int(*)(ANYARGS))cmd_block;
    exs_addr[C_SET] = (int(*)(ANYARGS))cmd_set;
    exs_addr[C_SETC] = (int(*)(ANYARGS))cmd_setc;
    exs_addr[C_SERIAL] = (int(*)(ANYARGS))cmd_serial;
    exs_addr[C_BEEP] = (int(*)(ANYARGS))cmd_beep;
    exs_addr[C_COMPUTE] = (int(*)(ANYARGS))cmd_compute;
    exs_addr[C_MARKPT] = (int(*)(ANYARGS))cmd_markpt;
    exs_addr[C_PAUSE] = (int(*)(ANYARGS))cmd_pause;
    exs_addr[C_EXEC] = (int(*)(ANYARGS))cmd_execute;
    exs_addr[C_COND] = (int(*)(ANYARGS))cmd_cond;
    exs_addr[C_CONDOUT] = (int(*)(ANYARGS))cmd_condout;
    exs_addr[C_CASE] = (int(*)(ANYARGS))cmd_case;
    exs_addr[C_CASET] = (int(*)(ANYARGS))cmd_caset;
    exs_addr[C_CASEM] = (int(*)(ANYARGS))cmd_casem;
    exs_addr[C_CLAUSE] = (int(*)(ANYARGS))cmd_clause;
    exs_addr[C_ENDCASE] = (int(*)(ANYARGS))cmd_endcase;
    exs_addr[C_CALC] = (int(*)(ANYARGS))cmd_calc;
    exs_addr[C_ICALC] = (int(*)(ANYARGS))cmd_calc;
    exs_addr[C_MCALC] = (int(*)(ANYARGS))cmd_calc;
    exs_addr[C_ILOOPINIT] = (int(*)(ANYARGS))cmd_iloopinit;
    exs_addr[C_ILOOP1INIT] = (int(*)(ANYARGS))cmd_iloop1init;
    exs_addr[C_ICLOOPINIT] = (int(*)(ANYARGS))cmd_icloopinit;
    exs_addr[C_ILOOP1] = (int(*)(ANYARGS))cmd_iloop1;
    exs_addr[C_ILOOPINC] = (int(*)(ANYARGS))cmd_iloopinc;
    exs_addr[C_ICLOOPINC] = (int(*)(ANYARGS))cmd_iloopinc;
    exs_addr[C_FLOOPINIT] = (int(*)(ANYARGS))cmd_floopinit;
    exs_addr[C_FLOOPINC] = (int(*)(ANYARGS))cmd_floopinc;
    exs_addr[C_SVERS] = (int(*)(ANYARGS))cmd_svers;
    exs_addr[C_ENDUNIT] = (int(*)(ANYARGS))cmd_endunit;
    exs_addr[C_OBJW] = (int(*)(ANYARGS))cmd_objw;
    exs_addr[C_DO] = (int(*)(ANYARGS))cmd_do;
    exs_addr[C_JUMP] = (int(*)(ANYARGS))cmd_jump;
    exs_addr[C_IMAIN] = (int(*)(ANYARGS))cmd_imain;
    exs_addr[C_IJUDGE] = (int(*)(ANYARGS))cmd_ijudge;
    exs_addr[C_IARROW] = (int(*)(ANYARGS))cmd_iarrow;
    exs_addr[C_ERASEU] = (int(*)(ANYARGS))cmd_eraseu;
    exs_addr[C_RESHAPE] = (int(*)(ANYARGS))cmd_reshape;
    exs_addr[C_FINISHU] = (int(*)(ANYARGS))cmd_finishu;
    exs_addr[C_NEXT] = (int(*)(ANYARGS))cmd_next;
    exs_addr[C_BACK] = (int(*)(ANYARGS))cmd_back;
    exs_addr[C_OUTUNIT] = (int(*)(ANYARGS))cmd_outunit;
    exs_addr[C_JUMPOUT] = (int(*)(ANYARGS))cmd_jumpout;
    exs_addr[C_ARROW] = (int(*)(ANYARGS))cmd_arrow;
    exs_addr[C_ARROW1] = (int(*)(ANYARGS))cmd_arrow1;
    exs_addr[C_ARROW2] = (int(*)(ANYARGS))cmd_arrow2;
    exs_addr[C_ARROW3] = (int(*)(ANYARGS))cmd_arrow3;
    exs_addr[C_RARROW] = (int(*)(ANYARGS))cmd_rarrow;
    exs_addr[C_GARROW] = (int(*)(ANYARGS))cmd_garrow;
    exs_addr[C_IFMATCH] = (int(*)(ANYARGS))cmd_ifmatch;
    exs_addr[C_ENDARROW] = (int(*)(ANYARGS))cmd_endarrow;
    exs_addr[C_PREANS] = (int(*)(ANYARGS))cmd_preans;
    exs_addr[C_ENDANS] = (int(*)(ANYARGS))cmd_endans;
    exs_addr[C_DMP] = (int(*)(ANYARGS))cmd_dmp;
    exs_addr[C_CMDS] = (int(*)(ANYARGS))cmd_cmds;
    exs_addr[C_LBEGIN] = (int(*)(ANYARGS))cmd_null;
    exs_addr[C_LEND] = (int(*)(ANYARGS))cmd_null;
    exs_addr[C_SLICE] = (int(*)(ANYARGS))cmd_slice;
    exs_addr[C_GET] = (int(*)(ANYARGS))cmd_get;
    exs_addr[C_PUT] = (int(*)(ANYARGS))cmd_put;
    exs_addr[C_RGET] = (int(*)(ANYARGS))cmd_rget;
    exs_addr[C_RPUT] = (int(*)(ANYARGS))cmd_rput;
    exs_addr[C_GGET] = (int(*)(ANYARGS))cmd_gget;
    exs_addr[C_GPUT] = (int(*)(ANYARGS))cmd_gput;
    exs_addr[C_EDIT] = (int(*)(ANYARGS))cmd_edit;
    exs_addr[C_REDIT] = (int(*)(ANYARGS))cmd_redit;
    exs_addr[C_GEDIT] = (int(*)(ANYARGS))cmd_gedit;
    exs_addr[C_BUTTON] = (int(*)(ANYARGS))cmd_button;
    exs_addr[C_RBUTTON] = (int(*)(ANYARGS))cmd_rbutton;
    exs_addr[C_GBUTTON] = (int(*)(ANYARGS))cmd_gbutton;
    exs_addr[C_SLIDER] = (int(*)(ANYARGS))cmd_slider;
    exs_addr[C_RSLIDER] = (int(*)(ANYARGS))cmd_rslider;
    exs_addr[C_GSLIDER] = (int(*)(ANYARGS))cmd_gslider;
    exs_addr[C_EDITR] = (int(*)(ANYARGS))cmd_editr;
    exs_addr[C_REDITR] = (int(*)(ANYARGS))cmd_reditr;
    exs_addr[C_GEDITR] = (int(*)(ANYARGS))cmd_geditr;
    exs_addr[C_BUTTONR] = (int(*)(ANYARGS))cmd_buttonr;
    exs_addr[C_RBUTTONR] = (int(*)(ANYARGS))cmd_rbuttonr;
    exs_addr[C_GBUTTONR] = (int(*)(ANYARGS))cmd_gbuttonr;
    exs_addr[C_SLIDERR] = (int(*)(ANYARGS))cmd_sliderr;
    exs_addr[C_RSLIDERR] = (int(*)(ANYARGS))cmd_rsliderr;
    exs_addr[C_GSLIDERR] = (int(*)(ANYARGS))cmd_gsliderr;
    exs_addr[C_TOUCH] = (int(*)(ANYARGS))cmd_touch;
    exs_addr[C_RTOUCH] = (int(*)(ANYARGS))cmd_rtouch;
    exs_addr[C_GTOUCH] = (int(*)(ANYARGS))cmd_gtouch;
    exs_addr[C_ALLOC] = (int(*)(ANYARGS))cmd_alloc;
    exs_addr[C_FORGET] = (int(*)(ANYARGS))cmd_forget;
    exs_addr[C_CANCEL] = (int(*)(ANYARGS))cmd_cancel;

    exs_addr[COTOFN] = (int(*)(ANYARGS))ex_cotofn;
    exs_addr[ZXYI] = (int(*)(ANYARGS))ex_zxyi;
    exs_addr[ZXYA] = (int(*)(ANYARGS))ex_zxya;
    exs_addr[ZXYR] = (int(*)(ANYARGS))ex_zxyr;
    exs_addr[ZXYG] = (int(*)(ANYARGS))ex_zxyg;
    exs_addr[SKIP] = (int(*)(ANYARGS))ex_val;
    exs_addr[TPOINT] = (int(*)(ANYARGS))ex_val;
    exs_addr[TDOT] = (int(*)(ANYARGS))ex_val;
    exs_addr[ITOC] = (int(*)(ANYARGS))ex_itoc;
    exs_addr[FTOC] = (int(*)(ANYARGS))ex_ftoc;
    exs_addr[ILITERAL] = (int(*)(ANYARGS))ex_iliteral;
    exs_addr[FLITERAL] = (int(*)(ANYARGS))ex_fliteral;
    exs_addr[MLITERAL] = (int(*)(ANYARGS))ex_mliteral;
    exs_addr[MLITC] = (int(*)(ANYARGS))ex_mlitc;
    exs_addr[XGLOBALVAL] = (int(*)(ANYARGS))ex_iglobalval;
    exs_addr[XLOCALVAL] = (int(*)(ANYARGS))ex_ilocalval;
    exs_addr[XPASSVAL] = (int(*)(ANYARGS))ex_ipassval;
    exs_addr[XGARRAYVAL] = (int(*)(ANYARGS))ex_igarrayval;
    exs_addr[XLARRAYVAL] = (int(*)(ANYARGS))ex_ilarrayval;
    exs_addr[XPARRAYVAL] = (int(*)(ANYARGS))ex_iparrayval;
    exs_addr[XPARRAY] = (int(*)(ANYARGS))ex_xparray;
    exs_addr[GLOBALVAL] = (int(*)(ANYARGS))ex_globalval;
    exs_addr[IGLOBALVAL] = (int(*)(ANYARGS))ex_iglobalval;
    exs_addr[BGLOBALVAL] = (int(*)(ANYARGS))ex_bglobalval;
    exs_addr[MGLOBALVAL] = (int(*)(ANYARGS))ex_mglobalval;
    exs_addr[GLOBALADDR] = (int(*)(ANYARGS))ex_globaladdr;
    exs_addr[IGLOBALADDR] = (int(*)(ANYARGS))ex_globaladdr;
    exs_addr[BGLOBALADDR] = (int(*)(ANYARGS))ex_globaladdr;
    exs_addr[MGLOBALADDR] = (int(*)(ANYARGS))ex_globaladdr;
    exs_addr[GARRAYVAL] = (int(*)(ANYARGS))ex_garrayval;
    exs_addr[IGARRAYVAL] = (int(*)(ANYARGS))ex_igarrayval;
    exs_addr[BGARRAYVAL] = (int(*)(ANYARGS))ex_bgarrayval;
    exs_addr[MGARRAYVAL] = (int(*)(ANYARGS))ex_mgarrayval;
    exs_addr[GARRAYADDR] = (int(*)(ANYARGS))ex_garrayaddr;
    exs_addr[IGARRAYADDR] = (int(*)(ANYARGS))ex_igarrayaddr;
    exs_addr[BGARRAYADDR] = (int(*)(ANYARGS))ex_bgarrayaddr;
    exs_addr[MGARRAYADDR] = (int(*)(ANYARGS))ex_mgarrayaddr;
    exs_addr[LOCALVAL] = (int(*)(ANYARGS))ex_localval;
    exs_addr[ILOCALVAL] = (int(*)(ANYARGS))ex_ilocalval;
    exs_addr[BLOCALVAL] = (int(*)(ANYARGS))ex_blocalval;
    exs_addr[MLOCALVAL] = (int(*)(ANYARGS))ex_mlocalval;
    exs_addr[LOCALADDR] = (int(*)(ANYARGS))ex_localaddr;
    exs_addr[ILOCALADDR] = (int(*)(ANYARGS))ex_localaddr;
    exs_addr[BLOCALADDR] = (int(*)(ANYARGS))ex_localaddr;
    exs_addr[MLOCALADDR] = (int(*)(ANYARGS))ex_localaddr;
    exs_addr[LARRAYVAL] = (int(*)(ANYARGS))ex_larrayval;
    exs_addr[ILARRAYVAL] = (int(*)(ANYARGS))ex_ilarrayval;
    exs_addr[BLARRAYVAL] = (int(*)(ANYARGS))ex_blarrayval;
    exs_addr[MLARRAYVAL] = (int(*)(ANYARGS))ex_mlarrayval;
    exs_addr[LARRAYADDR] = (int(*)(ANYARGS))ex_larrayaddr;
    exs_addr[ILARRAYADDR] = (int(*)(ANYARGS))ex_ilarrayaddr;
    exs_addr[BLARRAYADDR] = (int(*)(ANYARGS))ex_blarrayaddr;
    exs_addr[MLARRAYADDR] = (int(*)(ANYARGS))ex_mlarrayaddr;
    exs_addr[PASSVAL] = (int(*)(ANYARGS))ex_passval;
    exs_addr[IPASSVAL] = (int(*)(ANYARGS))ex_ipassval;
    exs_addr[BPASSVAL] = (int(*)(ANYARGS))ex_bpassval;
    exs_addr[MPASSVAL] = (int(*)(ANYARGS))ex_mpassval;
    exs_addr[PASSADDR] = (int(*)(ANYARGS))ex_passaddr;
    exs_addr[IPASSADDR] = (int(*)(ANYARGS))ex_ipassaddr;
    exs_addr[BPASSADDR] = (int(*)(ANYARGS))ex_bpassaddr;
    exs_addr[MPASSADDR] = (int(*)(ANYARGS))ex_mpassaddr;
    exs_addr[PARRAYVAL] = (int(*)(ANYARGS))ex_parrayval;
    exs_addr[IPARRAYVAL] = (int(*)(ANYARGS))ex_iparrayval;
    exs_addr[BPARRAYVAL] = (int(*)(ANYARGS))ex_bparrayval;
    exs_addr[MPARRAYVAL] = (int(*)(ANYARGS))ex_mparrayval;
    exs_addr[PARRAYADDR] = (int(*)(ANYARGS))ex_parrayaddr;
    exs_addr[IPARRAYADDR] = (int(*)(ANYARGS))ex_iparrayaddr;
    exs_addr[BPARRAYADDR] = (int(*)(ANYARGS))ex_bparrayaddr;
    exs_addr[MPARRAYADDR] = (int(*)(ANYARGS))ex_mparrayaddr;

    exs_addr[GDYARRAYVAL] = (int(*)(ANYARGS))ex_gdyarrayval;
    exs_addr[EXS_GDYARRAYVAL] = (int(*)(ANYARGS))exs_gdyarrayval;
    exs_addr[GDYARRAYADDR] = (int(*)(ANYARGS))ex_gdyarrayaddr;
    exs_addr[EXS_GDYARRAYADDR] = (int(*)(ANYARGS))exs_gdyarrayaddr;
    exs_addr[IGDYARRAYVAL] = (int(*)(ANYARGS))ex_igdyarrayval;
    exs_addr[EXS_IGDYARRAYVAL] = (int(*)(ANYARGS))exs_igdyarrayval;
    exs_addr[IGDYARRAYADDR] = (int(*)(ANYARGS))ex_igdyarrayaddr;
    exs_addr[EXS_IGDYARRAYADDR] =(int(*)(ANYARGS)) exs_igdyarrayaddr;
    exs_addr[BGDYARRAYVAL] = (int(*)(ANYARGS))ex_bgdyarrayval;
    exs_addr[EXS_BGDYARRAYVAL] = (int(*)(ANYARGS))exs_bgdyarrayval;
    exs_addr[BGDYARRAYADDR] = (int(*)(ANYARGS))ex_igdyarrayaddr;
    exs_addr[EXS_BGDYARRAYADDR] = (int(*)(ANYARGS))exs_igdyarrayaddr;
    exs_addr[GDYARRAY] = (int(*)(ANYARGS))ex_gdyarray;
    exs_addr[IGDYARRAY] = (int(*)(ANYARGS))ex_gdyarray;
    exs_addr[BGDYARRAY] = (int(*)(ANYARGS))ex_gdyarray;
    exs_addr[EXS_GDYARRAY] = (int(*)(ANYARGS))exs_gdyarray;
    
    exs_addr[LDYARRAYVAL] = (int(*)(ANYARGS))ex_ldyarrayval;
    exs_addr[EXS_LDYARRAYVAL] = (int(*)(ANYARGS))exs_ldyarrayval;
    exs_addr[LDYARRAYADDR] = (int(*)(ANYARGS))ex_ldyarrayaddr;
    exs_addr[EXS_LDYARRAYADDR] = (int(*)(ANYARGS))exs_ldyarrayaddr;
    exs_addr[ILDYARRAYVAL] = (int(*)(ANYARGS))ex_ildyarrayval;
    exs_addr[EXS_ILDYARRAYVAL] = (int(*)(ANYARGS))exs_ildyarrayval;
    exs_addr[ILDYARRAYADDR] = (int(*)(ANYARGS))ex_ildyarrayaddr;
    exs_addr[EXS_ILDYARRAYADDR] = (int(*)(ANYARGS))exs_ildyarrayaddr;
    exs_addr[BLDYARRAYVAL] = (int(*)(ANYARGS))ex_bldyarrayval;
    exs_addr[EXS_BLDYARRAYVAL] = (int(*)(ANYARGS))exs_bldyarrayval;
    exs_addr[BLDYARRAYADDR] = (int(*)(ANYARGS))ex_ildyarrayaddr;
    exs_addr[EXS_BLDYARRAYADDR] = (int(*)(ANYARGS))exs_ildyarrayaddr;
    exs_addr[LDYARRAY] = (int(*)(ANYARGS))ex_ldyarray;
    exs_addr[ILDYARRAY] = (int(*)(ANYARGS))ex_ldyarray;
    exs_addr[BLDYARRAY] = (int(*)(ANYARGS))ex_ldyarray;
    exs_addr[EXS_LDYARRAY] = (int(*)(ANYARGS))exs_ldyarray;
    
    exs_addr[PDYARRAYVAL] = (int(*)(ANYARGS))ex_pdyarrayval;
    exs_addr[EXS_PDYARRAYVAL] = (int(*)(ANYARGS))exs_pdyarrayval;
    exs_addr[PDYARRAYADDR] = (int(*)(ANYARGS))ex_pdyarrayaddr;
    exs_addr[EXS_PDYARRAYADDR] = (int(*)(ANYARGS))exs_pdyarrayaddr;
    exs_addr[IPDYARRAYVAL] = (int(*)(ANYARGS))ex_ipdyarrayval;
    exs_addr[EXS_IPDYARRAYVAL] = (int(*)(ANYARGS))exs_ipdyarrayval;
    exs_addr[IPDYARRAYADDR] = (int(*)(ANYARGS))ex_ipdyarrayaddr;
    exs_addr[EXS_IPDYARRAYADDR] = (int(*)(ANYARGS))exs_ipdyarrayaddr;
    exs_addr[BPDYARRAYVAL] = (int(*)(ANYARGS))ex_bpdyarrayval;
    exs_addr[EXS_BPDYARRAYVAL] = (int(*)(ANYARGS))exs_bpdyarrayval;
    exs_addr[BPDYARRAYADDR] = (int(*)(ANYARGS))ex_ipdyarrayaddr;
    exs_addr[EXS_BPDYARRAYADDR] = (int(*)(ANYARGS))exs_ipdyarrayaddr;
    exs_addr[PDYARRAY] = (int(*)(ANYARGS))ex_pdyarray;
    exs_addr[IPDYARRAY] = (int(*)(ANYARGS))ex_pdyarray;
    exs_addr[BPDYARRAY] = (int(*)(ANYARGS))ex_pdyarray;
    
    exs_addr[GARRAY] = (int(*)(ANYARGS))ex_garray;
    exs_addr[IGARRAY] = (int(*)(ANYARGS))ex_garray;
    exs_addr[BGARRAY] = (int(*)(ANYARGS))ex_garray;
    exs_addr[MGARRAY] = (int(*)(ANYARGS))ex_garray;
    exs_addr[XGARRAY] = (int(*)(ANYARGS))ex_garray;
    exs_addr[LARRAY] = (int(*)(ANYARGS))ex_larray;
    exs_addr[ILARRAY] = (int(*)(ANYARGS))ex_larray;
    exs_addr[BLARRAY] = (int(*)(ANYARGS))ex_larray;
    exs_addr[MLARRAY] = (int(*)(ANYARGS))ex_larray;
    exs_addr[XLARRAY] = (int(*)(ANYARGS))ex_larray;
    exs_addr[PARRAY] = (int(*)(ANYARGS))ex_parray;
    exs_addr[IPARRAY] = (int(*)(ANYARGS))ex_iparray;
    exs_addr[BPARRAY] = (int(*)(ANYARGS))ex_bparray;
    exs_addr[MPARRAY] = (int(*)(ANYARGS))ex_mparray;
    exs_addr[ASSIGN] = (int(*)(ANYARGS))ex_assign;
    exs_addr[IASSIGN] = (int(*)(ANYARGS))ex_iassign;
    exs_addr[BASSIGN] = (int(*)(ANYARGS))ex_bassign;
    exs_addr[MASSIGN] = (int(*)(ANYARGS))ex_massign;
    exs_addr[PLUS] = (int(*)(ANYARGS))ex_plus;
    exs_addr[IPLUS] = (int(*)(ANYARGS))ex_iplus;
    exs_addr[IINC] = (int(*)(ANYARGS))ex_iinc;
    exs_addr[MINUS] = (int(*)(ANYARGS))ex_minus;
    exs_addr[IMINUS] = (int(*)(ANYARGS))ex_iminus;
    exs_addr[IDEC] = (int(*)(ANYARGS))ex_idec;
    exs_addr[UMINUS] = (int(*)(ANYARGS))ex_uminus;
    exs_addr[IUMINUS] = (int(*)(ANYARGS))ex_iuminus;
    exs_addr[TIMES] = (int(*)(ANYARGS))ex_times;
    exs_addr[ITIMES] = (int(*)(ANYARGS))ex_itimes;
    exs_addr[DIVIDE] = (int(*)(ANYARGS))ex_divide;
    exs_addr[IDIVR] = (int(*)(ANYARGS))ex_idivr;
    exs_addr[IDIVT] = (int(*)(ANYARGS))ex_idivt;
    exs_addr[LUNION] = (int(*)(ANYARGS))ex_lunion;
    exs_addr[LMASK] = (int(*)(ANYARGS))ex_lmask;
    exs_addr[LDIFF] = (int(*)(ANYARGS))ex_ldiff;
    exs_addr[LSHIFT] = (int(*)(ANYARGS))ex_lshift;
    exs_addr[RSHIFT] = (int(*)(ANYARGS))ex_rshift;
    exs_addr[ITOF] = (int(*)(ANYARGS))ex_itof;
    exs_addr[FTOI] = (int(*)(ANYARGS))ex_ftoi;
    exs_addr[MUNIT] = (int(*)(ANYARGS))ex_munit;
    exs_addr[NOT] = (int(*)(ANYARGS))ex_not;
    exs_addr[AND] = (int(*)(ANYARGS))ex_and;
    exs_addr[OR] = (int(*)(ANYARGS))ex_or;
    exs_addr[MOD] = (int(*)(ANYARGS))ex_mod;
    exs_addr[EXPONIC] = (int(*)(ANYARGS))ex_exponic;
    exs_addr[EXPONENT] = (int(*)(ANYARGS))ex_exponent;
    exs_addr[ARCTAN] = (int(*)(ANYARGS))ex_arctan;
    exs_addr[ARCTAN2] = (int(*)(ANYARGS))ex_arctan2;
    exs_addr[INT] = (int(*)(ANYARGS))ex_int;
    exs_addr[FRAC] = (int(*)(ANYARGS))ex_frac;
    exs_addr[ROUND] = (int(*)(ANYARGS))ex_round;
    exs_addr[SIGN] = (int(*)(ANYARGS))ex_sign;
    exs_addr[ISIGN] = (int(*)(ANYARGS))ex_isign;
    exs_addr[COMP] = (int(*)(ANYARGS))ex_comp;
    exs_addr[BITCNT] = (int(*)(ANYARGS))ex_bitcnt;
    exs_addr[ZRGBN] = (int(*)(ANYARGS))ex_zrgbn;
    exs_addr[ZHSVN] = (int(*)(ANYARGS))ex_zhsvn;
    exs_addr[ZLENGTH] = (int(*)(ANYARGS))ex_zlength;
    exs_addr[ZLENGTHM] = (int(*)(ANYARGS))ex_zlengthm;
    exs_addr[ZLENGTHF] = (int(*)(ANYARGS))ex_zlengthf;
    exs_addr[ZPOSITION] = (int(*)(ANYARGS))ex_zposition;
    exs_addr[MCAT] = (int(*)(ANYARGS))ex_mcat;
    exs_addr[ZCODE] = (int(*)(ANYARGS))ex_zcode;
    exs_addr[ZCHAR] = (int(*)(ANYARGS))ex_zchar;
    exs_addr[ZFIRST] = (int(*)(ANYARGS))ex_zfirst;
    exs_addr[ZLAST] = (int(*)(ANYARGS))ex_zlast;
    exs_addr[ZBASE] = (int(*)(ANYARGS))ex_zbase;
    exs_addr[ZNEXT] = (int(*)(ANYARGS))ex_znext;
    exs_addr[ZPREVIOUS] = (int(*)(ANYARGS))ex_zprevious;
    exs_addr[ZSTART] = (int(*)(ANYARGS))ex_zstart;
    exs_addr[ZEND] = (int(*)(ANYARGS))ex_zend;
    exs_addr[ZCOPY] = (int(*)(ANYARGS))ex_zcopy;
    exs_addr[ZALTERED] = (int(*)(ANYARGS))ex_zaltered;
    exs_addr[ZEXTENT] = (int(*)(ANYARGS))ex_zextent;
    exs_addr[ZSAMEMARK] = (int(*)(ANYARGS))ex_zsamemark;
    exs_addr[ZHASSTYLE] = (int(*)(ANYARGS))ex_zhasstyle;
    exs_addr[ZICONCODE] = (int(*)(ANYARGS))ex_ziconcode;
    exs_addr[ZICONFILE] = (int(*)(ANYARGS))ex_ziconfile;
    exs_addr[ZSEARCH] = (int(*)(ANYARGS))ex_zsearch;
    exs_addr[ZSETMARK] = (int(*)(ANYARGS))ex_zsetmark;
    exs_addr[ZTEXTAT] = (int(*)(ANYARGS))ex_ztextat;
    exs_addr[ZPRECEDE] = (int(*)(ANYARGS))ex_zprecede;
    exs_addr[ZTEXTSEL] = (int(*)(ANYARGS))ex_ztextsel;
    exs_addr[ZTEXTVIS] = (int(*)(ANYARGS))ex_ztextvis;
    exs_addr[ZEDITBASE] = (int(*)(ANYARGS))ex_zeditbase;
    exs_addr[ZHOTINFOE] = (int(*)(ANYARGS))ex_zhotinfoe;
	exs_addr[ZHOTINFOM] = (int(*)(ANYARGS))ex_zhotinfom;
    exs_addr[ZHOTSEL] = (int(*)(ANYARGS))ex_zhotsel;
    exs_addr[ZVALUEB] = (int(*)(ANYARGS))ex_zvalueb;
    exs_addr[ZVALUES] = (int(*)(ANYARGS))ex_zvalues;
    exs_addr[ZVALUEDDE] = (int(*)(ANYARGS))ex_zddetext;
    exs_addr[ZSWIDTH] = (int(*)(ANYARGS))ex_zswidth;
    exs_addr[ZSHEIGHT] = (int(*)(ANYARGS))ex_zsheight;
    exs_addr[ZKS] = (int(*)(ANYARGS))ex_zks;
    exs_addr[ZNEXTWORD] = (int(*)(ANYARGS))ex_znextword;
    exs_addr[ZNEXTEXPR] = (int(*)(ANYARGS))ex_znextexpr;
	exs_addr[ZNEXTNUM] = (int(*)(ANYARGS))ex_znextnum;
    exs_addr[ZNEXTLINE] = (int(*)(ANYARGS))ex_znextline;
    exs_addr[ZFILENAME] = (int(*)(ANYARGS))ex_zfilename;
    exs_addr[ZFILEPATH] = (int(*)(ANYARGS))ex_zfilepath;
    exs_addr[ZNICONS] = (int(*)(ANYARGS))ex_znicons;
    exs_addr[LT] = (int(*)(ANYARGS))ex_lt;
    exs_addr[GT] = (int(*)(ANYARGS))ex_gt;
    exs_addr[LE] = (int(*)(ANYARGS))ex_le;
    exs_addr[GE] = (int(*)(ANYARGS))ex_ge;
    exs_addr[EQ] = (int(*)(ANYARGS))ex_eq;
    exs_addr[NE] = (int(*)(ANYARGS))ex_ne;
    exs_addr[SPLT] = (int(*)(ANYARGS))ex_splt;
    exs_addr[SPGT] = (int(*)(ANYARGS))ex_spgt;
    exs_addr[SPLE] = (int(*)(ANYARGS))ex_sple;
    exs_addr[SPGE] = (int(*)(ANYARGS))ex_spge;
    exs_addr[SPEQ] = (int(*)(ANYARGS))ex_speq;
    exs_addr[SPNE] = (int(*)(ANYARGS))ex_spne;
    exs_addr[ILT] = (int(*)(ANYARGS))ex_ilt;
    exs_addr[IGT] = (int(*)(ANYARGS))ex_igt;
    exs_addr[ILE] = (int(*)(ANYARGS))ex_ile;
    exs_addr[IGE] = (int(*)(ANYARGS))ex_ige;
    exs_addr[IEQ] = (int(*)(ANYARGS))ex_ieq;
    exs_addr[INE] = (int(*)(ANYARGS))ex_ine;
    exs_addr[TXEQ] = (int(*)(ANYARGS))ex_txeq;
    exs_addr[TXNEQ] = (int(*)(ANYARGS))ex_txne;
    exs_addr[ISPLT] = (int(*)(ANYARGS))ex_isplt;
    exs_addr[ISPGT] = (int(*)(ANYARGS))ex_ispgt;
    exs_addr[ISPLE] = (int(*)(ANYARGS))ex_isple;
    exs_addr[ISPGE] = (int(*)(ANYARGS))ex_ispge;
    exs_addr[ISPEQ] = (int(*)(ANYARGS))ex_ispeq;
    exs_addr[ISPNE] = (int(*)(ANYARGS))ex_ispne;
    exs_addr[EXS_ISPLT] = (int(*)(ANYARGS))exs_isplt;
    exs_addr[EXS_ISPGT] = (int(*)(ANYARGS))exs_ispgt;
    exs_addr[EXS_ISPLE] = (int(*)(ANYARGS))exs_isple;
    exs_addr[EXS_ISPGE] = (int(*)(ANYARGS))exs_ispge;
    exs_addr[EXS_ISPEQ] = (int(*)(ANYARGS))exs_ispeq;
    exs_addr[EXS_ISPNE] = (int(*)(ANYARGS))exs_ispne;
    exs_addr[MLT] = (int(*)(ANYARGS))ex_mlt;
    exs_addr[MGT] = (int(*)(ANYARGS))ex_mgt;
    exs_addr[MLE] = (int(*)(ANYARGS))ex_mle;
    exs_addr[MGE] = (int(*)(ANYARGS))ex_mge;
    exs_addr[MEQ] = (int(*)(ANYARGS))ex_meq;
    exs_addr[MNE] = (int(*)(ANYARGS))ex_mne;
    exs_addr[MSPLT] = (int(*)(ANYARGS))ex_msplt;
    exs_addr[MSPGT] = (int(*)(ANYARGS))ex_mspgt;
    exs_addr[MSPLE] = (int(*)(ANYARGS))ex_msple;
    exs_addr[MSPGE] = (int(*)(ANYARGS))ex_mspge;
    exs_addr[MSPEQ] = (int(*)(ANYARGS))ex_mspeq;
    exs_addr[MSPNE] = (int(*)(ANYARGS))ex_mspne;
    exs_addr[SIN] = (int(*)(ANYARGS))ex_sin;
    exs_addr[COS] = (int(*)(ANYARGS))ex_cos;
    exs_addr[TAN] = (int(*)(ANYARGS))ex_tan;
    exs_addr[CSC] = (int(*)(ANYARGS))ex_csc;
    exs_addr[SECANT] = (int(*)(ANYARGS))ex_sec;
    exs_addr[COT] = (int(*)(ANYARGS))ex_cot;
    exs_addr[ARCSIN] = (int(*)(ANYARGS))ex_arcsin;
    exs_addr[ARCCOS] = (int(*)(ANYARGS))ex_arccos;
    exs_addr[ARCCSC] = (int(*)(ANYARGS))ex_arccsc;
    exs_addr[ARCSEC] = (int(*)(ANYARGS))ex_arcsec;
    exs_addr[ARCCOT] = (int(*)(ANYARGS))ex_arccot;
    exs_addr[SQRT] = (int(*)(ANYARGS))ex_sqrt;
    exs_addr[ABS] = (int(*)(ANYARGS))ex_abs;
    exs_addr[EXP] = (int(*)(ANYARGS))ex_exp;
    exs_addr[LOG] = (int(*)(ANYARGS))ex_log;
    exs_addr[ALOG] = (int(*)(ANYARGS))ex_alog;
    exs_addr[LN] = (int(*)(ANYARGS))ex_ln;
    exs_addr[SINH] = (int(*)(ANYARGS))ex_sinh;
    exs_addr[COSH] = (int(*)(ANYARGS))ex_cosh;
    exs_addr[TANH] = (int(*)(ANYARGS))ex_tanh;
    exs_addr[GAMMA] = (int(*)(ANYARGS))ex_gamma;
    exs_addr[IBRANCHT] = (int(*)(ANYARGS))ex_ibrancht;
    exs_addr[IBRANCHF] = (int(*)(ANYARGS))ex_ibranchf;
    exs_addr[SYSVAR] = (int(*)(ANYARGS))ex_sysvar;
    exs_addr[ISYSVAR] = (int(*)(ANYARGS))ex_isysvar;
    exs_addr[TSYSVAR] = (int(*)(ANYARGS))ex_tsysvar;
    exs_addr[MSYSVAR] = (int(*)(ANYARGS))ex_msysvar;
    exs_addr[MSYSVARA] = (int(*)(ANYARGS))ex_msysvara;
    exs_addr[EFUNCT] = (int(*)(ANYARGS))ex_efunct;
    exs_addr[STORINF] = (int(*)(ANYARGS))ex_storinf;
    exs_addr[TKEYWORD] = (int(*)(ANYARGS))ex_tkeyword;
    exs_addr[TEXTARG] = (int(*)(ANYARGS))ex_textarg;
    exs_addr[TEXTARG1] = (int(*)(ANYARGS))ex_textarg1;
    exs_addr[ULOCADDR] = (int(*)(ANYARGS))ex_ulocaddr;
    exs_addr[LOOPCHK] = (int(*)(ANYARGS))ex_loopchk;
    exs_addr[CCODE] = (int(*)(ANYARGS))ex_ccode;
	exs_addr[DCODE] = (int(*)(ANYARGS))ex_dcode;
    exs_addr[ZCOMB] = (int(*)(ANYARGS))ex_zcomb;
    exs_addr[ZFACTORIAL] = (int(*)(ANYARGS))ex_zfactorial;
        
    exs_addr[EXS_ARRAYERR] = (int(*)(ANYARGS))ex_arrayerr;
    exs_addr[EXS_EXPONIC] = (int(*)(ANYARGS))exs_exponic;
    exs_addr[EXS_SYSVAR] = (int(*)(ANYARGS))exs_sysvar;
    exs_addr[EXS_ISYSVAR] = (int(*)(ANYARGS))exs_isysvar;
    exs_addr[EXS_TSYSVAR] = (int(*)(ANYARGS))exs_tsysvar;
    exs_addr[EXS_MSYSVAR] = (int(*)(ANYARGS))exs_msysvar;
    exs_addr[EXS_MSYSVARA] = (int(*)(ANYARGS))exs_msysvara;
    exs_addr[EXS_MGLOBALVAL] = (int(*)(ANYARGS))exs_mglobalval;
    exs_addr[EXS_MLOCALVAL] = (int(*)(ANYARGS))exs_mlocalval;
    exs_addr[EXS_PARRAY] = (int(*)(ANYARGS))exs_pass_array_inf;
    exs_addr[EXS_GARRAYVAL] = (int(*)(ANYARGS))exs_garrayval;
    exs_addr[EXS_GARRAYADDR] = (int(*)(ANYARGS))exs_garrayaddr;
    exs_addr[EXS_IGARRAYVAL] = (int(*)(ANYARGS))exs_igarrayval;
    exs_addr[EXS_IGARRAYADDR] = (int(*)(ANYARGS))exs_igarrayaddr;
    exs_addr[EXS_BGARRAYVAL] = (int(*)(ANYARGS))exs_bgarrayval;
    exs_addr[EXS_BGARRAYADDR] = (int(*)(ANYARGS))exs_bgarrayaddr;
    exs_addr[EXS_MGARRAYVAL] = (int(*)(ANYARGS))exs_mgarrayval;
    exs_addr[EXS_MGARRAYADDR] = (int(*)(ANYARGS))exs_mgarrayaddr;
    exs_addr[EXS_LARRAYVAL] = (int(*)(ANYARGS))exs_larrayval;
    exs_addr[EXS_LARRAYADDR] = (int(*)(ANYARGS))exs_larrayaddr;
    exs_addr[EXS_ILARRAYVAL] = (int(*)(ANYARGS))exs_ilarrayval;
    exs_addr[EXS_ILARRAYADDR] = (int(*)(ANYARGS))exs_ilarrayaddr;
    exs_addr[EXS_BLARRAYVAL] = (int(*)(ANYARGS))exs_blarrayval;
    exs_addr[EXS_BLARRAYADDR] = (int(*)(ANYARGS))exs_blarrayaddr;
    exs_addr[EXS_MLARRAYVAL] = (int(*)(ANYARGS))exs_mlarrayval;
    exs_addr[EXS_MLARRAYADDR] = (int(*)(ANYARGS))exs_mlarrayaddr;
    exs_addr[EXS_MLITERAL] = (int(*)(ANYARGS))exs_mliteral;
    exs_addr[EXS_MLITC] = (int(*)(ANYARGS))exs_mlitc;
    exs_addr[EXS_STORINF] = (int(*)(ANYARGS))exs_storinf;
    exs_addr[EXS_PARRAYVAL] = (int(*)(ANYARGS))exs_parrayval;
    exs_addr[EXS_IPARRAYVAL] = (int(*)(ANYARGS))exs_iparrayval;
    exs_addr[EXS_BPARRAYVAL] = (int(*)(ANYARGS))exs_bparrayval;
    exs_addr[EXS_MPARRAYVAL] = (int(*)(ANYARGS))exs_mparrayval;
    exs_addr[EXS_PARRAYADDR] = (int(*)(ANYARGS))exs_parrayaddr;
    exs_addr[EXS_IPARRAYADDR] = (int(*)(ANYARGS))exs_iparrayaddr;
    exs_addr[EXS_BPARRAYADDR] = (int(*)(ANYARGS))exs_iparrayaddr; /* deliberate */
    exs_addr[EXS_MPARRAYADDR] = (int(*)(ANYARGS))exs_mparrayaddr;
    exs_addr[EXS_EFUNCT] = (int(*)(ANYARGS))exs_efunct;
    exs_addr[EXS_SPLT] = (int(*)(ANYARGS))exs_splt;
    exs_addr[EXS_SPGT] = (int(*)(ANYARGS))exs_spgt;
    exs_addr[EXS_SPLE] = (int(*)(ANYARGS))exs_sple;
    exs_addr[EXS_SPGE] = (int(*)(ANYARGS))exs_spge;
    exs_addr[EXS_SPEQ] = (int(*)(ANYARGS))exs_speq;
    exs_addr[EXS_SPNE] = (int(*)(ANYARGS))exs_spne;
    exs_addr[EXS_MSPLT] = (int(*)(ANYARGS))exs_msplt;
    exs_addr[EXS_MSPGT] = (int(*)(ANYARGS))exs_mspgt;
    exs_addr[EXS_MSPLE] = (int(*)(ANYARGS))exs_msple;
    exs_addr[EXS_MSPGE] = (int(*)(ANYARGS))exs_mspge;
    exs_addr[EXS_MSPEQ] = (int(*)(ANYARGS))exs_mspeq;
    exs_addr[EXS_MSPNE] = (int(*)(ANYARGS))exs_mspne;
    exs_addr[EXS_MPASSVAL] = (int(*)(ANYARGS))exs_mpassval;
    exs_addr[EXS_MPASSADDR] = (int(*)(ANYARGS))exs_mpassaddr;
    exs_addr[EXS_STOREADDR] = (int(*)(ANYARGS))exs_storeaddr;
    exs_addr[EXS_FLOATINIT] = (int(*)(ANYARGS))exs_floatinit;
    exs_addr[EXS_XGLOBALVAL] = (int(*)(ANYARGS))exs_xglobalval;
    exs_addr[EXS_XLOCALVAL] = (int(*)(ANYARGS))exs_xlocalval;
    exs_addr[EXS_XPASSVAL] = (int(*)(ANYARGS))exs_xpassval;
    
#ifdef Nosuch
    exs_addr[EXS_LOCALP] = (*((int(*)())NULL));
    exs_addr[EXS_GLOBALP] = (*((int(*)())NULL));
    exs_addr[EXS_ISTACK] = (*((int(*)())istack));
    exs_addr[EXS_IRESP] = (*((int(*)())&iresP));
    exs_addr[EXS_FSTACK] = (*((int(*)())fstack));
    exs_addr[EXS_FRESP] = (*((int(*)())&fresP));
    exs_addr[EXS_BINP] = (*((int(*)())&ex_binP));
    exs_addr[EXS_PCODEP] = (*((int(*)())&pcodep));
#endif
    assign_pfun((long)&exs_addr[EXS_LOCALP],(long)NULL);
    assign_pfun((long)&exs_addr[EXS_GLOBALP],(long)NULL);
    assign_pfun((long)&exs_addr[EXS_ISTACK],(long)istack);
    assign_pfun((long)&exs_addr[EXS_IRESP],(long)&iresP);
    assign_pfun((long)&exs_addr[EXS_FSTACK],(long)fstack);
    assign_pfun((long)&exs_addr[EXS_FRESP],(long)&fresP);
    assign_pfun((long)&exs_addr[EXS_BINP],(long)&ex_binP);
    assign_pfun((long)&exs_addr[EXS_PCODEP],(long)&pcodep);
   

#ifdef WERKS
#ifdef __MC68K__
    if (macCoPr) {
		exs_addr[EXS_FLOATINIT] = (int(*)(ANYARGS))lcfinita;
		exs_addr[UMINUS] = (int(*)(ANYARGS))lcfumina;
		exs_addr[ABS] = (int(*)(ANYARGS))lcfabsa;
		exs_addr[PLUS] = (int(*)(ANYARGS))lcfadda;
		exs_addr[MINUS] = (int(*)(ANYARGS))lcfsuba;
		exs_addr[TIMES] = (int(*)(ANYARGS))lcfmulta;
		exs_addr[DIVIDE] = (int(*)(ANYARGS))lcfdiva;
/*		exs_addr[SQRT] = (int(*)(ANYARGS))lcfsqrta; */
		exs_addr[SIN] = (int(*)(ANYARGS))lcfsina;
		exs_addr[COS] = (int(*)(ANYARGS))lcfcosa;
		exs_addr[TAN] = (int(*)(ANYARGS))lcftana;
    } /* macCoPr if */
#endif
#endif

#ifdef THINKC5
    if (macCoPr) {
		exs_addr[EXS_FLOATINIT] = (int(*)(ANYARGS))lcfinita;
		exs_addr[UMINUS] = (int(*)(ANYARGS))lcfumina;
		exs_addr[ABS] = (int(*)(ANYARGS))lcfabsa;
		exs_addr[PLUS] = (int(*)(ANYARGS))lcfadda;
		exs_addr[MINUS] = (int(*)(ANYARGS))lcfsuba;
		exs_addr[TIMES] = (int(*)(ANYARGS))lcfmulta;
		exs_addr[DIVIDE] = (int(*)(ANYARGS))lcfdiva;
		exs_addr[SQRT] = (int(*)(ANYARGS))lcfsqrta;
		exs_addr[SIN] = (int(*)(ANYARGS))lcfsina;
		exs_addr[COS] = (int(*)(ANYARGS))lcfcosa;
		exs_addr[TAN] = (int(*)(ANYARGS))lcftana;
    } /* macCoPr if */
#endif

} /* exec_iprocs */


/* ******************************************************************* */

#ifdef MAC

int FAR *InitMIDITab() /* initialize freq->midi conversion table */

{	int MIDItab[129] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
		17, 18, 19, 21, 22, 
		23, 24, 26, 27, 29, 31, 33, 35, 
		37, 39, 41, 44, 46, 49, 52, 55, 
		58, 62, 65, 69, 73, 78, 82, 87, 
		92, 98, 104, 110, 117, 123, 131, 139, 
		147, 156, 165, 175, 185, 196, 208, 220, 
		233, 247, 262, 277, 294, 311, 330, 349, 
		370, 392, 415, 440, 466, 494, 523, 554, 
		587, 622, 659, 698, 740, 784, 831, 880, 
		932, 988, 1046, 1109, 1175, 1244, 1318, 1397, 
		1480, 1568, 1661, 1760, 1864, 1975, 2093, 2217, 
		2349, 2489, 2637, 2794, 2960, 3136, 3322, 3520, 
		3729, 3951, 4186, 4434, 4698, 4978, 5274, 5587, 
		5919, 6271, 6644, 7039, 7458, 7901, 8371, 8869, 
		9396, 9955, 10547, 11174, 11839, 12543, 13288 }; 
	int FAR *tabP; /* pointer to table */
	long size; /* size of table */
	
	size = 129*sizeof(int);
	tabP = (int FAR *)TUTORalloc(size,FALSE,"midi");
	if (tabP)
		TUTORblock_move((char FAR *)&MIDItab[0],(char FAR *)tabP,size);
	return(tabP);
		
} /* InitMIDITab */

#else

int FAR *InitMIDITab() { return(FARNULL); }

#endif

/* ******************************************************************* */
