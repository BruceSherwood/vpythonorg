
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>
#include "baseenv.h"
#include "kdefs.h"
#include "editmenu.h"
#include "tutor.h"
#include "editor.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "edglobal.h"
#include "txt.h"
#include "txtv.h"
#include "fkeys.h"
#include "kglobals.h"
#include "exprdefs.h" /* for TXEDIT ? */

#ifdef MAC
#ifdef THINKC5
#include <Windows.h>
#else
#ifdef WERKS
#include <Windows.h>
#else
#include <WindowMgr.h>
#endif
#endif
#endif

#ifndef MAC
#define PC_PASTE
#endif

#ifdef ctproto
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,
 int ebsref,struct  _trect *theR,int  relInfo,int  mintw,int  wrap,
 unsigned int  doc,long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),
 int  ro,int  corner,int  erase,int  frame,int tabsz,int lm,int rm,int inhss,int type);
extern int TUTORupmove_tview(Memh theV,TPoint where);  
int  TUTORpush_event(struct  tutorevent *event);
int  CTinq_closest_color(int  wn,double  redF,double  greenF,double  blueF,int  hsvf);
static int CvtTextColor(struct tutorColor FAR *tColor);
int  procexecw(unsigned int  execH,struct  tutorevent *event);
extern void TUTORset_color(int select,struct tutorColor FAR *newColor);
int  TUTORset_textfont(int  jj);
extern int TUTORset_button_font(Memh bH);
extern int DocBuffer(Memh ddd);
extern int  TUTORset_cursor(int  cInd,int  cChar);
extern int TUTORtrace(char *str);
extern int TUTORzero(char SHUGE *ptr,long length);
extern int TUTORset_sub_new(int sub,int new);
extern int setedittouch(struct tutorevent FAR *event);
int  TUTORinq_background_color(struct tutorColor *fc);
int  TUTORget_colors(struct tutorColor *fcx,struct tutorColor *bcx,struct tutorColor *wcx);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
int  TUTORset_comb_rule(int  rule);
int get_edit_ref(Memh eH);
int  TUTORinsert_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nIns);
int  AtTStyle(unsigned int  pd,long  pos,short  *styles);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,
 int ebsref,struct  _trect *theR,int  relInfo,int  mintw,int  wrap,
 unsigned int  doc,long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),
 int  ro,int  corner,int  erase,int  frame,int tabsz,int lm,int rm,int inhss,int type);
extern int  TUTORadd_edit_doc(unsigned int  doc,unsigned int  edit);
extern int  TUTORremove_edit_doc(unsigned int  doc,unsigned int  edit);
int  TUTORinq_select_line(unsigned int  theV,int  yy,long  *lineS,long  *lineL);
int  PanelEvent(unsigned int  edH,struct  tutorevent *event);
extern int  SetCaretPanel(struct  _tvdat FAR *vp,long  pos,int  kind,int  data);
extern int  CountDeletes(unsigned char  FAR *cp0,int  *nKeys,int  *offset);
int  TUTORinsert_file_tview(struct  _tvdat FAR *vp,struct  _fref FAR *newFile,int type);
int  RestartPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  selStart,long  selLen);
int  TUTORmaintain_doc_view(struct  _ktd FAR *dp,long  pos,long  len,long  cpos,long  clen,long  newC);
int  RefreshPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  cpos,long  clen,long  newC,long  selStart,long  selLen,int  scroll,int force);
extern int  Refresh1Panel(struct  _tvdat FAR *vp,long  pos,long  len,long  cpos,long  clen,long  newC,long  selStart,long  selLen,int  scroll,int force);
int  SetSelectPanel(struct  _tvdat FAR *vp,long  pos,long  len);
extern int  ActivatePanel(struct  _tvdat FAR *vp,int  aFlag,int  toView,int  setCursor);
int  DrawPanel(unsigned int  edH);
extern int  RedrawPanel(struct  _tvdat FAR *vp);
extern int  KeyPanel(struct  _tvdat FAR *vp,struct  tutorevent *event,long  startSelect,long  lenSelect);
extern int  TypeNewline(struct  _tvdat FAR *vp,unsigned char  *newls,long  startSelect,long  lenSelect);
extern int  specialkey(struct  _tvdat FAR *vp,int  ky,long  startSelect,long  lenSelect);
int  TUTORclose_panel(unsigned int  theV);
extern int  n_editornexts(struct  _tvdat FAR *vp,unsigned char  *ss,int  tellUser,int  direction);
extern int  n_editorsrt(struct  _tvdat FAR *vp,unsigned char  *ss,unsigned char  *rs,int  option,int  dir,long  curPos,long  curLen);
double  PanelScroll(struct  tutorview FAR *tview,int  hv,double  fn,int  type);
extern int  startcaret(struct  _tvdat FAR *vp,long  btime);
extern int  StartSearch1(struct  _tvdat FAR *vp,unsigned int  textH);
extern int  ResizeTextV(struct  _tvdat FAR *vp,int  delV);
extern int  DrawSearch1(struct  _tvdat FAR *vp,int  cFlag,unsigned int  textH);
extern unsigned int  MakeSearchPanel(struct  _tvdat FAR *vp,struct  _trect *tr2,int  relInfo,int  offset,unsigned int  textH);
extern int  KFilterSearch(long  ownerDat,unsigned int  textv,struct  tutorevent *cev);
extern int  SearchClick(struct  _tvdat FAR *vp,struct  tutorevent *event);
extern int  EndSearch1(struct  _tvdat FAR *vp,int  doDraw,unsigned int  textH);
extern int  GetSearchString2(struct  _tvdat FAR *vp,int  whichS,unsigned char  *ss,int  maxLen);
int  BeforeDialog(struct  _tvdat FAR *vp);
int  AfterDialog(struct  _tvdat FAR *vp,int  updateFlag);
int  EditorDefaultStyles(unsigned int  doc);
int  TUTORset_view(struct  tutorview FAR *vp);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  TUTORset_abs_view_rect(int  x1,int  y1,int  w,int  h);
int  TUTORset_abs_clip_rect(struct  _trect FAR *cr);
char  FAR *GetPtr(unsigned int  mm);
unsigned int  TUTORnew_tview(struct  tutorview FAR *ownerV,unsigned int  doc,long  pos,long  len,
struct  _trect FAR *vRect,int  style,int  dWidth,int  wordWrap,int inhss);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORmake_rel_rect(struct  tutorview FAR *viewP,struct  _trect *theR,int  inf,struct  _trect *relR);
int  TUTORoptimize_rect(struct  _trect FAR *rect);
int  TUTORinset_rect(struct  _trect FAR *rr,int  xx,int  yy);
int  CTset_window_color(int  cn);
int  CTset_background_color(int  color);
struct  tutorview FAR *TUTORinq_view(void);
struct  tutorview FAR *TUTORinit_view(int  sW,unsigned int  vDat,int  (*vProc)());
int  PanelEventStub(unsigned int  panelH,struct  tutorevent *event);
int  TUTORset_rect(struct  _trect *r,int  left,int  top,int  right,int  bottom);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
unsigned int  MakeScrollBar(struct  tutorview FAR *ovp,int  ew,unsigned int  ebshdrH,int ebsref,int  textF,int  sbType,int  info,struct  _trect *relRect,double  (*scrollProc)(),int  erase);
double  PanelScrollstub(struct  tutorview FAR *tview,int  hv,double  nn,int  type);
int  TUTORget_default_styles_doc(unsigned int  doc,short  FAR *defStyles);
int  TUTORclick_tview(unsigned int  theV,struct  _tpoint where,int  extend);
int  TUTORdump(char  *s);
int  TUTORinq_select_tview(unsigned int  theV,long  *pos,long  *len);
int  TUTORdefault_styles_doc(unsigned int  doc,short  FAR *defStyles);
long  TUTORsearch_string_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sLen,long  pos,long  posEnd);
long  _TUTORline_pos_tview(struct  _viewp FAR *tvp,int  lineN);
int  _TUTORinq_line_tview(unsigned int  theV,int  vv);
int  TUTORclose_doc(unsigned int  doc);
int  TUTORsave_do_doc(unsigned int  doc,long  pos,long  len,int  op,long  newLen);
int  TUTORstyle_doc(unsigned int  doc,long  pos,long  len,int  type,int  dat,int  canCombine,long  *extraPos);
int  CancelTrigger(int  id);
int  TUTORclose_sbar(unsigned int  theSBar);
int  TUTORclose_tview(unsigned int  theV);
int  set_last_edit(unsigned int  objH,int refcnt);
int  TUTORclick_drag_tview(unsigned int  theV,struct  _tpoint newWhere);
int  TUTORreset_text_sbar(unsigned int  sbi,struct  _sbarinf *sinf,int  doDraw);
int  TUTORclick_done_tview(unsigned int  theV,struct  _sbarinf *vb);
int  _TUTORget_styles_doc(struct  _ktd FAR *dp,long  pos,short  *curStyles);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORflush(void);
int  _TUTORdraw_caret_tview(struct  _viewp FAR *tvp,int  mess);
int  TUTORpost_event(struct  tutorevent *event);
int  TUTORstyle_hot_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *ss,long  sLen);
int  TUTORedit_dialog(int  wn,char  *msg,char  FAR *retS1,char *msg2,char  FAR *retS2,int  maxRet);
int  TUTORcompress_darray(unsigned int  da,int  offset);
int  _TUTORinternal_marker(struct  markvar FAR *mp,unsigned int  stackH,long  rloc);
int  TUTORframe_abs_rect(struct  _trect FAR *tr);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
int  TUTORclose(int  findx);
int  TUTORfread_graphic_doc(unsigned int  doc,int  type,int  find);
int  TUTORfread_doc(unsigned int  doc,long  len,int  docKind,int  fInd);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  strcmpf(char  FAR *aa,char  FAR *bb);
int  strlenf(char  FAR *aa);
int  TUTORupdate_tview(unsigned int  theV);
int  _TUTORhilite_select(unsigned int  theV,int  onoff);
int  TUTORset_select_tview(unsigned int  theV,long  pos,long  len,struct  _sbarinf *vb);
int  TUTORchange_tview(unsigned int  theV,long  pos,long  len,long  rpos,long  rlen,long  newC,long  selS,long  selL,struct  _sbarinf *vb,int force);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
int  TUTORobscure_cursor(void);
int  TUTORresize_tview(unsigned int  theV,struct  _trect FAR *vRect,int  dWidth,struct  _sbarinf *sbv,struct  _sbarinf *sbh);
int  TUTORuse_rel_rect(struct  _trect FAR *rRect,int  inf,struct  tutorview FAR *viewP,struct  _trect *sRect);
int  drawscrollbar(unsigned int  theSbar);
int  _TUTORinfo_vbar_tview(struct  _viewp FAR *tvp,struct  _sbarinf *vb);
int  _TUTORinfo_hbar_tview(struct  _viewp FAR *tvp,struct  _sbarinf *sbh);
int  TUTORchange_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,unsigned char  FAR *cp,long  cLen,long  fromOff,unsigned int  styles,unsigned int  specialT,long  *extraPos,int  eupFlag);
int  TUTORdelete_doc(unsigned int  doc,long  pos,long  len,long  *extraPos);
int  TUTORwhere_pix_tview(unsigned int  theV,struct  _ps FAR *posp);
int  TUTORto_clip_doc(unsigned int  doc,long  pos,long  len,int  doCut,long  *extraPos);
int  TUTORundo_doc(unsigned int  doc,long  *pos,long  *len,long  mpos,long  mlen,long  *newLen,long  *extraChange);
int  _TUTORscrollh_tview(unsigned int  theV,int  offset);
long  TUTORfrom_clip_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,long  *extraPos,int  saveDo);
int  TUTORbeep(int  *ff,int  *dur,int  *volume,int  nbeep);
int  TUTORresume_cursor(void);
long  _TUTORsearch_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sGood,long  sLen,unsigned int  strSpecial,long  strSOff,long  pos,long  posEnd,unsigned char  FAR *cTable);
int  TUTORwait_cursor(void);
int  TUTORclose_view(struct  tutorview FAR *vp);
int  TUTORtrace_n(char  *s,long  nn);
long  _TUTORscrollv_tview(unsigned int  theV,int  stype,long  arg);
int  TUTORmove_rect(struct  _trect FAR *rr,int  xx,int  yy);
int  TUTORdraw_text(unsigned char  FAR *buf,int  count);
int  TUTORabs_move_to(int  x,int  y);
int  TUTORmove_button(unsigned int  bH,int  left,int  top,int  right,int  bottom);
unsigned int  TUTORnew_button(int  wn,unsigned int  owner,unsigned int  objH,int objR,struct  _trect *tr,int  kind,
      int  thick,int  bFont,char  *title,Memh titleD,unsigned int  destH,int  (*DestProc)(),int  destMsg,
      int  destMsg1,double  destMsg2,int erase);
int  TUTORclear_doc(unsigned int  doc);
int  TUTORclose_button(unsigned int  bH);
int  TUTORpoint_in_rect(struct  _tpoint pt,struct  _trect *r);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
int  AddParaLayout(struct  _paral *pl);
int  TUTORinq_abs_string_width(unsigned char  FAR *s,int  lth,int  *dx);
int  TUTORset_textfont2(long  family,int  size,int  face);
int  TUTORforce_redraw(int  wix);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
int  mvar_temp_cleanup(void);
int  TUTORget_colors(struct tutorColor *fcx,struct tutorColor *bcx,struct tutorColor *wcx);
#endif /* ctproto */

#ifdef macproto
extern int MarkStyleMenus(TextVDat FAR *vp, int flag);
extern int TUTORclip_window(int wind);
long MacFileType(FileRef FAR *fRef);
int  TUTORinq_abs_clip_rect(struct  _trect *cr);
#endif

extern long _TUTORline_pos_tview();
extern long TUTORget_len_doc();
extern long TUTORfrom_clip_doc();
extern Memh TUTORnew_doc();
extern long _TUTORsearch_doc();
extern long TUTORsearch_string_doc();

#ifdef MAC
#ifdef THINKC5
#include <Menus.h>
#else
#ifdef WERKS
#include <Menus.h>
#else
#include <MenuMgr.h>
#endif
#endif
#define SCROLLSIZE 16
#define SCROLLMIN 8
#else
#ifdef DOSPC
#define SCROLLSIZE 16
#define SCROLLMIN 8
#else
#define SCROLLSIZE 20
#define SCROLLMIN 10
#endif
#endif

#define SEARCHSIG 56
#define SEARCHFWD 1
#define SEARCHBACK 2
#define SEARCHCANCEL 3

#define SEARCH1SPACE 5 /* vertical space between items */
#define SEARCH1PHEIGHT 30 /* height of search & replace panels */
#define SEARCH1BHEIGHT 20 /* height of search buttons */

#define SEARCH1HEIGHT (SEARCH1PHEIGHT+2*SEARCH1BHEIGHT+4*SEARCH1SPACE)
#define SEARCH1EXTRA (SEARCH1PHEIGHT+SEARCH1SPACE)

extern int PanelEventStub();

extern double  PanelScrollstub();
extern double  PanelScroll();
extern Memh MakeScrollBar();
extern Memh MakeTextPanel();
extern struct tutorview FAR *TUTORinit_view();
extern struct tutorview FAR *TUTORinq_view();
extern Memh TUTORnew_button();
extern Memh MakeSearchPanel();

extern Memh TUTORnew_tview();
extern long _TUTORscrollv_tview();
int KFilterSearch();

static Memh searchAllDoc=0, replaceAllDoc=0; /* global docs to remember last search strings */

/* ******************************************************************* */
Memh MakeTextPanel(wn,owner,ebshdrH,ebsref,theR,relInfo,mintw,wrap,doc,pos,len,
wantV,wantH,KeyF,readOnly,corner,erase,frame,tabsz,lm,rm,inhss,type)
int wn;     /* window # */
long owner; /* used as argument for filter routine */
Memh ebshdrH;   /* handle on cT object header */
int ebsref; /* reference count on cT object header */
TRect *theR;    /* where text panel will go (if doesn't exist, whole window) */
int relInfo;    /* resizing info for panel */
int mintw; /* minimum layout width for text view */
int wrap;   /* TRUE if we want lines to break on word boundaries */
Memh doc; /* existing document for text view */
long pos,len;   /* region of document where we want view */
int wantV,wantH;    /* flags for creation of vertical & horizontal scroll bars */
int (*KeyF) (); /* event filter procs */
int readOnly; /* TRUE if read-only */
int corner; /* TRUE if need to leave corner (usually on mac for grow icon) */
int erase; /* TRUE if need to erase panel on close */
int frame; /* TRUE if need a frame around text panel */
int tabsz; /* number pixels/tab, or -1 for default */
int lm; /* left margin, or -1 for default */
int rm; /* right margin, or -1 for default */
int inhss; /* TRUE if should inhibit sup/sub line height adjustment */
int type; /* 0 = editor */
          /* 1 = -edit- */
          /* 2 = -arrow- */
          /* 3 = -text- (actually C_TEXTM) */
          /* 4 = dialog box */
          /* 5 = help, dict */
          /* 6 = message */
          /* 7 = debug */
    {
    short style;    /* machine dependent style (MAC, PC or ANDREW) */
    int info;   /* resizing info */
    TRect panelR;   /* rect where we want text panel */
    TRect tempR;    /* modified copy of panelR, for setting up text view */
    TRect tempRel;  /* relative rectangle */
    TRect tempAbs;  /* abolute rectangle (for optimizing panel) */
    Memh newEdit;   /* the new text panel */
    REGISTER TextVDat FAR *vp;  /* pointer to text panel (newEdit) */
    REGISTER TViewP tvp;    /* pointer to tview */
    struct tutorview FAR *cv;   /* for saving & restoring view */
    int lwidth; /* initial text layout width */
    int xsize,ysize; /* x/y size of panel */
    int scroll_size; /* scroll bar size (smaller dimension) */
    struct tutorColor dfcolor; /* default foreground color */
    int dspmode; /* display mode (write,rewrite,etc) */
    int defaultXoff,defaultYoff; /* default offsets */
    TRect clipR; /* clip rectangle for -textm- */
    int euI; /* index in event-unit stuff */
    int supsubH,newlineH;
    struct tutorColor fc,bc,ec;
	
#ifdef KSWnotnow
    if (theR && (theR->right - theR->left < 10 || theR->bottom - theR->top < 10))
        { /* not enough space */
        return(HNULL);
        }
#endif
    scroll_size = SCROLLSIZE; /* default size */
    supsubH = -1; /* default */
    newlineH = 0;
    
    /* view machinery assumes document buffer is big enough for */
    /* enough characters to make one line across the window */
    /* add items to expand darray */
    
    DocBuffer(doc);
      
    newEdit = TUTORhandle("textvdat",(long) sizeof(TextVDat),TRUE);
    vp = (TextVDat FAR *) GetPtr(newEdit);
    TUTORzero((char FAR *)vp,(long)sizeof(TextVDat));

    if (!theR) {
        TUTORset_rect(&panelR, 0,0,windowsP[wn].wxsize,windowsP[wn].wysize);
        vp->absRect = panelR;
    } else {
        vp->absRect = *theR;
        TUTORset_rect(&panelR,theR->left+1,theR->top+1,theR->right-1,theR->bottom-1);
    }
    
    vp->self = newEdit;
    vp->ebshdrH = ebshdrH; /* handle on cT object header (if any) */
    vp->ebsref = ebsref; /* unique id */
    vp->scrollh = vp->scrollv = HNULL; /* no scroll bars, yet */
    
    if (type == 3) /* get parent's clip region */
        TUTORinq_abs_clip_rect(&clipR);

    /* set up text view */
    cv = TUTORinq_view();
    vp->view = TUTORinit_view(wn,newEdit,PanelEventStub);
    TUTORset_view(vp->view);
    vp->view->tabSize = tabsz; /* set view tab size (or -1) */
    vp->view->objectH = newEdit; /* view's handle on object */
    vp->view->objectT = TXEDIT;
    dfcolor.palette = color_defaultf; /* assume default if no parent */
    dspmode = -1;
    if (cv) {
        if (type == 3)  /* -textm- */
            dspmode = cv->CurrentMode;
        TUTORblock_move((char FAR *)&cv->fgndColor,(char FAR *)&dfcolor,
                        (long)sizeof(struct tutorColor));
        /* set to parent's colors */
        TUTORset_color(0,&cv->fgndColor);
        TUTORset_color(1,&cv->bgndColor);
        TUTORset_color(2,&cv->winColor);
        supsubH = cv->SupSub;
        newlineH = cv->newlineH;
        TUTORset_sub_new(supsubH,newlineH);
    }

    /* calculate rectangle for text view */
    tempR = panelR;
    if ((type == 3))
        defaultXoff = defaultYoff = 0; /* no offset for -textm- */
    else defaultXoff = defaultYoff = 3;
    /* inset to leave some margin around text */
    TUTORinset_rect((TRect FAR *) &tempR,defaultXoff,defaultYoff); 
    /* if the margins are changed, also change the compensation in CreateArrowView */
    
    if (lm >= 0)
        tempR.left = tempR.left-3+lm;
    if (rm >= 0)
        tempR.right = tempR.right+3-rm;
        
    if (wantV) {
        if ((tempR.right-tempR.left) < 3*scroll_size)
            scroll_size = SCROLLMIN; /* minimum size */
        tempR.right -= scroll_size;
    }
    if (wantH) {
        if ((tempR.bottom-tempR.top) < 3*scroll_size)
            scroll_size = SCROLLMIN; /* minimum size */
        tempR.bottom -= scroll_size;
    } if (wantV || wantH) {
        tempAbs = tempR;
        TUTORoptimize_rect(&tempAbs);
        tempR.left += tempAbs.left-tempR.left;
        tempR.right += tempAbs.right-tempR.right;
    }
    TUTORmake_rel_rect(vp->view,&tempR,relInfo,&tempRel);
    vp->relRect = tempRel;
    vp->sizeInfo = relInfo;
    if (type == 3) /* -textm- */
        vp->dispMode = dspmode;
    else
        vp->dispMode = -1; /* pre-set default display mode */

#ifndef MAC
#ifdef IBMPC
    style = PCSTYLE;
#else
    style = isx11 ? PCSTYLE : ANDREWSTYLE;
#endif
#else
    style = MACSTYLE;
#endif

    vp->minDest = mintw;
    lwidth = tempR.right - tempR.left + 1;
    if (lwidth < mintw)
        lwidth = mintw;
    
    if (len < 0) /* if len is < 0, we want to end of doc */
        len = TUTORget_len_doc(doc) - pos;
    vp->textv = TUTORnew_tview(vp->view,doc,pos,len,(TRect FAR *) &tempR,style,
                lwidth,wrap,inhss);

    /* set proper rects for view */
    TUTORset_view(vp->view);
    tvp = (TViewP) GetPtr(vp->textv);
    if (type == 3)
        TUTORset_abs_clip_rect((TRect FAR *)&clipR); /* set to parent's clip */
    else TUTORset_abs_clip_rect(&tvp->viewRect);
    tvp->eraseRect = vp->absRect;
    TUTORset_abs_view_rect(tvp->viewRect.left,tvp->viewRect.top,
            tvp->viewRect.right - tvp->viewRect.left+1,tvp->viewRect.bottom-tvp->viewRect.top+1);
    /* set scrollable flags for view */
    tvp->scrollH = wantH;
    tvp->scrollV = wantV;
    if (wantV)
        tvp->eraseRect.right -= scroll_size;
    if (wantH)
        tvp->eraseRect.bottom -= scroll_size;
    tvp->editcmd = (type == 1); /* TRUE if -edit- command */
    tvp->arrowcmd = (type == 2); /* TRUE if -arrow- command */
    tvp->textmcmd = (type == 3); /* TRUE if -textm- command */
    tvp->dialog = (type == 4); /* TRUE if text panel in dialog box */
    tvp->dict = (type == 5); /* TRUE if dictionary or help */
	tvp->message = (type == 6); /* TRUE if message window */
	tvp->debug = (type == 7); /* TRUE if debug expression panel */
    tvp->dispMode = vp->dispMode; /* write/rewrite/etc mode */
    tvp->newLine = newlineH; /* newline height */
    tvp->dySupSub = supsubH; /* superscript, subscript height */
    tvp->fColor = dfcolor; /* default foreground color */
    ReleasePtr(vp->textv);
    KillPtr(tvp);
    
    TUTORset_view(cv); /* set back to parent view */
 
    vp->textd = doc;
    vp->readOnly = readOnly;
    vp->caretSet = FALSE;
    vp->searchState = 1; /* can search, but currently in normal edit state */
    vp->searchDir = TRUE; /* forward */
    vp->searchExact = TRUE; /* exact match on search */
    vp->alteredc = 0;
    vp->eActive = FALSE;
    vp->blinkid = vp->inhibitState = 0;
    vp->keySelect = FALSE;
    vp->focusClick = FALSE;
    vp->absorbFClick = TRUE; /* absorb focus click */
    vp->highSel = TRUE; /* highlight selection */
    vp->singleSel = FALSE; /* don't select on single click */
    vp->doErase = erase;
    TUTORget_colors(&fc,&bc,&ec);
    vp->ecolor.palette = ec.palette;
    vp->ecolor.red = ec.red;
    vp->ecolor.green = ec.green;
    vp->ecolor.blue = ec.blue;
    vp->doFrame = frame;
    vp->nextPanel = HNULL; /* no panel following this one in doc's edit chain */
    TUTORget_default_styles_doc(doc,(short FAR *) vp->defStyles); /* copy doc's default styles */
    if (wn == ExecWn) {
	vp->defStyles[COLORSTYLE] = dfcolor.palette; /* take color from view (may be rgb) */
    }
#ifdef THINKC5
    vp->KeyFilter = (int(*)(...))(KeyF);
#else
    vp->KeyFilter = (int(*)())(KeyF);
#endif
    vp->ClickFilter = FARNULL;
    vp->ownerDat = owner;
    vp->hotunitF = 0; /* no associated unit for hot text */
    vp->hotunitN = 0;
    vp->hotunitA = 0.0;
    for(euI=0; euI<12; euI++) {
        vp->eventunitF[euI] = vp->eventunitN[euI] = 0;
        vp->eventunitA[euI] = 0.0;
    } /* for */

#ifdef MAC
    if (!theR && wantH && wantV)
        vp->drawGrow = TRUE;
    else
        vp->drawGrow = FALSE;
    vp->styleMenu = HNULL; /* no style menu */
#else
    vp->drawGrow = FALSE; /* no grow icon */
#endif
    
    if (wantV) { /* create vertical scroll bar */
        tempR = panelR;
        tempR.left = tempR.right - (scroll_size-1);
#ifdef MAC
        if (corner || wantH)
            tempR.bottom -= (scroll_size-1);
#endif
        info = relInfo & (TOPSTICK | BOTTOMSTICK);
        if (relInfo & RIGHTSTICK)
            info |= RIGHTSTICK;
        else
            info |= LEFTSTICK;
        TUTORmake_rel_rect(vp->view,&tempR,info,&tempRel);
        vp->scrollv = MakeScrollBar(vp->view,wn,0,0,TRUE,SBVERT,info,&tempRel,PanelScrollstub,erase);
    }
    if (wantH) { /* create horizontal scroll bar */
        tempR = panelR;
        tempR.top = tempR.bottom - (scroll_size-1);
        if (wantV || corner)
            tempR.right -= (scroll_size-1);
        info = relInfo & (LEFTSTICK | RIGHTSTICK);
        if (relInfo & BOTTOMSTICK)
            info |= BOTTOMSTICK;
        else
            info |= TOPSTICK;
        TUTORmake_rel_rect(vp->view,&tempR,info,&tempRel);
        vp->scrollh = MakeScrollBar(vp->view,wn,0,0,TRUE,SBHORIZ,info,&tempRel,PanelScrollstub,erase);
    }
    
    vp->curActive = newEdit; /* self (since no search panels yet) */
    
    ReleasePtr(newEdit);
    KillPtr(vp);
    TUTORset_view(cv); /* restore caller's view */
    
    TUTORadd_edit_doc(doc,newEdit); /* add this text panel to doc's edit chain */
    
    return(newEdit);

} /* MakeTextPanel */

int get_edit_ref(objH) /* get cT edit object reference count */
Memh objH; /* handle on cT object */

{   struct ebshdr FAR *objP; /* pointer to object header */
    Memh edH; /* handle on edit panel */
    TextVDat FAR *edP;  /* pointer to text panel */
    int refcnt; /* reference count on text panel */
    
    if (!objH)
        return(0);
    objP = (struct ebshdr FAR *)GetPtr(objH);
    edH = objP->objectH; /* handle on edit panel */
    ReleasePtr(objH); 
    KillPtr(objP);
    if (!edH)
        return(0);
    edP = (TextVDat FAR *)GetPtr(edH); 
    refcnt = edP->ebsref; /* get reference count from panel */
    ReleasePtr(edH);
    return(refcnt);
    
} /* get_edit_ref */    

static TUTORadd_edit_doc(doc,edit)  /* add edit panel to doc's chain */
Memh doc;   /* document we are adding to */
Memh edit;  /* panel to add */
    {
    REGISTER DocP dp;   /* pointer to document */
    REGISTER TextVDat FAR *vp;  /* pointer to text panel */
    Memh nextPanel, curPanel;   /* pointers for going thru linked list */
    
    dp = (DocP) GetPtr(doc);
    if (!dp->editPanel)
        dp->editPanel = edit;
    else
        { /* more than one panel on this doc */
        nextPanel = dp->editPanel;
        vp = (TextVDat FAR *) GetPtr(nextPanel);
        while (vp->nextPanel)
            { /* go to end of chain */
            curPanel = nextPanel;
            nextPanel = vp->nextPanel;
            ReleasePtr(curPanel);
            KillPtr(vp);
            vp = (TextVDat FAR *) GetPtr(nextPanel);
            }
        vp->nextPanel = edit;
        ReleasePtr(nextPanel);
        KillPtr(vp);
        
        /* and tell edit that it isn't the only one */
        vp = (TextVDat FAR *) GetPtr(edit);
        ReleasePtr(edit);
        KillPtr(vp);
        }
    ReleasePtr(doc);
    KillPtr(dp);
    
    return(0);
    }

static TUTORremove_edit_doc(doc,edit)   /* remove edit panel from doc's chain */
Memh doc;   /* document whose edit chain we are modifying */
Memh edit;  /* text panel to be removed */
    {
    REGISTER DocP dp;   /* pointer to document (doc) */
    REGISTER TextVDat FAR *vp;  /* pointer to text panel */
    Memh nextPanel, curPanel;   /* for going thru linked list */
    Memh editNext; /* the panel that edit (which we're removing) points to */
    int deldoc; /* TRUE if should close document (no longer in use) */
    
    vp = (TextVDat FAR *) GetPtr(edit);
    editNext = vp->nextPanel;
    ReleasePtr(edit);
    KillPtr(vp);
    
    deldoc = FALSE;
    dp = (DocP) GetPtr(doc);
    if (!dp->editPanel) {
    	ReleasePtr(doc);
    	return(0);
    }
    if (dp->editPanel == edit)
        { /* panel we are closing was head of chain */
        dp->editPanel = editNext;
        }
    else
        {
        nextPanel = dp->editPanel;
        vp = (TextVDat FAR *) GetPtr(nextPanel);
        
        while (nextPanel && (vp->nextPanel != edit))
            {
            curPanel = nextPanel;
            nextPanel = vp->nextPanel;
            ReleasePtr(curPanel);
            KillPtr(vp);
            if (nextPanel)
       			vp = (TextVDat FAR *) GetPtr(nextPanel);
            }
        if (nextPanel) {
        	vp->nextPanel = editNext;
        	ReleasePtr(nextPanel);
        }
        KillPtr(vp);
        }
    if ((dp->nUsers == 0) && (dp->editPanel == 0))
        deldoc = TRUE; /* set to close document */
    ReleasePtr(doc);
    KillPtr(dp);
    
    if (deldoc) 
        TUTORclose_doc(doc);

    return(0);
    }

TUTORinq_select_line(theV,yy,lineS,lineL)   /* get line boundaries of vertical position */
Memh theV;  /* text panel we want to count lines in */
int yy;     /* vertical position */
long *lineS, *lineL;    /* to be set to start & len of line */
/* returns line # */
{
    TViewP tvp; /* pointer to text panel */
    int lineN;  /* line # corresponding to vertical position */
    int nNewlines;  /* # of newlines in document, preceeding the layout top */
    DocP dp;    /* pointer to document */
    unsigned char tempS[2]; /* target of search string */
    long pos, end; /* bounds of search to count newlines */
    long found; /* position of found newline */
    
    if (!theV)
        {
        *lineS = *lineL = 0L;
        return(0);
        }
    
    lineN = _TUTORinq_line_tview(theV,yy);
    tvp = (TViewP) GetPtr(theV);
    *lineS = _TUTORline_pos_tview(tvp,lineN);
    *lineL = tvp->ld[lineN].nDraw;
    
    /* lineN (so far) is relative to layout start... */
    if (tvp->layoutTop > tvp->bounds.pos)
        { /* we need to count newlines that preceede the layout top */
        pos = tvp->bounds.pos;
        end = tvp->layoutTop;
        nNewlines = 0;
        dp = (DocP) GetPtr(tvp->doc);
        tempS[0] = NEWLINE;
        while (pos < end)
            {
            found = TUTORsearch_string_doc(dp,(unsigned char FAR *) tempS,1L,pos,end);
            if (found < 0)
                break; /* no more */
            nNewlines++;
            pos = found+1;
            }
        ReleasePtr(tvp->doc);
        KillPtr(dp);
        lineN += nNewlines;
        }
    
    ReleasePtr(theV);
    KillPtr(tvp);
    
    return(lineN);
}

int PanelEvent(edH,event)   /* event processor for edit portion of panel */
Memh edH;   /* edit panel */
register struct tutorevent *event; /* event to process */
{
    TPoint mousep;  /* current mouse x/y position */
    register long startSelect, lenSelect; /* selection region */
    long extraPos, extraPosBack;    /* region of extra changes due to paragraph styles */
    unsigned char mstr[MSGTEXTL+2]; /* message line string */
    register int ii;    /* index for save, checkpoint */
    struct tutorevent ctvevent; /* blink, conversion event */
    int jj,ll;  /* work variables */
    REGISTER TextVDat FAR *vp;  /* pointer to editable text info */
    TViewP tvp; /* pointer to tview */
    unsigned char searchS[MSGTEXTL+2], replaceS[MSGTEXTL+2];    /* search & replace strings */
    int atStart;    /* TRUE if view selection is at beginning of view marker */
    long tempL, tempL2, tempL3;
    SBarInfo sbi;   /* vertical scroll bar info */
    int cmdFlg; /* TRUE if cT command (arrow, edit, etc) */
    struct ebshdr FAR *ebsP; /* pointer to object header */     
    int hiInactive; /* TRUE if should highlight when inactive (err or step) */
  
    if (!edH)
        return(0);
    
    mousep.hh = event->x;
    mousep.vv = event->y;
    vp = (TextVDat FAR *) GetPtr(edH);
    
  	if (event->type != EVENT_DESTROY) {
    	if (vp->ebshdrH) {
    		ebsP = (struct ebshdr FAR *)GetPtr(vp->ebshdrH);
    		if (ebsP->inhibitF) 
    			event->type = -1; /* suppress event if object inhibited */
    		ReleasePtr(vp->ebshdrH);
    	}
    }
    
    /* make sure styles are in synch */
    TUTORdefault_styles_doc(vp->textd,(short FAR *) vp->defStyles);
    
    atStart = TUTORinq_select_tview(vp->textv,&tempL,&tempL2);
    startSelect = tempL;
    lenSelect = tempL2;
    
    if (vp->caretSet && !(event->type == EVENT_MENU && event->a1 == edit_region) &&
            event->type != EVENT_KEY && event->type != EVENT_TIME)
        {
        vp->caretSet = FALSE; /* caret styles now invalid */
#ifdef MAC
        MarkStyleMenus(vp,1);
#endif
        }
    
    /* stop execution and/or query if focus now on editor */

    switch (event->type) {

    case EVENT_SIGNAL:
        if (event->a1 != SEARCHSIG)
            break; /* unknown signal */
        TUTORset_view(vp->view);
        if (event->value == SEARCHCANCEL)
            EndSearch1(vp,TRUE,(Memh) 0); /* cancel first state */
        else if (event->value == SEARCHFWD || event->value == SEARCHBACK)
            { /* finish first state, start next */
            EndSearch1(vp,TRUE,edH); /* close down dialog */
            GetSearchString2(vp,2,searchS,MSGTEXTL);
            n_editornexts(vp,searchS,TRUE,event->value == SEARCHFWD);
            vp->searchDir = (event->value == SEARCHFWD);
            vp->searchState = 1; /* didn't find anything */
            }
        else
            TUTORdump("Unrecognized search signal");
        break;

    case EVENT_REDRAW:
        tvp = (TViewP) GetPtr(vp->textv);
        cmdFlg = tvp->arrowcmd;
        ReleasePtr(vp->textv);
        KillPtr(tvp);
        if (cmdFlg)
        	break; /* don't redraw for arrow-driven panel */
        RedrawPanel(vp);
        break;

    case EVENT_LEFTDOWN:
    case EVENT_RIGHTDOWN:
        if (vp->ebshdrH)
            setedittouch(event);
        if (vp->focusClick)
            break; /* throw away the focus click */

        if (vp->searchState == 2)
            { /* search dialog in progress */
            SearchClick(vp,event);
            break;
            }
        if (vp->ClickFilter && ((*vp->ClickFilter) (vp->ownerDat,edH,event)))
            break; /* filter took care of click */
        TUTORclick_tview(vp->textv,mousep,(event->type == EVENT_RIGHTDOWN) ? TRUE: FALSE);
        break;

    case EVENT_LEFTUP:
    case EVENT_RIGHTUP:
        if (vp->ebshdrH)
            setedittouch(event);
        if (vp->focusClick)
            { /* this is the end of the focus click.  Throw away event
                and reset to normal state */
            vp->focusClick = FALSE;
            break;
            }
        vp->keySelect = FALSE;
        if (vp->ClickFilter && ((*vp->ClickFilter) (vp->ownerDat,edH,event)))
            ; /* filter took care of click */
        else
            {
            jj = TUTORclick_done_tview(vp->textv,&sbi);
            if (vp->scrollv && jj)
                TUTORreset_text_sbar(vp->scrollv,&sbi,TRUE);
            }
#ifdef MAC
        MarkStyleMenus(vp,0);
#endif
        break;

	case EVENT_UPMOVE:
		if (vp->upHot) {
			TUTORupmove_tview(vp->textv,mousep);  
        }
		break;
		
    case EVENT_DOWNMOVE:
        if (vp->ebshdrH)
            setedittouch(event);
        if (vp->focusClick)
            break; /* we are throwing away the focus click */
        
        if (vp->ClickFilter && ((*vp->ClickFilter) (vp->ownerDat,edH,event)))
            break; /* filter took care of click */
        TUTORclick_drag_tview(vp->textv,mousep);
        break;

#ifndef MAC
#ifndef IBMPC
#ifndef PC_PASTE
    case EVENT_PASTE:   /* paste and replace (only on unix) */
        if (event->dp) {
            tvp = (TViewP) GetPtr(vp->textv);
            extraPos = n_editorpaste(vp->ro,vp->textd,startSelect,lenSelect,tvp->bounds.pos,
                    tvp->bounds.len,event->dp,(long) event->value, event->a1, &tempL);
            ReleasePtr(vp->textv);
            KillPtr(tvp);
            if (extraPos < 0)
                break; /* nothing done in editorpaste */
            RefreshPanel(vp,startSelect,extraPos-startSelect,startSelect,lenSelect,
                tempL,startSelect+tempL,0L,TRUE,FALSE);
        } /* dp if */
        break;
#endif
#endif
#endif

    case EVENT_FWD: /* select/deselect of edit view */
        if (event->value && vp->view != windowsP[vp->view->window].KeyFocus)
            break; /* only activate view with key focus */   
        tvp = (TViewP) GetPtr(vp->textv);  
        hiInactive = tvp->hiInactive;
        ReleasePtr(vp->textv);
		if ((vp->eActive != event->value) && (!hiInactive))
            ActivatePanel(vp,event->value,TRUE,TRUE);
	break;

    case EVENT_VFOCUS:
	if (vp->eActive == (event->value & 1))
            break; /* focus already set */
        ActivatePanel(vp,event->value & 1,TRUE,TRUE);
        if (event->value && (event->value & 2) && vp->absorbFClick) /* we got focus because of click */
            vp->focusClick = TRUE; /* discard the rest of this click */
#ifndef CTEDIT
        if (vp->ebshdrH)
            set_last_edit(vp->ebshdrH,vp->ebsref); 
#endif
        break;
    
    case EVENT_DESTROY: /* close down panel */
        if (vp->searchState == 2)
            EndSearch1(vp,FALSE,(Memh) 0); /* get rid of search dialog */

        TUTORclose_tview(vp->textv); /* closes view but not document */
        /* the owner of the view will have to close document */
        if (vp->scrollh)
            TUTORclose_sbar(vp->scrollh); /* close horizontal scroll */
        if (vp->scrollv)
            TUTORclose_sbar(vp->scrollv); /* close vertical scroll */
        if (vp->blinkid)
            CancelTrigger(vp->blinkid); /* stop blink time event */
        /* TUTORforce_redraw(vp->view->window); -- needed? */
        
        break;

    case EVENT_MSG:
    case EVENT_MENU:
        switch (event->a1) {
        
        case edit_search:
            StartSearch1(vp,edH);
            break;

        case edit_searchd:
            if (vp->readOnly && event->a2 != 0 && event->a2 != 4)
                break; /* no changes allowed in read-only doc */
                        
            if (!GetSearchString2(vp,2,searchS,MSGTEXTL))
                break;
            if (event->a2 == 0 || event->a2 == 4)
                {
                vp->searchDir = (event->a2 == 0);
                n_editornexts(vp,searchS,TRUE,vp->searchDir);
                }
            else
                {
                if (!GetSearchString2(vp,3,replaceS,MSGTEXTL))
                    break;
                n_editorsrt(vp,searchS,replaceS,event->a2-1,vp->searchDir,startSelect, lenSelect);
                }
            break;

        case edit_plain: /* set style to plainest */
            if (vp->readOnly) break; /* exit if read only */
            for (jj=0; jj<NSTYLES; jj++)
                TUTORstyle_doc(vp->textd,startSelect,lenSelect,jj,DEFSTYLE,FALSE,&extraPos);
            RefreshPanel(vp,startSelect,extraPos - startSelect,startSelect,0L,0L,startSelect,lenSelect,TRUE,FALSE);
            TUTORsave_do_doc(HNULL,0L,0L,0,0L); /* can't undo */
            break;

        case edit_region: /* style */
            if (vp->readOnly)
                break; /* no change allowed */
                
            jj = event->a3;
            if (jj == HOTSTYLE && lenSelect == 0)
                break; /* we don't allow hotStyle on caret */
            if (lenSelect > 0 || jj == PARASTYLE)
                { /* change style of region */
                if (jj == PARASTYLE)
                    ll = JUSTMASK;
                else if (jj == FONTSTYLE)
                    ll = FALSE;
                else
                    ll = TRUE;
                if (jj != HOTSTYLE || event->a2 == DEFSTYLE)
                    TUTORstyle_doc(vp->textd,startSelect,lenSelect,jj,event->a2,ll,&extraPos);
                else
                    { /* adding hot style, need to run dialog */
                    mstr[0] = '\0'; /* empty string to start with */
                    BeforeDialog(vp);
                    ll = TUTORedit_dialog(vp->view->window,"Hot text:",(char FAR *) mstr,
                            NEARNULL,FARNULL,MSGTEXTL);
                    mstr[MSGTEXTL] = '\0'; /* insure terminating zero */
                    AfterDialog(vp,TRUE);
                    if (!ll)
                        break; /* cancelled */
                    tempL = strlen((char *) mstr);
                    TUTORstyle_hot_doc(vp->textd,startSelect,lenSelect,
                            (unsigned char FAR *) mstr, tempL);
                    extraPos = startSelect + lenSelect;
                    }
                RefreshPanel(vp,startSelect,extraPos - startSelect,startSelect,0L,0L,startSelect,lenSelect,TRUE,FALSE);
                TUTORsave_do_doc(HNULL,0L,0L,0,0L); /* can't undo */
                }
            else
                { /* set caret style */
                SetCaretPanel(vp,startSelect,jj,event->a2);
                }
            break;
            

        } /* menu switch */
        break;

    case EVENT_FKEY:
    case EVENT_KEY:
        if (vp->KeyFilter && ((*vp->KeyFilter) (vp->ownerDat,vp->textv,event)))
            break; /* filter took care of keys */
        if (event->type == EVENT_KEY)
            KeyPanel(vp,event,startSelect,lenSelect);
        else
            specialkey(vp,event->value,startSelect,lenSelect);
        break;

    case EVENT_TIME:
        switch (event->value) {

        case time_blink:
			vp->blinkid = 0;
	    	if (vp->eActive) {
#ifdef MAC
                event->timestamp = GetCaretTime() *1000/60; 
#else
                event->timestamp = 500; /* 1/2 second */
#endif
                tvp = (TViewP) GetPtr(vp->textv);
				if (!tvp->message) /* don't blink in message window */
                	vp->blinkid = TUTORpost_event(event);
				if (!windowsP[event->window].iconified) 
					_TUTORdraw_caret_tview(tvp,0);
                ReleasePtr(vp->textv);
                KillPtr(tvp);
            } 
            break;

        } /* time switch */
        break;
    
    } /* event switch */
    TUTORflush();
    ReleasePtr(edH);
    KillPtr(vp);
    if (event->type == EVENT_DESTROY)
        TUTORfree_handle(edH);

    return 0;

} /* PanelEvent */

static SetCaretPanel(vp,pos,kind,data)  /* set style of caret */
REGISTER TextVDat FAR *vp;  /* pointer to text panel */
long pos;   /* position where caret is */
int kind;   /* kind of style (FACESTYLE, FONTSTYLE, etc.) we are setting */
int data;   /* data of style */
    {
    short curStyles[NSTYLES];   /* current styles at pos */
    DocP dp;    /* pointer to document */
    register int ii;
    
    if (kind == HOTSTYLE)
        return(0); /* we don't allow caret to have a hot style */

    if (!vp->caretSet)
        { /* find out what styles are at pos */
        dp = (DocP) GetPtr(vp->textd);
        if (dp->styles)
            AtTStyle(dp->styles,pos,curStyles);
        else
            {
            for (ii=0; ii<NSTYLES; ii++)
                curStyles[ii] = DEFSTYLE;
            curStyles[SIZESTYLE] = 0;
            }
        ReleasePtr(vp->textd);
        KillPtr(dp);
        
        for (ii=0; ii<NSTYLES; ii++)
            vp->caretStyle[ii] = curStyles[ii];
        
        vp->caretSet = TRUE;
        }
    
    if (kind == FACESTYLE && vp->caretStyle[FACESTYLE] != DEFSTYLE)
        vp->caretStyle[FACESTYLE] ^= data;
    else if (kind == SIZESTYLE)
        vp->caretStyle[SIZESTYLE] += data;
    else
        vp->caretStyle[kind] = data;
    
#ifdef MAC
        MarkStyleMenus(vp,0);
#endif

    return(0);
    }

/* ******************************************************************* */

TUTORinsert_file_tview(vp,newFile,fType) /* insert file */
TextVDat FAR *vp;   /* pointer to text panel */
FileRef FAR *newFile;   /* reference to file to be inserted */
int fType; /* -1 = unknown, 0 = text, 1 = monochrome bitmap, 2 = color image */
    {
    Memh tempDoc;   /* document filled with material to be inserted */
    int fi; /* file index */
    long pos, len;  /* current selection */
    long mpos, mlen;    /* "marker" of entire edit region */
    TViewP tvp; /* pointer to tview */
    long newChars;  /* length of file (in characters) that we are inserting */
   long extraPos;  /* actual end of change (due to style changes) */
    int type;   /* 0: text, 1: native graphic, 2: cT font, 3: fdb, 4: color graphic */
    int ii;

    /* determine type of file that is being inserted */
    
    ii = strlenf((char FAR *) newFile->path);
    ii -= 4; /* so refers to where .xxx would start */

	type = 0; /* if not recognized, assume text */
#ifdef MAC
    if (MacFileType(newFile) == 'PICT') {
        type = 1;
        if (fType == 2) type = 4; /* color pict */
    } else if (ii >= 0 && 0 == strcmpf((char FAR *) newFile->path+ii,(char FAR *) ".fdb"))
        type = 3;
    else if (ii >= 0 && 0 == strcmpf((char FAR *)newFile->path+ii,(char FAR *)".ppm"))
		type = 4;
    else if (ii >= 0 && 0 == strcmpf((char FAR *)newFile->path+ii,(char FAR *)".PPM"))
		type = 4;
#endif
    if (ii >= 0 && 0 == strcmpf((char FAR *) newFile->path+ii,(char FAR *) ".fdb"))
        type = 3;
    else if (ii >= 0 && 0 == strcmpf((char FAR *) newFile->path+ii,(char FAR *) ".fct"))
        type = 2;
#ifdef DOSPC
    else if (ii >= 0 && 0 == strcmpf((char FAR *) newFile->path+ii,(char FAR *) ".pcx"))
        type = 1;
    else if (ii >= 0 && 0 == strcmpf((char FAR *) newFile->path+ii,(char FAR *) ".fpc"))
		type = 2;
#endif
#ifdef WINPC
    else if (ii >= 0 && 0 == strcmpf((char FAR *) newFile->path+ii,(char FAR *) ".PCX"))
        type = 1;
    else if (ii >= 0 && 0 == strcmpf((char FAR *) newFile->path+ii,(char FAR *) ".FPC"))
		type = 2;
    else if (ii >= 0 && 0 == strcmpf((char FAR *) newFile->path+ii,(char FAR *) ".pcx"))
        type = 1;
    else if (ii >= 0 && 0 == strcmpf((char FAR *) newFile->path+ii,(char FAR *) ".fpc"))
		type = 2;
    else if (ii >= 0 && 0 == strcmpf((char FAR *)newFile->path+ii,(char FAR *)".bmp"))
		type = 4;
    else if (ii >= 0 && 0 == strcmpf((char FAR *)newFile->path+ii,(char FAR *)".BMP"))
		type = 4;
	else if (ii >= 0 && 0 == strcmpf((char FAR *)newFile->path+ii,(char FAR *)".dib"))
		type = 4;
    else if (ii >= 0 && 0 == strcmpf((char FAR *)newFile->path+ii,(char FAR *)".DIB"))
		type = 4;
#endif
#ifdef X11
    else if (ii >= 0 && 0 == strcmpf((char FAR *)newFile->path+ii,(char FAR *)".fpc"))
		type = 2;
    else if (ii >= 0 && 0 == strcmpf((char FAR *)newFile->path+ii,(char FAR *)".FPC"))
		type = 2;
#endif

    /* open the file */
    fi = TUTORopen(newFile,TRUE,FALSE,FALSE);
    if (!fi)
        return;
    
    /* document to be filled with the file we are inserting */
    tempDoc = TUTORnew_doc(TRUE,TRUE);
    if (!tempDoc)
        { /* couldn't get document!?! */
        TUTORclose(fi);
        return;
        }
    
    /* read the file */
    if (type == 0)
        TUTORfread_doc(tempDoc,-1L,-1,fi);
    else
        TUTORfread_graphic_doc(tempDoc,type,fi);
    TUTORclose(fi);
    
    /* insert new document into old */
    
    /* get the "marker" bounds */
    tvp = (TViewP) GetPtr(vp->textv);
    mpos = tvp->bounds.pos;
    mlen = tvp->bounds.len;
    ReleasePtr(vp->textv);
    KillPtr(tvp);
    
    newChars = TUTORget_len_doc(tempDoc); /* # of chars we are adding */
    
    /* what is current selection */ 
    TUTORinq_select_tview(vp->textv,&pos,&len);
    TUTORchange_doc_doc(vp->textd,pos,len,mpos,mlen,tempDoc,0L,
            TUTORget_len_doc(tempDoc),&extraPos,FALSE);
    
    TUTORclose_doc(tempDoc); /* we don't need it anymore */

    extraPos += len - newChars; /* convert to position in doc BEFORE change */
    RefreshPanel(vp,pos,extraPos-pos,pos,len,
                    newChars,pos+newChars,0L,TRUE,FALSE);

    return;
    }
    
/* ******************************************************************* */

RestartPanel(vp,pos,len,selStart,selLen) /* useful when document completely replaced */
REGISTER TextVDat FAR *vp;  /* pointer to panel */
register long pos,len;  /* region of document where we want view now */
long selStart, selLen;  /* selection region desired */
    {
    SBarInfo sbi;   /* vertical scroll bar info */
    REGISTER TViewP tvp;    /* pointer to tview */
    int markClosed; /* TRUE if bounds marker was closed */
   
    tvp = (TViewP) GetPtr(vp->textv);
    tvp->txtvH.dAnn = 0; /* invalidate all linestarts */
    tvp->layoutTop = tvp->layoutBottom = pos; /* nothing is laid out */
    TUTORdraw_abs_solid_rect(&tvp->viewRect,PAT_BACKGROUND); /* erase view */
    tvp->caretState = 0; /* since hilighting was erased */

    if (vp->doFrame) {
        TUTORset_abs_clip_rect(&vp->absRect);
        TUTORframe_abs_rect((TRect FAR *)&vp->absRect);
        TUTORset_abs_clip_rect(&tvp->viewRect);
    } /* frame if */
    
    /* set up bounds marker again */
    tvp->bounds.pos = pos;
    tvp->bounds.doclen = TUTORget_len_doc(vp->textd);
    if (len < 0)
        len = tvp->bounds.doclen - pos;
    tvp->bounds.len = len;
    tvp->bounds.alteredF = FALSE;
    markClosed = (tvp->bounds.doc == 0);
    tvp->bounds.doc = tvp->doc = vp->textd;
    DocBuffer(vp->textd); 
    if (markClosed)
        { /* marker was closed (because doc was closed) open it up again */
        _TUTORinternal_marker(&tvp->bounds,vp->textv,
            (long) ((char FAR *) &tvp->bounds - (char FAR *) &tvp->self));
        }
    /* else
        TUTORdump("RestartPanel on unclosed doc?"); -- arrow restarts on existing doc */

    ReleasePtr(vp->textv);
    KillPtr(tvp);
    TUTORcompress_darray(vp->textv,VIEWOFFSET); /* recover some memory */
    
    TUTORchange_tview(vp->textv,0L,0L,0L,0L,0L,selStart,selLen,&sbi,FALSE);
    
    if (vp->scrollv)
        TUTORreset_text_sbar(vp->scrollv,&sbi,TRUE);
    

#ifdef MAC
        MarkStyleMenus(vp,0);
#endif

    return 0;
    }

int DocBuffer(doc) /* set document internal buffer big enough for view */
Memh doc; /* handle on document */

{   int dynn; /* number items in darray */
    int dynnew; /* new items to add to darray */
    DocP dp;
  
    /* view machinery assumes document buffer is big enough for */
    /* enough characters to make one line across the window */
    /* add items to expand darray */
    
    dp = (DocP)GetPtr(doc); /* get pointer to document */
    if (dp->txtH.dAnAlloc < TBUFFLEN) {
        /* need to insert some items (so text buffer will be of size TBUFFLEN) */
        dynn = dp->txtH.dAnn;
        dp->txtH.dAnn = dp->txtH.dAnAlloc;
        dynnew = TBUFFLEN - dp->txtH.dAnn; /* # of items to insert */
        ReleasePtr(doc);
        TUTORinsert_darray(doc,FARNULL,DOCOFFSET,DOCTEXT,-1,dynnew);
        dp = (DocP)GetPtr(doc);
        dp->txtH.dAnn = dynn; /* restore items present */
    }
    ReleasePtr(doc);
	return(0);

} /* DocBuffer */

/* maintain view on document (when document changed) */
TUTORmaintain_doc_view(dp,pos,len,cpos,clen,newC)
DocP dp;    /* pointer to document */
long pos,len; /* total range of change (in terms of BEFORE change) */
long cpos,clen; /* where text was replaced */
long newC;  /* # of new characters that were added */
    {
    TextVDat FAR *vp;   /* pointer to panel */
    
    if (dp->editPanel)
        {
        vp = (TextVDat FAR *) GetPtr(dp->editPanel);
        RefreshPanel(vp,pos,len,cpos,clen,newC,-1L,0L,TRUE,FALSE);
        ReleasePtr(dp->editPanel);
        KillPtr(vp);
        }
    
    }

RefreshPanel(vp,pos,len,cpos,clen,newC,selStart,selLen,scroll,force)
REGISTER TextVDat FAR *vp;  /* pointer to panel */
long pos,len; /* total range of change (in terms of BEFORE change) */
long cpos,clen; /* where text was replaced */
long newC;  /* # of new characters that were added */
long selStart, selLen; /* where selection should end up (if selStart < 0, don't change) */
int scroll; /* TRUE if should update scroll bar */
int force; /* TRUE if should force complete update */
    {
    DocP dp;    /* pointer to document that view is on */
    Memh nextPanel, curPanel;   /* for doc's linked list of panels */
    TextVDat FAR *vp1;  /* pointer to current panel */
    struct tutorview FAR *cv;   /* to save & restore view */
    
    cv = TUTORinq_view();
   
    /* first we update the panel that was changed */
    Refresh1Panel(vp,pos,len,cpos,clen,newC,selStart,selLen,scroll,force);

    /* update all other panels on this document */
    dp = (DocP) GetPtr(vp->textd);
    nextPanel = dp->editPanel;
    
    while(nextPanel)
        { /* go thru panel chain */
        curPanel = nextPanel;
        vp1 = (TextVDat FAR *) GetPtr(nextPanel);
        if (curPanel != vp->self) /* we've already updated vp->self above */
            Refresh1Panel(vp1,pos,len,cpos,clen,newC,-1L,0L,scroll,force);
        nextPanel = vp1->nextPanel; /* get next panel in chain */
        ReleasePtr(curPanel);
        KillPtr(vp1);
        }
    
    ReleasePtr(vp->textd);
    KillPtr(dp);
    
    TUTORset_view(cv);
    }

/* change & redraw 1 panel */
Refresh1Panel(vp,pos,len,cpos,clen,newC,selStart,selLen,scroll,force)
REGISTER TextVDat FAR *vp;  /* pointer to panel */
long pos,len; /* total range of change (in terms of BEFORE change) */
long cpos,clen; /* where text was replaced */
long newC;  /* # of new characters that were added */
long selStart, selLen; /* where selection should end up */
int scroll; /* TRUE if should update scroll bar */
int force; /* TRUE if should force complete update */
    {
    SBarInfo sbi;   /* vertical scroll bar info */
    
    if (vp->inhibitState) {
    
    	/* if inhibit editdraw in effect, remember accumulated changes */
    	/* for later update on allow */
    	
    	if (vp->inhibitState == 1) {
    	   	/* initialize update parameters */
    		vp->inhibitState = 2; /* this panel needs an update */
    		vp->ihPos = pos; 
    		vp->ihLen = len;		
			vp->ihCpos = cpos;
			vp->ihClen = clen; 	
			vp->ihNewC = vp->ihScroll = vp->ihForce = 0;            
    	}
    	vp->ihSelStart = selStart;		
		vp->ihSelLen = selLen; 
		vp->ihNewC += newC;
		if (pos == vp->ihPos) { /* adjust range of change */
			if (len > vp->ihLen)
				vp->ihLen = len;
		} else if (pos < vp->ihPos) {
			if ((pos+len) < vp->ihPos)
				vp->ihForce = TRUE;
			vp->ihLen += vp->ihPos-pos;
			vp->ihPos = pos;
		} else {
			if ((pos+len) > (vp->ihPos+vp->ihLen)) {
				if (pos > (vp->ihPos+vp->ihLen))
					vp->ihForce = TRUE;
				vp->ihLen = (pos+len)-vp->ihPos;
			}
		}
		if (cpos == vp->ihCpos) { /* adjust range of replace */
			if (clen > vp->ihClen)
				vp->ihClen = clen;
		} else if (cpos < vp->ihCpos) {
			if ((cpos+clen) < vp->ihCpos)
				vp->ihForce = TRUE;
			vp->ihClen += vp->ihCpos-cpos;
			vp->ihCpos = cpos;
		} else {
			if ((cpos+clen) > (vp->ihCpos+vp->ihClen)) {
				if (cpos > (vp->ihCpos+vp->ihClen))
					vp->ihForce = TRUE;
				vp->ihClen = (cpos+clen)-vp->ihCpos;
			}
		}
		if (scroll)
			vp->ihScroll = TRUE;
		if (force) 			
			vp->ihForce = TRUE; 			    
    	vp->alteredc++;
    	return(0);	/* exit with update saved for later */
    } /* inhibitState */
    
    TUTORset_view(vp->view);
    
    /* keep doc styles in synch */
    TUTORdefault_styles_doc(vp->textd,(short FAR *) vp->defStyles);
    
    /* change the view */
    TUTORchange_tview(vp->textv,pos,len,cpos,clen,newC,selStart,selLen,&sbi,force);
    
    if (vp->scrollv && scroll)
        TUTORreset_text_sbar(vp->scrollv,&sbi,TRUE);
    
    vp->alteredc++;

#ifdef MAC
        MarkStyleMenus(vp,0);
#endif
    }

SetSelectPanel(vp,pos,len)  /* set selection region */
register TextVDat FAR *vp;  /* pointer to panel */
long pos,len;   /* desired selection region */
    {
    SBarInfo sbv;
    register int didScroll;
    
    /* keep doc styles in synch */
    TUTORdefault_styles_doc(vp->textd,(short FAR *) vp->defStyles);
    
    didScroll = TUTORset_select_tview(vp->textv,pos,len,&sbv);
    if (didScroll && vp->scrollv)
        TUTORreset_text_sbar(vp->scrollv,&sbv,TRUE);

#ifdef MAC
        MarkStyleMenus(vp,0);
#endif
    
    return 0;
    }

ActivatePanel(vp,aFlag,toView,setCursor)
REGISTER TextVDat FAR *vp;  /* pointer to panel */
int aFlag; /* active/inactive flag */
int toView; /* transmit to KView */
int setCursor; /* change cursor (is FALSE for search start because cursor already reset) */
    {
    REGISTER TViewP tvp;    /* pointer to tview */
    int searchOffset;   /* offset from bottom due to presence of search dialog */
    int wix; /* index of window */
    
    vp->eActive = aFlag;
    tvp = (TViewP) GetPtr(vp->textv);
    if (toView)
        {
		tvp->vActive = TRUE; /* so selection hilite works */
		if (tvp->hiInactive)
        	_TUTORhilite_select(vp->textv,TRUE);
		else
        	_TUTORhilite_select(vp->textv,aFlag);
		tvp->vActive = aFlag;
        }
    
#ifdef MAC
/*    if (setCursor)
        MacSetCursor(vp->view->window,&tvp->viewRect,aFlag ? 1 : 0); */
    if (setCursor && aFlag) {
    	wix = vp->view->window;
    	if (windowsP[wix].type != EXECW) {
    		TUTORset_cursor(windowsP[wix].normalCursorFont,windowsP[wix].normalCursorChar);
    	}
    }
    MarkStyleMenus(vp,aFlag ? 1 : -1);
    if (vp->drawGrow)
        { /* need to draw grow icon */
        TRect saveClip;
        
        if (vp->searchState == 2)
            searchOffset = SEARCH1HEIGHT + (vp->readOnly ? 0 : SEARCH1EXTRA);
        else
            searchOffset = 0;
        TUTORinq_abs_clip_rect(&saveClip);
        TUTORclip_window(vp->view->window);
        DrawGrowIcon((WindowPtr)windowsP[vp->view->window].wp);
        TUTORset_abs_clip_rect((TRect FAR *) &saveClip);
        }
#endif

    if (!aFlag)
        { /* turn off caret  */
        CancelTrigger(vp->blinkid);
        vp->blinkid = 0;
        _TUTORdraw_caret_tview(tvp,1); /* erase caret */
        }
    else
        { /* turn caret back on */
#ifdef MAC
        startcaret(vp,GetCaretTime() *1000/60);
#else
        startcaret(vp,500L);
#endif
        }
    ReleasePtr(vp->textv);
    KillPtr(tvp);
    return 0;
    }

DrawPanel(edH) /* draw complete panel (text & scroll bars) */
Memh edH;   /* text panel */
    
{   TextVDat FAR *vp;   /* pointer to panel */
    struct tutorview FAR *cv;   /* to save & restore view */
    SBarInfo sbi;   /* vertical scroll bar info */
    TViewP tvp; /* pointer to tview */
    
    if (!edH)
        return(0);
    
    cv = TUTORinq_view();
    
    vp = (TextVDat FAR *) GetPtr(edH);
    
    /* keep doc styles in synch */
   TUTORdefault_styles_doc(vp->textd,(short FAR *) vp->defStyles);
    
    TUTORset_view(vp->view);
    if (vp->dispMode >= 0)
        TUTORset_comb_rule(vp->dispMode);
    tvp = (TViewP)GetPtr(vp->textv);
    TUTORset_sub_new(tvp->dySupSub,tvp->newLine);
    ReleasePtr(vp->textv);
    KillPtr(tvp);
    TUTORupdate_tview(vp->textv);
    
    tvp = (TViewP) GetPtr(vp->textv);
    if (vp->doFrame) {
        TUTORset_abs_clip_rect(&vp->absRect);
        TUTORframe_abs_rect((TRect FAR *)&vp->absRect);
        TUTORset_abs_clip_rect(&tvp->viewRect);
    } /* frame if */
    
    if (vp->scrollh) {
        _TUTORinfo_hbar_tview(tvp,&sbi);
        TUTORreset_text_sbar(vp->scrollh,&sbi,FALSE);
        drawscrollbar(vp->scrollh);
    }

    if (vp->scrollv) {
        _TUTORinfo_vbar_tview(tvp,&sbi);
        TUTORreset_text_sbar(vp->scrollv,&sbi,FALSE);
        drawscrollbar(vp->scrollv);
    }
    
    ReleasePtr(vp->textv);
    KillPtr(tvp);
        
    ReleasePtr(edH);
    KillPtr(vp);
    
    TUTORset_view(cv); /* restore view */
    
    return(0);

} /* DrawPanel */

static RedrawPanel(vp)  /* handle redraw events for panel */
register TextVDat FAR *vp;  /* pointer to panel */
    {
    REGISTER TViewP tvp;    /* pointer to tview */
    int searchOffset;   /* offset due to search dialog */
    SBarInfo sbv, sbh;  /* vertical & horizontal scroll bar info */
    TRect vRect;    /* new view rect */
    TRect tempR;    /* for calculating new clip rect */
    int dWidth; /* new destination (layout) width */
    int wn; /* window number */
  
    tvp = (TViewP) GetPtr(vp->textv);
    wn = vp->view->window;
#ifdef MACnosuch
    MacSetCursor(wn,&tvp->viewRect,0);
#endif
    if (vp->doFrame) {
        TUTORset_abs_clip_rect(&vp->absRect);
        TUTORframe_abs_rect((TRect FAR *)&vp->absRect);
        TUTORset_abs_clip_rect(&tvp->viewRect);
    } /* frame if */
    
    ReleasePtr(vp->textv);
    KillPtr(tvp);

   /* calculate new view rect for text */
    TUTORuse_rel_rect(&vp->relRect,vp->sizeInfo,vp->view,&vRect);

    if (vp->scrollh || vp->scrollv) {
        TUTORoptimize_rect(&vRect);
    } /* scroll if */

    /* calculate new destination width */
    dWidth = vRect.right - vRect.left + 1;
    if (dWidth < vp->minDest)
        dWidth = vp->minDest;
    
    /* resize text view */

    TUTORresize_tview(vp->textv,(TRect FAR *) &vRect, dWidth,&sbv,&sbh);    /* redraw the view */

    /* reset view rects */
#ifdef MAC
    if (vp->drawGrow)
        { /* need to draw grow icon */
        TUTORclip_window(vp->view->window); /* whole window */
        DrawGrowIcon((WindowPtr)windowsP[vp->view->window].wp);
        }
#endif
    if (vp->searchState == 2)
        searchOffset = SEARCH1HEIGHT + (vp->readOnly ? 0 : SEARCH1EXTRA);
    else
        searchOffset = 0;
    tvp = (TViewP) GetPtr(vp->textv);
    tempR = tvp->viewRect;
    tempR.bottom += searchOffset; /* to include search portion in clip */
    TUTORset_abs_clip_rect((TRect FAR *) &tempR);
    TUTORset_abs_view_rect(tvp->viewRect.left,tvp->viewRect.top,tvp->viewRect.right - tvp->viewRect.left+1,
                tvp->viewRect.bottom-tvp->viewRect.top+1 + searchOffset);
    TUTORdraw_abs_solid_rect(&tvp->viewRect,PAT_WHITE);
#ifdef MACnosuch
    MacSetCursor(vp->view->window,&tvp->viewRect,1);
#endif
    ReleasePtr(vp->textv);
    KillPtr(tvp);
    TUTORupdate_tview(vp->textv);

    if (vp->scrollv)
        TUTORreset_text_sbar(vp->scrollv,&sbv,FALSE);
    if (vp->scrollh)
        TUTORreset_text_sbar(vp->scrollh,&sbh,FALSE);
        
    if (vp->searchState == 2)
        DrawSearch1(vp,FALSE,(Memh) 0);

    return 0;
    }
/* ******************************************************************* */

static KeyPanel(vp,event,startSelect,lenSelect) /* handle key events */
register TextVDat FAR *vp;  /* pointer to text panel */
register struct tutorevent *event;  /* the key event */
register long startSelect, lenSelect; /* where, in document we are replacing text */
    {
    int nKeys;  /* # of keys (out of event) we will process at once */
    int nUsed;  /* how many of the keys (from event) we have already processed */
    int keyType;    /* kind of key.  1: normal, 2: newline */
    int nActual;    /* # of keys to actually use */
    int ii,jj;
    int ll; /* # of deletes to do before doing text */
    int si; /* style index */
    int offset; /* offset to actual characters */
    long tempL;
    REGISTER TViewP tvp;    /* pointer to tview */
    long extraPos, extraPos2;   /* positions of end of actual change */
    int kyscroll; /* TRUE if will update scroll on normal key */
    unsigned char FAR *cp;  /* pointer to characters to be processed next */
    unsigned char specialNewline[30];   /* string for autoindent */
    short needVis;  /* TRUE if we need to wrap visible style around new chars */
    long boundsPos, boundsLen;  /* "marker" on text view */
    
    if (vp->readOnly) {
    	if (vp->ebshdrH) {
    		/* reroute event to executor */
    		event->window = ExecWn;
    		event->view = ExecVp;
       		TUTORset_key_focus(ExecWn,ExecVp,FALSE);
    		TUTORpush_event(event); /* pass to executor */
    	}
        return(0); /* nothing more to do here */
    }
    
    TUTORobscure_cursor(); /* hide cursor until mouse is moved again */
    
    nUsed = 0;

    /* convert RETURNs to NEWLINEs */
    for (ii=0; ii<event->nkeys; ii++)
        {
        jj = event->keys[ii];
        if (jj == RETURN)
            event->keys[ii] = NEWLINE;
        }           

    tvp = (TViewP) GetPtr(vp->textv);
    boundsPos = tvp->bounds.pos;
    boundsLen = tvp->bounds.len;
    if (startSelect+lenSelect >= tvp->bounds.doclen && 
            TUTORcharat_doc(vp->textd,tvp->bounds.doclen-1L) == NEWLINE)
        needVis = TRUE; /* we will want to wrap a visible style around new chars */
    else
        needVis = FALSE;
    ReleasePtr(vp->textv);
    KillPtr(tvp);
    
    while (nUsed < event->nkeys)
        {
        /* figure out what kind of key we have */
        kyscroll = TRUE; /* assume we will update scroll bar */
        jj = event->keys[nUsed];
        if (jj == NEWLINE)
            { /* possibly put in tabs at start of new line */
            keyType = 2;
            nKeys = TypeNewline(vp,specialNewline,startSelect,lenSelect);
            cp = (unsigned char FAR *) specialNewline;
            }
        else if (jj < 32 && jj != '\t' && jj != '\b')
            {
            specialkey(vp,jj,startSelect,lenSelect);
            nUsed++;
            continue; /* go get next key */
            }
        else
            { /* normal keys */
            keyType = 1;
            nKeys = 1;
#ifndef MAC
            kyscroll = FALSE; /* don't update scroll bar */
#endif
            cp = event->keys + nUsed;
            while (nUsed+nKeys < event->nkeys && (cp[nKeys] >= ' ' ||
                    cp[nKeys] == '\b' || cp[nKeys] == '\t'))
                {
                nKeys++;
                }
            }

        /* add key(s) to document+view */

        nActual = nKeys;
        if (keyType == 1)
            ll = CountDeletes(cp,&nActual,&offset); /* filter out deletes */
        else
            {
            ll = 0; /* no deletes on fancy newline */
            offset = 0;
            }
        
        if (ll)
            { /* do deletes first */
            tempL = startSelect + lenSelect; /* end of selection */
            if (lenSelect == 0)
                startSelect--;
            /* else first deletion takes out selection */
            startSelect -= (ll-1);
            tvp = (TViewP) GetPtr(vp->textv);
            if (startSelect < tvp->bounds.pos)
                startSelect = tvp->bounds.pos; /* can't delete before view */
            ReleasePtr(vp->textv);
            KillPtr(tvp);
            TUTORsave_do_doc(vp->textd,startSelect,tempL-startSelect,2,0L);
            TUTORdelete_doc(vp->textd,startSelect,tempL-startSelect, &extraPos); /* delete */
            boundsLen -= tempL - startSelect; /* maintain "marker" */
            /* remember extraPos from delete (in terms of doc before change) */
            extraPos += tempL-startSelect;
            RefreshPanel(vp,startSelect,extraPos-startSelect,startSelect,
                        tempL-startSelect,0L,startSelect,0L,TRUE,FALSE);
            lenSelect = 0;
            vp->caretSet = FALSE;
            }
        if (nActual)
            { /* now add keys */
            TUTORsave_do_doc(vp->textd,startSelect,lenSelect,0,(long) nActual);
            
            /* we call change_doc with a styles handle of -1 so that keys will absorb
                preceeding styles */
            TUTORchange_doc(vp->textd,startSelect,lenSelect,boundsPos,boundsLen,cp+offset,
                    (long) nActual,0L,(Memh) -1,(Memh) 0,&extraPos,FALSE);
            boundsLen += nActual; /* maintain "marker" */
            if (vp->caretSet)
                { /* put style over new keys */
                for (si=0; si<NSTYLES; si++)
                    {
                    if (si == PARASTYLE)
                        continue;
                    TUTORstyle_doc(vp->textd,startSelect,lenSelect+nActual,si,
                        vp->caretStyle[si],si == SIZESTYLE,NEARNULL);
                    }
                vp->caretSet = FALSE;
                }
            
            if (needVis)
                { /* make new chars visible */
                TUTORstyle_doc(vp->textd,startSelect,(long) nActual,PARASTYLE,0,
                                VISMASK,&extraPos2);
                if (extraPos2 > extraPos)
                    extraPos = extraPos2;
                needVis = FALSE;
                }
            extraPos += lenSelect - nActual; /* convert to position in doc BEFORE change */
    
            RefreshPanel(vp,startSelect,extraPos-startSelect,startSelect,lenSelect,
                (long) nActual,startSelect+nActual,0L,kyscroll,FALSE);
            lenSelect = 0;
            startSelect += nActual;
            }

        nUsed += nKeys;

        } /* end of key loop */
    
    return(0);
    }

static CountDeletes(cp0,nKeys, offset)  /* handle deletes in burst typing */
unsigned char FAR *cp0; /* pointer to event keys */
int *nKeys; /* # of keys that are usable */
int *offset; /* set to offset between keys passed in and keys to really use */
/* returns # of deletes to do before doing text */
    {
    register unsigned char FAR *cp, FAR *ce, FAR *cd;
    register int nDel;  /* # of deletes to do before inserting text (return value) */

    /* eliminate backspaces preceeded by characters (by scanning backwards) */
    cp = cp0 + *nKeys - 1; /* points at last char */
    cd = cp; /* destination of copy */
    ce = cp0; /* points at first char */
    nDel = 0;
    while (cp >= ce)
        {
        if (*cp == '\b')
            nDel++;
        else
            {
            if (nDel == 0)
                *cd-- = *cp; /* copy undeleted chars */
            else
                nDel--;
            }
        cp--;
        }
    cd++; /* now points to actual chars */

    *offset = (int) (cd - cp0);
    *nKeys -= *offset; /* # of actual chars */ 
    
    return(nDel);
    }

static TypeNewline(vp,newls,startSelect,lenSelect)  /* make string for auto-indent */
register TextVDat FAR *vp;  /* pointer to panel */
unsigned char *newls;   /* to be filled with string for autoindent */
register long startSelect, lenSelect;   /* current selection */
/* returns # of characters to add */
    {
    long viewStart; /* position of beginning of view (in doc chars) */
    REGISTER TViewP tvp;    /* pointer to tview */
    DocP dp;    /* pointer to doc */
    register long npos; /* position of previous newline */
    register int ii;    /* # of chars */

    newls[0] = NEWLINE;
    ii = 1;

    if (TRUE)
        { /* we always auto-indent now */
        /* get beginning of selection (and of view) */
        tvp = (TViewP) GetPtr(vp->textv);
        viewStart = tvp->bounds.pos;
        ReleasePtr(vp->textv);
        KillPtr(tvp);

        /* find previous newline */
        dp = (DocP) GetPtr(vp->textd);
        npos = TUTORsearch_string_doc(dp,(unsigned char FAR *) NEWLINES,1L,startSelect,viewStart);
        ReleasePtr(vp->textd);
        KillPtr(dp);
        npos++; /* go past newline */
        ii = 1;
        while (npos < startSelect && ii < 25 &&
                TUTORcharat_doc(vp->textd,npos) == '\t')
            {
            newls[ii++] = '\t';
            npos++;
            }
        }
    
    return(ii);
    }

static specialkey(vp,ky,startSelect,lenSelect)  /* process fkey event(s) */
register TextVDat FAR *vp;  /* pointer to editable text info */
int ky; /* the special key */
long startSelect, lenSelect;    /* current selection */
    {
    REGISTER TViewP tvp;    /* pointer to tview */
    Position startP;    /* position of part of selection region that is moved */
    TPoint fakeClick;   /* position of click we want to fake, for keyboard caret moves */
    char doScrollV; /* 0: don't update scroll bar, 1: update sbar, 2: get info & update sbar */
    char doScrollH; /* TRUE if horizontal scroll may be needed */
    char doClick;   /* TRUE if we need to mock up a click event */
    char vlocked;   /* TRUE if the text view is locked */
    SBarInfo sbv, sbh;  /* scroll bar info */
    int extendSelect;   /* TRUE if selection region is being extended */
    int moveIns;    /* TRUE if we are moving the caret */
    Memh tempDoc;   /* temporary document used for transpose operation */
    long tempL, extraPos, extraPos2;
    long tempL2, tempL3;
    int jj;

    doScrollV = 0;
    doScrollH = FALSE;
    doClick = FALSE;
    extendSelect = FALSE;
    moveIns = FALSE;
    tvp = (TViewP) GetPtr(vp->textv);
    vlocked = TRUE; /* text view is locked */
    
    switch (ky)
        {
        case KBEGFILE+1:
            extendSelect = TRUE;
        case KBEGFILE:
            moveIns = TRUE;
        case KSBEGFILE:
            if (moveIns)
                {
                tempL = tvp->bounds.pos; /* beginning of view */
                tempL2 = extendSelect ? (tvp->anchor.pos - tempL) : 0L;
                }
            ReleasePtr(vp->textv);
            KillPtr(tvp);
            vlocked = FALSE;
            PanelScroll(vp->view,0,1.,sbToTop);
            doScrollV = 2;
            if (moveIns)
                { /* move insertion point */
                TUTORset_select_tview(vp->textv,tempL,tempL2,&sbv);
                doScrollV = 1;
                }
            break;

        case KENDFILE+1:
            extendSelect = TRUE;
        case KENDFILE:
            moveIns = TRUE;
        case KSENDFILE:
            if (moveIns)
                {
                if (extendSelect)
                    {
                    tempL = tvp->anchor.pos;
                    tempL2 = tvp->bounds.pos+tvp->bounds.len - tempL;
                    }
                else
                    {
                    tempL = tvp->bounds.pos+tvp->bounds.len;
                    tempL2 = 0L;
                    }
                }
            ReleasePtr(vp->textv);
            KillPtr(tvp);
            vlocked = FALSE;
            PanelScroll(vp->view,0,1.,sbToBot);
            doScrollV = 2;
            if (moveIns)
                { /* move insertion point */
                TUTORset_select_tview(vp->textv,tempL,tempL2,&sbv);
                doScrollV = 1;
                }
            break;

        case KPAGEUP+1:
            extendSelect = TRUE;
        case KPAGEUP:
            moveIns = TRUE;
        case KSPAGEUP:
            if (moveIns)
                { /* generate fake click to move insertion point */
                if (tvp->selA.vv <= tvp->viewRect.bottom &&
                        tvp->selA.vv > tvp->viewRect.top)
                    { /* caret is on page, use same position for click */
                    fakeClick.hh = tvp->selA.hh;
                    fakeClick.vv = tvp->selA.vv;
                    }
                else
                    { /* caret isn't on page, use upper left */
                    fakeClick.hh = tvp->viewRect.left + 1;
                    fakeClick.vv = tvp->viewRect.top + 1;
                    }
                doClick = TRUE;
                }
            ReleasePtr(vp->textv);
            KillPtr(tvp);
            vlocked = FALSE;
            PanelScroll(vp->view,0,1.,sbPageUp);
            doScrollV = 2;
            break;

        case KPAGEDOWN+1:
            extendSelect = TRUE;
        case KPAGEDOWN:
            moveIns = TRUE;
        case KSPAGEDOWN:
            if (moveIns)
                { /* generate a fake click to move insertion point */
                if (tvp->selA.vv <= tvp->viewRect.bottom &&
                        tvp->selA.vv > tvp->viewRect.top)
                    { /* caret is on page, use same position for click */
                    fakeClick.hh = tvp->selA.hh;
                    fakeClick.vv = tvp->selA.vv;
                    }
                else
                    { /* caret isn't on page, use lower left */
                   fakeClick.hh = tvp->viewRect.left + 1;
                    fakeClick.vv = tvp->viewRect.bottom - 1;
                    }
                doClick = TRUE;
                }
            ReleasePtr(vp->textv);
            KillPtr(tvp);
            vlocked = FALSE;
            PanelScroll(vp->view,0,1.,sbPageDown);
            doScrollV = 2;
            break;

        case KBEGPAGE+1:
            extendSelect = TRUE;
        case KBEGPAGE:
            fakeClick.hh = tvp->selA.hh;
            fakeClick.vv = tvp->viewRect.top+1;
            doClick = TRUE;
            break;
        
        case KENDPAGE+1:
            extendSelect = TRUE;
        case KENDPAGE:
            fakeClick.hh = tvp->selA.hh;
            fakeClick.vv = tvp->viewRect.bottom-1;
            doClick = TRUE;
            break;

        case KENDLINE+1:
        case KBEGLINE+1:
            extendSelect = TRUE;
            ky--; /* make key look like non-extend-select key */
        case KENDLINE:
        case KBEGLINE:
            tempL = tvp->anchor.pos; /* position of anchor */
            tempL2 = _TUTORline_pos_tview(tvp,tvp->selA.nLine);
            if (ky == KENDLINE)
                tempL2 += tvp->ld[tvp->selA.nLine].nDraw;
            
            /* now tempL is anchor position, tempL2 is new position */
            
            if (extendSelect)
                {
                tempL2 -= tempL; /* now tempL2 is length of select from anchor */
                if (tempL2 < 0)
                    { /* change pos of select to beginning of select */
                    tempL += tempL2;
                    tempL2 = -tempL2;
                    }
                }
            else
                {
                tempL = tempL2;
                tempL2 = 0;
                }
            
            /* now tempL is select position, tempL2 is select len */
            
            /* set selection */
            ReleasePtr(vp->textv);
            KillPtr(tvp);
            vlocked = FALSE;
            TUTORset_select_tview(vp->textv,tempL,tempL2,&sbv);
            doScrollV = 1;
            doScrollH = TRUE;
            
            break;

        case KLEFT+1:
        case KRIGHT+1:
        case KUP+1:
        case KDOWN+1:
            extendSelect = TRUE;
            ky--;
        case KLEFT:
        case KRIGHT:
        case KUP:
        case KDOWN:
            startP = tvp->selA;
            if (!vp->keySelect)
                {
                vp->keySelect = TRUE;
                vp->selectH = startP.hh;
                }
            if (tvp->selA.pos != tvp->anchor.pos && !extendSelect)
                { /* collapse selection */
                if (((ky == KRIGHT || ky == KDOWN) && tvp->anchor.pos > tvp->selA.pos) ||
                        ((ky == KLEFT || ky == KUP) && tvp->anchor.pos < tvp->selA.pos))
                    startP = tvp->anchor; /* swap startP */
                TUTORwhere_pix_tview(vp->textv,(Position FAR *) &startP);
                fakeClick.hh = vp->selectH = startP.hh;
                fakeClick.vv = startP.vv;
                }
            else if (ky == KUP)
                { /* up arrow */
                if ((startP.nLine == tvp->topLine) || (tvp->topLine == tvp->botLine)) {
					fakeClick.hh = tvp->viewRect.left + 1;
                    fakeClick.vv = tvp->viewRect.top - 1;
					doClick = TRUE;
					ReleasePtr(vp->textv);
					KillPtr(tvp);
					vlocked = FALSE;
					PanelScroll(vp->view,0,1.,/* sbPageUp */ sbLineUp);
					doScrollV = 2;
                    break; 
				}
				if (startP.nLine > tvp->botLine)
					startP.nLine = tvp->botLine;
                fakeClick.hh = vp->selectH;
                fakeClick.vv = startP.vv - (tvp->ld[startP.nLine].lineAsc + 1);
                }
            else if (ky == KDOWN) { /* down arrow */
                if (startP.nLine >= tvp->botLine) {
					fakeClick.hh = tvp->viewRect.left + 1;
                    fakeClick.vv = tvp->viewRect.bottom - 1;
					doClick = TRUE;
					ReleasePtr(vp->textv);
					KillPtr(tvp);
					vlocked = FALSE;
					PanelScroll(vp->view,0,1.,/* sbPageDown */ sbLineDown);
					doScrollV = 2;
                    break; 
				}
                fakeClick.hh = vp->selectH;
                fakeClick.vv = startP.vv + (tvp->ld[startP.nLine].lineHeight -
                        tvp->ld[startP.nLine].lineAsc) + 1;
            } else if (ky == KRIGHT)
                { /* right arrow */
                if (startP.pos < tvp->bounds.pos + tvp->bounds.len)
                    {
                    startP.pos++;
                    startP.atEnd = TRUE;
                    TUTORwhere_pix_tview(vp->textv,(Position FAR *) &startP);
                    }
                fakeClick.hh = vp->selectH = startP.hh;
               fakeClick.vv = startP.vv;
                }
            else
                { /* left arrow */
                if (startP.pos > tvp->bounds.pos)
                    {
                    startP.pos--;
                    startP.atEnd = FALSE;
                    TUTORwhere_pix_tview(vp->textv,(Position FAR *) &startP);
                    }
                fakeClick.hh = vp->selectH = startP.hh;
                fakeClick.vv = startP.vv;
                }
            doClick = TRUE;
            break;

        case KTRANSPOSE: /* control+t (transpose 2 last characters) */
            tempL = (tvp->selA.pos > tvp->anchor.pos) ? tvp->selA.pos : tvp->anchor.pos;
            if (tempL < tvp->bounds.pos+2)
                break; /* there aren't two preceeding chars in view */
            /* we need to create a temporary document, cut 1 character into it and then paste it back */
            tempDoc = TUTORnew_doc(TRUE,TRUE);
            
            /* cut preceeding char into temp doc */
            TUTORchange_doc_doc(tempDoc,0L,0L,0L,0L,vp->textd,tempL-1L,1L,&extraPos,FALSE);
            TUTORdelete_doc(vp->textd,tempL-1L,1L,&extraPos);
            /* put char back, earlier in doc */
            TUTORchange_doc_doc(vp->textd,tempL-2L,0L,tvp->bounds.pos,tvp->bounds.len,
                    tempDoc,0L,1L,&extraPos2,FALSE);
            extraPos2--; /* both extraPos now in terms of doc BEFORE change */
            
            TUTORclose_doc(tempDoc);
            
            /* redraw view */
            if (extraPos > extraPos2)
                extraPos2 = extraPos;
            ReleasePtr(vp->textv);
            KillPtr(tvp);
            vlocked = FALSE; /* text view has been released */
            RefreshPanel(vp,tempL-2,extraPos2-(tempL-2),tempL-2,0L,0L,tempL,0L,TRUE,FALSE);
            break;

        case KFWDDEL: /* forward delete */
            /* set up a fake menu event and call PanelEvent */
            
            if (lenSelect == 0)
                {
                if (tvp->selA.pos < tvp->bounds.pos + tvp->bounds.len)
                    lenSelect = 1;
                else
                    break; /* at end, can't delete forward */
                }
            /* clear selection */
            TUTORsave_do_doc(vp->textd,startSelect,lenSelect,2,0L);
            TUTORdelete_doc(vp->textd,startSelect,lenSelect,&extraPos);
            extraPos += lenSelect; /* convert to position before change */
            
            /* refresh panel */
            ReleasePtr(vp->textv);
            KillPtr(tvp);
            vlocked = FALSE;
            RefreshPanel(vp,startSelect,extraPos-startSelect,startSelect,lenSelect,
                0L,startSelect,0L,TRUE,FALSE);
            break;

        case KUNDO:  /* undo last change */
            jj = TUTORundo_doc(vp->textd,&tempL,&tempL2,tvp->bounds.pos,
                    tvp->bounds.len,&tempL3,&extraPos);
            startSelect = tempL;
            lenSelect = tempL2;
            if (!jj)
                break; /* wasn't able to undo */
            extraPos += lenSelect - tempL3; /* convert to position in doc BEFORE change */
            ReleasePtr(vp->textv);
            KillPtr(tvp);
            vlocked = FALSE;
            RefreshPanel(vp,startSelect,extraPos-startSelect,startSelect,lenSelect,
                    tempL3,startSelect,tempL3,TRUE,FALSE);
            break;

        case KCUT:
            if (vp->readOnly || !lenSelect)
                break; /* exit if read only, or nothing selected */
            TUTORsave_do_doc(vp->textd,startSelect,lenSelect,2,0L);
        case KCOPY:
            if (!lenSelect)
                break; /* nothing selected */
            jj = TUTORto_clip_doc(vp->textd,startSelect,lenSelect,ky == KCUT,&extraPos);
            if (!jj || ky == KCOPY)
                break; /* error, or copy (we don't need to redraw) */
            extraPos += lenSelect; /* convert to position in doc BEFORE change */
            
            ReleasePtr(vp->textv);
            KillPtr(tvp);
            vlocked = FALSE;
            RefreshPanel(vp,startSelect,extraPos-startSelect,startSelect,lenSelect,
                0L,startSelect,0L,TRUE,FALSE);
            break;

        case KPASTE: /* paste */
            if (vp->readOnly) break; /* exit if read only */
            tempL = TUTORfrom_clip_doc(vp->textd,startSelect,lenSelect,tvp->bounds.pos,
                    tvp->bounds.len,&extraPos,TRUE);
            if (!tempL)
                break; /* nothing copied from clipboard */
                        /* though we may get an EVENT_PASTE soon... */
            extraPos += lenSelect - tempL; /* convert to position in doc BEFORE change */
            ReleasePtr(vp->textv);
            KillPtr(tvp);
            vlocked = FALSE;
            RefreshPanel(vp,startSelect,extraPos-startSelect,startSelect,lenSelect,
                    tempL,startSelect+tempL,0L,TRUE,FALSE);
            break;

#ifndef MAC
        case 18: /* control+r (change search direction & search) */
            vp->searchDir = !vp->searchDir;
        case 19: /* control+s (search) */
            if (vp->searchState != 1)
                break; /* not searchable (or search dialog in progress) */
            ReleasePtr(vp->textv);
            KillPtr(tvp);
            vlocked = FALSE;
            if (searchAllDoc)
                { /* use search string */
                unsigned char searchS[MSGTEXTL+1];
                GetSearchString2(vp,2,searchS,MSGTEXTL);
                n_editornexts(vp,searchS,TRUE,vp->searchDir);
                }
            else
                { /* start search dialog */
                StartSearch1(vp,vp->self);
                }
            break;
#endif

        default:
            break;

        } /* key switch */
    
    if (vlocked) /* release the text view */
        {
        ReleasePtr(vp->textv);
        KillPtr(tvp);
        }
    
    if (doClick)
        { /* run a fake click */
        jj = TUTORclick_tview(vp->textv,fakeClick,extendSelect);
        TUTORclick_done_tview(vp->textv,&sbv);
        if (!jj)
            { /* click didn't do anything, probably clicked in invisible */
                /* click again a little away */
            tvp = (TViewP) GetPtr(vp->textv);
            if (fakeClick.vv > 6+tvp->viewRect.top)
                fakeClick.vv -= 5;
            else
                fakeClick.vv += 5;
            ReleasePtr(vp->textv);
            KillPtr(tvp);
            TUTORclick_tview(vp->textv,fakeClick,extendSelect);
            TUTORclick_done_tview(vp->textv,&sbv);
            }
        doScrollV = 1;
        }

    if (doScrollV && vp->scrollv)
        {
        if (doScrollV == 2)
            {
            tvp = (TViewP) GetPtr(vp->textv);
            _TUTORinfo_vbar_tview(tvp,&sbv);    /* get scroll bar info */
            ReleasePtr(vp->textv);
            KillPtr(tvp);
            }
        TUTORreset_text_sbar(vp->scrollv,&sbv,TRUE);
        }
    
    if (doScrollH)
        { /* see if we need horizontal scroll and if so, do it */
        tvp = (TViewP) GetPtr(vp->textv);
            
        /* do we need horizontal scroll? */
        doScrollH = FALSE;
        if (tvp->selA.hh < tvp->viewRect.left)
            { /* caret is off to left, scroll */
            jj = tvp->leftOff + tvp->viewRect.left - tvp->selA.hh;
            if (-jj < 20)
                jj = 0; /* try to make horizontal scroll 0 */
            doScrollH = TRUE;
            }
        else if (tvp->selA.hh >= tvp->viewRect.right)
            {
            jj = tvp->leftOff + tvp->viewRect.right - tvp->selA.hh-1;
            doScrollH = TRUE;
            }
            
        if (doScrollH)
            { /* need horizontal scroll, jj is set to new desired offset */
            _TUTORscrollh_tview(vp->textv,jj);
            if (vp->scrollh)
                { /* fix horizontal scroll bar */
                _TUTORinfo_hbar_tview(tvp,&sbh);
                TUTORreset_text_sbar(vp->scrollh,&sbh,TRUE);
                }
            }
        ReleasePtr(vp->textv);
        KillPtr(tvp);
        }

    return;
    }


/* ******************************************************************* */

TUTORclose_panel(theV)  /* close a text panel */
Memh theV; /* the panel */
    {
    REGISTER TextVDat FAR *vp;  /* pointer to the panel */
    register struct tutorview FAR *vv;  /* the panel's view */
    struct tutorview FAR *cv;   /* to save & restore the view */
    TRect rr;   /* copy of panel's view rect, for clip rect */
    int doErase;    /* TRUE if we want to erase panel */
    struct tutorColor ecolor; /* color to erase with */
    struct tutorColor svcolor;
    TViewP tvp; /* pointer to tview */
    
    if (!theV)
        return(0);
    
    cv = TUTORinq_view();
    vp = (TextVDat FAR *) GetPtr(theV);
    vv = vp->view;
    vv->objectH = HNULL; /* break link between view/edit */
    vv->objectT = 0;
    doErase= vp->doErase;
    TUTORblock_move((char FAR *)&vp->ecolor,(char FAR *)&ecolor,
                    (long)sizeof(struct tutorColor));
    TUTORremove_edit_doc(vp->textd,theV); /* remove this panel from doc's edit chain */
    
#ifdef MACnosuch
    /* get rid of editing cursor */
    tvp = (TViewP) GetPtr(vp->textv);
    MacSetCursor(vv->window,&tvp->viewRect,0);
    ReleasePtr(vp->textv);
    KillPtr(tvp);
#endif

    /* erase the panel */
    if (doErase) {
        TUTORset_view(vv);
        /* rr = vv->rr; */
        rr = vp->absRect;
        TUTORset_abs_clip_rect(&rr);
    _TUTORhilite_select(vp->textv,FALSE); /* turn off hilighting */
    TUTORinq_background_color(&svcolor);
    TUTORset_color(1,&ecolor);
    TUTORdraw_abs_solid_rect(&rr, PAT_WHITE);
    TUTORset_color(1,&svcolor);
    }
    ReleasePtr(theV);
    KillPtr(vp);
    
    TUTORclose_view(vv);
    
    TUTORset_view(cv);
    
    return(0);
    }

/* ******************************************************************* */

static int n_editornexts(vp,ss,tellUser,direction) /* search for next incidence of search string */
            /* returns TRUE if string found */
register TextVDat FAR *vp;  /* pointer to editable text info */
unsigned char *ss;  /* string to search for */
int tellUser;   /* TRUE if want to inform user when not found */
int direction;  /* TRUE if forwards */
    {
    int found; /* TRUE if target found */
    long startSelect,lenSelect; /* current selection region */
    register long searchp; /* region of find */
    long pos,posEnd;    /* bounds of search */
    DocP dp;    /* pointer to document */
    TViewP tvp; /* pointer to tview */
    long sLen;  /* length of the search target */
    SBarInfo sbv;   /* vertical scroll bar info */

    TUTORwait_cursor();
    TUTORflush();
    TUTORinq_select_tview(vp->textv,&startSelect,&lenSelect);
        
    dp = (DocP) GetPtr(vp->textd);
    tvp = (TViewP) GetPtr(vp->textv);
    
    if (direction)
        {
        pos = startSelect+lenSelect;
        posEnd = tvp->bounds.pos + tvp->bounds.len;
        }
    else
        {
        pos = startSelect;
        posEnd = tvp->bounds.pos;
        }
    ReleasePtr(vp->textv);
    KillPtr(tvp);
    
    sLen = strlen((char *) ss);
    searchp = _TUTORsearch_doc(dp,(unsigned char FAR *) ss, sLen,sLen,HNULL,0L,
                        pos,posEnd,
                        vp->searchExact ? FARNULL : (unsigned char FAR *) -1L);
    ReleasePtr(vp->textd);
    KillPtr(dp);
    TUTORresume_cursor();
    if (searchp >= 0)
        {
        TUTORset_select_tview(vp->textv,searchp,sLen,&sbv);
        if (vp->scrollv)
            TUTORreset_text_sbar(vp->scrollv,&sbv,TRUE);
        }
    else if (tellUser)
#ifndef MAC
#ifndef IBMPC
#ifndef ibm032
#ifndef sunV3
#define cantbeep
#endif
#endif
#endif
#endif

#ifdef cantbeep
        { /* "other" machines can't beep */
        BeforeDialog(vp);
        TUTORalert(vp->view->window,"Not found");
        AfterDialog(vp,TRUE);
        }
#else
        TUTORbeep(NEARNULL,NEARNULL,NEARNULL,0);
#endif
    return(searchp >= 0);

} /* n_editornexts */

/* ******************************************************************* */

static n_editorsrt(vp,ss,rs,option,dir,curPos,curLen) /* do replace */
register TextVDat FAR *vp;  /* pointer to editable text info */
unsigned char *ss, *rs; /* strings for search & replace */
int option; /* 0: replace, 1: replace & find, 2: replace all */
int dir; /* TRUE if search forward, FALSE if back */
long curPos, curLen; /* selection when we start search */
    {
    long tLen;  /* length of the replace string */
    int found;  /* TRUE if we've found the target of our search */
    int count;  /* # of replaces we've done */
    long extraPos;  /* end of actual change */
    long boundsPos, boundsLen;  /* "marker" of edit view */
    TViewP tvp; /* pointer to tview */
    
    tLen = strlen((char *) rs);
    count = 0;
    
    tvp = (TViewP) GetPtr(vp->textv);
    boundsPos = tvp->bounds.pos;
    boundsLen = tvp->bounds.len;
    ReleasePtr(vp->textv);
    KillPtr(tvp);
    
    found = TRUE; /* so will go thru loop at least once */
    while (found)
        {
        if (option != 2)
            TUTORsave_do_doc(vp->textd,curPos,curLen,1,tLen);
        else
            TUTORsave_do_doc(HNULL,0L,0L,0,0L);
        
        TUTORchange_doc(vp->textd,curPos,curLen,boundsPos,boundsLen,(unsigned char FAR *) rs,
                            tLen,0L,-1,HNULL,&extraPos,FALSE);
        boundsLen += curLen - tLen; /* keep "marker" current */
        extraPos += curLen - tLen;
        RefreshPanel(vp,curPos,extraPos-curPos,curPos,curLen,tLen,curPos+tLen,0L,TRUE,FALSE);
        count++;
        if (option == 0)
            break;
        found = n_editornexts(vp, ss,count == 1,dir);
        if (option == 1)
            break;
        TUTORinq_select_tview(vp->textv,&curPos,&curLen);
        }
    
    return 0;
    }

/* ******************************************************************* */

double PanelScroll(tview,hv,fn,type) /* handle message from scroll bar to text panel */
struct tutorview FAR *tview; /* pointer to panel view */
int hv; /* TRUE if horiz, FALSE if vertical */
double fn;  /* scroll argument (depends on type) */
int type;   /* pageup, lineup, etc. */
/* returns the value scroll bar should have */

{   register long nn;   /* long version of fn */
    REGISTER TextVDat FAR *vp;  /* pointer to panel */
    long retVal;    /* the value we want scroll bar to have (return value) */
    struct tutorview FAR *cv;   /* to save & restore view */
    REGISTER TViewP tvp;    /* pointer to tview */
    register int maxOff;    /* the maximum horizontal offset the tview can have */
    register int curOff;    /* the current offset tview has */
    int left;   /* viewrect left */
    
    if (!tview)
        return(0.);
    
    nn = fn; /* convert double (from scroll bar) to long */
    cv = TUTORinq_view();
    TUTORset_view(tview);
    vp = (TextVDat FAR *) GetPtr(tview->vh);
    
    /* keep doc styles in synch */
    TUTORdefault_styles_doc(vp->textd,(short FAR *) vp->defStyles);
    
    if (!hv) { /* vertical scroll */
        tvp = (TViewP) GetPtr(vp->textv);
        switch (type) {

        case sbToPos:
            nn += tvp->bounds.pos; /* account for text before view */
            break;

        case sbPageUp:
            type = sbVUp;
            nn = tvp->viewRect.bottom - tvp->viewRect.top + 1 -
                    tvp->ld[tvp->topLine].lineHeight; /* where we want top line to go */
            break;

        case sbPageDown:
            type = sbVDown;
            nn = tvp->botLine;
            break;

        case sbVDown: /* andrew-style left click */
            /* convert nn from vertical position to line number */
            nn = _TUTORinq_line_tview(vp->textv,(int) nn);
            break;

        case sbLineUp:
        case sbLineDown:
        case sbVUp: /* andrew-style right click */
            ; /* don't need to do anything */
            break;

        case sbToTop: /* to beginning of view */
            nn = tvp->bounds.pos;
            type = sbToPos;
            break;

        case sbToBot: /* to end of view */
            nn = tvp->bounds.pos + tvp->bounds.len;
            type = sbToPos;
            break;

        default:
            TUTORdump("Unknown scrollv type in PanelScroll");
            break;

    } /* switch */

        ReleasePtr(vp->textv);
        KillPtr(tvp);
        retVal = _TUTORscrollv_tview(vp->textv,type,nn);
    } else { /* horizontal scroll */
        if (type == sbToPos) {
            _TUTORscrollh_tview(vp->textv,(int) -nn);
            retVal = nn;
        } else if (type == sbToTop) {
            _TUTORscrollh_tview(vp->textv,0);
            retVal = 0L;
        } else {
            tvp = (TViewP) GetPtr(vp->textv);
/* scroll-change */
 /*           maxOff = (tvp->viewRect.right - tvp->viewRect.left+1) - tvp->destWidth; */
            maxOff = (tvp->viewRect.right - tvp->viewRect.left+1) - HSCROLL_WIDTH;
            curOff = tvp->leftOff;
            left = tvp->viewRect.left;
            ReleasePtr(vp->textv);
            KillPtr(tvp);

            switch (type) {

            case sbToBot:
                curOff = -maxOff;
                break;

            case sbPageUp:
                curOff += 30;
                break;

            case sbPageDown:
                curOff -= 30;
                break;

            case sbLineUp:
                curOff += 5;
                break;

            case sbLineDown:
                curOff -= 5;
                break;

            case sbVDown: /* Andrew-style left click */
                curOff -= (nn - left);
                break;

            case sbVUp:
                curOff += (nn - left);
                break;

            default:
                TUTORdump("Unknown scrollh type in PanelScroll");

            } /* switch */

            if (curOff > 0)
                curOff = 0;
            else if (curOff < maxOff)
                curOff = maxOff;
            
            _TUTORscrollh_tview(vp->textv,curOff);
            retVal = -curOff;
        } /* type else */
    } /* horizontal else */
    
    ReleasePtr(tview->vh);
    KillPtr(vp);
    TUTORset_view(cv);
    
    return((double) retVal);
} /* PanelScroll */

/* ******************************************************************* */

startcaret(vp,btime) /* re-start editor blinking cursor, if neccessary */
register TextVDat FAR *vp; /* textpanel data */
long btime; /* amount of time (in milliseconds) to next blink */
    {
    struct tutorevent blinkev;  /* time event we will post */

    if (vp->blinkid == 0)
        {
        blinkev.type = EVENT_TIME;
        blinkev.window = vp->view->window; /* edit window */
        blinkev.view = vp->view; /* edit view */
        blinkev.value = time_blink;
        blinkev.timestamp = btime;
        blinkev.eDataP = FARNULL;
        vp->blinkid = TUTORpost_event(&blinkev);
        }
    
    return 0;
    }

/* ******************************************************************* */

static StartSearch1(vp, textH)  /* start the search dialog */
register TextVDat FAR *vp;  /* pointer to panel */
Memh textH; /* handle vp came from */
    {
    if (!vp->searchState)
        return 0; /* not a searchable view */
    
    if (!ResizeTextV(vp,-(SEARCH1HEIGHT + (vp->readOnly ? 0: SEARCH1EXTRA))))
        return 0; /* not enough space */
    
    /* draw search dialog */
    DrawSearch1(vp,TRUE,textH);
    vp->searchState = 2; /* running search dialog */

    /* redraw text */
    /* TUTORupdate_tview(vp->textv); */
    /* ActivatePanel(vp,FALSE,FALSE,FALSE); */
    vp->curActive = vp->searchPanel;
    
    /* redirect events */
    vp->view->caninput = FALSE; /* text view can't get keys & menus */
    
    }

static ResizeTextV(vp,delV) /* helper routine for StartSearch */
register TextVDat FAR *vp;  /* pointer to panel */
int delV; /* negative means text view getting smaller */
/* returns FALSE if cannot do resize */
    {
    REGISTER TViewP tvp;    /* pointer to tview */
    TRect tr;   /* new view rectangle */
    SBarInfo sbv, sbh;  /* vertical & horizontal scroll bar info */
    int dWidth; /* the destination (layout) width of tview */

    /* resize text */
    tvp = (TViewP) GetPtr(vp->textv);
    if (tvp->viewRect.bottom - tvp->viewRect.top < -delV)
        {
        ReleasePtr(vp->textv);
        KillPtr(tvp);
        return(FALSE); /* area too small, can't shrink enough */
        }
    
    /* change relRect, so resize changes viewRect properly */
    if (vp->sizeInfo & BOTTOMSTICK)
        vp->relRect.bottom -= delV;
    if (!(vp->sizeInfo & TOPSTICK))
        vp->relRect.top -= delV;
    
    /* calculate new view rect */
    TUTORuse_rel_rect(&vp->relRect,vp->sizeInfo,vp->view,&tr);
    
    dWidth = tvp->destWidth; /* existing destination width */
        
    ReleasePtr(vp->textv);
    KillPtr(tvp);
    TUTORresize_tview(vp->textv,(TRect FAR *) &tr,dWidth,&sbv,&sbh);

    if (vp->scrollv)
        TUTORreset_text_sbar(vp->scrollv,&sbv,TRUE);
        
    return(TRUE);
    }
    
static DrawSearch1(vp, cFlag,textH) /* draw (& possibly create) search dialog */
register TextVDat FAR *vp;  /* pointer to panel */
int cFlag; /* if TRUE, create objects */
Memh textH; /* needed when creating.  The handle of the text panel */
    {
    REGISTER TViewP tvp;    /* pointer to tview */
    int left, top, right, bottom;   /* desired bounds of dialog */
    TRect tr;   /* rectangle of bounds of dialog */
    TRect tr2;  /* bounds of search & replace sub-panels */
    TRect trB;  /* button rectangle */
    int relInfo;    /* resizing info for sub-panels */
    short ii, jj;
    Memh parentDoc; /* original panel's document */
    DocP dp;    /* pointer to parentDoc */
    short defStyles[NSTYLES];   /* parent doc's default styles */
    int curFont; /* current (saved) font index */
    Memh bFont; /* font to use for search buttons */

    curFont = textFont;
    bFont = -1;
#ifdef WINPC
    bFont = textFont0;
#endif
    tvp = (TViewP) GetPtr(vp->textv);
    top = tvp->viewRect.bottom+1;
    bottom = top + SEARCH1HEIGHT - 1 + (vp->readOnly ? 0 : SEARCH1EXTRA);
    left = tvp->viewRect.left+10;
    right = tvp->viewRect.right-10;
    parentDoc = tvp->doc;
    ReleasePtr(vp->textv);
    KillPtr(tvp);
    relInfo = vp->sizeInfo;
    
    /* draw search dialog */
    TUTORset_rect(&tr,left,top,right,bottom);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
    TUTORframe_abs_rect((TRect FAR *) &tr);
    TUTORinset_rect((TRect FAR *) &tr,1,1);
    TUTORframe_abs_rect((TRect FAR *) &tr);
    
    /* calculate position of search text panel */
    TUTORset_rect(&tr2,left+65,top+SEARCH1SPACE,right-3,top+SEARCH1SPACE+SEARCH1PHEIGHT);
    TUTORframe_abs_rect((TRect FAR *) &tr2);
    if (!vp->readOnly)
        { /* also frame replace panel */
        TUTORmove_rect((TRect FAR *) &tr2,0,SEARCH1EXTRA);
        TUTORframe_abs_rect((TRect FAR *) &tr2);
        TUTORmove_rect((TRect FAR *) &tr2,0,-SEARCH1EXTRA);
        }
    TUTORinset_rect((TRect FAR *) &tr2,2,2);
    
    if (cFlag)
        { /* we are creating objects */
        
        /* make sure global search strings exist */
        if (!searchAllDoc)
            searchAllDoc = TUTORnew_doc(TRUE,TRUE);
        if (!vp->readOnly && !replaceAllDoc)
            replaceAllDoc = TUTORnew_doc(TRUE,TRUE);
        
        vp->searchDoc = TUTORnew_doc(TRUE,TRUE);
        /* copy default styles from parent document */
        dp = (DocP) GetPtr(parentDoc);
        for (ii=0; ii<NSTYLES; ii++)
            defStyles[ii] = dp->defStyles[ii];
        ReleasePtr(parentDoc);
        KillPtr(dp);
        defStyles[PARASTYLE] = 0; /* no indent */
        
        TUTORdefault_styles_doc(vp->searchDoc,(short FAR *) defStyles);
        if (!vp->readOnly)
            {
            vp->replaceDoc = TUTORnew_doc(TRUE,TRUE);
            TUTORdefault_styles_doc(vp->replaceDoc,(short FAR *) defStyles);
            }
        
        /* make sure search view rect is always of constant size */
        if (relInfo & BOTTOMSTICK) /* if text view sticks to bottom... */
            relInfo &= ~TOPSTICK; /* ... search view shouldn't stick to top */
        else
            relInfo &= ~BOTTOMSTICK; /* text view is stuck to top */
            
        /* create panels */
        vp->searchPanel = MakeSearchPanel(vp,&tr2,relInfo,0,textH);
        if (!vp->readOnly)
            vp->replacePanel = MakeSearchPanel(vp,&tr2,relInfo,SEARCH1EXTRA,textH);

	/* create buttons */

        TUTORset_rect(&trB,left+10-1,bottom-(2*SEARCH1BHEIGHT+2*SEARCH1SPACE)-1,
                left+92,bottom - (SEARCH1BHEIGHT+2*SEARCH1SPACE) + 2);
        vp->searchButtons[0] = TUTORnew_button(vp->view->window,HNULL,0,0,&trB,
			0,1,bFont,"Fwd",HNULL,textH,
                        PanelEventStub,SEARCHSIG,SEARCHFWD,0.0,FALSE);
        TUTORmove_rect((TRect FAR *) &trB,90,0);
        vp->searchButtons[1] = TUTORnew_button(vp->view->window,HNULL,0,0,&trB,
			0,1,bFont,"Back",HNULL,textH,
                        PanelEventStub,SEARCHSIG,SEARCHBACK,0.0,FALSE);
        TUTORmove_rect((TRect FAR *) &trB,90,0);
        vp->searchButtons[2] = TUTORnew_button(vp->view->window,HNULL,0,0,&trB,
			0,1,bFont,"Cancel",HNULL,textH,
                        PanelEventStub,SEARCHSIG,SEARCHCANCEL,0.0,FALSE);
        }
    else
        { /* make sure objects are in the right place */
        TUTORset_rect(&trB,left+10,bottom-(2*SEARCH1BHEIGHT+2*SEARCH1SPACE),
                left+90,bottom - (SEARCH1BHEIGHT+2*SEARCH1SPACE));
        for (jj=0; jj<3; jj++)
            {
            TUTORmove_button(vp->searchButtons[jj],trB.left,trB.top,trB.right,trB.bottom);
            TUTORmove_rect((TRect FAR *) &trB,90,0);
            }
        }
    
    /* draw exact toggle */
    jj = bottom - SEARCH1SPACE - SEARCH1BHEIGHT/2; /* middle of toggle y position */
    TUTORset_rect(&tr2,left+10,jj-10,left+10+SEARCH1BHEIGHT,jj+10); /* a square */
    TUTORframe_abs_rect((TRect FAR *) &tr2);
        if (vp->searchExact)
        {
        TUTORinset_rect((TRect FAR *) &tr2,3,3);
        TUTORdraw_abs_solid_rect((TRect FAR *) &tr2, PAT_BLACK);
        }
        
    /* plot text labels */
    TUTORset_button_font(vp->searchButtons[0]);
    TUTORabs_move_to(left+4,top+SEARCH1SPACE+SEARCH1PHEIGHT-8);
    TUTORdraw_text((unsigned char FAR *) "Search:",7);
    if (!vp->readOnly)
        { /* draw prompt for replace */
        TUTORabs_move_to(left+4,top+2*(SEARCH1SPACE+SEARCH1PHEIGHT)-8);
        TUTORdraw_text((unsigned char FAR *) "Replace:",8);
        }
    TUTORabs_move_to(left+20+SEARCH1BHEIGHT,bottom - (SEARCH1SPACE+4));
    TUTORdraw_text((unsigned char FAR *) "Exact match",11);

    TUTORset_textfont(curFont); /* restore font */
    return 0;
    }

/* helper routine for DrawPanel - make subpanel */
static Memh MakeSearchPanel(vp,tr2,relInfo,offset,textH)
register TextVDat FAR *vp;  /* pointer to original panel */
TRect *tr2; /* rectangle of desired subpanel */
int relInfo;    /* resizing info for subpanel */
int offset; /* if == 0, this is search, else this is replace */
Memh textH; /* the text panel (vp points at it) */
/* returns handle of newly created subpanel */
    {
    Memh subPanel;  /* the newly created subpanel */
    REGISTER TextVDat FAR *searchvp;    /* pointer to subpanel */
    Memh doc;   /* document of subpanel */
    long docLen;    /* length of doc */
    long extraPos;  /* dummy */
    SBarInfo sbv;   /* vertical scroll bar info */
    
    if (offset)
        { /* this is replace panel */
        doc = vp->replaceDoc;
        docLen = TUTORget_len_doc(replaceAllDoc);
        TUTORchange_doc_doc(vp->replaceDoc,0L,0L,0L,0L,replaceAllDoc,0L,
                docLen,&extraPos,FALSE);
        }
    else
        { /* this is search panel */
        doc = vp->searchDoc;
        docLen = TUTORget_len_doc(searchAllDoc);
        TUTORchange_doc_doc(vp->searchDoc,0L,0L,0L,0L,searchAllDoc,0L,
                docLen,&extraPos,FALSE);
        }
    if (offset)
        {
        tr2->top += offset;
        tr2->bottom += offset;
        }

    subPanel = MakeTextPanel(vp->view->window,(long) textH,0,0,tr2,relInfo,
                0,TRUE,doc,0L,docLen,FALSE,FALSE,KFilterSearch,FALSE,FALSE,
                FALSE,FALSE,-1,-1,-1,FALSE,4);
    if (offset)
        {
        tr2->top -= offset;
        tr2->bottom -= offset;
        }
    if (!subPanel)
        return(0); /* failed! */
    searchvp = (TextVDat FAR *) GetPtr(subPanel);
    TUTORupdate_tview(searchvp->textv);
    /* if (!offset)
        ActivatePanel(searchvp,TRUE,TRUE,TRUE); /* activate search (not replace) panel */
    TUTORset_select_tview(searchvp->textv,0L,docLen,&sbv);
    
    if (!offset)
        { /* focus set to search panel (not replace) */
        TUTORset_key_focus(vp->view->window,searchvp->view,FALSE);
        windowsP[vp->view->window].MenuFocus = searchvp->view;
        }
    
    ReleasePtr(subPanel);
    KillPtr(searchvp);
    
    return(subPanel);
    }

/* key filter for search dialog subpanels */
static KFilterSearch(ownerDat,textv,cev)
long ownerDat; /* handle of search dialog owner's panel */
Memh textv; /* tview of text panel */
register struct tutorevent *cev; /* the key event structure */
/* returns TRUE if we used key, FALSE otherwise */
    {
    struct tutorevent tempEv;   /* for posting end of search event */
    register int ii;
    int postEvent;  /* if TRUE we are done */
    
    /* look thru event for a newline */
    postEvent = FALSE; 
    for (ii=0; ii<cev->nkeys; ii++)
        if (cev->keys[ii] == NEWLINE || cev->keys[ii] == RETURN)
            {
            cev->nkeys = ii; /* clip out newline */
            postEvent = TRUE;
            break;
            }
    
    /* post a signal indicating that search is over */
    if (postEvent)
        {
        TUTORzero((char FAR *)&tempEv,(long)sizeof(struct tutorevent));
        tempEv.type = EVENT_SIGNAL;
        tempEv.eDataP = FARNULL;
        tempEv.value = SEARCHFWD;
	tempEv.window = -1; /* not sent to a window */
#ifdef THINKC5
	tempEv.vproc = (int(*)(...))(PanelEventStub);
#else
	tempEv.vproc = (int(*)())(PanelEventStub);
#endif
        tempEv.a1 = SEARCHSIG;
        tempEv.a2 = tempEv.a6 = 0;
        tempEv.a5 = ownerDat;
        tempEv.timestamp = 0;
        TUTORpost_event(&tempEv);
        }
    
    return(!cev->nkeys); /* return TRUE if there are no keys left... */
    }

static SearchClick(vp,event)    /* handle click in search dialog */
register TextVDat FAR *vp;  /* pointer to text panel */
struct tutorevent *event;   /* the click event */
    {
    register int top, bottom, left; /* bounds of search dialog */
    TRect tr2;  /* bounds of "exact" toggle */
    REGISTER TViewP tvp;    /* pointer to tview */
    TPoint tpoint;  /* point of the click */
    int jj;
    
    tvp = (TViewP) GetPtr(vp->textv);
    top = tvp->viewRect.bottom+1;
    bottom = top + SEARCH1HEIGHT - 1 + (vp->readOnly ? 0 : SEARCH1EXTRA);
    left = tvp->viewRect.left+10;
    ReleasePtr(vp->textv);
    KillPtr(tvp);
    jj = bottom - SEARCH1SPACE - SEARCH1BHEIGHT/2; /* middle of toggle y position */
    TUTORset_rect(&tr2,left+10,jj-10,left+10+SEARCH1BHEIGHT,jj+10); /* a square */
    tpoint.vv = event->y;
    tpoint.hh = event->x;
    
    if (TUTORpoint_in_rect(tpoint,&tr2))
        { /* toggle exact */
        TUTORinset_rect((TRect FAR *) &tr2,3,3);
        TUTORdraw_abs_solid_rect((TRect FAR *) &tr2, vp->searchExact ? PAT_WHITE : PAT_BLACK);
        vp->searchExact = !vp->searchExact;
        }
    }

static EndSearch1(vp,doDraw,textH)  /* finish the search dialog */
register TextVDat FAR *vp;  /* pointer to main text panel */
int doDraw; /* TRUE if want to redraw main text */
Memh textH; /* where vp came from */
    {
    struct tutorview FAR *vv;   /* pointer to subpanel view */
    register int ii;
    REGISTER TextVDat FAR *searchvp;    /* pointer to subpanel */
    Memh doc;   /* subpanel doc */
    int oldHeight;  /* height of search dialog */
    long extraPos;  /* dummy */
    
    /* get rid of search dialog items */
    for (ii=0; ii< 3; ii++)
        { /* get rid of buttons */
        TUTORclose_button(vp->searchButtons[ii]);
        }
    /* close search panel */
    searchvp = (TextVDat FAR *) GetPtr(vp->searchPanel);
    vv = searchvp->view;
    doc = searchvp->textd;
    ReleasePtr(vp->searchPanel);
    KillPtr(searchvp);
    TUTORclose_panel(vp->searchPanel);
    TUTORclear_doc(searchAllDoc);
    TUTORchange_doc_doc(searchAllDoc,0L,0L,0L,0L,
            doc,0L,TUTORget_len_doc(doc),&extraPos,FALSE);
    if (!vp->readOnly)
        { /* close replace panel */
        searchvp = (TextVDat FAR *) GetPtr(vp->replacePanel);
        vv = searchvp->view;
        doc = searchvp->textd;
        ReleasePtr(vp->replacePanel);
        KillPtr(searchvp);
        TUTORclose_panel(vp->replacePanel);
        TUTORclear_doc(replaceAllDoc);
        TUTORchange_doc_doc(replaceAllDoc,0L,0L,0L,0L,doc,0L,
                    TUTORget_len_doc(doc),&extraPos,FALSE);
        }
    mvar_temp_cleanup(); /* clean up document chain */

    oldHeight = SEARCH1HEIGHT + (vp->readOnly ? 0 : SEARCH1EXTRA);
    ResizeTextV(vp,oldHeight);
    
    /* redraw text */
    vv = vp->view;
    TUTORset_view(vv);
    TUTORdraw_abs_solid_rect(&vv->rr,PAT_WHITE);
    if (doDraw)
        TUTORupdate_tview(vp->textv);
    
    vp->curActive = vp->self; /* current active panel is edit */
    vp->searchState = 1;
    
    /* ActivatePanel(vp,TRUE,FALSE,TRUE); */

    /* fix up events */
    vp->view->canclick = TRUE; /* text view can get clicks now */

    /* fix up event focus */
    TUTORset_key_focus(vp->view->window,vp->view,FALSE);
    windowsP[vp->view->window].MenuFocus = vp->view;
    
    return 0;
    }

/* get search or replace strings */
static GetSearchString2(vp, whichS,ss, maxLen)
register TextVDat FAR *vp;  /* pointer to main panel */
int whichS; /* 0: search, 1: replace, 2: searchAll, 3: replaceAll*/
unsigned char *ss; /* where to copy string */
int maxLen; /* we will copy max of maxLen chars (and then append a null) */
/* returns FALSE if requested string is not available */
    {
    register Memh doc;  /* relevant document */
    long sLen;  /* length of doc */

    switch (whichS)
        {
        case 0: doc = vp->searchDoc; break;
        case 1: doc = vp->replaceDoc; break;
        case 2: doc = searchAllDoc; break;
        case 3: doc = replaceAllDoc; break;
        }

    if (!doc)
        return(FALSE);

    sLen = TUTORget_len_doc(doc);
    if (sLen > maxLen)
        sLen = maxLen; /* clip string that is too long */
    if (sLen == 0)
        *ss = '\0';
    else
        TUTORget_string_doc(doc,0L,sLen,(unsigned char FAR *) ss);

    return(TRUE);
    }

BeforeDialog(vp)    /* special work to do before running dialog over panel */
register TextVDat FAR *vp;  /* pointer to panel */
    {
    TViewP tvp; /* pointer to tview */

    tvp = (TViewP) GetPtr(vp->textv);
    tvp->vActive = TRUE; /* so selection hilite works */
    _TUTORhilite_select(vp->textv,FALSE);
    tvp->vActive = FALSE;
    ReleasePtr(vp->textv);
    KillPtr(tvp);
   }

AfterDialog(vp,updateFlag)  /* special work after dialog over panel */
register TextVDat FAR *vp;  /* pointer to panel */
int updateFlag; /* TRUE if we want to force a redraw of the panel */
    {
    TViewP tvp; /* pointer to tview */

    tvp = (TViewP) GetPtr(vp->textv);
    tvp->vActive = TRUE; /* so selection hilite works */
    _TUTORhilite_select(vp->textv,TRUE);
    tvp->vActive = TRUE;
    ReleasePtr(vp->textv);
    KillPtr(tvp);

    /* make sure focus is correct */
    windowsP[vp->view->window].MenuFocus = vp->view;
    windowsP[vp->view->window].KeyFocus = vp->view;
    if (updateFlag)
        TUTORforce_redraw(vp->view->window);
    }


/* ******************************************************************* */

EditorDefaultStyles(doc) /* put editor's default styles on doc */
Memh doc;   /* document to get default styles */
    
{   ParagraphLayout pLay;   /* the proper paragraph layout */
    short defP; /* the default paragraph style */
    short defStyles[NSTYLES];   /* default styles we want */
    short ii;
    int digitWidth; /* width of a digit (a 5 is used) */

    TUTORset_textfont2(pffamily,pfsize,pfface);
    TUTORinq_abs_string_width((unsigned char FAR *) "5",1,&digitWidth);
    pLay.tabSize = digitWidth * prfP->nTabs;
    pLay.leftMar = pLay.rightMar = 10;
    pLay.paraIndent = 0;
    defP = (AddParaLayout(&pLay) << 3);
    defP |= LEFTJUST;
    
    defStyles[FONTSTYLE] = pffamily;
    defStyles[SIZESTYLE] = pfsize;
    defStyles[FACESTYLE] = pfface;
    defStyles[PARASTYLE] = defP;
    defStyles[COLORSTYLE] = prfP->fcolor; /* normal foreground color */
    defStyles[HOTSTYLE] = 0;
    TUTORdefault_styles_doc(doc,(short FAR *) defStyles);
    
    return(0);

} /* EditorDefaultStyles */

/* ******************************************************************* */

static int CvtTextColor(tColor) /* convert text color to palette color */
struct tutorColor FAR *tColor; /* text color */

{   int slotN;

    if ((tColor->palette != color_rgb) || (CurrentWindow < 0))
	return(tColor->palette); /* already know or can't get palette color */
    slotN = CTinq_closest_color(CurrentWindow,tColor->red,
		tColor->green,tColor->blue,FALSE);
    if (slotN < 0)
	slotN = color_black;
    return(slotN);

} /* CvtTextColor */


/* ******************************************************************* */
