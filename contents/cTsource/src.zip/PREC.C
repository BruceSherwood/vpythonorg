
/* begin-of-file */

/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*  yacc specification for precedence analysis of arithmetic expressions */


#include "compute.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "exprdefs.h"

#ifdef ctproto
extern char FAR *TUTORalloc(long size,int abort,char *label);
int  yywrap(void);
int  yyerror(char  *str);
int  n_parenchk(int  left,int  right);
int  yyparse(void);
int  n_yaddop(int  op);
int  n_addop(int  op);
int  yylex(void);
int  genadda(int  op,long  var,int  indices);
int  n_addtoken(struct  xtoken *t);
int  addad(int  ad,long  dp,long  addr);
int  genarray(int  op,long  var);
int  n_addlit(int  ad,int FAR *vp);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */



#ifdef macproto
extern int sprintf(char *, char *, ...);
#endif

static long nulla = -1;

static int i;	/* work variables */
static struct xtoken t;		/* operator/adytpe */
static char c;
static long lw;


/* ******************************************************************* */

yywrap() { return(TRUE); }

/* ******************************************************************* */

yyerror(str) 
char *str;

{	
	if (exa->errnum!= 0) return(0); /* if lexical error */
	if (indexcnt !=0) {
		exa->errnum = FORMERR;
		exa->errmess = "Array has wrong number of dimensions.";
		return(0); 
	} /* indexcnt if */
	if ((parencnt == 0) && (embedcnt == 0)) {
		cI -= 1;  /* back up for caret positioning */
		exa->errnum = FORMERR;
		exa->errmess = "Bad form."; 
		if (str)
			exa->errmess = str;
	} else { 
		if (parencnt<0) {
			exa->errnum = LPARENERR;
			exa->errmess = "Missing left parenthesis."; 
		} else if (parencnt > 0) {
			exa->errnum = RPARENERR;
			exa->errmess = "Missing right parenthesis.";
			cI -= 1; 
		} else if (embedcnt < 0) {
			exa->errnum = LPARENERR;
			exa->errmess = "Missing left embed.";
		} else {
			exa->errnum = RPARENERR;
			exa->errmess = "Missing right embed.";
			cI -= 1; 
		} /* embedcnt else */
	} /* parencnt == else */
	return(0);

} /* yyerror */

/* ******************************************************************* */

n_parenchk(left,right) int left, right; {
/* return TRUE if parens are same kind (paren, bracket, brace) */
if (left == right) return(TRUE);
parencnt--;  /* force paren error */
yyerror(NULL);
return(FALSE);
}

/* ******************************************************************* */

# define SKIP 200
# define FLITERAL 201
# define ILITERAL 202
# define MLITERAL 203
# define MLITC 204
# define SYSVAR 205
# define ISYSVAR 206
# define MSYSVAR 207
# define MSYSVARA 208
# define TSYSVAR 209
# define GLOBALVAL 210
# define GLOBALADDR 211
# define LOCALVAL 212
# define LOCALADDR 213
# define PASSVAL 214
# define PASSADDR 215
# define GARRAYVAL 216
# define GARRAYADDR 217
# define LARRAYVAL 218
# define LARRAYADDR 219
# define PARRAYVAL 220
# define PARRAYADDR 221
# define GDYARRAYVAL 222
# define GDYARRAYADDR 223
# define LDYARRAYVAL 224
# define LDYARRAYADDR 225
# define PDYARRAYVAL 226
# define PDYARRAYADDR 227
# define GARRAY 228
# define LARRAY 229
# define PARRAY 230
# define GDYARRAY 231
# define LDYARRAY 232
# define PDYARRAY 233
# define LT 234
# define SPLT 235
# define GT 236
# define SPGT 237
# define LE 238
# define SPLE 239
# define GE 240
# define SPGE 241
# define EQ 242
# define SPEQ 243
# define NE 244
# define SPNE 245
# define COMMA 246
# define QUOTE 247
# define ZK 248
# define KEYNAME 249
# define NOT 250
# define MOD 251
# define LEFTPAREN 252
# define SLEFTEMBED 253
# define RIGHTPAREN 254
# define SRIGHTEMBED 255
# define ASSIGN 256
# define OR 257
# define AND 258
# define RELOP 259
# define IRELOP 260
# define LSHIFT 261
# define RSHIFT 262
# define LUNION 263
# define LMASK 264
# define LDIFF 265
# define PLUS 266
# define MINUS 267
# define TIMES 268
# define DIVIDE 269
# define IDIVR 270
# define IDIVT 271
# define UMINUS 272
# define UPLUS 273
# define UNOT 274
# define EXPONENT 275
# define FUNCT 276
# define EFUNCT 277
# define ARCTAN 278
# define ARCTAN2 279
# define ZLENGTH 280
# define ZLENGTHM 281
# define ZLENGTHF 282
# define ZCOMB 283
# define ZEXTENT 284
# define ZSAMEMARK 285
# define ZPRECEDE 286
# define ZSEARCH 287
# define ZSETMARK 288
# define ZTEXTAT 289
# define ZRGBN 290
# define ZHSVN 291
# define ZHASSTYLE 292
# define ZICONCODE 293
# define ZICONFILE 294
# define ZCLIPBOARD 295
#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern short yyerrflag;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
YYSTYPE yylval, yyval;
# define YYERRCODE 256


short yyexca[] ={
-1, 1,
	0, -1,
	-2, 0,
	};
# define YYNPROD 93
# define YYLAST 453
short yyact[]={

   4,  18,  43,  44,  45,  40,  41,  17,  70,  42,
  14,  58,  15, 239,  16,  50,   6,  51,   7, 156,
   8,  50,   9, 194,  10,  50,  11,  65,  66,  68,
  67,  69,  59,  60,  61,  62,  63,  64, 193, 192,
 191,  70,  61,  62,  63,  64, 190,  47,  46,  70,
  22,  37,  48,  49,  59,  60,  61,  62,  63,  64,
 228, 184, 241,  70, 231,  50,  20,  19, 188, 227,
 183,  50,  50,  75,  21,  50,  35,  36,  24, 240,
  23, 168,  50,  25,  26,  27,  31,  32,  33,  34,
  38,  39,  28,  29,  30,  18,  43,  44,  45,  40,
  41,  17, 238,  42,  14,  50,  15,  74,  16,  73,
  77, 171,  78,  72,  79, 230,  80,  71,  81, 170,
  82, 237,  50, 226,  50, 229,  50, 225,  50, 224,
 223,  99,  50,  50,  50, 160, 222, 221,  50,  50,
  50,  47,  46, 165,  22,  37,  48,  49, 103, 220,
 219, 218,  50,  50,  50, 217, 216,  57,  50,  50,
  20,  19, 187, 182, 186, 185,  50,  56,  21,  55,
  35,  36,  24,  50,  23,  50,  50,  25,  26,  27,
  31,  32,  33,  34,  38,  39,  28,  29,  30,  18,
  43,  44,  45,  40,  41,  17, 181,  42,  14,  54,
  15, 160,  16,  53,   6, 180,   7,  50,   8, 164,
   9, 179,  10, 178,  11, 177,  50, 176, 175, 174,
 112,   2,  50, 173,  50, 160,  50,  52,  50,  50,
  50, 172, 102, 163,  50,  47,  46,  12,  22,  37,
  48,  49,  50, 169, 167, 155,  50,  50,  50, 160,
 160, 160, 101, 100,  20,  19,   3, 162, 161, 159,
  98,  97,  21,  96,  35,  36,  24,  95,  23, 107,
 108,  25,  26,  27,  31,  32,  33,  34,  38,  39,
  28,  29,  30,  94,  93,  92,  91,  90,  89,  88,
  87,  86, 131, 132, 133, 134, 135,  85, 105, 106,
   5, 111, 109, 110,  13, 118, 136, 138, 139, 140,
 141, 142, 143, 144, 145, 146, 147, 148, 149, 150,
 151, 152, 153, 154,  76,  83,  84,   1,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0, 137, 104,   0,   0,   0, 158,   0,
   0,   0,   0,   0,   0, 113, 114, 115, 116, 117,
   0,   0,   0,   0, 119, 120, 121, 122, 123, 124,
 125, 126, 127, 128, 129, 130,   0,   0,   0,   0,
   0, 189,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0, 195, 196, 197, 198, 199, 200, 201, 202,
 203, 204, 205,   0,   0, 206, 207, 208, 209, 210,
 157, 211, 212, 213, 214, 215,   0,   0,   0,   0,
   0,   0,   0, 166,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0, 232, 233,   0, 234,
   0, 235, 236 };
short yypact[]={

-200,-1000,-232,-1000,-1000,-241, -25, -49, -53, -83,
 -85, -95,-248,-234,-139,-143,-147,-149,-183,-106,
-106,-106,  45,  39,  38,  37,  36,  35,  34,  33,
  32,  31,  15,  11,   9,   8,-122,   1,   0, -20,
-1000,-1000,-1000,-1000,-1000,-1000,-101,  95,-106,-106,
-1000,-1000,-106,-106,-106,-106,-106,-106,-1000,-106,
-106,-106,-106,-106,-106,-106,-106,-106,-106,-106,
-106,-106,-106,-106,-106,-106,-267, -25, -49, -53,
 -83, -85, -95,-267,-267,-106, -12,-106,-106,-106,
-106,-106,-106,-106,-106,-106,-106,-106,-106,-106,
-106,-106,-106,-1000,-1000,-1000,-1000,  -9,-236,-106,
-106,   5,-232,   4,   3, -21, -45,-111,-106,-226,
-226,-267,-267,-267,-267,-212,-212,-212,-212,-212,
-1000,-232,-232,-232,-232,-232, -10,-173, -11,-135,
 -15, -23, -27, -28, -29, -31, -33, -35, -41, -50,
 -91,-185, -81, -82, -84,-1000,-1000,-241,-248,-188,
-106,-210,-216,-217,-218,-233,-234,-1000,-1000,-1000,
-1000,-106,-106,-106,-106,-106,-106,-106,-106,-106,
-106,-106,-1000,-1000,-106,-106,-106,-106,-106,-232,
-106,-106,-106,-106,-106, -98, -99,-103,-104,-105,
-117,-118,-124,-125,-119,-123,-186,-129,-131,-182,
-232,-232,-232,-232,-232,-232,-1000,-1000,-1000,-1000,
-1000,-1000,-1000,-1000,-1000,-106,-106,-1000,-106,-1000,
-106,-106,-133,-152,-242,-175,-192,-1000,-1000,-1000,
-1000,-1000 };
short yypgo[]={

   0, 327, 237, 301, 220, 256, 304, 305, 300, 303,
 302 };
short yyr1[]={

   0,   1,   1,   1,   1,   5,   5,   5,   5,   5,
   5,   6,   6,   6,   6,   6,   6,   6,   6,   6,
   6,   6,   6,   6,   6,   6,   6,   6,   6,   6,
   6,   6,   6,   6,   6,   6,   6,   6,   6,   6,
   6,   6,   6,   6,   6,   6,   6,   6,   6,   6,
   6,   6,   6,   6,   6,   6,   6,   6,   6,   6,
   6,   6,   6,   6,   6,   6,   6,   6,   6,   6,
   6,   6,   6,   6,   6,   6,   6,   6,   6,   6,
   6,   6,   3,   3,   2,   7,   2,   8,   9,   8,
   4,  10,   4 };
short yyr2[]={

   0,   1,   1,   1,   0,   1,   1,   1,   1,   1,
   1,   3,   3,   3,   3,   6,   6,   6,   6,   6,
   6,   3,   3,   3,   3,   3,   3,   3,   3,   3,
   3,   3,   3,   2,   2,   3,   2,   4,   4,   4,
   4,   6,   6,   6,   6,   6,   6,   6,   6,   6,
   8,   8,   4,   4,   6,   8,   6,   8,   8,   4,
   4,   4,   4,   4,   4,   1,   1,   1,   1,   1,
   1,   1,   1,   1,   1,   1,   2,   2,   2,   2,
   3,   3,   1,   3,   1,   0,   4,   1,   0,   4,
   1,   0,   4 };
short yychk[]={

-1000,  -1,  -4,  -5, 200,  -8, 216, 218, 220, 222,
 224, 226,  -2,  -6, 210, 212, 214, 207, 201, 267,
 266, 274, 250, 280, 278, 283, 284, 285, 292, 293,
 294, 286, 287, 288, 289, 276, 277, 251, 290, 291,
 205, 206, 209, 202, 203, 204, 248, 247, 252, 253,
 257, 258, 252, 252, 252, 252, 252, 252, 259, 266,
 267, 268, 269, 270, 271, 261, 262, 264, 263, 265,
 275, 256, 256, 256, 256, 256,  -6, 216, 218, 220,
 222, 224, 226,  -6,  -6, 252, 252, 252, 252, 252,
 252, 252, 252, 252, 252, 252, 252, 252, 252, 253,
 252, 252, 252, 249, 249, 203, 204,  -4,  -4, -10,
  -9,  -3,  -4,  -3,  -3,  -3,  -3,  -3,  -7,  -6,
  -6,  -6,  -6,  -6,  -6,  -6,  -6,  -6,  -6,  -6,
  -6,  -4,  -4,  -4,  -4,  -4,  -4,  -5,  -4,  -4,
  -4,  -4,  -4,  -4,  -4,  -4,  -4,  -4,  -4,  -4,
  -4,  -4,  -4,  -4,  -4, 254, 255,  -8,  -2, 254,
 246, 254, 254, 254, 254, 254,  -6, 254, 254, 254,
 254, 246, 246, 246, 246, 246, 246, 246, 246, 246,
 246, 246, 254, 255, 246, 246, 246, 246, 256,  -4,
 256, 256, 256, 256, 256,  -4,  -4,  -4,  -4,  -4,
  -4,  -4,  -4,  -4,  -4,  -4,  -4,  -4,  -4,  -4,
  -4,  -4,  -4,  -4,  -4,  -4, 254, 254, 254, 254,
 254, 254, 254, 254, 254, 246, 246, 255, 246, 254,
 246, 246,  -4,  -4,  -4,  -4,  -4, 254, 254, 255,
 254, 254 };
short yydef[]={

   4,  -2,   1,   2,   3,  90,   5,   6,   7,   8,
   9,  10,  87,  84,  69,  70,  71,  68,  72,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
  65,  66,  67,  73,  74,  75,   0,   0,   0,   0,
  91,  88,   0,   0,   0,   0,   0,   0,  85,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,  33,   0,   0,   0,
   0,   0,   0,  34,  36,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,  76,  77,  78,  79,   0,   0,   0,
   0,   0,  82,   0,   0,   0,   0,   0,   0,  22,
  23,  24,  25,  26,  27,  28,  29,  30,  31,  32,
  35,  11,  12,  13,  14,  21,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,  80,  81,  92,  89,  59,
   0,  60,  61,  62,  63,  64,  86,  37,  38,  39,
  40,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,  52,  53,   0,   0,   0,   0,   0,  83,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
  15,  16,  17,  18,  19,  20,  41,  42,  43,  44,
  45,  46,  47,  48,  49,   0,   0,  54,   0,  56,
   0,   0,   0,   0,   0,   0,   0,  50,  51,  55,
  57,  58 };
#ifndef lint
static char yaccpar_sccsid[] = "@(#)yaccpar	4.1	(Berkeley)	2/11/83";
#endif

#
# define YYFLAG -1000
# define YYERROR goto yyerrlab
# define YYACCEPT return(0)
# define YYABORT return(1)

/*	parser for yacc output	*/

#ifdef YYDEBUG
int yydebug = 0; /* 1 for debugging */
#endif
short FAR *yys;
int yyForceErr = 0; /* prec.ed patch so error exits work */
YYSTYPE FAR *yyv = FARNULL;
int yychar = -1; /* current input token number */
int yynerrs = 0;  /* number of errors */
short yyerrflag = 0;  /* error recovery flag */

yyparse() {

	short yyj, yym;

/* prec.ed patch to make pointers FAR -- */
register YYSTYPE FAR *yypvt;
register YYSTYPE FAR *yypv;
register short yystate, yyn;
short FAR *yyps;
short FAR *yyxi;

	yyForceErr = 0; /* prec.ed patch so error exits work */
	if (yyv == FARNULL) {
		yyv = (YYSTYPE FAR *)TUTORalloc((long)((YYMAXDEPTH+2)*sizeof(YYSTYPE)),TRUE,"yyv");
		yyv++; /* so yyv[-1] pointer arithmetic works */
		yys = (short FAR *)TUTORalloc((long)((YYMAXDEPTH+2)*sizeof(short)),TRUE,"yys");
		yys++; /* so yys[-1] pointer arithmetic works */
	}
/* prec.ed patch */
	yystate = 0;
	yychar = -1;
	yynerrs = 0;
	yyerrflag = 0;
	yyps= &yys[-1];
	yypv= &yyv[-1];

 yystack:    /* put a state and value onto the stack */

#ifdef YYDEBUG
	if( yydebug  ) printf( "state %d, char 0%o\n", yystate, yychar );
#endif
		if( ++yyps> &yys[YYMAXDEPTH] ) { yyerror( "yacc stack overflow" ); return(1); }
		*yyps = yystate;
		++yypv;
		*yypv = yyval;

 yynewstate:

	yyn = yypact[yystate];

	if( yyn<= YYFLAG ) goto yydefault; /* simple state */

	if( yychar<0 ) if( (yychar=yylex())<0 ) yychar=0;
	if( (yyn += yychar)<0 || yyn >= YYLAST ) goto yydefault;

	if( yychk[ yyn=yyact[ yyn ] ] == yychar ){ /* valid shift */
		yychar = -1;
		yyval = yylval;
		yystate = yyn;
		if( yyerrflag > 0 ) --yyerrflag;
		goto yystack;
		}

 yydefault:
	/* default state action */

	if( (yyn=yydef[yystate]) == -2 ) {
		if( yychar<0 ) if( (yychar=yylex())<0 ) yychar = 0;
		/* look through exception table */

		for( yyxi=yyexca; (*yyxi!= (-1)) || (yyxi[1]!=yystate) ; yyxi += 2 ) ; /* VOID */

		while( *(yyxi+=2) >= 0 ){
			if( *yyxi == yychar ) break;
			}
		if( (yyn = yyxi[1]) < 0 ) return(0);   /* accept */
		}

	if( yyn == 0 ){ /* error */
		/* error ... attempt to resume parsing */

		switch( yyerrflag ){

		case 0:   /* brand new error */

			yyerror( "syntax error" );
	if (yyForceErr) return(1); /* prec.ed patch so error exits work */
		yyerrlab:
			++yynerrs;

		case 1:
		case 2: /* incompletely recovered error ... try again */

			yyerrflag = 3;

			/* find a state where "error" is a legal shift action */

			while ( yyps >= yys ) {
			   yyn = yypact[*yyps] + YYERRCODE;
			   if( yyn>= 0 && yyn < YYLAST && yychk[yyact[yyn]] == YYERRCODE ){
			      yystate = yyact[yyn];  /* simulate a shift of "error" */
			      goto yystack;
			      }
			   yyn = yypact[*yyps];

			   /* the current yyps has no shift onn "error", pop stack */

#ifdef YYDEBUG
			   if( yydebug ) printf( "error recovery pops state %d, uncovers %d\n", *yyps, yyps[-1] );
#endif
			   --yyps;
			   --yypv;
			   }

			/* there is no state on the stack with an error shift ... abort */

	yyabort:
			return(1);


		case 3:  /* no shift yet; clobber input char */

#ifdef YYDEBUG
			if( yydebug ) printf( "error recovery discards char %d\n", yychar );
#endif

			if( yychar == 0 ) goto yyabort; /* don't discard EOF, quit */
			yychar = -1;
			goto yynewstate;   /* try again in the same state */

			}

		}

	/* reduction by production yyn */

#ifdef YYDEBUG
		if( yydebug ) printf("reduce %d\n",yyn);
#endif
		yyps -= yyr2[yyn];
		yypvt = yypv;
		yypv -= yyr2[yyn];
		yyval = yypv[1];
		yym=yyn;
			/* consult goto table to find next state */
		yyn = yyr1[yyn];
		yyj = yypgo[yyn] + *yyps + 1;
		if( yyj>=YYLAST || yychk[ yystate = yyact[yyj] ] != -yyn ) yystate = yyact[yypgo[yyn]];
		switch(yym){
			
case 1:
{ n_addop(0); } break;
case 2:
{ n_addop(0); } break;
case 3:
{ n_yaddop(SKIP) ; } break;
case 4:
{ if (exa->errnum==0) {
                       		cI--; /* for error reporting */
			exa->errnum = BLANKERR;
 			exa->errmess="Blank expression."; } } break;
case 5:
{ genarray(GARRAY, yypvt[-0].defloc); } break;
case 6:
{ genarray(LARRAY, yypvt[-0].defloc); } break;
case 7:
{ genarray(PARRAY, yypvt[-0].defloc); } break;
case 8:
{ genarray(GDYARRAY, yypvt[-0].defloc); } break;
case 9:
{ genarray(LDYARRAY, yypvt[-0].defloc); } break;
case 10:
{ genarray(PDYARRAY, yypvt[-0].defloc); } break;
case 11:
{ addad(GLOBALADDR,yypvt[-2].defloc,nulla); 
			  exa->varcnt++;
			  n_yaddop(ASSIGN);
			  exa->opcnt++; exa->assigned = TRUE; } break;
case 12:
{ addad(LOCALADDR,yypvt[-2].defloc,nulla); 
			  exa->varcnt++;
			  n_yaddop(ASSIGN);
			  exa->opcnt++; exa->assigned = TRUE; } break;
case 13:
{ addad(PASSADDR,yypvt[-2].defloc,nulla); 
			  exa->varcnt++;
			  n_yaddop(ASSIGN);
			  exa->opcnt++; exa->assigned = TRUE; } break;
case 14:
{	if ((yypvt[-2].lval != ZARROWM) && (yypvt[-2].lval != ZARROWSEL) && (yypvt[-2].lval != ZCLIPBOARD)) {
				exa->errnum = FORMERR;
 				exa->errmess="Illegal left side of assignment.";
			} /* if */
			t.defloc = HNULL;  	/* not defined variable */
			t.constf = FALSE;	/* set not constant */
			t.type = TMARK;
			t.code= MSYSVARA;	/* store-able marker reserved word */
			t.ivalue = yypvt[-2].lval;
			t.fvalue = 0.0;
			exa->varcnt++;
			exa->opcnt++;
			exa->assigned = TRUE; 
			n_addtoken(&t);		/* add store-able reserved marker */
			n_yaddop(ASSIGN);
		} break;
case 15:
{ if (!n_parenchk(yypvt[-4].ival,yypvt[-2].ival)) return(0);
			  if (!genadda(GARRAYADDR,yypvt[-5].defloc,yypvt[-3].ival))
				return(0); 
			  exa->varcnt++;
			  n_yaddop(ASSIGN);
			  exa->opcnt++; exa->assigned = TRUE; } break;
case 16:
{ if (!n_parenchk(yypvt[-4].ival,yypvt[-2].ival)) return(0);
			  if (!genadda(LARRAYADDR,yypvt[-5].defloc,yypvt[-3].ival))
				return(0); 
			  exa->varcnt++;
			  n_yaddop(ASSIGN);
			  exa->opcnt++; exa->assigned = TRUE; } break;
case 17:
{ if (!n_parenchk(yypvt[-4].ival,yypvt[-2].ival)) return(0);
			  if (!genadda(PARRAYADDR,yypvt[-5].defloc,yypvt[-3].ival))
				return(0); 
			  exa->varcnt++;
			  n_yaddop(ASSIGN);
			  exa->opcnt++; exa->assigned = TRUE; } break;
case 18:
{ if (!n_parenchk(yypvt[-4].ival,yypvt[-2].ival)) return(0);
			  if (!genadda(GDYARRAYADDR,yypvt[-5].defloc,yypvt[-3].ival))
				return(0); 
			  exa->varcnt++;
			  n_yaddop(ASSIGN);
			  exa->opcnt++; exa->assigned = TRUE; } break;
case 19:
{ if (!n_parenchk(yypvt[-4].ival,yypvt[-2].ival)) return(0);
			  if (!genadda(LDYARRAYADDR,yypvt[-5].defloc,yypvt[-3].ival))
				return(0); 
			  exa->varcnt++;
			  n_yaddop(ASSIGN);
			  exa->opcnt++; exa->assigned = TRUE; } break;
case 20:
{ if (!n_parenchk(yypvt[-4].ival,yypvt[-2].ival)) return(0);
			  if (!genadda(PDYARRAYADDR,yypvt[-5].defloc,yypvt[-3].ival))
				return(0); 
			  exa->varcnt++;
			  n_yaddop(ASSIGN);
			  exa->opcnt++; exa->assigned = TRUE; } break;
case 21:
{ exa->errnum = FORMERR;
 			  exa->errmess="Can't assign to constant.";
			  exa->varcnt++;
			  exa->opcnt++; exa->assigned = TRUE; } break;
case 22:
{ n_yaddop(PLUS); 
			  exa->opcnt++; } break;
case 23:
{ n_yaddop(MINUS); 
			  exa->opcnt++; } break;
case 24:
{ n_yaddop(TIMES); 
			  exa->opcnt++; } break;
case 25:
{ n_yaddop(DIVIDE); 
			  exa->opcnt++; } break;
case 26:
{ n_yaddop(IDIVR); 
			  exa->opcnt++; } break;
case 27:
{ n_yaddop(IDIVT); 
			  exa->opcnt++; } break;
case 28:
{ n_yaddop(LSHIFT); 
			  exa->opcnt++; } break;
case 29:
{ n_yaddop(RSHIFT); 
			  exa->opcnt++; } break;
case 30:
{ n_yaddop(LMASK); 
			  exa->opcnt++; } break;
case 31:
{ n_yaddop(LUNION); 
			  exa->opcnt++; } break;
case 32:
{ n_yaddop(LDIFF); 
			  exa->opcnt++; } break;
case 33:
{ n_yaddop(UMINUS); exa->canstore = FALSE; } break;
case 34:
{ exa->canstore = FALSE; } break;
case 35:
{ n_yaddop(EXPONENT); 
			  exa->opcnt++; } break;
case 36:
{ n_yaddop(NOT); } break;
case 37:
{ if (!n_parenchk(yypvt[-2].ival,yypvt[-0].ival)) return(0);
                       		  n_yaddop(NOT); } break;
case 38:
{  if (!n_parenchk(yypvt[-2].ival,yypvt[-0].ival)) return(0);
                       		  n_yaddop(ZLENGTH); 
				} break;
case 39:
{	if (!n_parenchk(yypvt[-2].ival,yypvt[-0].ival)) return(0);
                       		n_yaddop(ZLENGTHM);  } break;
case 40:
{ if (!n_parenchk(yypvt[-2].ival,yypvt[-0].ival)) return(0);
                       		  n_yaddop(ARCTAN); } break;
case 41:
{ if (!n_parenchk(yypvt[-4].ival,yypvt[-0].ival)) return(0);
                       		  n_yaddop(ARCTAN2); } break;
case 42:
{ 	if (!n_parenchk(yypvt[-4].ival,yypvt[-0].ival)) return(0);
                       	n_yaddop(ZCOMB); 
		} break;
case 43:
{ 	if (!n_parenchk(yypvt[-4].ival,yypvt[-0].ival)) return(0);
                       	n_addop(ZEXTENT); 
			if (!exa->mfunctst) exa->canstore = FALSE;
		} break;
case 44:
{ 	if (!n_parenchk(yypvt[-4].ival,yypvt[-0].ival)) return(0);
                       	n_yaddop(ZSAMEMARK); 
			if (!exa->mfunctst) exa->canstore = FALSE;
		} break;
case 45:
{ 	if (!n_parenchk(yypvt[-4].ival,yypvt[-0].ival)) return(0);
                       	n_yaddop(ZHASSTYLE); 
			exa->canstore = FALSE;
		} break;
case 46:
{ 	if (!n_parenchk(yypvt[-4].ival,yypvt[-0].ival)) return(0);
                       	n_yaddop(ZICONCODE); 
			exa->canstore = FALSE;
		} break;
case 47:
{ 	if (!n_parenchk(yypvt[-4].ival,yypvt[-0].ival)) return(0);
                       	n_yaddop(ZICONFILE); 
			exa->canstore = FALSE;
		} break;
case 48:
{ 	if (!n_parenchk(yypvt[-4].ival,yypvt[-0].ival)) return(0);
                       	n_yaddop(ZPRECEDE); 
			if (!exa->mfunctst) exa->canstore = FALSE;
		} break;
case 49:
{ 	if (!n_parenchk(yypvt[-4].ival,yypvt[-0].ival)) return(0);
                       	n_addop(ZSEARCH); 
			if (!exa->mfunctst) exa->canstore = FALSE;
		} break;
case 50:
{ 	if (!n_parenchk(yypvt[-6].ival,yypvt[-0].ival)) return(0);
                       	n_yaddop(ZSETMARK); 
			if (!exa->mfunctst) exa->canstore = FALSE;
		} break;
case 51:
{ 	if (!n_parenchk(yypvt[-6].ival,yypvt[-0].ival)) return(0);
                       	n_yaddop(ZTEXTAT); 
			if (!exa->mfunctst) exa->canstore = FALSE;
		} break;
case 52:
{	if (!n_parenchk(yypvt[-2].ival,yypvt[-0].ival)) return(0);
			n_addop(FUNCT); 
			i = yypvt[-3].ival; 		/* function op code */
			xtokd[ntokd].ivalue = i; 
			if ((i == ZFIRST) || (i == ZLAST) || (i == ZNEXT) ||
			   (i == ZPREVIOUS) || (i == ZBASE) || (i == ZSTART) || 
			   (i == ZNEXTEXPR) ||
			   (i == ZEND) || (i == ZNEXTWORD) || (i == ZNEXTLINE)) {
				if (!exa->mfunctst) exa->canstore = FALSE;
			} else exa->canstore = FALSE;
		} break;
case 53:
{	n_addop(EFUNCT); 
			xtokd[ntokd].ivalue = yypvt[-3].ival; 
			exa->canstore = FALSE;
		} break;
case 54:
{	n_addop(EFUNCT); 
			xtokd[ntokd].ivalue = (yypvt[-5].ival)+1; 
			exa->canstore = FALSE;
		} break;
case 55:
{	n_addop(EFUNCT); 
			xtokd[ntokd].ivalue = (yypvt[-7].ival)+2; 
			exa->canstore = FALSE;
		} break;
case 56:
{ if (!n_parenchk(yypvt[-4].ival,yypvt[-0].ival)) return(0);
                       		  n_yaddop(MOD); } break;
case 57:
{ 	if (!n_parenchk(yypvt[-6].ival,yypvt[-0].ival)) return(0);
                       	n_yaddop(ZRGBN); 
			exa->canstore = FALSE;
		} break;
case 58:
{ 	if (!n_parenchk(yypvt[-6].ival,yypvt[-0].ival)) return(0);
                       	n_yaddop(ZHSVN); 
			exa->canstore = FALSE;
		} break;
case 59:
{ if (!n_parenchk(yypvt[-2].ival,yypvt[-0].ival)) return(0);
			  if (!genadda(GARRAYVAL,yypvt[-3].defloc,yypvt[-1].ival))
				return(0); 
			  exa->canstore = TRUE;
			  exa->varcnt++; } break;
case 60:
{ if (!n_parenchk(yypvt[-2].ival,yypvt[-0].ival)) return(0);
			  if (!genadda(LARRAYVAL,yypvt[-3].defloc,yypvt[-1].ival))
				return(0); 
			  exa->canstore = TRUE;
			  exa->varcnt++; } break;
case 61:
{ if (!n_parenchk(yypvt[-2].ival,yypvt[-0].ival)) return(0);
			  if (!genadda(PARRAYVAL,yypvt[-3].defloc,yypvt[-1].ival))
				return(0); 
			  exa->canstore = TRUE;
			  exa->varcnt++; } break;
case 62:
{ if (!n_parenchk(yypvt[-2].ival,yypvt[-0].ival)) return(0);
			  if (!genadda(GDYARRAYVAL,yypvt[-3].defloc,yypvt[-1].ival))
				return(0); 
			  exa->canstore = TRUE;
			  exa->varcnt++; } break;
case 63:
{ if (!n_parenchk(yypvt[-2].ival,yypvt[-0].ival)) return(0);
			  if (!genadda(LDYARRAYVAL,yypvt[-3].defloc,yypvt[-1].ival))
				return(0); 
			  exa->canstore = TRUE;
			  exa->varcnt++; } break;
case 64:
{ if (!n_parenchk(yypvt[-2].ival,yypvt[-0].ival)) return(0);
			  if (!genadda(PDYARRAYVAL,yypvt[-3].defloc,yypvt[-1].ival))
				return(0); 
			  exa->canstore = TRUE;
			  exa->varcnt++; } break;
case 65:
{ addad(SYSVAR,-1L,yypvt[-0].lval);
			  exa->varcnt++; } break;
case 66:
{ addad(ISYSVAR,-1L,yypvt[-0].lval);
			  exa->varcnt++; } break;
case 67:
{ addad(TSYSVAR,-1L,yypvt[-0].lval);
			  exa->varcnt++; } break;
case 68:
{ addad(MSYSVAR,-1L,yypvt[-0].lval);
			  exa->varcnt++; } break;
case 69:
{ addad(GLOBALVAL,yypvt[-0].defloc,nulla); 
			  exa->varcnt++; } break;
case 70:
{ addad(LOCALVAL,yypvt[-0].defloc,nulla); 
			  exa->varcnt++; } break;
case 71:
{ addad(PASSVAL,yypvt[-0].defloc,nulla); 
			  exa->varcnt++; } break;
case 72:
{ n_addlit(FLITERAL,(int FAR *) &(yypvt[-0].dval)); } break;
case 73:
{ n_addlit(ILITERAL,(int FAR *) &(yypvt[-0].lval)); } break;
case 74:
{ n_addlit(MLITERAL,(int FAR *) &(yypvt[-0].lval)); } break;
case 75:
{ n_addlit(MLITC,(int FAR *) &(yypvt[-0].lval)); } break;
case 76:
{ exa->canstore = FALSE;
		           lw = yypvt[-0].ival;
			  n_addlit(ILITERAL,(int FAR *) &lw); } break;
case 77:
{ exa->canstore = FALSE;
		           lw = yypvt[-0].ival;
			  n_addlit(ILITERAL,(int FAR *) &lw); } break;
case 78:
{ exa->canstore = FALSE;
		           lw = yypvt[-0].lval;
			  n_addlit(MLITERAL,(int FAR *) &lw); } break;
case 79:
{ exa->canstore = FALSE;
		           lw = yypvt[-0].lval;
			  n_addlit(MLITC,(int FAR *) &lw); } break;
case 80:
{ if (!n_parenchk(yypvt[-2].ival,yypvt[-0].ival)) return(0);
			  exa->canstore = FALSE;
			} break;
case 81:
{ if (!n_parenchk(yypvt[-2].ival,yypvt[-0].ival)) return(0);
			  exa->canstore = FALSE;
			} break;
case 82:
{ yyval.ival = 1; } break;
case 83:
{ yyval.ival += 1; /* count indices */ } break;
case 84:
{ yyval.ival = 0; } break;
case 85:
{ if (yypvt[-1].ival) { n_yaddop(yypvt[-1].ival+1); yyval.ival = ntokd; ibranf = TRUE; }
			  else yyval.ival = -1; } break;
case 86:
{ if (yypvt[-1].ival >= 0) { 
                                                xtokd[yypvt[-1].ival].nextr = ntokd+1;
                                             } 
			  exa->opcnt++;
			  yyval.ival = yypvt[-2].ival; } break;
case 87:
{ if (yypvt[-0].ival) n_yaddop(yypvt[-0].ival); } break;
case 88:
{ yyval.ival = ntokd; } break;
case 89:
{ if (yypvt[-0].ival) n_yaddop(yypvt[-0].ival);
			  n_yaddop(AND);
			  xtokd[yypvt[-1].ival].nextb = ntokd;
                          ibranf = TRUE;
			  exa->opcnt++; } break;
case 90:
{ ; } break;
case 91:
{ yyval.ival = ntokd; } break;
case 92:
{ n_yaddop(OR);
                          xtokd[yypvt[-1].ival].nextb = ntokd;
                          ibranf = TRUE;
			  exa->opcnt++; } break; 
		}
		goto yystack;  /* stack new state and value */

	}
