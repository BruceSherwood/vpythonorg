
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* ******************************************************************* */

#ifdef ibm032z

#include "compile.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "compute.h"
#include "tglobals.h"

	/* code generation subroutines for IBM-032 */

#define nindr 6			/* number array indexes allowed to register */

#define regtl 33	/* size of register reservation table */
			/* last slot in table must always be unused */

#define regx 0		/* unuseable register */
#define rega 1		/* subroutine argument/return/internal register */
#define regw 2		/* general working register */
#define regf 3		/* floating point register */

#define tempal 32	/* number bytes temp storage in stack frame */

#ifdef ctproto
extern int InitExpressionTable(struct exprt FAR *xt);
#endif

extern long lowcore();	/* low-memory routines */
extern long lciresult();
extern double lcfresult();
extern long lcloop();
extern long lcftoi();
extern long lcflt();
extern long lcfgt();
extern long lcfle();
extern long lcfge();
extern long lcfeq();
extern long lcfne();	
extern long lclt();
extern long lcgt();
extern long lcle();
extern long lcge();
extern long lceq();
extern long lcne();
extern long lcimult();
extern long lclshf();
extern long lcrshf();
extern long lcunion();
extern long lcmask();
extern long lcdiff();
extern long lcimult();
extern long lcidivr();
extern long lcidivt();
extern long lccomp();
extern long lcbitcnt();
extern double lcitof();
extern double lcfadd();
extern double lcfsub();
extern double lcfmult();
extern double lcfdiv();
extern double lcfumin();
extern double lcsin();
extern double lccos();
extern double lctan();
extern double lccsc();
extern double lcsec();
extern double lccot();
extern double lcfexpon();
extern double lcfexpic();
extern double lcarcsin();
extern double lcarccos();
extern double lcarccsc();
extern double lcarcsec();
extern double lcarccot();
extern double lcsqrt();
extern double lcabs();
extern double lcexp();
extern double lclog();
extern double lcalog();
extern double lcln();
extern double lcsinh();
extern double lccosh();
extern double lctanh();
extern double lcgamma();
extern double lcfsysv();
extern long lcint();
extern double lcfrac();
extern long lcsign();
extern long lcerr();

static short regtyp[regtl];	/* physical register usage type */
static int regrsv[regtl];	/* register reservation table */
static short reguse[regtl];	/* register used flags */
static int regtrack[regtl];	/* last use of register */

static long slasta;	/* address of store-able operand */
static int slastk;	/* local/global int/float type of store-able operand */
static int slastt;	/* TFLOAT, TINT, TBYTE type of store-able operand */

static int globalr;	/* TRUE if pointer to globals in register */
static int localr;	/* TRUE if pointer to locals in register */
static int tempsl;	/* amount of temporary storage for expression */
static long aerrorc;	/* address of array bounds error exit call */
static int ifcode;	/* begin of expression code (ICODE or FCODE) */
static int codep;	/* index to expression type byte of compiled code */
static int codeb;	/* index to length field of compiled code */
static int prevret;	/* index to previous return jump */

/* ******************************************************************* */

machcod()

/* generate compiled code for IBM-032 */

{	
register int is; 	/* index in token stack */
register struct xtoken *t;	/* pointer to current token */
int ia,ib;	/* index of argument tokens */
int opc, iac, ibc;	/* op, arg1, arg2 codes */
int ar,br,rr,tr;	/* arg1, arg2, result, temporary registers */
int af,bf;		/* INT, FLOAT flags */
int codel;		/* length of compiled code */
int ploc;		/* current location within pcodes */
int aaf;		/* array assign flag */
int iaa;		/* index of token being assigned */
int dim;		/* number array dimensions */
long abase;	/* base address of array */
int asize;		/* size of array elements */
long amaxl;	/* maximum length of array */
long alength;	/* array length (by dimension) */
long alower;	/* array lower bound (by dimension) */
long aclth;	/* accumulated length of array */
int aaddrf;		/* TRUE if array address, FALSE if value */
int larrayi;		/* index of last array reference (for storeability) */
int air[nindr];	/* array index registers */
long *pd;		/* pointer to array description info */
int fpacc;		/* TRUE if floating point accelerator present */
int fpafunc;	/* TRUE if function which destroys fpa regs encountered */
int removed;	/* number bytes removed when continued -calc- appended */
int i,j;		/* work variables */
long lv;
unsigned char *ucp;

/* make register assignments for compiled code */

if (!pgen) {
	fpacc = fpastat();  /* check floating accelerator present */
	fpafunc = FALSE;

	for (i=0; i<regtl; i++) { /* initialize register tables */
		regrsv[i] = 0;
		reguse[i] = FALSE;
		regtrack[i] = 0;
	} /* for */
	slasta = -1;	/* no storeable operand yet */

	is = 0;		/* initialize index */
	larrayi = 0;	/* initialize index of last array reference */
	ploc = 0;		/* initialize logical index */
	topw = 0; 		/* initialize stack */
	tempsl = 0; /* temporary storage required */
	ar = br = tundef;
	t = &xtokd[is];
	while (!xt[t->code].endop) {

		/* chain forward to next operator/operand */

		is = xtokd[is].nextt;	/* link to next token in chain */
		t = &xtokd[is];
		xtokd[is].loc = (++ploc);	/* set logical order */
		opc = t->code;		/* get operator code */
		xtokd[is].result = tundef;	/* pre-set result undefined */
		if (!xt[opc].cgen) pgen = TRUE;	/* cant generate compiled code */

		/* process operand */

		if (!t->opad)  {

			/* check for reserved word - destroys registers */

			if (opc == SYSVAR) {
				regtrack[2] = regtrack[3] = t->loc;
				regtrack[4] = regtrack[5] = t->loc;
			} /* sysvar if */

			/* process indexed array */

			if (xt[opc].array == 1) {
				larrayi = is;	/* save index of last array */
				fpafunc = TRUE;	/* fpa regs may be destroyed */
				for (i=0; i<nindr; i++) air[i] = tundef; /* no registers yet */
				
				/* pick up array dimensions */

				if (tstga(opc)) dim = (long)unit[0].descriptors[t->ivalue+3];
				else dim = (long)unit[compunit].descriptors[t->ivalue+3];

				/* pop operand being assigned to indexed array */

				aaf = tstaa(opc);
				if (aaf)  { iaa = popw(); ar = asgreg(iaa,regw); }

				/* pop array indexes from working stack */

				for (i=1; i<=dim; i++) {
					ia = popw();
					ar = asgreg(ia,regw); /* assign index to register */
					j = dim-i;
					if (j<nindr) air[j] = ar; /* remember register used  */
				} /* for */

				for (i=0; i<nindr; i++) relreg(air[i]);	/* release registers */
				regtrack[2] = regtrack[3] = t->loc;
				regtrack[4] = regtrack[5] = t->loc;
				regtrack[11] = regtrack[12] = t->loc;

				/* restore operand being assigned to indexed array */

				if (aaf) pushw(iaa);	/* push operand back on stack */
			} /* array if */
			pushw(is);	/* push result operand on working stack */

		} /* operand if */
 
		/* process operator */

		else {

			/* function call assumed to destroy fpa regs */

			if (xt[opc].xaddr) fpafunc = TRUE;

			/* process unary operator */

			if (xt[opc].unary) {
				ia = popw();	/* pop operand from working stack */
				iac = xtokd[ia].code;
				if (xt[opc].rr) {	/* process register operator */

					/* special treatment for end - always in r2 */

					if (xt[opc].endop) {
						xtokd[is].result = 2;	/* result = r2 */
						xtokd[ia].result = 2;
					} /* endi if */

					/* process fpa floating unary */

					else if (fpacc && (!fpafunc) && ((opc == UMINUS))) {
						ar = asgreg(ia,regf); /* assign to floating register */
					} /* plus else if */

					/* process ordinary register unary */

					else {
						if (xt[iac].subr) ar = fixreg(ia,2); 
						ar =asgreg(ia,regw); /* assign operand to reg */
					} /* else */
				} /* register if */
						
				/* process subroutine unary */

				else {
					if (opc == EXPONIC) ar = fixreg(ia,3);
					else ar = fixreg(ia,2);
					regtrack[2] = regtrack[3] = t->loc;
					regtrack[4] = regtrack[5] = t->loc;
				} /* subroutine else */

				/* flag registers used if result to temporary */

				if (ar<0) {
					regtrack[2] = regtrack[3] = t->loc;
					regtrack[4] = regtrack[5] = t->loc;
					regtrack[11] = regtrack[12] = t->loc;
				} /* ar if */
				else relreg(ar);
			} /* unary if */

			/* process binary operator */

			else {
				ib = popw();	/* pop 2nd operand from working stack */
				ibc = xtokd[ib].code;
				ia = popw();	/* pop 1st operand from working stack */
				iac = xtokd[ia].code;
				if (xt[opc].rr){

					/* special treatment for assignment - look ahead to */
					/* determine result register */

					if ((opc == ASSIGN) || (opc == IASSIGN) || 
					   (opc == BASSIGN)) {
						br = fixreg(ib,4);
						i = xtokd[is].nextt;
						i = xtokd[i].code; /* get next operand/op code */
						if (xt[i].endop) 
							ar = fixreg(ia,2);
						else ar = asgreg(ia,regw);/* assign opr to reg */
					} /* assign if */

					else if (fpacc && ((opc == PLUS) || (opc == MINUS) ||
					           (opc == UMINUS) || (opc == TIMES) ||
					           (opc == DIVIDE))) {
						if (fpafunc) {
							ar = asgreg(ia,regw); /* assign to reg */
							if (xt[ibc].subr) br = fixreg(ib,2);
							br = asgreg(ib,regw); /* assign to reg */
						} else {
							ar = asgreg(ia,regf); /* to float reg */
							br = asgreg(ib,regf);	
						} /* fpafunc else */
					} /* plus else if */

					/* ordinary register binary op */

					else {
						ar = asgreg(ia,regw); /* assign operand to reg */
						if (xt[ibc].subr) br = fixreg(ib,2);
						br = asgreg(ib,regw); /* assign operand to reg */
					} /* assign else */
				} /* all register if */

				/* ordinary subroutine binary op */

				else {
					br = fixreg(ib,2); /* 2nd argument to r2/r2-r3 */
					if (xt[opc].targ == TFLOAT)
						ar = fixreg(ia,4); /* 1st argument to r4-r5 */
					else ar = fixreg(ia,3);	/* 1st argument to r3 */
					regtrack[2] = regtrack[3] = t->loc;
					regtrack[4] = regtrack[5] = t->loc;
				} /* not-register else */

				/* flag registers used if result to temporary */

				if ((ar<0) || (br<0)) {
					regtrack[2] = regtrack[3] = t->loc;
					regtrack[4] = regtrack[5] = t->loc;
					regtrack[11] = regtrack[12] = t->loc;
				} /* ar if */

				relreg(ar);
				relreg(br);

			} /* binary else */

			pushw(is);	/* push result operand on working stack */

		} /* operator else */

	};  /* while */
	exprmsg("after register\n"); dmpexpr();

} /* not-pgen if */


/* ------------------------------------------------------------------------------ */

/* generate machine instructions */

if (!pgen) {
	is = 0;	/* initialize index */
	topw = 0;	/* initialize working stack */
	for (i=10; i<=14; i++) 
		reguse[i] = TRUE; /* r10,11,12,13,14 used */
	t = &xtokd[0];

	/* initialize for first of multiple expressions */

	if (cmp->multiple == 1) {
		multei = 0; /* init index */
		cmp->multcode = TRUE; /* all compiled so far */
	} /* multiple if */

	/* process continued -calc- and multiple expressions */

	if ((cmp->multiple > 1) && (cmp->multcode))
		cmp->apprev = TRUE; /* can append if multiple, compiled */
	if (cmp->apprev && ((cmpl-codep) > 16000))
		cmp->apprev = FALSE; /* limit code size */

	if (cmp->apprev) {
		removed = cmpl-prevret; /* number bytes removed */
		cmpl = prevret; /* re-set to remove previous return */
		                /* and new -calc- command */
		ifcode = ((endopc == ENDI)? ICODE: FCODE);
		if (cmp->calc || cmp->multiple) ifcode = ICODE;
		plantbyte(ifcode,(long)(codep));
	} else {

		/* add compiled code flag, insure code starts on word boundary */

		codep = cmpl; /* start of expression */
		ifcode = ((endopc == ENDI)? ICODE: FCODE);
		if (cmp->calc || cmp->multiple) ifcode = ICODE;
		addbyte(ifcode);	
		if  (cmpl & 1) addbyte(0);	/* force word boundary */
		codeb = cmpl;		/* save pointer to length */
		addbyte(0);		/* reserve space for code length */
		addbyte(0);
		aerrorc = 0; /* address of call to array error exit */
		genbegin(); /* generate initial setup code */
		globalr = localr = FALSE; /* pointers not in register */
	} /* continued else */

	/* if appended code generate code to update cmdloc */
	/* in case of exec error */

	if (cmp->apprev && (cmp->multiple == 0)) {

		/* generate code to set cmdloc in case exec err */

		if (cmpl <= (prevret+removed)) lv = prevret+removed+1;
		else lv = cmpl; /* insure bias in this command, not prev */
		i = PCMDLOC*sizeof(struct exprt);
		gen32v(11,lv); /* get r11 = position */
		gendf(0xcd,5,14,i);	/* l   r5,k(r14) */
		gendsf(0x3,11,5,0);	/* sts r11,0(r5) */
	} /* appended if */

	/* generate code for each operator/operand */

	while (!xt[t->code].endop) {

		/* chain forward to next operator/operand */

		is = xtokd[is].nextt;	/* link to next token in chain */
		t = &xtokd[is];
		opc = t->code;		/* get operator code */
		tr = rr = t->result;	/* get result register */
		if (tr < 0) tr = 11;		/* use r11 if result to temporary */
		if (tr >= 16)
			if ((opc != ITOF) && (opc != PLUS) && (opc != MINUS) &&
			   (opc != UMINUS) && (opc != TIMES) && (opc != DIVIDE))
				tr =2;	/* use r2 as temp */
			
		/* process operand */

		if (!t->opad)  {

			/* process indexed array */

			if (xt[opc].array == 1) {

				/* pick up array description */
	
				if (tstga(opc)) pd = unit[0].descriptors+t->ivalue;
				else pd = unit[compunit].descriptors+t->ivalue;
				asize = siza(opc);	/* size of array elements */
				abase = (*pd)+4;	/* base address of array */
				amaxl = *(pd+1);	/* total length of array */
				pd += 3;
				dim = (int)(*pd);	/* get number dimensions */
				pd = pd+(dim*2);	/* advance to end of dimensions */
			} /* array if  */
		} /* operand if */
 
		/* process operator */

		else {

			/* process unary operator */

			if (xt[opc].unary) {
				ia = popw();	/* pop operand from working stack */
				ar = xtokd[ia].result;	/* get operand register */
				iac = xtokd[ia].code;
				af = xt[iac].trel;
				if (xt[opc].rr)  /* bring operand to register */
					if (ar<0) { genmovf(af,ar,2,xtokd[ia].resulta); ar = 2;}
				else if (xt[opc].subr) {
					if (opc == EXPONIC) {
						if (ar != 3) { 
							genmovf(af,ar,4,xtokd[ia].resulta);
							ar = 3;
						} /* ar if */
					} else {
						if (ar != 2) { 
							genmovf(af,ar,2,xtokd[ia].resulta); 
							ar = 2;
						} /* ar if */
					} /* exponic else */
				} /* subr else/if */
			} /* unary if */

			/* process binary operator */

			else {
				ib = popw();	/* pop 2nd operand from working stack */
				ia = popw();	/* pop 1st operand from working stack */
 				ar = xtokd[ia].result;	/* get 1st operand register */
				af = xtokd[ia].code;
				af = xt[af].trel;	/* get integer/floating type */
				br = xtokd[ib].result;	/* get 2nd operand register */
				bf = xtokd[ib].code;
				bf = xt[bf].trel;	/* get integer/floating type */
				if (xt[opc].rr) {
					if (xt[opc].targ == TFLOAT) {
						if (ar<0) { 
							genmovf(af,ar,4,xtokd[ia].resulta); 
							ar = 4;
						} /* ar if */
						if (br<0) { 
							genmovf(bf,br,2,xtokd[ib].resulta); 
							br = 2;
						} /* br if */
					} else {
						if (ar<0) {
							genmov(ar,3,xtokd[ia].resulta); 
							ar = 3;
						} /* ar if */
						if (br<0) { 
							genmov(br,2,xtokd[ib].resulta); 
							br = 2;
						} /* br if */
					} /* not-float else */
				} /* all register if */
				else if (xt[opc].subr) {
					if (xt[opc].targ == TFLOAT) {
						if (ar != 4) { 
							genmovf(af,ar,4,xtokd[ia].resulta); 
							ar = 4;
						} /* ar if */
						if (br != 2) { 
							genmovf(bf,br,2,xtokd[ib].resulta); 
							br = 2;
						} /* br if */
					} else {
						if (ar != 3) { 
							genmov(ar,3,xtokd[ia].resulta); 
							ar = 3;
						} /* ar if */
						if (br != 2) { 
							genmov(br,2,xtokd[ib].resulta); 
							br = 2;
						} /* br if */
					} /* not-float else */
				} /* assign else if */
			} /* binary else */

		} /* operator else */

		switch (opc) {

		case ENDI:
		case ENDF:
		tr = ar; /* take result of previous operation */
		if ((!cmp->calc) && (tr != 2)) { /* get result to r2 */
			genmovf(xt[opc].trel,tr,2,xtokd[is].resulta);
		}
		tr = rr = 2;
		break;

		case ILITERAL:
		gen32v(tr,t->ivalue);
		break;

		case FLITERAL:
		ucp = (unsigned char *) &t->fvalue;	/* set pointer to floating value */
		lv = 0;
		for(i=1; i<=4; i++) lv = (lv << 8) | (*ucp++);
		gen32v(tr,lv);
		lv = 0;
		for(i=1; i<=4; i++) lv = (lv << 8) | (*ucp++);
		gen32v(tr+1,lv);
		break;

		case GLOBALVAL:
		setlasta(t->ivalue,PVGLOBALF,TFLOAT);
		gengp();	/* set up pointer to globals */
		i = t->ivalue;
		if (i<0x7fff) {
			gendf(0xcd,tr,13,i);		/* l  ra,k(r13) */
			gendf(0xcd,tr+1,13,i+4);	/* l  rb,k+4(r13) */
		} else {
			gen32v(tr,i);
			genrf(0xe1,tr,13);	/* add  tr,13 */
			gendsf(7,tr+1,tr,1);	/* ls  tr+1,4(tr) */
			gendsf(7,tr,tr,0);	/* ls  tr,0(tr) */
		} /* large address else */
		break;

		case IGLOBALVAL:
		setlasta(t->ivalue,PVGLOBALI,TINT);
		gengp();	/* set up pointer to globals */
		if (t->ivalue<0x7fff) {
			gendf(0xcd,tr,13,t->ivalue);		/* l  r,k(r13) */
		} else {
			gen32v(tr,t->ivalue);
			genrf(0xe1,tr,13);	/* add  tr,13 */
			gendsf(7,tr,tr,0);	/* ls  tr,0(tr) */
		} /* large address else */
		break;

		case BGLOBALVAL:
		setlasta(t->ivalue,PVGLOBALB,TBYTE);
		gengp();	/* set up pointer to globals */
		if (t->ivalue<0x7fff) {
			gendf(0xce,tr,13,t->ivalue);		/* lc  r,k(r13) */
		} else {
			gen32v(tr,t->ivalue);
			genrf(0xe1,tr,13);	/* add  tr,13 */
			gendsf(4,tr,tr,0);	/* lcs  tr,0(tr) */
		} /* large address else */
		break;

		case GLOBALADDR:
		case IGLOBALADDR:
		case BGLOBALADDR:
		if (opc == GLOBALADDR) { 
			i = PVGLOBALF;
			j = TFLOAT;
		} else if (opc == IGLOBALADDR) {
			i = PVGLOBALI;
			j = TINT;
		} else {
			i = PVGLOBALB;
			j = TBYTE;
		}
		setlasta(t->ivalue,i,j);
		gengp();	/* set up pointer to globals */
		if (t->ivalue<0x7fff) {
			gendf(0xc8,tr,13,t->ivalue);	/* cal  r,k(r13) */
		} else {
			gen32v(tr,t->ivalue);
			genrf(0xe1,tr,13);	/* add  tr,13 */
		} /* large address else */
		break;

		case LOCALVAL:
		setlasta(t->ivalue,PVLOCALF,TFLOAT);
		genlp();	/* set up pointer to locals */
		i = t->ivalue;
		if (i<0x7fff) {
			gendf(0xcd,tr,13,i);		/* l  ra,k(r13) */
			gendf(0xcd,tr+1,13,i+4);	/* l  rb,k+4(r13) */
		} else {
			gen32v(tr,i);
			genrf(0xe1,tr,13);	/* add  tr,13 */
			gendsf(7,tr+1,tr,1);	/* ls  tr+1,4(tr) */
			gendsf(7,tr,tr,0);	/* ls  tr,0(tr) */
		} /* large address else */
		break;

		case ILOCALVAL:
		setlasta(t->ivalue,PVLOCALI,TINT);
		genlp();	/* set up pointer to locals */
		if (t->ivalue<0x7fff) {
			gendf(0xcd,tr,13,t->ivalue); /* l  r,k(r13) */
		} else {
			gen32v(tr,t->ivalue);
			genrf(0xe1,tr,13);	/* add  tr,13 */
			gendsf(7,tr,tr,0);	/* ls  tr,0(tr) */
		} /* large address else */
		break;

		case BLOCALVAL:
		setlasta(t->ivalue,PVLOCALB,TBYTE);
		genlp();	/* set up pointer to locals */
		if (t->ivalue<0x7fff) {
			gendf(0xce,tr,13,t->ivalue);	/* lc  r,k(r13) */
		} else {
			gen32v(tr,t->ivalue);
			genrf(0xe1,tr,13);	/* add  tr,13 */
			gendsf(4,tr,tr,0);	/* lcs  tr,0(tr) */
		} /* large address else */
		break;

		case LOCALADDR:
		case ILOCALADDR:
		case BLOCALADDR:
		if (opc == LOCALADDR) {
			i = PVLOCALF;
			j = TFLOAT;
		} else if (opc == IGLOBALADDR) {
			i = PVLOCALI;
			j = TINT;
		} else {
			i = PVLOCALB;
			j = TBYTE;
		}
		setlasta(t->ivalue,i,j);
		genlp();	/* set up pointer to locals */
		if (t->ivalue<0x7fff) {
			gendf(0xc8,tr,13,t->ivalue);	/* cal  r,k(r13) */
		} else {
			gen32v(tr,t->ivalue);
			genrf(0xe1,tr,13);	/* add  tr,13 */
		} /* large address else */
		break;

		case GARRAYVAL:
		case GARRAYADDR:
		case IGARRAYVAL:
		case IGARRAYADDR:
		case BGARRAYVAL:
		case BGARRAYADDR:
		case LARRAYVAL:
		case LARRAYADDR:
		case ILARRAYVAL:
		case ILARRAYADDR:
		case BLARRAYVAL:
		case BLARRAYADDR:

		/* set up store-ablilty info */

		slasta = -1;	/* turn off final lastaddr/lastkind */
		if ((opc == GARRAYVAL) || (opc == GARRAYADDR)) {
			slastk = PVGLOBALF;
			slastt = TFLOAT;
		} else if ((opc == IGARRAYVAL) || (opc == IGARRAYADDR)) {
			slastk = PVGLOBALI;
			slastt = TINT;
		} else if ((opc == BGARRAYVAL) || (opc == BGARRAYADDR)) {
			slastk = PVGLOBALB;
			slastt = TBYTE;
		} else if ((opc == LARRAYVAL) || (opc == LARRAYADDR)) {
			slastk = PVLOCALF;
			slastt = TFLOAT;
		} else if ((opc == ILARRAYVAL) || (opc == ILARRAYADDR)) {
			slastk = PVLOCALI;
			slastt = TINT;
		} else if ((opc == BLARRAYVAL) || (opc == BLARRAYADDR)) {
			slastk = PVLOCALB;
			slastt = TBYTE;
		}

		/* check for assignment to array */

		aaddrf = tstaa(opc);		/* TRUE if address */
		if (aaddrf) iaa = popw();	/* pop operand being assigned */

		/* generate code to compute index into array */

		aclth = 1; /* accumulated length */
		for (i=1; i<=dim; i++) {
			ia = popw();	/* pop next index from working stack */
			ar = xtokd[ia].result;
			if ((ar<0) || ((i == 1) && (ar != 12))) {
				j = ((i == 1) ? 12: 11); /* use r12 1st time, r11 afterwards */
				genmov(ar,j,xtokd[ia].resulta);	/* move to r11/12 */
			} else j = ar;
			alength = *(pd--);	/* lth this dimension */
			alower = *(pd--);	/* lower bound */

			if (alower == 1) {
				genrf(0x92,j,1);	/* sis  rj,1 */
			} else {
				gen32v(2,alower);	/* get alower to r2 */
				genrf(0xe2,j,2);	/* s  r11/12,r2 */
			} /* lower else */
			if (aerrorc == 0) {
				addbyte(0x9);		/* jlt  *+14 */
				addbyte(7);
			} else {
				lv = -((cmpl-aerrorc)/2);
				addbyte(0x8e);	/* jlt  *-k */
				addbyte(0x90+((lv >> 16) & 0xf));
				addbyte((lv >> 8) & 0xff);
				addbyte(lv & 0xff);
			} /* aerrorc else */
			gendf(0xd8,2,0,((alength >> 16) & 0xffff)); /* cau  r2,k */
			gendf(0xc4,2,2,(alength & 0xffff)); /* oil16  r2,r2,k */
			genrf(0xb4,j,2);		/* c  rj,r2 */
			if (aerrorc == 0) {
				addbyte(0x09);		/* jlt  *+16 */
				addbyte(8);
				aerrorc = cmpl;
				gen32v(2,1); /* load constant 1 = array err to r2 */
				gensubr(PCALCE); /* call error handling subroutine */
			} else {
				lv = -((cmpl-aerrorc)/2);
				addbyte(0x88);	/* bnblt  *-k */
				addbyte(0x90+((lv >> 16) & 0xf));
				addbyte((lv >> 8) & 0xff);
				addbyte(lv & 0xff);
			} /* aerrorc else */
			if (i != 1) {
				genmov(j,2,0);		/* copy r11 or r12 to r2 */
				gen32v(3,aclth);	/* load mutiplier to r3 */
				gensubr(ITIMES);	/* call multiply routine */
				genrf(0xe1,12,2);	/* add  r12,r2 */
			} /* not 1st index if */
			aclth = aclth*alength;
		} /* for */

		/* generate code to set arrayitems for store-ability */

		if ((cmp->canstore) && (cmp->reqstore) && (is == larrayi)) {
			if (amaxl < 0x7fff) gendf(0xd2,4,12,amaxl);	/* sfi  r4,r12,amaxl */
			else {
				gen32v(4,amaxl);	/* get array length to r4 */
				genrf(0xe2,4,12);	/* s  r4,r12 */
			} /* long length else */
			i = PARRAYI*sizeof(struct exprt);
			gendf(0xcd,5,14,i);		/* l   r5,k(r14) */
			gendsf(0x3,4,5,0);		/* sts r4,0(r5) */
		} /* store-able if */

		/* generate code to index into array */

		gen32v(11,abase);		/* load base address to r11 */
		if (asize == 8) genrf(0xaa,12,3);		/* sli  r12,3 */
		else if (asize == 4) genrf(0xaa,12,2);		/* sli  r12,2 */
		genrf(0xe1,11,12);				/* a  r11,r12 */
		if (tstga(opc)) gengp(); /* set pointer to globals */
		else genlp(); /* set pointer to locals */
		genrf(0xe1,11,13);		/* a  r11,r13 */

		/* generate code to set lastaddr, lastkind for store-ability */

		if ((cmp->canstore) && (cmp->reqstore) && (is == larrayi)) {
			i = PLASTK*sizeof(struct exprt);
			gendf(0xcd,5,14,i);		/* l  r5,k(r14) */
			gendf(0xc8,4,0,slastt);		/* cal  r4,k */
			gendsf(0x2,4,5,0);		/* sths  r4,0(r5) */
			i = PLASTA*sizeof(struct exprt);
			gendf(0xcd,5,14,i);		/* l   r5,k(r14) */
			gendsf(0x3,11,5,0);		/* sts r11,0(r5) */
		} /* store-able if */
				
		/* generate code to load value */

		if (aaddrf) tr = 11;	/* address result in r11 */
		else if ((tr<0) || (tr>=16)) tr = 2;
		if (asize == 8) {
			if (!aaddrf) {
				gendsf(0x7,tr+1,11,1);	/* ls  tr+1,4(r11) */
				gendsf(0x7,tr,11,0);	/* ls  tr,0(r11) */
			} /* value if */
		} else if (asize == 4) {
			if (!aaddrf) gendsf(0x7,tr,11,0);	/* ls  tr,0(r11) */
		} else {
			if (!aaddrf) gendsf(0x4,tr,11,0);	/* lcs  tr,0(r11) */
		} /* size else */

		/* restore operand being assigned to indexed array */

		if (aaddrf) pushw(iaa);	/* push operand back on stack */
		break;

		case IPLUS:
		if (tr == ar) genrf(0xe1,tr,br);	/* add  ra,rb */
		else {
			genrf(0xe1,br,ar);	/* add  rb,ra */
			tr = br;	/* result in arg 2 register */
		} /* else */
		break;

		case IINC:
		if (tr != ar) gendf(0xc1,tr,ar,1);	/* ai  tr,ar,1 */
		else genrf(0x91,ar,1);	/* inc  r,1 */
		break;

		case IMINUS:
		genrf(0xe2,ar,br);	/* s  ra,rb */
		tr = ar;	/* result in arg 1 register */
		break;

		case IDEC:
		genrf(0x93,ar,1);	/* dec  r,1 */
		tr = ar;	/* result in arg 1 register */
		break;

		case IUMINUS:
		genrf(0xe4,tr,ar);	/* twoc  ra,rb */
		break;

		case ASSIGN:
		gendsf(0x3,ar,br,0);		/* sts  ar,0(br) */
		gendsf(0x3,ar+1,br,1);	/* sts  ar+1,4(br) */
		tr = ar;	/* result in arg 1 register */
		break;

		case IASSIGN:
		gendsf(0x3,ar,br,0);		/* sts  ar,0(br) */
		tr = ar;	/* result in arg 1 register */
		break;

		case BASSIGN:
		gendsf(0x1,ar,br,0);		/* stsc  ar,0(br) */
		tr = ar;	/* result in arg 1 register */
		break;

		case EXPONIC:
		case SYSVAR:
		gen32v(2,t->ivalue);
		gensubr(opc);
		tr = 2;	/* result in d2 */
		break;

		case ITOF:
		case UMINUS:
		if (fpacc) {
			if (opc == ITOF) {
				if (tr<16) tr = 16;	/* use fp0-1 */
				genfpa(0x80c00+((tr-16) << 6)+((tr-16) << 2));	/* ciwl */
				gendsf(0x03,ar,11,0);		/* sts  ar,0(r11) */
			} /* itof */
			else if (opc == UMINUS) {
				if (tr<16) tr = 16;	/* use fp0-1 */
				if (ar<16) {genmovf(af,ar,16,xtokd[ia].resulta);  ar = 16; }
				genfpa(0x15000+((ar-16) << 6)+((tr-16) << 2));	
				gendsf(0x03,11,11,0);		/* sts  r11,0(r11) */
			} /* unary minus elseif */
		} else {
			gensubr(opc);
			tr = 2;	/* result in r2 */
		} /* no floating accelerator else */
		break;

		case PLUS:
		case MINUS:
		case TIMES:
		case DIVIDE:
		if (fpacc) {
			if (ar<16) { genmovf(af,ar,16,xtokd[ia].resulta); ar = 16; }
			if (br<16) { genmovf(bf,br,18,xtokd[ib].resulta); br = 18; }
			if (opc == PLUS) i = 0x10000;		/* addl */
			else if (opc == MINUS) i = 0x14000;	/* subl */
			else if (opc == TIMES) i = 0x1c000;	/* mull */
			else if (opc == DIVIDE) i = 0x18000;	/* divl */
			genfpa(i+((br-16) << 6)+((ar-16) << 2));	
			gendsf(0x03,11,11,0);		/* sts  r11,0(r11) */
			tr = ar;
		} else {
			gensubr(opc);
			tr = 2;	/* result in r2 */
		} /* no floating accelerator else */
		break;

		case ITIMES:
		case IDIVR:
		case IDIVT:
		case LSHIFT:
		case RSHIFT:
		case LUNION:
		case LMASK:
		case LDIFF:
		case COMP:
		case BITCNT:
		case INT:
		case FRAC:
		case ROUND:
		case SIGN:
		case EXPONENT:
		case FTOI:
		case EQ:
		case NE:
		case GT:
		case LT:
		case GE:
		case LE:
		case IEQ:
		case INE:
		case IGT:
		case ILT:
		case IGE:
		case ILE:
		gensubr(opc);
		tr = 2;	/* result in r2 */
		break;

		case FFUNCT:
		gensubr(t->ivalue+256);
		tr = 2;	/* result in r2 */
		break;

		default:
		printf("compile/codegen - unrecognized op %d\n",opc);
		break;

		} /* switch */
			
		/* transfer result register if neccessary */

		if (rr != tr) {
			genmovf(xt[opc].trel,tr,rr,xtokd[is].resulta);
		}

		pushw(is);	/* push result back on working stack */

	};  /* while */

	/* generate code to set arrayitems/lastaddr/lastkind for store-ability */

	if ((cmp->canstore) && (cmp->reqstore) && (slasta >= 0)) {
		if (narrayi) {
			i = PARRAYI*sizeof(struct exprt);
			gendf(0xcd,5,14,i);	/* l  r5,k(r14) */
			gen32v(4,narrayi);	/* get num items to r4 */
			gendsf(0x3,4,5,0);	/* sts  r4,0(r5) */
		} /* arrayitems if */
		i = PLASTK*sizeof(struct exprt);
		gendf(0xcd,5,14,i);		/* l   r5,k(r14) */
		gendf(0xc8,4,0,slastt);		/* cal r4,k */
		gendsf(0x2,4,5,0);		/* sths d4,0(r5) */
		i = PLASTA*sizeof(struct exprt);
		gendf(0xcd,5,14,i);		/* l   r5,k(r14) */
		gen32v(4,slasta); /* get relative address of var to r4 */
        	if ((slastk==PVGLOBALF) || (slastk==PVGLOBALI) ||
		   (slastk==PVGLOBALB)) gengp(); /* set pointer to globals */
		else genlp();	/* set pointer to locals */
		genrf(0xe1,4,13);	/* a  r4,r13 */
		gendsf(0x3,4,5,0);	/* sts  r4,0(r5) */
	} /* store-able if */

	/* generate code to build table of results for multiple expressions */

	if (cmp->multiple) {
		if (cmp->reqstore) {
			if (cmp->multiple == 1) { /* zero index in result table */
				i = PRESULTI*sizeof(struct exprt);
				gendf(0xcd,5,14,i);	/* l   r5,k(r14) */
				genrf(0xe7,11,11);	/* x   r11,r11 */
				gendsf(0x3,11,5,0);	/* sts r11,0(r5) */
			} /* multiple if */
			if (endopc == ENDI) gensubr(ENDIM);
			else gensubr(ENDFM);
		} else {

			/* get pointer to results table */

			i = PRESULT*sizeof(struct exprt);
			gendf(0xcd,5,14,i);	/* l   r5,k(r14) */
			i = multei*sizeof(struct evresult);
			if (i) gendf(0xc1,5,5,i);	/* ai  r5,r5,k */

			/* set integer/float type */

			i = (endopc == ENDF);
			gendf(0xc2,11,0,i);	/* cal16  r11,0,k */
			gendsf(0x3,11,5,0);	/* sts r11,0(r5) */

			/* store integer or floating result */

			if (endopc == ENDI) {
				gendsf(0x3,2,5,1);	/* sts r2,4(r5) */
			} else {
				gendsf(0x3,2,5,2);	/* sts r2,8(r5) */
				gendsf(0x3,3,5,3);	/* sts r3,12(r5) */
			} /* endopc else */

			/* update index in results table */

			i = PRESULTI*sizeof(struct exprt);
			gendf(0xcd,5,14,i);	/* l   r5,k(r14) */
			gendf(0xc2,11,0,(multei+1)); /* cal16  r11,0,k */
			gendsf(0x3,11,5,0);	/* sts r11,0(r5) */
		} /* reqstore else */
	} /* multiple if */
	

	/* generate code to restore registers and return */

	prevret = cmpl; /* save addr of lm for continued -calc- */
	if (cmp->calc) {
		addbyte(0xc2); /* cal16  r10,0,k */
		addbyte(0xa0);
		lv = cmpl;
		addint2(0); /* reserve space for uloc value */
		i = PULOC*sizeof(struct exprt);
		gendf(0xcd,5,14,i); /* l   r5,k(r14) r5 = &uloc */
		gendsf(0x2,10,5,0); /* sths  r10,0(r5) */
		genret(); /* generate code to restore registers and return */
		plantint2((int)(cmpl),lv); /* plant uloc value */
	} else genret();

	/* set length of compiled code */

	codel = cmpl-(codeb+2);
	cmpbuf[codeb] = (codel >> 8) & 0xff;
	cmpbuf[codeb+1] = codel & 0xff;

	/* if multiple expression, build table */

	if (cmp->multiple) {
		multeic[multei++] = codep; /* index to begin */
	} /* multiple if */

} /* not-pgen if */

} /* machcod */


/* ******************************************************************* */

int genloop(mode,cmdp,addr)
/* generate compiled code for -loop- and related commands*/

int mode; /*  0 = initializations */
          /* +n = command number, cmdp assumed valid */
long cmdp; /* starting position of command */
long addr; /* -outloop- loop exit address */

{	long brptr; /* position of branch displacement */
	long brptr1, brptr2, brptr3; 
	long headptr; /* position of top of loop */
	int codel; /* length of compiled code */
	int cangen; /* TRUE if can compile  loop */
	int i; /* work variable */

	if (mode == 0) return(TRUE);

	if (cmdp > 0x7ff0) return(FALSE);

	/* compile "loop" (no tag) or "loop (condition)" forms */
	/* compile "loop  i:=a,b" and "loop  i:=a,b,c" forms */

	if ((mode == LOOP) || (mode == LOOPB) || (mode == ILOOPONEB) || 
	    (mode == ILOOPGENB)) {
		brptr1 = brptr2 = brptr3 = 0;
		if ((mode == ILOOPONEB) || (mode == ILOOPGENB)) {
			if (cmpbuf[cmdp+3] != ICODE) return(FALSE);
			if (!cmp->multcode) return(FALSE);
			i = cmpbuf[cmdp];
			if ((i != ILOOPONEB) && (i != ILOOPGENB)) 
				return(FALSE);
			cmpl = prevret; /* reset to remove return */

			/* generate test to skip first increment+test */

			i = PLOOPINT*sizeof(struct exprt);
			gendf(0xcd,5,14,i); /* l   r5,k(r14) */
			gendsf(0x7,11,5,0); /* ls  r11,0(r5) r11 = loopint */
			genrf(0xe7,10,10);  /* x   r10,r10 */
			gendsf(0x3,10,5,0); /* sts r10,0(r5) clear loopint */
			genrf(0xe3,11,11);  /* o   r11,r11 */
			brptr1 = cmpl;
			addbyte(0x09);      /* jlt *+k */
			addbyte(0); /* reserve byte for displacement */

			/* get address of results table */

			i = PRESULT*sizeof(struct exprt);
			gendf(0xcd,5,14,i); /* l   r5,k(r14) */

			/* get increment for general increment case */

			if (mode == ILOOPGENB) {
				i = (2*sizeof(struct evresult))+4;
				gendf(0xc1,10,5,i);  /* ai  r10,r5,k */
				gendsf(0x7,11,10,0); /* ls  r11,0(r10) r11 = inc */
			} /* mode if */

			/* get address of index var from results table */

			gendf(0xc1,10,5,20); /* ai  r10,r5,20 */
			gendsf(0x7,10,10,0); /* ls  r10,0(r10) r10 = lastaddr */

			/* increment index */

			gendsf(0x7,4,10,0); /* ls  r4,0(r10) r4 = index */
			if (mode == ILOOPGENB) {
				genrf(0xe1,4,11); /* a  r4,r11 */
			} else {
				genrf(0x90,4,1); /* ais  r4,1 */
			} /* else */
			gendsf(0x3,4,10,0); /* sts r4,0(r10) update index */

			/* compute address of end value table entry */

			i = sizeof(struct evresult)+4; /* bias to end value */
			gendf(0xc1,10,5,i); /* ai  r10,r5,k - xresult[1].lval */
			gendsf(0x7,10,10,0); /* ls  r10,0(r10) */
			
			/* generate end-test */
			/* perform appropriate test for sign of increment */

			if (mode == ILOOPGENB) {
				genrf(0xe3,11,11);  /* o   r11,r11 */
				brptr = cmpl;
				addbyte(0x0b);      /* jgt *+k */
				addbyte(0); /* reserve byte for displacement */
				genrf(0x92,10,1); /* sis r10,1 */
				genrf(0xb4,4,10); /* c  r4,r10 */
				brptr2 = cmpl;
				addbyte(0x0b); /* jgt  *+k - jump to continue loop */
				addbyte(0); /* reserve byte for displacement */
				brptr3 = cmpl; 
				addbyte(0x00); /* j    *+k - jump to end loop */
				addbyte(0); /* reserve byte for displacement */
				plantbyte(((cmpl-brptr)>>1),brptr+1); /* plant branch displ */
			} /* mode if */
			genrf(0x90,10,1); /* ais  r10,1 */
			genrf(0xb4,4,10); /* c  r4,r10 */
			brptr = cmpl;
			addbyte(0x09); /* jlt  *+k - jump to continue loop */
			addbyte(0); /* reserve byte for displacement */
		} else if (mode == LOOP){
			if (cmpbuf[cmdp+3] != ICODE) return(FALSE);
			if (!cmp->multcode) return(FALSE);
			cmpl = prevret; /* reset to remove return */

			/* generate test and branch */

			genrf(0xe3,2,2);  /* o   r2,r2 */
			brptr = cmpl;
			addbyte(0x09);    /* jlt *+k - jump to continue loop */
			addbyte(0); /* reserve byte for displacement */
		} else if (mode == LOOPB) {

			/* generate expression header and setup code */

			codep = cmpl; /* start of expression */
			addbyte(ICODE);
			if (cmpl & 1) addbyte(0); /* force word boundary */
			codeb = cmpl;	/* save pointer to length */
			addbyte(0);	/* reserve space for code length */
			addbyte(0);
			aerrorc = 0;	/* address of call to array error exit */
			globalr = localr = FALSE; /* pointers not in register */
			genbegin(); /* initial setup code */

			/* generate branch over exit code */

			brptr = cmpl;
			addbyte(0x00); /* j    *+k - jump to continue loop */
			addbyte(0); /* reserve byte for displacement */		
		} else return(FALSE);

		/* generate code to update uloc */

		loopexit = cmpl; /* save address of update code */
		if (brptr3)
			plantbyte(((cmpl-brptr3)>>1),brptr3+1); /* plant branch displ */
		i = PCODEP*sizeof(struct exprt);
		gendf(0xcd,5,14,i); /* l   r5,k(r14) r5 = &pcodep */
		gendsf(0x7,5,5,0);  /* ls  r5,0(r5)  r5 = pcodep */
		gendf(0xc1,5,5,(cmdp+1)); /* ai  r5,r5,k */
		gendsf(0x4,10,5,0); /* lcs r10,0(r5) */
		genrf(0xaa,10,8);   /* sli r10,8 */
		gendsf(0x4,11,5,1); /* lcs r11,1(r5) */
		genrf(0xe3,10,11);  /* o   r10,r11 */
		i = PULOC*sizeof(struct exprt);
		gendf(0xcd,5,14,i); /* l   r5,k(r14) r5 = &uloc */
		gendsf(0x2,10,5,0);  /* sths  r10,0(r5) */
	 
		/* generate code to exit and terminate loop */

		genret(); /* generate return from subroutine */

		/* satisfy forward references to continue-loop code */

		plantbyte(((cmpl-brptr)>>1),brptr+1); /* plant branch displ */
		if (brptr1)
			plantbyte(((cmpl-brptr1)>>1),brptr1+1); /* plant branch displ */
		if (brptr2)
			plantbyte(((cmpl-brptr2)>>1),brptr2+1); /* plant branch displ */

		/* generate code to update uloc and return for continuing loop */

		prevret = cmpl;	/* save for multiple expr or continued -calc- */
		addbyte(0xc2); /* cal16  r10,0,k */
		addbyte(0xa0);
		brptr = cmpl;
		addint2(0); /* reserve space for uloc value */
		i = PULOC*sizeof(struct exprt);
		gendf(0xcd,5,14,i); /* l   r5,k(r14) r5 = &uloc */
		gendsf(0x2,10,5,0); /* sths  r10,0(r5) */
		genret(); /* generate code to restore registers and return */
		plantint2((int)(cmpl),brptr); /* plant uloc value */

		/* set length of compiled code */

		codel = cmpl-(codeb+2);
		cmpbuf[codeb] = (codel >> 8) & 0xff;
		cmpbuf[codeb+1] = codel & 0xff;

		plantbyte(CLOOP,cmdp); /* replace command code */

		/* set up so next compile can append to this */

		appendok = TRUE;
		prevend = cmpl;
		return(TRUE);
	} /* loop if */

	/* compile "endloop" */

	else if (mode == ENDLOOP) {
		headptr = (cmpbuf[cmdp+1] & 0xff) << 8;
		headptr += cmpbuf[cmdp+2] & 0xff;
		cangen = TRUE; /* assume can compile */
		if (cmpbuf[headptr] != CLOOP) cangen = FALSE;
		else if (!appendok) cangen = FALSE;
		if (cangen) {
			cmpl = prevret; /* re-set end of previous calc */

			/* generate code to update uloc */

			gen32v(10,headptr); /* get r10 = uloc value */
			i = PULOC*sizeof(struct exprt);
			gendf(0xcd,5,14,i); /* l   r5,k(r14) r5 = &uloc */
			gendsf(0x2,10,5,0); /* sths  r10,0(r5) */

			/* generate call to loop interrupt-check routine */

			gensubr(PLOOP); 

			/* generate test+branch back to top of loop */

			genxf(0x6,3,2,0); /* cas r3,r2 */
			genxf(0x6,2,14,0); /* cas  r2,r14 */
			gendf(0xc9,6,1,tempal);	/* lm  r6,tempal(r1) */
			gendf(0xc1,1,1,(tempal+76)); /* ai  r1,k(r1) */
			genrf(0xe3,3,3);  /* o   r3,r3 */
			headptr += 6; /* advance to compiled code */
			if (headptr & 1) headptr++; 
			i = -((cmpl-headptr) >> 1);
			addbyte(0x8e); /* jeq  *-k */
			addbyte(0xa0+((i >> 16) & 0x0f));
			addbyte((i >> 8) & 0xff);
			addbyte(i & 0xff);
			addint2(0xe88f); /* br   r15 */	

			/* set length of compiled code */

			codel = cmpl-(codeb+2);
			cmpbuf[codeb] = (codel >> 8) & 0xff;
			cmpbuf[codeb+1] = codel & 0xff;
			return(TRUE);
		} /* cangen if */
	} /* endloop else if */

	/* compile "outloop" */

	else if ((mode == OUTLOOP) || (mode == OUTLOOPB)) {
		if (addr < 0) return(FALSE);
		if (mode == OUTLOOPB) {
			if (!appendok) return(FALSE);
			cmpl = prevret; /* append to previous -calc- */

			/* generate unconditional branch to top of loop */

			i = -((cmpl-addr) >> 1);
			addbyte(0x88); /* j  *-k */
			addbyte(0x80+((i >> 16) & 0x0f));
			addbyte((i >> 8) & 0xff);
			addbyte(i & 0xff);
			appendok = FALSE; /* cant append to this */
		} else {
			if (!cmp->multcode) return(FALSE);
			cmpl = prevret; /* append to condition expr */
			if (!appendok)
				plantbyte(CLOOP,cmdp); /* replace command code */

			/* generate test and branch */

			genrf(0xe3,2,2);  /* o   r2,r2 */
			i = -((cmpl-addr) >> 1);
			addbyte(0x8e); /* jlt  *-k */
			addbyte(0x90+((i >> 16) & 0x0f));
			addbyte((i >> 8) & 0xff);
			addbyte(i & 0xff);

			/* generate code to update uloc and exit */

			prevret = cmpl; /* save address of exit */
			addbyte(0xc2); /* cal16  r10,0,k */
			addbyte(0xa0);
			brptr = cmpl;
			addint2(0); /* reserve space for uloc value */
			i = PULOC*sizeof(struct exprt);
			gendf(0xcd,5,14,i); /* l   r5,k(r14) r5 = &uloc */
			gendsf(0x2,10,5,0); /* sths  r10,0(r5) */
			genret(); /* generate code to restore registers and return */
			plantint2((int)(cmpl),brptr); /* plant uloc value */
			appendok = TRUE; /* allow next to append */
		} /* OUTLOOPB else */

		/* set length of compiled code */

		codel = cmpl-(codeb+2);
		cmpbuf[codeb] = (codel >> 8) & 0xff;
		cmpbuf[codeb+1] = codel & 0xff;
		prevend = cmpl;
		return(TRUE);
	} /* outloop else if */

	return(FALSE);

} /* genloop */

/* ******************************************************************* */

/* code generation subroutines for IBM-RT */

/* ------------------------------------------------------------------------------ */

int findreg(t,rtyp)	/* find single register for specified operand */
int t;			/* index of token to find register for */
int rtyp;		/* type of register to find */

{	int i;		/* index */
	int loc;	/* relative location of specified token in code */

	i = regtl;		/* search backwards from last reg */
	loc = xtokd[t].loc;	/* relative location */

	do {
		--i;	/* back-up to next register */
		if ((regtyp[i] == rtyp)  && (regrsv[i] == 0) &&
		   (regtrack[i] <= loc)) return(i);
	} while (i > 0);
	return(tundef);	/* no register found */

} /* findreg */

/* ------------------------------------------------------------------------------ */

int findregp(t,rtyp)	/* find register pair for specified operand */
int t;			/* index of token to find register for */
int rtyp;		/* type of register to find */

{	int i;		/* index */
	int loc;	/* relative location of specified token in code */

	i = regtl & 0xfffe;	/* search backwards from last even reg */
	loc = xtokd[t].loc;	/* relative location */

	do {
		i = i-2;	/* back up to next register pair */
		if ((regtyp[i] == rtyp) && (regtyp[i+1] == rtyp) &&
		   (regrsv[i] == 0) && (regrsv[i+1] == 0) &&
		   (regtrack[i] <= loc) && (regtrack[i+1] <= loc))
			return(i);
	} while (i > 0);
	return(tundef);	/* no register pair found */

} /* findregp */

/* ------------------------------------------------------------------------------ */

asgreg(t,rtyp)		/* assign operand to working register */
int t;			/* index of token to assign */
int rtyp;		/* type of register to assign to */

/* if no register is available, operand will be assigned to stack frame */
/* storage - if stack frame storage exceeded, p-code will be produced */
/* instead of machine code */

{	int rn;	/* register number selected */
	int opc, opcf;	/* operand code, floating flag */

	if (xtokd[t].result != tundef)  rn = xtokd[t].result; /* already assigned */
	else {
	
		/* determine if floating (2-register) operation */

		opc = xtokd[t].code;
		opcf = ((xt[opc].trel == TFLOAT) ? TRUE: FALSE);

		/* attempt to locate free working register or pair */

		if (opcf) rn = findregp(t,rtyp);	/* locate register pair */
		else rn = findreg(t,rtyp);		/* find single register */

		/* reserve register or temporary */

		if (rn >= 0) {
			regrsv[rn] = t;	/* mark in use */
			regtrack[rn] = xtokd[t].loc;	/* mark location of use */
			reguse[rn] = TRUE;
			if (opcf) {
				regrsv[rn+1] = t;
				regtrack[rn+1] = xtokd[t].loc;
				reguse[rn+1] = TRUE;
			} /* floating if */
		} else {
			rn = tonstk;	/* flag quantity in temporary */
			xtokd[t].resulta = tempsl; /* set address of temporary */
			tempsl = tempsl+(opcf ? 8: 4); /* reserve space */
			if (tempsl >= tempal) pgen = TRUE; /* cant produce compiled code */
		} /* temporary else */

		xtokd[t].result = rn; /* assign operand to reg/temp */
	} /* not assigned else */
	return(rn);

} /* asgreg */

/* ------------------------------------------------------------------------------ */

fixreg(t,rn)	/* assign operand to argument (fixed) register */
int t;			/* index of operand to assign */
int rn;		/* register number to assign to */

{	int opc;		/* operand/operator code of token */
	int opcf;		/* integer/floating flag */

	opc = xtokd[t].code;
	opcf = (xt[opc].trel == TFLOAT);

	/* check if specified register available */

	if ((regtrack[rn] <= xtokd[t].loc) && (regrsv[rn] == 0) &&
	  ((!opcf) || ((regtrack[rn+1] <= xtokd[t].loc) &&
	  (regrsv[rn+1] == 0)))) {	
		regrsv[rn] = t;	/* reserve specified register (pair) */
		regtrack[rn] = xtokd[t].loc;
		reguse[rn] = TRUE;
		if (opcf) {
			regrsv[rn+1] = t;
			regtrack[rn+1] = xtokd[t].loc;
			reguse[rn+1] = TRUE;
		} /* float if */
		xtokd[t].result = rn;	/* assign token to register */
	} /* available if */

	/* move elsewhere if register not available */

	else rn = asgreg(t,regw);	/* desired register not available */
	return(rn);

} /* fixreg */

/* ------------------------------------------------------------------------------ */

relreg(rn)		/* release register */
int rn;		/* register to release */

{	int opc;	/* operand code */
	int t;		/* index of operand assigned to register */

	if (rn >= 0) {
		t = regrsv[rn];
		if (t > 0) {
			opc = xtokd[t].code;		/* release 2nd register if float */
			if (xt[opc].trel == TFLOAT) regrsv[rn+1] = 0;
		} /* register reserved if */
		regrsv[rn] = 0;
	} /* register assigned if */
	return(0);

} /* relreg */

/* ------------------------------------------------------------------------------ */

setlasta(lasta,lastk,lastt)		/* set store-ability information */
long	lasta;	/* address of operand */
int lastk;		/* global/local, integer/float type of operand */
int lastt;		/* TFLOAT, TINT, etc. type of operand */

{
	slasta = lasta;
	slastk = lastk;
	slastt = lastt;

} /* setlasta */

/* ------------------------------------------------------------------------------ */

gengp()			/* generate code to load pointer to globals */

{	int disp;	/* displacement from r14 to global var pointer */

	if (!globalr) {
		disp = PGLOBAL*sizeof(struct exprt);
		gendf(0xcd,13,14,disp);	/* l  r13,k(r14) */
		gendsf(0x07,13,13,0);	/* l  r13,0(r13) */
		globalr = TRUE;
		localr = FALSE;
	}
	return;

} /* gengp */

/* ------------------------------------------------------------------------------ */

genlp()			/* generate code to load pointer to locals */

{	int disp;	/* displacement from r14 to local var pointer */

	if (!localr) {
		disp = PLOCAL*sizeof(struct exprt);
		gendf(0xcd,13,14,disp);	/* l  r13,k(r14) */
		gendsf(0x07,13,13,0);	/* l  r13,0(r13) */
		localr = TRUE;
		globalr = FALSE;
	}
	return;

} /* genlp */

/* ------------------------------------------------------------------------------ */

gendf(op,r2,r3,i)	/* generate D format instruction */
int op;		/* instruction code */
int r2;		/* r2 field */
int r3;		/* r3 field */
int i;			/* immediate field */

{
	addbyte(op);			/* instruction code */
	addbyte((r2 << 4)+r3);	/* r2, r3 fields */
	addint2(i);			/* immediate field */
	return;

} /* gendf */

/* ------------------------------------------------------------------------------ */

gendsf(op,r2,r3,i)	/* generate D-short format instruction */
int op;		/* instruction code */
int r2;		/* r2 field */
int r3;		/* r3 field */
int i;			/* immediate field */

{
	addbyte((op << 4)+(i & 0xf));	/* instruction, immediate fields */
	addbyte((r2 << 4)+r3);	/* r2, r3 fields */
	return;

} /* gendsf */

/* ------------------------------------------------------------------------------ */

genxf(op,r1,r2,r3)	/* generate x format instruction */
int op;	/* instruction code */
int r1;	/* r1 field */
int r2;	/* r2 field */
int r3;	/* r3 field */

{
	addbyte((op << 4)+r1);	/* instruction, r1 */
	addbyte((r2 << 4)+r3);	/* r2,r3 fields */
	return;

} /* genxf */

/* ------------------------------------------------------------------------------ */

genrf(op,r1,r2)		/* generate r format instruction */
int op;	/* instruction code */
int r1;	/* r1 field */
int r2;	/* r2 (or immediate) field */

{
	addbyte(op);	/* instruction code */
	addbyte((r1 << 4)+r2);	/* r1, r2 (or immediate) fields */
	return;

} /* genrf */

/* ------------------------------------------------------------------------------ */

gen32v(r,value)	/* generate code to load 32-bit value */
int r; /* register to load to */
long value; /* 32-bit value */

{	int iv;

	iv = value;
	if (value == 0) genrf(0xe7,r,r);			/* x  r,r */
	else if ((value >> 16) == 0) gendf(0xc2,r,0,iv);	/* cal16  r,0,k */
	else {
		gendf(0xd8,r,0,((value >> 16) & 0xffff));	/* cau  r,k */
		if (value & 0xffff)
			gendf(0xc4,r,r,(value & 0xffff));	/* oil16  r,r,k */
	} /* else */
	return;

} /* gen32v */


/* ------------------------------------------------------------------------------ */

genfpa(fpaddr)		/* generate code to form floating accelerator address */
long fpaddr;	/* address to form */

{
	gendf(0xd8,11,0,((fpaddr >> 16) & 0xffff)+0xff00);	/* cau  r11,k */
	if (fpaddr & 0xffff)
		gendf(0xc4,11,11,(fpaddr & 0xffff));		/* oil  r11,k+r11 */
	return;

} /* genfpa */

/* ------------------------------------------------------------------------------ */

genmov(fr,tr,addr)	/* generate move to/from reg or temporary */
int fr;			/* from register */
int tr;		/* to register */
long addr;	/* to/from address */

{
	if ((fr >= 0) && (tr >= 0)) genxf(0x6,tr,fr,0);	/* cas  tr,fr */
	else if (fr<0) gendf(0xcd,tr,1,addr);		/* l  tr,k(r1) */
	else gendf(0xdd,fr,1,addr);			/* s fr,k(r1) */
	return;

} /* genmov */

/* ------------------------------------------------------------------------------ */

genmovf(iftyp,fr,tr,addr)	/* generate move to/from reg or temporary */
				/* moves register pair if floating operand */
int iftyp;	/* TINT, TFLOAT, etc. */
int fr;		/* from register */
int tr;	/* to register */
long addr;	/* to/from address */

{

	/* general register to general register */

	if ((fr<16) && (tr<16)) {
		genmov(fr,tr,addr);	/* move 1st register */
		if (iftyp == TFLOAT) {
			if (fr>0) 
				if (tr>0) genmov(fr+1,tr+1,addr+4);	/* move from 2nd register */
				else genmov(fr+1,tr,addr+4);
			else genmov(fr,tr+1,addr+4);		/* move to 2nd register */
		} /* floating if */
	} /* general register if */

	/* floating register pair to temporary */

	else if ((fr>=16) && (tr<0)) {
		genfpa(0x2f000+((fr-16) << 6));	/* rdfr */
		gendf(0xcd,12,11,0x40);		/* l  12,0x40(r11) */
		gendsf(0x07,11,11,0);		/* ls  11,0(r11) */
		genmov(11,tr,addr);		/* copy r11 to temp */
		genmov(12,tr,addr+4);	/* copy r12 to temp */
	} /* floating to temporary else if */

	/* temporary to floating register pair */

	else if ((fr<0) && (tr>=16)) {
		genmov(fr,2,addr);			/* copy temp to r2 */
		genmov(fr,3,addr+4);		/* copy temp to r3 */
		genfpa(0x25000+((tr-16) << 2));	/* wtfr */
		gendsf(0x03,2,11,0);		/* sts  2,0(r11) */
		gendsf(0x03,3,11,1);		/* sts  3,4(r11) */
	} /* temporary to floating else if */
	

	/* floating register pair to general register pair */

	else if ((fr>=16) && (tr<16)) {
		genfpa(0x2f000+((fr-16) << 6));	/* rdfr */
		gendsf(0x07,tr,11,0);		/* ls  tr,0(r11) */
		gendf(0xcd,tr+1,11,0x40);	/* l  tr+1,0x40(r11) */
	} /* floating to general else if */

	/* general register pair to floating register pair */

	else if ((fr<16) && (tr>=16)) {
		genfpa(0x25000+((tr-16) << 2));	/* wtfr */
		gendsf(0x03,fr,11,0);		/* sts  fr,0(r11) */
		gendsf(0x03,fr+1,11,1);		/* sts  fr+1,4(r11) */
	} /* general to floating else if */
	
	/* floating register pair to floating register pair */

	else if ((fr>=16) && (tr>=16)) {
		genfpa(0x11000+((fr-16)<<6)+((tr-16)<<2));	/* copl */
		gendsf(0x03,11,11,0);		/* sts  r11,0(r11) */
	} /* floating to floating else if */

} /* genmovf */

/* ------------------------------------------------------------------------------ */

gensubr(opc)		/* generate call to subroutine */
int opc;		/* operator/operand code */

{	int disp;	/* displacement in xt[] table */

	disp = opc*sizeof(struct exprt);
if (disp > 0x3fff) TUTORdump("expression table too small");
	gendf(0xcd,10,14,disp);	/* l  r10,k(r14) r10  = adr of data segment */
	genxf(0x06,0,10,0);	/* cas r0,0(r10) */
	gendsf(0x07,10,10,0);	/* ls r10,0(r10) r10 = adr of routine */
	genrf(0xec,15,10);	/* balr r15,r10 */
	
} /* gensubr */

/* ------------------------------------------------------------------------------ */

genbegin()	/* generate initial setup code */

{
	/* generate stm instruction to save registers */

	gendf(0xd9,6,1,-76);		/* stm  r6,-76(r1) */

	/* generate ai instruction to allocate frame */
	
	gendf(0xc1,1,1,(-(tempal+76)));	/* ai  r1,-k(r1) */

	/* set up r14 as pointer to xt[] (stack, lvarp, routines, etc.) */

	genmov(2,14,0);	/* move r2 to r14 */

} /* genbegin */

/* ------------------------------------------------------------------------------ */

genret()	/* generate code to restore registers and return */

{

	/* generate load-multiple instruction to restore registers */

	gendf(0xc9,6,1,tempal);	/* lm  r6,tempal(r1) */

	/* generate return from subroutine */

	addint2(0xe98f);	/* brx   r15 */
	gendf(0xc1,1,1,(tempal+76));	/* ai  r1,k(r1) */

} /* genret */


/* ------------------------------------------------------------------------------ */

icgen()		/* initializations for code generator */

{	int i;		/* index in expression analyzer table */
	int fpacc;	/* TRUE if floating point accelerator present */
	double (*dfp)();	/* pointer to floating routine */
	long (*lfp)();		/* pointer to integer routine */

	for (i=0; i<regtl; i++){ regtyp[i] = regx; }

	fpacc = fpastat();	 /* check floating accelerator present */

	regtyp[0] = rega;		/* r0 pointer to data area */
	regtyp[1] = rega;		/* r1 pointer to stack frame */
	regtyp[2] = rega;		/* r2 subroutine */
	regtyp[3] = rega;		/* r3 subroutine */
	regtyp[4] = rega;		/* r4 subroutine */
	regtyp[5] = rega;		/* r5 subroutine */
	regtyp[6] = regw;		/* r6 available */
	regtyp[7] = regw;		/* r7 available */
	regtyp[8] = regw;		/* r8 available */
	regtyp[9] = regw;		/* r9 available */
	regtyp[10] = rega;		/* r10 internal scratch */
	regtyp[11] = rega;		/* r11 internal scratch */
	regtyp[12] = rega;		/* r12 internal scratch */
	regtyp[13] = rega;		/* r13 pointer to global/local variables */
	regtyp[14] = rega;		/* r14 pointer to pointers */
	regtyp[15] = rega;		/* r15 return address */
	regtyp[16] = rega;		/* fp0 floating point scratch */
	regtyp[17] = rega;		/* fp1 floating point scratch */
	regtyp[18] = rega;		/* fp2 floating point scratch */
	regtyp[19] = rega;		/* fp3 floating point scratch */
	regtyp[20] = regf;		/* fp4 floating point */
	regtyp[21] = regf;		/* fp5 floating point */
	regtyp[22] = regf;		/* fp6 floating point */
	regtyp[23] = regf;		/* fp7 floating point */
	regtyp[24] = regf;		/* fp8 floating point */
	regtyp[25] = regf;		/* fp9 floating point */
	regtyp[26] = regf;		/* fpa floating point */
	regtyp[27] = regf;		/* fpb floating point */
	regtyp[28] = regf;		/* fpc floating point */
	regtyp[29] = regf;		/* fpd floating point */

	xt[ENDI].cgen = TRUE;
	xt[ENDIM].cgen = TRUE;
	xt[ENDF].cgen = TRUE;
	xt[ENDFM].cgen = TRUE;
	xt[ILITERAL].cgen = TRUE;
	xt[FLITERAL].cgen = TRUE;
	xt[GLOBALVAL].cgen = TRUE;
	xt[IGLOBALVAL].cgen = TRUE;
	xt[BGLOBALVAL].cgen = TRUE;
	xt[LOCALVAL].cgen = TRUE;
	xt[ILOCALVAL].cgen = TRUE;
	xt[BLOCALVAL].cgen = TRUE;
	xt[GLOBALADDR].cgen = TRUE;
	xt[IGLOBALADDR].cgen = TRUE;
	xt[BGLOBALADDR].cgen = TRUE;
	xt[LOCALADDR].cgen = TRUE;
	xt[ILOCALADDR].cgen = TRUE;
	xt[BLOCALADDR].cgen = TRUE;
	xt[GARRAYVAL].cgen = TRUE;
	xt[GARRAYADDR].cgen = TRUE; 
 	xt[IGARRAYVAL].cgen = TRUE;
	xt[IGARRAYADDR].cgen = TRUE; 
 	xt[BGARRAYVAL].cgen = TRUE;
	xt[BGARRAYADDR].cgen = TRUE; 
	xt[LARRAYVAL].cgen = TRUE;
	xt[LARRAYADDR].cgen = TRUE; 
 	xt[ILARRAYVAL].cgen = TRUE;
	xt[ILARRAYADDR].cgen = TRUE; 
 	xt[BLARRAYVAL].cgen = TRUE;
	xt[BLARRAYADDR].cgen = TRUE; 
	xt[IPLUS].cgen = TRUE;
	xt[IMINUS].cgen = TRUE;
	xt[IUMINUS].cgen = TRUE;
	xt[IINC].cgen = TRUE;
	xt[IDEC].cgen = TRUE;
	xt[ITIMES].cgen = TRUE;
	xt[IDIVR].cgen = TRUE;
	xt[IDIVT].cgen = TRUE;
	xt[LSHIFT].cgen = TRUE;
	xt[RSHIFT].cgen = TRUE;
	xt[LMASK].cgen = TRUE;
	xt[LUNION].cgen = TRUE;
	xt[LDIFF].cgen = TRUE;
	xt[COMP].cgen = TRUE;
	xt[BITCNT].cgen = TRUE;
	xt[ASSIGN].cgen = TRUE;
	xt[IASSIGN].cgen = TRUE;
	xt[BASSIGN].cgen = TRUE;
	xt[EQ].cgen = TRUE;
	xt[NE].cgen = TRUE;
	xt[GT].cgen = TRUE;
	xt[LT].cgen = TRUE;
	xt[GE].cgen = TRUE;
	xt[LE].cgen = TRUE;  
	xt[IEQ].cgen = TRUE;
	xt[INE].cgen = TRUE;
	xt[IGT].cgen = TRUE;
	xt[ILT].cgen = TRUE;
	xt[IGE].cgen = TRUE;
	xt[ILE].cgen = TRUE;  
	xt[ITOF].cgen = TRUE;
	xt[FTOI].cgen = TRUE;
	xt[PLUS].cgen = TRUE;
	xt[MINUS].cgen = TRUE;
	xt[UMINUS].cgen = TRUE;
	xt[TIMES].cgen = TRUE;
	xt[DIVIDE].cgen = TRUE;
	xt[INT].cgen = TRUE;
	xt[FRAC].cgen = TRUE;
	xt[ROUND].cgen = TRUE;
	xt[NULLF].cgen = TRUE;
	xt[SIGN].cgen = TRUE;
	xt[FFUNCT].cgen = TRUE;
	xt[EXPONENT].cgen = TRUE;
	xt[EXPONIC].cgen = TRUE;
	xt[SYSVAR].cgen = TRUE;  

	xt[ENDI].rr = TRUE;
	xt[ENDIM].rr = TRUE;
	xt[ENDF].rr = TRUE;
	xt[ENDFM].rr = TRUE;
	xt[ILITERAL].rr = TRUE;			
	xt[IGLOBALVAL].rr = TRUE;		
	xt[BGLOBALVAL].rr = TRUE;		
	xt[ILOCALVAL].rr = TRUE;		
	xt[BLOCALVAL].rr = TRUE;		
	xt[IGLOBALADDR].rr = TRUE;	
	xt[BGLOBALADDR].rr = TRUE;	
	xt[ILOCALADDR].rr = TRUE;		
	xt[BLOCALADDR].rr = TRUE;		
	xt[IPLUS].rr = TRUE;
	xt[IMINUS].rr = TRUE;;			
	xt[IUMINUS].rr = TRUE;		
	xt[IINC].rr = TRUE;
	xt[IDEC].rr = TRUE;
	xt[ASSIGN].rr = TRUE;
	xt[IASSIGN].rr = TRUE;
	xt[BASSIGN].rr = TRUE;

	if (fpacc) {
		xt[ITOF].rr = TRUE;
		xt[PLUS].rr = TRUE;
		xt[MINUS].rr = TRUE;
		xt[UMINUS].rr = TRUE;
		xt[TIMES].rr = TRUE;
		xt[DIVIDE].rr = TRUE;
		lfp = lcftoi;
		xt[FTOI].xaddr = (long)lfp;
		xt[FTOI].subr = TRUE;
	} else {
		dfp = lcitof;
		xt[ITOF].xaddr = (long)dfp;
		xt[ITOF].subr = TRUE;
		dfp = lcfadd;
		xt[PLUS].xaddr = (long)dfp;
		xt[PLUS].subr = TRUE;	
		dfp = lcfsub;
		xt[MINUS].xaddr = (long)dfp;
		xt[MINUS].subr = TRUE;
		dfp = lcfumin;
		xt[UMINUS].xaddr = (long)dfp;
		xt[UMINUS].subr = TRUE;
		dfp = lcfmult;
		xt[TIMES].xaddr = (long)dfp;
		xt[TIMES].subr = TRUE;
		dfp = lcfdiv;
		xt[DIVIDE].xaddr = (long)dfp;
		xt[DIVIDE].subr = TRUE;
		lfp = lcftoi;
		xt[FTOI].xaddr = (long)lfp;
		xt[FTOI].subr = TRUE;
	} /* no accelerator else */
	
	lfp = lciresult;	xt[ENDIM].xaddr = (long)lfp;
	dfp = lcfresult;	xt[ENDFM].xaddr = (long)dfp;	
	lfp = lcimult;	xt[ITIMES].xaddr = (long)lfp;	xt[ITIMES].subr = TRUE;
	lfp = lcidivr;	xt[IDIVR].xaddr = (long)lfp;	xt[IDIVR].subr = TRUE;
	lfp = lcidivt;	xt[IDIVT].xaddr = (long)lfp;	xt[IDIVT].subr = TRUE;
	lfp = lclshf;	xt[LSHIFT].xaddr = (long)lfp;	xt[LSHIFT].subr = TRUE;
	lfp = lcrshf;	xt[RSHIFT].xaddr = (long)lfp;	xt[RSHIFT].subr = TRUE;
	lfp = lcmask;	xt[LMASK].xaddr = (long)lfp;	xt[LMASK].subr = TRUE;
	lfp = lcunion;	xt[LUNION].xaddr = (long)lfp;	xt[LUNION].subr = TRUE;
	lfp = lcdiff;	xt[LDIFF].xaddr = (long)lfp;	xt[LDIFF].subr = TRUE;
	lfp = lccomp;	xt[COMP].xaddr = (long)lfp;	xt[COMP].subr = TRUE;
	lfp = lcbitcnt;	xt[BITCNT].xaddr = (long)lfp;	xt[BITCNT].subr = TRUE;
	lfp = lcint;	xt[INT].xaddr = (long)lfp;	xt[INT].subr = TRUE;
	lfp = lcftoi;	xt[ROUND].xaddr = (long)lfp;	xt[ROUND].subr = TRUE;
	lfp = lcsign;	xt[SIGN].xaddr = (long)lfp;	xt[SIGN].subr = TRUE;
	lfp = lceq;	xt[IEQ].xaddr = (long)lfp;	xt[IEQ].subr = TRUE;
	lfp = lcne;	xt[INE].xaddr = (long)lfp;	xt[INE].subr = TRUE;
	lfp = lcgt;	xt[IGT].xaddr = (long)lfp;	xt[IGT].subr = TRUE;
	lfp = lclt;	xt[ILT].xaddr = (long)lfp;	xt[ILT].subr = TRUE;
	lfp = lcge;	xt[IGE].xaddr = (long)lfp;	xt[IGE].subr = TRUE;
	lfp = lcle;	xt[ILE].xaddr = (long)lfp;	xt[ILE].subr = TRUE;
	lfp = lcfeq;	xt[EQ].xaddr = (long)lfp;	xt[EQ].subr = TRUE;
	lfp = lcfne;	xt[NE].xaddr = (long)lfp;	xt[NE].subr = TRUE;
	lfp = lcfgt;	xt[GT].xaddr = (long)lfp;	xt[GT].subr = TRUE;
	lfp = lcflt;	xt[LT].xaddr = (long)lfp;	xt[LT].subr = TRUE;
	lfp = lcfge;	xt[GE].xaddr = (long)lfp;	xt[GE].subr = TRUE;
	lfp = lcfle;	xt[LE].xaddr = (long)lfp;	xt[LE].subr = TRUE;
	dfp = lcfrac;	xt[FRAC].xaddr = (long)dfp;	xt[FRAC].subr = TRUE;
	dfp = lcfexpon;	xt[EXPONENT].xaddr = (long)dfp;	xt[EXPONENT].subr = TRUE;
	dfp = lcfexpic;	xt[EXPONIC].xaddr = (long)dfp;	xt[EXPONIC].subr = TRUE;
	dfp = lcfsysv;	xt[SYSVAR].xaddr = (long)dfp;	xt[SYSVAR].subr = TRUE;

	dfp = lcsin;	xt[SIN+256].xaddr = (long)dfp;	xt[SIN+256].subr = TRUE;
	dfp = lccos;	xt[COS+256].xaddr = (long)dfp;	xt[COS+256].subr = TRUE;
	dfp = lctan;	xt[TAN+256].xaddr = (long)dfp;	xt[TAN+256].subr = TRUE;
	dfp = lccsc;	xt[CSC+256].xaddr = (long)dfp;	xt[CSC+256].subr = TRUE;
	dfp = lcsec;	xt[SEC+256].xaddr = (long)dfp;	xt[SEC+256].subr = TRUE;
	dfp = lccot;	xt[COT+256].xaddr = (long)dfp;	xt[COT+256].subr = TRUE;
	dfp = lcarcsin; xt[ARCSIN+256].xaddr = (long)dfp;	xt[ARCSIN+256].subr = TRUE;
	dfp = lcarccos;	xt[ARCCOS+256].xaddr = (long)dfp;	xt[ARCCOS+256].subr = TRUE;
	dfp = lcarccsc;	xt[ARCCSC+256].xaddr = (long)dfp;	xt[ARCCSC+256].subr = TRUE;
	dfp = lcarcsec;	xt[ARCSEC+256].xaddr = (long)dfp;	xt[ARCSEC+256].subr = TRUE;
	dfp = lcarccot; xt[ARCCOT+256].xaddr = (long)dfp;	xt[ARCCOT+256].subr = TRUE;
	dfp = lcsqrt; 	xt[SQRT+256].xaddr = (long)dfp;	xt[SQRT+256].subr = TRUE;
	dfp = lcabs; 	xt[ABS+256].xaddr = (long)dfp;	xt[ABS+256].subr = TRUE;
	dfp = lcexp; 	xt[EXP+256].xaddr = (long)dfp;	xt[EXP+256].subr = TRUE;
	dfp = lclog; 	xt[LOG+256].xaddr = (long)dfp;	xt[LOG+256].subr = TRUE;
	dfp = lcalog; 	xt[ALOG+256].xaddr = (long)dfp;	xt[ALOG+256].subr = TRUE;
	dfp = lcln; 	xt[LN+256].xaddr = (long)dfp;	xt[LN+256].subr = TRUE;
	dfp = lcsinh; 	xt[SINH+256].xaddr = (long)dfp;	xt[SINH+256].subr = TRUE;
	dfp = lccosh; 	xt[COSH+256].xaddr = (long)dfp;	xt[COSH+256].subr = TRUE;
	dfp = lctanh; 	xt[TANH+256].xaddr = (long)dfp;	xt[TANH+256].subr = TRUE;
	dfp = lcgamma;	xt[GAMMA+256].xaddr = (long)dfp;	xt[GAMMA+256].subr = TRUE;

	InitExpressionTable(xt);
	lfp = lcerr;
	xt[PCALCE].xaddr = (long)lfp;
	xt[PCODEP].xaddr = (long)(&pcodep);
	lfp = lcloop;	xt[PLOOP].xaddr = (long)lfp;
	

} /* icgen */

/* ******************************************************************* */

#endif

#ifdef ibm032

#include <machine/float.h>

/* ------------------------------------------------------------------------------ */

int fpastat()	/* returns TRUE if FPA hardware present */

{	int fpacc;
	struct floatstate fpstat;
	int fpsize;

	fpsize = sizeof(struct floatstate);
	fpacc = getfloatstate(&fpstat,&fpsize);
	fpacc = float_has_fpa(fpstat.process_state); 
	if (fpacc) fpacc = 1;
	setfpaf(fpacc);
	return(fpacc);

} /* fpastat */

/* ------------------------------------------------------------------------------ */

#endif
