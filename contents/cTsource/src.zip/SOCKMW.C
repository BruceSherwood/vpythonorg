
/*
A component of the cT (TM) programming environment.
(c) Copyright 1994 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* ******************************************************************* */

#define STRICT
#include <windows.h>
#include <string.h>
#include <ddeml.h>

#include "ctmsw.h"
#include "baseenv.h"
#include "compute.h"
#include "tfiledef.h"
#include "tglobals.h"
#include "kglobals.h"
#include "eglobals.h"

/* ******************************************************************* */

#ifdef ctproto
extern int buffer_socket(struct sockInf FAR *socketP,unsigned char FAR *dataP);
extern int strlenf(char FAR *cc);
extern int  TUTORset_hsize(Memh mm,long newsize,int abort);
extern int cTRegisterWindow(HWND hWnd,int cTtype,int cTindex,int cmdN,Memh infH);
extern int TUTORzero(char FAR *ptr,long len);
extern int file_slot(void);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORreset_sockets(void);
int  TUTORserver(char  *addr,int  aType,char  *info);
int  TUTORsocket_server(int  fInd);
int  TUTORhosts(char  *addr,int  nn,char  *info,int  infoSize,int  *nNames);
int  TUTORsocket_client(char  *addr,int  aType,int  nn);
long  TUTORwrite_socket(int  ss,char  FAR *buf,long  len);
long  TUTORread_socket(int  ss,char  FAR *buf,long  maxLen);
int  TUTORclose_socket(struct  tutorfile FAR *tfp);
int  TUTORungetc_socket(struct	tutorfile FAR *tfp,int	cc);
static int tutorsock_setup(int ss);
#endif /* ctproto */

int tutorsock_setup();
long TUTORread_socket();
long TUTORwrite_socket();
extern char FAR *GetPtr();
extern char FAR *TUTORalloc();

/* ******************************************************************* */

extern HANDLE hcTInst ; /* current instance of cT */

/* ******************************************************************* */

TUTORinit_sockets()

{

    return(0);
}

/* ******************************************************************* */

TUTORreset_sockets()
    {
    return(0);
    }

/* ******************************************************************* */

TUTORserver(addr,aType,info)
char *addr; /* the address we are advertising (application) */
int aType;  /* TRUE if logical, FALSE if absolute */
char *info;  /* additional information (topic) (may by NULL) */
/* returns tutor file slot # or 0 for failure */

{

    tfilerr = FILEMISSING;

    return(0); /* return index in file table */

} /* TUTORserver */

/* ******************************************************************* */

TUTORsocket_server(fInd)
int fInd; /* index in tutor file structure */
/* returns success flag */

{

    tfilerr = FILEMISSING;
    return(0);

} /* TUTORsocket_server */

/* ******************************************************************* */

TUTORsocket_client(addr,aType,nn)
char *addr;  /* address we are connecting to */
int aType; /* TRUE if logical address type */
int nn;  /* which instance (1 based) we want to connect to */
/* returns tutor file slot # or 0 for failure */

{

    tfilerr = FILEMISSING;
    return(0); /* no sockets */

} /* TUTORsocket_client */

/* ******************************************************************* */

int TUTORwait_socket() { return(FALSE); }

/* ******************************************************************* */

TUTORclose_socket(tfp)
struct tutorfile FAR *tfp; /* pointer to file table entry */

{

    return(0);

} /* TUTORclose_socket */

/* ******************************************************************* */

TUTORhosts(addr,nn,info,infoSize,nNames)
char *addr;  /* address to look up (this must be a logical type) */
int nn;  /* we want nnth instance (1 based) */
char *info;  /* to be filled with extra info */
int infoSize; /* maximum amount of info */
int *nNames; /* to be filled with # of names found */
/* returns success flag (FALSE if no names found at all) */
    {
    if (nNames)
        *nNames = 0;
    return(FALSE);
    }

/* ******************************************************************* */

long TUTORwrite_socket(fI,buf,len)
int fI;
char FAR *buf;
long len;
/* returns # of chars actually written */

{
    return(0L);

} /* TUTORwrite socket */

/* ******************************************************************* */

long TUTORread_socket(fI,buf,maxLen)
int fI;
char FAR *buf;
long maxLen;
/* returns # of chars actually read */

{

    tfilerr = FILENOTOPEN;
    return(0L); /* no sockets */

} /* TUTORread_socket */

/* ******************************************************************* */


int TUTORungetc_socket(tfp,cc)
struct tutorfile FAR *tfp; /* pointer to file table entry */
int cc;

{
    return(0);
}

/* ******************************************************************* */

static int tutorsock_setup(ss)	/* set up a "file" for a tutor socket */
int ss; /* index in sockets table */
/* returns tutor file index */

{

    tfilerr = FILEMISSING;
    return(0);

 } /* tutorsock_setup */

/* ******************************************************************* */

void executeit(str) /* execute program */
char *str;

{   unsigned int retf;

    retf = WinExec((char FAR *)str,SW_SHOWMINNOACTIVE);
    if (retf >= 32) exS.zreturn = -1;
    else exS.zreturn = retf;

} /* executeit */

/* ******************************************************************* */
