
/* A component of the cT (TM) programming environment.  */
/* (c) Copyright 1989 Carnegie Mellon University. */
/* cT is a trademark of Carnegie Mellon University. */
/* All rights reserved. */
/* May not be copied without the written consent */
/* of Carnegie Mellon University.  */


/* C routines specific to IBM PC version */

#include "baseenv.h"
#include <bios.h>
#include <dos.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#ifndef TURBOC
#include <direct.h>
#endif
#include <sys\timeb.h>
#include "time.h"

#include "baseenv.h"
#include "tglobals.h"

#ifdef ctproto
int  breakpt(void);
int  breakpt1(void);
int  breakpt2(void);
int  cmdbreakpt(void);
long  TUTORinq_msec_clock(void);
int  TUTORcvt_file_name(char  *ssx,struct  _fref FAR *fRef,struct  _fref FAR *baseRef);
int  FileExists(struct  _fref FAR *fRef);
int  fork(void);
double  gamma(double  a);
long  TUTOR_random(void);
int  TUTORovl_log(int  overlay,int  callret);
int  TUTORlog(char  *str);
int  setfptr(int  FAR *aptr,unsigned int  seg,unsigned int  adr);
char  *strf2n(char  FAR *strp);
char  *strnf2n(char  FAR *strp,int  nn);
int  strlenf(char  FAR *aa);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
char  FAR *strcatf(char  FAR *aa,char  FAR *bb);
int  strcmpf(char  FAR *aa,char  FAR *bb);
int  strcmpnw(char  FAR *aa,char  FAR *bb);
char  FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
char  FAR *strncatf(char  FAR *aa,char  FAR *bb,int  nn);
int  strncmpf(char  FAR *aa,char  FAR *bb,int  nn);
int  matherr(struct  exception *x);
extern char *strcat(char *aa, char *bb);
extern char *strcpy(char *aa, char *bb);
extern int rand(void);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
int  execerr(char  *msgstr);
extern int strlen(char *str);
int  TUTORdump(char  *s);
/* extern ftime(); */
#ifdef IBMPROTO
int _CDECL fclose(FILE *);
int _CDECL fprintf(FILE *, const char *, ...);
FILE * _CDECL fopen(const char *, const char *);
#endif /* IBMPROTO */
#endif /* ctproto */

/* ******************************************************************* */

breakpt()
{
    return(0);
}

breakpt1()
{
    return(0);
}

breakpt2()
{
    return(0);
}

cmdbreakpt()

{
    return(0);
}

/* ******************************************************************* */

static long timebase = 0; /* initial seconds, gmt since 1/1/70 */
long lastmsec = 0;

long TUTORinq_msec_clock()  /* return millisecond clock */

{       struct timeb timev;
    long secs;

    ftime(&timev);  /* get time structure */
    if (timebase == 0) {
        timebase = timev.time;
    } /* timebase if */
    secs = timev.time-timebase;
    lastmsec = secs*1000L+(long)timev.millitm;
    return(lastmsec);

} /* TUTORinq_msec_clock */

/* ******************************************************************* */

#ifdef Nosuzhz

TUTORset_directory(dirR)
FileRef FAR *dirR;
/* returns -1 on error, 0 if no problem */

{    char temp[FILEL];
     char *cp, *pp;
     int len;
     union REGS inr;         /* input registers for int86x */
     union REGS outr;        /* output registers for int86x */
     int driveN, errr;
     char FAR *dir;

     dir = dirR->name;
     if (dir[0] == '\0')
    return(0);

    /* look for drive specifier */

    driveN = -1;
    if (dir[1] == ':') { /* need to change default drive */
    if (dir[0] <= 'Z')
        driveN = dir[0] - 'A';
    else
        driveN = dir[0] - 'a';
    if (driveN < 0 || driveN > 26)
        return(-1); /* bad drive specifier */

    inr.h.ah = 0x0e; /* 0e = change default drive */
    inr.h.dl = driveN; /* drive number */
    int86(0x21,&inr,&outr);
    if (driveN >= outr.h.al) {
        return(-1); /* couldn't set drive, for some reason */
    }
    strcpyf((char FAR *) temp,dir+2); /* get just directory name into temp */

    /* get rid of trailing \ */

    len = strlen(temp);
    if (len <= 0) { /* path must have been "a:", make reference to top */
        temp[0] = '\\';
        temp[1] = '\0';
    }
    } else
    strcpyf((char FAR *) temp,dir);

    if (temp[len-1] == '\\' || temp[len-1] == '/')
    temp[len-1] = '\0';

    /* change the working directory */

    errr = chdir(temp);

    if (driveN >= 0) {
    AUTHDIR.name[0] = 'a'+driveN;
    AUTHDIR.name[1] = ':';
    AUTHDIR.name[2] = '\0';
    } else
    AUTHDIR.name[0] = '\0';
    getcwd(temp,(FILEL-4));
    cp = temp;
    if ((strlen(cp) > 1) && (*(cp+1) == ':'))
    cp += 2; /* skip over drive specifier */

    pp = cp;
    while (*pp) { /* convert to lower case */
    if ((*pp >= 'A') && (*pp <= 'Z'))
        *pp = (*pp-'A')+'a';
    pp++;
    }
    strcat(AUTHDIR.name,cp); /* drive+path to authdir */

    return(errr);

}  /* TUTORset_directory */

#endif

/* ******************************************************************* */

TUTORcvt_file_name(ssx,fRef, baseRef) /* convert ss to full path name */
char *ssx; /* a file name, possibly partial */
FileRef FAR *fRef; /* complete file reference, to be created */
FileRef FAR *baseRef;       /* directory to work from */
/* returns TRUE if ssx is full path, FALSE otherwise */
    
{   char *ss, buffer[CTPATHLEN];
    int mlen;
    char FAR *pp;

    fRef->path[0] = '\0';
    fRef->nameInd = 0;
    if (baseRef)
    fRef->drive = baseRef->drive;
    else fRef->drive = ctDir.drive;

    /* we don't want leading spaces */
    while (*ssx == ' ')
        ssx++;

    /* strip trailing spaces */
    mlen = strlen(ssx);
    /* strip trailing spaces */
    while (mlen > 0 && ssx[mlen-1] == ' ')
        mlen--;

    if (mlen == 0)
        return(FALSE); /* no file name */

    strcpy(buffer,ssx); /* make copy of path (so we don't modify the original) */
    buffer[mlen] = '\0';
    ss = buffer;

    while (*ss) {
        if (*ss == '/') {
            *ss = '\\'; /* convert slash to backslash */
        } else if ((*ss >= 'A') && (*ss <= 'Z')) /* convert to lower case */
            *ss = (*ss -'A')+'a';
        ss++;
    } /* while */

    if (buffer[1] == ':') { /* already a full path */
        if (buffer[0] < 'a' || buffer[0] > 'z')
            return FALSE;
        fRef->drive = buffer[0] - 'a' + 1;
        strcpyf(fRef->path,(char FAR *) buffer + 2);
        pp = fRef->path+strlenf(fRef->path)-1;
        while (*pp != '\\')
            pp--; /* scan backwards for beginning of file name */
        fRef->nameInd = (pp-(char FAR *)fRef->path)+1;
        return(TRUE);
    }

    if (!baseRef)
       return(FALSE); /* not full path */
    
    ss = buffer;
    if (ss[0] == '~'){  
        /* user name reference */
        while (*ss && *ss != '\\')
            ss++; /* we want to scan past the user name token */
    } else if (ss[0] == '.' && ss[1] == '\\') {
        /* reference to current working directory (baseRef) */
        ss += 2; /* skip the ./ */
        strncpyf(fRef->path,baseRef->path,baseRef->nameInd);
        fRef->path[baseRef->nameInd] = '\0';
    } else if (ss[0] == '\\') {
        /* full path (without drive) */
        fRef->path[0] = '\0';
    } else {
        /* not a full path, must be in working directory */
        strncpyf(fRef->path,baseRef->path,baseRef->nameInd);
        fRef->path[baseRef->nameInd] = '\0';
    }

    if (strlenf(fRef->path) + strlen(buffer) > FILEL)
        execerr("File path too long");

    strcatf(fRef->path,(char FAR *) ss);
    pp = fRef->path + strlenf(fRef->path) - 1;
    while (*pp != '\\')
        pp--; /* scan for beginning of file name */
    fRef->nameInd = (pp - (char FAR *)fRef->path) + 1;

    return(TRUE); /* we always concoct a full path name */

} /* TUTORcvt_file_name */

/* ******************************************************************* */

FileExists(fRef) /* return TRUE if file "s" exists */
FileRef FAR *fRef;

{   long length;

    if (fRef->path[0] == 0)
    return(FALSE);
    TUTORinq_file_info(fRef,NEARNULL,&length,NEARNULL,NEARNULL,NEARNULL);
    if (length >= 0)
    return(TRUE);
    else return(FALSE);

} /* FileExists */

/* ******************************************************************* */

int fork() /* UNIX fork */

{
    return(0); /* 0 = process did not fork */

} /* fork */

/* ******************************************************************* */

double gamma(a)
double a;

{
    return(a);

} /* gamma */

/* ******************************************************************* */

long TUTOR_random()

{
    return(rand());

} /* TUTOR_random */

/* ******************************************************************* */

static int rwf = 0; /* rewind flag */

TUTORovl_log(overlay,callret)   /* log overlay calls */
int overlay; /* index of overlay being loaded */
int callret; /* 1 = call to overlay, 0 = return from overlay */

{   char logmsg[80];

    if (callret) strcpy(logmsg,"call to overlay (");
    else strcpy(logmsg,"return to overlay(");
    if (overlay == 0) strcat(logmsg,"main");
    else if (overlay == 1) strcat(logmsg,"edit+compile");
    else if (overlay == 2) strcat(logmsg,"execute");
    else if (overlay == 3) strcat(logmsg,"init");
    else strcat(logmsg,"other");
    strcat(logmsg,")\n");
    TUTORlog(logmsg);

} /* TUTORovl_log */

/* ******************************************************************* */

TUTORlog(str)   /* write to log file */
char *str;      /* pointer to string to write */

{   FILE *logfp;

    if (rwf == 0) {
    logfp = fopen("ct.log","w");
        rwf = 1;
    } else {
    logfp = fopen("ct.log","a");
    } /* else */

    if (logfp == NULL) return(0);
    fprintf(logfp,"%s",str);
    if (str[strlen(str)-1] != '\n')
        fprintf(logfp,"\n");
    fclose(logfp);

} /* TUTORlog */

/* ******************************************************************* */

setfptr(aptr,seg,adr)   /* set far pointer to segment:address  */
int far *aptr;      /* address of pointer variable */
unsigned int seg;   /* segment */
unsigned int adr;   /* address within segment */

{
    *aptr = adr;
    *(aptr+1) = seg;

} /* setfptr */

/* ******************************************************************* */

static char localstr[MAXNEARLEN+8]; /* local copy of string */

char *strf2n(strp)    /* convert far string to near */
char FAR *strp;

{   char *nstrp; /* far pointer to near string */

    localstr[MAXNEARLEN] = '*';
    nstrp = localstr;
    while (*nstrp++ = *strp++)
    if (localstr[MAXNEARLEN] != '*') TUTORdump("strf2n");
    return(localstr);

} /* strf2n */

/* ******************************************************************* */

char *strnf2n(strp,nn)  /* convert far string to near */
char FAR *strp;
int nn;

{   char *nstr;

    nstr = localstr;
    localstr[MAXNEARLEN] = '*';
    while ((nn > 0) && (*nstr++ = *strp++)) {
        nn--;
        if (localstr[MAXNEARLEN] != '*') TUTORdump("strnf2n");
    }
    return(localstr);

} /* strnf2n */

/* ******************************************************************* */

int strlenf(aa)
char FAR *aa;

{   long count;

    count = 0;
    while (*aa++) count++;
    return(count);

} /* strlenf */


/* ******************************************************************* */

char FAR *strcpyf(aa,bb)  /* copy two far character strings */
char FAR *aa;
char FAR *bb;

{
    while (*aa++ = *bb++);

} /* strcpyf */

/* ******************************************************************* */

char FAR *strcatf(aa,bb)  /* concatenate two far character strings */
char FAR *aa;
char FAR *bb;

{
    while (*aa) aa++;
    while (*aa++ = *bb++);

} /* strcatf */

/* ******************************************************************* */

int strcmpf(aa,bb) /* compare two far character strings */
char FAR *aa;
char FAR *bb;

{
    while(TRUE) {
    if (*aa != *bb) {
        if (*aa > *bb) return(1);
        else return(-1);
    } /* if */
    if (!(*aa)) return(0);
    aa++;
    bb++;
    }

} /* strcmpf */

/* ******************************************************************* */

int strcmpnw(aa,bb) /* compare two far newline-termiated strings */
char FAR *aa;
char FAR *bb;

{
    while(TRUE) {
    if (*aa != *bb) {
        if (*aa > *bb) return(1);
        else return(-1);
    } /* if */
    if (*aa == '\n') return(0);
    aa++;
    bb++;
    }

} /* strcmpnw */

/* ******************************************************************* */

char FAR *strncpyf(aa,bb,nn) /* copy two far character strings */
char FAR *aa;
char FAR *bb;
int nn;

{
    while ((nn > 0) && (*aa++ = *bb++)) nn--;

} /* strncpyf */

/* ******************************************************************* */

char FAR *strncatf(aa,bb,nn)  /* concatenate two far character strings */
char FAR *aa;
char FAR *bb;
int nn;

{
    while (*aa) aa++;
    while ((nn > 0) && (*aa++ = *bb++)) nn--;

} /* strcatf */

/* ******************************************************************* */

int strncmpf(aa,bb,nn) /* compare two far character strings */
char FAR *aa;
char FAR *bb;
int nn;

{
    while (nn > 0) {
    nn--;
    if (*aa != *bb) {
        if (*aa > *bb) return(1);
        else return(-1);
    } /* if */
    if (!(*aa)) return(0);
    aa++;
    bb++;
    } /* while */
    return(0);

} /* strncmpf */

/* ******************************************************************* */

int matherr(x)
struct exception *x;

{
    return(1);

} /* matherr */

/* ******************************************************************* */
