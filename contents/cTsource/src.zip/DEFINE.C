/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>
#include "ctutor.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "exprdefs.h"
#include "yacc.h"
#include "ct_ctype.h"


#ifdef ctproto
extern char  *strf2n(char  FAR *strp);
extern int TUTORdump(char *str);
extern int init_unit_defines(void);
int release_define_chain(Memh hh);
char  FAR *strcatf(char  FAR *aa,char  FAR *bb);
extern long add_descriptor(char FAR *item,long size);
extern long getindex(int *term);
extern int release_local_defines(void);
extern int TUTORcompare(char FAR *aa,char FAR *bb, long len);
extern int compare_def_sets(Memh sA,Memh sB);
extern long  getindex(int *term);
double  getliteral(int  *term);
extern int release_old_defines(void);
extern int init_all_defines(void);
extern int end_global_defines(void);
extern int end_local_defines(void);
extern int TUTORblock_move(char SHUGE *from,char SHUGE *to,long len);
int  sizetv(int  opc);
extern int strcmpf(char FAR *aa,char FAR *bb);
extern int find_def_sym(Memh topSetH,char *s,Memh *retSet,int *retIndex) ;
extern int comp_next_define(void);
extern Memh create_defset(char *nm);
extern Memh find_defset(char *nm);
extern int global_defset_name(char *ws);
extern int user_defset_name(char *ws);
extern int merge_defset(Memh setH);
extern int set_wk_defset(Memh setH);
extern char FAR *strcpyf(char FAR *aa,char FAR *bb);
int comp_unit_args(void);
extern int comp_define_line(void);
extern int TUTORzero(char SHUGE *ptr,long len);
extern unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
extern int TUTORfree_handle(unsigned int hh);
int  cerror(int  errnumber,char  *execstr);
int  _TUTORinq_state_internal_marker(int  ind,long  *pos,long  *len,int  *altered);
int  cmpbuf_plant_word(unsigned int  addr,int  n);
int  add_dest(int  type,int  label,unsigned int  pos);
int  plant_xref(int  iref,unsigned int  adest);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  cmpbuf_word(int  n);
int  add_xref(int  kind,int  label,unsigned int  aref,unsigned int  adest);
char  FAR *GetPtr(unsigned int  mm);
int  compile_simple_numeric(int  nmask,int  fmask,int  stopl);
int  compile_short_value(int  vv);
int  cmpbuf_xref(int  kind,int  label);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
int  CTisascii(int cc);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
int  deflook(char  *s,int  glf,int  symi);
int  extract_keyword_cB(char  *kname,int  maxl,int  spaces,int  *term);
long  TUTORget_hsize(unsigned int  mm);
int  skip_white_cB(void);
int  FillBuffer(unsigned int  readDoc,long  readPos,long  maxRead);
int  next_cB(void);
int  StripTrailingComment(int  cIndex,int  cmdN);
int  getdefines(long  currentkind);
int  satisfy_xref(int  index,int  kind,int  label,unsigned int  adest);
int  compile(struct  expra *exap);
int  TUTORdealloc(char  FAR *ptr);
char  FAR *TUTORrealloc(char  FAR *ptr,long  oldsize,long  newsize,int  abort);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  compile_file(int  storef);
int  compile_keyword_and_args(struct  keywdinf *klist,int  *term);
int  compile_marker(int  storef,int  semic);
int  pbscan(unsigned char  FAR *str,int  indx,char  *target);
int  compile_txtype(int  type,int storef);
int  compile_float(void);
int  compile_single_keyword(struct  keywdinf *klist,int  *term);
extern int  define_seg(void);
extern long  AddDescriptor(long  baseaddr,long  *arraylength,int  *arraysum,long  currentkind);
extern long  getindex(int  *term);
double  getliteral(int  *term);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  cerror(int  errnumber,char  *execstr);
int  deflook(char  *s,int  glf,int  symi);
int  extract_keyword_cB(char  *kname,int  maxl,int  spaces,int  *term);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
char  *strf2n(char  FAR *strp);
int  skip_white_cB(void);
long  TUTORget_hsize(unsigned int  mm);
int  compile(struct  expra *exap);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
#endif /* ctproto */

extern double getliteral(); /* evaluate floating constant */
extern long lcftoi();	/* round double to integer conversion */
extern long AddDescriptor();
extern long getindex();
extern Memh create_defset();
extern Memh find_defset();
extern global_defset_name();
extern user_defset_name();
extern long add_descriptor();

/* ******************************************************************* */

struct defopinf {
	char *name; /* option name */
	int type; /* option type */
	int value; /* associated value */
}; /* defopinf */

#define DOP_VAR 1
#define DOP_TXTYPE 2
#define DOP_USER 3
#define DOP_AUTHOR 4
#define DOP_MERGE 5
#define DOP_SET 6

static struct defopinf defoplist[20] = { {"float",DOP_VAR,TFLOAT},
  {"f",DOP_VAR,TFLOAT}, {"integer",DOP_VAR,TINT}, {"i",DOP_VAR,TINT},
  {"byte",DOP_VAR,TBYTE}, {"b",DOP_VAR,TBYTE}, {"marker",DOP_VAR,TMARK}, 
  {"m",DOP_VAR,TMARK}, {"file",DOP_TXTYPE,TXFILE}, 
  {"screen",DOP_TXTYPE,TXSCREEN}, {"button",DOP_TXTYPE,TXBUTTON}, 
  {"slider",DOP_TXTYPE,TXSLIDER}, {"edit",DOP_TXTYPE,TXEDIT},
  {"touch",DOP_TXTYPE,TXTOUCH}, {"dde",DOP_TXTYPE,TXDDE},
  {"author",DOP_AUTHOR,0},
  {"user",DOP_USER,0},
  {"merge",DOP_MERGE,0},{"group",DOP_SET,0},
  {NULL,0,0} };

/* ******************************************************************* */

comp_unit_args() /* compile unit arguments */
/* cI points at first character past left paren */
/* uargH is handle on (initialized) arguments table */

{	int term; /* terminating character */
	int loc; /* current location in input */
	int symlen; /* length of argument name */
	int passvalf; /* TRUE if processing pass-by-value */
	Memh fSetH; /* for find_def_sym call */
	int fIndex; /* for find_def_sym call */
	int retf; /* TRUE if argument defined */
	struct argdef FAR *thisargP; /* pointer in arguments table */
	char c;
	char ws[DEFNAMEL+2]; /* argument name */
		
	if (uargP == NULL)
		uargP = (struct argdef FAR *)GetPtr(uargH);
	thisargP = uargP; /* pointer in arguments table */
	passvalf = TRUE; /* start processing pass-by-value */
	loc = cI;
	c = next_cB(); /* get next character */
	if (c == ';')
		passvalf = FALSE;
	else cI = loc; /* process character again */
	
	do {
	
		/* get next unit argument name */
		
		symlen = extract_keyword_cB(ws,NAMEL,FALSE,&term);
		if (symlen <= 0)
			cerror(BADNAME,NEARNULL);
		thisargP->startOfLine = startofline;
		thisargP->cI = cI;

		/* add to unit arguments table */
		
		strcpyf(thisargP->name,(char FAR *)ws);
		if (passvalf) 
			npass_by_value++;
		else
			npass_by_addr++;
		if ((npass_by_value > MAXPASSVAL) || (npass_by_addr > MAXPASSADDR))
			cerror(SPECIFICERR,"Unit has too many arguments");
			
		if (term == ';')
			passvalf = FALSE; /* now on pass-by-address */
		thisargP++;
		
	} while ((term != ')') && (term != ']'));
	
	c = next_cB(); /* next character should be end */
	if (c != NEWLINE)
		cerror(TOOMANY,NEARNULL);
	ReleasePtr(uargH);
	uargP = NULL; /* release unit arguments table */

} /* comp_unit_args */

/* ******************************************************************* */

comp_define_line() /* compile line of defines */

{	int term; /* terminating character */
	int loc; /* position in source line */
	int symlen; /* length of symbol name */
	int eolf; /* TRUE if should be at end of line */
	char c; /* current character */
	struct defopinf *dfp; /* pointer in options table */
	Memh setH; /* handle on define set */
	struct defset FAR *setP; /* pointer to define set */
	int ndefs; /* number defines in set */
	char ws[DEFNAMEL+2]; /* keyword */

	addcmd = -1; /* don't add to binary */
	chkeol = FALSE; /* assume processed entire line */
	eolf = FALSE; /* not expecting end of line yet */

	if (wkSetH == HNULL) 
		cerror(SPECIFICERR,"no define group in effect?");
		
	loc = cI; /* save starting position */
	term = -1; /* terminating character unknown */
	symlen = extract_keyword_cB(ws,NAMEL,FALSE,&term);
	if (symlen <= 0)
		ws[0] = '\0'; /* no keyword understood */
	
	/* check if define xxxx: option */
	
	dfp = &defoplist[0];
	do {
		if (strcmp(ws,dfp->name) == 0)
			break; /* recognized option */
		dfp++;
	} while (dfp->type);

	switch (dfp->type) {
	
	case DOP_VAR: /* i:, f:, etc */
		if ((term == NEWLINE) || (term == ',')) {
			cI = loc; /* variable, not type */
			break;
		}
		if (term != ':')
			cerror(NEEDCOLON,NEARNULL);
		currentkind = dfp->value; /* get variable type */
		break;
		
	case DOP_TXTYPE: /* file:, edit:, etc */
		if (term != ':')
			cerror(NEEDCOLON,NEARNULL);
		currentkind = ((long)dfp->value << 16)+TXTYPE; 
		break;
	
	case DOP_AUTHOR: /* author variables */
	case DOP_USER: /* user/student variables */
		if (term != ':')
			cerror(NEEDCOLON,NEARNULL);
		eolf = TRUE; /* this operation ends line */
		
		/* set up global/user set name */
		
		if (dfp->type == DOP_AUTHOR) {
			global_defset_name(ws); /* get global defines name */
		} else {
			user_defset_name(ws); /* get user defines name */
		}
		
		/* locate global or user define set */
			
		setH = find_defset(ws); /* check if already exists */
		if (!setH)
			cerror(SPECIFICERR,"Can't find global/user defines");
	
		/* select global/user set */
		
		set_wk_defset(setH); /* compiling this set */	
		break;
		
	case DOP_MERGE: /* merge globals or another set */
		if (term != ',')
			cerror(MISSINGARG,NEARNULL);
		eolf = TRUE; /* should be at end of line */
	
		/* get define set name */
		
		symlen = extract_keyword_cB(ws,NAMEL,FALSE,&term);
		if (symlen <= 0)
			cerror(BADNAME,NEARNULL);
		if (term != ':')
			cerror(NEEDCOLON,NEARNULL);
		if (strcmp(ws,"globals") == 0)  
			ws[6] = '\0'; /* convert globals to global */
			
		/* get appropriate name for global/user define sets */
		
		if (strcmp(ws,"global") == 0) 
			global_defset_name(ws);
		else if (strcmp(ws,"user") == 0)
			user_defset_name(ws);
			
		/* search for set to merge */
			
		setH = find_defset(ws); /* search for specified set */
		if (setH == HNULL) {
			if (compunit == 0) {
				setH = create_defset(ws); /* create new define set */
			} else cerror(SPECIFICERR,"Merge of nonexistent define group");
		}
			
		/* merge this set with current */
		
		merge_defset(setH); /* merge with current */
		
		/* flag that this unit references globals */
		
		if (compunit)
			unittab[compunit].hasglobals = TRUE;
		break;
		
	case DOP_SET: /* begin new define set */
		if (term != ',')
			cerror(MISSINGARG,NEARNULL);
		if (compunit)
			cerror(SPECIFICERR,"Define groups must be global");
		eolf = TRUE; /* should be at end of line */
			
		/* get define set name */
		
		symlen = extract_keyword_cB(ws,NAMEL,FALSE,&term);
		if (symlen <= 0)
			cerror(BADNAME,NEARNULL);
		setH = find_defset(ws); /* check if already exists */
		if (setH) {
			setP = (struct defset FAR *)GetPtr(setH);
			ndefs = setP->defvarN; /* get number of defines */
			ReleasePtr(setH);
			KillPtr(setP);
			if (ndefs)
				cerror(SPECIFICERR,"Duplicate define set");
		} else { /* create new define set */
			setH = create_defset(ws); /* create new define set */
		}
		set_wk_defset(setH); /* compiling new set */
		currentkind = NOTDEFINED;
		break;
		
	default:
		cI = loc; /* didn't recognize: reset to start of line */
		break;
		
	} /* switch */
	
	/* check if operation that must terminate line */
	
	if (eolf && (term != NEWLINE)) {
		c = next_cB(); /* get next character */
		if (c == NEWLINE)
			return; /* at end of line */
		cerror(BADMERGEG,NEARNULL);
	} /* eolf if */
	
	/* process rest of this line */
	
	do {
		term = comp_next_define();
	} while (term != NEWLINE);
	
} /* comp_define_line */

/* ******************************************************************* */

static int comp_next_define() /* process next symbol define */

{	int term; /* terminating character */
	int loc; /* current position in input buffer */
	int symlen; /* length of current symbol */
	Memh fSetH; /* handle on define set for symbol */
	int fIndex; /* index in name table at which symbol belongs */
	int uii; /* index in unit arguments table */
	int passv; /* TRUE if pass-by-value argument */
	int passa; /* TRUE if pass-by-address argument */
	long nkind; /* variable (array) type */
	struct argdef FAR *argP; /* pointer in unit arguments table */
	int vsize; /* size of currentkind variables */
	long ndefsz; /* size of defvar table */
	int ndim; /* number dimensions (of array) */
	int dii; /* index in array dimensions */
	int definite; /* TRUE if hit a definite array dimension */
	int indefinite; /* TRUE if hit an indefinite array dimension */
	int dynarray; /* TRUE if dynamically allocated array */
	long lower; /* lower bound of array */
	long length; /* length of array dimension */
	long cumlth; /* cumulative length of array dimension(s) */
	long descloc; /* location of array descriptor */
	struct defvar newdef; /* new definition building */
	struct array_desc adsc; /* array descriptor */
	struct dim_desc ddsc[10]; /* dimension descriptors */
	struct mark_desc mdsc; /* marker descriptor */
	struct txtype_desc txdsc; /* txtype descriptor */
	struct defvar FAR *defP; /* pointer to symbol table */
	char FAR *mvfrom; /* from address for move */
	char FAR *mvto; /* to address for move */
	long mvlen; /* length for move */
	int numericK; /* true if numeric kind */
	long zeri; /* index of new defines to zero */
	long zern; /* number of new defines to zero */
	int retf; 
	int c;
	char ws[DEFNAMEL+2]; /* symbol name */

	/* check if have defined name symbol table yet */

	if (wkSetP->defvarH == HNULL) {
		wkSetP->defvarA = 20; /* allocate space for 20 names */
		wkSetP->defvarN = 0;
		wkSetP->defvarH = TUTORhandle("defvar",20L*sizeof(struct defvar),TRUE);
	} /* defvarH if */
	
	/* check if have room for new symbol */
	
	if ((wkSetP->defvarA-wkSetP->defvarN) < 1) {
		zeri = wkSetP->defvarA; /* current number allocated */
		wkSetP->defvarA += (wkSetP->defvarA/5); /* add 20% new slots */
		zern = wkSetP->defvarA-zeri; /* number new slots to zero */
		ndefsz = (long)(wkSetP->defvarA*sizeof(struct defvar));
		retf = TUTORset_hsize(wkSetP->defvarH,ndefsz,FALSE);
		if (!retf)
			cerror(COMPMEM,NEARNULL); /* out of memory */
		defP = (struct defvar FAR *)GetPtr(wkSetP->defvarH);
		mvto = (char FAR *)(&defP[zeri]);
		mvlen = zern*sizeof(struct defvar);
		TUTORzero(mvto,mvlen); /* zero new define table slots */
		ReleasePtr(wkSetP->defvarH);
		KillPtr(defP);
	} /* defvarA if */
	
	/* check if already at end of line (trailing whitespace) */
	
	loc = cI; /* save current position */
	c = next_cB(); /* get next character */
	if (c == NEWLINE) 
		return(c); /* done if at end of line */
	cI = loc; /* reset to begin of symbol */
	
	/* get next defined name */
	
	symlen = extract_keyword_cB(ws,NAMEL,FALSE,&term);
	if ((symlen <= 0) || (!CTisalpha(ws[0])) || CTisdigit(ws[0]))
		cerror(BADNAME,NEARNULL);
	
	/* check if this name already defined */
	
	retf = find_def_sym(wkSetH,ws,&fSetH,&fIndex);
	if (retf)
		cerror(DUPDEF,NEARNULL);
	if (currentkind == NOTDEFINED)
		cerror(DEFFLOAT,NEARNULL);
		
	/* check if this is an argument of the unit */
	
	passv = passa = dynarray = FALSE;
	if(npass_by_value || npass_by_addr) {
		if (uargP == NULL)
			uargP = (struct argdef FAR *)GetPtr(uargH);
		argP = uargP;
		for (uii=0; uii<(npass_by_value+npass_by_addr); uii++) {
			if (strcmpf((char FAR *)ws,argP->name) == 0) { /* argument of unit */
				if (uii >= npass_by_value)
					passa = TRUE; /* pass-by-address argument */
				else passv = TRUE; /* pass-by-value argument */
				break; /* exit for */
			} /* strcmpf if */
			argP++; /* advance to next argument */
		} /* uii for */
	} /* arguments if */
	
	if ((curvbytes & 3) != 0) /* force alignment on 32-bit boundary */
		curvbytes = (curvbytes & (~3L))+4L;
#ifdef SOLARIS
    if (currentkind == TFLOAT) { 
        if ((curvbytes & 7) != 0) /* force 8-byte alignment */
            curvbytes = (curvbytes & (~7L))+8L;
    }
#endif
#ifdef hp700
    if (currentkind == TFLOAT) { 
        if ((curvbytes & 7) != 0) /* force 8-byte alignment */
            curvbytes = (curvbytes & (~7L))+8L;
    }
#endif
#ifdef IBMPC
	/* force floats to 8-byte alignment to insure float will never */
	/* cross segment boundary */
    if (currentkind == TFLOAT) { 
        if ((curvbytes & 7) != 0) /* force 8-byte alignment */
            curvbytes = (curvbytes & (~7L))+8L;
    }

    /* marker variables on PC are forced to be 64 bytes (normal size */
    /* is about 44 bytes) and at run time the stack is always managed */
    /* in multiples of 64 bytes - this insures a marker variable will */
    /* never cross a segment boundary */
    if (currentkind == TMARK) {
        if ((curvbytes & 0x3f) != 0) /* force 64-byte alignment */
            curvbytes = (curvbytes & (~0x3fL))+0x40L;
    }
#endif
	TUTORzero((char SHUGE *)&newdef,(long)sizeof(struct defvar));
	vsize = sizetv(currentkind); /* bytes/variable */
	strcpy(newdef.name,ws); /* set new variable name */
	newdef.kind = currentkind; /* TINT/TFLOAT/etc */
	newdef.loc = -1; /* no location yet */
	newdef.arrayinfo = -1; /* not an array */
	newdef.receive = FALSE; /* not pass-by-address */
	newdef.literal = FALSE;

	if ((term == NEWLINE) || (term == ',')) {
		
		/* process simple variable definition */
	
		newdef.loc = curvbytes; /* location in stack */
		if (passa) {
			newdef.receive = TRUE; /* pass-by-address */
			curvbytes += sizeof(long);
		} else {
			curvbytes += vsize; /* inc variable bytes added */
			if (currentkind == TMARK) {
				TUTORzero((char SHUGE *)&mdsc,(long)sizeof(struct mark_desc));
				mdsc.dtype = 4; /* 4 = single marker variable */
				mdsc.addr = newdef.loc; /* relative address */
				add_descriptor((char FAR *)&mdsc,
				    (long)sizeof(struct mark_desc));
			} else if ((currentkind & 0xffffL) == TXTYPE) {
				TUTORzero((char SHUGE *)&txdsc,(long)sizeof(struct txtype_desc));
				txdsc.dtype = 5; /* 5 = txtype (edit, button, etc) */
				txdsc.ltype = currentkind;
				txdsc.addr = newdef.loc; /* relative address */
				add_descriptor((char FAR *)&txdsc,
				    (long)sizeof(struct txtype_desc));
			}
		} /* passa else */
	} else if (term == '=') { 
		
		/* process literal or expression definition */
		
		if (passv || passa)
			cerror(ARGVAR,NEARNULL);
		newdef.dvalue = getliteral(&term);
		newdef.literal = TRUE; /* literal value */
		if ((term != ',') && (term != NEWLINE))
			cerror(WRONGSEP,NEARNULL);
	} else if (term == '(') {
		
		/* process array or function definition */
	
		if (passa)
			newdef.receive = TRUE; /* pass-by-address */
		if (passv)
			cerror(SPECIFICERR,"Can't pass array by value");
		numericK = TRUE; /* assume numeric type */
		if (currentkind == TINT) nkind = IARRAY;
		else if (currentkind == TFLOAT) nkind = FARRAY;
		else if (currentkind == TBYTE) nkind = BARRAY;
		else if (currentkind == TMARK) {
			nkind = MARRAY;
			numericK = FALSE;
		} else if ((currentkind & 0xffffL) == TXTYPE) {
			nkind = (currentkind >> 16) & 0xffffL;
			nkind = (nkind << 16) | XARRAY;
			numericK = FALSE;
		} else cerror(SPECIFICERR,"Unknown variable type");
		
		ndim = 0; /* haven't hit any dimensions yet */
		TUTORzero((char SHUGE *)&adsc,(long)sizeof(struct array_desc));
		TUTORzero((char SHUGE *)&ddsc[0],10L*sizeof(struct dim_desc));
		cumlth = 1; /* cumulative length of array */
		indefinite = definite = FALSE; 
		do {
			loc = cI; /* current position in buffer */
			c = next_cB(); /* get next character */
			if (c == '*') { /* indefinite dimension */
			
				/* process indefinite dimension */
				
				lower = length = cumlth = 0;
				indefinite = TRUE;
				if (!passa) 
					dynarray = TRUE; /* must be dynamic if not passed */
				term = next_cB(); /* get terminating character */
			} else { /* numeric dimension */
			
				/* process definite dimension */
				
				definite = TRUE; /* have hit a definite dim */
				lower = 1; /* assume lower bound = 1 */
				cI = loc; /* reset to start of expression */
				length = getindex(&term);
				if (term == ':') { /* from:to form */
					lower = length; 
					length = getindex(&term); /* get *to* */
					length = length-lower+1;
					if (length <= 0)
						cerror(SPECIFICERR,"array(from:to) with from>to");
				} /* term if */
				if (length <= 0)
					cerror(SPECIFICERR,"array length <= 0");
			} /* else */
			if ((term != ',') && (term != ')') && (term != ']'))
				cerror(WRONGSEP,NEARNULL);
				
			/* set up descriptor for this dimension */
			
			ddsc[ndim].lower = lower;
			ddsc[ndim].length = length;
			cumlth *= length; /* build total length */
			ndim++; /* increment number dimensions */
			if (ndim > 10)
				cerror(SPECIFICERR,
					"Array may not have more than 10 dimensions");
		} while (term != ')');
		
		/* check if improper mixture of def/indef dimensions */
		
		if (indefinite && definite) 
			cerror(MIXINDEF,NEARNULL);
		if (definite && passa)
			cerror(SPECIFICERR,
			      "Pass-by-address array must not have definite length");
			
		/* dynamic array restricted to numeric types */
		
		if (passa && numericK)
			dynarray = TRUE; /* treat all passed numeric arrays as dynamic */
		if (dynarray && (!numericK))
			cerror(SPECIFICERR,"Dynamic array must be numeric type");
			
		/* check if next terminator (after paren) ok */
		
		term = next_cB();
		if ((term != ',') && (term != NEWLINE))
			cerror(WRONGSEP,NEARNULL);
			
		/* compute multiplier for each dimension */
		
		if (!dynarray) {
			dii = ndim; /* loop backwards thru dimensions */
			length = 1;
			do {
				dii--; /* index for next dimension */
				ddsc[dii].multiplier = length;
				length = length*ddsc[dii].length; 
			} while (dii);
		}
		
		/* build array descriptor */
		
		if (dynarray) adsc.dtype = 6; /* dynamic array */
		else adsc.dtype = 1; /* 1 = array descriptor */
		newdef.dynamic = dynarray; 
		adsc.ltype = currentkind; /* variable kind */
		adsc.addr = curvbytes; /* base address */
		adsc.size = sizetv(currentkind); /* size of element */
		adsc.length = cumlth; /* total length (#elements) */
		adsc.ndim = ndim; /* number dimensions */
		adsc.passa = passa; /* TRUE if pass-by-address */
		curvbytes += (adsc.size*adsc.length)+ARRAYHDR;
		
		/* add array+dimension descriptors to pool */
		
		descloc = add_descriptor((char FAR *)&adsc,
		              (long)sizeof(struct array_desc));
		add_descriptor((char FAR *)&ddsc[0],
		    (long)(ndim*sizeof(struct dim_desc)));
			
		/* finish symbol table entry */
		
		newdef.kind = nkind;
		newdef.loc = adsc.addr; 
		newdef.arrayinfo = descloc;
	} else 
		cerror(WRONGSEP,NEARNULL);
	
	/* insert new define into symbol table */
	
	defP = (struct defvar FAR *)GetPtr(wkSetP->defvarH);
	fIndex = (-fIndex)-1;
	/* move to shove following entries down */
	mvfrom = (char FAR *)(defP+fIndex); 
	mvto = mvfrom+sizeof(struct defvar);
	mvlen = wkSetP->defvarN-fIndex; /* num table slots to move */
	mvlen *= sizeof(struct defvar); /* convert to bytes */
	if (mvlen > 0)
		TUTORblock_move(mvfrom,mvto,mvlen);
	TUTORblock_move((char SHUGE *)&newdef,mvfrom,
	                (long)sizeof(struct defvar));
	ReleasePtr(wkSetP->defvarH);
	wkSetP->defvarN++; /* increment number of symbols */

	return(term);
	
} /* comp_next_define */

/* ******************************************************************* */

static long add_descriptor(item,size) /* add to descriptors pool */
/* returns address of new space */
char FAR *item; /* address of item to add to pool */
long size; /* amount of space to add */

{	long descloc; /* relative location in descriptors pool */

	descloc = TUTORget_hsize(descH); /* get current length */
	if (descP) 
		ReleasePtr(descH); /* allow handle resize */
	TUTORset_hsize(descH,descloc+size,TRUE);
	descP = GetPtr(descH); /* reaquire pointer */
	TUTORblock_move(item,descP+descloc,size); /* add item */
	unittab[compunit].descl += size; 
	descloc -= unittab[compunit].descp; /* make relative to unit */
	return(descloc); /* return relative address of new item */
		
} /* add_descriptor */

/* ******************************************************************* */

int end_global_defines() /* process end of global definitions */

{	int uii; /* index in unit table */
	int altered; /* TRUE if global defines have altered */
	Memh newsH; /* handle on new set */
	Memh nextnH; /* handle on next new set */
	Memh oldsH; /* handle on old set */
	Memh nextoH; /* handle on next old set */
	struct defset FAR *sP; /* pointer to set */
	char FAR *cpAP; /* pointer to old data to compare */
	char FAR *cpBP; /* pointer to new data to compare */

	if (global_def_fin) 
		return(0); /* already finished up */
	global_def_fin = TRUE;
	
	/* set to use default global define set */
	
	set_wk_defset(globalSetH);
	
	/* set size of global variables */
	
	if ((curvbytes & 0x3) != 0) /* force alignment on 32-bit boundary */
		curvbytes = (curvbytes & (~0x3L))+0x4L;
#ifdef SOLARIS
    if ((curvbytes & 7) != 0) /* force 8-byte alignment */
        curvbytes = (curvbytes & (~7L))+8L;
#endif
#ifdef hp700
    if ((curvbytes & 7) != 0) /* force 8-byte alignment */
        curvbytes = (curvbytes & (~7L))+8L;
#endif
#ifdef IBMPC
    if ((curvbytes & 0x3f) != 0) /* force align on 64-byte boundary */
        curvbytes = (curvbytes & (~0x3fL))+0x40L;
#endif
	gvaraddr = curvbytes;
	
	/* compare all define sets to old copies */

	altered = FALSE; /* no changes yet */
	nextnH = firstSetH; /* handle on first set in new chain */
	nextoH = oldSetH; /* handle on first set in old chain */
	while (nextnH || nextoH) {
		if ((nextnH ? TRUE: FALSE) != (nextoH ? TRUE: FALSE)) {
			altered = TRUE;
			break; /* set chains do not compare */
		}
		newsH = nextnH; /* handle on new set */
		oldsH = nextoH; /* handle on old set */
		if (!compare_def_sets(newsH,oldsH)) {
			altered = TRUE;
			break; /* exit if sets did not compare */
		}
		sP = (struct defset FAR *)GetPtr(newsH);
		nextnH = sP->nextSet; /* next set in new chain */
		ReleasePtr(newsH);
		sP = (struct defset FAR *)GetPtr(oldsH);
		nextoH = sP->nextSet; /* next set in old chain */
		ReleasePtr(oldsH);
	} /* while */
	
	/* check if global array descriptors have changed */
	
	if ((unittab[0].descl ? TRUE: FALSE) != (oldDescH ? TRUE: FALSE))
		altered = TRUE;
	if (!altered && oldDescH) {
		if ((long)unittab[0].descl != TUTORget_hsize(oldDescH))
			altered = TRUE;
		if (descP == NULL)/* get pointer to descriptors pool */
			descP = GetPtr(descH);
		cpAP = GetPtr(oldDescH); /* address of old data */
		cpBP = descP+unittab[0].descp; /* address of new data */
		if (!TUTORcompare(cpAP,cpBP,(long)unittab[0].descl)) {
			altered = TRUE;
		}
		ReleasePtr(oldDescH);
		ReleasePtr(descH);
		KillPtr(descP);
		descP = FARNULL;
	} /* oldDescH if */
	
	if (!altered) 
		return(FALSE); /* no changes */
	
	/* force recompile of units that reference global variables */

	for (uii = 1; uii < nunits; uii++) {
		if (unittab[uii].hasglobals) 
			unittab[uii].compiled = FALSE;
	} /* for */
	gvarzero = TRUE; /* must re-zero global vars */	
	return(TRUE); /* defines were altered */

} /* end_global_defines */

/* ******************************************************************* */

end_local_defines() 

{	int aii; /* index in unit arguments table */
	long dscloc; /* location in descriptors */
	Memh SetH; /* handle on define set */
	struct defset FAR *SetP; /* pointer to define set */
	Memh SymH; /* handle on defined symbols */
	struct defvar FAR *SymP; /* pointer to defined symbols */
	struct argdef FAR *thisargP; /* pointer in arguments table */
	struct arg_desc argdsc; /* unit argument descriptor */
	Memh fSetH; /* handle on define set of symbol */
	int fIndex; /* index of symbol in define set */
	int retf; /* return from variable name search */
	char msg[80];
	
	local_def_fin = TRUE;
	
	/* set size of local variables */

	if ((curvbytes & 0x3) != 0) /* force alignment on 32-bit boundary */
		curvbytes = (curvbytes & (~0x3L))+0x4L;
#ifdef SOLARIS
    if ((curvbytes & 7) != 0) /* force 8-byte alignment */
        curvbytes = (curvbytes & (~7L))+8L;
#endif
#ifdef hp700
    if ((curvbytes & 7) != 0) /* force 8-byte alignment */
        curvbytes = (curvbytes & (~7L))+8L;
#endif
#ifdef IBMPC
    if ((curvbytes & 0x3f) != 0) /* force align on 64-byte boundary */
        curvbytes = (curvbytes & (~0x3fL))+0x40L;
#endif
	lvaraddr = curvbytes;
	
	/* use global defines by default if no local defines */

	SetP = (struct defset FAR *)GetPtr(localSetH);
	if ((!SetP->defvarN) && (!SetP->mergeN)) {
		set_wk_defset(globalSetH);
	}
	ReleasePtr(localSetH);
	KillPtr(SetP);

	if ((npass_by_value+npass_by_addr) == 0)
		return; /* no arguments to process */
	
	/* build unit argument descriptors */
	
	dscloc = TUTORget_hsize(descH); /* starting index in descriptors */
	unittab[compunit].argdesc = dscloc-unittab[compunit].descp;
	unittab[compunit].nvargs = npass_by_value;
	unittab[compunit].naargs = npass_by_addr;
	if (uargP == NULL)
		uargP = (struct argdef FAR *)GetPtr(uargH);
	thisargP = uargP;  /* pointer in arguments table */
	for(aii=0; aii<(npass_by_value+npass_by_addr); aii++) {
	
		/* check that unit argument has been defined */
	
		if (!thisargP->defined) {
			
			/* search to see if name defined */
			
			retf = find_def_sym(wkSetH,strf2n(thisargP->name),&fSetH,&fIndex);
			if (retf) {
				thisargP->defsetH = fSetH; 
				thisargP->defIndex = fIndex;
				thisargP->defined = TRUE;
			} else {	
				
				/* error if argument not defined */
				/* reset so message will highlight unit line */

				strcpy(msg,"Unit argument '");
				strcatf((char FAR *)msg,thisargP->name);
				strcat(msg,"' not defined");
				startofline = thisargP->startOfLine;
				cI = thisargP->cI;
				ciStart = 0;
				ReleasePtr(uargH); 
				uargP = FARNULL;
				cerror(SPECIFICERR,msg);
			} /* else */
		} /* not defined if */
	
		/* locate next symbol definition */
		
		SetH = thisargP->defsetH; /* handle on define set */
		SetP = (struct defset FAR *)GetPtr(SetH); 
		SymH = SetP->defvarH; /* handle on symbol table */
		SymP = (struct defvar FAR *)GetPtr(SymH);
		SymP += thisargP->defIndex; /* pointer to this defined symbol */
		
		/* error if unit argument is constant */
		
		if (SymP->literal) {
			strcpy(msg,"Unit argument '");
			strcatf((char FAR *)msg,thisargP->name);
			strcat(msg,"' is a constant");
			cI = 0; /* stop cerror from highlighting */
			ReleasePtr(SetH);
			KillPtr(SetP);
			ReleasePtr(SymH);
			KillPtr(SymP);
			ReleasePtr(uargH); 
			uargP = FARNULL;
			cerror(SPECIFICERR,msg);
		}
		
		/* build argument descriptor */

		TUTORzero((char SHUGE *)&argdsc,(long)sizeof(struct arg_desc));
		argdsc.dtype = ((aii < npass_by_value) ? 2: 3); 
		/* 2 = pass-by-value, 3 = pass-by-address */
		argdsc.ltype = SymP->kind; /* int/float/mark etc type */
		argdsc.global = !SetP->local; /* global/local flag */
		argdsc.addr = SymP->loc; /* relative addr on stack */
		add_descriptor((char FAR *)&argdsc,(long)sizeof(struct arg_desc));
		ReleasePtr(SymH); /* release symbol table */
		KillPtr(SymP);
		ReleasePtr(SetH); /* release define set */
		KillPtr(SetP);
		if (argdsc.global && (argdsc.dtype == 3)) {
			ReleasePtr(uargH);
			uargP = FARNULL;
			cerror(SPECIFICERR,"Can't use global variable for pass-by-address");
		}
		thisargP++; /* advance pointer in arguments table */
	} /* aii for */
	lvaraddr = curvbytes; 
	ReleasePtr(uargH);
	uargP = NULL; /* release unit arguments table */
	
} /* end_local_defines */

/* ******************************************************************* */

static int compare_def_sets(saH,sbH) /* compare two define sets */
Memh saH; /* handle on first set to compare */
Memh sbH; /* handle on second set to compare */

{	struct defset FAR *aP; /* pointer to first set */
	struct defset FAR *bP; /* pointer to second set */
	char FAR *adP; /* pointer to 1st set of defined symbols */
	char FAR *bdP; /* pointer to 2nd set of defined symbols */
	long len; /* length of symbol table */
	int same; /* TRUE if sets verify */
	
	if (!saH) 
		return(FALSE); /* cant compare if no set */
	if ((saH ? TRUE: FALSE) != (sbH ? TRUE: FALSE))
		return(FALSE); /* did not compare */
	
	aP = (struct defset FAR *)GetPtr(saH); 
	bP = (struct defset FAR *)GetPtr(sbH);
	same = (strcmpf(aP->name,bP->name) == 0); /* checks set names */
	if (aP->defvarN != bP->defvarN)
		same = FALSE; /* doesnt verify */
	if (aP->mergeN != bP->mergeN)
		same = FALSE; /* doesnt verify */
	if ((aP->defvarH ? TRUE: FALSE) != (bP->defvarH ? TRUE: FALSE))
		same = FALSE; /* doesnt verify */
	if (same && aP->defvarH) {
		len = aP->defvarN*sizeof(struct defvar);
		if (same) {
			adP = GetPtr(aP->defvarH);
			bdP = GetPtr(bP->defvarH);
			same = TUTORcompare(adP,bdP,len); /* compare symbol tables */
			ReleasePtr(aP->defvarH);
			ReleasePtr(bP->defvarH);
		}
	} /* defvarH */
	
	ReleasePtr(saH);
	ReleasePtr(sbH);
	return(same); /* TRUE if verified */

} /* compare_def_sets */

/* ******************************************************************* */

init_all_defines() /* initialize all defines/sets */

{	struct unitinfo FAR *uP; /* pointer to unit table entry */
	char FAR *fromP; /* from address for move */
	char FAR *toP; /* to address for move */
	struct defset FAR *dsetp; /* pointer to define set */
	int ii;
	char ws[DEFNAMEL]; /* define set name */

#ifdef IBMPC
	if (sizeof(struct markvar) != 64) /* must be power of 2 on PC */
		TUTORdump("markvar");
#endif
	set_wk_defset(HNULL); /* not compiling any define set yet */
	
	/* release local define sets kept for debugging */
	
	for (ii = 0; ii < nunits; ii++) {
		if (unittab[ii].debugSetH) {
			release_define_chain(unittab[ii].debugSetH);
			unittab[ii].compiled = FALSE;
		}
		unittab[ii].debugSetH = HNULL;
	}	
	
	/* destroy previous saved define/descriptors structures */
	
	release_old_defines();
	
	/* destroy local define set */

	release_local_defines();

	/* save handle on entire -define- structure for later compare */
	/* to see if global defines have changed */
	
	oldSetH = firstSetH;
	
	/* save global array descriptors for later compare to see if */
	/* global defines have changed */
	
	uP = &unittab[0]; /* pointer to IEU entry in unit table */
	if (uP->descl) { /* check if IEU has any descriptors */
		if (descP == NULL)/* get pointer to descriptors pool */
			descP = GetPtr(descH);
		oldDescH = TUTORhandle("olddsc",(long)uP->descl,TRUE);
		toP = GetPtr(oldDescH); /* address to copy to */
		fromP = descP+uP->descp; /* address of descriptors */
		TUTORblock_move(fromP,toP,(long)uP->descl); /* copy descript */
		ReleasePtr(oldDescH);
		KillPtr(toP);
	} /* descl if */	
	
	/* set up for new global defines */
	
	firstSetH = lastSetH = HNULL; /* break defined sets chain */
	globalSetH = userSetH = HNULL;
	curvbytes = 3*sizeof(struct markvar); /* reset allocation */
	
	/* clear currently-compiling set */
	
	set_wk_defset(HNULL);
	
	/* allocate new global and user define sets */
	
	global_defset_name(ws);
	globalSetH = create_defset(ws); 
	sourcetable[0].globaldefsetH = globalSetH;
	dsetp = (struct defset FAR *)GetPtr(globalSetH);
	dsetp->global = TRUE; /* flag as default global set */
	ReleasePtr(globalSetH);
	KillPtr(dsetp);
	
	user_defset_name(ws);
	userSetH = create_defset(ws);
	sourcetable[0].userdefsetH = userSetH;
	dsetp = (struct defset FAR *)GetPtr(userSetH);
	dsetp->user = TRUE; /* flag as user define set */
	ReleasePtr(userSetH); 
	KillPtr(dsetp);
	
	set_wk_defset(globalSetH); /* pre-set to use global defines */
	merge_defset(userSetH); /* merge global+user */
	
	for(ii=1; ii<sourcemalloc; ii++) {
		sourcetable[ii].globaldefsetH = HNULL; /* no define author: yet */
		sourcetable[ii].userdefsetH = HNULL; /* no define user: yet */
	}
	global_def_fin = local_def_fin = FALSE; /* not thru compiling globals yet */
	
} /* init_all_defines */

/* ******************************************************************* */

int release_local_defines() /* destroy local define set, if any */
	
{	struct defset FAR *lsetp; /* pointer to local var defs */

	set_wk_defset(HNULL); /* no define set in effect */
	release_define_chain(localSetH); /* (only 1 set in chain) */
	localSetH = HNULL; /* no local define set */

} /* release_local_defines */	
	

/* ******************************************************************* */	

init_unit_defines() /* initialize defines for this unit/file */

{	Memh setH; /* handle on defs for this file */
	char ws[DEFNAMEL]; /* name for files global defines */
	struct sourcefile FAR *srP; /* pointer to sourcetable entry */
	struct defset FAR *newP; /* pointer to new/local define set */
	
	/* if debugging, local set saved in unit table */
	
	if (DebugWn >= 0) set_wk_defset(HNULL); /* no define set in effect */
	else release_local_defines(); /* destroy existing local set */
	
	local_def_fin = FALSE;
	srP = &sourcetable[csourcen];
	
	/* check if compiling IEU - may need to set up define sets */
	
	if (compunit == 0) {

		/* check if need to create global defines for this file */
	
		if (!srP->globaldefsetH) {
			global_defset_name(ws); /* create name */
			setH = find_defset(ws); /* try to locate this set */
			if (!setH)
				setH = create_defset(ws); /* create new "global" defines */
			srP->globaldefsetH = setH; /* set as global defines for this file */
			newP = (struct defset FAR *)GetPtr(setH);
			newP->global = TRUE; /* flag as global defines for this file */
			ReleasePtr(setH);
			KillPtr(newP);
		}
	
		/* check if need to create user defines for this file */
	
		if (!srP->userdefsetH) {
			user_defset_name(ws); /* create name */
			setH = find_defset(ws); /* try to locate this set */
			if (!setH)
				setH = create_defset(ws); /* create new "user" defines */
			srP->userdefsetH = setH; /* set as user defines for this file */
			set_wk_defset(srP->globaldefsetH); /* now working on globals */
			merge_defset(setH); /* combine global+user */
			newP = (struct defset FAR *)GetPtr(setH);
			newP->user = TRUE; /* flag as user defines for this file */
			ReleasePtr(setH);
			KillPtr(newP);
		}
	} /* compunit if */
		
	/* set global define set for this unit+file */
	
	globalSetH = srP->globaldefsetH;
	userSetH = srP->userdefsetH;

	/* create new local define set */
	
	if (compunit == 0) {
		set_wk_defset(globalSetH); /* no local defines, use globals */
		if (csourcen == 0) /* main file */
			curvbytes = 3*sizeof(struct markvar); /* init variable allocation */
	} else {
		curvbytes = 0; /* init variable allocation */
		localSetH = TUTORhandle("defset",(long)sizeof(struct defset),TRUE);
		newP = (struct defset FAR *)GetPtr(localSetH);
		TUTORzero((char SHUGE *)newP,(long)sizeof(struct defset));
		newP->local = TRUE; /* flag as local define set */
		strcpyf(newP->name,(char FAR *)" local");
		ReleasePtr(localSetH);
		set_wk_defset(localSetH); /* pre-set to local define set */
	} /* compunit if */

} /* init_unit_defines */

/* ******************************************************************* */

int release_old_defines() /* destroy saved previous -define- tree */

{	Memh nextH; /* handle on next set in chain */
	Memh dumpH; /* handle set to dump */
	struct defset FAR *dsetP; /* pointer on next define set */
	
	release_define_chain(oldSetH); /* release saved defines */

	if (oldDescH) { /* dump old descriptors */
		TUTORfree_handle(oldDescH);
	} /* oldDescH if */
	
	oldSetH = oldDescH = HNULL;
		
} /* release_old_defines */

/* ******************************************************************* */	

static Memh create_defset(name) /* create a new define set */
char *name; /* name for new define set */

{	Memh newH; /* handle on new define set */
	struct defset FAR *newP; /* pointer to new define set */
	struct defset FAR *prevP; /* pointer to previous define set */
	
	/* create new define set */
	
	newH = TUTORhandle("defset",(long)sizeof(struct defset),TRUE);
	newP = (struct defset FAR *)GetPtr(newH);
	TUTORzero((char SHUGE *)newP,(long)sizeof(struct defset));
	strcpyf(newP->name,(char FAR *)name);
	newP->srcfile = csourcen; /* set index in source table */
	ReleasePtr(newH);
	
	/* add to defined sets chain */
	
	if (firstSetH) { /* if already a chain */
		prevP = (struct defset FAR *)GetPtr(lastSetH);
		prevP->nextSet = newH; /* chain previous to this */
		ReleasePtr(lastSetH);
	} else firstSetH = newH; /* first set in chain */
	lastSetH = newH; /* make this set last */

	return(newH); /* return handle on new define set */
	
} /* create_defset */

/* ******************************************************************* */

static int merge_defset(msetH) /* merge define set with compiling set */
Memh msetH; /* handle on set to merge */

{	int tii; /* index in merged sets table */
	int dii; /* index in defined symbols table */
	int already; /* TRUE if set already merged */
	int nalloc; /* number table slots (to be) allocated */
	long FAR *tP; /* handle on merged sets table */
	Memh fSetH; /* handle on define set for symbol */
	int fIndex; /* index in name table at which symbol belongs */
	int retf; 
	Memh nextMergeH; /* handle on set being merged */
	int mergeN; /* number sets to merge */
	struct defset FAR *msetP; /* pointer to set being merged */
	struct defvar FAR *defsP; /* pointer to symbols */
	char defnm[DEFNAMEL]; /* current defined name searching for */
	char msg[80]; /* error message buffer */

	if (msetH == wkSetH) /* don't merge ourselves */
		return(FALSE);
		
	/* initialize merge table if doesnt exist */
	
	if (wkSetP->mergeH == HNULL) {
		wkSetP->mergeA = nalloc = 5;
		wkSetP->mergeH = TUTORhandle("defmrg",
		                       (long)(nalloc*sizeof(long)),TRUE);
	} /* mergeH if */
	
	/* search table of merged sets to see if already included */
	
	already = FALSE; /* not known to be already merged */
	tP = (long FAR *)GetPtr(wkSetP->mergeH); /* ptr to table */
	for(tii=0; tii<wkSetP->mergeN; tii++) {
		if (tP[tii] == msetH) {
			already = TRUE; /* set is already merged */
			break; /* exit for */
		} /* tP if */
	} /* for */
	
	/* add this set to merged list if not in list */
	
	if (!already){ /* add if not already merged */
	
		/* check if need to extend table */
		
		if (wkSetP->mergeN >= wkSetP->mergeA) {
			wkSetP->mergeA += 5; 
			nalloc = wkSetP->mergeA;
			ReleasePtr(wkSetP->mergeH); 
			TUTORset_hsize(wkSetP->mergeH,(long)(nalloc*sizeof(long)),
			               TRUE);
			tP = (long FAR *)GetPtr(wkSetP->mergeH); 
		} /* mergeN if */
		
		/* check for conflicts with symbols in other sets */
		
		msetP = (struct defset FAR *)GetPtr(msetH);
		if (msetP->defvarN) {
			defsP = (struct defvar FAR *) GetPtr(msetP->defvarH);
			for (dii=0; dii<msetP->defvarN; dii++) {
				/* extract next name, check if already defined */	
				strcpyf((char FAR *)defnm,defsP[dii].name); 	
				retf = find_def_sym(wkSetH,defnm,&fSetH,&fIndex);
				if (retf) {
				
					/* clean up before error exit */
					
					ReleasePtr(msetP->defvarH);
					KillPtr(defsP);
					ReleasePtr(msetH);
					KillPtr(msetP);
					ReleasePtr(wkSetP->mergeH);
					KillPtr(tP);
					
					sprintf(msg,"Duplicate symbol: %s",defnm);
					cerror(SPECIFICERR,msg);
				} /* retf if */
			} /* for */
			ReleasePtr(msetP->defvarH);
		} /* defvarN if */
		ReleasePtr(msetH); /* release set being merged */
		
		/* add set to table */
		
		tP[wkSetP->mergeN++] = msetH;
	} /* already if */
	ReleasePtr(wkSetP->mergeH); /* release merge table */
	
	if (already)
		return(FALSE); /* exit if not a new merge */
	
	/* recursively add sets merged into new set */
			
	msetP = (struct defset FAR *)GetPtr(msetH);	
	mergeN = msetP->mergeN;
	ReleasePtr(msetH); /* release define set */		
	if (mergeN) {
		for(tii=0; tii<mergeN; tii++) {
			msetP = (struct defset FAR *)GetPtr(msetH);
			tP = (long FAR *)GetPtr(msetP->mergeH);
			nextMergeH = tP[tii];
			ReleasePtr(msetP->mergeH); /* release table */
			ReleasePtr(msetH); /* release define set */
			merge_defset(nextMergeH);
		} /* for */
	} /* mergeN if */
	
	return(TRUE); /* merged a new set */
	
} /* merge_defset

/* ******************************************************************* */

static global_defset_name(cret) /* return global define set name */
char *cret; /* buffer for global set name */

{	char ws[40];

	/* use csourcen to identify which file defines are in */
	sprintf(ws,"global %d",(int)csourcen);
	strcpy(cret,ws); /* return name */
	
} /* global_defset_name */

/* ******************************************************************* */

static user_defset_name(cret) /* return user define set name */
char *cret; /* buffer for user set name */

{	char ws[40];

	/* use csourcen to identify which file defines are in */
	sprintf(ws,"user %d",(int)csourcen);
	strcpy(cret,ws); /* return name */
	
} /* user_defset_name */

/* ******************************************************************* */

Memh find_defset(setname) /* search for defined variable set */
char *setname; /* name of set to find */

{	Memh setH; /* handle on current set */
	Memh nextH; /* handle on next set */
	struct defset FAR *setP; /* pointer to current define set */
	
	setH = firstSetH; /* start with first define set */
	do {
		setP = (struct defset FAR *)GetPtr(setH);
		nextH = setP->nextSet; /* get handle on next set */
		ReleasePtr(setH);
		if (strcmpf((char FAR *)setname,setP->name) == 0) 
			return(setH); /* found a match */
		setH = nextH; /* advance to next set */
	} while (setH); /* loop thru set chain */
	return(HNULL); /* didn't find set */

} /* find_defset */

/* ******************************************************************* */


/* ******************************************************************* */
/*
 * Array definition, execution, and pass-by-address
 * 
 * The handling of multidimensional arrays is somewhat complex. The statement
 * "define f: M(10, 1960:1980)" defines a floating-point array whose first
 * dimension goes from 1 thru 10 and the second goes from 1960 thru 1980.
 *
 * This definition information is stored in the handle "descH" as a a
 * "struct array_desc" followed by the required number of "struct dim_desc"
 *
 * array_desc
 *     dtype       always 1 for array descriptor 
 *     ltype       int/float/marker type
 *     ndim        number of dimensions
 *     size        size of int/float/marker
 *     addr        base address of array relative to local/global stack
 *                 at execution time the long indicated by addr contains
 *                 the index of the array description in "descH"
 *                 actual array data follows at addr+ARRAYHDR
 *                 data is stored in the order M(1,1960), M(1,1961), .. M(2,1960)..
 *     length      number of elements in the array
 *
 * dim_desc
 *     lower       lower bound of this dimension
 *     length      length (number elements) of this dimension
 *     multiplier  index multiplier for this dimension
 * 
 * 
 * This makes it possible to refer to an array simply by base address, and use
 * the pointer information stored there to find the description, which is
 * used for indexing and bounds checking.  Upon entry to a unit, we run thru
 * the descriptors and store pointers in the base address locations.
 * 
 * Pass by address of arrays requires that the receiving local array be defined
 * by "L(*, *)" which indicates that it takes on the description of the
 * passed-in array.  The description for L has dimensionality 2, but the
 * lower bounds and lengths for each dimension are zero. After checking that
 * both M and L are of the same type the pointer at M's base address is
 * stored into L's (local) base address.
 * 
 */

/* ******************************************************************* */

int define_seg() { return(0); } /* tgraphmac */


/* ******************************************************************* */

long getindex(term) /* determine an integer array length */
int *term; /* returned - terminating character */

{	struct expra wkexa; /* scratch analyzer params */

	wkexa = defexp;
	wkexa.tcolon = TRUE; /* allow colon terminator */
	wkexa.tparen = TRUE; /* allow right paren terminator */
	wkexa.rtype = TINT; /* require integer expression */
	wkexa.nogen = TRUE; /* don't generate p-code */
	compile(&wkexa); /* evaluate index expression */
	if (!wkexa.isconst) 
		cerror(SPECIFICERR,"Array dimensions must be constants.");
	if (term) *term = wkexa.lastchar; /* return terminator */
	return(wkexa.iconst); /* return integer value */

} /* getindex */

/* ******************************************************************* */

double getliteral(term)
int *term; /* returned - terminating character */

{	struct expra wkexa; /* scratch analyzer params */

	wkexa = defexp;
	wkexa.rtype = TFLOAT; /* require floating expression */
	wkexa.nogen = TRUE; /* dont generate p-code */
	compile(&wkexa); /* evaluate expression */
	if (!wkexa.isconst) 
		cerror(SPECIFICERR,"Literal must not depend on a variable.");
	if (term) *term = wkexa.lastchar; /* return terminator */
	return(wkexa.fconst); /* return integer value */

} /* getliteral */


/* ******************************************************************* */
