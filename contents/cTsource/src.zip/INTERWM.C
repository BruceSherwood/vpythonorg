
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#ifdef LINUX
#define _USE_BSD
#include <sys/types.h>
#include <sys/resource.h>
#include <sys/wait.h>
#endif

#ifdef SOLARIS
#define _USE_BSD
#include <sys/types.h>
#include <sys/resource.h>
#include <sys/wait.h>
#endif

#include "baseenv.h"

#ifdef hp700
#define _BSD
#include "wait.h"
#endif

#ifdef SOLARIS
#include "wait.h"
#endif


#include <stdio.h>

#ifdef ANDREW
/* #include <sys/time.h> */
#ifndef sys_typesh
#include <sys/types.h>
#define sys_typesh
#endif
#ifndef SYSV
#include "wait.h"
#endif
#include <sys/errno.h>
#include "file.h"
#endif /* ANDREW */

#include "tutor.h"
#include "editor.h"
#include "tfiledef.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "eglobals.h"

#ifdef DOSPC
#include "dos.h"
#include "tgraphpc.h"
#endif

#ifdef ctproto    
extern int EqFloat(double v1,double v2);
extern long quickCount(void);    
extern long TUTORinq_msec_clock(void);
extern int TUTORfile_region(FileRef FAR *fRef,long regionID);
extern char *rindex_z(char *str,int object);
extern int AppendSlash(char *str);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  TUTORclose(int  findx);
long  TUTORwrite(char  FAR *ptr,int  pSize,long  count,int  findx);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
long  TUTORget_hsize(unsigned int  mm);
int  assoc_name(struct  _fref FAR *fn,struct  _fref FAR *bfilen,char  *extnNew);
long  TUTORabs_save_region(int  x1,int  y1,int  x2,int  y2);
int  TUTORfree_region(long  id);
int  TUTORabs_restore_region(long  id,int  x1,int  y1);
int  TUTORpost_event(struct  tutorevent *event);
extern int StartPicture(int type,int fileid,TRect FAR *pRect,int dpi);
extern int FinishPicture(void);
char *TUTORgetenv(char *ev);
int  TUTORbad_binary(struct  _fref FAR *filen);
int  setexectitle(char  *fname);
int  ReMsg(void);
int  TMessage(char FAR *s);
int  TUTORrescale_message(void);
int  TUTORshowt(double  value,int  nBefore,int  nAfter,int  showperiod,char  *s);
int  errprintf(void);
int  InsureUnit(int  unitn);
int  system2(char  *shellcmd,int  waitflag);
extern double fabs(double x);
int  TUTORset_view(struct  tutorview FAR *vp);
int  TUTORflush(void);
int  TUTORdraw_text(unsigned char  FAR *buf,int  count);
extern int strlen(char *str);
int  TUTORabs_move_to(int  x,int  y);
int  TUTORinq_abs_string_width(unsigned char  FAR *s,int  lth,int  *dx);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
int  TUTORinset_rect(struct  _trect FAR *rr,int  xx,int  yy);
int  TUTORset_rect(struct  _trect *r,int  left,int  top,int  right,int  bottom);
int  TUTORset_comb_rule(int  rule);
int  TUTORset_textfont(int  jj);
int  TUTORinq_abs_screen_size(int  *x,int  *y,int  *dx,int  *dy);
int  TUTORunset_clip_rectangle(void);
struct  tutorview FAR *TUTORinq_view(void);
extern char *strncpy(char *aa, char *bb, int nn);
extern char *strcpy(char *aa, char *bb);
int  TUTORdump(char  *s);
char  FAR *GetPtr(unsigned int  mm);
int  ReleasePtr(unsigned int  mm);
int  TUTORtrace(char  *s);
extern char *TUTORget_user(void);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

extern char *machinename();
extern char *getenv();
extern char *FullName();
extern struct tutorview FAR *TUTORinq_view();
extern long TUTORget_hsize();
extern char *rindex_z();
extern char *TUTORget_user();

#ifndef IBMPC
/* magic string which may be edited (in binary file) to point to ct.env file */
static char *binDirMagic = 
"\001binDirMagic23456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"; 
extern long getpid();
#endif

#ifdef X11
extern char *getlogin();
extern int pd_barheight;
#endif

#ifdef DOSPC
extern int pd_barheight;
extern int wmg_top; /* topmost window number */
#endif


extern char *cTCmdLineP; /* pointer to command line + arguments */


/* ******************************************************************* */

TUTORbad_binary(filen)
FileRef FAR *filen;
    {
    TUTORdump("binary not valid"); /* no recovery attempt */
    }

/* ******************************************************************* */

#ifdef ANDREW
char ProgramName[16];
#endif

setexectitle(fname) /* set wm program title for Andrew */
char *fname; /* file name to use as title */

{   int fie,fib,wi; /* indexs in file, window names */
    char wname[16]; /* window name */

    strcpy(wname,"ct"); /* default name */
#ifdef ANDREW
    if (nosourcelayout) {
        fie = strlen(fname);
        if ((fie > 2) && (fname[fie-2] == '.'))
            fie -= 2; /* skip to before ".t" extension */
        fib = fie;
        while ((fib > 0) && (fname[fib-1] != '/'))
            fib--; /* back up to start of name */
        wi = 0; /* initialize index in window name */
        while ((wi < 15) && (fib < fie))
            wname[wi++] = fname[fib++];
        wname[wi] = '\0';
    } /* EditWn if */
    strcpy(ProgramName,wname);
#endif

} /* setexectitle */

TUTORrescale_message() /* return message type flag to RescaleText */
/* returns are 0: no message, 1: no font message (window is max), 2: bigger window */
    {
    return(2); /* message always asks for bigger window */
    }


/*************************************************************************/

#ifdef X11

char *TUTORget_user()

{
	return(getlogin());

} /* TUTORget_user */

#endif

#ifdef WINPC

char *TUTORget_user()

{   char *usrP;

    if (usrP = TUTORgetenv("USER"))
	return(usrP);

    return("Windows");

} /* TUTORget_user */

#endif

/*************************************************************************/

#ifndef IBMPC
static char FAR *local_envP = FARNULL;
static char binDir[CTPATHLEN+2]; /* path to cT */
static char envFile[CTPATHLEN+2]; /* full path to file */
#endif

char *TUTORgetenv(env)
char *env;
    
{	char *penv; /* pointer to environment var string */
	char *cP; /* working pointer */
	char *retP; /* returned string */
        int targetLen; /* length of target string */
	int relHereF; /* TRUE if ./ path */
	int relUpF; /* TRUE if ../ path */
	int sL; /* length of string */

	/* check for global environment variable */
	
	penv = getenv(env);
	if (penv)
		return(penv); /* if environment variable set, use it */

#ifdef IBMPC
	return(NEARNULL); /* nothing else to try on PC */
#else
	retP = NULL;
	
	/* no global environment variable, try environment file */
	
	if (!local_envP) {
		long fileSize; /* size of environment file */
		int fileRet; /* file operation return value */
		FILE *envFp; 
		struct stat statB; /* file status block */
		
		if (*binDirMagic != 1) {
			if (strncmp(binDirMagic,"../",3) == 0) { /* rel path */
				FindBinDir(cTCmdLineP,binDir);
				AppendSlash(binDir);
				binDir[strlen(binDir)-1] = 0; /* remove trailing slash */
				if (cP = rindex_z(binDir,'/'))
					*(cP+1) = 0; /* remove last path component */
				strcat(binDir,(binDirMagic+3));
			} else
				strcpy(binDir,binDirMagic); /* absolute path planted */
		} else  {
			FindBinDir(cTCmdLineP,binDir);
		}
		AppendSlash(binDir);
		
		/* attempt to read environment file */
		
		strcpy(envFile,binDir);
		strcat(envFile,"ct.env"); /* append file name */
		envFp = fopen(envFile,"r");
		if (!envFp) {

                    /* if no environment file, return cT directory for pieces of cT */

		    if ((strcmp("CT_FONTS",env) == 0) ||
			(strcmp("CT_UTIL",env) == 0) ||
			(strcmp("CT_COMMON",env) == 0)) {
			return(binDir);
		    }
		    return(NULL); /* don't know what to do */
		}
		fileRet = stat(envFile,&statB);
		if (fileRet == 0) {
			fileSize = statB.st_size;
			if (fileSize > 0) {
			
				/* read file contents */
				
				local_envP = (char *)malloc(fileSize+2);
				fread(local_envP,1,fileSize,envFp);
				
				/* convert newlines to 0s - '\377' terminates file */
				
				*(local_envP+fileSize) = '\377'; /* insure terminated */
				cP = local_envP;
				while (*cP != '\377') {
					if (*cP == NEWLINE)
						*cP = '\0';
					cP++;
				} /* while */
			}
		} /* fileRet if */
		fclose(envFp);
		if (!local_envP)
			local_envP = "\0\377"; /* point to empty string */
	}
		
	/* search for environment variable in file contents */
	
	penv = local_envP; /* point in environment file contents */
	targetLen = strlen(env);
	while (*penv != '\377') {
		cP = penv;
		while ((*cP == ' ') || (*cP == '\t')) cP++; /* skip white */
		if (strncmp(cP,env,targetLen) == 0) {
			cP += targetLen; /* advance past keyword */
			while ((*cP == ' ') || (*cP == '\t')) cP++; /* skip white */
			retP = cP; /* return pointer to string */
			break; /* exit while */
		}
		while (*penv && (*penv != '\377'))
			penv++; /* advance to next line */
		if (!*penv) penv++; /* advance past string terminator */
	} /* while */
	
	/* make relative path relative to binDir */
	
	if (retP) { 
	    if (relUpF = (strncmp(retP,"../",3) == 0))
			retP += 3;
		else if (relHereF = (strncmp(retP,"./",2) == 0))
			retP += 2;
		if (relUpF || relHereF) {
			sL = strlen(binDir);
			if ((sL+strlen(retP)) > CTPATHLEN)
				return(NULL); /* can't build string */
			strcpy(envFile,binDir); /* start with path to directory */
			if (relUpF && (sL > 2)) {
				*(envFile+sL-1) = 0; /* remove trailing slash */
				cP = rindex_z(envFile,'/');
				if (cP)
					*(cP+1) = 0; /* remove last component of path */
			}
			strcat(envFile,retP); /* add rest of path */
			retP = envFile; /* point to new string */
		} /* rel path if */
	}
	return(retP);
#endif /* PC else */
	
} /* TUTORgetenv */

/* ******************************************************************* */

int AppendSlash(str) /* append (back)slash to string if not present */
char *str;

{	int len;
	char slashS[2];

#ifdef IBMPC
	slashS[0] = '\\';
#else
	slashS[0] = '/';
#endif
	slashS[1] = 0;
	len = strlen(str);
	if (len && str[len-1] != slashS[0])
		strcat(str,slashS);
	return(0);
	
} /* AppendSlash */

/*************************************************************************/

TUTORshowt(value, nBefore, nAfter,showperiod, s)
double value;
int nBefore, nAfter, showperiod;
char *s;
     {
    char *p;
    int n;

#ifdef ibm032
/* The IBM RT shows 0 for "showt  val, nn, 0" if
    0.5 <= fabs(val) < 1.0 (but should show 1 or -1) */

    if(nAfter == 0 && 0.5 <= fabs(value) && fabs(value) < 1.0)
        value = (value > 0.0) ? 1.0 : -1.0;
#endif /* ibm032 */

    if ((fabs(value) > (10.0E40)) || (fabs(value) < (1.0E-40))) {
        sprintf(s, "%.*G", nBefore+nAfter+showperiod,value);
    } else sprintf(s, "%*.*f", nBefore+nAfter+showperiod, nAfter, value);

    /* unix sprintf does correct job except for 0 not becoming 0.00 */
    if (value != 0.0)
        return(0);

    p = s;
    for (n = 1; n < nBefore; n++) *(p++) = ' ';
    *(p++) = '0';
    if (nAfter != 0) 
        {
        *(p++) = '.';
        for (n = 1; n <= nAfter; n++) *(p++) = '0';
        }
    *p = '\0';

    return(0);
    }

/* ******************************************************************* */

errprintf() /* dummy routine called by wmclient? */

{ 
	return(0);
} /* errprintf */

/* ******************************************************************* */

#ifdef NOSUCH

printdoc(vp)    /* print source document */
TextVDat FAR *vp;

{   FileRef fRef;
    char cs[2*CTPATHLEN+32]; /* print command string */
    char *penv; /* pointer to print command name */
    int pid;    /* current process id */

#ifndef EXECUTE
    penv = getenv("CT_PRINT");
    if (penv == NULL) penv = "ezprint";
    pid = getpid();
    sprintf(fRef.path,"/tmp/print.%d.t",pid);
    fRef.nameInd = 5;
    writedoc(vp->textd,&fRef,0);
    sprintf(cs,"%s %s",penv,fRef.path);
    system2(cs,TRUE);
    TUTORdelete_file(&fRef); /* remove the tmp file */
#endif

} /* printdoc */

#endif

/* ******************************************************************* */

InsureUnit(unitn) /* insure specified unit is in memory, set code pointers */
int unitn; /* unit number */

{   
    if (pcodeh) ReleasePtr(pcodeh); /* release previous, if any */
    pcodeh = unittab[unitn].pcodeAlphaH; /* handle on pcodes */
    /* get pointer on pcodes, prevent movement */
    pcodep = (unsigned char FAR *) GetPtr(pcodeh); 
    /* NOTE: pcodeh is left locked.  Someone else has to ReleasePtr(pcodeh) */   
    return(0);

} /* InsureUnit */

/* ******************************************************************* */

#ifdef ANDREW
#define UNIX_EXEC
#endif

#ifdef X11
#define UNIX_EXEC
#ifdef SOLARIS
#define SVID89F
#endif
#endif

#ifdef UNIX_EXEC

int system2(shellcmd,waitflag)
char *shellcmd;
int waitflag;

{
#ifdef SVID89F
    int status;
#else
    union wait status;
#endif
    int pid;
    int fd; /* index of current file descriptor */
    int numfds; /* number of file descriptors */

    wait3(&status,WNOHANG,0L); /* wait on previous processes */
    pid = vfork();
    if (pid == 0) {
#ifdef hp700
	numfds = 32;
#else
        numfds = getdtablesize();   /* number file descriptors */
#endif
        for (fd = 3; fd < numfds; fd++) 
            close(fd); /* close all but stdin/out/err */
        execlp("/bin/sh","sh", "-c",shellcmd,(char *)0);
        _exit(101);
    }
    if (waitflag == 0)
        return 0;
    while (wait(&status) != pid);
    return(0);

} /* system2 */

/* ------------------------------------------------------------------- */

#endif /* UNIX_EXEC */

/* ------------------------------------------------------------------- */

#ifdef X11

static int start_type; /* menu/command flag */
static int start_file_id; /* index of file */

StartPicture(type,fileid,rect,dpi) 
int type; /* 0 = from menu, create picture file */
          /* 1 = from command, use file given */
int fileid; /* file id number */
TRect FAR *rect;
int dpi;

{   struct tutorevent rdw;

    if (exS.pictF) 
    	return(FALSE); /* exit if already building picture */

    if (type == 0) {

    	/* issue redraw event for executor window */

    	TUTORzero((char FAR *)&rdw,(long)sizeof(struct tutorevent));
    	rdw.window = ExecWn; /* set up event fields */
    	rdw.type = EVENT_REDRAW;
    	rdw.x = windowsP[ExecWn].wxsize;
    	rdw.y = windowsP[ExecWn].wysize-pd_barheight;
    	rdw.pressed = FALSE;
    	TUTORpost_event(&rdw);
    }
    
    /* start building picture */

    exS.pictF = 2; /* building picture */
    start_type = type; /* save type */
    start_file_id = fileid;

    return(TRUE);

} /* StartPicture */

/* ------------------------------------------------------------------- */

FinishPicture() 

{   int x1,y1,x2,y2;
    long regionID; /* id (Memh) of saved region */
    FileRef PPMf; /* PPM data file */
    int PPMid; /* index of data file */
    struct tutorfile FAR *fptr; /* pointer to file info */
    int si; /* length of name */
    char FAR *cp; /* pointer in file name */
    char wfname[FILEL]; /* file name */
    char extn[8]; /* extension */

    /* exit if not building picture, or haven't really started */

    if ((!exS.pictF) || (exS.pictF == 2)) {
    	exS.pictF = 0;
    	return(0);
    } /* pictF if */

    exS.pictF = 0; /* in case of error, we are done */

    if (start_type == 0) {

	/* build file name for *.bmp file */

	PPMf = sourcetable[0].fRef; /* copy file ref */
	cp = &PPMf.path[PPMf.nameInd];
        strcpyf((char FAR *)wfname,cp);
	si = strlen(wfname)-1;
        while (si >= 0) {
	    if (wfname[si] == '.')
            	wfname[si] = 0; /* truncate name at period */
	    si--;
        } /* while */
	wfname[4] = 0; /* truncate name, no more than 4 chars */
	if (pictur_id > 999) pictur_id = 1;
	sprintf(extn,"%d.ppm",pictur_id);
        strcat(wfname,extn);
        strcpyf(cp,(char FAR *)wfname); /* replace name */
    	pictur_id++;

	/* open *.bmp file */

	PPMid = TUTORopen((FileRef FAR *)&PPMf,FALSE,TRUE,FALSE);
    } else {
	PPMid = start_file_id; /* pick up file id */
	fptr = PPMid+(struct tutorfile FAR *)GetPtr(filesopen);
	PPMf = fptr->fRef;
    	ReleasePtr(filesopen);
    }
    if (!PPMid) return(0); /* didn't get file */
    TUTORclose(PPMid);

    /* copy screen bitmap for region */

    x1 = exS.OffsetX+(int)lclocx(exS.RegionXmin)-1;
    y1 = exS.OffsetY+(int)lclocy(exS.RegionYmin)-1;
    x2 = exS.OffsetX+(int)lclocx(exS.RegionXmax)+1;
    y2 = exS.OffsetY+(int)lclocy(exS.RegionYmax)+1;
    if (x1 < 0) x1 = 0;
    if (x2 >= windowsP[ExecWn].wxsize) x2 = windowsP[ExecWn].wxsize-1;
    if (y1 < 0) y1 = 0;
    if (y2 >= windowsP[ExecWn].wysize) y2 = windowsP[ExecWn].wysize-1;
   
    regionID = TUTORabs_save_region(x1,y1,x2,y2);
    if (!regionID)
	return(FALSE); /* didn't work */

    si = TUTORfile_region((FileRef FAR *)&PPMf,regionID);
	TUTORfree_region(regionID);
    return(si);
	
} /* FinishPicture */

#endif

/* ------------------------------------------------------------------- */

#ifdef WINPC

static int start_type; /* menu/command flag */
static int start_file_id; /* index of file */

StartPicture(type,fileid) 
int type; /* 0 = from menu, create picture file */
          /* 1 = from command, use file given */
int fileid; /* file id number */

{   struct tutorevent rdw;

    if (exS.pictF) 
    	return(FALSE); /* exit if already building picture */

    if (type == 0) {

    	/* issue redraw event for executor window */

    	TUTORzero((char FAR *)&rdw,(long)sizeof(struct tutorevent));
    	rdw.window = ExecWn; /* set up event fields */
    	rdw.type = EVENT_REDRAW;
    	rdw.x = windowsP[ExecWn].wxsize;
    	rdw.y = windowsP[ExecWn].wysize;
    	rdw.pressed = FALSE;
    	TUTORpost_event(&rdw);
    }
    
    /* start building picture */

    exS.pictF = 2; /* building picture */
    start_type = type; /* save type */
    start_file_id = fileid;

    return(TRUE);

} /* StartPicture */

/* ------------------------------------------------------------------- */

FinishPicture() 

{   int x1,y1,x2,y2;
    long regionID; /* id (Memh) of saved region */
    FileRef BMPf; /* BMP data file */
    int BMPid; /* index of data file */
    struct tutorfile FAR *fptr; /* pointer to file info */
    int si; /* length of name */
    char FAR *cp; /* pointer in file name */
    char wfname[FILEL]; /* file name */
    char extn[8]; /* extension */

    /* exit if not building picture, or haven't really started */

    if ((!exS.pictF) || (exS.pictF == 2)) {
    	exS.pictF = 0;
    	return(0);
    } /* pictF if */

    exS.pictF = 0; /* in case of error, we are done */

    if (start_type == 0) {

	/* build file name for *.bmp file */

	BMPf = sourcetable[0].fRef; /* copy file ref */
	cp = &BMPf.path[BMPf.nameInd];
        strcpyf((char FAR *)wfname,cp);
	si = strlen(wfname)-1;
        while (si >= 0) {
	    if (wfname[si] == '.')
            	wfname[si] = 0; /* truncate name at period */
	    si--;
        } /* while */
	wfname[4] = 0; /* truncate name, no more than 4 chars */
	if (pictur_id > 999) pictur_id = 1;
	sprintf(extn,"%d.bmp",pictur_id);
        strcat(wfname,extn);
        strcpyf(cp,(char FAR *)wfname); /* replace name */
    	pictur_id++;

	/* open *.bmp file */

	BMPid = TUTORopen((FileRef FAR *)&BMPf,FALSE,TRUE,FALSE);
    } else {
	BMPid = start_file_id; /* pick up file id */
	fptr = BMPid+(struct tutorfile FAR *)GetPtr(filesopen);
	BMPf = fptr->fRef;
    	ReleasePtr(filesopen);
    }
    if (!BMPid) return(0); /* didn't get file */
    TUTORclose(BMPid);

    /* copy screen bitmap for region */

    x1 = exS.OffsetX+(int)lclocx(exS.RegionXmin)-1;
    y1 = exS.OffsetY+(int)lclocy(exS.RegionYmin)-1;
    x2 = exS.OffsetX+(int)lclocx(exS.RegionXmax)+1;
    y2 = exS.OffsetY+(int)lclocy(exS.RegionYmax)+1;
    if (x1 < 0) x1 = 0;
    if (x2 >= windowsP[ExecWn].wxsize) x2 = windowsP[ExecWn].wxsize-1;
    if (y1 < 0) y1 = 0;
    if (y2 >= windowsP[ExecWn].wysize) y2 = windowsP[ExecWn].wysize-1;
   
    regionID = TUTORabs_save_region(x1,y1,x2,y2);
    if (!regionID)
	return(FALSE); /* didn't work */

    si = TUTORfile_region((FileRef FAR *)&BMPf,regionID);
    return(si);
	
} /* FinishPicture */

#endif

/* ------------------------------------------------------------------- */

#ifdef DOSPC

struct pcxhdr {
    char manuf; /* ? manufacturors code? = 0x0a */
    char tcode; /* version code 5 = version 3.0+palette */
    char encode; /* compression method = 1 = rle */
    char bpix; /* bits/pixel = 1 */
    int x1; /* coordinates of upper left of image */
    int y1;
    int x2; /* coordinates of lower right of image */
    int y2;
    int hres; /* card horizontal resolution */
    int vres; /* card vertical resolution */
    char palette[48]; /* color palette */
    char unused1;
    char nplanes; /* number planes in image */
    int scanl; /* bytes per line in image */
    char unused2[60]; /* fill to 128 bytes */
}; /* pcxhdr */

struct pcsvimg {
    int rows; /* number pixel rows */
    int pixrow; /* number pixels/row */
    int bytrow; /* number bytes/row */
    char lastm; /* mask for last pixel in row */
    char nplanes; /* number planes */
}; /* pcsvimg */

static int start_type; /* menu/command flag */
static int start_file_id; /* index of file */

/* ------------------------------------------------------------------- */

StartPicture(type,fileid)
int type; /* 0 = from menu, 1 = from command */
int fileid; /* file id if from command */

{   struct tutorevent rdw; /* redraw event for executor */

    if (exS.pictF) 
    return(FALSE); /* exit if already building picture */

    if (type == 0) {

    /* issue redraw event for executor window */

    TUTORzero((char FAR *)&rdw,(long)sizeof(struct tutorevent));
    rdw.window = ExecWn; /* set up event fields */
    rdw.type = EVENT_REDRAW;
    rdw.x = windowsP[ExecWn].wxsize;
    rdw.y = windowsP[ExecWn].wysize-pd_barheight;
    rdw.pressed = FALSE;
    TUTORpost_event(&rdw);
    }
    
    /* start building picture */

    exS.pictF = 2; /* building picture */
    start_type = type; /* save type */
    start_file_id = fileid;

    return(TRUE);

} /* StartPicture */

/* ------------------------------------------------------------------- */

FinishPicture()

{   int x1,y1,x2,y2;
    int pixels_row; /* number pixels/row */
    long regionID;
    Memh regionH; /* handle on saved region header */
    struct saved_region FAR *regionP; /* pointer to saved region header */
    Memh sectH; /* handle on section of region */
    unsigned char FAR *sectP; /* pointer to section */
    long sectL; /* length of section */
    int si; /* index to section */
    int rowi; /* index in rows */
    int rii; /* index within row */
    int imd; /* current byte of image data */
    struct pcxhdr phdr; /* PCX file header */
    FileRef pcxf; /* PCX data file */
    int pcxid; /* index of PCX data file */
    struct pcsvimg FAR *imghdr; /* pointer to image section header */
    unsigned char FAR *imgP; /* pointer to image data */
    unsigned char FAR *imgP_by_plane; /* pointer to image data */
    int repmax,repc; /* rle compression variables */
    char FAR *cp;
    struct tutorfile FAR *fptr; /* pointer in file table */
    union REGS inr; /* input  registers for int86 */
    union REGS outr; /* output registers for int86 */
    struct SREGS segr; /* segment registers for int86x */
    char wfname[14];
    char extn[8];

    /* exit if not building picture, or haven't really started */

    if ((!exS.pictF) || (exS.pictF == 2)) {
    	exS.pictF = 0;
    	return(0);
    } /* pictF if */

    exS.pictF = 0; /* in case of error, we are done */

    if (start_type == 0) {

    /* build file name for *.pcx file */

    if (pictur_id == 0) {
        assoc_name(&sourcetable[0].fRef,(FileRef FAR *) &pcxf, ".pcx");
    } else {
        pcxf = sourcetable[0].fRef; /* copy file ref */
        cp = &pcxf.path[pcxf.nameInd];
        strcpyf((char FAR *)wfname,cp);
        si = strlen(wfname)-1;
        while (si >= 0) {
        if (wfname[si] == '.')
            wfname[si] = 0; /* truncate name at period */
        si--;
        } /* while */
        wfname[6] = 0; /* truncate name */
        if (pictur_id > 99) pictur_id = 1;
        sprintf(extn,"%d.pcx",pictur_id);
        strcat(wfname,extn);
        strcpyf(cp,(char FAR *)wfname); /* replace name */
    } /* pictur_id else */
    pictur_id++;

    /* open *.pcx file */

    pcxid = TUTORopen((FileRef FAR *)&pcxf,FALSE,TRUE,FALSE);
    } else {
    	pcxid = start_file_id; /* pick up file id */
    	fptr = pcxid+(struct tutorfile FAR *)GetPtr(filesopen);
    		pcxf = fptr->fRef;
    	ReleasePtr(filesopen);
    }
    if (!pcxid) return(0); /* didn't get file */

    /* copy screen bitmap for region */

    x1 = exS.OffsetX+(int)lclocx(exS.RegionXmin)-1;
    y1 = exS.OffsetY+(int)lclocy(exS.RegionYmin)-1;
    x2 = exS.OffsetX+(int)lclocx(exS.RegionXmax)+1;
    y2 = exS.OffsetY+(int)lclocy(exS.RegionYmax)+1;
    if (x1 < 0)
    x1 = 0;
    if (x2 >= windowsP[ExecWn].wxsize)
    x2 = windowsP[ExecWn].wxsize-1;
    if (y1 < 0)
    y1 = 0;
    if (y2 >= windowsP[ExecWn].wysize)
    y2 = windowsP[ExecWn].wysize-1;
    pixels_row = (x2-x1)+1;
    unclip();
    regionID = TUTORabs_save_region(x1,y1,x2,y2);
    setclip();
    if (!regionID) {
    TUTORclose(pcxid);
    return(0);
    }

    /* set up PCX file header */

    TUTORzero((char FAR *)&phdr,(long)sizeof(struct pcxhdr));
    phdr.manuf = 0x0a; /* magic ? */
    phdr.tcode = 5; /* 5 = version 3.0 + palette */
    phdr.encode = 1; /* normal run-length encoding */
    phdr.bpix = 1; /* bits/pixel (in single plane) */
    phdr.x1 = 0;
    phdr.y1 = 0;
    phdr.x2 = x2-x1;
    phdr.y2 = y2-y1;
    phdr.hres = 0x78; /* horizontal resolution  magic ? */
    phdr.vres = 0x90; /* vertical resolution  magic ? */
    phdr.nplanes = 4;
    phdr.scanl = pixels_row >> 3; /* bytes/row (for one plane) */
    if (pixels_row & 7)
    phdr.scanl++; /* last byte is fractional */

    /* read RGB palette */

    phdr.tcode = 3; /* forget about palette */
    phdr.nplanes = 1; /* forget about planes */
#ifdef Nosuch
    segread(&segr);
    cp = (char FAR *)(phdr.palette);
    inr.h.ah = 0x10;    /* misc functions */
    inr.h.al = 0x17;   /* read DAC color registers */
    inr.x.bx = 0; /* first register */
    inr.x.cx = 16; /* number registers to read */
    inr.x.dx = FP_OFF(cp);
    segr.es = FP_SEG(cp);
    int86x(0x10,&inr,&outr,&segr);
    for (si=0; si<48; si++)
    phdr.palette[si] = phdr.palette[si]*4;
#endif
    TUTORwrite((char FAR *)&phdr,1,128L,pcxid); /* write header */

    regionH = regionID; /* id is actually handle */
    regionP = (struct saved_region FAR *)GetPtr(regionH);

    /* step thru saved chunks */

    for (si=0; si<SR_MAXP; si++) {
    sectH = regionP->ids[si];
    if (!sectH)
        break; /* no more chunks */
    sectP = (unsigned char FAR *)GetPtr(sectH);
    sectL = TUTORget_hsize(sectH); /* get size of handle */
    imghdr = (struct pcsvimg FAR *)sectP;
    imgP = sectP+sizeof(struct pcsvimg);

    /* loop thru rows, planes, bytes */

    for (rowi=0; rowi<imghdr->rows; rowi++) {
        rii = 1;
        while (rii<=imghdr->bytrow) {
        imd = *imgP;
        repc = 0; /* not repeated yet */
        if (rii == imghdr->bytrow) {
            imd &= imghdr->lastm;
        } else {
            repmax = (imghdr->bytrow-rii)-1;
            if (repmax > 16) repmax = 16;
            while ((imd == *(imgP+1)) && (repc < repmax)) {
            repc++; /* count number repetitions */
            imgP++; /* advance thru data */
            rii++; /* advance index in row */
            } /* while */
        } /* rii else */
        if (repc) {
            TUTORwrite_char(0xc1+repc,pcxid);
            TUTORwrite_char(imd,pcxid);
        } else if ((imd & 0xc0) != 0xc0) {
            TUTORwrite_char(imd,pcxid);
        } else {
            TUTORwrite_char(0xc1,pcxid);
            TUTORwrite_char(imd,pcxid);
        }
        imgP++;
        rii++;
        } /* rii for */
    } /* rowi for */
    ReleasePtr(sectH);
    } /* si for */

    ReleasePtr(regionH);
    TUTORfree_region(regionID);
    TUTORclose(pcxid);

    return(0);

} /* FinishPicture */

/* ------------------------------------------------------------------- */

#endif /* DOSPC */

/* ------------------------------------------------------------------- */

#ifndef CTEDIT 

#ifdef IBMPC

#define NAN_DEF 1   /* have defined indefinite */

int TstIndefinite(value) /* check if floating value indefinite */
double value;

{   unsigned short *vaddr; /* pointer to floating value, seen as 16-bit ints */
    unsigned short fexponent; /* exponent of floating value */
    
    vaddr = (unsigned short *)(&value);
    fexponent = *(vaddr+3); /* get exponent */
    if ((fexponent & 0x7ff0) == 0x7ff0) {
        if (EqFloat(value,Infinite))
            return(FALSE); /* not indefinite if infinite */
        else
            return(TRUE); /* indefinite value */
    } /* fexponent if */
    
    return(FALSE);

} /* TstIndefinite */

#endif /* IBMPC */

/* ------------------------------------------------------------------- */

#ifndef NAN_DEF /* fall back on default routine if no other definition */

int TstIndefinite(value) /* check for indefinite (NAN) value */
double value; /* floating value to check */

{   double ft1,ft2;

    ft1 = 0.0;
    /* produce a zero without letting compiler optimize anything */
    TUTORzero((char FAR *)(&ft2),(long)sizeof(double));
    ft1 = ft1/ft2; /* produce an indefinite (0/0) */
    if (EqFloat(value,ft1)) /* catch at least one common indefinite */
        return(TRUE);
    return(FALSE);  /* don't recognize as indefinite */
    
} /* TstIndefinite */

#endif

#endif /* CTEDIT */

/* ******************************************************************* */

#ifdef X11

Memh LoadTable(tableFile,tableSize) /* read up a copy of a cT data table */
char *tableFile; /* file name */
int *tableSize; /* size of table */

{   FileRef theFile; /* table file reference */
    int fii; /* index of file */
    long fsize; /* size of file */
    Memh blockH; /* handle on memory block */
    char FAR *blockP; /* pointer to mem block */

    if (tableSize)
		*tableSize = 0;

    TUTORcopy_fileref_dir((FileRef FAR *) &theFile,ctDirP);
    TUTORcopy_fileref_name((FileRef FAR *) &theFile,(char FAR *)tableFile);
    fii = TUTORopen((FileRef FAR *) &theFile,TRUE,FALSE,FALSE);
    if (fii < 0) {
        printf("Couldn't find: %s\n",theFile.path);
        return(0);
    }
    TUTORinq_file_info((FileRef FAR *) &theFile,NEARNULL,&fsize,NEARNULL,NEARNULL,NEARNULL);
    if (fsize <= 0) {
		TUTORclose(fii);
		return(0);
    }
    blockH = TUTORhandle("table",fsize,TRUE);
    if (!blockH) {
		TUTORclose(fii);
		return(0);
    }
    blockP = GetPtr(blockH);
    TUTORread(blockP,1,fsize,fii);
    ReleasePtr(blockH);
    TUTORclose(fii);

    if (tableSize)
	*tableSize = fsize;

    return(blockH);

} /* LoadTable */

#endif

/* ******************************************************************* */  

long quickCount()

{
	return(TUTORinq_msec_clock());
	
} /* quickCount */

/* ******************************************************************* */
