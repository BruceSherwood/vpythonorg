
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "baseenv.h"
#include "txt.h"
#include "compute.h"
#include "tutor.h"
#include "tglobals.h"
#include "ecglobal.h"

#ifdef ctproto
extern int mvar_clear_cache(void);
int  GetUnitName(int  unitn,unsigned char  *name);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  tdoc_getstyles(unsigned int  theD,long  pos,short  *styles);
unsigned int  mvar_new(int  ref);
int init_mvar_cache(void);
int  mvar_cache_ovr(void);
int  mvar_cache(unsigned int  docH);
int mvar_uncache(unsigned int Doch);
int  mvar_attach_doc(struct  markvar SHUGE *mvarP,unsigned int  docH,unsigned char  SHUGE *stackP);
int  mvar_attach_doc2(struct  markvar SHUGE *mvarP,unsigned int  docH,unsigned char  SHUGE *stackP,unsigned int  stackH);
int  TUTORclose_all_markers(unsigned int  doc);
int  mvar_detach_doc(struct  markvar SHUGE *mvarP,unsigned int  docH,unsigned char  SHUGE *stackP);
int  mvar_detach_doc2(struct  markvar SHUGE *mvarP,unsigned int  docH,unsigned char  SHUGE *stackP,unsigned int  stackH);
int  mvar_get_inf(unsigned int  docH,long  *len,long *users,long  *head);
int  mvar_ref_doc(unsigned int  docH);
int  mvar_unref_doc(unsigned int  docH);
int  mvar_temp_cleanup(void);
int  mvar_append(struct  markvar FAR *mx,struct  markvar FAR *my);
int  mvar_replace(struct  markvar FAR *mx,struct  markvar FAR *my);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
int  appenddoc(unsigned int  theDoc,char  FAR *sP,int  sLen);
int  tdoc_isvis(unsigned int  theD,long  pos);
int  tdoc_is_string(unsigned int  theD,long  pos,long  len);
int  GetSelect(unsigned int  theV,long  *pos,long  *len);
int  EncloseRange(unsigned int  doc,long  pl,long  len,unsigned int  style);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  TUTORdump(char  *s);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORclear_doc(unsigned int  doc);
int  TUTORclose_doc(unsigned int  doc);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  AtTStyle(unsigned int  pd,long  pos,short  *styles);
int  _TUTORget_styles_doc(struct  _ktd FAR *dp,long  pos,short  *curStyles);
int  TUTORinsert_string_doc(unsigned int  doc,long  pos,unsigned char  FAR *ss,long  sLen);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
int  TUTORtrace(char  *s);
int  TUTORstyle_doc(unsigned int  doc,long  pos,long  len,int  type,int  dat,int  canCombine,long  *extraPos);
int  TUTORinq_select_tview(unsigned int  theV,long  *pos,long  *len);
int  _TUTORload_buffer_doc(struct  _ktd FAR *dp,long  pos);
#endif /* ctproto */

extern Memh TUTORnew_doc();
extern long TUTORget_len_doc();


/* ******************************************************************* */

#define DCACHEMAX 350 /* must be at least 20 for -do- arguments */
static int dcachen = 0; /* number documents cached */
static Memh FAR *dcache = FARNULL; /* document cache */

Memh mvar_new(ref) /* assign new m-variable document */
/* retrieve doc from cache or create new doc */
int ref; /* TRUE if should add (temp) doc to reference chain */

{   Memh ndoc; /* handle on new document */

    if (dcachen) {
        ndoc = dcache[--dcachen];
        dcache[dcachen] = 0;
    } else
        ndoc = TUTORnew_doc(TRUE,TRUE);
    if (ref)
        mvar_ref_doc(ndoc); /* add to reference chain */
    return(ndoc); /* create new document */

} /* mvar_new */

/* ******************************************************************* */

int mvar_cache_ovr() /* check document cache (nearly) full */

{
    return(refnum > 4);

} /* mvar_cache_ovr */

/* ******************************************************************* */

init_mvar_cache() /* initialize marker document cache */

{
	if (!dcache) 
		dcache = (Memh FAR *)TUTORalloc((long)DCACHEMAX*sizeof(Memh),TRUE,"dcache");
		
} /* init_mvar_cache */

/* ******************************************************************* */

mvar_cache(docH) /* add document to m-var document cache */
Memh docH; /* handle on document */

{   DocP dP;    
		
    /* delete document if no room in cache */

    if (dcachen >= DCACHEMAX) {
        TUTORclose_doc(docH); /* dump document if can't cache */
        return(0);
    } /* dcachen if */
    
    dP = (DocP) GetPtr(docH);
    if (dP->styles) { /* document has styles */
        ReleasePtr(docH);
        TUTORclose_doc(docH); /* don't cache if styled */
        return(0);
    }
    ReleasePtr(docH);
    
    /* add document to m-variables document cache */

    TUTORclear_doc(docH); /* dump contents of document */
    dcache[dcachen++] = docH;
 
} /* mvar_cache */

/* ******************************************************************* */

mvar_uncache(docH) /* remove document from cache */
Memh docH;

{	int dii;

	if (!docH)
		return;
		
	for(dii = 0; dii < dcachen; dii++) {
		if (dcache[dii] = docH) {
			if (dii != (dcachen-1))
				dcache[dii] = dcache[dcachen-1]; /* copy last to this */
			dcachen--;
			dcache[dcachen] = 0;
		}
	} /* for */
	
} /* mvar_uncache */

/* ******************************************************************* */

mvar_clear_cache() /* empty document cache */

{	Memh docH;

	while (dcachen) {
		docH = dcache[0];
		TUTORclose_doc(docH);
	}
	
} /* mvar_clear_cache */

/* ******************************************************************* */

#ifndef CTEDIT
#include "eglobals.h"

mvar_attach_doc(mvarP,docH,stackP) /* attach m-variable to document */
struct markvar SHUGE *mvarP; /* address of marker variable */
Memh docH; /* handle on document */
unsigned char SHUGE *stackP; /* stack containing marker variable */
    {
    mvar_attach_doc2(mvarP,docH,stackP,exS.stackH); /* marker variable on execute stack */
    }
#endif

/* should replace mvar_attach_doc2 in tdoc.. */
mvar_attach_doc2(mvarP,docH,stackP,stackH) /* attach m-variable to document */
struct markvar SHUGE *mvarP; /* address of marker variable */
Memh docH; /* handle on document */
unsigned char SHUGE *stackP; /* stack containing marker variable */
Memh stackH; /* handle to stack of marker */

{   DocP dp; /* pointer to document */
    struct markvar SHUGE *nmp; /* pointer to next marker */
    long rloc; /* relative location of marker */
    unsigned char SHUGE *stackP2; /* pointer to another stack */

    rloc = (unsigned char SHUGE *)(mvarP)-stackP; /* rel address */

    /* add marker variable to document's chain */

    dp = (DocP)GetPtr(docH);
    dp->nUsers++; /* inc num markers refering to document */
    mvarP->doclen = dp->totLen; /* length of document */
    mvarP->attached = TRUE; /* is attached to document update chain */
    mvarP->prevm = -1;  /* put new at begin of chain */
    mvarP->prevstack = 0;
    mvarP->nextm = dp->headM;
    mvarP->nextstack = dp->nextHandle;
    dp->headM = rloc; /* relative address of mvar */
    dp->nextHandle = stackH;
    if (mvarP->nextm >= 0) {
        if (mvarP->nextstack == stackH) /* already have pointer to correct stack */
            nmp = (struct markvar SHUGE *)(stackP+mvarP->nextm);
        else
            { /* have to get marker in another stack */
            stackP2 = (unsigned char FAR *) GetPtr(mvarP->nextstack);
            nmp = (struct markvar SHUGE *) (stackP2+mvarP->nextm);
            }
        if (nmp->doc != docH) 
	    TUTORdump("tdoc 1");
        nmp->prevm = rloc; /* chain next to this */
        nmp->prevstack = stackH;
        if (mvarP->nextstack != stackH)
            {
            ReleasePtr(mvarP->nextstack);
            KillPtr(nmp);
            }
    }
    ReleasePtr(docH);
    KillPtr(dp);

} /* mvar_attach_doc2 */

/* ******************************************************************* */

TUTORclose_all_markers(doc) /* close all markers on a doc */
Memh doc;
    {
    struct markvar SHUGE *mp;
    int ii;
    DocP dp;
    Memh nextStack, stackH;
    long nextm;
    char SHUGE *stackP;
    
    dp = (DocP) GetPtr(doc);
    if (dp->nUsers)
        {
        stackH = dp->nextHandle;
        stackP = GetPtr(stackH);
        nextm = dp->headM;
  
        do
            {
            mp = (struct markvar SHUGE *) (stackP+nextm);
            mp->doc = 0;
            nextm = mp->nextm;
            mp->nextm = mp->prevm = -1;
            mp->attached = FALSE;
            if (nextm != -1 && mp->nextstack != stackH)
                {
                nextStack = mp->nextstack;
                ReleasePtr(stackH);
                KillPtr(stackP);
                stackH = nextStack;
                stackP = GetPtr(stackH);
                }
	    	dp->nUsers--;
            } while (nextm != -1);
        ReleasePtr(stackH);
        KillPtr(stackP);
        dp->nUsers = 0;
        dp->headM = -1;
        dp->nextHandle = 0;
        }
    ReleasePtr(doc);
    KillPtr(dp);
    
    }

/* ******************************************************************* */

#ifndef CTEDIT
mvar_detach_doc(mvarP,docH,stackP) /* detach m-variable from document */
struct markvar SHUGE *mvarP; /* address of marker variable */
Memh docH; /* handle on document */
unsigned char SHUGE *stackP; /* stack containing marker variable */
    {
    mvar_detach_doc2(mvarP,docH,stackP,exS.stackH);
    }
#endif

/* ******************************************************************* */

mvar_detach_doc2(mvarP,docH,stackP,stackH) /* detach m-variable from document */
struct markvar SHUGE *mvarP; /* address of marker variable */
Memh docH; /* handle on document */
unsigned char SHUGE *stackP; /* stack containing marker variable */
Memh stackH;    /* stack of marker variable */

{   DocP dp; /* pointer to document */
    struct markvar SHUGE *mp; /* pointer to next/previous marker variable */
    long nusers; /* document usage count */
    unsigned char SHUGE *stackP2;

    if (!mvarP->attached) 
        return(0); /* not attached, don't detach */

    dp = (DocP) GetPtr(docH);

    /* decouple this marker var from documents chain */

    if (mvarP->nextm >= 0) {
        if (mvarP->nextstack == stackH)
            mp = (struct markvar SHUGE *)(stackP+mvarP->nextm);
        else {
            stackP2 = (unsigned char SHUGE *) GetPtr(mvarP->nextstack);
            mp = (struct markvar SHUGE *)(stackP2+mvarP->nextm);
        }
        if (mp->doc != docH) 
	    TUTORdump("tdoc 2");
        mp->prevm = mvarP->prevm; /* chain next to previous */
        mp->prevstack = mvarP->prevstack;
        if (mvarP->nextstack != stackH) {
            ReleasePtr(mvarP->nextstack);
            KillPtr(mp);
        }
    }
    if (mvarP->prevm >= 0) {
        if (mvarP->prevstack == stackH)
            mp = (struct markvar SHUGE *)(stackP+mvarP->prevm);
        else {
            stackP2 = (unsigned char FAR *) GetPtr(mvarP->prevstack);
            mp = (struct markvar SHUGE *)(stackP2+mvarP->prevm);
        }
        if (mp->doc != docH) 
	    TUTORdump("tdoc 3");
        mp->nextm = mvarP->nextm; /* chain previous to next */
        mp->nextstack = mvarP->nextstack;
        if (mvarP->prevstack != stackH) {
            ReleasePtr(mvarP->prevstack);
            KillPtr(mp);
        }
    } else {
if (dp->headM != (long)((unsigned char SHUGE *)mvarP-stackP))
  TUTORdump("tdoc 4");
        dp->headM = mvarP->nextm;
        dp->nextHandle = mvarP->nextstack;
    }
    mvarP->nextm = mvarP->prevm = -1;
    mvarP->nextstack = mvarP->prevstack = 0;
    mvarP->doc = mvarP->attached = 0;

    /* decrement user count, add to reference chain for clean-up */

    nusers = --(dp->nUsers);
 
if ((nusers <= 0) && (dp->headM >= 0))
 TUTORdump("tdoc 5");
    ReleasePtr(docH);
    KillPtr(dp);
    if (nusers == 0) mvar_ref_doc(docH);

} /* mvar_detach_doc2 */

/* ******************************************************************* */

mvar_get_inf(docH,len,users,head) /* get m-variable info from document */
Memh docH;  /* handle on document */
long *len;  /* returned = total length */
long *users; /* returned = number m-vars referencing doc */
long *head; /* relative address of first m-var */

{   DocP docP;

    docP = (DocP)GetPtr(docH);
    if (len)
        *len = docP->totLen;
    if (users)
        *users = docP->nUsers;
    if (head)
        *head = docP->headM;
    ReleasePtr(docH);
    KillPtr(docP);

} /* mvar_get_inf */

/* ******************************************************************* */

mvar_ref_doc(docH) /* add doc to referenced chain for later clean-up */
Memh docH; /* handle on document */

{   DocP docP; /* this document */
    DocP nextp; /* next document in chain */

    docP = (DocP)GetPtr(docH);

    /* add to chain if not already in chain */

    if ((docP->nextd == 0) && (docP->prevd == 0) && (docH != refhead)) {
        refnum++; /* inc items in chain */
        docP->nextd = refhead; /* chain this to next */
        refhead = docH;
        if (docP->nextd) { 
            nextp = (DocP)GetPtr(docP->nextd);
            nextp->prevd = docH; /* chain next to this */
            ReleasePtr(docP->nextd);
            KillPtr(nextp);
        } /* nextd if */
    }
    ReleasePtr(docH);
    KillPtr(docP);
    
} /* mvar_ref_doc */

/* ******************************************************************* */

mvar_unref_doc(docH) /* remove doc from ref chain to prevent clean-up */
Memh docH; /* handle on document */

{   DocP docP; /* this document */
    Memh nexth; /* next document in chain */
    DocP nextp;
    Memh prevh; /* previous document in chain */
    DocP prevp;

    if (docH == 0) return(0); /* no document */
    docP = (DocP)GetPtr(docH);

    /* remove from chain if in chain */

    if (docP->nextd || docP->prevd || (docH == refhead)) {
        refnum--; /* dec number in chain */
        nexth = docP->nextd;
        prevh = docP->prevd;
        if (nexth) { /* chain next to previous */
            nextp = (DocP)GetPtr(nexth);
            nextp->prevd = prevh;
            ReleasePtr(nexth);
            KillPtr(nextp);
        }
        if (prevh) { /* chain previous to next */
            prevp = (DocP)GetPtr(prevh);
            prevp->nextd = nexth;
            ReleasePtr(prevh);
            KillPtr(prevp);
        } else { /* chain top to next */
            refhead = nexth;
        } /* else */
    } /* nextd if */
    docP->nextd = docP->prevd = 0; /* not in ref chain */
    ReleasePtr(docH);
    KillPtr(docP);
    
} /* mvar_unref_doc */

/* ******************************************************************* */

mvar_temp_cleanup() /* clean up m-variable temporary documents */

{   Memh nexth; /* handle on next document */
    DocP thisp; /* pointer to this document */
    Memh thish; /* handle on this document */
    long nusers; /* number mvars on this document */
    Memh epanel; /* next panel in view chain */

    if (refhead == 0) return(0); /* exit if no reference chain */
    nexth = refhead;
    refhead = 0; /* no reference chain */
    while (nexth) { /* loop thru reference chain */
        refnum--; /* dec number in chain */
        thish = nexth;
        thisp = (DocP)GetPtr(thish);
        nexth = thisp->nextd; /* link to next doc */
        thisp->prevd = 0; /* decouple from previous */
        thisp->nextd = 0; /* decouple from next */
        nusers = thisp->nUsers;
		epanel = thisp->editPanel;
        ReleasePtr(thish); 
        KillPtr(thisp);
        if ((nusers == 0) && (epanel == 0))
            mvar_cache(thish); /* cache this document */
    }; /* while */

} /* mvar_temp_cleanup */

/* ******************************************************************* */

mvar_append(mx,my)  /* append one marked string to another */
struct markvar SHUGE *mx; /* string to append to */
struct markvar SHUGE *my; /* string to append */
    
{   long extraPos;
    
    TUTORchange_doc_doc(mx->doc,mx->pos+mx->len,0L,mx->pos,mx->len,
                        my->doc,my->pos,my->len,&extraPos,TRUE);
    return(0);
}

/* ******************************************************************* */

mvar_replace(mx,my) /* replace one marked string with another */
struct markvar SHUGE *mx; /* string to replace */
struct markvar SHUGE *my; /* string to replace with */
    
{   long extraPos;
    
    TUTORchange_doc_doc(mx->doc,mx->pos,mx->len,mx->pos,mx->len,
                        my->doc,my->pos,my->len,&extraPos,TRUE);
    return(0);
}

/* ******************************************************************* */

InsertString(theD,pos,sP,sLen)
Memh theD;
register long pos;
char FAR *sP;
long sLen;
    
{
    TUTORinsert_string_doc(theD,pos,(unsigned char FAR *) sP,sLen);
}

/* ******************************************************************* */

appenddoc(theDoc,sP,sLen)
Memh theDoc;
char FAR *sP;
int sLen;
    {
    long extraDumm, dlen;
    
    dlen = TUTORget_len_doc(theDoc);
    TUTORinsert_string_doc(theDoc,dlen,(unsigned char FAR *) sP,(long) sLen);
    }

tdoc_isvis(theD,pos) /* check if document is visible up to pos */
Memh theD; /* tutor document */
long pos; /* position in doc */
/* returns TRUE if doc is visible up to (& including) pos */
    {
    short curStyles[NSTYLES];
    DocP dp;
    
    dp = (DocP) GetPtr(theD);
    _TUTORget_styles_doc(dp,pos,curStyles);
    ReleasePtr(theD);
    KillPtr(dp);
    
    return(!(curStyles[PARASTYLE] & VISMASK));
    }

tdoc_is_string(theD,pos,len) /* check if doc is simple in a range */
Memh theD;  /* document */
long pos, len;  /* where to check */
/* returns TRUE if all styles are DEFSTYLE in range && there are no special chars */
    {
    DocP dp;
    short curStyles[NSTYLES];
    int ii, pst;
    int unstyled;
    int nCheck;
    register unsigned char FAR *tp;
    long nextStyle;
    StyleDatP styleP;
    register Style1 SHUGE *s1p;

    unstyled = TRUE;
    dp = (DocP) GetPtr(theD);
    if (dp->styles)
        { /* check if region is unstyled */
        /* get styles at start of region */
        nextStyle = AtTStyle(dp->styles,pos,curStyles);
        for (ii=0; ii<NSTYLES && unstyled; ii++)
            {
            if (ii != PARASTYLE)
                if (curStyles[ii] != DEFSTYLE)
                    unstyled = FALSE;
            else
                { /* we want to ignore visible/invisible distinction */
                pst = curStyles[ii];
                if (pst == DEFSTYLE ||
                        ((pst & PARALMASK) == PARADEFAULT && (pst & JUSTMASK) == LEFTJUST))
                    ; /* ok, this is a default style */
                else
                    unstyled = FALSE;
                }
            }
        if (unstyled && nextStyle > -1)
            { /* check to make sure next style doesn't start before end of our region */
            styleP = (StyleDatP) GetPtr(dp->styles);
            s1p = ((Style1 SHUGE *) styleP->styles) + nextStyle;
            while (nextStyle < styleP->sHead.dAnn && unstyled && s1p->pos <pos + len)
                { /* scan thru styles */
                if (s1p->type != PARASTYLE)
                    unstyled = FALSE;
                else /* paragraph style, ignore invisiblity */
                    {
                    pst = s1p->dat;
                    if (pst == DEFSTYLE ||
                            ((pst & PARALMASK) == PARADEFAULT && (pst & JUSTMASK) == LEFTJUST))
                        ; /* ok, this is a default style */
                    else
                        unstyled = FALSE;
                    nextStyle++; /* we have to keep looking at styles */
                    s1p++;
                    }
                }
            ReleasePtr(dp->styles);
            KillPtr(styleP);
            }
        }
    /* else there are no styles */

    if (unstyled)
        { /* no styles, check for special chars */
        while (unstyled && len)
            { /* run thru len, reloading buffer as needed */
            if (pos < dp->buffStart || pos >= dp->buffEnd)
                _TUTORload_buffer_doc(dp,pos);
            nCheck = dp->buffEnd - pos;
            if (nCheck > len)
                nCheck = len;
            tp = ((unsigned char FAR *) dp->text) + pos - dp->buffStart;
            for (ii=0; ii<nCheck; ii++,tp++)
                if (*tp > 0x7f && *tp < 0xa0)
                    { /* we found a special character */
                    unstyled = FALSE;
                    break;
                    }
            len -= nCheck;
            pos += nCheck;
            }
        }
    
    ReleasePtr(theD);
    KillPtr(dp);
    
    return(unstyled);
    }

GetSelect(theV,pos,len)
Memh theV;
long *pos, *len;
    {
    if (theV)
        TUTORinq_select_tview(theV,pos,len);
    else
        {
        *pos = 0L;
        *len = 0L;
        }
    }

EncloseRange(doc,pl,len,style)
Memh doc;
long pl,len;
unsigned int style;
    {
    TUTORstyle_doc(doc,pl,len,FACESTYLE,style,FALSE,NEARNULL);
    }

tdoc_getstyles(theD,pos,styles) /* look for non-default styles in document */
Memh theD; /* the Tutor document */
long pos; /* the position in the document */
short *styles; /* to be filled with the styles */
/* returns TRUE if found non-default styles at pos */
    
{	DocP dp;
    int isStyled, ii;

    isStyled = FALSE;
    dp = (DocP) GetPtr(theD);
    if (dp->styles) {
        AtTStyle(dp->styles,pos,styles);
        /* check to see if they are all default */
        for (ii=0; ii<NSTYLES; ii++)
            if (styles[ii] != DEFSTYLE)
                break;
        isStyled = (ii < NSTYLES);
    } /* styles if */
    
    /* else no styles in doc at all */
    
    ReleasePtr(theD);
    KillPtr(dp);
    
    return(isStyled);
    
} /* tdoc_getstyles */
