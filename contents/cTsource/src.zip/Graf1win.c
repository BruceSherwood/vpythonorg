
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989,1992 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* ******************************************************************* */

#define STRICT
#include <windows.h>
#include <string.h>
#include <direct.h>

#include "baseenv.h"
#include "ctmsw.h"
#include "tglobals.h"
#include "kglobals.h"
#include "txt.h"
#include "kdefs.h"
#include "ct_ctype.h"
#include "compute.h"
#include "eglobals.h"
#include "ecglobal.h"
#include "chardef.h"
#include "fkeys.h"
#include "editmenu.h"

/* ******************************************************************* */

extern void ScreenWindow(TRect *wR);
extern void cTReleaseDC(HWND hWnd,HDC hDC);
extern HDC cTGetDC(HWND hWnd);
int  TUTORbeep(int  *ff,int  *dur,int  *volume,int  nbeep);   
extern int CTcount_colors(int oldf);
extern int TUTORset_window_title(int wix,char *str);
extern int breakpt(void);     
extern int CTpalette(int wn,Memh palH,int newF,Memh defH);
/* extern int isdigit(char cc); */
extern int sscanf(char *str,char *form, ...);                   
extern int TUTORsymbolic_fileref(struct _fref FAR *fR,char FAR *str);
extern int FileExists(struct _fref FAR *fR);
extern int set_textfont_win(int fi);
extern int set_textfont_fpc(int fi);
extern int TUTORget_font2(long fam,int size,unsigned int face,int cid);
extern int extend_font_table(int nnew);
extern char FAR *strncpyf(char FAR *ss,char FAR *tt,int len);          
extern int TUTORfree_handle(Memh hh);
extern int DummyFontID(void);
int  TUTORget_fileref_name(struct  _fref FAR *fRef,char  FAR *name); 
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
extern  int TUTORinq_file_info(FileRef FAR *fname,int *waccess,long *length,long *modtim,int *posx,int *posy);
extern int TUTORclose(int ff);    
extern int sprintf(char *s1,char *s2,...);
extern int TUTORabs_move_to(int xx,int yy);      
extern int TUTORdraw_text(unsigned char FAR *cp,int count);
int map_default_color(int cIndex); 
int  TUTORabs_fill_polygon(int  npoints,long  *fx,long  *fy); 
extern int extract_palette_color(int indx,int *rr,int *gg,int *bb);                      
extern int TUTORnormal_cursor(void);
extern int TUTORwait_cursor(void);     
extern int TUTORblock_move(char SHUGE *ss,char SHUGE *dd,long lth);
int  TUTORfill_abs_rect(struct  _trect FAR *tr,int  pattInd,int  pattC);
extern int TUTORset_fill(int ff,int fc);
extern int TUTORmove_abs_rect(int x1,int y1,int x2,int y2,int newx,int newy);     
extern int pat_fill_region(HRGN rH,int pFont,int pChar);
int TUTORset_abs_clip_rect(TRect FAR *clipR);                         
extern int MovieSupport(void);
/* extern int srand(int seed);   */                          
extern Memh LoadTable(char *tableFile,int *tableSize);
extern int fpc_delete_bitmap_cache(Memh fH);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
static int cur_tst_bit(struct pccharl *cdef,int rowBytes,unsigned char *bits,
       int xx,int yy);
static int cur_clr_bit(struct pccharl *cdef,int rowBytes,unsigned char *bits,
       int xx,int yy);
extern void TUTORset_color(int select,struct tutorColor FAR *newColor);
void WinKeyFixup(struct tutorevent FAR *event);
extern int strlenf(char FAR *cc);
extern int TUTORinq_icon_size(int fontid,int iconN,int *dx,int *dasc,int *ddes);
extern int TUTORzero(char FAR *ptr,long len);
extern int interact(int block);
extern HBRUSH fpc_brush(int pattF,int pattC,int invertF);
extern  long TUTORget_hsize(Memh mm);
extern int font_ptr_fpc(FileRef *fontRef,int fInd,int size,int face);
extern int font_ptr_win(int fInd,int size,unsigned int face,int known);
extern int strncmpf(char FAR *aa,char FAR *bb,int nn);
extern int strcmpf(char FAR *aa,char FAR *bb);
extern Memh read_fpc(FileRef FAR *fpcPath);
extern char SHUGE *fpc_char(struct pcfont FAR *fpcP,long charI,
			  struct pccharl *charDef);
extern int fpc_draw_char(Memh ftH,struct pcfont FAR *ftP,int cc);
extern int fpc_add_bitmap_cache(Memh ftH,int charI,int type,HBITMAP mapH,struct pccharl *pDef);
extern int fpc_find_bitmap_cache(Memh fontH,int cc,int type);
extern HDC fpc_mem_dc(int type);
extern char  FAR *strcpyf(char	FAR *aa,char  FAR *bb);
extern char  FAR *strcatf(char	FAR *aa,char  FAR *bb);
extern int TUTORchecksum(char FAR *addr,long length);
extern int TutorDeleteCard(Memh barh,int cardI);
extern int MenuNames(unsigned int mbar,int item,char *cardName,char *itemName);
extern int cTRegisterWindow(HWND hWnd,int cTtype,int cTindex,int cmdN,Memh infH);
extern int TUTORset_hsize(unsigned int	mm,long newsize,int abort);
extern unsigned int TUTORhandle(char *name,long size,int purgewmrm);
extern int TUTORdone_startup(void);
extern int TUTORstart_menubar(unsigned int  barh);
extern int TUTORforward_window(int wix);
extern int TUTORnew_window(int	wid);
extern long TUTORadd_ffamily(struct  _fref *famName,int	isSys,int  isSwitch);
extern long TUTORparse_font_family(struct  _fref *fontTag,struct  _fref *familyName,int  isFont,int  oneTag,int  *fontSize);
extern int TUTORinq_abs_string_width(unsigned char  FAR *s,int  lth,int  *dx);
extern int TUTORtrace(char *str);
extern int TUTORset_abs_clip_rectangle(int x1,int y1,int x2,int y2);
extern int TUTORdraw_abs_solid_rect(TRect FAR *tr,int color);
extern int TUTORinq_abs_screen_size(int *x,int *y,int *dx,int *dy);
extern int TUTORinq_abs_pen_pos(int *x,int *y);
extern int TUTORabs_line_to(int xx,int yy);
extern int TUTORdump(char *s);
extern int  TUTORpost_event(struct  tutorevent *event);
extern int TUTORpoll_events(int block);
extern int TUTORdealloc(char  FAR *ptr);
extern int start_executor(void);
extern int  TUTORfont_ptr(int  fInd,int  size,unsigned int  face,int cid);
extern int  ReleasePtr(unsigned int  mm);
extern char  FAR *GetPtr(unsigned int  mm);
extern int TUTORcopy_fileref(FileRef FAR *fDest,FileRef FAR *fSource);
extern int TUTORcmp_fileref(FileRef FAR *f1,FileRef FAR *f2);
extern int TUTORcopy_fileref_name(FileRef FAR *fRef,char FAR *name);
extern int TUTORcopy_fileref_dir(FileRef FAR *dirname,FileRef FAR *fullname);
extern char  *strf2n(char  FAR *strp);
extern char  *strnf2n(char  FAR *strp,int  nn);
extern int TUTORstartup(int argc,char **argv,FileRef FAR *filenameR);
extern void RestoreExecCursor(void);
extern void DestroyExecCursor(void);
extern int TraceMsg(char FAR *str);
extern long TUTORread();
extern long TUTORwrite();
extern long TUTORadd_ffamily();
extern long TUTORinq_ffamily_id();

/* ******************************************************************* */

struct BitmapCacheEntry {
    Memh fontH; /* handle on fpc font */
    int charI; /* index of character */
    int type; /* type 0 = character, 1 = brush, 2 = inverted brush */
    HBITMAP mapH; /* handle on Windows bitmap */
    struct pccharl charDef; /* FPC character definition */
}; /* BitmapCacheEntry */

#define BitmapCacheMax 8 /* maximum entries in bitmap cache */

int BitmapCacheN = 0; /* number entries in bitmap cache */

struct BitmapCacheEntry FAR *BitmapCache; /* bitmap cache */

long scrBitSize = 0; /* scratch bitmap size */
Memh scrBitH; /* handle on scratch bitmap */

int leftDown = 0;
int rightDown = 0;
int anyDown = 0;
int lastMouseX;
int lastMouseY;

long pollCtr = 0;
long maxPtime = 0;

/* ******************************************************************* */

extern HANDLE hcTInst ; /* current instance of cT */
extern HWND FirstWinH; /* first window created in ctauth */
extern HBRUSH hbrWhite; /* handle on stock white brush */
extern HBRUSH hbrBlack; /* handle on stock black brush */
extern jmp_buf mainenv; /* saved enviornment for longjmp */
extern int tDump; /* TRUE if crashed (TUTORdump called) */
extern int KeepRunning; /* TRUE if still alive */
extern char FAR *_pgmptr;
extern long winMainTime;
extern char *classStr; /* window class name string */
extern BOOL fMovieOpen; /* TRUE if VFW movie currently open */
extern int qtMovieOpenF; /* TRUE if QuickTime movie currently open */
extern int mControllerHasPalette; /* TRUE if movie controller controls palette */
extern struct tutorevent FAR *needScrollUp;
extern double scrollChangeLast;
extern double scrollSentLast;
extern int inPrint; /* TRUE if drawing to a printer */
extern int inMenu; /* TRUE if selecting a menu */
extern int AuxWn; /* debugger auxiliary window number */  
extern int fMoviePlaying; /* TRUE if movie currently playing */
extern char *aboutStr;

char *zcursorsStr = "zcursors";
char *ziconsStr = "zicons";
char *zpatternsStr = "zpatterns";

/* ******************************************************************* */

HWND CurrentWinH = NULL; /* handle on current window */
HDC CurrentDC; /* current window's device context */
int HaveDC = FALSE; /* TRUE if have device context */
HPEN OriginalPen = HNULL; /* handle on original pen */
long polltime; /* time of last poll */
Memh cTwinInfH = HNULL; /* handle on cT window (cTwinInf) table */
int cTwinInfN; /* number entries in cT window table */
int havePalette; /* TRUE if palette-based display */
int paletteNcolors; /* size of color palette */
int paletteNresv; /* number colors reserved by system */
int wColorSet = -1; /* window colors set for */
int frrC,frbC,frgC; /* foreground color as r,g,b */
int bkrC,bkbC,bkgC; /* background color as r,g,b */
COLORREF frRef = 0; /* foreground color */
COLORREF bkRef = 0; /* background color */
int colorInvert = FALSE; /* TRUE if must invert frRef/bkRef */
int MillionsColor = FALSE; /* TRUE if TrueColor display */
int ReadOnlyColor = FALSE; /* TRUE if read-only palette */
HCURSOR ExecCursor = 0; /* executor-created cursor */
HCURSOR SysCursor = 0; /* system cursor (arrow or wait) */
HCURSOR ArrowCursor = 0; /* arrow cursor */
HCURSOR WaitCursor = 0; /* wait cursor */
int mouseCapture = 0; /* TRUE if have mouse during scroll */    
long TopTime = 0; /* time at top of cT interact loop */

static int cTwinInfA; /* number entries allocated in cT window table */
static long CurrentFontH; /* currently selected font */
static int CurrentFontType; /* type of font (0 = windows, 1 = fpc) */
static int textFontFamily; /* current font family */
static int textFontSize;   /* current font size */
static int textFontFace;   /* current font face */
static int zpatternsF = -1; /* index of patterns */
static int HaveMemDC = 0; /* 0 = don't have memory dc */
                          /* 1 = memory dc for icon plotting */
                          /* 2 = memory dc for text xor */
static HDC hMemDC = HNULL; /* compatible memory device context */
static HBITMAP OMemBitMapH = HNULL; /* handle on original mem dc bitmap */
static HBITMAP CDefBitMapH = HNULL; /* handle on bitmap that defines size */
static HFONT CFontH = HNULL; /* handle on font used in mem context */
static HFONT OMemFontH = HNULL; /* handle on original mem dc font */
static int f_height = -1; /* current font height (-1 = unknown ) */
static int f_maxwidth; /* current font maximum width */
static int f_ascent; /* current ascent */
static long textScrollTime = 0;

/* ******************************************************************* */

int TUTORinteract(block) /* main interact() driver */
int block; /* TRUE if should block on input */

{
    if (!windowsP)
		return(0); /* not up far enough yet */

    TopTime = TUTORinq_msec_clock();
    do { /* if running, give executor 100 msec bursts */
        if (!HaveDC) {
            CurrentDC = cTGetDC(CurrentWinH);
	    	if ((CurrentWindow == ExecWn) && windowsP[CurrentWindow].winPalH && (!fMovieOpen) &&
			   (!mControllerHasPalette)) {
				/* select current palette into device context */
                SelectPalette(CurrentDC,(HPALETTE)windowsP[CurrentWindow].winPalH,0);
                RealizePalette(CurrentDC);   
	    	}
	    	RestoreExecCursor();
        }
        interact(block); /* main cT interact loop */
		if ((runflag == halt) || (waitflag != atinterrupt) || exS.shouldint || fMoviePlaying)
            break; /* continue while executor runs */    
    } while ((TUTORinq_msec_clock()-TopTime) < 100);         
    
    if (HaveDC) { /* release device context */
    	cTReleaseDC(CurrentWinH,CurrentDC);
    }
    return(0);

} /* TUTORinteract */

/* ******************************************************************* */

TUTORpoll_events(block) /* queue up any pending events */
int block;

{   HWND hWnd;      /* handle on current window */
    RECT wrect;     /* window client area rectangle */
    int wix;        /* index of current window */
    MSG pMsg; /* next message in queue */
    int peekF; /* true if message in queue */
    struct tutorevent ev;  /* current event */
    struct tutorevent FAR *timequep;
    int i;

    polltime = TUTORinq_msec_clock();
    if (nevents > (EVENTLIMIT-2))
	return(0);

    /* check if need to handle text scroll */

    if (!leftDown) {
		if (mouseCapture)
			ReleaseCapture();
		anyDown = mouseCapture = 0;
    }
    if (anyDown && (CurrentWindow >= 0)) {
	if (!mouseCapture) {
	    SetCapture((HWND)windowsP[CurrentWindow].wp);
	    mouseCapture = TRUE;
	}
	if ((nevents == 0) && (polltime > textScrollTime)) {
	    TUTORzero((char FAR *)&ev,(long)sizeof(struct tutorevent));
	    ev.window = CurrentWindow;
	    ev.type = EVENT_DOWNMOVE;
	    ev.leftdown = TRUE;
	    ev.timestamp = polltime;
	    ev.x = lastMouseX;
	    ev.y = lastMouseY;
	    eventque[nevents++] = ev;
	    textScrollTime = polltime+100L;
	} /* nevents if */
    }
    if (nevents > (EVENTLIMIT-2))
	return(0);

    /* check for up-event needed for scrollbar */

    if (needScrollUp && (needScrollUp->type >= 0)) {
	if (leftDown && (scrollChangeLast == scrollSentLast))
	    needScrollUp->timestamp = TUTORinq_msec_clock()+100;
	if ((!leftDown) || (TUTORinq_msec_clock() >= needScrollUp->timestamp)) {
	    needScrollUp->timestamp = 0;
	    eventque[nevents++] = *needScrollUp;
	    if (leftDown)
			needScrollUp->timestamp = TUTORinq_msec_clock()+200;
	    else
			needScrollUp->type = -1;
	    scrollSentLast = scrollChangeLast;
	}
    }

    /* check for redraw events */

    for (wix=0; wix<WINDOWLIMIT; wix++) {
        if (windowsP[wix].wp && windowsP[wix].winRedraw) {
            if (nevents >= EVENTLIMIT)
                return(0); /* exit if queue full */
            hWnd = (HWND)windowsP[wix].wp;
	    windowsP[wix].winRedraw = FALSE; /* clear redraw */
	    TUTORzero((char FAR *)&ev,(long)sizeof(struct tutorevent));
            ev.window = wix; /* set up event fields */
            ev.view = (struct tutorview FAR *)-1;
            ev.id = 0;
	    ev.type = EVENT_REDRAW;
            ev.timestamp = polltime;
            GetClientRect(hWnd,(LPRECT)(&wrect));
            ev.x = wrect.right;
            ev.y = wrect.bottom;
            if (nevents && (eventque[nevents-1].type == EVENT_REDRAW) &&
               (eventque[nevents-1].window == wix) &&
               (eventque[nevents-1].view == (struct tutorview FAR *)-1)) {
                eventque[nevents-1] = ev; /* replace previous event */
            } else
                eventque[nevents++] = ev;
        } /* redraw if */
    } /* for */

    if (nevents > (EVENTLIMIT-2))
	return(0);

    /* check for timing events */

    timequep = (struct tutorevent FAR *)GetPtr(timeque);
    while (ntiming && (timequep[0].timestamp <= polltime)) {
        if (timequep[0].type >= 0)
            eventque[nevents++] = timequep[0];
        ntiming--;
        for (i=1; i<=ntiming; i++) timequep[i-1] = timequep[i];
    } /* while */
    ReleasePtr(timeque);

    /* if no event, see if need mock event for event still in */
    /* windows queue */

    if ((nevents == 0) && (CurrentWindow >= 0)) {
        hWnd = (HWND)windowsP[CurrentWindow].wp;
        peekF = PeekMessage((MSG FAR *)&pMsg,hWnd,0,0,PM_NOYIELD | PM_NOREMOVE);
	if (peekF) {
	    TUTORzero((char FAR *)&ev,(long)sizeof(struct tutorevent));
            ev.type = ev.window = -1; /* bogus event */
            ev.view = (struct tutorview FAR *)-1L;
            eventque[nevents++] = ev;
        }
    } /* nevents if */
    return(0);

} /* TUTORpoll_events */

/* ******************************************************************* */

TUTORinq_wmg_busy(target)
int target; /* window or -1 for all windows */

{   HWND hWnd;
    int peekF; /* true if message in queue */
    MSG pMsg; /* next message in queue */

    if (inMenu)
		return(TRUE); /* in process of selecting menu */

    if ((ExecWn < 0) || (target != ExecWn))
		return(0);

    hWnd = (HWND)windowsP[ExecWn].wp;
    peekF = PeekMessage((MSG FAR *)&pMsg,hWnd,0,0,PM_NOYIELD | PM_NOREMOVE);

    return(peekF); /* TRUE if event waiting for executor */

} /* TUTORinq_wmg_busy */

/* ******************************************************************* */

void WinKeyFixup(event) /* special key handling */
struct tutorevent FAR *event;

{   int key;
    int fKey; /* non-zero if special key */
    int mKey; /* non-zero if menu key */

    fKey = mKey = 0; /* not special key yet */
    key = event->keys[0];
    if ((key == 127) || (key == 0x09)) /* del, tab */
		event->type = -1; /* handled by WM_KEYDOWN */
    if (key == 0x0d) event->keys[0] = 0x0a; /* enter */
    if (event->window >= 0) {
		if (windowsP[event->window].type == EDITW) {
			if (key == 0x18) /* ctrl+x */
	    		fKey = KCUT;
			else if (key == 0x03) /* ctrl+c */
	    		fKey = KCOPY;
			else if (key == 0x16) /* ctrl+v */
	    		fKey = KPASTE;
			else if (key == 0x13)  /* ctrl+s */
	    		mKey = edit_save;
			else if (key == 0x0f)  /* ctrl+o */
	    		mKey = edit_switch;
			else if (key == 0x06)
	    		mKey = edit_search; /* ctrl+f */
		} else if (windowsP[event->window].type == EXECW) {
			if (key == 0x03) /* ctrl+c */
	    		fKey = KCOPY;
			else if (key == 0x16) /* ctrl+v */
	    		fKey = KPASTE;
		} else if (windowsP[event->window].type == HELPW) {
			if (key == 0x03) /* ctrl+c */
	    		fKey = KCOPY;
		} /* HELPW else */
	} /* window if */

    if (fKey) {
		event->type = EVENT_FKEY;
		event->nkeys = 1;
		event->value = fKey; /* set key value */
    } /* fKey if */

    if (mKey) {
		event->type = EVENT_MENU;
		event->a1 = mKey;
		event->a2 = 0;
    }

} /* WinKeyFixup */

/* ******************************************************************* */

TUTORnew_window(wid)    /* open new window */
                        /* windows[].wxsize/wysize = initial size */
                        /* if 0 = window managers default */
int wid; /* id # in window table */

{   HWND winH; /* handle on new window */
    int xpos; /* x position for window */
    int ypos; /* y position for window */
    int xsize; /* x size for window */
    int ysize; /* y size for window */
    int otherStyles; /* additional styles for window creation */
    struct tutorwindow FAR *wp; /* pointer to ct window data */
    RECT wrect; /* client area rectangle */
    TEXTMETRIC textm; /* for default text size info */
    char *wTitle; /* window title */
	TRect *pR; /* preferences setting for window */

    wp = &windowsP[wid];
    wp->winRedraw = TRUE; /* start with redraw flag set */
	wp->moved = FALSE; /* havent moved/resized window yet */
    otherStyles = 0; /* pre-set to use defaults */
    xsize = ysize = CW_USEDEFAULT; /* pre-set to use defaults */
    xpos = ypos = CW_USEDEFAULT;
    xsize = 500; /* pre-set to something sensible */
    ysize = 150;
    wTitle = NULL; /* no title yet */
	pR = NULL; /* no rectangle yet */

    if (wp->wxsize) {
		xpos = ypos = 0;
        xsize = wp->wxsize;
        ysize = wp->wysize;
    } else if (wp->type == EDITW) { /* editor window */
		pR = &prfP->editWp;
    } else if (wp->type == EXECW) { /* executor window */
		wTitle = "cT Executor";
#ifdef EXECUTE
		xpos = ypos = 0;
        xsize = 500;
		ysize = 400;
		if (ExecWinX) {
	    	xsize = ExecWinX;
	    	ysize = ExecWinY;
		}
#else
		pR = &prfP->execWp;
#endif
    } else if (wp->type == MESGW) {
		pR = &prfP->msgWp;
		wTitle = "Message";    
   } else if (wp->type == DEBUGW) {
		pR = &prfP->debugWp;
		wTitle = "Debug";    
	} else if (wp->type == DEBUGAUXW) {
		pR = &prfP->stackWp;
		wTitle = "Debug";   
	} else if (wp->type == ABOUTW) {
#ifdef AUTHOR
		wTitle = aboutStr;
#endif
		xsize = 460;
		ysize = 480;
    } else if (wp->type == TRACEW) {
		wTitle = "Trace";    
    }
	
	if (pR) {
		ScreenWindow(pR);
		xpos = pR->left;
		ypos = pR->top;
		xsize = (pR->right-pR->left)+1;
		ysize = (pR->bottom-pR->top)+1;
	}

    if (wp->type == EDITW) { /* editor windows */
		otherStyles |= (WS_HSCROLL | WS_VSCROLL);
    }

    if (wid) {
		winH = CreateWindow((LPSTR)(classStr), /* window class */
		FARNULL, /* window name */
		WS_OVERLAPPEDWINDOW | otherStyles, /* window style */
		xpos,	    /* x position */
		ypos,	    /* y position */
		xsize,	    /* width */
		ysize,	    /* height */
		NEARNULL,	/* parent handle */
		NEARNULL,	/* menu or child ID */
		hcTInst,	/* program instance */
		FARNULL);	/* additional info */

        if (winH) {
            ShowWindow(winH,SW_SHOWNORMAL);  /* initial display of window */
            UpdateWindow(winH); /* sends WM_PAINT message  */
        } /* winh if */
    } else { /* first window */
	winH = (HWND)FirstWinH; /* first window already created */
	if ((xpos != CW_USEDEFAULT) && (xsize != CW_USEDEFAULT)) {
	    MoveWindow(winH,xpos,ypos,xsize,ysize,TRUE);
	}
    } /* wid else */

    GetClientRect(winH,(LPRECT)(&wrect));
    wp->wxsize = (wrect.right-wrect.left)+1;
    wp->wysize = (wrect.bottom-wrect.top)+1;

    wp->wp = (long)(char FAR *)(winH);
    if (wp->wp == (long)FARNULL)
        TUTORdump("could not create new window");

    /* get handles on scrollbar children */
	
    if (wp->type == EDITW) {
		wp->vScrollW = (long)(char FAR *)GetWindow(winH,GW_CHILD); /* first child = vertical scroll */
		wp->hScrollW = wp->vScrollW;
    }
	
    cTRegisterWindow((HWND)winH,cTw_Overlap,wid,0,HNULL);
    if (HaveDC) /* release previous context */
        cTReleaseDC(CurrentWinH,CurrentDC);
    CurrentWinH = winH; /* new window is current window */
    CurrentDC = cTGetDC(winH);
    if (wid == 0) { /* first window */
		if (GetTextMetrics(CurrentDC,(LPTEXTMETRIC)(&textm))) {
			SysFontHeight = textm.tmAscent+textm.tmDescent+textm.tmExternalLeading;
			SysFontWidth = textm.tmAveCharWidth;
		} else {
			SysFontHeight = 20;
			SysFontWidth = 10;
		}
    }
    SetMapMode(CurrentDC,MM_TEXT);
    SetTextAlign(CurrentDC,TA_UPDATECP | TA_BASELINE);
    if (wp->type == EDITW) {
		SetScrollRange(winH,SB_HORZ,0,32767,FALSE);
		SetScrollRange(winH,SB_VERT,0,32767,FALSE);
    }
    wp->paletteSize = CTcount_colors(FALSE);

    if (wTitle)
		TUTORset_window_title(wid,wTitle);

    return(0);

} /* TUTORnew_window */

/* ******************************************************************* */

void ScreenWindow(wR) /* check + force window rectangle on-screen */
TRect *wR; /* window rectangle to check */

{	HWND winH; /* handle on desktop window */
	RECT dR; /* desktop window rectangle */
	int dX,dY; /* window width, height */
	int ddX,ddY; /* desktop width, height */
   
	winH = GetDesktopWindow();
    GetWindowRect(winH,(LPRECT)(&dR));
	ddX = dR.right-dR.left;
	ddY = dR.bottom-dR.top;

	/* check size reasonable for desktop */

	dX = wR->right-wR->left;
	dY = wR->bottom-wR->top;
	if ((dX <= 0) || (dY <= 0) || (dX > ddX) || (dY > ddY)) {
		wR->left = dR.left;
		wR->right = wR->left+(ddX/2);
		wR->top = dR.top;
		wR->bottom = wR->top+(ddY/2);
		dX = wR->right-wR->left;
		dY = wR->bottom-wR->top;
	}

	/* check position on desktop */

	if (wR->left < dR.left) {
		wR->left = dR.left;
		wR->right = wR->left+dX;
	}
	if (wR->right > dR.right) {
		wR->left = dR.left;
		wR->right = dR.left+dX;
	}
	if (wR->top < dR.top) {
		wR->top = dR.top;
		wR->bottom = wR->top+dY;
	}
	if (wR->bottom > dR.bottom) {
		wR->top = dR.top;
		wR->bottom = wR->top+dY;
	}

} /* ScreenWindow */

/* ******************************************************************* */

int TUTORclose_window(wix) 
int wix; /* index of window to close */

{   struct tutorevent FAR *evp;
    struct cTwinInf FAR *cTwinInfP; /* pointer to cTwinInf table */
    HWND hWnd; /* handle on window to destroy */
    int ii;
    RECT wRect; /* window rectangle */
	TRect tR; /* cT format window rectangle */

    
    if (wix < 0) 
        return(0); /* nothing to do */
    hWnd = (HWND)windowsP[wix].wp;
    if (!hWnd)
		return(0); /* nothing to do */

    if (HaveDC) { /* release device context */
		cTReleaseDC(CurrentWinH,CurrentDC);
    }

	GetWindowRect(hWnd,(RECT FAR *)&wRect);
	tR.left = wRect.left;
	tR.right = wRect.right;
	tR.top = wRect.top;
	tR.bottom = wRect.bottom;
    if (wix == MsgWn) { /* remember message window position */
		prfP->msgWp = tR;
    }
    if (wix == DebugWn) { /* remember debug window position */
		prfP->debugWp = tR;
    }
    if (wix == AuxWn) { /* remember stack window position */
		prfP->stackWp = tR;
    }
    
    SetMenu(hWnd,NULL);
    DestroyWindow(hWnd);
    windowsP[wix].wp = (long)FARNULL;

    /* remove from cT windows registry */

    cTwinInfP = (struct cTwinInf FAR *)GetPtr(cTwinInfH);
    for(ii=0; ii<cTwinInfN; ii++) {
	if (cTwinInfP[ii].index == wix) {
	    cTwinInfP[ii].index = -1;
	    cTwinInfP[ii].type = 0;
	}
    } /* for */
    ReleasePtr(cTwinInfH);

    /* cancel pending events for this window */
    
    for(ii=0; ii<nevents; ii++) {
       if (eventque[ii].window == wix)
            eventque[ii].type = -1; /* kill event */
    } /* for */
    evp = (struct tutorevent FAR *) GetPtr(timeque);
    for(ii = 0; ii < ntiming; ii++, evp++) {
        if (evp->window == wix) 
            evp->type = -1; /* kill event */
    } /* for */
    ReleasePtr(timeque);
    
} /* TUTORclose_window */

/* ******************************************************************* */

int cTRegisterWindow(hWnd,cTtype,cTindex,cmdN,infH) /* add window to cTwinInf table */
HWND hWnd; /* Windows handle on window */
int cTtype; /* cT type for window */
int cTindex; /* index in cT table (windows[]) */
int cmdN; /* command this (button) window will send */
Memh infH; /* cT handle on additional information */

{   struct cTwinInf FAR *cTwinInfP; /* pointer to cTwinInf table */
    int wii; /* index in cTwinInf table */
    int wjj; /* scratch index */

    if (cTwinInfH == HNULL) { /* no table yet */
	cTwinInfA = 5; /* number entries to allocate */
	cTwinInfN = 0; /* nothing in table yet */
	cTwinInfH = TUTORhandle("cTwinIn",
		    (long)(cTwinInfA*sizeof(struct cTwinInf)),FALSE);
    } /* cTwinInf if */

    cTwinInfP = (struct cTwinInf FAR *)GetPtr(cTwinInfH);
    wii = -1; /* no slot assigned yet */
    if (cTwinInfN < cTwinInfA) {
		wii = cTwinInfN++; /* take next slot */
    } else {
		/* search for a free slot */
		for(wjj=0; wjj<cTwinInfN; wjj++) {
	    	if (cTwinInfP[wjj].type == 0) {
				wii = wjj; /* found an open slot */
				break; /* exit for */
	    	}
		} /* for */
    } /* cTwinInfN else */

    /* extend table if didn't find a slot */

    if (wii < 0) {
		cTwinInfA += 5; /* extend table */
		ReleasePtr(cTwinInfH); /* release table for reallocate */
		TUTORset_hsize(cTwinInfH,(long)(cTwinInfA*sizeof(struct cTwinInf)),TRUE);
		cTwinInfP = (struct cTwinInf FAR *)GetPtr(cTwinInfH); /* re-aquire ptr */
		wii = cTwinInfN++;  /* take next free slot */
    } /* wii if */

    /* add entry to table */

    cTwinInfP += wii;
    cTwinInfP->hWnd = hWnd; /* handle on window */
    cTwinInfP->type = cTtype; /* basic type of window */
    cTwinInfP->index = cTindex; /* index in windows[] */
    cTwinInfP->cmdN = cmdN; /* command this window will send */
    cTwinInfP->infH = infH; /* handle on additional information */
    ReleasePtr(cTwinInfH);

    return(wii);

} /* cTRegisterWindow */

/* ******************************************************************* */

TUTORselect_window(wix) /* select specified window */
int wix; /* index in window table */

{   struct tutorfont FAR *fp;
    int fontIndex;

    fpc_mem_dc(0); /* release memory device context */
    if (HaveDC) /* release device context */
        cTReleaseDC(CurrentWinH,CurrentDC);
    CurrentWinH = (HWND)windowsP[wix].wp; /* get window handle */
    CurrentDC = cTGetDC(CurrentWinH);
    CurrentWindow = wix;
    fontIndex = windowsP[wix].FontIndex;
    f_height = -1;
    wColorSet = -1;
    if (fontIndex >= 0) {
        textFont = fontIndex;
		fp = fontIndex + (struct tutorfont FAR *) GetPtr(fontsH);
		CurrentFontH = fp->fptr;
		CurrentFontType = fp->datType;
		ReleasePtr(fontsH);
    }

    if (((HPALETTE)windowsP[wix].winPalH) && (!fMovieOpen) && !mControllerHasPalette && (runflag == halt)) {
		SelectPalette(CurrentDC,(HPALETTE)windowsP[wix].winPalH,0); /* select into device context */
        RealizePalette(CurrentDC);   
    } else if (windowsP[wix].type == EXECW) {   
		CTpalette(wix,defaultPalette,2,HNULL);
    }
    return(0);

} /* TUTORselect_window */

/* ******************************************************************* */

TUTORforward_window(wix) /* bring specified window forward */
int wix; /* index in window table */

{   HWND winH;
    HPALETTE winPalH; 
#ifdef NOSUCH
    HDC hdc;
    HPALETTE oldPalH; 
#endif

    winH = (HWND)windowsP[wix].wp; /* get window handle */
    BringWindowToTop(winH); /* bring to top of overlapped windows */
    SetFocus(winH); /* set input focus to this window */
    if (winPalH = (HPALETTE)windowsP[wix].winPalH) {
#ifdef NoSuch
        hdc = cTGetDC(winH);
        oldPalH = SelectPalette(hdc,winPalH,FALSE);
        RealizePalette(hdc);
        cTReleaseDC(winH,hdc);
#endif

    }

    return(0);

} /* TUTORforward_window */

/* ******************************************************************* */

TUTORshow_window(wix) /* show specified window */
int wix; /* index in window table */

{   HWND winH;

    winH = (HWND)windowsP[wix].wp; /* get window handle */
	ShowWindow(winH,SW_SHOWNORMAL);
    BringWindowToTop(winH); /* bring to top of overlapped windows */
    return(0);

} /* TUTORshow_window */

/* ******* font routines ********************************************* */

long TUTORparse_font_family(fontTag,familyName,isFont,oneTag,fontSize)
FileRef *fontTag; /* either full path, or bare (which is either file in sourceDir, or a system reference) */
FileRef *familyName; /* to be set to the font's family name (possibly including full path) */
int isFont;    /* 0 = icons/pattern, 1 = font, 2 = fontp */
int oneTag; /* TRUE if this is from a one-tag font type command */
int *fontSize; /* if exists, set to font size derived from fontTag */
/* returns font family id */

{   char *cp;
    int ii,jj;
    int fSize;
    FileRef tempRef;
    long famId;
    int isSys, issymbolic;
    FontFamily FAR *ffp; /* pointer to font family table entry */
    int famIndx; /* index of font family */

    fSize = -1;
    issymbolic = fontTag->path[0] != '\\'; /* TRUE if symbolic font */

    if (isFont == 2) {

	/* for -fontp-, don't presume knowledge of font family names or */
	/* font sizes */

	ii = jj = strlenf((char FAR *)fontTag->path)-1; /* end of name string */
	if (ii > 0) {
	    while ((ii >= 0) && (fontTag->path[ii] != '\\'))
		ii--; /* back up to backslash */
	    if (ii < jj) { /* we did back up */
		strcpyf((char FAR *)&fontTag->path[0],
			(char FAR *)&fontTag->path[ii+1]);
	    }
	} /* ii if */
    } /* isFont if */

    if (oneTag) {
	/* get rid of possible .fwm or .fpc extension */
	ii = strlen(fontTag->path) - 1; /* index to last char */
	if ((strcmp(&fontTag->path[ii-3],".fwm") == 0) ||
	    (strcmp(&fontTag->path[ii-3],".fpc")) == 0) {
	    ii -= 4;
	    fontTag->path[ii+1] = '\0';
	}
	/* get rid of (and parse) trailing size */
	while (ii > 1 && isdigit(fontTag->path[ii])) ii--;
	if (fontTag->path[ii+1]) {
	    /* if we backed up at all */
	    sscanf(fontTag->path+ii+1,"%d",&fSize);
	    if (issymbolic)
		fontTag->path[ii+1] = '\0';
	}
    } /* oneTag */

    /* name conversions */
    cp = NULL;
    if (strcmp(fontTag->path, "helv") == 0)
	cp = "zsans";
    else if (strcmp(fontTag->path,"time") == 0)
	cp = "zserif";
    else if (strcmp(fontTag->path,"cour") == 0)
	cp = "zfixed";
    else if (strcmp(fontTag->path,"symb") == 0)
	cp = "zsymbol";
/*  else cp = fontTag->path;	*/

    if (cp) { /* found symbolic name */
	TUTORsymbolic_fileref((FileRef FAR *)familyName,(char FAR *)cp);
    } else { /* not symbolic, just copy fontTag */
	TUTORcopy_fileref((FileRef FAR *)familyName,(FileRef FAR *)fontTag);
    }
    
    if (fontSize)
	*fontSize = fSize;

    famId = TUTORinq_ffamily_id(familyName,isFont != 2); /* look for already existing family */

    if (famId < 0) {
	/* this is a new family */
	isSys = TRUE;
	if (issymbolic) {
	    /* not full path.  could be in sourceDir, or could be reference to system */
	    TUTORcopy_fileref_dir((FileRef FAR *) &tempRef, sourceDirP);
	    TUTORcopy_fileref_name((FileRef FAR *) &tempRef,familyName->path);
	    if (FileExists((FileRef FAR *) &tempRef)) {
		/* in sourceDir */
		TUTORcopy_fileref((FileRef FAR *) familyName,&tempRef);
		isSys = FALSE;
	    } else
		isSys = TRUE; /* must be reference to system font */
	} /* issymbolic */
	famIndx = nFamilies; /* will be index of new family */
	famId = TUTORadd_ffamily(familyName,isSys,TRUE);
	if (isFont == 2) {
	    famId |= 0x4000L; /* change family id */
	    ffp = famIndx+(FontFamily FAR *)GetPtr(fontFamilies);
	    ffp->fID = famId; /* change family id */
	    ffp->knownFont = FALSE; /* don't know size data */
	    for(ii=0; ii<3; ii++) {
		for(jj=0; jj <NFSIZES; jj++) {
		    ffp->famSizes[ii][jj] = -1; /* no size data */
		} /* jj for */
	    } /* ii for */
	    ReleasePtr(fontFamilies);

	}
    } /* famId if */
    return(famId);

} /* TUTORparse_font_family */

/* *********************************************************************** */

TUTORis_symbolic(ss) /* returns TRUE if name is symbolic */
char *ss; /* possible symbolic name */

{   int sLen;
    char cc, *cp;
    int ret;

    sLen = strlen(ss);

    /* temporarily get rid of trailing digits */
    cp = ss + sLen - 1;
    while (cp > ss && isdigit(*cp))
        cp--;
    cc = *(cp+1);
    *(cp+1) = '\0';

    /* we should compare against system font list, but for now just
       compare against z* */

    ret = FALSE;
    if (!strcmp(ss,"zsans"))
        ret = TRUE;
    else if (!strcmp(ss,"zserif"))
       ret = TRUE;
    else if (!strcmp(ss,"zfixed"))
        ret = TRUE;
    else if (!strcmp(ss,"zsymbol"))
        ret = TRUE;
    else if (!strcmp(ss,ziconsStr))
        ret = TRUE;
    else if (!strcmp(ss,zpatternsStr))
        ret = TRUE;
    else if (!strcmp(ss,zcursorsStr))
        ret = TRUE;

    *(cp+1) = cc; /* restore string */

    return(ret);

} /* TUTORis_symbolic */

/* *********************************************************************** */

int TUTORset_textfont(jj) /* set text font */
int jj; /* index in font table of font to set to */

{   struct tutorfont FAR *fp; /* pointer to font table entry */
    int fontType; /* type of font to select */

    if (jj == textFont)
	    return(0); /* already set to correct font */

    fpc_mem_dc(0); /* get rid of font in memory DC (xor mode text) */

    fp = jj + (struct tutorfont FAR *) GetPtr(fontsH);
    fontType = fp->datType;
    ReleasePtr(fontsH);

    if (fontType == 0)
	    return(set_textfont_win(jj)); /* windows font */
    else if (fontType == 1)
	    return(set_textfont_fpc(jj)); /* fpc font */
    else return(0);

} /* TUTORset_textfont */

/* *********************************************************************** */

static int set_textfont_win(jj) /* set text font */ /* wm version */
int jj; /* index in font table of font to set to */

{   long fh; /* font handle */
    struct tutorfont FAR *fp; /* pointer in ct font table */

    if (CurrentWindow < 0)
	return(0);
    if (inPrint)
	return(0);
    fp = jj + (struct tutorfont FAR *) GetPtr(fontsH);
    fh = fp->fptr;
    textFont = windowsP[CurrentWindow].FontIndex = jj;
    textFontFamily = (int)fp->fID;
    textFontSize = fp->size;
    textFontFace = fp->textface;
    ReleasePtr(fontsH);
    CurrentFontH = fh;
    CurrentFontType = 0; /* windows font */
    SelectObject(CurrentDC,(HGDIOBJ)fh);
    return(0);

} /* set_textfont_win */

/* *********************************************************************** */

int set_textfont_fpc(jj) /* set text font */
int jj; /* index in font table of font to set to */

{   Memh fh;
    struct tutorfont FAR *fp;

    fp = jj + (struct tutorfont FAR *) GetPtr(fontsH);
    fh = (Memh)fp->fptr;
    textFontFamily = (int)fp->fID;
    textFontSize = fp->size;
    textFontFace = fp->textface;
    ReleasePtr(fontsH);

    CurrentFontH = fh;
    CurrentFontType = 1; /* fpc font */
    textFont = jj;
    return(0);

} /* set_textfont_fpc */

/* *********************************************************************** */

TUTORset_textfont2(family,size,face)
/* set to possibly unknown font by characteristics */
long family; /* id, not index */
int size; /* system size */
int face; /* face code */

{
    if (family != textFontFamily || size != textFontSize || face != textFontFace)
	TUTORset_textfont(TUTORget_font2(family,size,face,111)); /* set to new font */
    return 0;

} /* TUTORset_textfont2 */

/* *********************************************************************** */

TUTORinvalidate_font()

{
    textFont = textFontFamily = -1;
    textFontSize = textFontFace = 0;
    return(0);

} /* TUTORinvalidate_font */

/* *********************************************************************** */

TUTORinq_font_index() /* return index (in font table) of current font */

{
    return(textFont);
}

/* *********************************************************************** */

TUTORfont_ptr(fInd,size,face,cid) /* get font pointer for item */
int fInd; /* index of family in family table */
int size; /* system size */
unsigned int face; /* size & face of desired font */
int cid; /* caller id */
/* returns index of new font entry */

{   char FAR *famN; /* family name */
    int wSymbolicF; /* TRUE if windows-format symbolic font */
    int fpcF; /* TRUE if cT FPC-format font */
    int defFillF; /* TRUE if font used for default fill */
    FontFamily FAR *familyP; /* pointer to family table entry */
    struct tutorfont FAR *fontP; /* pointer to font table entry */
    struct tutorfont FAR *tfP; /* pointer to font table entry */
    int fi; /* index in font table */
    int familyID; /* family id code */
    FileRef famRef; /* (mock) file reference for font family */
    FileRef fpcRef; /* file reference for fpc-format font */
    int ftIndex; /* index in font table */
    int si,len; /* indexes in font name */

    wSymbolicF = fpcF = defFillF = FALSE; /* haven't recognized font yet */
    f_height = -1;
    if (fInd < 0) {
		fontP = textFont + (struct tutorfont FAR *) GetPtr(fontsH);
		fInd = fontP->family;
		ReleasePtr(fontsH);
	}

    familyP = fInd + (FontFamily FAR *) GetPtr(fontFamilies);
    familyID = (int)familyP->fID;
    famRef = familyP->familyRef;

    /* check if font already in table */

    fontP = (struct tutorfont FAR *) GetPtr(fontsH);
    tfP = fontP;
    for (fi=0; fi<nfonts; fi++) {
	    if ((tfP->fID == familyID) && (tfP->size == size) &&
		(tfP->textface == face) && tfP->fptr) {
            ReleasePtr(fontsH);
            ReleasePtr(fontFamilies);
            return(fi); /* return index in table */
        }
	    tfP++; /* advance pointer in font table */
    } /* fi for */

    /* check for recognized font name */

    famN = famRef.path;
    if (famN[0] == '\\') { /* file path, not symbolic name */
	    ;
    } else if (strcmpf(famN, (char FAR *) ziconsStr) == 0) {
	    fpcF = TRUE; /* known fpc format font */
    } else if (strcmpf(famN, (char FAR *) zcursorsStr) == 0) {
	    fpcF = TRUE;
    } else if (strcmpf(famN, (char FAR *) zpatternsStr) == 0) {
	    fpcF = TRUE;
        if (zpatternsF < 0) 
            defFillF = TRUE; /* need to set zpatternsF */
    } else if (strcmpf(famN, (char FAR *) "zsans") == 0) {
	    wSymbolicF = TRUE; /* known windows font */
    } else if (strcmpf(famN, (char FAR *) "zserif") == 0) {
	    wSymbolicF = TRUE;
    } else if (strcmpf(famN, (char FAR *) "zfixed") == 0) {
	    wSymbolicF = TRUE;
    } else if (strcmpf(famN, (char FAR *) "zsymbol") == 0) {
	    wSymbolicF = TRUE;
    } else if (strcmpf(famN, (char FAR *) "system") == 0) {
	    wSymbolicF = TRUE;
    }

    ReleasePtr(fontsH);
    ReleasePtr(fontFamilies);

    /* handle recongized Windows font */

    if (wSymbolicF) {
	    ftIndex = font_ptr_win(fInd,size,face,TRUE);
	    if (ftIndex >= 0)
	        return(ftIndex); /* got the font */
    }

    /* handle recognized fpc format font (zicons, zpatterns, zcursors) */

    if (fpcF) {
	    /* zicons, zpatterns, zcursors must be in cT directory */
	    TUTORcopy_fileref_dir((FileRef FAR *) &fpcRef,ctDirP);
	    strcatf((char FAR *)fpcRef.path,famN);
	    strcatf((char FAR *)fpcRef.path,(char FAR *)".fpc");
	    ftIndex = font_ptr_fpc(&fpcRef,fInd,size,face);
	    if (ftIndex >= 0) {
            if (defFillF) 
                zpatternsF = ftIndex; /* set index of zpatterns */
	        return(ftIndex); /* got the font */
        }
    }

    /* attempt to read fpc file */

    ftIndex = font_ptr_fpc(&famRef,fInd,size,face);
    if (ftIndex >= 0)
	    return(ftIndex); /* got the font */
    len = strlen(famRef.path); /* get length of (presumed) file name */
    if (len) {
	    si = len-1;
	    while ((si > 0) && (famRef.path[si] != '.') && (famRef.path[si] != '\\'))
	        si--; /* search backwards for period */
	    if (famRef.path[si] != '.')
	        strcat(famRef.path,".fpc");
	    ftIndex = font_ptr_fpc(&famRef,fInd,size,face);
	    if (ftIndex >= 0)
	        return(ftIndex); /* got the font */
    }

    /* attempt to obtain windows font */

    ftIndex = font_ptr_win(fInd,size,face,FALSE);
    if (ftIndex >= 0)
	    return(ftIndex); /* got the font */

    return(0); /* take first entry in table */

} /* TUTORfont_ptr */

/* *********************************************************************** */

static char s_sizehw[156] =  { 10, 4,11, 5,14, 7,16, 8,19, 9,24,13,
/* zfixed bold */		        9, 5,11, 6,14, 8,16, 8,20,10,25,14,
/* zfixed italic */		        9, 5,11, 6,14, 9,16, 9,19,11,24,16,
/* zfixed bold italic */	    9, 6,11, 7,14, 9,16,10,20,12,25,17,
/* zsans */		               11, 4,13, 5,15, 7,17, 8,22,11,29,15,
/* zsans bold */	           11, 5,13, 7,15, 8,17, 9,22,12,29,16,
/* zsans italic */	           11, 6,13, 8,15,10,17,11,22,12,29,19,
/* zsans bold italic */ 	   11, 6,13, 8,15,10,17,12,22,15,29,20,
/* zserif */		           10, 6,13, 7,15, 8,18,10,21,12,28,18,
/* zserif bold */	           10, 5,13, 7,15, 8,18,11,21,14,28,16,
/* zserif italic */	           10, 6,13, 8,15, 9,18, 9,22,14,29,18,
/* zserif bold italic */       10, 7,13, 9,15,10,17,10,21,15,28,18,
/* zsymbol */		           11, 5,14, 6,16, 8,20, 9,25,10,32,14 };

static int font_ptr_win(fInd,size,face,known) /* set up specified Windows font */
int fInd; /* index of family in font family table */
int size; /* size desired */
unsigned int face; /* face style desired */
int known; /* TRUE if recognized (cT) Windows font */

{   struct tutorfont FAR *fontp; /* pointer to font table entry */
    FontFamily FAR *familyp; /* pointer to font family table entry */
    int familyid; /* id of font family */
    char family[FILEL]; /* family name */
    long fonth; /* handle on logical font */
    int fi; /* index in font table */
    FileRef fontRef; /* (psuedo) file reference for font */
    int size_si; /* index in size table */
    int symbolF; /* TRUE if symbol font */
    int alphaIcon; /* TRUE if alpha icons */
    int fsi; /* index in face name string */
    char FAR *styleP; /* pointer to style string */
    char actual_face[82]; /* face name of font obtained */
 
    /* parameters for CreateFont call */

    short nheight; /* character height */
    short nwidth; /* character width */
    short nescapement; /* angle of line of text */
    short norientation; /* angle of character baseline */
    short nweight; /* character weight 400=normal, 700=bold */
    BYTE citalic; /* TRUE if italic */
    BYTE cunderline; /* TRUE if underlined */
    BYTE cstrikeout; /* TRUE if characters struck out */
    BYTE ccharset; /* character set type (ANSI, OEM) */
    BYTE coutputprecision; /* closeness of character match */
    BYTE cclipprecision; /* type of clipping */
    BYTE cquality; /* always PROOF_QUALITY for CT */
    BYTE cpitchandfamily; /* fixed, proportional, modern, roman, etc */
    LPSTR lpfacename; /* pointer to face name */
	char wkName[CTPATHLEN+2]; /* font name */
     
	/* if executor window, be sure to have device context */
	
	if ((CurrentWindow == ExecWn) && (CurrentWinH == (HWND)windowsP[ExecWn].wp)) {
        if (!HaveDC) {
            CurrentDC = cTGetDC(CurrentWinH);
        }	
	}
	
    /* get family table entry */

    familyp = fInd + (FontFamily FAR *) GetPtr(fontFamilies);
    familyid = (int)familyp->fID;
    fontRef = familyp->familyRef;
    strcpyf((char FAR *)family,(char FAR *)fontRef.path);

    /* set up default assumptions */

    symbolF = FALSE; /* not symbol font */
    alphaIcon = 0;
    nheight = size;
    nwidth = 0; /* match width against aspect ratio */
    nescapement = 0; /* no rotation of lines of text */
    norientation = 0; /* no rotation of characters */
    nweight = ((face & style_bold) ? FW_BOLD: FW_NORMAL);
    citalic = ((face & style_italic) ? TRUE: FALSE);
    cunderline = FALSE;
    cstrikeout = FALSE;
    ccharset = ANSI_CHARSET;
    coutputprecision = OUT_DEFAULT_PRECIS;
    cclipprecision = CLIP_DEFAULT_PRECIS;
    cquality = PROOF_QUALITY;
    cpitchandfamily = VARIABLE_PITCH | FF_DONTCARE;

    size_si = -1; /* don't have info on size */
    fonth = 0L; /* don't have font yet */
    if (strcmp(family,("zserif")) == 0) {
        cpitchandfamily = VARIABLE_PITCH | FF_ROMAN;
		lpfacename = "zserif";
		size_si = 96;
    } else if (strcmp(family,"zsans") == 0) {
        cpitchandfamily = VARIABLE_PITCH | FF_SWISS;
		lpfacename = "zsans";
		size_si = 48;
    } else if (strcmp(family,"zfixed") == 0) {
        cpitchandfamily = FIXED_PITCH | FF_MODERN;
		lpfacename = "zfixed";
		size_si = 0;
    } else if (strcmp(family,"zsymbol") == 0) {
        cpitchandfamily = VARIABLE_PITCH | FF_DONTCARE;
		lpfacename = "zsymbol";
		size_si = 144;
		symbolF = TRUE; /* symbol font */
    } else if (strcmp(family,"system") == 0) {
		cpitchandfamily = VARIABLE_PITCH | FF_SWISS;
		lpfacename = "system";
		fonth = (long)(char FAR *)GetStockObject(SYSTEM_FONT);
		size = 10; /* size always the same */
    } else {
		ccharset = DEFAULT_CHARSET;
		cclipprecision = CLIP_TT_ALWAYS;
		cpitchandfamily = VARIABLE_PITCH | FF_DONTCARE | TMPF_TRUETYPE;
		coutputprecision = OUT_TT_PRECIS;
		if (!(face & style_bold) && !(face & style_italic))
	    	nweight = FW_DONTCARE;
        	lpfacename = family;
		fsi = strlenf((char FAR *)lpfacename)-1;
        while (fsi >= 0) { /* search backwards in case path */
            if (*(lpfacename+fsi) == '\\') {
                lpfacename = lpfacename+fsi+1;
                break; /* exit while */
            }
            fsi--;
        } /* while */
    } /* default else */
	strcpyf(wkName,lpfacename); /* get temp copy of name */
	lpfacename = wkName; /* point to temp, so can modify */

    /* convert font size to width, height if known font */
    /* update face name if bold or italic */

    if (size_si >= 0) { /* know about this font's sizes */
		alphaIcon = 1;

        /* remove bold/italic component of name if already present */

		fsi = strlenf((char FAR *)lpfacename);
		if (fsi > 7) {
	    	styleP = lpfacename+fsi-7;
	    	if (strcmpf(styleP,(char FAR *)" italic") == 0)
				*styleP = '\0';
    	}
		fsi = strlenf((char FAR *)lpfacename);
		if (fsi > 5) {
	    	styleP = lpfacename+fsi-5;
	    	if (strcmpf(styleP,(char FAR *)" bold") == 0)
                	*styleP = '\0';
    	}

        /* adjust for bold/italic font */

		if (!symbolF) { /* symbol font doesn't have face styles */
	    	if (face & style_bold) {
				size_si += 12;
				strcatf(lpfacename,(char FAR *)" bold");
				nweight = FW_NORMAL;
	    	}
	    	if (face & style_italic) {
				size_si += 24;
				strcatf(lpfacename,(char FAR *)" italic");
				citalic = FALSE;
	    	}
		} /* symbolF if */

        /* look up weight, height from table */

		if (size >= 24) {
	    	size_si += 10;  
	    	if (size != 24)
	    		ExactMatchFont = FALSE;
		} else if (size >= 18) {
	    	size_si += 8;      
	    	if (size != 18)
	    		ExactMatchFont = FALSE;
		} else if (size >= 14) {
	    	size_si += 6;  
	    	if (size != 14)
	    		ExactMatchFont = FALSE;
		} else if (size >= 12) {
	    	size_si += 4;
	    	if (size != 12)
	    		ExactMatchFont = FALSE;
		} else if (size >= 10) {
	    	size_si += 2;  
	    	if (size != 10)
	    		ExactMatchFont = FALSE;   
		} else if (size != 8)
			ExactMatchFont = FALSE;
		nheight = s_sizehw[size_si];
		nwidth = s_sizehw[size_si+1];
    } else if (!known) {
		if (HaveDC) {
	    	nheight = -((size*GetDeviceCaps(CurrentDC,LOGPIXELSY))/72);
		}
    } /* size_si else */

    /* create instance of font */

    if (!fonth) {
		fonth = (long)(char FAR *)CreateFont(
	    	nheight,	    /* character height */
	    	nwidth,	    /* character width */
	    	nescapement,    /* angle of line of text */
	    	norientation,   /* angle of character baseline */
	    	nweight,	    /* character weight 400=normal, 700=bold */
	    	citalic,	    /* TRUE if italic */
	    	cunderline,     /* TRUE if underlined */
	    	cstrikeout,     /* TRUE if characters struck out */
	    	ccharset,	    /* character set type (ANSI, OEM) */
	    	coutputprecision, /* closeness of character match */
	    	cclipprecision, /* type of clipping */
	    	cquality,	    /* always PROOF_QUALITY for CT */
	    	cpitchandfamily,  /* fixed, prop, modern, roman, etc */
	    	lpfacename);    /* face name */
    }
    if (fonth == NIL) {
		ReleasePtr(fontFamilies); 
		ExactMatchFont = FALSE;
		return(-1); /* didn't work */
    }

    /* check if obtained desired font */

    if (HaveDC) {
		SelectObject(CurrentDC,(HGDIOBJ)fonth);
		GetTextFace(CurrentDC,80,(LPSTR)&actual_face[0]);
		if (strcmpf((char FAR *)&actual_face[0],lpfacename))
	    	ExactMatchFont = FALSE;
    }
		
    /* get a font table entry */

    fontp = (struct tutorfont FAR *) GetPtr(fontsH);
    for (fi = 0; (fi<nfonts && fontp->fID >= 0); fi++, fontp++);
    if (fi >= nfonts) { /* need to make font table bigger */
        ReleasePtr(fontsH);
        extend_font_table(4);
        fontp = fi + (struct tutorfont FAR *) GetPtr(fontsH);
    }

    /* set up font table entry */

    TUTORcopy_fileref(&fontp->fontfile,(FileRef FAR *) &fontRef);
    fontp->family = fInd;
    fontp->fID = familyid;
    fontp->textface = face;
    fontp->size = size;
    fontp->sysFlag = TRUE;
    fontp->alphaIcon = alphaIcon;
    fontp->fptr = fonth;
    fontp->datType = 0; /* windows font */
    fontp->nheight = nheight; /* character height */
    fontp->nwidth = nwidth; /* character width */
    fontp->nweight = nweight; /* character weight 400=normal, 700=bold */
    fontp->citalic = citalic; /* TRUE if italic */
    fontp->cpitchandfamily = cpitchandfamily; /* fixed, proportional, modern, roman, etc */
    strncpyf((char FAR *)&fontp->cfacename[0],lpfacename,32); /* font face name */
    ReleasePtr(fontsH);
    ReleasePtr(fontFamilies);
    return(fi); /* return index in font table */

} /* font_ptr_win */

/* *********************************************************************** */

static int font_ptr_fpc(fontRef,fInd,size,face) /* set up fpc format font */
FileRef *fontRef; /* path to *.fpc file */
int fInd; /* index in font table */
int size; /* font size */
int face; /* font face style */

{   FontFamily FAR *ffP; /* pointer to family table entry */
    struct tutorfont FAR *foP; /* pointer to font table entry */
    Memh fpcH; /* handle on fpc file contents */
    struct pcfont FAR *fpcP; /* pointer to file contents */
    int fi; /* index in font table */

    fpcH = read_fpc((FileRef FAR *)fontRef);
    if (fpcH == HNULL)
	    return(-1); /* didnt find the file */

    /* get a font table entry */

    ffP = fInd + (FontFamily FAR *) GetPtr(fontFamilies);
    foP = (struct tutorfont FAR *) GetPtr(fontsH);
    for (fi = 0; (fi<nfonts && foP->fID >= 0); fi++, foP++);
    if (fi >= nfonts) { /* need to make font table bigger */
        ReleasePtr(fontsH);
        extend_font_table(4);
	foP = fi + (struct tutorfont FAR *) GetPtr(fontsH);
    }

    /* set up font table entry */

    TUTORcopy_fileref(&foP->fontfile,(FileRef FAR *) &fontRef);
    foP->family = fInd;
    foP->fID = ffP->fID;
    foP->textface = face;
    foP->size = size;
    foP->sysFlag = FALSE;
    foP->alphaIcon = foP->codeSize = 0;
    foP->fptr = fpcH;
    foP->datType = 1; /* fpc format font */
    fpcP = (struct pcfont FAR *)GetPtr(fpcH);
    if (fpcP->format & 4)
        foP->codeSize = 1; /* 16-bit encoding */
    ReleasePtr(fpcH);

    ReleasePtr(fontsH);
    ReleasePtr(fontFamilies);

    return(fi); /* return index in font table */

} /* font_ptr_fpc */

/* *********************************************************************** */

int TUTORrelease_font(findx,fam,size,face,forget) /* forget about previously known font */
int findx; /* index in font family table (use fam/size/face if -1) */
long fam; /* font family id (not index) */
int size; /* system size */
unsigned int face; /* face code */
int forget; /* forget this instance of font */

{   struct tutorfont FAR *fp;
    int ii;

    fp = (struct tutorfont FAR *) GetPtr(fontsH);
    if (findx >= 0) {
        fp += findx; /* select table entry */
    } else {
        /* look up font in table */
        for (ii=0; ii<nfonts; ii++,fp++) {
            if (fp->fID == fam && fp->size == size && fp->textface == face) {
                findx = ii; /* found the font */
                break;
            } 
        } /* for */
    } /* findx else */
    if (findx >= 0) {
        fp->nusers--; /* decrement users of this font */
        if (forget) {
	    if (fp->nusers == 0) {
		fp->fID = 0; /* recycle this slot */
		if ((fp->datType == 1) && (fp->fptr)) { /* fpc format file */
		    TUTORfree_handle((Memh)fp->fptr);
		    fp->fptr = HNULL;
		} else if ((fp->datType == 0) && (fp->fptr)) { /* windows */
		    DeleteObject((HGDIOBJ)fp->fptr);
		    fp->fptr = HNULL;
		}
	    } else {
		fp->fID = DummyFontID(); /* invalidate this slot */
	    }
        }
    } /* findx if */
    ReleasePtr(fontsH);
   
    return(0);

} /* TUTORrelease_font */

/* *********************************************************************** */

static int otherID = 1001; /* 1000+ gives unique id's */

long MyFontID(famName,isSys, iso,cTknown)
FileRef *famName; /* either a complete path (file reference), or reference to system font */
int isSys; /* TRUE if is a system font */
int *iso;
int *cTknown;

{
    *iso = *cTknown = 1; /* all fonts on pc are iso */
    return(otherID++);

} /* MyFontID */

/* *********************************************************************** */

int DummyFontID()

{
    return(otherID++);

} /* DummyFontID */

/* *********************************************************************** */

/* oldCR is Yy font size, newCR is newline font size */
static short oldCR[] = {10, 12, 13, 17, 22, 22, 10, 12, 14, 18, 24, 24}; /* serif info, sans info */
static short newCR[] = {11, 13, 15, 19, 25, 25, 11, 13, 15, 20, 26, 26};

static short fAvailSizes[] = {8, 10, 12, 16, 22, 22};
/* note that the # of font sizes should == NFSIZES */

static short fAvailSizesX[] = {8, 10, 12, 14, 18, 24};

static short oldserifCRX[] = {7, 9, 12, 13, 17, 22}; /* serif info */
static short newserifCRX[] = {11, 12, 15, 17, 22, 29};
static short oldsansCRX[] = {7, 10, 12, 14, 18, 24};  /* sans info */
static short newsansCRX[] = {10, 14, 16, 18, 23, 30};
static short oldfixedCRX[] = {7, 8, 11, 12, 15, 19}; /* fixed info */
static short newfixedCRX[] = {11, 13, 15, 20, 24, 32};
static short oldsymbolCRX[] = {8, 9, 12, 13, 17, 22}; /* symbol info */
static short newsymbolCRX[] = {12, 15, 17, 21, 26, 33};

/* *********************************************************************** */

TUTORround_font_size(size)
int size;
/* returns proper system size corresponding to size */

{   short *sz;
    int ii;
    
    sz = fAvailSizesX; /* since we are using X11 fonts */
    
    for (ii=1; ii<6; ii++) {
        if (size < sz[ii])
            return(sz[ii-1]);
    } /* for */
    return(sz[ii-1]); /* largest size */

} /* TUTORround_font_size */

/* in TUTORfont_sizes, if there are not copies of the font for all sizes, fill out the size
table for what exists, then finish the size table with -1 in all places */

int TUTORfont_sizes(id,fontN) /* fill out font family sizes */ /* wm and X11 version */
/* called by ctgraph.c */
long id; /* font id - unused */
int fontN; /* index in fontFamilies table */

/*
   In the following table, Yy is the height from top of Y to bottom of y,
   CR is height of newline (top of Y to top of Y on next line),
   and leading is space between lines (using BE1 display routines).
   If NewFontSize is TRUE, CharHeight represents CR rather than Yy.
   "n" is width of n; "avg." is average width of lower-case letters.
   In parentheses are shown hypothetical CR and leading values based
   on proportional scaling from the 12-point font.

   BE1 format.c calculated CR from the font info on NorthToSouth (total height
   including allowance for leading) plus extra space to allow for a 5-dot-high
   editing caret not to hit the line beneath it.  That is, extra leading was added
   if necessary so that descenders plus leading was enough for the editing caret.
   NWtoOrigin is the height of an upper-case letter.  BE1 format.c checked for
   NtoS - NWtoOrigin being >= 5 for the editing caret.

   FONT        Yy    CR    leading    n    avg.    avg/CR    NtoS        NWtoOrigin
   andy8    09    12 (11)    3 (2)    5    4.81    .40 (.44)    11 (+1 for CR)    7
   andy10    12    14 (13)    2 (1)    6    5.58    .40 (.43)    13 (+1 for CR)    9
   andy12    13    15 (15)    2 (2)    7    6.50    .43 (.43)    15        10
   andy16    17    18 (19)    1 (2)    10    8.35    .46 (.44)    18        13
   andy22    22    24 (25)    2 (3)    13    11.08    .46 (.44)    24        18

   andysans8    10    12 (11)    2 (1)    6    5.15    .43 (.47)    10 (+2 for CR)    7
   andysans10    12    13 (13)    1 (1)    7    6.11    .47 (.47)    12 (+1 for CR)    8
   andysans12    14    15 (15)    1 (1)    8    6.96    .46 (.46)    14 (+1 for CR)    10
   andysans16    18    18 (20)    0 (2)    10    9.23    .51 (.46)    18        13
   andysans22    24    25 (26)    1 (2)    14    12.19    .49 (.47)    25        19
*/

{   short ii, offset;
    FontFamily FAR *fFam;
    short *p1, *p2;
    char fontName[FILEL+1];

    fFam = fontN + (FontFamily FAR *) GetPtr(fontFamilies);
    offset = 0;
    TUTORget_fileref_name(&fFam->familyRef,(char FAR *) fontName);
    if (!strcmp("helv",fontName)) {
	p1 = oldsansCRX;
	p2 = newsansCRX;
    } else if (!strcmp("cour",fontName)) {
	p1 = oldfixedCRX;
	p2 = newfixedCRX;
    } else if (!strcmp("symb",fontName)) {
	p1 = oldsymbolCRX;
	p2 = newsymbolCRX;
    } else {
	p1 = oldserifCRX;
	p2 = newserifCRX;
    }
    for (ii=0; ii<NFSIZES; ii++) {
	fFam->famSizes[0][ii] = fAvailSizesX[ii];
	fFam->famSizes[1][ii] = *(p1+ii);	  /* Yy height definition */
	fFam->famSizes[2][ii] = *(p2+ii); /* newline height definition */
    } /* for */

    ReleasePtr(fontFamilies);
    return(0);

} /* TUTORfont_sizes */

/* ******************************************************************* */

TUTORinq_font_info(ascent,descent,maxwidth,leading)
int *ascent;    /* maximum ascent above base line */
int *descent;    /* maximum descent below base line */
int *maxwidth;    /* maximum character width */
int *leading;    /* leading (extra fill between lines) */

{   struct pcfont FAR *fpcP; /* pointer to fpc font */
    TEXTMETRIC textm; /* text info structure */
    int ret;

    if (CurrentFontType == 0) { /* normal windows font */

	    /* return info for Windows font */

	    ret = GetTextMetrics(CurrentDC,(LPTEXTMETRIC)(&textm));
	    if (ret == 0) {
	        TUTORzero((char FAR *)&textm,(long)sizeof(TEXTMETRIC));
	    } /* ret if */
        if (ascent)
	        *ascent = textm.tmAscent;
        if (descent)
	        *descent = textm.tmDescent;
        if (maxwidth)
	        *maxwidth = textm.tmMaxCharWidth;
        if (leading)
	        *leading = textm.tmExternalLeading;
    } else if (CurrentFontType == 1) { /* cT fpc format font */

	    /* return info for FPC font */

	    fpcP = (struct pcfont FAR *)GetPtr((Memh)CurrentFontH);
	    if (ascent)
	        *ascent =  fpcP->ascent;
	    if (descent)
	        *descent = fpcP->descent;
	    if (maxwidth)
	        *maxwidth = fpcP->maxwidth;
	    if (leading)
	        *leading = fpcP->newline-(fpcP->ascent+fpcP->descent);
	    ReleasePtr((Memh)CurrentFontH);
    } /* CurrentFontType if */

    return 0;

} /* TUTORinq_font_info */

/* ************************************************************************* */

static Memh read_fpc(fpcPath) /* read specified fpc file from disk */
FileRef FAR *fpcPath;
    
{   Memh fpcH; /* handle on fpc file contents */
    struct pcfont FAR *fpcP; /* pointer to fpc file contents */
    long ferr; /* file operations error return */
    long fsize; /* file size */
    int fileI; /* file index */
    int fii; /* index in file name */
    int fnl; /* length of file name */

    fpcH = HNULL;

    /* check if this "file" is actually a resource */

    fnl = strlenf(fpcPath->path);
    if ((fnl >= 12) && (strcmpf(fpcPath->path+fnl-12,"zcursors.fpc") == 0)) {
		fpcH = LoadTable(zcursorsStr,&fii);
    } else if ((fnl >= 10) && (strcmpf(fpcPath->path+fnl-10,"zicons.fpc") == 0)) {
		fpcH = LoadTable(ziconsStr,&fii);
    } else if ((fnl >= 12) && (strcmpf(fpcPath->path+fnl-12,"zpattern.fpc") == 0)) {
		fpcH = LoadTable(zpatternsStr,&fii);
    } else if ((fnl >= 13) && (strcmpf(fpcPath->path+fnl-13,"zpatterns.fpc") == 0)) {
		fpcH = LoadTable(zpatternsStr,&fii);
    }
    if (fpcH)
		return(fpcH);

    /* open fpc file */

    fileI = TUTORopen(fpcPath,TRUE,FALSE,FALSE);
    if (fileI == 0) {
		fii = strlenf(fpcPath->path);
		if ((fii > 4) &&
			(strcmpf(fpcPath->path+fii-4,(char FAR *)".fct") == 0)) {
			fpcPath->path[fii-4] = 0;
			strcatf(fpcPath->path,(char FAR *)".fpc");
			fileI = TUTORopen(fpcPath,TRUE,FALSE,FALSE);
		} /* fii if */
    } /* fileI if */
    if (fileI == 0)
		return(HNULL);

    /* determine size of fpc file */

    TUTORinq_file_info(fpcPath,NEARNULL,&fsize,NEARNULL,NEARNULL,NEARNULL);
    if (fsize <= 0) {
		TUTORclose(fileI);
        return(HNULL);
    }

    /* allocate memory and read fpc file from disk */

    fpcH = TUTORhandle("fpc",(long)fsize,FALSE);
    fpcP = (struct pcfont far *)GetPtr(fpcH);
    ferr = TUTORread((char FAR *)fpcP,1,(long)fsize,fileI);
    TUTORclose(fileI);
    if (ferr != fsize) {
		ReleasePtr(fpcH);
		TUTORfree_handle(fpcH);
        return(HNULL);
    }
    ReleasePtr(fpcH);

    return(fpcH);

} /* read_fpc */

/* ******************************************************************* */

Memh wmg_load_font(fRef,index) 
FileRef FAR *fRef;
int index;

{
	return(read_fpc(fRef));
	
} /* wmg_load_font */

/* ******************************************************************* */

displayffv(x,y,op,format,value) /* display formatted floating value */
/* used for putting labels on graphs */
int x;      /* x co-ordinate */
int y;      /* y co-ordinate */
int op;     /* 0 = top, between left and right */
        /* 1 = bottom, between left and right */
        /* 2 = left, between top and bottom */
        /* 3 = right, between top and bottom */
int format;   /* 1 = G, 2 = E */
double value;   /* floating value to display */

{   char s[60];
    int slen, ascent, descent, dx;
    int dummy;

    sprintf(s, "%G", value);
    slen = strlen(s);
    TUTORinq_abs_string_width((unsigned char far *) s,slen,&dx);
    TUTORinq_font_info(&ascent,&descent,&dummy,&dummy);
    if ((ascent+descent) < CurrentView->newlineH)
	ascent += CurrentView->newlineH-(ascent+descent);

    switch (op) {
    case 0:
        x -= (dx >> 1);
        y += ascent;
        break;
    case 1:
        x -= (dx >> 1);
        y -= descent;
        break;
    case 2:
        y += (ascent >> 1);
        break;
    case 3:
        x -= dx;
        y += (ascent >> 1);
        break;
    } /* switch */

    TUTORabs_move_to(x,y);
    TUTORdraw_text((unsigned char far *)s,slen); 
    return(0);

} /* displayffv */

/* ******************************************************************* */

#ifdef NOSUCH

TUTORdraw_char(ch)      /* output single character */
char ch;

{   POINT xypos;     /* x,y position */
    struct tutorfont FAR *fontP; /* pointer to font table entry */
    Memh fpcH; /* handle on fpc-format font */
    int descent,leading;
    int deltaX; /* x width of character */
    RECT rc; /* character rectangle */
    int nMapBytes; /* bytes needed for bitmap */
    char FAR *scrBitP; /* pointer to bitmap bits */
    HBITMAP OldMapH; /* handle on previous bitmap */

    if (ch == NEWLINE) return(0);
    if (CurrentFontType == 0) { /* windows font */
	if (CurrentMode == SRC_XOR) {
            if (f_height < 0) {

                /* get maximum character size from font */

		TUTORinq_font_info(&f_ascent,&descent,&f_maxwidth,&leading);
                f_height = f_ascent+descent+leading;

                /* allocate memory for bitmap to define size */

                nMapBytes = ((f_maxwidth+15) >> 4) << 4; /* width in words */
                nMapBytes *= f_height; /* bytes needed for bitmap */
                if (nMapBytes >= scrBitSize) {
                    scrBitSize = nMapBytes+16; /* reset size */
                    TUTORset_hsize(scrBitH,scrBitSize,TRUE);
                } /* nMapBytes if */
            }
            if (HaveMemDC != 2) {
                fpc_mem_dc(2); /* obtain memory context for char xor */

                /* initialize context */

                SetTextAlign(hMemDC,TA_UPDATECP | TA_BASELINE);
		        SetBkColor(hMemDC,RGB(255,255,255));
		        SetTextColor(hMemDC,RGB(0,0,0));
		        SetBkMode(hMemDC,OPAQUE);

                /* create a bitmap and select into memory */
                /* device context to set size of context to */
                /* maximum for this font */

                scrBitP = (char FAR *)GetPtr(scrBitH);
                CDefBitMapH = CreateBitmap(f_maxwidth,f_height,1,1,scrBitP);
		OldMapH = SelectObject(hMemDC,CDefBitMapH); /* put bitmap in context */
		if (!OMemBitMapH)
		    OMemBitMapH = OldMapH;
                SetRect(&rc,0,0,f_maxwidth,f_height) ;
                FillRect(hMemDC,&rc,(HBRUSH)GetStockObject(WHITE_BRUSH));
                ReleasePtr(scrBitH);
		fontP = textFont + (struct tutorfont FAR *) GetPtr(fontsH);
		CFontH = fontP->fptr;
		ReleasePtr(fontsH);
                OMemFontH = SelectObject(hMemDC,CFontH);
            } /* HaveMemDC if */

            /* plot text in memory context */

	        SelectObject(hMemDC,CDefBitMapH);
            MoveTo(hMemDC,0,f_ascent);
            TextOut(hMemDC,0,f_ascent,(LPCSTR)(&ch),1);
            GetCurrentPositionEx(hMemDC,&xypos);
            deltaX = xypos.x;

            /* blit into current context */

	    SetBkColor(CurrentDC,RGB(0,0,0));
	    SetTextColor(CurrentDC,RGB(255,255,255));
            BitBlt(CurrentDC,RealX,RealY-f_ascent,deltaX,f_height,
                   hMemDC,0,0,SRCINVERT);
            RealX += deltaX;
            if (ch == ' ') {
                RealX += (SpaceShim >> 16);
            } /* space if */

	    /* clean up */

	    SelectObject(hMemDC,OMemBitMapH);
            if (colorInvert) {
                SetTextColor(CurrentDC,bkRef);
                SetBkColor(CurrentDC,frRef);
            } else {
                SetTextColor(CurrentDC,frRef);
                SetBkColor(CurrentDC,bkRef);
            }
            return(0);
        } /* CurrentMode if */
        MoveTo(CurrentDC,RealX,RealY);
        SetTextAlign(CurrentDC,TA_UPDATECP | TA_BASELINE);
        TextOut(CurrentDC,RealX,RealY,(LPCSTR)(&ch),1);
        xypos = GetCurrentPosition(CurrentDC);
        RealX = LOWORD(xypos);
        if (ch == ' ') {
            RealX += (SpaceShim >> 16);
        } /* space if */
    } else if (CurrentFontType == 1) { /* fpc font */
        fontP = textFont+(struct tutorfont FAR *)GetPtr(fontsH);
		fpcH = fontP->fptr; /* get handle on fpc file */
	    fpc_draw_char(fpcH,FARNULL,ch); /* draw fpc-format character */
        ReleasePtr(fontsH);
        if (ch == ' ') {
            RealX += (SpaceShim >> 16);
        } /* space if */
    } /* CurrentFontType else-if */

    return(0);

} /* TUTORdraw_char */

/* ******************************************************************* */

TUTORdraw_text(buf,count)       /* output text string */
char FAR *buf;  /* pointer to buffer containing text */
int count;      /* number characters to plot */

{   int i;          /* index in string */

    for (i=0; i<count; i++) {
        TUTORdraw_char(buf[i]);
    } /* for */
    return(0);

} /* TUTORdraw_text */

#endif

/* ******************************************************************* */

draw_chars_fpc(buf,count) /* plot characters from FPC font */
char FAR *buf;  /* pointer to buffer containing text */
int count;      /* number characters to plot */

{   char ch; /* current character */
    int cii; /* index in characters */
    struct tutorfont FAR *fontP; /* pointer to font table entry */
    Memh fpcH; /* handle on fpc-format font */

    if (count <= 0) return(0); /* nothing to do */

    fontP = textFont+(struct tutorfont FAR *)GetPtr(fontsH);
    fpcH = (Memh)fontP->fptr; /* get handle on fpc file */
    for (cii=0; cii<count; cii++) {
	ch = *(buf+cii);
	fpc_draw_char(fpcH,(struct pcfont FAR *)FARNULL,ch); /* draw fpc-format character */
	if (ch == ' ')
	    RealX += (int)(SpaceShim >> 16);
    } /* cii for */
    ReleasePtr(fontsH);

    return(0);

} /* draw_chars_fpc */

/* ******************************************************************* */

draw_chars_win(buf,count) /* plot characters from windows font */
char FAR *buf;  /* pointer to buffer containing text */
int count;      /* number characters to plot */

{   POINT xypos;     /* x,y position */
    struct tutorfont FAR *fontP; /* pointer to font table entry */
    int descent,leading;
    int deltaX; /* x width of character */
    RECT rc; /* character rectangle */
    int nMapBytes; /* bytes needed for bitmap */
    char FAR *scrBitP; /* pointer to bitmap bits */
    HBITMAP OldMapH; /* handle on previous bitmap */
    int lcc; /* last character */

    if (count <= 0) return(0); /* nothing to do */

    if (CurrentMode == SRC_XOR) {

	/* special handling for XOR - Windows can't directly XOR */
	/* text so we build an off-screen bitmap and XOR that */

	if (f_height < 0) {

	    /* get maximum character size from font */

	    TUTORinq_font_info(&f_ascent,&descent,&f_maxwidth,&leading);
	    f_height = f_ascent+descent+leading;

	    /* allocate memory for bitmap to define size */

	    nMapBytes = (((count*f_maxwidth)+15) >> 4) << 4; /* width in words */
	    nMapBytes *= f_height; /* bytes needed for bitmap */
	    if (nMapBytes >= scrBitSize) {
		scrBitSize = nMapBytes+16; /* reset size */
		TUTORset_hsize(scrBitH,scrBitSize,TRUE);
	    } /* nMapBytes if */
	}
	if (HaveMemDC != 2) {
	    fpc_mem_dc(2); /* obtain memory context for char xor */

	    /* initialize context */

	    SetTextAlign(hMemDC,TA_UPDATECP | TA_BASELINE);
	    SetBkColor(hMemDC,RGB(255,255,255));
	    SetTextColor(hMemDC,RGB(0,0,0));
	    SetBkMode(hMemDC,OPAQUE);

	    /* create a bitmap and select into memory */
	    /* device context to set size of context to */
	    /* maximum for this font */

	    scrBitP = (char FAR *)GetPtr(scrBitH);
	    CDefBitMapH = CreateBitmap(count*f_maxwidth,f_height,1,1,scrBitP);
	    OldMapH = SelectObject(hMemDC,CDefBitMapH); /* put bitmap in context */
	    if (!OMemBitMapH)
		OMemBitMapH = OldMapH;
	    SetRect(&rc,0,0,count*f_maxwidth,f_height) ;
	    FillRect(hMemDC,&rc,(HBRUSH)GetStockObject(WHITE_BRUSH));
	    ReleasePtr(scrBitH);
	    fontP = textFont + (struct tutorfont FAR *) GetPtr(fontsH);
	    CFontH = (HFONT)fontP->fptr;
	    ReleasePtr(fontsH);
	    OMemFontH = SelectObject(hMemDC,CFontH);
	} /* HaveMemDC if */

	/* plot text in memory context */

	SelectObject(hMemDC,CDefBitMapH);
	MoveToEx(hMemDC,0,f_ascent,NULL);
	TextOut(hMemDC,0,f_ascent,(LPCSTR)(buf),count);
	GetCurrentPositionEx(hMemDC,&xypos);
	deltaX = xypos.x;

	/* blit into current context */

	SetBkColor(CurrentDC,RGB(0,0,0));
	SetTextColor(CurrentDC,RGB(255,255,255));
	BitBlt(CurrentDC,RealX,RealY-f_ascent,deltaX,f_height,
	       hMemDC,0,0,SRCINVERT);
	RealX += deltaX;
	lcc = *(buf+count-1); /* last character in chunk */
	if (lcc == ' ') {
	    RealX += (int)(SpaceShim >> 16);
	} /* space if */

	/* clean up */

	SelectObject(hMemDC,OMemBitMapH);
	if (colorInvert) {
	    SetTextColor(CurrentDC,bkRef);
	    SetBkColor(CurrentDC,frRef);
	} else {
	    SetTextColor(CurrentDC,frRef);
	    SetBkColor(CurrentDC,bkRef);
	}
	return(0);
    } /* CurrentMode if */

    /* handle normal case (not XOR) */

    MoveToEx(CurrentDC,RealX,RealY,NULL);
    SetTextAlign(CurrentDC,TA_UPDATECP | TA_BASELINE);
    TextOut(CurrentDC,RealX,RealY,(LPCSTR)(buf),count);
    GetCurrentPositionEx(CurrentDC,&xypos);
    RealX = xypos.x;
    lcc = *(buf+count-1); /* last character in chunk */
    if (lcc == ' ') {
	    RealX += (int)(SpaceShim >> 16);
    } /* space if */

    return(0);

} /* draw_chars_win */

/* ******************************************************************* */

TUTORdraw_text(buf,count)       /* output text string */
unsigned char FAR *buf;  /* pointer to buffer containing text */
int count;      /* number characters to plot */

{   int eii; /* ending index to plot */
    int cc; /* current character */
    int doPlot; /* TRUE if have something to plot */

    while (count > 0) {

	/* find next chunk of text to plot */

	/* a space is always the last character in a chunk so */
	/* draw_chars_* can shim */
	/* NEWLINE is a single char chunk which is not drawn */

	eii = 0;
	doPlot = TRUE;
	while (eii < count) {
	    cc = buf[eii++];
	    if (cc == NEWLINE) {
		if (eii == 1)
		    doPlot = FALSE; /* don't draw newline */
		else
		    eii--; /* don't count newline in chunk */
		break; /* end this chunk */
	    } else if (cc == ' ') {
		break; /* end this chunk, space is last char */
	    }
	} /* eii while */

	/* draw chars from Windows or FPC font */

	if (doPlot) {
	    if (CurrentFontType == 0)
		draw_chars_win(buf,eii);
	    else if (CurrentFontType == 1)
		draw_chars_fpc(buf,eii);
	} /* doPlot if */

	/* advance to next chunk */

	buf += eii;
	count -= eii;
    } /* count while */
    return(0);

} /* TUTORdraw_text */

/* ******************************************************************* */

TUTORinq_abs_string_width(s,lth,dx) /* find width and height of string */
unsigned char FAR *s;
int lth;
int *dx;

{   int x;  /* current x position, in current line */
    int y;  /* current y position */
    short stringl; /* string length */
    SIZE xysize;
    int i;  /* index in string */

    if (CurrentFontType != 0)
	    return(0); /* don't know how to handle fpc yet */

    stringl = lth;
    if (stringl) {
        GetTextExtentExPoint(CurrentDC,(LPSTR)(s),stringl,0,NULL,NULL,&xysize);
        x = xysize.cx;
        y = xysize.cy;
        for(i=0; i<stringl; i++) {
            if (s[i] == ' ') x += (int)(SpaceShim >> 16);
        } /* for */
    } /* stringl if */
    if (dx) *dx = x;
    return(x);

} /* TUTORinq_abs_string_width */

/* ************************************************************************* */

int TUTORinq_icon_size(fontid,iconN,dx,dasc,ddes)
int fontid; /* index of font */
int iconN; /* index of icon */
int *dx; /* returned with x width */
int *dasc; /* returned with ascent */
int *ddes; /* returned with descent */

{   struct tutorfont FAR *fontP; /* pointer to font table entry */
    Memh fpcH; /* handle on fpc-format font */
    struct pcfont FAR *fpcP; /* pointer to fpc file contents */
    struct pccharl charDef; /* character description */
    int width; /* width of character */
    char SHUGE *bitP; /* pointer to character bitmap */

    width = 0; /* don't know width yet */
    fontP = fontid+(struct tutorfont FAR *)GetPtr(fontsH);
    if (fontP->datType == 0) { /* windows font */
		;
    } else if (fontP->datType == 1) { /* fpc format font */
		fpcH = (Memh)fontP->fptr; /* get handle on fpc file */
		fpcP = (struct pcfont FAR *)GetPtr(fpcH);
        bitP = fpc_char(fpcP,iconN,&charDef); /* get character description */
        if (dasc)
	        *dasc = fpcP->ascent;
	    if (ddes)
	        *ddes = fpcP->descent;
		ReleasePtr(fpcH);
        if (bitP) 
            width = charDef.pdx; /* x width of character */
    }
    ReleasePtr(fontsH);
    if (dx)
        *dx = width;
    return(width);

} /* TUTORinq_icon_size */

/* ************************************************************************* */

char SHUGE *fpc_char(fpcP,charI,charDef) /* return fpc char info */
/* returns NULL or pointer to bitmap, handle left locked */
struct pcfont FAR *fpcP; /* pointer to fpc file contents */
long charI; /* index of character */
struct pccharl *charDef; /* filled with character definition */

{   struct pcfont16 SHUGE *fpc16P; /* alternate pointer to font header */
    struct pcchars FAR *smallP; /* pointer to small-format char definition */
    struct pccharl FAR *largeP; /* pointer to large-format char definition */
    struct pcchar16 SHUGE *c16P;  /* pointer to 16-bit encoding definition */
    char SHUGE *defP; /* pointer to base of character definitions */
    char SHUGE *mapP; /* pointer to base of character maps */
    long first,last; /* first character, last character */
    int encode16; /* TRUE if 16-bit encoding */
    int eii; /* index in encoding table */
    long cii; /* index in encoding range */
    struct pcccode SHUGE *enP; /* pointer in encoding table */
    long mapBias; /* bias to character bitmap */

    fpc16P = (struct pcfont16 FAR *)fpcP;
    encode16 = (fpcP->format & 4) != 0;
    if (encode16) {
#ifndef CTEDIT	/* bug in MSoft C compiler - bombs on this stuff */
        first = fpc16P->first16;
        last = fpc16P->last16;
        defP = ((char SHUGE *)(fpc16P))+fpc16P->ddef; /* base of defs */
	mapP = ((char SHUGE *)(fpc16P))+fpc16P->dmap; /* base of maps */
#endif
    } else {
	    first = fpcP->first8; /* 8-bit encoding */
	    last = first+fpcP->nchars8-1;
        defP = ((char SHUGE *)(fpcP))+fpcP->ddef; /* base of defs */
        mapP = ((char SHUGE *)(fpcP))+fpcP->dmap; /* base of maps */
    }
    if ((charI < first) || (charI > last))
	    return(FARNULL); /* no character */

    if (encode16) {
#ifndef CTEDIT	/* bug in MSoft C compiler - bombs on this stuff */
	    enP = (struct pcccode SHUGE *)(((char SHUGE *)(fpc16P))+fpc16P->dencod);
        c16P = (struct pcchar16 SHUGE *)FARNULL; /* no pointer yet */
        for (eii=0; eii<fpc16P->nencode; eii++) {
            cii = charI-enP->sRangeE;
            if ((cii >= 0) && (cii < enP->nRange)) {
                cii = cii+enP->sRangeI;
                c16P = ((struct pcchar16 SHUGE *)defP)+cii;
                break; /* exit for */
            }
           enP++;
        } /* for */
        if (c16P == (struct pcchar16 SHUGE *)FARNULL)
            return(FARNULL); /* didn't find character */
        mapBias = c16P->map;
        charDef->map = 0; /* map field too small */
		charDef->pdx = c16P->pdx;
		charDef->pdy = c16P->pdy;
		charDef->bndx = c16P->bndx;
		charDef->bndy = c16P->bndy;
		charDef->mapw = charDef->bnw = c16P->mapw;
		charDef->maph = charDef->bnh = c16P->maph;
		charDef->mapdx = 0;
		charDef->mapdy = 0;
#endif
    } else if (fpcP->format & 1) { /* large format characters */
	    largeP = ((struct pccharl FAR *)defP)+(charI-first);
	    if (largeP->bnw == 0) /* no character */
	        return(FARNULL);
		*charDef = *largeP; /* return character definition */
        mapBias = charDef->map;
    } else {
		smallP = ((struct pcchars FAR *)defP)+(charI-first);
		if (smallP->bnw == 0) /* no character */
	    	return(FARNULL); 
	    mapBias = (long)smallP->map;
		charDef->map = (unsigned int)mapBias;
		charDef->pdx = (signed char)smallP->pdx;
		charDef->pdy = (signed char)smallP->pdy;
		charDef->bndx = (signed char)smallP->bndx;
		charDef->bndy = (signed char)smallP->bndy;
		charDef->bnw = smallP->bnw;
		charDef->bnh = smallP->bnh;
		charDef->mapdx = (signed char)smallP->mapdx;
		charDef->mapdy = (signed char)smallP->mapdy;
		charDef->mapw = smallP->mapw;

		charDef->maph = smallP->maph;
    } /* small else */
    mapP += mapBias;
    return(mapP); /* return pointer  to character bitmap */

} /* fpc_char */

/* ************************************************************************* */

int fpc_draw_char(fontH,fontP,cc) /* draw fpc-format character */
Memh fontH;
struct pcfont FAR *fontP; /* pointer to font header (may be null) */
int cc; /* character number */

{   int fLock; /* TRUE if font locked */
    struct pccharl charDef; /* filled character definition */
    struct pccharl *charDefP; /* pointer to character definition */
    char SHUGE *bitP; /* pointer to character bitmap */
    char FAR *scratchP; /* pointer to scratch bitmap area */
    char FAR *sP; /* pointer within scratch area */
    int colii; /* column index in bitmap */
    int rowii; /* row index in bitmap */
    int oddRow; /* TRUE if odd number bytes/row */
    int rowSize; /* size of row in bytes */
    int scrSize; /* size for scratch bitmap computations */
    int icX,icY; /* actual icon position */
    int preClear; /* TRUE if need to pre-clear background */
    int plotInvert; /* TRUE if need to invert colors for plot */
    int foreZero; /* TRUE if foreground color set to black */
    DWORD clrRop; /* ROP code to pre-clear bitmap */
    DWORD plotRop; /* ROP code to plot bitmap */
    int cacheI; /* index in bitmap cache */
    HBITMAP mapH; /* handle on bitmap */
    HBITMAP OldMapH; /* handle on previous bitmap */
    BITMAP bhdr; /* bitmap header */
    POINT pSize; /* size of bitmap */
    POINT pOrigin; /* origin of bitmap */

    fLock = FALSE; /* haven't locked font yet */
    scratchP = FARNULL; /* haven't locked scratch area yet */

    /* check if alreay have bitmap */

    cacheI = fpc_find_bitmap_cache(fontH,cc,0);
    if (cacheI >= 0) {
	mapH = BitmapCache[cacheI].mapH;
	charDef = BitmapCache[cacheI].charDef;
	charDefP = &charDef;
    } else { /* create monochrome bitmap for character */
        if (fontP == (struct pcfont FAR *)FARNULL) {
            fLock = TRUE; /* need to aquire pointer */
            fontP = (struct pcfont FAR *)GetPtr(fontH);
        } 
        bitP = fpc_char(fontP,cc,&charDef); /* get character info */
        if (bitP == FARNULL) {
            if (fLock) ReleasePtr(fontH);
		return(0); /* no bitmap */
        }
        charDefP = &charDef;

        /* windows insists on even number of bytes in bitmap */
        /* CreateBitmap also can't handle a bitmap that extends */
        /* across segment boundaries - in either case, copy bitmap */
        /* to scratch area */

        scrSize = rowSize = (charDef.mapw+7) >> 3;
        oddRow = (scrSize & 1);
        if ((fontP->format & 4) || oddRow) {
            if (oddRow) scrSize++; /* make even */
            scrSize *= charDef.maph; /* size required */
            if (scrSize > scrBitSize) {
                scrBitSize = scrSize+16; /* reset size */
                TUTORset_hsize(scrBitH,scrBitSize,TRUE);
            }
            scratchP = (char FAR *)GetPtr(scrBitH);
            sP = scratchP;
            for (rowii=0; rowii<charDef.maph; rowii++) {
                for (colii=0; colii<rowSize; colii++) {
                    *sP++ = *bitP++;
                } /* colii for */
                if (oddRow)
                    *sP++ = 0; /* fill in to make even rows */
            } /* rowii for */
            bitP = scratchP; /* reset pointer */
        }

        /* create bitmap */

        mapH = CreateBitmap(charDef.mapw,charDef.maph,1,1,bitP);
        fpc_add_bitmap_cache(fontH,cc,0,mapH,charDefP);
    } /* mapH if */

    if (scratchP) /* release scratch area */
        ReleasePtr(scrBitH);
    if (fLock) /* release fpc font */
        ReleasePtr(fontH); 
    if (mapH == NULL) return(0); /* couldn't create map */

    icX = RealX+charDefP->bndx;
    icY = RealY+charDefP->bndy;
    preClear = plotInvert = foreZero = FALSE;
    clrRop = plotRop = 0;

    switch (CurrentMode) {

    case SRC_COPY: /* rewrite */
        plotInvert = TRUE; 
	plotRop = SRCCOPY;
	break;

    case SRC_OR: /* write */
	plotInvert  = preClear = foreZero = TRUE;
	clrRop = 0x220326;
	plotRop = SRCPAINT;
	break;

    case SRC_BIC: /* erase */
        preClear = foreZero = TRUE;
	clrRop = 0x220326;
	plotRop = SRCPAINT;
	break;

    case SRC_XOR: /* xor */
	plotRop = SRCINVERT;
	foreZero = TRUE;
	break;

    case NOT_SRC_COPY: /*inverse */
        plotRop = SRCCOPY;
        break;       
    } /* switch */
  
	/* select bitmap into memory device context */

    if (HaveMemDC != 1)
        fpc_mem_dc(1); /* create memory device context */
    OldMapH = SelectObject(hMemDC,mapH); /* put bitmap memory context */
    if (!OMemBitMapH)
	OMemBitMapH = OldMapH;
    GetObject(mapH,sizeof(BITMAP),(LPSTR)&bhdr);
    pSize.x = bhdr.bmWidth;
    pSize.y = bhdr.bmHeight;
    DPtoLP(CurrentDC,&pSize,1); /* convert device coords to logical */
    pOrigin.x = pOrigin.y = 0;
    DPtoLP(hMemDC,&pOrigin,1);

    /* if write/erase blit bitmap into window device to mask pixels */

    if (preClear) {
        SetBkColor(CurrentDC,RGB(255,255,255));
        SetTextColor(CurrentDC,RGB(0,0,0));
    	BitBlt(CurrentDC,icX,icY,pSize.x,pSize.y,hMemDC,pOrigin.x,pOrigin.y,clrRop);
    }
    if (plotInvert) {
	SetBkColor(CurrentDC,frRef);
	SetTextColor(CurrentDC,bkRef);
    } else {
        SetBkColor(CurrentDC,bkRef);
        SetTextColor(CurrentDC,frRef);
    }
    if (foreZero) {
	SetTextColor(CurrentDC,RGB(0,0,0));
    }

    /* blit bitmap into window device */

    BitBlt(CurrentDC,icX,icY,pSize.x,pSize.y,hMemDC,pOrigin.x,pOrigin.y,plotRop);

    /* clean up */

    SelectObject(hMemDC,OMemBitMapH);
    RealX += charDefP->pdx; /* increment x */
    if (colorInvert) {
        SetTextColor(CurrentDC,bkRef);
        SetBkColor(CurrentDC,frRef);
    } else {
        SetTextColor(CurrentDC,frRef);
        SetBkColor(CurrentDC,bkRef);
    }
    return(0);

} /* fpc_draw_char */

/* *********************************************************** */

static int fpc_add_bitmap_cache(fontH,charI,type,mapH,cDefP) /* add bitmap to cache */
Memh fontH; /* handle on fpc format font */
int charI; /* index of character */
int type; /* 0 = character, 1 = brush, 2 = inverted brush */
HBITMAP mapH; /* handle on bitmap */
struct pccharl *cDefP; /* pointer to FPC character definition */

{   int ii;
    struct BitmapCacheEntry FAR *bP; /* pointer in cache */

    if (!BitmapCache) {
	BitmapCache = (struct BitmapCacheEntry FAR *)TUTORalloc(
		      (long)BitmapCacheMax*sizeof(struct BitmapCacheEntry),
		      TRUE,"bitmap");
    }
    if (BitmapCacheN == BitmapCacheMax) { /* cache full */
	DeleteObject(BitmapCache[0].mapH);
        BitmapCacheN--; /* decrement items in cache */
        for(ii=0; ii<BitmapCacheN; ii++) /* shove cache down */
            BitmapCache[ii] = BitmapCache[ii+1]; 
    } /* BitmapCacheN if */

    bP = &BitmapCache[BitmapCacheN];
    bP->fontH = fontH; /* handle on fpc font */
    bP->charI = charI; /* index of character */
    bP->type = type; /* character/brush type */
    bP->mapH = mapH; /* handle on bitmap */
    if (cDefP) 
	bP->charDef = *cDefP;
    BitmapCacheN++;
    return(0);

} /* fpc_add_bitmap_cache */

/* *********************************************************** */

int fpc_delete_bitmap_cache(fontH) /* remove bitmap(s) from cache */
Memh fontH; /* handle on fpc format font */

{   int ii,jj,foundF;
    struct BitmapCacheEntry FAR *bP; /* pointer in cache */

    if (!BitmapCache)
	return(0);
    do {
	foundF = FALSE;
	for(ii=0; ii<BitmapCacheN; ii++) {
	    bP = &BitmapCache[ii];
	    if (bP->fontH == fontH) {
		DeleteObject(BitmapCache[ii].mapH);
		foundF = TRUE;
		BitmapCacheN--; /* decrement items in cache */
		for(jj=ii; jj<BitmapCacheN; jj++) {
		    BitmapCache[jj] = BitmapCache[jj+1];
		}
	    } /* fontH if */
	} /* ii for */
    } while (foundF);

} /* fpc_delete_bitmap_cache */

/* *********************************************************** */

fpc_clear_bitmap_cache() /* dump contents of cache */

{   int ii;

    for(ii=0; ii<BitmapCacheN; ii++) {
	DeleteObject(BitmapCache[ii].mapH);
    }
    BitmapCacheN = 0;  
    return(0);

} /* fpc_clear_bitmap_cache */

/* *********************************************************** */

int fpc_find_bitmap_cache(fontH,cc,type) /* find cached bitmap */
Memh fontH; /* handle on fpc font */
int cc; /* index of character */
int type; /* 0 = character, 1 = brush, 2 = inverted brush */

{   int cacheI; /* index in bitmap cache */
    struct BitmapCacheEntry FAR *bP; /* pointer in bitmap cache */
    
    /* check if bitmap in cache */

    bP = &BitmapCache[0];
    for(cacheI=0; cacheI<BitmapCacheN; cacheI++) {
        if ((bP->type == type) && (bP->fontH == fontH) && 
            (bP->charI == cc)) 
            return(cacheI);
        bP++;
    } /* for */
    return(-1);

} /* fpc_find_bitmap_cache */

/* *********************************************************** */

HDC fpc_mem_dc(type)
int type; /* type of useage */
          /* 0 = none, 1 = icon plot, 2 = text xor */

{   HBITMAP mapH;
    int bitS = 0;
    char FAR *bitP; /* pointer to bits */

    if (type && (type == HaveMemDC)) 
        return(hMemDC); /* already have context */

    /* get rid of previous memory device context */

    if (HaveMemDC) {
        if ((HaveMemDC == 1) || (HaveMemDC == 2)) {
            if (OMemBitMapH)
                SelectObject(hMemDC,OMemBitMapH); /* restore original */
	   if (CDefBitMapH) {
		DeleteObject(CDefBitMapH);
	    }
            CDefBitMapH = HNULL;
            if (CFontH) {
                SelectObject(hMemDC,OMemFontH); /* restore original */
		CFontH = HNULL;
            }
        }
        DeleteDC(hMemDC);
        HaveMemDC = 0;
        OMemBitMapH = HNULL;
    }
    if (!type)
        return(HNULL); /* nothing further to do */

    /* create compatible device context */

    HaveMemDC = type; /* remember what DC was used for */
    hMemDC = CreateCompatibleDC(CurrentDC);
    if ((type == 1) || (type == 2)) { /* icon or xor will use bitmap */
        /* create a dummy bitmap, use SelectObject to get */
        /* handle on original bitmap object setting, then */
        /* delete dummy bitmap */
        bitP = (char FAR *)&bitS;
        mapH = CreateBitmap(1,1,1,1,bitP);
        OMemBitMapH = SelectObject(hMemDC,mapH); /* get original setting */
	SelectObject(hMemDC,OMemBitMapH); /* restore original setting */
	DeleteObject(mapH);
    }
    return(hMemDC);

} /* fpc_mem_dc */

/* *********************************************************** */

static HBRUSH fpc_brush(pattF,pattC,invertF) /* build brush from fpc char */
int pattF; /* index in font table */
int pattC; /* brush pattern character # */
int invertF; /* TRUE if should invert bitmap */

{   struct tutorfont FAR *fontP; /* pointer to font table entry */
    Memh fpcH; /* handle on fpc-format font */
    struct pcfont FAR *fpcP; /* pointer to fpc file contents */
    struct pccharl cdef; /* fpc character definition */
    char SHUGE *cmapP; /* pointer to character bitmap */
    int cb; /* current byte of character */
    int bii; /* index in bitmap */
    int rsize; /* bytes/row in bitmap */
    int bsize; /* number bytes to copy from bitmap */
    short bitPat[8]; /* pattern to fill with */
    HBITMAP bmpH; /* handle on pattern bitmap */
    HBRUSH brushH; /* handle on pattern brush */
    int cacheI; /* index in bitmap cache */
    int bcacheT; /* cache type = 1 = brush = 2 = inverted brush */

    /* check if already have bitmap */

    bcacheT = (invertF ? 2: 1);
    fontP = pattF+(struct tutorfont FAR *)GetPtr(fontsH);
    if ((fontP->fptr == HNULL) || (fontP->datType != 1)) {
		ReleasePtr(fontsH);
		return(0); /* can't build pattern */
    }
    fpcH = (Memh)fontP->fptr; /* get handle on fpc file */
    cacheI = fpc_find_bitmap_cache(fpcH,pattC,bcacheT);
    if (cacheI >= 0) {
        bmpH = BitmapCache[cacheI].mapH;
    }else { /* haven't got bitmap yet */

        /* build pattern bitmap from fpc format font */

        for(bii=0; bii<8; bii++) bitPat[bii] = 0; /* pre-zero bitmap */
        fpcP = (struct pcfont FAR *)GetPtr(fpcH);
        cmapP = fpc_char(fpcP,pattC,&cdef);
        if (cmapP) { /* have bitmap */
		    bsize = cdef.maph;
		    if (bsize > 8)
	    	    bsize = 8; /* can only handle 8x8 bitmap */
		    rsize = (cdef.mapw+7) >> 3; /* bytes/row */
		    for(bii=0; bii<bsize; bii++) {
	    	    cb = *(cmapP+bii*rsize);
	    	    if (invertF)
				    bitPat[bii] = (~cb) & 0xff;
	    	    else
				    bitPat[bii] = cb;
		    } /* bii for */
        } /* cmapP if */
        ReleasePtr(fpcH);
        bmpH = CreateBitmap(8,8,1,1,bitPat);
        fpc_add_bitmap_cache(fpcH,pattC,bcacheT,bmpH,NEARNULL); /* add to cache */
    } /* bmpH if */
    ReleasePtr(fontsH);

    brushH = CreatePatternBrush(bmpH);
    UnrealizeObject(brushH);
    return(brushH);

} /* fpc_brush */

/* ******************************************************************* */

int pen_fix() /* set color,pen,brush for current mode/colors */

{   int bkModeF; /* opaque/transparent mode */
    HDC hdc; /* handle on device context */
    int cIndex; /* index of color in cT palette */
    int wIndex; /* index of color in Windows palette */
    HPALETTE winPalH; /* handle on current palette */
    PALETTEENTRY pEnt; /* color palette entry */
    COLORREF forRef; /* foreground color */
    COLORREF bakRef; /* background color */
    COLORREF swapRef;
    HPEN oldPen; /* handle on previous pen */
    HPEN newPen; /* handle on new pen */
    Memh paletteH; /* handle on current cT palette */
    struct CTcolorentry FAR *palP; /* pointer in cT palette */

    if ((CurrentWindow < 0) || (defaultPalette == HNULL))
		return(0); /* not initialized yet */

	if (!HaveDC && !inPrint) {
		CurrentDC = cTGetDC(CurrentWinH);
	}

    colorInvert = FALSE;
    bkModeF = TRANSPARENT;
    if (CurrentMode == NOT_SRC_COPY) {
		colorInvert = TRUE; /* invert colors for inverse */
		bkModeF = OPAQUE; /* opaque background for inverse */
    } else if (CurrentMode == SRC_BIC) {
		colorInvert = TRUE; /* invert colors for erase */
    } else if (CurrentMode == SRC_COPY) {
		bkModeF = OPAQUE; /* erase background for rewrite */
    }

    hdc = CurrentDC; /* get handle on device context */
    winPalH = (HPALETTE)windowsP[CurrentWindow].winPalH;
    if (wColorSet != CurrentWindow) {
		wColorSet = CurrentWindow;
		paletteH = windowsP[CurrentWindow].paletteH;
		if (!paletteH)
			paletteH = defaultPalette;
	palP = (struct CTcolorentry FAR *)GetPtr(paletteH);

	/* handle foreground color */

	if (fgndColor.palette == color_rgb) {
	    frrC = (int)((fgndColor.red/100.0)*255.0);
	    frgC = (int)((fgndColor.green/100.0)*255.0);
	    frbC = (int)((fgndColor.blue/100.0)*255.0);
	    frRef = RGB(frrC,frgC,frbC);
	} else if (winPalH) {
	    if (fgndColor.palette == color_white) {
		frrC = frgC = frbC = 255;
		frRef = RGB(255,255,255);
	    } else if (fgndColor.palette == color_black) {
		frrC = frgC = frbC = 0;
		frRef = RGB(0,0,0);
	    } else {
		cIndex = map_default_color(fgndColor.palette);
            	if ((cIndex < 0) || (cIndex >= windowsP[CurrentWindow].paletteSize))
		    cIndex = 0;
		wIndex = (int)((palP+cIndex)->realV);
		if (wIndex < 0)
		    wIndex = 0;
		GetPaletteEntries(winPalH,wIndex,1,(PALETTEENTRY FAR *)&pEnt);
		frrC = pEnt.peRed;
            	frgC = pEnt.peGreen;
            	frbC = pEnt.peBlue;
		if (!mControllerHasPalette) frRef = PALETTEINDEX(wIndex);
		else frRef = RGB(frrC,frgC,frbC);
	    }
	} else { /* not rgb, no palette */
	    extract_palette_color(fgndColor.palette,&frrC,&frgC,&frbC); /* get cT color */
            frRef = GetNearestColor(hdc,RGB(frrC,frgC,frbC)); /* convert for windows */
	    extract_palette_color(bgndColor.palette,&bkrC,&bkgC,&bkbC); /* get cT color */
	    bkRef = GetNearestColor(hdc,RGB(bkrC,bkgC,bkbC)); /* convert for windows */
	}

	/* handle background color */

	if (bgndColor.palette == color_rgb) {
	    bkrC = (int)((bgndColor.red/100.0)*255.0);
	    bkgC = (int)((bgndColor.green/100.0)*255.0);
	    bkbC = (int)((bgndColor.blue/100.0)*255.0);
	    bkRef = RGB(bkrC,bkgC,bkbC);
	} else if (winPalH) {
	    if (bgndColor.palette == color_white) {
		bkrC = bkgC = bkbC = 255;
		bkRef = RGB(255,255,255);
	    } else if (bgndColor.palette == color_black) {
		bkrC = bkgC = bkbC = 0;
		bkRef = RGB(0,0,0);
	    } else {
		cIndex = map_default_color(bgndColor.palette);
            	if ((cIndex < 0) || (cIndex >= windowsP[CurrentWindow].paletteSize))
		    cIndex = 0;
		wIndex = (int)((palP+cIndex)->realV);
		if (wIndex < 0)
		    wIndex = 0;
		GetPaletteEntries(winPalH,wIndex,1,(PALETTEENTRY FAR *)&pEnt);
            	bkrC = pEnt.peRed;
            	bkgC = pEnt.peGreen;
            	bkbC = pEnt.peBlue;
		if (!mControllerHasPalette) bkRef = PALETTEINDEX(wIndex);
		else bkRef = RGB(bkrC,bkgC,bkbC);
	    }
	} else { /* not rgb, no palette */
	    extract_palette_color(bgndColor.palette,&bkrC,&bkgC,&bkbC); /* get cT color */
	    bkRef = GetNearestColor(hdc,RGB(bkrC,bkgC,bkbC)); /* convert for windows */
	}
	ReleasePtr(paletteH);
    } /* wColorSet if */
    forRef = frRef;
    bakRef = bkRef;
    if (colorInvert) {
	swapRef = forRef; /* exchange colors if need to invert */
	forRef = bakRef;
	bakRef = swapRef;
    }
    SetTextColor(hdc,forRef);
    SetBkColor(hdc,bakRef);
    SetBkMode(hdc,bkModeF);
    newPen = CreatePen(PS_SOLID,1,forRef); /* create new pen */
    oldPen = SelectObject(hdc,newPen); /* select into graphics context */
    if (!OriginalPen)
	OriginalPen = oldPen; /* save first pen ever found */
    else
	DeleteObject(oldPen); /* forget old pen */

    return(0);

} /* pen_fix */

/* ******************************************************************* */

TUTORset_cursor(cInd,cChar) /* set current cursor */
int cInd, cChar;

{   struct tutorfont FAR *fontP; /* pointer to font table entry */
    Memh fpcH; /* handle on fpc-format font */
    struct pcfont FAR *fpcP; /* pointer to fpc file contents */
    struct pccharl cdef; /* fpc character definition */
    char SHUGE *cmapP; /* pointer to character bitmap */
    int haveBits; /* TRUE if have bit pattern for cursor */
    int xMetric,yMetric; /* system-defined cursor size */
    int srcRowBytes; /* bytes/row in fpc character */
    int curRowBytes; /* bytes/row in cursor */
    int bii,cii,rowii,colii; /* index in bits */
    int curByte; /* current byte */
    int hotX,hotY; /* cursor hotspot */
    HDC hdc; /* handle on device context */
    HCURSOR newCursor;
    unsigned char ANDbits[128]; /* bits for AND mask */
    unsigned char XORbits[128]; /* bits for XOR mask */

#ifdef NOSUCH  
    int rowFirst,rowLast;   
    int anyPixel; 
    int curBit,prevBit; /* current, previous bits */
#endif

    if (CurrentWindow != ExecWn)
	return(0); /* executor only */
    if (cInd == cursorFont && cChar == cursorChar)
        return 0; /* already set */
    if ((cInd < 0) || (cChar < 0)) {
	cInd = cChar = -1; /* unset */
	return(0);
    }
    if ((cInd == cursorFont0) && (cChar == cursorChar0)) {
	TUTORnormal_cursor();
	return(0);
    }
    if ((cInd == cursorFont0) && ((cChar == 72) || (cChar == 2))) {
	TUTORwait_cursor();
	return(0);
    }

    if (!HaveDC)
	return(0);

    xMetric = GetSystemMetrics(SM_CXCURSOR);
    yMetric = GetSystemMetrics(SM_CYCURSOR);
    if ((xMetric > 32) || (yMetric > 32) ||
	(xMetric <= 0) || (yMetric <= 0))
	return(0);
    curRowBytes = (xMetric+7) >> 3;

    /* extract bit pattern for fpc-format character */

    fpcH = HNULL;
    fontP = cInd+(struct tutorfont FAR *)GetPtr(fontsH);
    haveBits = FALSE; /* dont have bit pattern yet */
    if (fontP->datType == 0) { /* windows font */
        ;
    } else if (fontP->datType == 1) { /* fpc format font */
	fpcH = (Memh)fontP->fptr; /* get handle on fpc file */
	fpcP = (struct pcfont FAR *)GetPtr(fpcH);
	cmapP = fpc_char(fpcP,cChar,&cdef);
        if (cmapP)
	   haveBits = TRUE; /* have bit pattern for cursor */
	if (fpcP->format & 4)
	    haveBits = FALSE; /* can't use 16-bit encoded font */
	srcRowBytes = (cdef.mapw+7) >> 3;
    }
    ReleasePtr(fontsH);

    if (haveBits) {
	for(bii=0; bii<128; bii++) {
	    XORbits[bii] = 0;
	    ANDbits[bii] = 0xff;
	}

	/* copy character bits to XORbits[] as xMetric x yMetric image */

	for(rowii=0; rowii<cdef.maph; rowii++) {
	    for(colii=0; colii<srcRowBytes; colii++) {
		bii = (rowii*srcRowBytes)+colii;
		curByte = *(cmapP+bii);
		cii = (rowii*curRowBytes)+colii;
		if (cii < 128) {
		    XORbits[cii] = curByte;
		} /* cii if */
	    } /* colii for */
	} /* rowii for */

	/* build mask for image */
#ifdef NOSUCH
	for(rowii=0; rowii<cdef.maph; rowii++) {
	    prevBit = anyPixel = 0;
	    rowFirst = -1;
	    for(colii=0; colii<cdef.mapw; colii++) {
		curBit = cur_tst_bit(&cdef,curRowBytes,&XORbits[0],colii,rowii);
		if (curBit) anyPixel = TRUE;
		if (curBit && !prevBit) {
		    rowFirst = colii-1;
		    break; /* exit colii for */
		}
		prevBit = curBit;
	    } /* colii for */
	    prevBit = 0;
	    rowLast = -1;
	    for(colii=cdef.mapw-1; colii>=0; colii--) {
		curBit = cur_tst_bit(&cdef,curRowBytes,&XORbits[0],colii,rowii);
		if (curBit && !prevBit) {
		    rowLast = colii+1;
		    break; /* exit colii for */
		}
		prevBit = curBit;
	    } /* colii for */
	    if (anyPixel) {
		if (rowFirst < 0) rowFirst = 0;
		if (rowLast < 0) rowLast = cdef.mapw-1;
	    }
	    if ((rowFirst >= 0) && (rowLast >= 0)) {
		for(colii=rowFirst;colii<=rowLast;colii++) {
		    cur_clr_bit(&cdef,curRowBytes,&ANDbits[0],colii,rowii);
		}
	    }
	} /* rowii for */
#endif   

	/* turn bits into a cursor */
       
    hotX = hotY = 0; 
    if (cInd == cursorFont0) {
    	if (cChar == 1) {    
    		hotX = 15;
    		hotY = 3;
    	} else if (cChar == 4) {
    		hotX = hotY = 7;
    	} else if (cChar == 5) {
    		hotX = hotY = 8;
    	}
    } /* cInd if */
	hdc = CurrentDC;
	SetTextColor(hdc,RGB(0,0,0));
	SetBkColor(hdc,RGB(255,255,255));

	newCursor = CreateCursor(hcTInst,hotX,hotY,xMetric,yMetric,
		    (char FAR *)ANDbits,(char FAR *)XORbits);
	SetCursor(newCursor);
	ShowCursor(TRUE);
	DestroyExecCursor();
	ExecCursor = newCursor;
	SysCursor = 0;
	pen_fix(); /* restore colors, etc */
    } /* haveBits if */

    if (fpcH)
	ReleasePtr(fpcH);
    return(0);

} /* TUTORset_cursor */

/* ******************************************************************* */

static int cur_tst_bit(cdef,rowBytes,bits,xx,yy)
struct pccharl *cdef; /* fpc character definition */
int rowBytes; /* bytes/row in bitmap */
unsigned char *bits; /* bitmap */
int xx; /* x position in bitmap */
int yy; /* y postion in bitmap */

{   int byteI; /* index of byte */
    int curByte; /* current byte */
    int shift;

    byteI = yy*rowBytes+(xx >> 3);
    if ((xx < 0) || (yy < 0) || (xx >= cdef->mapw) ||
	(yy >= cdef->maph) || (byteI >= 128))
	return(0);
    curByte = *(bits+byteI);
    shift = xx & 7;
    if (curByte & (0x80 >> shift))
	return(1);
    return(0);

} /* cur_tst_bit */

/* ******************************************************************* */

static int cur_clr_bit(cdef,rowBytes,bits,xx,yy)
struct pccharl *cdef; /* fpc character definition */
int rowBytes; /* bytes/row in bitmap */
unsigned char bits[]; /* bitmap */
int xx; /* x position in bitmap */
int yy; /* y postion in bitmap */

{   int byteI; /* index of byte */
    int curByte; /* current byte */
    int shift;

    byteI = yy*rowBytes+(xx >> 3);
    if ((xx < 0) || (yy < 0) || (xx >= cdef->mapw) ||
	(yy >= cdef->maph) || (byteI >= 128))
	return(0);
    curByte = *(bits+byteI);
    shift = xx & 7;
    curByte = curByte & (0xff7f >> shift);
    *(bits+byteI) = curByte;
    return(0);

} /* cur_clr_bit */

/* ******************************************************************* */

void RestoreExecCursor()

{   HCURSOR curCursor;

    if ((CurrentWindow == ExecWn) && ExecCursor &&
	((HWND)(windowsP[ExecWn].wp) == GetActiveWindow())) {
	curCursor = GetCursor();
	if (curCursor != ExecCursor) {
	    SetCursor(ExecCursor);
	    ShowCursor(TRUE);
	}
    }

} /* RestoreExecCursor */

/* ******************************************************************* */

static void DestroyExecCursor()

{
    if (CurrentWindow == ExecWn) {
	if (ExecCursor)
	    DestroyCursor(ExecCursor); /* dump previous created cursor */
	ExecCursor = NULL;
    }

} /* DestroyExecCursor */

/* ******************************************************************* */

TUTORarrow_cursor() 

{ 
    TUTORnormal_cursor(); /* arrow cursor is normal cursor */
    return(0);

} /* TUTORarrow_cursor */

/* ******************************************************************* */

TUTORwait_cursor() 

{
    if (!WaitCursor)
	WaitCursor = LoadCursor(NULL,IDC_WAIT);
    SysCursor = WaitCursor;
    SetCursor(SysCursor); /* hourglass cursor */
    DestroyExecCursor(); /* if executor, dump exec created cursor */
    ShowCursor(TRUE);
    return(0); 

} /* TUTORwait_cursor */

/* ******************************************************************* */

TUTORnormal_cursor() 

{
    if (!ArrowCursor)
	ArrowCursor = LoadCursor(NULL,IDC_ARROW);
    SysCursor = ArrowCursor;
    SetCursor(SysCursor); /* arrow cursor */
    DestroyExecCursor(); /* if executor, dump exec created cursor */
    ShowCursor(TRUE);
    return(0); 

} /* TUTORnormal_cursor */

/* ******************************************************************* */

TUTORresume_cursor() 

{ 
    TUTORnormal_cursor(); /* restore normal cursor after wait */
    return(0); 

} /* TUTORresume_cursor */

/* ******************************************************************* */

TUTORobscure_cursor() { return(0); }

/* ******************************************************************* */

TUTORdraw_graphic_icons(iconFont,str,len) /* plot a string of chars at */
               /* current position, update screen position    */
int iconFont; /* index in font table */
char *str; /* character string */
int len; /* length of character string */

{   struct tutorfont FAR *fontP; /* pointer to font table entry */
    Memh fpcH; /* handle on fpc-format font */
    struct pcfont FAR *fpcP; /* pointer to fpc file contents */
    int ii; /* index in string */
    int iconN; /* 16-bit character code */

    fontP = iconFont+(struct tutorfont FAR *)GetPtr(fontsH);
    if (fontP->datType == 0) { /* windows font */
		;
    } else if (fontP->datType == 1) { /* fpc format font */
		fpcH = (Memh)fontP->fptr; /* get handle on fpc file */
		fpcP = (struct pcfont FAR *)GetPtr(fpcH);
        if (fpcP->format & 4) { /* 16-bit encoding */
            for(ii=0; ii<len; ii+=2) {
                iconN = (str[ii] << 8) | str[ii+1];
                fpc_draw_char(fpcH,fpcP,iconN); /* draw fpc-format char */
            } /* for */
        } else { /* 8-bit encoding */
		    for(ii=0; ii<len; ii++) {
	    	    fpc_draw_char(fpcH,fpcP,str[ii]); /* draw fpc-format character */
		    } /* for */
        }
		ReleasePtr(fpcH);
    }

    ReleasePtr(fontsH);  
    return(0);

} /* TUTORdraw_graphic_icons */

/* ************************************************************* */

TUTORdraw_alpha_icons(iconFont,s,len) /* start text at upper left corner */
int iconFont;
char *s;
int len;

{  
#ifdef NOSUCH 
	Memh savfont; /* save current font selection */  
#endif

   TUTORdraw_graphic_icons(iconFont,s,len);
#ifdef NoSuch
    savfont = wmFonth;
    wmg_font(TUTORinq_font_ptr(iconFont));
    len = strlen(s);
    TUTORabs_move(0,wmFont->ascent);
    TUTORdraw_text((unsigned char far *) s,len);
    TUTORabs_move(0,-(wmFont->ascent));
    wmg_font((long)savfont);
#endif 
	return(0);

} /* TUTORdraw_alpha_icons */

/* ******************************************************************* */

TUTORabs_move_to(x,y)   /* set current screen location */
int x,y;

{

    RealX = x;
    RealY = y;
    return(0);

} /* TUTORabs_move_to */

/* ******************************************************************* */

TUTORabs_move(x,y)      /* move x/y co-ordinate by specified amount */
int x,y;

{
    TUTORabs_move_to(RealX+x,RealY+y);
    return(0);

} /* TUTORabs_move */

/* ******************************************************** */

TUTORabs_draw_dot(x1,y1)            /* make a dot */
int x1, y1;

{   HDC hdc; /* device context */

	TUTORabs_move_to(x1,y1);
	TUTORabs_line_to(x1,y1);

#ifdef NOSUCH
    hdc = CurrentDC;
    RealX = x1;
    RealY = y1;
    MoveToEx(hdc,(short)RealX,(short)RealY,NULL);
    /* LineTo draws up to, but not including, last dot */
    LineTo(hdc,(short)RealX+1,(short)RealY);
    MoveToEx(hdc,(short)RealX,(short)RealY,NULL);
#endif
    return(0);

} /* TUTORabs_draw_dot */

/* ******************************************************************* */

TUTORabs_line_to(x, y)  /* draw line from current screen location */
int x, y;

{   HDC hdc;        /* device context */
	int dxy,axy; 
	int x1,y1,x2,y2;
	long fx[8],fy[8]; /* points for thick-line polygon */

	if (lineThick) {
		dxy = lineThick; /* -1;  */
		axy = lineThick >> 1;
		if (RealX < x) {
			x1 = RealX-axy;		y1 = RealY-axy;
			x2 = x-axy;			y2 = y-axy;
		} else {
			x1 = x-axy;			y1 = y-axy;
			x2 = RealX-axy;		y2 = RealY-axy;
		}
		if (y1 > y2) {
			fx[1] = x1;		fy[1] = y1;
			fx[2] = x1;		fy[2] = y1+dxy;
			fx[3] = x1+dxy;	fy[3] = y1+dxy;
			fx[4] = x2+dxy;	fy[4] = y2+dxy;
			fx[5] = x2+dxy;	fy[5] = y2;
			fx[6] = x2;		fy[6] = y2;
			fx[7] = x1;		fy[7] = y1;
		} else {
			fx[1] = x1;		fy[1] = y1;
			fx[2] = x1;		fy[2] = y1+dxy;
			fx[3] = x2;		fy[3] = y2+dxy;
			fx[4] = x2+dxy;	fy[4] = y2+dxy;
			fx[5] = x2+dxy;	fy[5] = y2;
			fx[6] = x1+dxy;	fy[6] = y1;
			fx[7] = x1;		fy[7] = y1;
		}
		TUTORabs_fill_polygon(7,fx,fy);
		RealX = x;
		RealY = y;
		return(0);
	} /* lineThick */

    hdc = CurrentDC;
    MoveToEx(hdc,(short)RealX,(short)RealY,NULL);
    RealX = x;
    RealY = y;
    LineTo(hdc,(short)RealX,(short)RealY);
    /* LineTo draws up to, but not including, last dot */
    LineTo(hdc,(short)RealX+1,(short)RealY);
    MoveToEx(hdc,(short)RealX,(short)RealY,NULL);

    return(0);

} /* TUTORabs_line_to */

/* ******************************************************************* */

TUTORset_comb_rule(rule) /* set display mode (write, erase etc.) */
int rule;

{   HDC hdc;        /* device handle */
    short drawmode; /* raster op */
    int backmode; /* text background mode */

    if (rule == CurrentMode)
        return(0);
    if (rule == -1)
    	rule = SRC_OR; /* default to mode write if unset */
    	
	drawmode = R2_COPYPEN;
    switch (rule) {
        case SRC_COPY:
            backmode = OPAQUE;
            break;          /* mode rewrite */
        case SRC_OR:
            backmode = TRANSPARENT;
            break;          /* mode write */
        case SRC_XOR:
	    	drawmode = R2_NOT; 
            backmode = TRANSPARENT;
            break;          /* mode xor */
        case SRC_BIC:
            backmode = OPAQUE;
            break;          /* mode erase */
        case NOT_SRC_COPY:
            backmode = TRANSPARENT;
            break;          /* mode inverse */
        default:
	    TUTORdump("set_comb_rule");
        } /* switch */

        /* set pen mode */

        hdc = CurrentDC;
        SetBkMode(hdc,backmode); /* set text mode */
        SetROP2(hdc,drawmode); /* set pen/background combination mode */

        CurrentMode = rule;
        wColorSet = -1;
		pen_fix(); /* set colors/pen */

        return(0);

} /* TUTORset_comb_rule */

/* ******************************************************************* */

TUTORforce_redraw(wix) /* force redraw event for specified window */

{
    windowsP[wix].winRedraw = TRUE;
    return(0);

} /* TUTORforce_redraw */

/* ******************************************************************* */

TUTORset_program_name(pname) /* dummy - handled by TUTORset_window_title */
char *pname; /* program name string */

{
    return(0);

}  /* TUTORset_program_name */

/* ******************************************************************* */

TUTORset_window_title(wix,wt) /* set title of specified window */  
int wix;
char *wt; /* window title string */

{   char *wprogram; /* pointer to program name */
    char wtitle[64+8+2]; /* window title */
    HWND SetWinH; /* window handle */

    /* build window title */

    wprogram = "";
    if (wix == EditWn[0]) wprogram = "cT Create";
    else if ((wix == ExecWn) && (wt == NIL)) wprogram = "cT Execute";
    strcpy(wtitle,wprogram);
    if (wt != NIL) {
        if (wtitle[0] != 0)
            strcat(wtitle,": ");
        strncat(wtitle,wt,64);
    } /* wt if */

    /* set window title */

    SetWinH = (HWND)windowsP[wix].wp;
    SetWindowText(SetWinH,(LPSTR)(wtitle));
    return(0);

} /* TUTORset_window_title */

/* ******************************************************************* */

TUTORresize_window(wid,newX, newY)
int wid;
int newX, newY;

{
    windowsP[wid].wxsize = newX;
    windowsP[wid].wysize = newY;

    return(0);

} /* TUTORresize_window */

/* ******************************************************************* */

TUTORset_event_mask(eventc,value) /* set specified event mask entry */
int eventc;    /* event type to set */
int value;    /* TRUE or FALSE for this event */

{   struct tutorwindow FAR *wp;    /* pointer to current window data */

    if (CurrentWindow < 0)
		return(0);
    wp = &windowsP[CurrentWindow];
    wp->eventMask[eventc] = value;
    return(0);

} /* TUTORset_event_mask */

/* ******************************************************************* */

TUTORdraw_abs_solid_rect(tr, color) /* fill rectangle with specified color */
TRect FAR *tr;
int color;

{   int curPatF; /* current fill pattern font index */
	int curPatC; /* current fill pattern character */
	int curMode; /* current write/erase mode */
	struct tutorColor curFgndC; /* current foreground color */
	struct tutorColor curBgndC; /* current background color */

    curPatF = patternFont; /* save current fill pattern */
	curPatC = patternChar;
	curMode = CurrentMode; /* save current mode */
	/* save colors */
	TUTORblock_move((char FAR *)&fgndColor,(char FAR *)&curFgndC,
			(long)sizeof(struct tutorColor));
	TUTORblock_move((char FAR *)&bgndColor,(char FAR *)&curBgndC,
			(long)sizeof(struct tutorColor));

    /* if color is unknown (e.g. -1), determine color based on current mode */
    if (color != PAT_BLACK && color != PAT_WHITE)
        color = (CurrentMode == NOT_SRC_COPY) ? PAT_BLACK : PAT_WHITE;

	if (color == PAT_WHITE) {
		/* reverse colors */
		TUTORblock_move((char FAR *)&curFgndC,(char FAR *)&bgndColor,
			(long)sizeof(struct tutorColor));
		TUTORblock_move((char FAR *)&curBgndC,(char FAR *)&fgndColor,
			(long)sizeof(struct tutorColor));
	}
	
	CurrentMode = -1; /* force comb_rule to act */
	TUTORset_comb_rule(SRC_COPY); /* set to mode rewrite */
	TUTORfill_abs_rect(tr,patternFont0,patternChar0); /* fill solid */

	/* restore colors */
	TUTORblock_move((char FAR *)&curFgndC,(char FAR *)&fgndColor,
			(long)sizeof(struct tutorColor));
	TUTORblock_move((char FAR *)&curBgndC,(char FAR *)&bgndColor,
			(long)sizeof(struct tutorColor));
	
	TUTORset_fill(curPatF,curPatC); /* restore fill pattern */
	CurrentMode = -1; /* force comb_rule to act */
	TUTORset_comb_rule(curMode); /* restore write/erase mode */  
	return(0);

} /* TUTORdraw_abs_solid_rect */

/* ******************************************************************* */

TUTORabs_erase_rect(tr, pattInd, pattC)
TRect *tr;
int pattInd;            /* index of fill pattern in font table */
int pattC;            /* pattern character # */

{	int savemode;

    savemode = CurrentMode;
    TUTORset_comb_rule(SRC_BIC); /* set to mode erase */
    TUTORfill_abs_rect((TRect FAR *)tr, pattInd, pattC);
    TUTORset_comb_rule(savemode);    /* restore mode */   
    return(0);

} /* TUTORabs_erase_rect */

/* ******************************************************************* */

TUTORframe_abs_rect(tr)
TRect FAR *tr;

{   int penx, peny;
    int temp1;
    int left,top,right,bottom;

    left = tr->left;
    top = tr->top;
    right = tr->right;
    bottom = tr->bottom;
    TUTORinq_abs_pen_pos(&penx,&peny); /* frame operation shouldn't move pen */

    if (left > right) {
        temp1 = left;
        left = right;
        right = temp1;
    }
    if (top > bottom) {
        temp1 = top;
        top = bottom;
        bottom = temp1;
    }
    TUTORabs_move_to(left,top);
    TUTORabs_line_to(left,bottom);
    TUTORabs_line_to(right,bottom);
    TUTORabs_line_to(right,top);
    TUTORabs_line_to(left,top);
    TUTORabs_move_to(penx,peny);  /* restore pen position */
    return(0);

} /* TUTORframe_abs_rect */

/* ******************************************************************* */

TUTORscroll_rect(r,dh,dv)    /* scroll specified area of screen */
TRect *r;    /* rectangular area to scroll */
int dh;        /* amount to scroll right */
int dv;        /* amount to scroll down */

{    TRect er;    /* rectangle to erase */

    if (dh == 0 && dv == 0) return(0); /* nothing to do */

    /* move specified area */
    TUTORmove_abs_rect(r->left,r->top,r->right,r->bottom,r->left+dh,r->top+dv);
    
    /* clear previous area */
    er = *r;
    /* make sure erase doesn't overlap new area.  Note that this assumes that one
       of dh and dv are 0 */
    if (dh > 0) er.right = r->left+dh-1;
    if (dh < 0) er.left = r->right+dh;
    if (dv > 0) er.bottom = r->top+dv-1;
    if (dv < 0) er.top = r->bottom+dv;
    TUTORdraw_abs_solid_rect((TRect FAR *) &er,PAT_BACKGROUND);
    return(0);

} /* TUTORscroll_rect */

/* ******************************************************************* */

TUTORmove_abs_rect(x1,y1,x2,y2,newx,newy) /* move rectangle to new position */
int x1,y1,x2,y2;        /* rectangle to move */
int newx,newy;          /* new position */

{   HDC hdc;        /* device handle */
    short width,height;

    if (newy < 0) { /* adjust if move off-screen */
        y1 = y1-newy;
        newy = 0;
    } /* newy if */

    hdc = CurrentDC;
    width = x2-x1+1;
    height = y2-y1+1;
    BitBlt(hdc,(short)newx,(short)newy,width,height,
               hdc,(short)x1,(short)y1,SRCCOPY);
    return(0);

} /* TUTORmove_abs_rect */

/* ******************************************************************* */

TUTORinvert_abs_rect(x1,y1,x2,y2) /* invert colors in rectangle */
int x1,y1,x2,y2;

{   RECT rectR; /* rectangular area */
    HDC hdc; /* handle on graphics context */

    hdc = CurrentDC;
    rectR.left = x1;
    rectR.top = y1;
    rectR.right = x2+1;
    rectR.bottom = y2+1;
    InvertRect(hdc,(RECT FAR *)&rectR);
    return(0);

} /* TUTORinvert_abs_rect */

/* ******************************************************************* */

TUTORset_rect(r,left,top,right,bottom) /* set up rectangle */
TRect *r;    /* rectangle to set up */
int left,top,right,bottom;

{  
    r->top = top;
    r->left = left;
    r->right = right;
    r->bottom = bottom;
    return(0);

} /* TUTORset_rect */

/* ******************************************************************* */

TUTORmove_rect(rr,xx,yy) /* move a rectangles coordinates */
register TRect FAR *rr;
int xx;
int yy;

{
    rr->top += yy;
    rr->bottom += yy;
    rr->left += xx;
    rr->right += xx;
    return(0);

} /* TUTORmove_rect */

/* ******************************************************************* */

TUTORinset_rect(rr,xx,yy) /* inset a rectangles coordinates */
register TRect FAR *rr;
int xx;
int yy;

{
    rr->top += yy;
    rr->bottom -= yy;
    rr->left += xx;
    rr->right -= xx;
    return(0);

} /* TUTORinset_rect */

/* ******************************************************************* */

TUTORpoint_in_rect(pt,r)    /* determine if point in specified rectangle */
TPoint pt;    /* x/y co-ordinates to check */
TRect *r;        /* rectangle to check within */

{ 
    if ((pt.hh < r->left) || (pt.vv < r->top)) return(FALSE);
    if ((pt.hh > r->right) || (pt.vv > r->bottom)) return(FALSE);
    return(TRUE);

} /* TUTORpoint_in_rect */

/* ******************************************************************* */

TUTORhilite(x1,y1,x2,y2) /* hilite text (usually an inversion) */
int x1,y1,x2,y2; /* coords to hilite */

{
    TUTORinvert_abs_rect(x1,y1,x2,y2);   
    return(0);

} /* TUTORhilite */

/* *********************************************************** */

TUTORfill_abs_rect(tr,pattF,pattC)
TRect FAR *tr; /* ordered screen coords */
int pattF; /* index of fill pattern in font table */
int pattC; /* pattern character # */

{   int left,right,top,bottom; /* rectangle */
    int preClear; /* TRUE if should pre-clear screen bits */
    int invertF1; /* TRUE if should invert bitmap for foreground blt */
    int invertF2; /* TRUE if should invert bitmap for background blt */
    struct tutorColor curFgndC; /* current (saved) foreground color */
    struct tutorColor curBgndC; /* current (saved) background color */
    HDC hdc; /* device context */
    HBRUSH brushH; /* handle on pattern brush */
    HBRUSH bwbrushH; /* handle on black/white pattern brush */
    HBRUSH curBrushH; /* handle on current brush */
    DWORD patRop; /* raster operation */

    left = tr->left;
    right = tr->right;
    top = tr->top;
    bottom = tr->bottom;

    invertF1 = TRUE;
    invertF2 = FALSE;
    curFgndC = fgndColor; /* save colors */
    curBgndC = bgndColor;
    hdc = CurrentDC;

    preClear = FALSE; /* TRUE if need to pre-clear screen bits */
    patRop = 0;
    switch (CurrentMode) {

    case SRC_COPY: /* mode rewrite */
    case NOT_SRC_COPY: /* mode inverse */
	patRop = 0xf00021L; /* p */
	break;
    case SRC_OR: /* mode write */
    case SRC_BIC: /* mode erase */
        if ((pattF == zpatternsF) && (pattC == 16)) {
            /* default solid pattern - treat like rewrite */
            patRop = 0xf00021L; 
	} else {
	    invertF2 = TRUE;
	    preClear = TRUE;
	    patRop = 0xfa0089L; /* p|d */
        }
	break;
    case SRC_XOR: /* mode xor */
	patRop = 0x5a0049L; /* p^d */
	SetBkColor(CurrentDC,RGB(0,0,0));
	SetBkMode(CurrentDC,TRANSPARENT);
	/* xor with black does nothing, so if foreground color */
	/* is black, use white instead */
	if (fgndColor.palette == 0) {
	    SetTextColor(hdc,RGB(255,255,255));
	}
	break;
    } /* switch */

    brushH = fpc_brush(pattF,pattC,invertF1); /* invert bitmap */
    if (preClear) {
	SetBkColor(hdc,RGB(255,255,255));
	SetTextColor(hdc,RGB(0,0,0));
	SetBkMode(hdc,TRANSPARENT);
	bwbrushH = fpc_brush(pattF,pattC,invertF2);
	curBrushH = SelectObject(hdc,bwbrushH);
	PatBlt(hdc,left,top,right-left+1,bottom-top+1,(DWORD)0xa000c9L);
	fgndColor = curFgndC; /* restore colors */
	bgndColor = curBgndC;
	pen_fix(); /* apply restored colors */
	SetBkMode(hdc,TRANSPARENT); /* insure background transparent */
	SetBkColor(hdc,RGB(0,0,0)); /* insure background OR is a no-op */
	SelectObject(hdc,brushH); /* set to colored brush */
	DeleteObject(bwbrushH); /* destroy brush */
    } else {
	curBrushH = SelectObject(hdc,brushH);
    }
    PatBlt(hdc,left,top,right-left+1,bottom-top+1,patRop);
    SelectObject(hdc,curBrushH); /* restore brush */
    DeleteObject(brushH); /* destroy brush */
    if (preClear) {
	fgndColor = curFgndC; /* restore colors */
	bgndColor = curBgndC;
	pen_fix(); /* reapply colors, modes, etc */
    }

    return(0);

} /* TUTORfill_abs_rect */

/* ******************************************************************* */

TUTORabs_fill_polygon(npoints,fx,fy)

int npoints; /* number points */
long *fx; /* x co-ordinates (fx[0] not used) */
long *fy; /* y co-ordinates (fy[0] not used) */

{   POINT polyPts[FILLPOINTS]; /* array of points defining polygon */
    POINT *pPtr; /* pointer in points array */
    int pii; /* index in points */
    HRGN polyH; /* handle on polygon region */

    fx++; /* kludge - adjust to start at fx[1] not fx[0] */
    fy++;

    if (npoints > FILLPOINTS)
	npoints = FILLPOINTS;

    /* create polygon region */

    pPtr = polyPts;
    for(pii=0; pii<npoints; pii++) {
	    pPtr->x = (int)(*fx++);
	    pPtr->y = (int)(*fy++);
	    pPtr++;
    } /* pii for */

    polyH = CreatePolygonRgn((POINT FAR *)polyPts,npoints,WINDING);
    if (polyH == NULL)
	    return(0); /* didn't work */

    /* fill polygon region */

    pat_fill_region(polyH,patternFont,patternChar);
    return(0);

} /* TUTORabs_fill_polygon */

/* ******************************************************************* */

TUTORabs_fill_disk(type,xc,yc,rp,pFont,pChar) /* filled disk */
/* partial disks not allowed at present */
int type; /* 0 = radius, center valid, 1 = rectangle, center not valid */
long xc,yc; /* center */
TRect *rp; /* bounding rectangle */
int pFont; /* index of pattern font */
int pChar; /* index of pattern char */

{   HRGN ellipseH; /* handle on eliptical region */
	int dx,dy;

	dx = rp->right-rp->left;
	dy = rp->bottom-rp->top;
	if ((dx == dy) && ((dx == 1) || (dx == 2))) {
		TUTORabs_draw_dot(rp->left,rp->top);
		return(0);
	}
    ellipseH = CreateEllipticRgn(rp->left,rp->top,rp->right+1,rp->bottom+1);
    if (ellipseH == NULL)
	    return(0); /* didn't work */
    pat_fill_region(ellipseH,patternFont,patternChar);
    return(0);

} /* TUTORabs_fill_disk */

/* ******************************************************************* */

static int pat_fill_region(regionH,pFont,pChar) /* fill region with pattern */
HRGN regionH; /* handle on region */
int pFont; /* index of pattern font */
int pChar; /* index of pattern char */

{   HBRUSH brushH; /* handle on brush to fill with */
    HDC hdc; /* current device context */
    int curROP; /* current raster mode */
    int patROP; /* raster mode for pattern fill */
    int invertF; /* TRUE if should invert pixels in brush */
    int bMode; /* background mode */
    int curBkMode; /* current background mode */
    HRGN crgn;      /* handle on clip region */
	HRGN dest;		/* handle on destination region */
	int x1,y1,x2,y2; /* clip region coordinates */

	/* apply clip region */
	
    x1 = tgclipR.left;
    y1 = tgclipR.top;
    x2 = tgclipR.right;
    y2 = tgclipR.bottom;
    crgn = CreateRectRgn(x1,y1,x2+1,y2+1); /* set up clip region */
	dest = CreateRectRgn(0,0,0,0); /* set up destination region */
	CombineRgn(dest,regionH,crgn,RGN_AND); /* apply clip */
    DeleteObject(crgn); /* don't need this copy */

    /* create brush */

    invertF = TRUE; /* for windows, 0 = black (fgnd) , 1 = white (bgnd) */
    patROP = 0;
    bMode = TRANSPARENT;
   
    switch (CurrentMode) {
    case SRC_COPY: /* mode rewrite */
		patROP = R2_COPYPEN; /* p */
        bMode = OPAQUE;
		break;
    case SRC_OR: /* mode write */
		patROP = R2_COPYPEN; /* p */
		break;
    case SRC_XOR: /* mode xor */
		invertF = FALSE;
		patROP = R2_XORPEN; /* p^d */
		break;
    case SRC_BIC: /* mode erase */
		patROP = R2_COPYPEN; /* p */
		break;
    case NOT_SRC_COPY: /* mode inverse */
		patROP = R2_COPYPEN; /* p */
        bMode = OPAQUE;
		break;
    } /* switch */

    brushH = fpc_brush(pFont,pChar,invertF); /* get brush */
    hdc = CurrentDC;
    curROP = GetROP2(hdc); /* get current raster mode */
    SetROP2(hdc,patROP);
    curBkMode = GetBkMode(hdc);
    SetBkMode(hdc,bMode);
    SelectObject(hdc,dest); /* select region into window */
    FillRgn(hdc,dest,brushH); /* fill the region */
    SetROP2(hdc,curROP); /* restore raster mode */
    SetBkMode(hdc,curBkMode); /* restore background mode */
    tgclipx = tgclipx-1; /* force new clip */
    TUTORset_abs_clip_rect((TRect FAR *)&tgclipR); /* set clip region */
    DeleteObject(dest); /* done with cipped region */
	DeleteObject(regionH); /* done with original region */
    DeleteObject(brushH); /* done with brush */
 
    return(0);

} /* pat_fill_region */

/* ******************************************************************* */

SetWinFill()

{   int curMode;

    curMode = CurrentMode;
    CurrentMode = -1; /* force comb_rule to act */
    TUTORset_comb_rule(curMode);
    return(0);

} /* SetWinFill */

/* ******************************************************************* */

TUTORclear_screen()     /* full screen erase */

{   RECT wrect; /* window client area rectangle */
    TRect tr; /* rectangle to erase */
    struct tutorColor savFgndC; /* saved foreground color */
    struct tutorColor savBgndC; /* saved background color */
    int savMode; /* saved write/erase mode */

    GetClientRect(CurrentWinH,(LPRECT)&wrect);
	ValidateRect(CurrentWinH,&wrect);
    tr.left = wrect.left; /* set up rectangle to erase */
    tr.top = wrect.top;
    tr.right = wrect.right;
    tr.bottom = wrect.bottom;
    TUTORblock_move((char FAR *)&fgndColor,(char FAR *)&savFgndC,
                    (long)sizeof(struct tutorColor));
    TUTORblock_move((char FAR *)&bgndColor,(char FAR *)&savBgndC,
                    (long)sizeof(struct tutorColor));
    TUTORset_color(0,(struct tutorColor FAR *)&winColor);
    savMode = CurrentMode; /* save mode */
    CurrentMode = wColorSet = -1; /* force comb_rule to act */
    TUTORset_comb_rule(SRC_COPY); /* fill in mode rewrite */
    TUTORfill_abs_rect((TRect FAR *)&tr, patternFont0, patternChar0); /* fill solid */
    /* restore colors */
    TUTORblock_move((char FAR *)&savFgndC,(char FAR *)&fgndColor,
                    (long)sizeof(struct tutorColor));
    TUTORblock_move((char FAR *)&savBgndC,(char FAR *)&bgndColor,
                    (long)sizeof(struct tutorColor));
    CurrentMode = -1; /* force comb_rule to act (invokes pen_fix) */
    TUTORset_comb_rule(savMode); /* apply saved color/mode */
    return(0);

} /* TUTORclear_screen */

/* ******************************************************************* */

TUTORset_abs_clip_rect(cr)    /* set clip region */
TRect FAR *cr;

{   int x1, y1, x2, y2; /* corners of clip region */
	int tt;
	
    x1 = cr->left;
    x2 = cr->right;
    y1 = cr->top;
    y2 = cr->bottom;            
    if (x2 < x1) {
    	tt = x1;
    	x1 = x2;
    	x2 = tt;
    }
    if (y2 < y1) {
    	tt = y1;
    	y1 = y2;
    	y2 = tt;
    }
    TUTORset_abs_clip_rectangle(x1,y1,x2,y2);
    return(0);

} /* TUTORset_abs_clip_rect */

/* ******************************************************************* */

TUTORset_abs_clip_rectangle(x1,y1,x2,y2)        /* set clip region */
int x1,y1,x2,y2;        /* corners of clip region */

{   HDC hdc;        /* device handle */
    HRGN crgn;      /* handle on clip region */

    if ((tgclipx == x1) && (tgclipy == y1) && (tgclipw == (x2-x1+1)) &&
       (tgcliph == (y2-y1+1))) return(0);
    tgclipx = x1;
    tgclipy = y1;
    tgclipw = (x2-x1)+1;
    tgcliph = (y2-y1)+1;
    tgclipR.left = x1;
    tgclipR.top = y1;
    tgclipR.right = x2;
    tgclipR.bottom = y2;

    hdc = CurrentDC;
    crgn = CreateRectRgn(x1,y1,x2+1,y2+1);
    SelectClipRgn(hdc,crgn); /* set clip region */
    DeleteObject(crgn); /* don't need this copy */
   
    return(0);

} /* TUTORset_abs_clip_rectangle */

/* ******************************************************************* */

TUTORinq_abs_screen_size(x, y, dx, dy)
/* return location of upper-left corner of screen, width, height */

int *x, *y, *dx, *dy;

{
    *x = 0;
    *y = 0;
    if (CurrentWindow < 0) {
	*dx = *dy = 0;
	return(0);
    }
    *dx = windowsP[CurrentWindow].wxsize;
    *dy = windowsP[CurrentWindow].wysize;
    return(0);

} /* TUTORinq_abs_screen_size */

/* *********************************************************** */

TUTORinq_abs_pen_pos(x, y) /* return current screen location */
int *x, *y;

{
    *x = RealX;
    *y = RealY;
    return(0);

} /* TUTORinq_abs_pen_pos */

/* ******************************************************************* */

int TUTORinq_mouse_xy(xx,yy) /* return current mouse position */
long *xx;
long *yy;

{
    if (xx)
	*xx = lastMouseX;
    if (yy)
	*yy = lastMouseY;
    return(0);

} /* TUTORinq_mouse_xy */

/* ******************************************************************* */

TUTORsync()    /* synchronize with window manager */

{
    return(0);

} /* TUTORsync */

/* ******************************************************************* */

TUTORflush()

{
    if (CurrentWindow < 0)
	return(0);
    if (windowsP[CurrentWindow].menuf) /* check if should redraw menu bar */
	    DrawMenuBar(CurrentWinH);
    windowsP[CurrentWindow].menuf = FALSE;
    return(0);

} /* TUTORflush */

/* ******************************************************************* */

TUTORshould_interrupt()

{
    return((TopTime+750L) < TUTORinq_msec_clock());

} /* TUTORshould_interrupt */

/* ******************************************************************* */

TUTORfree_event_memory(event)
struct tutorevent FAR *event;

{
    if (event->type == EVENT_HOT)
	TUTORdealloc(event->eDataP);
    
    return(0);

} /* TUTORfree_event_memory */

/* ******************************************************************* */

TUTORsystem_tasks() /* do periodic tasks from root segment */

{
    MovieSupport();
    return(0);

} /* TUTORsystem_tasks */

/* ******************************************************************* */

TUTORunlock_code() /* unlock or otherwise free all non-root code segments */

{
    return(0);

} /* TUTORunlock_code */

/* ******************************************************************* */

int start_executor() /* post event to begin execution */

{   struct tutorevent event;

    TUTORpoll_events(FALSE); /* allow initial redraws into que */
    event.type = EVENT_MSG;
    event.window = ExecWn;
    event.value = event.id = 0;
    event.timestamp = 0;
    event.eDataP = FARNULL;
    event.view = ExecVp;
    event.a1 = exec_run;
    TUTORpost_event(&event);
    return(0);

} /* start executor */

/* ******************************************************************* */

TUTORseed_random(value) /* seed random number generator */
int value;

{
    srand((int)value);    /* seed random number generator */
    return(0);

} /* TUTORseed_random */

/* ******************************************************************* */

int  TUTORbeep(ff,dur,volume,nbeep)
int  *ff;
int  *dur;
int  *volume;
int  nbeep;

{
	MessageBeep(MB_OK); 
	return(0);

} /* TUTORbeep */


/* *************** debugging aids ************************************ */

static short tx = 1;    /* trace output x */
static short ty = 16;   /* trace output y */

TUTORtrace(s) /* display debug message */
char *s;

{
    TraceMsg((char FAR *)s);  
    return(0);
}

#ifdef NOSUCH

{   char tStr[80];

    if (s == NEARNULL) return(0);
    if (strlen(s) == 0) return(0);
    strncpy(tStr,s,79);
    tStr[79] = 0;
    if (tStr[strlen(tStr)-1] != '\n')
	strcat(tStr,"\n");
    OutputDebugString((LPCSTR)tStr);
    LPSTR textp;    /* pointer to text string */
    HWND TraceWinH; /* handle on trace window */
    HDC hdc;        /* device handle */
    int twn;        /* trace window number */
    int i,j;        /* index in string */
    short sx,sy;    /* saved x,y */

    twn = TraceWn;
    if (twn < 0) twn = EditWn[0];
    if (twn < 0) twn = ExecWn;
    if (twn >= 0) TraceWinH = windowsP[twn].wp;
    else TraceWinH = FirstWinH;
    if (TraceWinH == NEARNULL) return(0);
    sx = RealX;
    sy = RealY;
    hdc = cTGetDC(TraceWinH);
    textp = s;
    if (strlen(s) < 80) {
        strcpy(tbuff,s);
        for(i=strlen(s); i<80; i++) tbuff[i] = ' ';
        tbuff[79] = '\0';
        textp = (LPSTR)(tbuff);
        MoveTo(hdc,tx,ty);
        TextOut(hdc,tx,ty,textp,(short)strlen(tbuff));
        MoveTo(hdc,sx,sy); /* restore saved position */
    } /* strlen if */
    ty += 16;
    if (ty >= 240) ty = 16;
		cTReleaseDC(TraceWinH,hdc);

    for(i=1; i<32766; i++) {
        for(j=1; j<2; j++) { /* delay for a while */
            j=j;
        }
    }
    return(0);

} /* TUTORtrace */
#endif

/* ******************************************************************* */

TUTORdump(s)
char *s;

{
  /*  mw_mem_map();      */
    FatalAppExit(0,(LPCSTR)s);
    return(0);

} /* TUTORdump */

/* ******************************************************************* */
