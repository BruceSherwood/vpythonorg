
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989,1992 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* ******************************************************************* */

#define STRICT
#include <windows.h>
#include <string.h>
#include <direct.h>

#include "baseenv.h"
#include "ctmsw.h"
#include "kdefs.h"
#include "tglobals.h"
#include "kglobals.h"
#include "editor.h"
#include "execdefs.h"

/* ******************************************************************* */

struct pcscroll { /* data required for scrollbar */
    struct tutorview FAR *ownerV;   /* view pointer to owner */
    struct tutorview FAR *scrollV;  /* scroll view pointer */
    Memh ebshdrH; /* handle on cT object header (if any) */
    int ebsref; /* reference count on cT object header */
    TRect rr;   /* scrollbar rectangle */
    TRect relRect;  /* to position scroll in window */
    char textF;     /* TRUE if attached to text view */
    char unitF; /* non-zero if cT unit to invoke */
		/* = 0 = no unit */
		/* = 1 = unit, no arguments */
		/* = 2 = unit + value argument */
    char type;  /* vertical/horizontal type */
    char posInfo;   /* positioning flags */
    int candraw;    /* TRUE if big enough window for scrollbar */
    int candrag;    /* TRUE if left-down in draggable area */
    int drag;	    /* TRUE if dragging scrollbar */
    double minVal;  /* minimum value os scroll bar */
    double maxVal;  /* maximum value of scroll bar */
    double curVal;  /* current value */
    double pageInc; /* pageup/pagedown increment */
    double lineInc; /* lineup/linedown increment */
    char killErase; /* TRUE if we erase when scroll bar is closed */
    struct tutorColor ecolor; /* color to erase with */
    int tbartop;    /* top (or left) of text rectangle */
    int tbarbottom; /* bottom (or right) of text rectangle */
    int unitN;	    /* unit to invoke */
    double unitarg; /* argument of unit */
    double (*ScrollProc)();	/* proc for scrolling */
    HWND scrollWindow; /* handle on scroll child window */
    HWND editCtrl; /* handle on edit control scroll bar */
    int sb_Type; /* Windows SB_CTL, SB_HORZ, SB_VERT type */
    int cTwi; /* index in cTwinInf table */
}; /* scroll */

struct tutorevent FAR *needScrollUp = FARNULL;
double scrollChangeLast;
double scrollSentLast;

/* ******************************************************************* */

extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
extern char  FAR *TUTORalloc(long  size,int  abort,char  *label);
extern int TUTORdealloc(char  FAR *ptr);
extern struct tutorview FAR *TUTORinq_view(void);
extern long ProcWndScroll(struct cTwinInf *wI,HWND hWnd,UINT message,
			  WPARAM wP,LPARAM lP);
extern int cTRegisterWindow(HWND hWnd,int cTtype,int cTindex,int cmdN,Memh infH);
extern struct tutorview FAR *TUTORinit_view(int  sW,unsigned int  vDat,
       int  (*vProc)());
extern int  procscrollstub(unsigned int  scrH,struct  tutorevent *event);
extern int  procscroll(unsigned int  theSbar,struct  tutorevent *event);
extern int  procexecwstub(unsigned int	wh,struct  tutorevent *event);
extern struct  tutorview FAR *TUTORinq_slider_view(unsigned int  theSBar);
extern unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
extern unsigned int  MakeScrollBar(struct  tutorview FAR *ovp,int  ew,
   unsigned int  ebshdrH,int ebsref,int  textF,int  sbType,int	info,
   struct  _trect *relRect,double  (*scrollProc)(),int	erase);
extern int TUTORclose_sbar(Memh theSBar);
extern int  TUTORuse_rel_rect(struct  _trect FAR *rRect,int  inf,
       struct  tutorview FAR *viewP,struct  _trect *sRect);
extern struct tutorview FAR *TUTORinq_slider_view(Memh sH);
extern HANDLE hcTInst; /* current instance of cT */

/* ******************************************************************* */

Memh MakeScrollBar(ovp,ew,ebshdrH,ebsref,textF,sbType,info,relRect,
		   scrollProc,erase)
struct tutorview FAR *ovp; /* owning view */
int ew; /* window index */
Memh ebshdrH; /* handle on cT object header (if any) */
int ebsref; /* reference count on cT object header */
int textF; /* TRUE if scroll bar owner is text view */
int sbType; /* type of scrollbar (horiz/vert) */
int info;
TRect *relRect;
double (*scrollProc)(); /* procedure to run scrolling */
int erase; /* TRUE if should erase on close */

{   struct pcscroll FAR *scP; /* pointer to cT scroll information */
    Memh theSbar; /* handle on cT scroll information */
    struct tutorview FAR *scrollView; /* pointer to scroll view data */
    struct tutorview FAR *currentView; /* pointer to current view data */
    TRect tempR; /* temporary rectangle for windows */
    int x1,y1,width,height; /* location of scroll child window */
    HWND parentW; /* handle on parent window */
    HWND scrollW; /* handle on scroll bar child window */
    int sbsType; /* horizontal/vertical type for CreateWindow */
    int oix; /* index of owner window */
    int EditF; /* TRUE if edit window (scroll bars created with window) */
    struct tutorColor eColor; /* color to erase with */
    struct tutorColor dc; /* dummy */
	int testInf;

    TUTORget_colors(&dc,&dc,&eColor); /* erase in current window color */
    oix = ovp->window; /* index of owner window */
    EditF = windowsP[oix].type == EDITW; /* TRUE if edit window */
    currentView = TUTORinq_view();
    scrollView = FARNULL;
    if (!EditF) {
	    scrollView = TUTORinit_view(ew,HNULL,procscrollstub);
	    if (!scrollView) return(0); /* failure to create new view */
    }
    theSbar = TUTORhandle("scroll  ",(long) sizeof(struct pcscroll),TRUE);
    if (!theSbar) return(0); /* failure to create scroll data */

    parentW = (HWND)windowsP[oix].wp;
    scP = (struct pcscroll FAR *) GetPtr(theSbar);
    TUTORzero((char FAR *)scP,(long)sizeof(struct pcscroll));
    scP->scrollV = scrollView;
    scP->textF = textF;
    scP->ebshdrH = ebshdrH; /* handle on cT object header */
    scP->ebsref = ebsref;
    scP->unitF = 0; /* no unit yet */
    scP->type = sbType;
    scP->ownerV = ovp;
    scP->candraw = FALSE;   /* cant generate display yet */
    scP->candrag = FALSE;   /* cant drag yet */
    scP->drag = FALSE;
    *tempFarR = *relRect;
    TUTORuse_rel_rect(tempFarR,info,ovp,&tempR);
    scP->rr = tempR;

    scP->relRect = *relRect;
    scP->posInfo = info;
    scP->curVal = scP->maxVal =  scP->minVal = 0.0;
    scP->pageInc = scP->lineInc = 0.0;
    scP->ScrollProc = scrollProc;
    scP->killErase = erase;
    scP->ecolor = eColor;

    x1 = scP->rr.left; /* get bounds of child window rectangle */
    y1 = scP->rr.top;
    width = scP->rr.right-x1+1;
    height = scP->rr.bottom-y1+1;
    sbsType = ((sbType == SBHORIZ) ? SBS_HORZ : SBS_VERT);

    if (EditF) {
	    if (sbsType == SBS_HORZ) { /* horizontal */
	        scP->sb_Type = SB_HORZ;
	        windowsP[oix].hScroll = theSbar; /* window's horizontal bar */
			scP->editCtrl = (HWND)windowsP[oix].hScrollW;
	    } else {
	        scP->sb_Type = SB_VERT;
	        windowsP[oix].vScroll = theSbar; /* window's vertical bar */
			scP->editCtrl = (HWND)windowsP[oix].vScrollW;
	    }
	    scP->editCtrl = parentW;
    } else {
	    scP->sb_Type = SB_CTL;
	    scP->scrollWindow = CreateWindow ((LPCSTR)"scrollbar", (LPCSTR)NEARNULL,
			      (DWORD)(WS_CHILD | WS_VISIBLE | WS_TABSTOP | sbsType),
			      x1, y1, width, height,
			      parentW, (HMENU)theSbar, hcTInst, FARNULL);
	    SetScrollRange(scP->scrollWindow,SB_CTL,0,32767,FALSE);
	    ShowWindow(scP->scrollWindow,SW_SHOW);
	    UpdateWindow(scP->scrollWindow);
		testInf = GetWindowLong(scP->scrollWindow,GWL_ID);
		if (testInf != theSbar)
			TUTORdump("GWL_ID bad");

	    /* set up cT's version of scrollbar view */

	    TUTORset_view(scrollView);
	    scrollView->vh = theSbar;
	    TUTORset_abs_view_rect(scP->rr.left,scP->rr.top,scP->rr.right-scP->rr.left+1,
            scP->rr.bottom-scP->rr.top+1);
	    TUTORset_view(currentView);
	    scP->cTwi = cTRegisterWindow(scP->scrollWindow,cTw_Scroll,oix,0,theSbar);

    } /* EditF else */

    ReleasePtr(theSbar);
    return(theSbar);

} /* MakeScrollBar */

/* ******************************************************************* */

TUTORclose_sbar(theSBar) /* destroy scroll bar */
Memh theSBar; /* handle on scroll bar data */
    
{   struct pcscroll FAR *sP; /* pointer to scroll bar data */
    struct tutorview FAR *cv; /* current view */
    struct tutorview FAR *sv; /* scroll bar view */
    struct tutorview FAR *ownerV; /* owner's view */
    int mainW; /* main (edit,execute) window */
    TRect rr; /* scroll bar rectangle */
    int doErase;
	struct tutorColor ecolor,svcolor; /* color erase info */

    if (!theSBar) 
        return(0);
    cv = TUTORinq_view(); /* remember current view for restore */
    sP = (struct pcscroll FAR *) GetPtr(theSBar);
    sv = sP->scrollV;
    sP->scrollV = FARNULL; /* we will destroy view */
    ownerV = sP->ownerV;
    mainW = ownerV->window;
    ecolor = sP->ecolor; /* pick up color to erase with */
    doErase = sP->killErase; /* find out whether we want to erase */
    rr = sP->rr; /* pick up scroll bar rectangle */
    if (sP->scrollWindow) {
	    ClosecTChildWindow((HWND)sP->scrollWindow,mainW,doErase,&ecolor,(TRect FAR *)&rr);
	}
    if (doErase && sv) {
	TUTORset_view(sv);
	TUTORinq_background_color(&svcolor); /* save background color */
        CTset_background_color(ecolor);
	TUTORdraw_abs_solid_rect((TRect FAR *)&rr,PAT_WHITE);
        CTset_background_color(svcolor);
    }   
    ReleasePtr(theSBar);
    if (sv)
        TUTORclose_view(sv); /* destroy scrollbar view */
    TUTORset_view(cv); /* restore view */
    
    return(0);

} /* TUTORclose_sbar */

/* ******************************************************************* */

long ProcWndScroll(winEntry, hWnd, message, wParam, lParam)
struct cTwinInf *winEntry; /* entry found in table */
HWND hWnd;	/* window handle		   */
UINT message;	/* type of message		   */
WPARAM wParam;	/* additional information	   */
LPARAM lParam;	/* additional information	   */

{   Memh theSbar; /* handle on scroll bar info */
    struct pcscroll FAR *scP; /* pointer to scroll bar data */
    int wix; /* index of window in windows[] */
    struct tutorevent cev; /* event for cT */
    double oldV; /* previous scroll bar value */
    int sendHit; /* TRUE if should send event */
    int setPos; /* TRUE if should update scroll bar */
    int scrollPos; /* new scroll bar position */
    int scrollHV; /* horizontal/vertical type for text view */
    double scrollN; /* position/change sent to text view */
    int scrollType; /* scroll action sent to text view */
    HWND parentW; /* parent window */
    int scrollMsgF; /* TRUE if WM_SCROLL message */

    sendHit = setPos = scrollMsgF = FALSE; /* not ready to send event yet */
    scrollType = 0; /* no editor event yet */
    parentW = NULL; /* no parent to return focus to yet */
    wix = winEntry->index;
    theSbar = HNULL; /* no scroll bar handle yet */
    TUTORzero((char FAR *)&cev,(long)sizeof(struct tutorevent));
    if (winEntry->type == cTw_Scroll) {
	    theSbar = winEntry->infH;
	    parentW = GetParent(winEntry->hWnd);
	    scrollMsgF = TRUE;
    }
    if (message == WM_VSCROLL) {
	    /* get handle on window's vertical scroll bar */
	    if (winEntry->type == cTw_Overlap)
		theSbar = windowsP[wix].vScroll;
	    scrollMsgF = TRUE;
    } else if (message == WM_HSCROLL) {
	    /* get handle on window's horizontal scroll bar */
	    if (winEntry->type == cTw_Overlap)
		theSbar = windowsP[wix].hScroll;
	    scrollMsgF = TRUE;
    } else return(0); /* unrecognized message */
    if (!theSbar)
	    return(0); /* no information on scroll bar */

    scP = (struct pcscroll FAR *)GetPtr(theSbar);
    oldV = scP->curVal; /* present value of scroll bar */

    if (scrollMsgF) {
	switch (LOWORD(wParam)) {

	case SB_LINEUP:
	    scP->curVal -= scP->lineInc;
	    scrollN = 0;
	    scrollType = sbLineUp;
	    sendHit = setPos = TRUE;
	    break;

	case SB_LINEDOWN:
	    scP->curVal += scP->lineInc;
	    scrollN = 0;
	    scrollType = sbLineDown;
	    sendHit = setPos = TRUE;
	    break;

	case SB_PAGEUP:
	    scP->curVal -= scP->pageInc;
	    scrollN = 0;
	    scrollType = sbPageUp;
	    sendHit = setPos = TRUE;
	    break;

	case SB_PAGEDOWN:
	    scP->curVal += scP->pageInc;
	    scrollN = 0;
	    scrollType = sbPageDown;
	    sendHit = setPos = TRUE;
	    break;

	case SB_THUMBTRACK:
	    if (scP->textF)
			break; /* ignore if text view */
	case SB_THUMBPOSITION:
	    scrollPos = HIWORD(wParam); /* get new position */
	    scP->curVal = ((double)scrollPos/32767.0)*(scP->maxVal-scP->minVal);
	    scP->curVal += scP->minVal;
	    scrollN = scP->curVal;
	    scrollType = sbToPos;
	    sendHit = setPos = TRUE;
	    break;

	} /* switch */
    } /* scrollMsgF if */

    /* process scroll event for editor/text panel */

    if (scP->textF && scrollType) { /* if attached to text view */
	    scrollHV = (scP->type == SBHORIZ);
	    scP->curVal = (*scP->ScrollProc)
			 (scP->ownerV,scrollHV,scrollN,scrollType);
    } /* textF if */


    /* update scroll bar for new position */

    if (scP->curVal > scP->maxVal) scP->curVal = scP->maxVal;
    if (scP->curVal < scP->minVal) scP->curVal = scP->minVal;
    if (setPos) {
	    scrollPos = ((scP->curVal-scP->minVal) /
		    (scP->maxVal-scP->minVal))*32767.0;
	    if (winEntry->type == cTw_Overlap) {
	        SetScrollPos(hWnd,scP->sb_Type,scrollPos,TRUE);
	    } else if (winEntry->type == cTw_Scroll) {
	        SetScrollPos(winEntry->hWnd,SB_CTL,scrollPos,TRUE);
	    }
    } /* setPos if */

    /* process event for executor - generate event to execute unit */

    if (sendHit && scP->unitF && (oldV != scP->curVal)) {

	    /* send event to do unit if value has changed */

	    cev.type = EVENT_SIGNAL;
	    cev.window = -1; /* not sent to a window */
	    cev.eDataP = FARNULL;
	    cev.a5 = windowsP[ExecWn].wH;
	    cev.vproc = procexecwstub;
	    cev.timestamp = TUTORinq_msec_clock()+200L;
	    if (scP->unitF == 1)
	        cev.a1 = BUTTONSIGNAL;
	    else cev.a1 = BUTTONSIGNALA;
	    cev.a2 = scP->ebshdrH;
	    cev.a6 = scP->ebsref;
	    cev.a3 = scP->unitarg;
	    cev.value = scP->unitN;
/*  hold event, dont send immediately	  TUTORpost_event(&cev);    */
	    if (!needScrollUp) {
			needScrollUp = (struct tutorevent FAR *)TUTORalloc(
			(long)sizeof(struct tutorevent),FALSE,"sev");
			if (needScrollUp)
				needScrollUp->type = -1;
	    }
	    if (needScrollUp) {
			scrollChangeLast = scP->curVal;
			scrollSentLast = scrollChangeLast+1.0;
			if (needScrollUp->type >= 0)
				cev.timestamp = 0; /* send immediately */
			TUTORblock_move((char SHUGE *)&cev,(char SHUGE *)needScrollUp,(long)sizeof(struct tutorevent));
	    }
    } /* sendHit/unitF if */

    if (parentW)
	    SetFocus(parentW); /* return focus to parent */
    ReleasePtr(theSbar);

    return(0);

} /* ProcWndScroll */

/* ******************************************************************* */

int  procscroll(theSbar,event)
Memh theSbar; /* handle on scroll bar data */
struct tutorevent *event; /* pointer to current event */

{   struct pcscroll FAR *scP; /* pointer to scroll bar info */
    int x1,y1,width,height;
    TRect tempR; /* temporary rectangle for windows */
	RECT sRect; /* scrollbar rectangle to redraw */

    scP = (struct pcscroll FAR *) GetPtr(theSbar);
    
    switch (event->type) {

    case EVENT_REDRAW:
        if (scP->scrollWindow) { /* child window, not edit scroll */
            TUTORuse_rel_rect(&scP->relRect,scP->posInfo,scP->ownerV,&tempR);  /* set up scrollbar rectangle */
            scP->rr = tempR;
            TUTORset_abs_view_rect(scP->rr.left,scP->rr.top,
                 scP->rr.right-scP->rr.left+1,scP->rr.bottom-scP->rr.top+1);
            TUTORclip_window(event->window);
            MoveWindow(scP->scrollWindow,scP->rr.left,scP->rr.top,
                (scP->rr.right-scP->rr.left)+1,(scP->rr.bottom-scP->rr.top)+1,TRUE);
			sRect.top = 0;
			sRect.left = 0;
			sRect.bottom = (scP->rr.bottom-scP->rr.top)+1;
			sRect.right = (scP->rr.right-scP->rr.left)+1;
			InvalidateRect(scP->scrollWindow,(RECT FAR *)&sRect,TRUE);
        } /* scrollWindow if */
        break;

    case EVENT_DESTROY:
        ReleasePtr(theSbar);
        TUTORfree_handle(theSbar); /* release memory */
        scP = FARNULL;
        break;

    default:
        break;

    } /* switch */
   
    if (scP)
        ReleasePtr(theSbar);
    return(0);

} /* procscroll */

/* ******************************************************************* */

double  SliderScroll(tview,hv,fn,type)
struct  tutorview FAR *tview;
int  hv;
double  fn;
int  type;

{   long nn;
    struct pcscroll FAR *scp;
    double retv; /* returned value */

    scp = (struct pcscroll FAR *)tview; /*  actually pointer to scroll */
    nn = fn; 
    retv = scp->curVal;

    switch (type) {

        case sbToPos:
            break;

        case sbPageUp:
            retv = scp->curVal-scp->pageInc;
            break;

        case sbPageDown:
            retv = scp->curVal+scp->pageInc;
            break;

        case sbVDown: /* andrew-style left click */
        case sbVUp: /* andrew-style right click */
            break;

        case sbLineUp:
            retv = scp->curVal-scp->lineInc;
            break;

        case sbLineDown:
            retv = scp->curVal+scp->lineInc;
            break;

        case sbToTop:
            retv = scp->minVal;
            break;

        case sbToBot: /* to end of view */
            retv = scp->maxVal;
            break;

        default:
            break;

    } /* switch */
    return(retv);

} /* SliderScroll */

/* ******************************************************************* */

TUTORreset_values_sbar(sbi,value,minim,maxim,pinc,linc,unitf,unitn,unitarg,doDraw)
Memh sbi;
double value, minim, maxim, pinc, linc;
int unitf; /* = 0 = no associated unit */
           /*   1 = unit, no arguments */
           /*   2 = unit with single value argument */
int unitn; /* unit number */
double unitarg; /* unit value argument */
int doDraw; /* TRUE if we want to draw here */
    
{   struct pcscroll FAR *sp;
    long myMax;
    double dist,tmp;
    int ival; /* value for windows scroll bar */

    sp = (struct pcscroll FAR *) GetPtr(sbi);
    
    /* set everything explicitly & draw */

    sp->maxVal = maxim;
    sp->minVal = minim;
    tmp = sp->minVal;  /* rearranged for possible bug in MSC 7.0 ? */
    sp->unitF = unitf;
    sp->unitN = unitn;
    sp->unitarg = unitarg;
    sp->pageInc = pinc;
    sp->lineInc = linc;
    if ((!sp->textF) && (sp->type == SBVERT)) {
	    /* invert value for vertical scroll bar */
	    dist = value-tmp;
        value = sp->maxVal-dist;
    }
    sp->curVal = value;
    if (sp->curVal < sp->minVal)
        sp->curVal = sp->minVal;
    else if (sp->curVal > sp->maxVal)
        sp->curVal = sp->maxVal;
    ival = 32767L*((sp->curVal-sp->minVal)/(sp->maxVal-sp->minVal));
	if (sp->scrollWindow)
    	SetScrollPos(sp->scrollWindow,sp->sb_Type,ival,TRUE);
	else if (sp->editCtrl)
		SetScrollPos(sp->editCtrl,sp->sb_Type,ival,TRUE);

    ReleasePtr(sbi);

    return(0);

} /* TUTORreset_values_sbar */

/* ******************************************************************* */

TUTORreset_text_sbar(sbiH,sinfP,doDraw)
Memh sbiH; /* handle on scroll bar info */
SBarInfo *sinfP; /* pointer to editor's scroll bar info */
int doDraw; /* TRUE if we want to draw here */
    
{   struct pcscroll FAR *sP;
    long myMax;
    int scrollPos; /* new scroll bar position */
    int sb_type; /* Windows scroll bar type */

    sP = (struct pcscroll FAR *) GetPtr(sbiH);
    if (!sP->textF) {
	    ReleasePtr(sbiH);
        return(0);
    }
    
    /* adjust horizontal so that right edge of text never goes past */
    /* right edge of view */
    if (sP->type == SBHORIZ)
	    myMax = sinfP->maxPos - sinfP->rangeLen;
    else
	    myMax = sinfP->maxPos;
    
    /* set everything explicitly & draw */
    sP->maxVal = myMax;
    sP->curVal = sinfP->curPos;

    scrollPos = (sP->curVal-sP->minVal)/(sP->maxVal-sP->minVal)*32767.0;
	if (doDraw) {
		if (sP->scrollWindow)
    		SetScrollPos(sP->scrollWindow,sP->sb_Type,scrollPos,TRUE);
		else if (sP->editCtrl)
			SetScrollPos(sP->editCtrl,sP->sb_Type,scrollPos,TRUE);
	}

    ReleasePtr(sbiH);

    return(0);

} /* TUTORreset_text_sbar */

/* ******************************************************************* */

TUTORset_slider_value(sbi,value)
Memh sbi;
double value;
    
{   struct pcscroll FAR *sp;
    long myMax;
    double dist,tmp;
	int ival;

    sp = (struct pcscroll FAR *) GetPtr(sbi);

    if ((!sp->textF) && (sp->type == SBVERT)) {
		/* invert value for vertical scroll bar */
		tmp = sp->minVal;
		dist = value-tmp;
        value = sp->maxVal-dist;
    }
    if (value >sp->maxVal) value = sp->maxVal;
    if (value < sp->minVal) value = sp->minVal;
    sp->curVal = value; 
    ival = 32767L*((sp->curVal-sp->minVal)/(sp->maxVal-sp->minVal));
	if (sp->scrollWindow)
    	SetScrollPos(sp->scrollWindow,sp->sb_Type,ival,TRUE);   
    ReleasePtr(sbi);

    return(0);

} /* TUTORset_slider_value */

/* ******************************************************************* */

double TUTORinq_slider_value(sbi)
Memh sbi;

{   struct pcscroll FAR *sp;
    double value,dist;

    sp = (struct pcscroll FAR *) GetPtr(sbi);
    value = sp->curVal;
    if ((!sp->textF) && (sp->type == SBVERT)) {
        /* invert value for vertical scroll bar */
        dist = value-sp->minVal;
        value = sp->maxVal-dist;
    }
    ReleasePtr(sbi);
    return(value);

} /* TUTORinq_slider_value */

/* ******************************************************************* */

struct tutorview FAR *TUTORinq_slider_view(theSBar)
Memh theSBar;
    
{   struct pcscroll FAR *ss;
    struct tutorview FAR *vv;

    if (!theSBar)
	return(FARNULL);
    ss = (struct pcscroll FAR *) GetPtr(theSBar);
    vv = ss->scrollV;
    ReleasePtr(theSBar);
    KillPtr(ss);

    return(vv);

} /* TUTORinq_slider_view */

/* ******************************************************************* */

int get_slider_ref(objH) /* get slider object reference count */
Memh objH; /* handle on cT object */

{   struct ebshdr FAR *objP; /* pointer to cT object */
    Memh sH; /* handle on slider info */
    struct pcscroll FAR *sp; /* pointer to slider info */
    int refcnt;
    
    if (!objH) return(0);
    objP = (struct ebshdr FAR *)GetPtr(objH);
    sH = objP->objectH; /* handle on slider info */
    ReleasePtr(objH);
    sp = (struct pcscroll FAR *)GetPtr(sH);
    refcnt = sp->ebsref; /* get reference count */
    ReleasePtr(sH);
    return(refcnt);

} /* get_slider_ref */

/* ******************************************************************* */
