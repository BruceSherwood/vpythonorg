
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University. */

/* file & io commands */

#include <stdio.h>
#include "execdefs.h"
#include "eglobals.h"
#include "tglobals.h"
#include "tfiledef.h"
#include "exprdefs.h"
#include "kglobals.h"
#include "txt.h"
#include "editor.h"
#include "video.h"

/* ******************************************************************* */

#ifdef ctproto
extern long TUTORcopy_region(long regid);
extern int PrintDoc(Memh doc,long pos,long len);
extern int TUTORprint_dialog(int wix,int type);
extern int MoviePaletteUse(int useF);
extern int MovieLoop(int loopV);
int TUTORset_dir(FileRef FAR  *path);
int  translate_ct_string(unsigned char  *s0);
extern int MovieHalt(void);
extern int MovieClose(int type);
extern int MovieShow(double time);
extern int MovieStep(long nSteps);
extern int MovieSource(int ff,long xx,long yy,long x2,long y2);
extern int TUTORinq_sys_color(int ci,double *rr,double *gg,double *bb);
extern int MovieSound(double volume);
extern long  MovieGetFrame(void);
extern long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
extern int TUTORtrace(char *s);
extern int TUTORinput_dialog(int wn,char *msg,char *input);
extern int TUTORync_dialog(int wn, char *msg);
extern int TUTORok_dialog(int wn,char *msg);
long  TUTORget_hsize(unsigned int  mm);
int  TUTORfree_handle(unsigned int  mm);
extern Memh TUTORget_default_rgb(void);
extern int CTcount_colors(int oldF);
extern void TUTORset_color(int select,struct tutorColor FAR *newColor);
int TUTORset_color_rgb(int select,int SysOrPal,double red,double green,double blue);
extern int  set_exec_pt(unsigned int  uloc);
extern long  get_exec_pt(void);
extern int TUTORwait_socket(int fIndx,int type);
extern int cmd_sockwait(void);
extern int TUTORpoll_events(int block);
int  set_exec_pt(unsigned int  uloc);
extern int MovieSupport(void);
extern int MovieOpen(FileRef *fRef);
extern int MovieRectangle(int mode,int x1,int y1,int x2,int y2,int cx1,int cy1,int cx2,int cy2,int cvis);
extern int MoviePlay(double from,double to);
extern int TUTORforce_redraw(int wid);
extern int AllowHandlePurge(Memh hh);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
int cvt_font_name(char *nstr);
int  TUTORadd_inset_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,int  kind,unsigned int  dat,long  *extraPos);
extern int TUTORblock_move(char SHUGE *aa,char SHUGE *bb,long length);
extern int arraybnds(void);
extern int cmd_block(void);
extern int UnlockExec(void);
extern int LockExec(void);
extern int cmd_forget(void);
int  TUTORget_font2(long fam,int  size,unsigned int  face,int cid);
extern int TUTORrelease_font(int findx,long fam,int size,int face,int forget);
long TUTORparse_font_family(struct  _fref *fontTag,struct  _fref *familyName,int  isFont,int  oneTag,int  *fontSize);
int CTset_background_color(int cn);
extern int TUTORset_view(struct tutorview FAR *vp);
extern int TUTORinq_foreground_color(struct tutorColor *fc);
extern int TUTORinq_background_color(struct tutorColor *bc);
int  RefreshPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  cpos,long  clen,long  newC,long  selStart,long  selLen,int  scroll,int force);
extern int StartPicture(int type,int fileid,TRect FAR *pR,int dpi);
extern int FinishPicture(void);
int ex_arrayerr(void);
long  TUTORinq_symbolic_font_id(char  *fontName);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
int  mvar_get_inf(unsigned int  docH,long  *len,long *users,long  *head);
int  TUTORmaintain_doc_view(struct  _ktd FAR *dp,long  pos,long len,long  cpos,long  clen,long  newC);
int  TUTORstyle_hot_doc(unsigned int  doc,long  pos,long  len,unsigned char FAR *ss,long  sLen);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
int  TUTORstyle_doc(unsigned int  doc,long  pos,long  len,int  type,int  dat,int  canCombine,long  *extraPos);
char FAR *TUTORalloc(long len,int abort,char *label);
int TUTORdealloc(char FAR *ptr);
extern int TUTORfree_handle(Memh hh);
extern int TUTORzero(char SHUGE *ptr,long length);
extern Memh TUTORhandle(char *name,long size, int puregewmrm);
extern  int TUTORset_file_type(FileRef FAR *fName,int findx,int type,int xx,int yy);
int cmd_style(void);
int cmd_alloc(void);
int  cmd_sound(void);
int cmd_pict(void);
int  cmd_video(void);
int cmd_vwait(void); 
int cmd_vclose(void);
int  cmd_vset(void);
int  cmd_vstep(void);
int  cmd_vshow(void);
int  cmd_vplay(void);
int  cmd_addfile(void);
int  cmd_setfile(void);
int  cmd_delfile(void);
int  cmd_setdir(void);
int  cmd_adddir(void);
int  cmd_deldir(void);
int  cmd_getdir(void);
int  cmd_reset(void);
int  cmd_datain(void);
int  cmd_dataout(void);
int  cmd_xin(void);
int  cmd_xout(void);
int  xdataio(int  type);
int  cmd_numout(void);
int  cmd_readln(void);
int  cmd_server(void);
int  cmd_socket(void);
int  xservsoc(int  type);
int  cmd_getserv(void);
int  cmd_serial(void);
int cmd_sysinfo(void);
int cmd_dialog(void);
int cmd_print(void);
int cmd_step(void);
int cmd_stepover(void);
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
int  CloseFile(long SHUGE *loc);
int  MMotionPlay(long  from,long  to,double  rate);
int  Pi6000Play(long  start,long  stop,double  speed);
int  Pi6000Step(long  nSteps);
int  MMotionSet(int  opc,int  onoff,long  arg1,long  arg2,long  arg3,long  arg4);
int  Pi6000Set(int  comm,int  onoff);
int  lclocy(long  q);
int  lclocx(long  q);
int  InitMMotionVideo(void);
int  InitExternalVideo(int  findx);
int  TUTORopen_serial(int  port,long  baud,int  datab,int  parity,double  stopb);
int  TUTORsound(struct  _fref FAR *fRef,long  soundid);
int  marker_file_name(struct  markvar FAR *mx,struct  _fref FAR *fullRef,int  symbolic);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  FinishFileOpen(long SHUGE *loc,int  findx);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  TUTORfile_exists(struct  _fref FAR *fRef);
int  setclip(void);
int  TUTORreadfile_dialog(int  wn,char  *msghdr,struct  _fref *filename,char *defname,int  maxRet,int  type,int  msgb,int  doRedraw);
int  unclip(void);
int  execerr(char  *msgstr);
int  TUTORclose(int  findx);
int  mvar_temp_cleanup(void);
int  TUTORfwrite_doc(unsigned int  doc,long  pos,long  len,int  fInd,int  nativeF);
int  FileWriteOK(long  findx);
int  fputvar(unsigned char SHUGE *vaddr,int  vkind,double  fvalue);
int  ReadNumber(int  findx,double  *value);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORfread_doc(unsigned int  doc,long  len,int  docKind,int  fInd);
int  mvar_assign(struct markvar SHUGE *vadr,struct  markvar SHUGE *mx);
int  killptr(char  FAR * FAR *ptr);
int  FileIsOpen(long  fid);
int  mvar_init(struct  markvar SHUGE *mp);
int  sizetv(int  opc);
int  flush(void);
int  TUTORreset_file(int  findx,int  option);
int  DeleteFile(long SHUGE *loc);
long  TUTORwrite(char  FAR *ptr,int  pSize,long  count,int  findx);
int  marker_to_string(struct  markvar SHUGE *mx,char  *s,int  limit);
int  TUTORwrite_char(int cc,int  findx);
long  lcftoi(double  dv);
int  iputvar(unsigned char SHUGE *vaddr,int  vkind,long  ivalue);
int  TUTORget_char(int  findx,int  tryHard);
int  TUTORsocket_client(char  *addr,int  aType,int  nn);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int  TUTORserver(char  *addr,int  aType,char  *info);
int  TUTORsocket_server(int  fInd);
int  appenddoc(unsigned int  theDoc,char  FAR *sP,int  sLen);
int  TUTORcvt_native_chars(unsigned char  FAR *cp,long  clen);
int  TUTORchange_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,unsigned char  FAR *cp,long  cLen,long  fromOff,unsigned int  styles,unsigned int  specialT,long  *extraPos,int  eupFlag);
int  TUTORhosts(char  *addr,int  nn,char  *info,int  infoSize,int  *nNames);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
#ifndef THINKC5
#ifndef WERKS
extern int sprintf(char *ss, char *form, ...);
extern int printf(char *form, ...);
#endif
#endif
#endif

extern long TUTORget_len_doc();
extern long l_bin();
extern long l_read();
extern double f_bin();
extern double f_read();
extern long array_addr();
extern  double lcfsysv();
extern  long lcmsysa();
extern  long lcbitcnt();
extern double CoordToFloat();
extern long pass_addr();
extern long get_exec_pt();
extern  int TimedPauseStub();
extern double evalduser();
extern Memh darrowv(); /* handle on arrow text */
extern Memh dtextv();   /* handle on displayed text */
extern  Coord IntToCoord();
extern  Coord FloatToCoord();
extern  Coord DivCoord();
extern  long TUTORwrite();
extern char FAR *GetPtr();
extern  long TUTORread();
extern long lcftoi();
extern Memh TUTORcopy_handle();
extern long TUTORinq_msec_clock();
long  TUTORabs_save_region();
extern char FAR *TUTORalloc();
extern long MovieGetFrame();

/* ******************************************************************* */

extern int execrun; /* executor run/return flag */
extern int movieCtrlH; /* movie controller height */
extern int DebugWn; /* debugger window */

#ifndef long_align
#define long_read(addr) (*(long SHUGE *)(addr))
#define flt_read(addr) (*(double SHUGE *)(addr))
#else
#define long_read(addr) (l_read(addr))
#define flt_read(addr) (f_read(addr))
#endif

#ifndef style_plain
#define style_plain 0
#endif

/* ------------------------------------------------------------------- */

cmd_sound() /* -sound- command execution */

{   FileRef fRef; /* sound file */
    long soundid; /* index of sound */
    int retf; 

    iresP = istack; /* void stacks */
    markP = markstack;

    exS.zreturn = -1; /* pre-set worked */
    soundid = istack[0];

    /* evaluate file name expression */

    marker_file_name(markP,(FileRef FAR *) &fRef,TRUE); 
   
    retf = TUTORsound((FileRef FAR *)&fRef,soundid);
    if (retf) 
        exS.zreturn = retf;

} /* cmd_sound */

/* ------------------------------------------------------------------- */

cmd_pict() /* -pict- command execution */

{   int nn; /* number items on integer stack */
	int nm; /* number items on marker stack */
    FileRef fRef; /* pict file */
    int fileid; /* index in ct file table */
    int pret;
    Coord x1,y1,x2,y2;
    long templ;
    int dotsInch; /* dots-per-inch */
  
  	nn = iresP-istack;
    nm = markP-markstack;
    iresP = istack; /* void stacks */
    markP = markstack;
    
	dotsInch = 0;
    exS.zreturn = -1; /* pre-set worked */
    x1 = x2 = y1 = y2 = -1;
    
    /* process blank-tag form - close current picture */
    
    if (nm == 0) { 
        nn = FinishPicture();
        if (!nn)
        	exS.zreturn = FILEMEM;
        return;
    } /* nm if */
 
    /* evaluate file name expression */

    marker_file_name(markP,(FileRef FAR *) &fRef,TRUE); 

	if (nn > 0) {
		dotsInch = istack[0];
	}
	
#ifdef NOSUCH
       
    /* pick up co-ordinates if present */
    
    if (nn >= 4) {
    	x1 = istack[0];
    	y1 = istack[1];
    	x2 = istack[2];
    	y2 = istack[3];
    	x1 = exS.OffsetX+lclocx(x1);
        y1 = exS.OffsetY+lclocy(y1);
        x2 = exS.OffsetX+lclocx(x2);
        y2 = exS.OffsetY+lclocy(y2);

        /* normalize rectangle */

        if (x2 < x1) {
            templ = x2;
            x2 = x1;
            x1 = templ;
        }
        if (y2 < y1) {
            templ = y2;
            y2 = y1;
            y1 = templ;
        }
        if (((x2-x1) <= 0) || ((y2-y1) <= 0)) {
        	exS.zreturn = FILEREGION;
            return(0);
        }
    }
#endif
    
    /* open picture file */
    
    fileid = TUTORopen((FileRef FAR *)&fRef,FALSE,TRUE,FALSE);
    if (fileid <= 0) {
        exS.zreturn = FILEMISSING;
        return;
    } /* fileid if */
    
    pret = StartPicture(1,fileid,FARNULL,dotsInch); /* start building picture */
    
    if (!pret) 
        exS.zreturn = FILEMISSING; /* something went wrong */
    else
        exS.pictF = 1; /* building picture */

} /* cmd_pict */

/* ------------------------------------------------------------------- */

cmd_video() /* -video- command execution */

{   int nn,nm,nf,nii,fii;
    int modeF; /* clip/scale mode */
    int playF; /* play movie flag */
    int rectF; /* movie rectangle flag */
    int controlF; /* movie controller flag */
    int ctrlRectF; /* controller rectangle specified */
    int soundF; /* sound volume flag */
    int loopF; /* loop movie specified */
    int loopV; /* loop movie flag */
    int paletteV; /* palette flag */
    int playRange; /* TRUE if controller/play range set */
    double playFrom,playTo;
    double soundV;
    Coord x1,y1,x2,y2; /* movie rectangle coordinates */
    Coord ctrlX1,ctrlY1,ctrlX2,ctrlY2; /* controller rectangle */
    FileRef fRef; /* cT file reference */
    long tmpl;

    exS.zreturn = -1;
    nn = iresP-istack;
    nf = fresP-fstack;
    nm = markP-markstack;
    iresP = istack; /* void stacks */
    fresP = fstack;
    markP = markstack;
    
   	execrun = FALSE; /* return from executor */
	waitflag = atinterrupt; 
    
    if ((nn == 0) && (nm == 0) && (nf == 0)) { /* blank tag */
    	MovieClose(0);
    	return;
    }
    if (istack[0] == 0) vid_kind = 1; /* serial port */
    else if (istack[0] == 1) vid_kind = 2; /* mmotion video */
    else if (istack[0] == 2) vid_kind = 3; /* QT or VFW */
    else vid_kind = -1;
    playFrom = playTo = -1.0;
    
    switch (vid_kind) {

    case 1: /* external player/monitor on serial port */
		exS.zreturn = FILENOTSUP;
        break;

    case 2: /* IBM M-Motion video card */
		exS.zreturn = FILENOTSUP;
        break;

    case 3: /* QuickTime or Video For Windows */
    	exS.vidMode = 1; /* default mode for vset = scale */
        modeF = -1; /* default is not to scale movie to box */
        rectF = 0; /* default is no rectangle */
        playF = 0; /* default is not to play */
        controlF = ctrlRectF = 0; /* default is no controller */
        soundF = 0; /* default sound setting - no change */
        loopF = 0; /* default loop setting - don't loop */
        paletteV = TRUE;
        
        /* evaluate file name expression */

		if (!markP->len) {
			exS.zreturn = FILEMISSING;
			return(0);
		}
        marker_file_name(markP,(FileRef FAR *) &fRef,TRUE); 
    
        if (nn > 1) {
        
            /* get movie display rectangle */
    
            x1 = istack[1];
            y1 = istack[2];
            x2 = istack[3];
            y2 = istack[4];
            x1 = exS.OffsetX + lclocx(x1);
            y1 = exS.OffsetY + lclocy(y1);
            x2 = exS.OffsetX + lclocx(x2);
            y2 = exS.OffsetY + lclocy(y2);

            /* normalize rectangle */

            if (x1 > x2) { /* normalize x */
                tmpl = x1; x1 = x2; x1 = tmpl;
            }
            if (y1 > y2) { /* normalize y */
                tmpl = y1; y1 = y2; y2 = tmpl;
            }
            
            /* remember rectangle */
            
            exS.vidX1 = x1;
            exS.vidY1 = y1;
            exS.vidX2 = x2;
            exS.vidY2 = y2;
            rectF = TRUE;
        } /* nn if */
        
        /* process additional arguments */
        
        nii = 5;
        fii = 0;
        while (nii < nn) {
            switch (istack[nii++]) {
            
            case 1:
                modeF = 0; /* no scale */
                break;
                
            case 2:
                modeF = 1; /* scale */
                break;
                
            case 3:
                modeF = 2; /* center */
                break;
                
            case 4:
                playF = TRUE; /* play */
                break;
                
            case 5:
            	controlF = TRUE; /* use movie controller */
            	break;
            	
            case 6: /* controller range */
            	playRange = controlF = TRUE; /* range set */
            	playFrom = fstack[fii++];
            	playTo = fstack[fii++];
            	break;
            	
            case 7: /* sound volume */
            	soundF = TRUE; /* sound set */
            	soundV = fstack[fii++];
            	break;
            	
            case 8: /* controller rectangle */
            	ctrlRectF = controlF = TRUE;
            	ctrlX1 = istack[nii++];
            	ctrlY1 = istack[nii++];
            	ctrlX2 = istack[nii++];
            	ctrlY2 = istack[nii++];
            	ctrlX1 = exS.OffsetX + lclocx(ctrlX1);
            	ctrlY1 = exS.OffsetY + lclocy(ctrlY1);
            	ctrlX2 = exS.OffsetX + lclocx(ctrlX2);
            	ctrlY2 = exS.OffsetY + lclocy(ctrlY2);

            	/* normalize rectangle */

            	if (ctrlX1 > ctrlX2) { /* normalize x */
                	tmpl = ctrlX1; ctrlX1 = ctrlX2; ctrlX1 = tmpl;
            	}
            	if (ctrlY1 > ctrlY2) { /* normalize y */
                	tmpl = ctrlY1; ctrlY1 = ctrlY2; ctrlY2 = tmpl;
                }
            	break;
            	
            case 9: /* loop */
            	loopF = TRUE;
            	loopV = 0;
            	if (istack[nii++] < 0)
            		loopV = TRUE;
            	break;
            	
            case 10: /* palette */
            	paletteV = 0;
            	if (istack[nii++] < 0)
            		paletteV = TRUE;
            	break;
            	
            } /* switch */
        } /* nii while */
		
        /* open movie file */
   
        exS.zreturn = MovieOpen(&fRef);
        if (exS.zreturn >= 0) 
            break; /* open failed */
		exS.didPalette++;
		   
        /* set volume level if specified */
        
        if (soundF) {
 			exS.zreturn = MovieSound(soundV);	 
 			if (exS.zreturn >= 0)
 				return; /* failed */
 		}   	   
 		
 		/* set palette usage */
 		
 		MoviePaletteUse(paletteV);
 		
 		/* set up controller and/or video rectangle */
 		
 		if (modeF == -1) 
 			modeF = 1; /* default is scale */    
 			
 		if (!ctrlRectF) { /* default rectangle */
        	ctrlX1 = exS.vidX1;
        	ctrlY1 = exS.vidY2+1;
        	ctrlX2 = exS.vidX2;
        	ctrlY2 = exS.vidY2+movieCtrlH+2;
        } 
            
        if (controlF || rectF)    
        	exS.zreturn = MovieRectangle(modeF,x1,y1,x2,y2,ctrlX1,ctrlY1,ctrlX2,ctrlY2,controlF); 
        
        if (loopF) /* set loop flag */
 			MovieLoop(loopV);
 			
   	    /* play movie */
        
	    if ((exS.zreturn == -1) && playF)
			exS.zreturn = MoviePlay(0.0,-1.0); /* play entire movie */     

        break;
        
    default: /* no video equipment identified */
        exS.zreturn = FILENOTOPEN;
        break;

    } /* switch */
    
    if (exS.zreturn != -1)
        vid_kind = -1; /* no video */

} /* cmd_video */

/* ------------------------------------------------------------------- */  

cmd_vclose() /* -vclose- internal command to close current movie */

{
	MovieClose(0);
    execrun = FALSE; /* return from executor */
    waitflag = atinterrupt;  
    return(0); 

} /* cmd_vclose */
       
/* ------------------------------------------------------------------- */

cmd_vwait() /* -vwait- (internal) command execution */

{	int opType;

    if (opType = MovieSupport()) {
    	if (opType == 2) {
    		/* back-up uloc to re-execute this command */
    		exS.uloc = (((unsigned char FAR *)(ex_binP))-pcodep)-2; 
      		set_exec_pt(exS.uloc); 
      	}
    	TUTORpoll_events(FALSE);
        execrun = FALSE; /* return from executor */
        waitflag = atinterrupt;
    } /* shouldint if */
    return(0);
    
} /* cmd_vwait */

/* ------------------------------------------------------------------- */

cmd_vset() /* -vset- command execution */

{   int nn,nm,nf,nii,fii;
    int modeF; /* clip/scale mode */
    int rectF; /* rectangle flag */
    int controlF; /* movie controller flag */
    int playF; /* play movie flag */
    int soundF; /* sound volume flag */
    int loopF; /* movie loop specified */
    int loopV; /* movie loop flag */
    int paletteF; /* palette tag specified */
    int paletteV; /* palette flag */
    int playRange; /* TRUE if controller/play range set */
    int ctrlRectF; /* controller rectangle specified */
    double playFrom,playTo;
    double soundV;
    Coord x1,y1,x2,y2; /* movie rectangle coordinates */
    Coord ctrlX1,ctrlY1,ctrlX2,ctrlY2; /* controller rectangle */
    FileRef fRef; /* cT file reference */
    long tmpl;

    exS.zreturn = -1;
    nn = iresP-istack;
    nf = fresP-fstack;
    nm = markP-markstack;
    iresP = istack; /* void stacks */
    fresP = fstack;
    markP = markstack;
    modeF = -1; /* no mode tag yet */
    rectF = 0; /* no rectangle yet */
    controlF = ctrlRectF = paletteF = 0; /* no controller tag yet */
    soundF = 0; /* no sound tag yet */
    loopF = 0; /* loop not specified */
    playF = 0; /* don't play movie */
    playFrom = playTo = -1.0;
    
    x1 = exS.vidX1; /* pre-set to current rectangle */
 	y1 = exS.vidY1;
 	x2 = exS.vidX2;
 	y2 = exS.vidY2;
 	
    nii = 0;
    fii = 0;
    while (nii < nn) {
        switch (istack[nii++]) {
            
        case 0: /* movie display rectangle */
        	rectF = TRUE;
            x1 = istack[nii++];
            y1 = istack[nii++];
            x2 = istack[nii++];
            y2 = istack[nii++];
            x1 = exS.OffsetX + lclocx(x1);
            y1 = exS.OffsetY + lclocy(y1);
            x2 = exS.OffsetX + lclocx(x2);
            y2 = exS.OffsetY + lclocy(y2);

            /* normalize rectangle */

            if (x1 > x2) { /* normalize x */
                tmpl = x1; x1 = x2; x1 = tmpl;
            }
            if (y1 > y2) { /* normalize y */
                tmpl = y1; y1 = y2; y2 = tmpl;
            }
                        
            /* remember rectangle */
            
            exS.vidX1 = x1;
            exS.vidY1 = y1;
            exS.vidX2 = x2;
            exS.vidY2 = y2;
            break;
            	
        case 1:
            modeF = 0; /* no scale */
            break;
                
        case 2:
            modeF = 1; /* scale */
            break;
                
        case 3:
            modeF = 2; /* center */
            break;
            
        case 4:
            playF = TRUE; /* play */
            break;            
            
        case 5:
        	controlF = TRUE; /* use movie controller */
            break;
            	
        case 6:
        	playRange = TRUE; /* range set */
        	controlF = TRUE; /* must have controller */
            playFrom = fstack[fii++];
            playTo = fstack[fii++];
            break;
            	
        case 7:
        	soundF = TRUE; /* sound set */
            soundV = fstack[fii++];
            break;
            
        case 8: /* controller rectangle */
            ctrlRectF = controlF = TRUE;
            ctrlX1 = istack[nii++];
            ctrlY1 = istack[nii++];
            ctrlX2 = istack[nii++];
            ctrlY2 = istack[nii++];
            ctrlX1 = exS.OffsetX + lclocx(ctrlX1);
            ctrlY1 = exS.OffsetY + lclocy(ctrlY1);
            ctrlX2 = exS.OffsetX + lclocx(ctrlX2);
            ctrlY2 = exS.OffsetY + lclocy(ctrlY2);

            /* normalize rectangle */

            if (ctrlX1 > ctrlX2) { /* normalize x */
                tmpl = ctrlX1; ctrlX1 = ctrlX2; ctrlX1 = tmpl;
            }
            if (ctrlY1 > ctrlY2) { /* normalize y */
                tmpl = ctrlY1; ctrlY1 = ctrlY2; ctrlY2 = tmpl;
            }
            break;  
            
		case 9: /* loop */
			loopF = TRUE; /* loop specified */
			loopV = 0;
			if (istack[nii++] < 0)
				loopV = TRUE;
			break; 
			
		case 10: /* palette */
			paletteF = TRUE; /* palette specified */
			paletteV = 0;
			if (istack[nii++] < 0)
				paletteV = TRUE;
			break;  
			                   
        } /* switch */
    } /* nii while */
		
    /* set volume level if specified */
        
    if (soundF) {
 		exS.zreturn = MovieSound(soundV);	 
 		if (exS.zreturn >= 0)
 			return; /* failed */
 	}   	
 	   	
 	/* set up for controller */
    	
    if (modeF == -1) 
    	modeF = exS.vidMode; /* use current mode */
    if (!ctrlRectF) {
        ctrlX1 = exS.vidX1;
        ctrlY1 = exS.vidY2+1;
        ctrlX2 = exS.vidX2;
        ctrlY2 = exS.vidY2+movieCtrlH+2;
    } 
    if (paletteF) 
    	MoviePaletteUse(paletteV); 
    
    /* set up movie rectangle if neccessary */
    	
    if (rectF || (modeF != -1) || ctrlRectF) {
    	if (modeF == -1)
    		modeF = exS.vidMode; /* use current */
    	exS.zreturn = MovieRectangle(modeF,x1,y1,x2,y2,ctrlX1,ctrlY1,ctrlX2,ctrlY2,controlF);
        if (exS.zreturn >= 0)
            return; /* failed */
	}
        
 	if (loopF) /* set movie loop flag if neccessary */
 		MovieLoop(loopV);	
 	
 	if ((exS.zreturn == -1) && playF)
		exS.zreturn = MoviePlay(0.0,-1.0); /* play entire movie */   	
    
	execrun = FALSE; /* return from executor */
	waitflag = atinterrupt;
	TUTORpoll_events(FALSE);
 
} /* cmd_vset */

/* ------------------------------------------------------------------- */

cmd_vstep() /* -vstep- command execution */

{
	iresP = istack; /* void stack */
	
	switch (vid_kind) {
    	
    case 3: /* QuickTime or Video for Windows */
    	exS.zreturn = MovieStep(istack[0]);
    	break;
    	
    default:
    	exS.zreturn = FILENOTSUP;
    	break;
    	
    } /* switch */

} /* cmd_vstep */

/* ------------------------------------------------------------------- */

cmd_vshow() /* -vshow- command execution */

{   double mTime;

	fresP = fstack;
    mTime = fstack[0];

    switch (vid_kind) {

    case 1:
#ifdef NOSUCH
        Pi6000Play(frame,frame,0.);
#endif
		exS.zreturn = FILENOTSUP;
        break;

    case 2:
#ifdef NOSUCH
        MMotionPlay(frame,frame,0.);
#endif
		exS.zreturn = FILENOTSUP;
        break;

    case 3:
        exS.zreturn = MovieShow(mTime);
        break;
        
    default:
        break;

    } /* switch */

} /* cmd_vshow */

/* ------------------------------------------------------------------- */

cmd_vplay() /* -vplay- command execution */

{   int nn;

	nn = fresP-fstack;
    iresP = istack; /* void stacks */
    fresP = fstack;
    if (nn == 0) { /* no arguments */
    	fstack[0] = 0.0;
    	fstack[1] = -1.0;
    }

    switch (vid_kind) {

    case 1:
#ifdef NOSUCH
        Pi6000Play(istack[0],istack[1],fstack[0]);
#endif
		exS.zreturn = FILENOTSUP;
        break;

    case 2:
#ifdef NOSUCH
        MMotionPlay(istack[0],istack[1],fstack[0]);
#endif
		exS.zreturn = FILENOTSUP;
        break;

    case 3:
        exS.zreturn = MoviePlay(fstack[0],fstack[1]);
        break;
        
    default:
        break;

    } /* switch */
 
} /* cmd_vplay */

/* ------------------------------------------------------------------- */   

cmd_addfile() /* -addfile- command execution */

{   int nn; /* number items on integer stack */      
	int nm; /* number items on marker stack */
    int ni; /* index in integer stack */
    long SHUGE *faddr; /* address of file variable */
    int fileid; /* index of file in table */
    int retf; /* dialog return */
    int styledf; /* TRUE if styled text */
    struct tutorColor fc,bc; /* saved foreground/background colors */
    FileRef fRef;
    struct tutorview FAR *mfocus; /* saved menu focus */
    struct tutorview FAR *kfocus; /* saved key foucs */
    struct tutorfile FAR *fptr; /* pointer to file info */  
    char dfn[CTPATHLEN+1]; /* suggested file name */
    struct markvar SHUGE *mx; /* marker with suggested file name */ 
    long mlen; /* length of file name */

    nn = iresP-istack;            
    nm = markP-markstack;
    iresP = istack; /* void stack */
    markP = markstack;

    exS.zreturn = -1; /* indicates operation ok */
    faddr = (long SHUGE *)istack[2]; /* address of file variable */
    retf = styledf = 0;      
    dfn[0] = 0; /* no suggested file name yet */
 
    CloseFile(faddr);
    *faddr = (-1); /* initialize contents of author variable */

    ni = 4; /* index in integer stack */
    while (ni < nn) {
        switch (istack[ni]) {

        case KW_STYLED: /* accept styled text */
            styledf = (istack[ni+1] < 0);
            ni += 2;
            break;
        
        case KW_FNAME: /* file name specified */ 
        	mx = markP+1;        
        	mlen = mx->len;
        	if (mlen > CTPATHLEN)
        		mlen = CTPATHLEN;
          	TUTORget_string_doc(mx->doc,mx->pos,(long) mlen,(unsigned char FAR *) dfn);
        	ni += 1;
        	break;
        	
        default:
            execerr("Unrecognized option");

        } /* end of switch */
    } /* end of while (ni < nn) */
    
    if (markP->len == 0) {

        /* open dialog to get file name */

		TUTORcopy_fileref((FileRef FAR *) &fRef,currentDirP);
        mfocus = windowsP[ExecWn].MenuFocus; /* preserve focus */
        kfocus = windowsP[ExecWn].KeyFocus;
        TUTORinq_foreground_color(&fc);
        TUTORinq_background_color(&bc);
        unclip();
        retf = TUTORreadfile_dialog(ExecWn,"Create:", &fRef,dfn,0,5,2,FALSE);
        TUTORset_view(ExecVp); /* insure set to exec view */
        setclip();
        TUTORset_color(0,&fc);
        TUTORset_color(1,&bc);
        windowsP[ExecWn].MenuFocus = mfocus;  /* restore focus */
        windowsP[ExecWn].KeyFocus = kfocus;
        if (exS.modal_dialog_redraw) {
            /* force redraw if unprocessed redraw during dialog */
            TUTORforce_redraw(exS.baseView->window);
            exS.modal_dialog_redraw = FALSE;
        }
        if (retf != 1) {
            if (retf == 2)
                exS.zreturn = FILECANCEL; /* dialog canceled */
            else if (retf == 3)
                exS.zreturn = FILEREGION; /* not enough screen space */
            else if (retf == 4)
                exS.zreturn = FILEMEM; /* not enough memory */
            else if (retf == 5) exS.zreturn = FILEBAKWIN;
            else 
                exS.zreturn = FILEMISSING; /* unrec error */
            return(0);
        }
    } else {

        /* evaluate file name */

        marker_file_name(markP,(FileRef FAR *)&fRef,FALSE); 
    } /* len else */

    /* check if file already exists */

    if ((retf == 0) && TUTORfile_exists((FileRef FAR *) &fRef)) {
        exS.zreturn = FILEDUP; /* duplicate file */
        return(0); /* exit if duplicate, no dialog box */
    }

    /* create the file */

    fileid = TUTORopen((FileRef FAR *)&fRef,FALSE,TRUE,FALSE);
    if (fileid) {
        TUTORset_file_type((FileRef FAR *) &fRef,fileid,1, -10000,-10000);
        TUTORclose(fileid); /* close new file */
    	/* try to open for read+write */
    	fileid = TUTORopen((FileRef FAR *) &fRef,TRUE,TRUE,FALSE); 
    	if (fileid <= 0) /* fall back to write-only */
        	fileid = TUTORopen((FileRef FAR *) &fRef,FALSE,TRUE,FALSE); 
    }
    FinishFileOpen(faddr,fileid);

    /* set lastop, styled fields for new file */

    if (fileid > 0) {
        fptr = fileid+(struct tutorfile FAR *)GetPtr(filesopen);
        fptr->lastop = fop_new;
	fptr->styles_allowed = styledf;
#ifdef IBMPC
	fptr->crKind = 2; /* 0x0d, 0x0a */
#endif
#ifdef MAC
	fptr->crKind = 1; /* 0x0d */
#endif
	if (fptr->crKind == -1)
	    fptr->crKind = 0; /* 0x0a */
        ReleasePtr(filesopen);
    } /* fileid if */

} /* cmd_addfile */

/* ------------------------------------------------------------------- */

cmd_setfile() /* -setfile- command execution */

{   int nn,ni;
    long SHUGE *faddr; /* address of file variable */
    register int fileid; /* index in file table */
    int rw,ro,wo; /* read write/read oonly/write only flags */
    int retf; /* dialog return */
    int boolf; /* boolean argument value */
    int styledf; /* styled-file flag */
    struct tutorColor fc,bc; /* saved foreground/background colors */
    FileRef fRef;
    struct tutorview FAR *mfocus; /* menu focus */
    struct tutorview FAR *kfocus; /* key focus */
    struct tutorfile FAR *fptr; /* pointer to file info */

    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* void stack */
    markP = markstack;

    exS.zreturn = -1; /* indicates operation ok */
    ro = wo = rw = FALSE; /* neither read/write or read-only */
    styledf = FALSE; /* not styled */
    faddr = (long SHUGE *)istack[2];
    CloseFile(faddr);
    if (nn <= 4) return(0); /* exit if close operation */

    *(long FAR *) (faddr) = -1; /* initialize contents of author variable */
    ni = 4; /* index in integer stack */

    while (ni < nn) {
        boolf = (istack[ni+1] < 0); /* possible boolean flag */
        switch (istack[ni]) {

        case KW_READONLY: /* read-only file */
            ro = boolf;
            ni += 2;
            break;
            
        case KW_WRITEONLY: /* write-only file */
        	wo = boolf;
        	ni += 2;
        	break;
 
        case KW_READWRITE: /* read/write file */
            rw = boolf;
            ni += 2;
            break;

        case KW_STYLED: /* accept styled text */
            styledf = boolf;
            ni += 2;
            break;

        default:
            execerr("Unrecognized option");

        } /* end of switch */
    } /* end of while (ni < nn) */

    ni = 0;
    if (ro) ni++;
    if (rw) ni++;
    if (wo) ni++;
    if (ni == 0)
	ro = TRUE; /* assume read-only */
    else if (ni != 1)
        execerr("File read/write options wrong");
    
    if (markP->len == 0) {

        /* open dialog to get file name */

	TUTORcopy_fileref((FileRef FAR *) &fRef,currentDirP);
        mfocus = windowsP[ExecWn].MenuFocus; /* preserve focus */
        kfocus = windowsP[ExecWn].KeyFocus;
        TUTORinq_foreground_color(&fc);
        TUTORinq_background_color(&bc);
        unclip();
        retf = TUTORreadfile_dialog(ExecWn,"Open:", &fRef,NEARNULL,0,5,1,FALSE);
        TUTORset_view(ExecVp); /* insure set to exec view */
        setclip();
        TUTORset_color(0,&fc);
        TUTORset_color(1,&bc);
        windowsP[ExecWn].MenuFocus = mfocus;  /* restore focus */
        windowsP[ExecWn].KeyFocus = kfocus;
        if (exS.modal_dialog_redraw) {
            /* force redraw if unprocessed redraw during dialog */
            TUTORforce_redraw(exS.baseView->window);
            exS.modal_dialog_redraw = FALSE;
        }
        if (retf != 1) {
            if (retf == 2)
                exS.zreturn = FILECANCEL; /* dialog box cancled */
            else if (retf == 3)
                exS.zreturn = FILEREGION; /* not enough screen space */
            else if (retf == 4)
                exS.zreturn = FILEMEM; /* not enough memory for dialog */
            else if (retf == 5) 
           		exS.zreturn = FILEBAKWIN; /* not front window */
            else
                exS.zreturn = FILEMISSING; /* unrec error */
            return(0);
        }
    } else {

        /* evaluate file name */

        marker_file_name(markP,(FileRef FAR *)&fRef,FALSE); 
    } /* len else */
 
    if (!wo) {
    	if (!TUTORfile_exists((FileRef FAR *) &fRef)) {
	    exS.zreturn = FILEMISSING; /* file not found */
	    return(0);
    	} /* TUTORfile_exists if */
    }
	
    fileid = TUTORopen((FileRef FAR *) &fRef,(!wo),(!ro),FALSE);
    FinishFileOpen(faddr,fileid);
 
    if (fileid > 0) {
        fptr = fileid+(struct tutorfile FAR *)GetPtr(filesopen);
	fptr->styles_allowed = styledf;
	ReleasePtr(filesopen);
    } /* fileid if */

    return(0);

} /* cmd_setfile */

/* ------------------------------------------------------------------- */

cmd_delfile() /* -delfile- command execution */

{   long fid;
    long SHUGE *faddr;

    iresP = istack; /* void stack */
    exS.zreturn = -1; /* indicates operation ok */
    fid = istack[0];
    faddr = (long SHUGE *)istack[2];
    if (!FileIsOpen(fid)) {
        exS.zreturn = FILENOTOPEN;
        return(0);
    }
    DeleteFile(faddr);

} /* cmd_delfile */


/* ------------------------------------------------------------------- */

int cmd_setdir() 

{   FileRef wfn; 
	long mlen;
	  
    iresP = istack; /* void stacks */
    markP = markstack;
	TUTORzero((char FAR *)&wfn,(long)sizeof(FileRef));
	
	/* evaluate file name */

    mlen = markP->len;
    if (mlen > CTPATHLEN) 
        execerr("File name too long.");
    
    TUTORget_string_doc(markP->doc,markP->pos,mlen,(unsigned char FAR *) &wfn.path[0]);
    if (!translate_ct_string((unsigned char *) &wfn.path[0]))
        execerr("Illegal character in file name.");

    exS.zreturn = TUTORset_dir((FileRef FAR *)&wfn);
   
	return(0); 
	
} /* cmd_setdir */

/* ------------------------------------------------------------------- */

int cmd_adddir() { return(0); }
int cmd_deldir() { return(0); }
int cmd_getdir() { return(0); }

/* ------------------------------------------------------------------- */

cmd_reset() /* -reset- command execution */

{   register int findex; /* index of file in table */
    register int option; /* type of reset operation */
    
    iresP = istack; /* void stack */
    exS.zreturn = -1; /* indicates operation ok */
    findex = istack[0];
    option = istack[1];
    if (!FileIsOpen(findex)) {
        exS.zreturn = FILENOTOPEN;
        return(0);
    }
    TUTORreset_file(findex,option);
    exS.zreturn = tfilerr;
 
} /* cmd_reset */

/* ------------------------------------------------------------------- */

cmd_datain() { xdataio(0); } /* -datain- command execution */
cmd_dataout() { xdataio(1); } /* -dataout- command execution */
cmd_xin() { xdataio(2); } /* -xin- command execution */
cmd_xout() { xdataio(3); } /* -xout- command execution */

xdataio(type) /* datain, dataout command execution */
int type; /* 0 = datain, 1 = dataout, 2 = xin, 3 = xout */

{   int nn; 
    int arrayf; /* TRUE if full array */
    int lengthf; /* TRUE if length specified */
    int kind; /* type (int, float, mark) of data */
    unsigned char SHUGE *vaddr; /* address of buffer */
    int vsize; /* size of item in buffer */
    register long maxlth; /* maximum amount to read */
    int fileid; /* index in file table */
    register long amtrw; /* number data items actually read */
    struct markvar mx; /* copy of marker */
    struct markvar SHUGE *mxp; /* pointer to marker */
    struct tutorfile FAR *tfp; /* pointer to file info */
    double numeric; /* numeric input */
    int mayblock; /* TRUE if long time-out on input */
    int DocKind; /* document type for read/write */
    int styledf; /* TRUE if styled file */
    int waitF; /* TRUE if need to wait on socket operation */
    long tempL;
    int cc; /* current character code */
    int postWait; /* TRUE if should interrupt after command */
    int fkind;
    long SHUGE *llp;
    char tmpbuf[100]; /* temporary buffer for string input */
    
    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* void stacks */
    fresP = fstack;
    markP = markstack;

    exS.loopcounter += 20; /* crude means of enforcing interrupts */
    exS.zreturn = -1; /* indicates operation ok */
    exS.zretinf = amtrw = 0; /* no data read/written yet */
    postWait = FALSE;
    flush();
    
    /* process file argument */

    fileid = istack[0];
    if (!FileIsOpen(fileid)) {
        exS.zreturn = FILENOTOPEN;
        return(0);
    } /* not open if */
   
    /* check if must block */
    
    if ((type == 0) || (type == 2)) {
        waitF = TUTORwait_socket(fileid,3); /* check if need to wait before read */
    } else {
        waitF = TUTORwait_socket(fileid,2); /* check if need to wait before write */
    }
    if (waitF) { /* need to wait before I/O operation */
        set_exec_pt(exS.markpt); /* back up to -markpt- cmd */
        execrun = FALSE; /* return from executor */
        waitflag = atinterrupt;
        TUTORpoll_events(TRUE);
        return(0);
    }
    
    lengthf = istack[nn-1]; /* TRUE if length present */
    arrayf = istack[nn-2]; /* TRUE if full array */
    kind = istack[2]; /* input variable kind */
    vsize = sizetv(kind); /* size of item */
    if (kind == TMARK) {
        if ((type == 0) || (type == 2)) {
            vaddr = (unsigned char SHUGE *)istack[3]; /* variable address */
            mvar_init((struct markvar SHUGE *)&mx); /* initialize temp marker */
        } else mx = markstack[0]; /* copy temp marker */
        maxlth = 0x7fffffffL; /* no limit on marker */
    } else {
        vaddr = (unsigned char SHUGE *)istack[3]; /* buffer address */
        if (arrayf == 1) 
            vaddr += ARRAYHDR; /* skip past array header */
        else if (arrayf == 2) { /* dynamic array */
            if (istack[4] <= 0)
                ex_arrayerr();
            llp = ((long SHUGE *)vaddr)+1;
            vaddr = (unsigned char SHUGE *)(*llp); /* address of actual array */
        }
        maxlth = istack[4]; /* maximum number items */
    }

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += fileid;
    styledf = tfp->styles_allowed; /* TRUE if may be read as styled file */
    if (tfp->kind == 6)
        postWait = TRUE;
    ReleasePtr(filesopen);
    KillPtr(tfp);
    if (styledf) DocKind = -1; /* determine file type */
    else DocKind = 0; /* native */

    /* process length argument */

    if (lengthf) {
        if ((istack[4] != -1) && (istack[5] != 1)) { /* literal */
            if (istack[5] > maxlth)
                execerr("Array address out of bounds.");
        }
        maxlth = istack[5];
    } /* length if */

    switch(type) {

    case 0: /* -datain- */
        if (kind == TMARK) {

            /* process string read into marker */

            mxp = &mx;
            mvar_assign((struct markvar SHUGE *)vaddr,mxp); /* assign (empty) temp marker to var */
            TUTORfread_doc(mx.doc,maxlth,DocKind,fileid);

            /* set marker position/length */

            mxp = (struct markvar SHUGE *)vaddr;
            mxp->pos = 0;
        	mxp->len = amtrw = TUTORget_len_doc(mx.doc);
        	mxp->doclen = mxp->len;
        	mvar_temp_cleanup();
        } else {

            /* process numeric read */

            for (amtrw = 0; amtrw < maxlth; amtrw++) {
                if (!ReadNumber(fileid,&numeric)) break;
                fputvar(vaddr,kind,numeric);
                vaddr += vsize;
            } /* for */
        } /* numeric else */
        break; /* -datain- */

    case 1: /* -dataout- */
        if ((cc = FileWriteOK(fileid)) >= 0) {
            exS.zreturn = cc; /* err if not positioned for write */
            return(0);
        } /* cc if */

        if (kind == TMARK) {

            /* string output - write marked region to file */
            tempL = (maxlth < mx.len) ? maxlth : mx.len;
            TUTORfwrite_doc(mx.doc,mx.pos,tempL,fileid,!styledf);
            amtrw = tempL;
            mvar_temp_cleanup();
        } else {

            /* numeric output */

            for (amtrw = 0; amtrw < maxlth; amtrw++) {
                if (maxlth > 1) { /* array */
                    if (vsize == sizeof(long))
                        numeric = long_read(vaddr);
                    else if (vsize == sizeof(char))
                        numeric = *(vaddr);
                    else {
                        numeric = *(double SHUGE *)(vaddr);
                    }
                } else { /* single value */
                    if (kind == TFLOAT) 
                        numeric = fstack[0];
                    else numeric = istack[1];
                } /* else */
                vaddr += vsize;
                sprintf(tmpbuf," %.*G%c",15,numeric,NEWLINE);
                TUTORwrite((char FAR *)tmpbuf,(int)sizeof(char),
                           (long)strlen(tmpbuf),fileid);
            } /* for */
        } /* numeric else */
        break; /* -dataout- */

    case 2: /* -xin- command */
        if (styledf)
            execerr("can't use -xin- command on styled file");
		if (vsize == sizeof(char)) {
			amtrw = TUTORread((char FAR *)vaddr,(int)sizeof(char),maxlth,fileid);
		} else {
        	for (amtrw = 0; amtrw < maxlth; amtrw++) {
            	if ((cc = TUTORget_char(fileid,FALSE)) == EOF)
                	break;  /* reached end of file */
            	iputvar(vaddr,kind,(long)cc);
            	vaddr += vsize;
        	} /* for */
		} /* else */
        break; /* -xin- */

    case 3: /* -xout- command */
        if (styledf)
            execerr("can't use -xout- command on styled file");
        if ((cc = FileWriteOK(fileid)) >= 0) {
            exS.zreturn = cc; /* err if not positioned for write */
            return(0);
        } /* cc if */
        if (vsize == sizeof(char) && maxlth > 1) {
            TUTORwrite((char FAR *)vaddr,(int)sizeof(char),maxlth,fileid);
            amtrw = maxlth;
        } else for (amtrw = 0; amtrw < maxlth; amtrw++) {
            if (maxlth > 1) { /* array */
                if (vsize == sizeof(long))
                    cc = long_read(vaddr);
                else cc = round(readflt(vaddr));
                vaddr += vsize;
            } else { /* single value */
                if (kind == TFLOAT) cc = fstack[0];
                else cc = istack[1];
            }
            if (cc & ~0xff)
                execerr( "-xout- data must be in the range 0 to 255.");
            TUTORwrite_char((unsigned char)cc,(int)fileid);
        } /* for */
        break; /* -xout- */

    } /* switch */
    
    exS.zretinf = amtrw; /* return number items read/written */ 
    
    if (postWait) {
        while (TUTORwait_socket(fileid,4)) 
            TUTORpoll_events(TRUE);
        execrun = FALSE; /* return from executor */
        waitflag = atinterrupt;
    }
 
} /* xdataio */

/* ------------------------------------------------------------------- */

cmd_numout() /* -numout- command execution */

{   int fileid; /* index of file in table */
    double numeric; /* value to output */
    register int si; /* index in temp string */
    char tmpstr[20]; /* temp string for output */

    iresP = istack; /* void stack */
    fresP = fstack;

    flush();
    exS.zreturn = -1; /* indicates operation ok */
    exS.zretinf = 0; /* nothing written yet */

    /* process file argument */

    fileid = istack[0];
    if (!FileIsOpen(fileid)) {
        exS.zreturn = FILENOTOPEN;
        return(0);
    }
    
    /* check if must block */
    
    if (TUTORwait_socket(fileid,2)) { /* check if need to wait before write */
        set_exec_pt(exS.markpt); /* back up to -markpt- cmd */
        execrun = FALSE; /* return from executor */
        waitflag = atinterrupt;
        TUTORpoll_events(TRUE);
        return(0);
    }
    
    /* write value to file */

    numeric = fstack[0];
    sprintf(tmpstr," %.*G",15,numeric);
    si = 0;
    while (tmpstr[si] == ' ') si++; /* strip leading blanks */
    if (TUTORwrite((char FAR *)(&tmpstr[si]),(int)sizeof(char),
                   (long)(strlen(&tmpstr[si])),fileid))
        exS.zretinf = 1; /* one value written */
    
} /* cmd_numout */

/* ------------------------------------------------------------------- */

cmd_readln() /* -readln- command execution */

{   int nm;
    register int fileid; /* index of file in table */
    struct markvar mx; /* temp marker */
    struct markvar SHUGE *mxp; /* pointer to marker variable */
    int mayblock; /* TRUE if long time-out on input */
    int styledf; /* TRUE if styled file */
    struct tutorfile FAR *tfp;
    register int ti; /* index in terminating string */
    register int tl; /* length of terminating string */
    int tmpbufl; /* length in input buffer */
    int cc,ic; /* current character */
    int lastChar; /* previous character */
    int crKind; /* -1 = unknown, 0 = 0x0a, 1 = 0x0d, 2 = 0x0d, 0x0a */
    int oldKind; /* previous crKind */
	int nCount; /* number bytes we've looked at */
    char term[1002]; /* terminating string */
    char tmpbuf[1002]; /* input buffer */

    nm = markP-markstack;
    iresP = istack; /* void stacks */
    fresP = fstack;
    markP = markstack;

    flush();
    exS.zreturn = -1; /* indicates operation ok */
    exS.zretinf = 0; /* nothing read yet */

    /* process file argument */

    fileid = istack[0];
    if (!FileIsOpen(fileid)) {
        exS.zreturn = FILENOTOPEN;
        return(0);
    }
    
    /* check if must block */
    
    if (TUTORwait_socket(fileid,3)) { /* check if need to wait before read */
        set_exec_pt(exS.markpt); /* back up to -markpt- cmd */
        execrun = FALSE; /* return from executor */
        waitflag = atinterrupt;
        TUTORpoll_events(TRUE);
        return(0);
    }
    
    /* check if styled file, check EOL type */

    tfp = fileid+(struct tutorfile FAR *)GetPtr(filesopen);
    styledf = tfp->styles_allowed; /* TRUE if styled file allowed */
    ic = tfp->lastC; /* get previous character read */
    crKind = tfp->crKind;
    oldKind = crKind;
    ReleasePtr(filesopen);
    KillPtr(tfp);
    if (styledf)
        execerr("can't use -readln- command on styled file");

    if (nm > 1) { /* process terminating string argument */
        marker_to_string(markP+1,term,1000); 
    } else {
        term[0] = NEWLINE; /* default terminator */
        term[1] = 0;
    } /* else */
    tl = strlen(term); /* length of terminating string */

    mvar_init((struct markvar SHUGE *)&mx); /* set up temp marker */
    /* assign temp marker to marker variable */
    mvar_assign((struct markvar SHUGE *)istack[3],(struct markvar SHUGE *)&mx);
    mxp = (struct markvar SHUGE *)(istack[3]);

    /* read next "line" to marker */

    tmpbufl = 0; /* pre-set buffer empty */
    ti = 0; /* index of termination char to try to match */
	nCount = 0; /* haven't read anything yet */
    mayblock = FALSE; /* on first read, don't try hard to get char */

    while (TRUE) {
		lastChar = ic;
		cc = ic = TUTORget_char(fileid,mayblock);
		nCount++;
		
		/* check if started in the middle of a 0x0a, 0x0d sequence */
		
		if (nCount == 1) {
			if ((lastChar == 0x0d) && (ic == 0x0a)) {
				cc = 0; /* started in the middle of a cr sequence */
				crKind = 2; /* 0x0d, 0x0a terminator */
			}
		}
		
		/* check special characters, determine terminator type of file */
		
		if (cc == EOF) {
			break;
		} else if (cc == 0x0d) {
			if (crKind == -1)
				crKind = 1;
		} else if (cc == 0x0a) {
			if ((lastChar == 0x0d) && ((crKind == -1) || (crKind == 1))) {
				crKind = 2; /* 0x0d, 0x0a terminator */
			} else if (crKind == -1)
				crKind = 0; /* 0x0a terminator */
		}

		/* translate 0x0d -> 0x0a or 0x0a -> 0x0d as needed */

		if ((crKind == 0) && (cc == 0x0a)) { /* file uses 0x0a as terminator */
			cc = NEWLINE;
		} else if ((crKind == 1) && (cc == 0x0d)) { /* file uses 0x0d as terminator */
			cc = NEWLINE;
		} else if ((crKind == 2) && (cc == 0x0d)) { /* file uses 0x0d, 0x0a as terminator */
			cc = 0; /* suppress 0x0d */
		} else if ((crKind == 2) && (cc == 0x0a)) { /* file uses 0x0d, 0x0a as terminator */
			cc = NEWLINE; /* make 0x0a code terminator */
		}
	
        mayblock = TRUE; /* on subsequent reads, try hard */
        if (cc)
            tmpbuf[tmpbufl++] = cc;
        else
            continue; /* go get another character */

		if (tmpbufl >= 1000) {
            TUTORcvt_native_chars((unsigned char FAR *) tmpbuf,(long) tmpbufl);
            appenddoc(mx.doc,(char FAR *)tmpbuf,tmpbufl);
            tmpbufl = 0; /* re-set buffer */
        } /* arg4 */

        /* check for match against terminator */

        if (cc == term[ti] && tl) {
            if (!term[++ti])
                break; /* matched whole terminator */
        } else ti = 0; /* didn't match next, restart */
    } /* while */

    if (tmpbufl) { /* append last buffer's worth */
        TUTORcvt_native_chars((unsigned char FAR *) tmpbuf,(long) tmpbufl);
        appenddoc(mx.doc,(char FAR *)tmpbuf,tmpbufl);
    }

    /* update end-of-line code if neccessary */

    if (crKind != oldKind) {
		tfp = fileid+(struct tutorfile FAR *)GetPtr(filesopen);
		tfp->crKind = crKind; /* update eol type */
		ReleasePtr(filesopen);
    }

    /* set marker position/length */

    exS.zretinf = TUTORget_len_doc(mx.doc);
    mxp->pos = 0;
    mxp->len = (long)exS.zretinf;
    mxp->doclen = mxp->len;
    mvar_temp_cleanup();

} /* cmd_readln */

/* ------------------------------------------------------------------- */

static int wIndex = 0; /* index of socket to wait on */

cmd_server() { xservsoc(0); } /* -server- command execution */
cmd_socket() { xservsoc(1); } /* -socket- command execution */

xservsoc(type) /* server and socket command executions */
int type;

{   int nn;
    int nm;
    long SHUGE *faddr; /* address of file variable */
    int fileid; /* index in file table */
    int logical; /* TRUE if logical address */
    int instance; /* instance of socket */
    char *infop; /* pointer to info string */
    struct tutorfile FAR *tf; /* pointer to file table entry */
    char filestr[CTPATHLEN+2]; /* name string */
    char infostr[32]; /* info string */
    int ii;

    nn = iresP-istack;
    nm = markP-markstack;
    iresP = istack; /* void stack */
    markP = markstack;

    flush(); /* flush output before doing lengthy operation */
    exS.zreturn = -1; /* indicates operation ok */
    execrun = FALSE; /* return from executor */
    waitflag = atinterrupt;

    /* process file argument */

    faddr = (long SHUGE *)istack[2];
    fileid = *faddr; /* index in file table */

    if (nn == 4)
        logical = TRUE; /* file argument only */
    else
        logical = istack[4]; /* logical/absolute flag */

    if (logical) {

        /* evaluate logical address */

        if (nn == 4) {
            if (type == 0) { /* simple server command */
                strcpyf((char FAR *)filestr,sourcetable[0].fRef.path);
                infop = NEARNULL;
                instance = 1;
            } /* else is simple socket command, which is server socket connect.
                    We don't need to do anything for this case */
        } else {
            marker_to_string(markP,filestr,CTPATHLEN); /* extract string */
            if (type == 0) { /* server */
                if (nm > 1) {
                    marker_to_string(markP+1,infostr,29); 
                    infop = infostr;
                } else
                    infop = NEARNULL;
            } else { /* socket */
                if (nn > 5)
                    instance = istack[5];
                else
                    instance = 1;
            }
        } /* nn == 4 else */
    } else {

        /* evaluate absolute address */

        marker_to_string(markP,filestr,CTPATHLEN); 
        infop = NEARNULL;
        instance = 0;
    } /* else */

    if ((type == 1) && FileIsOpen(fileid)) {

        /* need to check for previous server operation on file pointer */
 
        tf = fileid+(struct tutorfile FAR *) GetPtr(filesopen);
        if (tf->lastop == fop_server && nn == 4) {
            /* look for client connection on server socket */
            ii = TUTORsocket_server(fileid);
            exS.zreturn = (ii ? -1 : FILEMISSING);
            ReleasePtr(filesopen);
            KillPtr(tf);
            return(0);
        }
        /* otherwise, we treat this as a new client connection */
        ReleasePtr(filesopen);
        KillPtr(tf);
    } /* type if */

    CloseFile(faddr); /* close previous open file on this file pointer */
    if (type == 0) {
        ii = TUTORserver(filestr,logical,infop);
        if (ii) { /* save the address as file name */
            tf = ii+(struct tutorfile FAR *) GetPtr(filesopen);
            strcpyf(tf->fRef.path,(char FAR *)filestr);
            tf->lastop = fop_server;
            ReleasePtr(filesopen);
            KillPtr(tf);
        }
    } else
        ii = TUTORsocket_client(filestr,logical,instance);
    wIndex = ii;
    FinishFileOpen(faddr,ii);

} /* xservsoc */

/* ------------------------------------------------------------------- */

cmd_sockwait() /* wait for -socket- command to complete */

{   struct tutorfile FAR *tfp;
    int type;

    tfp = wIndex+(struct tutorfile FAR *)GetPtr(filesopen);
    type = tfp->kind;
    ReleasePtr(filesopen);
#ifdef MAC
    if (type != 6) /* check if PTP socket */
	return;
#endif
    if (TUTORwait_socket(wIndex,1)) { /* if need to wait on this socket */
        set_exec_pt((unsigned int)(get_exec_pt() - 2)); /* we'll come back here */
        execrun = FALSE; /* return from executor */
        waitflag = atinterrupt;
        TUTORpoll_events(TRUE);
        return;
    }
    if (!FileIsOpen(wIndex))
        exS.zreturn = FILEMISSING; /* set for error */
    wIndex = 0; /* clear file number */
    
} /* cmd_sockwait */

/* ------------------------------------------------------------------- */

cmd_getserv() /* -getserv- command execution */

{   int nm;
    int refreshf; /* TRUE if refresh call */
    int infof; /* TRUE if host info obtained */
    struct markvar mx; /* temp marker */
    struct markvar SHUGE *mxp; /* pointer to marker var */
    int instance;
    int nnames; /* number names found */
    struct markvar SHUGE *maddr; /* address of marker variable */
    long infol; /* length of info found */
    char addrstr[CTPATHLEN+2];
    char namestr[CTPATHLEN+2];
    long extraDumm;

    nm = markP-markstack;
    iresP = istack; /* void stacks */
    fresP = fstack;
    markP = markstack;

    flush(); /* flush output before doing lengthy operation */
    refreshf = (nm == 1); /* TRUE if single argument (refresh) */

    marker_to_string(markP,addrstr,CTPATHLEN); 
    if (refreshf) instance = -1; 
    else instance = istack[0];

    infof = TUTORhosts(addrstr,instance,namestr,CTPATHLEN-1,&nnames);
    exS.zreturn = (infof ? -1: FILEMISSING);
    exS.zretinf = nnames; /* number names found */
    if (refreshf) return(0); /* done if refresh call */

    maddr = (struct markvar SHUGE *)istack[3];
    mxp = (struct markvar SHUGE *)maddr;
    mvar_init((struct markvar SHUGE *)&mx); /* set up new marker/document */
    mvar_assign(maddr,(struct markvar SHUGE *)&mx); /* reassign marker */
    mxp->pos = mxp->len = mxp->doclen = 0;
    if (infof) {
        infol = strlen(namestr);
        TUTORchange_doc(mx.doc,0L,0L,0L,0L,(unsigned char FAR *) namestr,infol,
                    0L,HNULL,HNULL,&extraDumm,FALSE);
    } else infol = 0; /* no information */

    mxp->alteredF = 0;
    mvar_temp_cleanup(); /* release temp document(s) */

} /* cmd_getserv */

/* ------------------------------------------------------------------- */

cmd_serial() /* -serial- command execution */

{   int nn;
    long SHUGE *faddr; /* address of file variable */
    int port,databits,parity;
    long baud;
    double stopbits;
    int fi; /* file index */

    nn = iresP-istack;
    iresP = istack; /* void stacks */
    fresP = fstack;
    markP = markstack;
    exS.zreturn = -1; /* pre-set operation ok */

    faddr = (long SHUGE *)istack[2];
    CloseFile(faddr); /* pre-close any open file */
    if (nn == 1) return(0); /* done if single argument form */
    port = istack[4];
    baud = istack[5];
    databits = istack[6];
    parity = istack[7];
    stopbits = fstack[0];
    *(long SHUGE *)(faddr) = -1; /* initialize author file variable */
    fi = TUTORopen_serial(port,baud,databits,parity,stopbits);
    exS.zreturn = tfilerr;
    FinishFileOpen(faddr,fi);

} /* cmd_serial */

/* ------------------------------------------------------------------- */

cmd_alloc() /* -alloc- command execution */

{   int nn;
    long vkind; /* int/float/etc array kind */
    int vsize; /* size of element */
    int local; /* TRUE if local array */
    long stack_rel; /* relative address on stack */
    int passa; /* TRUE if pass-by-address dynamic array */
    struct array_desc FAR *pda; /* pointer to array descriptor */
    struct dim_desc FAR *pdd; /* pointer to dimension descriptor(s) */
    long SHUGE *lsP; /* pointer to array header on stack */
    int ndim; /* number array dimensions */
    long newlthI; /* size of new array (items) */
    long newlthB; /* size of new array (bytes) */
    Memh newH; /* handle on new array */
    char SHUGE *newP; /* pointer to new array */
    long oldlthI; /* size of old array (items) */
    Memh oldH; /* handle on old array */
    char SHUGE *oldP; /* pointer to old array */
    long old_rel; /* relative address in old array */
    long new_rel; /* relative address in new array */
    int lowerI; /* lower bound of array (zero or one) */
    long new_dim[10]; /* new dimensions */
    long new_mult[10]; /* new multipliers */
    long dimI[10];  /* index in each dimension */
    char SHUGE *toP; /* to pointer for move */
    char SHUGE *fromP; /* from pointer for move */
    int sii,dii,ii;

    nn = iresP-istack; 
    iresP = istack; /* void stack */
    exS.zreturn = -1; /* pre-set worked */

    /* get array info off stack, find array descriptor */
    
    vkind = istack[0]; /* get basic int/float/etc kind */
    local = istack[1]; /* get local/global flag */
    stack_rel = istack[2]; /* relative addr on stack */
    passa = istack[3]; /* get pass-by-address flag */
    if (local) 
        stack_rel += exS.lvars; /* add bias for local variables */
    lsP = (long SHUGE *)(exS.stackP+stack_rel);
    if (passa) 
        lsP = (long SHUGE *)(exS.stackP+*lsP); /* indirect if pass */
    pda = (struct array_desc FAR *)(descP+*lsP); 
    ndim = pda->ndim; /* number dimensions */
    pdd = (struct dim_desc FAR *)(pda+1); /* bias to base of dimensions */
    vsize = sizetv(vkind); /* get size of element in bytes */
    oldlthI = pda->length; /* previous size (items) */
    
    /* get dimensions, multipliers */
    
    sii = 4; /* index in integer stack */
    newlthI = 0; /* cumulative length */

    for (dii=0; dii<ndim; dii++) {
        if (istack[sii] < 0)
            execerr("Array has negative length");
        new_dim[dii] = istack[sii++]; /* get new dimensions */
    } /* for */
    newlthI = 1; /* cumulative length */
    for (dii=ndim-1; dii>=0; dii--) {
        new_mult[dii] = newlthI;
        newlthI = newlthI*new_dim[dii];
    } /* for */
    
    /* allocate new array */
    
    newH = HNULL; /* no handle yet */
    newP = FARNULL; /* no pointer yet */
    newlthB = newlthI*vsize; /* convert size to bytes */
#ifdef MAC
    if (newlthB >= 0x1000000L) {
        exS.zreturn = NOMEM;
        return;
    }
#endif
#ifdef DOSPC
    if (newlthB >= 0x10000L) {
        exS.zreturn = NOMEM;
        return;
    }
#endif
    if (newlthB) { 
        /* kludge - try to get memory so can give error return */
        /* if memory not available */
        newP = TUTORalloc(newlthB,FALSE,"try");
        if (newP == FARNULL) {
            exS.zreturn = NOMEM; /* didn't find enough memory */
            return; /* exit */
        }
        TUTORdealloc(newP); /* release memory */
        newH = TUTORhandle("array",newlthB,TRUE); 
        newP = GetPtr(newH); /* get pointer to new array */
        TUTORzero(newP,newlthB); /* pre-zero new array */
        exS.dynLocked++;
    } /* newlth if */
    
    /* transfer contents of old array to new */
    
    oldP = (char SHUGE *)(*(lsP+1));
    oldH = *(lsP+2);
    if ((int)(oldH) == -1)
        execerr("Cannot reallocate this array");
    if (oldH && newH) { /* both old and new have contents */
        if (!oldP) {
            oldP = GetPtr(oldH);
            exS.dynLocked++;
        } 
        fromP = oldP; /* from address for move */
        for (dii=0; dii<ndim; dii++)
            dimI[dii] = 0; /* pre-zero - start at array(0,...0) */
        for (old_rel=0; old_rel<oldlthI; old_rel++) { /* loop thru old array */
            new_rel = 0;
            for (dii=0; dii<ndim; dii++) { /* loop thru dimensions */
                new_rel += dimI[dii]*new_mult[dii];
            } /* dii for */
            if (new_rel < newlthI) {
                new_rel *= vsize; /* convert to bytes */
                toP = newP+new_rel; /* bias in new array */
                if (vkind == FARRAY) 
                    *(double SHUGE *)(toP) = *(double SHUGE *)(fromP);
                else if (vkind == IARRAY)
                    *(long SHUGE *)(toP) = *(long SHUGE *)(fromP);
                else if (vkind == BARRAY)
                    *toP = *fromP;
            }
            fromP += vsize; /* advance pointer in old array */
            /* multi-precision add to increment indexes in old array */
            for (dii=ndim-1; dii>=0; dii--) { /* last index is least sig */
                dimI[dii]++; /* increment next index */
                if (dimI[dii] >= pdd[dii].length) {
                    dimI[dii] = 0; /* overflow */
                } else break; /* no carry, exit for */
            } /* dii for */
        } /* old_rel for */
    } /* oldH if */

    /* deallocate old array */
    
    if (oldH) {
        if (oldP) {
            ReleasePtr(oldH);
            KillPtr(oldP);
            exS.dynLocked--;
        }
        TUTORfree_handle(oldH); /* release memory */
    } /* oldH if */
    
    /* set new array handle and pointer */
    
    *(lsP+1) = (long)newP;
    *(lsP+2) = (long)newH;
    
    /* set new array dimensions and multipliers */
    /* Halt procedure will re-set descriptors - otherwise compiler */
    /* check for change in global defines will trigger unneccessarily */
    
    lowerI = 1; /* lower bound is assumed 1 if array exists */
    pda->length = newlthI; /* set new total length */
    if (newlthI == 0) { /* if deallocating, insure all cleaned up */
        for(dii=0; dii<ndim; dii++)
            pdd[dii].lower = pdd[dii].length = pdd[dii].multiplier = 0;
    }
    for (dii=0; dii<ndim; dii++) {
        pdd[dii].lower = lowerI;
        pdd[dii].length = new_dim[dii];
        pdd[dii].multiplier = new_mult[dii];
    } /* dii for */
    return(0);

} /* cmd_alloc */


/* ------------------------------------------------------------------- */

cmd_style() /* -style- command execution */

{   int nn; /* number items on interger stack */
    int nm; /* number items on marker stack */  
    int ni; /* index in integer stack */
    int ninc; /* increment in integer stack */
    int mi; /* index in marker stack */
    int boolf; /* (potentail) boolean flag */
    int sii; /* index in styles */
    int plainF,plainestF,boldF,italicF,hotF; /* style flags */
    int superF,subF;
    int set_styles; /* bits for styles to set */
    int colorV; /* color to set to */
    int justV; /* type of justification to set to */
    long fontV; /* font to set to */
    int sizeV; /* bigger/smaller value */
    int relayoutF; /* TRUE if should force complete re-layout */
    int Nicons; /* number icons for icon style */
    long totLen; /* length of document */
    long rpos,rlen; /* area affected for redraw */
    long spos,slen; /* selection region */
    long iconDatL; /* length of icon data */
    long iconN; /* next icon number */
    long extraPos;
    int FAR *iconDatP; /* pointer to icon data */
    struct markvar SHUGE *modmx;
    struct markvar SHUGE *hotmx;
    struct markvar SHUGE *iconmx;
    DocP dP; /* pointer to document */
    TextVDat FAR *vP;   /* pointer to panel */
    unsigned char mstr[256]; /* message line string */
    
    nn = iresP-istack;
    nm = markP-markstack;
    iresP = istack; /* void stacks */
    markP = markstack;
    
    modmx = markP; /* marker var to modify */
    plainF = plainestF = boldF = italicF = hotF = 0; /* no style setting yet */
    superF = subF = 0;
    relayoutF = FALSE;  
    colorV = -1; /* no color setting yet */
    fontV = -1; /* no font setting yet */
    justV = -1; /* no justification setting yet */
    sizeV = 0;
    rpos = spos = modmx->pos;
    rlen = slen = modmx->len;
    mi = 1; /* index in marker stack */
    ni = 4; /* index in integer stack */
 
    while (ni < nn) {
        boolf = istack[ni+1] < 0; /* assume next arg boolean */
        ninc = 2; /* assume increment is 2 */
        
        switch (istack[ni]) {

        case KW_PLAINEST:
            plainestF = boolf; /* plainest - remove all styles */
            break;
            
        case KW_PLAIN:
            plainF = boolf; /* plain style */
            break;

        case KW_BOLD:
            boldF = boolf; /* bold style */
            break;

        case KW_ITALIC:
            italicF = boolf; /* italic style */
            break;
            
        case KW_SUPSCRIPT:
            superF = boolf; /* superscripted style */
            break;
            
        case KW_SUBSCRIPT:
            subF = boolf; /* subscripted style */
            break;

        case KW_HOTSTYLE:
            hotmx = &markstack[mi++]; /* hot style */
            hotF = TRUE;
            ninc = 1;
            break;

        case KW_BLACK:
        case KW_WHITE:
        case KW_RED:
        case KW_GREEN:
        case KW_BLUE:
        case KW_YELLOW:
        case KW_CYAN:
        case KW_MAGENTA:
        case KW_DEFCOLORST:
            if (boolf) 
                colorV = istack[ni]-KW_BLACK;
            break;
    
        case KW_FULLJUST:
            if (boolf)
                justV = FULLJUST;
            break;
            
        case KW_LEFTJUST:
            if (boolf)
                justV = LEFTJUST;
            break;
            
        case KW_RIGHTJUST:
            if (boolf)
                justV = RIGHTJUST;
            break;
            
        case KW_CENTER:
            if (boolf)
                justV = CENTERJUST;
            break;
            
        case KW_SERIF:
            if (boolf)
                fontV = TUTORinq_symbolic_font_id("zserif");
            break;
            
        case KW_SANS:
            if (boolf)
                fontV = TUTORinq_symbolic_font_id("zsans");
            break;
            
        case KW_TYPEWRITER:
            if (boolf)
                fontV = TUTORinq_symbolic_font_id("zfixed");
            break;
            
        case KW_SYMBOL:
            if (boolf)
                fontV = TUTORinq_symbolic_font_id("zsymbol");
            break;
            
        case KW_BIGGER:
            if (boolf)
                sizeV = BIGGERSIZE;
            break;
            
        case KW_SMALLER:
            if (boolf)
                sizeV = -BIGGERSIZE;
            break;

        case KW_ICON:
            if (exS.iconStextH) 
                execerr("More than one icon style");
            ninc = 0; /* we will step thru stack */
            iconmx = &markstack[mi++]; /* icon/font name string */
            ni++; /* advance to number icons */
            Nicons = istack[ni++]; /* pick up number of icons */
            if (iconmx->len == 0)
                execerr("No icons font or file name");
            if (iconmx->len >= MSGTEXTL)
                execerr("Icon name string too long");

            /* allocate handle for icon data */
            
            iconDatL = (Nicons+2)*sizeof(int)+iconmx->len+1;
            exS.iconStextH = TUTORhandle("icontxt",iconDatL,TRUE);
            if (!exS.iconStextH) 
                execerr("Not enough memory for -style- command");
            iconDatP = (int FAR *)GetPtr(exS.iconStextH);
            *iconDatP++ = Nicons; /* set number icons */
            for(sii=0; sii<Nicons; sii++) {
                iconN = istack[ni++];
                if ((iconN < 0) || (iconN >= 0x10000L))
                    execerr("Illegal icon number");
                *iconDatP++ = iconN;
            }
            
            /* evaluate font name */
            
            TUTORget_string_doc(iconmx->doc,iconmx->pos,iconmx->len,
                                (unsigned char FAR *)mstr);
            *iconDatP++ = cvt_font_name((char *)mstr); /* convert font name to index */
            strcpyf((char FAR *)iconDatP,(char FAR *)mstr); /* family name */
            ReleasePtr(exS.iconStextH);
            KillPtr(iconDatP);
            
            TUTORpurge_info(exS.iconStextH,M_WORM,FARNULL,0);
            AllowHandlePurge(exS.iconStextH);
            break;
    	
    	case KW_IMAGESTYLE:
    		if (exS.imageStextH)
    			execerr("More than one image style");
    		ninc = 5;
    		if (istack[ni+1]) {
    			exS.imageStextH = TUTORcopy_region(istack[ni+1]);
    		}
    		break;
    		
        default:
            execerr("unrecognized option on style");

        } /* switch */

        ni += ninc; /* increment index in integer stack */
    } /* while */

    /* handle icons */
    
    if (exS.iconStextH) {
        TUTORadd_inset_doc(modmx->doc,modmx->pos+modmx->len,0L,
                     0L,TUTORget_len_doc(modmx->doc),ICONSPECIAL,exS.iconStextH,
                     &extraPos);
        relayoutF = TRUE;
        exS.iconStextH = HNULL; /* not executors responsibility anymore */
    }
 
 	/* handle image */
 	
 	if (exS.imageStextH) {
 		TUTORadd_inset_doc(modmx->doc,modmx->pos+modmx->len,0L,
                     0L,TUTORget_len_doc(modmx->doc),PIXMAPSPECIAL,exS.imageStextH,
                     &extraPos);
        exS.imageStextH = HNULL; /* not executors responsibility anymore */
        relayoutF = TRUE;
 	}
 	   
    /* handle plain/plainest */

    if (plainestF) {
        relayoutF = TRUE;
        for (sii=0; sii<NSTYLES; sii++)
            TUTORstyle_doc(modmx->doc,modmx->pos,modmx->len,
                           sii,DEFSTYLE,FALSE,NEARNULL);
    } else if (plainF) {
        relayoutF = TRUE;
        TUTORstyle_doc(modmx->doc,modmx->pos,modmx->len,FACESTYLE,
                       style_plain,FALSE,NEARNULL);
    }
    
    /* handle face styles */
    
    set_styles = 0;
    if (boldF) 
        set_styles |= style_bold;
    if (italicF) 
        set_styles |= style_italic;
    if (superF) 
        set_styles |= SUPERSTYLE;
    if (subF) 
        set_styles |= SUBSTYLE;
    if (set_styles) {
        relayoutF = TRUE;
        TUTORstyle_doc(modmx->doc,modmx->pos,modmx->len,FACESTYLE,
                       set_styles,1,NEARNULL);
    }
    
    /* handle color style */

    if (colorV >= 0) {
        if (colorV == (KW_DEFCOLORST-KW_BLACK))
            colorV = DEFSTYLE;
        relayoutF = TRUE;
        TUTORstyle_doc(modmx->doc,modmx->pos,modmx->len,COLORSTYLE,
                       colorV,TRUE,NEARNULL);
    }
        
    /* handle font styles */
    
    if (fontV >= 0) {
        relayoutF = TRUE;
        TUTORstyle_doc(modmx->doc,modmx->pos,modmx->len,FONTSTYLE,
                       (int)fontV,TRUE,NEARNULL);
    }
           
    /* handle bigger, smaller */
    
    if (sizeV) {
        relayoutF = TRUE;
        TUTORstyle_doc(modmx->doc,modmx->pos,modmx->len,SIZESTYLE,
                       sizeV,TRUE,NEARNULL);
    }
                    
    /* handle paragraph styles */
    
    if (justV >= 0) {
        TUTORstyle_doc(modmx->doc,modmx->pos,modmx->len,PARASTYLE,
                       justV,0,NEARNULL);
        relayoutF = TRUE;
    }
                       
    /* handle hot style */
    
    if (hotF) {
        /* if (modmx->len <= 0)
            execerr("Can't apply hot style to empty marker"); */
        if (hotmx->len > 255)
            execerr("Associated string too long");
        TUTORget_string_doc(hotmx->doc,hotmx->pos,hotmx->len,(unsigned char FAR *)mstr);
        TUTORstyle_hot_doc(modmx->doc,modmx->pos,modmx->len,
                           (unsigned char FAR *) mstr, hotmx->len);
        relayoutF = TRUE;
    } /* hotf if */
    
    /* set to redraw entire text panel when layout has changed - this */
    /* shouldn't be neccessary, but is safer */

    if (relayoutF) {
        mvar_get_inf(modmx->doc,&totLen,NEARNULL,NEARNULL);
        rpos = 0;
        rlen = totLen;
          
        /* update text views */

        dP = (DocP)GetPtr(modmx->doc);  
        if (dP->editPanel) {
            vP = (TextVDat FAR *) GetPtr(dP->editPanel);
            RefreshPanel(vP,rpos,rlen,rpos,rlen,0L,spos,slen,TRUE,TRUE);
            ReleasePtr(dP->editPanel);
        }
        ReleasePtr(modmx->doc);
    } /* relayoutF if */
    
    mvar_temp_cleanup(); /* clean up temporary docs */

} /* cmd_style */

/* ------------------------------------------------------------------- */

cmd_forget() /* -forget- command execution */
    
{   FileRef fRef;
    FileRef famName;
    long famid; /* font family id */
    int fsize; /* font size */
    int cFont;

    iresP = istack; /* void stack */
    markP = markstack;
    
    marker_file_name(markP,(FileRef FAR *) &fRef,TRUE);
    famid = TUTORparse_font_family(&fRef,&famName,0,TRUE,&fsize);
    UnlockExec(); /* allow memory management of executor items */
    cFont = TUTORget_font2(famid,fsize,0,114);
    LockExec(); 
    TUTORrelease_font(-1,famid,fsize,0,TRUE);
    if (exS.iconFont == cFont)
        exS.iconFont = iconFont0;

} /* cmd_forget */

/* ------------------------------------------------------------------- */

cmd_block() /* -block- command executions */

{   long nn;
    long length; /* length to move */
    int size1,size2; /* size of individual elements */
    int array1f,array2f; /* TRUE if whole array */
    int array1k,array2k; /* types of arrays */
    unsigned char SHUGE *array1a; /* address of array */
    unsigned char SHUGE *array2a; /* address of array */
    long array1l,array2l; /* lengths of arrays */
    int mv_fwd; /* TRUE if direction of move is forwards */
    long ivalue;
    double fvalue;
    long SHUGE *llp;

    nn = iresP-istack;
    iresP = istack; /* void stacks */
    fresP = fstack;

    if (nn > 10) {
        length = istack[10]; /* length is specified */
        if (length == 0) return(0); /* nothing to do */
        if (length < 0) arraybnds();
    } else length = -1;
        
    array1f = istack[4]; /* TRUE if whole array */
    array2f = istack[9];
    array1k = istack[1]; /* int/float/byte kind */
    array2k = istack[6];
    array1a = (unsigned char SHUGE *)istack[2]; /* address of array */
    array2a = (unsigned char SHUGE *)istack[7];
    array1l = istack[3]; /* length of array */
    array2l = istack[8];

    if (array1f == 1) 
        array1a += ARRAYHDR; /* skip past array header */
    else if (array1f == 2){ /* dynamic array */
        if (array1l <= 0)
            return; /* nothing to do if no length */
        llp = ((long SHUGE *)array1a)+1;
        array1a = (unsigned char SHUGE *)(*llp); /* pointer to actual array */
    }

    if (array2f == 1) 
        array2a += ARRAYHDR; /* skip past array header */
    else if (array2f == 2){ /* dynamic array */
        if (array2l <= 0)
            arraybnds(); /* error if no length */
        llp = ((long SHUGE *)array2a)+1;
        array2a = (unsigned char SHUGE *)(*llp); /* pointer to actual array */
    }

    if (length > 0) { /* number items specified */
        if ((length > array1l) || (length > array2l)) 
            arraybnds();
    } else {
        if (array2l < array1l)
            arraybnds();
        length = array1l;
    }
   
    size1 = sizetv(array1k); /* get size of element */
    size2 = sizetv(array2k);
    mv_fwd = (array1a >= array2a);

    if (size1 == size2) { /* same size, use block move */
        length = size1*length;
        TUTORblock_move((char SHUGE *)array1a,(char SHUGE *)array2a,length);
    } else {
        if (!mv_fwd) {
            array1a += size1*(length-1);
            array2a += size2*(length-1);
        }
        for (nn=0; nn<length; nn++) {
            switch (size1) {

            case sizeof(char):
                ivalue = *(unsigned char FAR *)(array1a);
                break;
                
            case sizeof(long):
                ivalue = *(long FAR *)(array1a);
                break;
                
            case sizeof(double):
                fvalue = *(double FAR *)(array1a);
                break;
        
            default:
                execerr("Unrecognized array type");
                
            } /* switch */
            
            if (size1 == sizeof(double)) 
                fputvar(array2a,array2k,fvalue);
            else
                iputvar(array2a,array2k,ivalue);
                
            if (mv_fwd) {
                array1a += size1;
                array2a += size2;
            } else {
                array1a -= size1;
                array2a -= size2;
            }
        } /* for */
    } /* size else */

} /* cmd_block */

arraybnds() { execerr( "Array address out of bounds."); }

/* ------------------------------------------------------------------- */

cmd_sysinfo() /* -sysinfo- command execution */

{   int inn; /* number items on integer stack */
    int iii; /* index in integer stack */ 
    int type; /* type of operation */
    int vkind; /* variable kind */
    unsigned char SHUGE *vaddr; /* variable address */
    long value; /* single value to return */
    Memh rgbH; /* handle on default RGB table */
    int aii,ajj; /* indexes in arrays */
    long SHUGE *llp;
    long arrayL; /* size of red, green, blue arrays */
    long rgbL; /* size of rgb data */
    char SHUGE *vAaddr[3]; /* array addresses */
    long vAkind[3]; /* array types */
    int vAesize[3]; /* array element sizes */
    double cElem[3]; /* color r,g,b components */
    double FAR *rgbP; /* pointer to RGB data */

    inn = iresP-istack; /* number items on integer stack */
    iresP = istack; /* pop stacks */
    fresP = fstack;
    iii = 0;

    while (iii < inn) {
    
        switch (type = istack[iii++]) {
    
        case KW_SYSFONTHT:
        case KW_PALETTESZ:
        case KW_DEFCOLOR:
            switch (type) {
            case KW_SYSFONTHT:
                value = SysFontHeight;
                break;
            case KW_PALETTESZ:
                CTcount_colors(FALSE);
                value = SysPal;
                break;
            case KW_DEFCOLOR:
                CTcount_colors(FALSE);
                value = SysColors;
                break;
            } /* switch */
            vkind = istack[iii+1]; /* storeable variable kind */
            vaddr = (unsigned char SHUGE *)istack[iii+2];
            iputvar(vaddr,vkind,(long)value);
            iii += 4;
            break;
            
        case KW_DEFRGB:
            rgbH = TUTORget_default_rgb();
            if (!rgbH) {
                exS.zretinf = 0; /* didn't return any colors */
                break; /* done with command */
            }
            
            /* get address of each array, length of shortest */
            
            arrayL = istack[iii+3];
            for (aii=0; aii<3; aii++) { /* loop thru r,g,b arrays */
                vAkind[aii] = istack[iii+1]; /* basic type of array */
                vAaddr[aii] = (char SHUGE *)istack[iii+2]; /* base address of array */
                if (arrayL < istack[iii+3])
                    arrayL = istack[iii+3]; /* keep shortest length */
                if (istack[iii+4] == 1) {
                    vAaddr[aii] += ARRAYHDR; /* skip past array header */
                } else if (istack[iii+4] == 2){ /* dynamic array */
                    if (istack[iii+3] > 0) {
                        llp = ((long SHUGE *)vAaddr[aii])+1;
                        vAaddr[aii] = (char SHUGE *)(*llp); /* pointer to actual array */
                    }
                } /* else */
                vAesize[aii] = sizetv((int)vAkind[aii]); /* get size of element */
                iii += 5; /* advance to next array */
            } /* aii for */
            
            /* transfer RGB values to arrays */
            
            rgbL = TUTORget_hsize(rgbH)/(3*sizeof(double)); /* # rgb triples */
            if (arrayL > rgbL)
                arrayL = rgbL; /* don't overrun data */
            rgbP = (double FAR *)GetPtr(rgbH);
            for(aii=0; aii<arrayL; aii++) {
                for(ajj=0; ajj<3; ajj++) {
                    fputvar((unsigned char SHUGE *)vAaddr[ajj],(int)vAkind[ajj],*rgbP++);
                    vAaddr[ajj] += vAesize[ajj];
                } /* ajj for */
            } /* aii for */
            ReleasePtr(rgbH);
            TUTORfree_handle(rgbH); /* release storage */
            exS.zretinf = arrayL;
            break;
        
        case KW_DEFFGND:
        case KW_DEFBGND:
        	if (type == KW_DEFFGND) ajj = 0; /* foreground */
        	else ajj = 1; /* background */
        	TUTORinq_sys_color(ajj,&cElem[0],&cElem[1],&cElem[2]);
        	for(aii=0; aii<3; aii++) {
            	vkind = istack[iii+1]; /* storeable variable kind */
            	vaddr = (unsigned char SHUGE *)istack[iii+2];
            	fputvar(vaddr,vkind,cElem[aii]);
            	iii += 4;
            }
        	break;
        	
        } /* switch */
    
    } /* while */
    
    return(0);
    
} /* cmd_sysinfo */

/* ------------------------------------------------------------------- */

cmd_dialog() /* -dialog- command execution */

{   int nn; /* number items on integer stack */
    int ni; /* index in integer stack */
    int mi; /* index in marker stack */
    int dType; /* dialog box type */
    int retf; /* dialog return */
    char msg[82]; /* dialog box message */
    char input[82]; /* input from dialog box */
    struct tutorColor fc,bc; /* saved foreground/background colors */
    struct tutorview FAR *mfocus; /* saved menu focus */
    struct tutorview FAR *kfocus; /* saved key foucs */
    struct markvar SHUGE *mv;
    struct markvar SHUGE *maddr; /* address of result marker variable */
    struct markvar mx; /* copy of result marker */
    struct markvar SHUGE *mxp; /* pointer to result marker */
    long infol; /* length of input from dialog */
    long extraDumm;
    int pType; /* print dialog type */
    
    nn = iresP-istack;
    iresP = istack; /* void stack */
    markP = markstack;

    exS.zreturn = -1; /* indicates operation ok */
    retf = dType = 0;
    msg[0] = 0;

    ni = mi = 0; /* indexes in stacks */
    while (ni < nn) {
        switch (istack[ni]) {

        case KW_DYNC: /* yes/no/cancel dialog */
            dType = 1;
            mv = markstack+mi; /* get text marker */
            marker_to_string(mv,msg,80);
            mi++;
            ni++;
            break;
            
        case KW_DOK: /* ok dialog */
            dType = 2;
            mv = markstack+mi; /* get text marker */
            marker_to_string(mv,msg,80);
            mi++;
            ni++;
            break;
            
        case KW_DINPUT: /* text input dialog */
            dType = 3;
            mv = markstack+mi; /* get message text marker */
            marker_to_string(mv,msg,80);
            mv = markstack+mi+1; /* get input text marker */
            marker_to_string(mv,input,80);
            maddr = (struct markvar SHUGE *)istack[ni+3];
            mi += 3;
            ni += 5;
            break;

		case KW_DPRINTS: /* print page setup */
			dType = 4;
			pType = 0;
			ni++;
			break;
			
		case KW_DPRINTX: /* print */
			dType = 5;
			pType = 1;
			ni++;
			break;
			
        default:
            execerr("Unrecognized option");

        } /* end of switch */
    } /* end of while (ni < nn) */
    
    exS.zreturn = -1;
    exS.zretinf = 0;
    if (dType) {
        mfocus = windowsP[ExecWn].MenuFocus; /* preserve focus */
        kfocus = windowsP[ExecWn].KeyFocus;
        TUTORinq_foreground_color(&fc);
        TUTORinq_background_color(&bc);
        unclip();
        if (dType == 1) {
            retf = TUTORync_dialog(ExecWn,msg);
            if (retf == -1) exS.zreturn = FILEREGION;
            else if (retf == -2) exS.zreturn = FILEMEM;
            else if (retf == -3) exS.zreturn = FILEBAKWIN;
            else if (retf >= 0)
                exS.zretinf = retf+1; /* 1 = yes, 2 = no, 3 = cancel */
        } else if (dType == 2) {
            retf = TUTORok_dialog(ExecWn,msg);
            if (retf == -1) exS.zreturn = FILEREGION;
            else if (retf == -2) exS.zreturn = FILEMEM;
            else if (retf == -3) exS.zreturn = FILEBAKWIN;
            else if (retf >= 0)
                exS.zretinf = 1;
        } else if (dType == 3) {
            retf = TUTORinput_dialog(ExecWn,msg,input);
            if (retf == -1) exS.zreturn = FILEREGION;
            else if (retf == -2) exS.zreturn = FILEMEM;
            else if (retf == -3) exS.zreturn = FILEBAKWIN;
            else if (retf == 0) {
                exS.zretinf = 1;
                mxp = (struct markvar SHUGE *)maddr;
                mvar_init((struct markvar SHUGE *)&mx); /* set up new marker/document */
                mvar_assign(maddr,(struct markvar SHUGE *)&mx); /* reassign marker */
                mxp->pos = mxp->len = mxp->doclen = 0;
                infol = strlen(input);
                if (infol) {
                    TUTORchange_doc(mx.doc,0L,0L,0L,0L,(unsigned char FAR *)input,infol,
                        0L,HNULL,HNULL,&extraDumm,FALSE);
                }
                mxp->alteredF = 0;
                mvar_temp_cleanup(); /* release temp document(s) */
            } else if (retf == 1)
                exS.zretinf = 2;
        } else if ((dType == 4) || (dType == 5)) {
        	retf = TUTORprint_dialog(ExecWn,pType);
        	if (retf == -1) exS.zreturn = FILEREGION;
            else if (retf == -2) exS.zreturn = FILEMEM;
            else if (retf == -3) exS.zreturn = FILEBAKWIN;
            else if (retf >= 0)
                exS.zretinf = retf+1; /* 1 = ok, 2 = cancel */
        }
        TUTORset_view(ExecVp); /* insure set to exec view */
        setclip();
        TUTORset_color(0,&fc);
        TUTORset_color(1,&bc);
        windowsP[ExecWn].MenuFocus = mfocus;  /* restore focus */
        windowsP[ExecWn].KeyFocus = kfocus;
        if (exS.modal_dialog_redraw) {
            /* force redraw if unprocessed redraw during dialog */
            TUTORforce_redraw(exS.baseView->window);
            exS.modal_dialog_redraw = FALSE;
        }
    } /* dType if */
    
    return(0);
    
} /* cmd_dialog */

/* ------------------------------------------------------------------- */

cmd_print()

{	int retF;

    iresP = istack; /* void stack */
    markP = markstack;

	exS.zreturn = PrintDoc(markP->doc,markP->pos,markP->len);
	
} /* cmd_print */

/* ------------------------------------------------------------------- */

cmd_step()

{
    iresP = istack; /* void stack */
    markP = markstack;
    
    if (istack[0] >= 0) { /* end step mode */
    	exS.stepMode = 0;
    } else if (DebugWn >= 0) { /* begin step mode */
    	exS.stepMode = 1;
    }

} /* cmd_step */

/* ------------------------------------------------------------------- */

cmd_stepover()

{
	exS.inOver = TRUE; /* indicate a block of commands to step over */
	
} /* cmd_stepover */

/* ------------------------------------------------------------------- */
