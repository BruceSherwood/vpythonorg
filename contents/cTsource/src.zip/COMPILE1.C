
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* arithmetic expression analyzer */

#include "compile.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "exprdefs.h"
#include "yacc.h"

/* ******************************************************************* */

#ifdef ctproto
extern long get_arrayinfo(long arrayvar);
int  compile(struct  expra *exap);
int  getnum(char  *s,int  *floatf,long  *i,double  *d,char  * *errm,int  *errn);
int  sizetv(int  opc);
int  tstaa(int  opc);
int  tstga(int  opc);
int  tstpa(int  opc);
int tstda(int opc);
int  siza(int  opc);
int  tstnum(int  ty);
int  efunctna(int  cd);
int  genitof(int  t);
int  genftoi(int  t);
int  pushw(int  t);
int  popw(void);
int  genadda(int  op,long  var,int  indices);
int  genarray(int  op,long  var);
int  n_addtoken(struct  xtoken *t);
int  n_addop(int  op);
int  n_yaddop(int  op);
int  n_addlit(int  ad,int  FAR *vp);
int  addad(int  ad,long  dp,long  addr);
extern int  add_byte(int  b);
extern int  add_word(int  n);
extern int  add_long(long  n);
extern int  add_flt(double  n);
extern int  badtype(void);
int  n_myinput(void);
int  matherror(int  errnum,char  *s);
int  initlex(struct  expra *initcmp);
char  FAR *GetPtr(unsigned int  mm);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
extern void longjmp(jmp_buf env, int value);
int  yyparse(void);
double  lcitof(long  iv);
long  lcftoi(double  dv);
long  IntToCoord(int  xx);
long  FloatToCoord(double  zz);
int  dmpexpr(void);
int  exprmsg(char  *pstr);
extern double fabs(double x);
extern double cos(double x);
extern double sin(double x);
long  lcint(double  av);
extern double acos(double x);
extern double asin(double x);
double  lcfexpon(double  y,double  x);
extern double log(double x);
extern double pow(double x,double y);
extern double log10(double x);
extern double exp(double x);
extern double sqrt(double x);
extern double tan(double x);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
int  add_dest(int  type,int  label,unsigned int  pos);
int  add_xref(int  kind,int  label,unsigned int  aref,unsigned int  adest);
int  TUTORtrace_n(char  *s,long  nn);
char  FAR *TUTORrealloc(char  FAR *ptr,long  oldsize,long  newsize,int  abort);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  yyerror(char  *str);
#endif /* ctproto */

#ifdef MAC
extern int setjmp(jmp_buf env);
#endif

/* ******************************************************************* */

extern jmp_buf cenv;	/* saved enviornment for longjmp */

#ifndef WERKS
extern double sin(),cos(),tan();
extern double sqrt(),fabs(),exp();
extern double asin(), acos();
extern double pow(),log10(),log(),alog();
extern double sinh(),cosh(),tanh(),gamma();
#endif

extern double lcitof();
extern double lcfexpon();

/* ******************************************************************* */

static char *kIllChar = "Illegal character in a number.";
static char *kIllForm = "Illegal form of number.";

int getnum(s, floatf, i, d, errm, errn)
/* convert character string to integer or floating-point number */
/* input may be integer, integer of form base#number, floating or */
/* exponential of the form 3.784e+05 */
/* or -3.784E-12 */
/* return TRUE if legal numeric value */

char *s;		/* input character string */
int *floatf;		/* TRUE if floating result */
long *i;		/* integer result */
double *d;	/* floating result */
char **errm;	/* set to error message, if any */
int *errn;

{	char c; /* current character code */
	int frac; /* TRUE if fractional part */
	int expflag;	/* TRUE if exponential notation */
	int ibaseflg; /* TRUE if base#value form */
	int negative; /* TRUE if negative value */ 
	int contf; /* TRUE if should continue building value */
	int nc; /* index of current character */
	int length; /* length of input string */
	long ivalue;	/* integer value building */
	int ibase; /* integer base */
	double value; /* floating value building */
	double mult;	/* current multiplier */
	double xpbase; /* base for exponential form */
	char *dummycp; /* dummy pointer if error message not wanted */
	int dummynp; /* dummy integer if error number not wanted */

	if (errm == NEARNULL)
		errm = &dummycp;
	if (errn == NEARNULL)
		errn = &dummynp;
	negative = expflag = ibaseflg = frac = *floatf = FALSE ;
	value = 0.0;
	ivalue = 0;
	mult = 10.0;
	ibase = 10;
	length = strlen(s);
	contf = TRUE;

	nc = 0;
	while ((s[nc] == ' ') || (s[nc] == '\t')) nc++; /* skip white */
	if (s[nc] == '#') ivalue = 16;	/* if no base, assume base 16 */

	for (nc=0; (nc<length) && contf; nc++) {
		switch (c = s[nc]) {

		case ' ':
		case '\t':
			break;	/* ignore spaces */

		case NEWLINE:
		case ';':
		case ',':
			contf = FALSE; /* stop on NEWLINE, separator */
			break;

		case '$': /* stop on $$ comment (parse_env) */
			if (s[nc+1] == '$') {
				contf = FALSE; /* stop on comment */
				break;
			}
			*errm = kIllChar;
			*errn = CHARERR;
			return(FALSE);

		case '0':	/* add next digit to value building */
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			if (!(*floatf)) {
				if ((c-'0') >= ibase) {
					*errm = "Illegal digit..";
					*errn = FORMERR;
					return(FALSE);
				} /* if */
				ivalue = (ivalue*ibase)+(c-'0');
				if ((ivalue>100000000) && (!ibaseflg)) {
					value = ivalue;
					*floatf = TRUE;
				} /* large value if */
			} else {
				if (frac) { 
					value = value+(c-'0')/mult ;
					mult = 10.0*mult ;
				} else value = mult*value+(c-'0');
			} /* float else */
			break;

		case 'A':
		case 'B':
		case 'C':
		case 'D':
		case 'F':
			c += ('a' - 'A') ;
		case 'a':
		case 'b':
		case 'c':
		case 'd':
		case 'f':
			if ((ibaseflg) && ((c-'a'+10)<ibase)){
				ivalue = (ivalue*ibase)+(c-'a')+10;
			} else {
				*errm = kIllForm;
				*errn = FORMERR;
				return(FALSE); 
			} /* else */
			break;

		case '.':	/* switch to fractional part */
			if (frac || expflag) {
				*errm = "Too many decimal points.";
				*errn = DECERR;
				return(FALSE); }
			frac = TRUE ;
			if (!(*floatf)) {
				value = ivalue;
				*floatf = TRUE;
			} /* not float if */
			break;

		case '-':	/* negative value */
			negative = !negative;
		case '+': 	/* positive value */
			if ((value != 0.0) || (ivalue != 0)) {
				*errm = "Illegal form of number.";
				*errn = FORMERR;
				return(FALSE); 
			} /* zero if */
			break;

		case '#':
			if (ibaseflg) {
				*errm = "# should appear just once.";
				*errn = FORMERR;
				return(FALSE);
			} /* base if */
			if (*floatf) {
				*errm = kIllForm;
				*errn = FORMERR;
				return(FALSE);
			} /* float if */
			if ((ivalue<2) || (ivalue>16)) {
				*errm = "illegal base.";
				*errn = FORMERR;
				return(FALSE);
			} /* value if */
			ibaseflg = TRUE;
			ibase = ivalue;
			ivalue = 0;
			break;

		case 'e':	/* exponential form */
		case 'E':
			if ((ibaseflg) && (ibase >= 15)) {
				ivalue = (ivalue*ibase)+14;
				break;
			} /* e if */
			if (expflag) {
				*errm = "Exponent should appear just once.";
				*errn = FORMERR;
				return(FALSE);
			} /* expflag if */
			if (ibaseflg) {
				*errm = kIllForm;
				*errn = FORMERR;
				return(FALSE);
			} /* ibaseflg if */
			if (!(*floatf)) {
				*floatf = TRUE;
				value = ivalue;
			} /* not float if */
			xpbase = negative ? -value : value;
			negative = frac = FALSE;
			expflag = TRUE;
			value = 0.0;
			ivalue = 0;
			mult = 10.0;
			break;

		default:	/* unrecognized character */
			*errm = kIllChar;
			*errn = CHARERR;
			return(FALSE);
		} /* switch */
	} /* for */

	if (negative) { value = -value; ivalue = - ivalue; }
	if (expflag) value = xpbase*pow(10.0, value);
	*d = value;
	*i = ivalue;
	return(TRUE); 

} /* getnum */

/* ******************************************************************* */

int sizetv(opc)	/* return size of tutor (author) variable */
int opc;		/* variable code */

{	int mopc;

	if ((opc == TFLOAT) || (opc == FARRAY)) return sizeof(double);
	if ((opc == TINT) || (opc == IARRAY)) return sizeof(long);
	if ((opc == TBYTE) || (opc == BARRAY)) return sizeof(char);
	if ((opc == TMARK) || (opc == MARRAY)) return sizeof(struct markvar);
	mopc = opc & 0xffff; /* TXTYPE is 16/type, 16/TXTYPE */
	if ((mopc == TXTYPE) || (mopc == XARRAY)) return sizeof(long);
	TUTORtrace_n("sizetv unrecognized code",(long) opc);
	return(sizeof(double));

} /* sizetv */

/* ******************************************************************* */

tstaa(opc)	/* check for assignment to array */
int opc;		/*operand code to check */

{
	if ((opc == GARRAYADDR) || (opc == LARRAYADDR) ||
	   (opc == PARRAYADDR) || (opc == IGARRAYADDR) ||
	   (opc == ILARRAYADDR) || (opc == IPARRAYADDR) ||
	   (opc == BGARRAYADDR) || (opc == BLARRAYADDR) ||
	   (opc == BPARRAYADDR) || (opc == MGARRAYADDR) ||
	   (opc == MLARRAYADDR) || (opc == MPARRAYADDR) ||
	   (opc == GDYARRAYADDR) || (opc == IGDYARRAYADDR) ||
	   (opc == BGDYARRAYADDR) || (opc == MGDYARRAYADDR) ||
	   (opc == LDYARRAYADDR) || (opc == ILDYARRAYADDR) ||
	   (opc == BLDYARRAYADDR) || (opc == MLDYARRAYADDR)	||
	   (opc == PDYARRAYADDR) || (opc == IPDYARRAYADDR) ||
	   (opc == BPDYARRAYADDR) || (opc == MPDYARRAYADDR))
		return(TRUE);
	else return(FALSE);

} /* tstaa */

/* ******************************************************************* */

tstga(opc)	/* check for global array/variable */
int opc;		/* operand code to check */

{
	if ((xtP[opc].local == 0) || (xtP[opc].local == 3))
		return(TRUE);
	else return(FALSE);

} /* tstga */

/* ******************************************************************* */

tstpa(opc)	/* check for pass-by-address array */
int opc;		/* operand code to check */

{
	if (((xtP[opc].local == 2) || (xtP[opc].local == 5)) && (xtP[opc].array))
		return(TRUE);
	else return(FALSE);

} /* tstpa */

/* ******************************************************************* */

tstda(opc)	/* check for dynamic array */
int opc;		/* operand code to check */

{
	return((xtP[opc].local >= 3) && (xtP[opc].local <= 5));

} /* tstda */

/* ******************************************************************* */

siza(opc)		/* return size of array element */
int opc;		/* operand code to return element size of */

{
	if ((opc == GARRAYVAL) || (opc == GARRAYADDR) ||
	   (opc == LARRAYVAL) || (opc == LARRAYADDR) ||
	   (opc == PARRAYVAL) || (opc == PARRAYADDR) ||
	   (opc == GDYARRAYVAL) || (opc == GDYARRAYADDR) ||
	   (opc == LDYARRAYVAL) || (opc == LDYARRAYADDR) ||
	   (opc == PDYARRAYVAL) || (opc == PDYARRAYADDR) ) 
		return(sizeof(double));
	else if ((opc == IGARRAYVAL) || (opc == IGARRAYADDR) ||
	          (opc == ILARRAYVAL) || (opc == ILARRAYADDR) ||
	          (opc == IPARRAYVAL) || (opc == IPARRAYADDR) ||
	          (opc == XGARRAYVAL) || (opc == XLARRAYVAL) ||
	          (opc == XPARRAYVAL) ||
	          (opc == IGDYARRAYVAL) || (opc == IGDYARRAYADDR) ||
	          (opc == XGDYARRAYVAL) ||
	          (opc == ILDYARRAYVAL) || (opc == ILDYARRAYADDR) ||
	          (opc == XLDYARRAYVAL) ||
	          (opc == IPDYARRAYVAL) || (opc == IPDYARRAYADDR) ||
	          (opc == XPDYARRAYVAL) ) 
			return(sizeof(long));
	else if ((opc == BGARRAYVAL) || (opc == BGARRAYADDR) ||
	          (opc == BLARRAYVAL) || (opc == BLARRAYADDR) ||
	          (opc == BPARRAYVAL) || (opc == BPARRAYADDR) ||
	          (opc == BGDYARRAYVAL) || (opc == BGDYARRAYADDR) ||
		      (opc == BLDYARRAYVAL) || (opc == BLDYARRAYADDR) ||
			  (opc == BPDYARRAYVAL) || (opc == BPDYARRAYADDR) )
			return(sizeof(unsigned char));
	else if ((opc == MGARRAYVAL) || (opc == MGARRAYADDR) ||
	          (opc == MLARRAYVAL) || (opc == MLARRAYADDR) ||
	          (opc == MPARRAYVAL) || (opc == MPARRAYADDR) ||
	          (opc == MGDYARRAYVAL) || (opc == MGDYARRAYADDR) ||
		      (opc == MLDYARRAYVAL) || (opc == MLDYARRAYADDR) ||
			  (opc == MPDYARRAYVAL) || (opc == MPDYARRAYADDR))
			return(sizeof(struct markvar));
	TUTORtrace_n("siza unrecognized code",(long)opc);
	return(sizeof(double));

} /* siza */

/* ******************************************************************* */

tstnum(ty)	/* check for numeric type (TFLOAT, TINT, etc) */
int ty;		/* type to check */

{
	if ((ty == TFLOAT) || (ty == TINT) || (ty == TBYTE)) return(TRUE);
	else return(FALSE);

} /* tstnum */

/* ******************************************************************* */

int efunctna(cd) /* return number arguments for EFUNCT (embed) function */
int cd; /* EFUNCT type code */

{	int i;

	i = (cd % 3);
	return((i == 0) ? 3: i);

} /* efunctna */

/* ******************************************************************* */

genitof(t)		/* generate integer-to-floating conversion */
int t;			/* index of token to convert */

{ 	int nx;	/* index of token following itof */

	n_addop(ITOF);	/* add conversion operator */
	nx = xtokd[t].nextt;
	xtokd[ntokd].nextt = nx;	/* chain itof to next */
	xtokd[nx].prevt = ntokd;	/* chain next to itof */
	xtokd[t].nextt = ntokd;	/* chain previous to itof */
	xtokd[ntokd].prevt = t;	/* chain itof to previous */
	
} /* genitof */

/* ******************************************************************* */

genftoi(t)		/* generate floating-to-integer conversion */
int t;			/* index of token to convert */

{	int nx;	/*index of token following ftoi */

	n_addop(FTOI);	/* add conversion operator */
	nx = xtokd[t].nextt;
	xtokd[ntokd].nextt = nx;	/* chain ftoi to next */
	xtokd[nx].prevt = ntokd;	/* chain next to ftoi */
	xtokd[t].nextt = ntokd;	/* chain previous to ftoi */
	xtokd[ntokd].prevt = t;	/* chain ftoi to previous */
	if (xtokd[t].nextb) {
		xtokd[ntokd].nextb = xtokd[t].nextb; /* chain ftoi to next */
		xtokd[t].nextb = 0; /* de-couple previous */ 
	} /* logical op link if */
	
} /* genftoi */

/* ******************************************************************* */

pushw(t)		/* push token on working stack */
int t;			/* index of token to push */

{
	xtokd[topw].nextw = t;	/* chain previous top to this */
	xtokd[t].prevw = topw;	/* chain this to previous top */
	xtokd[t].nextw = 0;
	topw = t;				/* new top of stack */

} /* pushw */

/* ******************************************************************* */

popw()		/* pop token from working stack */
			/* return index of token popped */
{	int wt;

	wt = topw;		/* index of old top of stack */
	topw = xtokd[wt].prevw;	/* set top of stack to previous entry */
	xtokd[topw].nextw = 0;
	return(wt);	/* return index of token popped */

} /* popw */

/* ******************************************************************* */

static long get_arrayinfo(arrayvar) /* get arrayinfo field */
long arrayvar; /* 16 handle on defined set, 16/index of variable */

{	Memh setH; /* handle on defined set */
	struct defset FAR *setP; /* pointer to defined set */
	int symI; /* index to defined symbol */
	struct defvar FAR *symP; /* pointer to defined symbol */
	long addr; /* rel addr of array descriptor */
	struct array_desc FAR *adsc; /* pointer to array descriptor */
	
	/* look up defined set, symbol table, and extract addr */
	/* of array descriptor */
	
	symI = arrayvar & 0xffff; /* mask off index of symbol */
	setH = (arrayvar >> 16) & 0xffff; /* handle on define set */
	setP = (struct defset FAR *)GetPtr(setH); 
	symP = (struct defvar FAR *)GetPtr(setP->defvarH);
	symP = symP+symI; /* pointer to defined symbol */
	addr = symP->arrayinfo; /* get bias to array descriptor */
	ReleasePtr(setP->defvarH);
	ReleasePtr(setH);
	return(addr); /* index in array descriptors */
	
} /* get_arrayinfo */

/* ******************************************************************* */

genadda(op, var, indices) /* for array with explicit indices */
/* return TRUE if array dimensions okay */
int op, indices; 
long var;  /* 16/set, 16/index */

{	long addr; /* rel addr in array descriptors */
	struct array_desc FAR *adsc; /* pointer to array descriptor */
	int uii; /* index of unit */
	
	addr = get_arrayinfo(var); /* get rel addr in descriptors */
	
	if ((op == GARRAYADDR) || (op == GARRAYVAL) || (op == GDYARRAYVAL) ||
	    (op == GDYARRAYADDR))
		uii = 0;
	else 
		uii = compunit;
	addad(op,var,addr);
	adsc = (struct array_desc FAR *)(descP+unittab[uii].descp+addr);
	indexcnt = adsc->ndim;
	if (indexcnt != indices) {
 		yyerror(NEARNULL);
		longjmp(cenv,1);
	}
	indexcnt = 0;
	return(TRUE);
	
} /* genadda */
 
/* ******************************************************************* */

genarray(op, var) /* for whole array (no indices) */
int op; 
long var; 

{	long addr;
	struct defvar FAR *varp;

	addr = get_arrayinfo(var); /* get rel addr in descriptors */
	addad(op,var,addr);
	return(0);

}  /* genarray */

/* ******************************************************************* */

n_addtoken(t)	/* add token to expression analyzer stack */ 
struct xtoken *t;
 
{	struct xtoken FAR *xtp;

	if ((++ntokd) >= 256) {
		exa->errnum = FORMERR;
		exa->errmess = "Expression too compilicated.";
		longjmp(cenv,1);
	} /* ntokd if */
	if (ntokd >= xtokmalloc) {
		xtokd = (struct xtoken FAR *)(TUTORrealloc(
		        (char FAR *)xtokd,(long)(xtokmalloc*sizeof(struct xtoken)),
			(long)((xtokmalloc+32)*sizeof(struct xtoken)),TRUE));
		if (!xtokd) {
			xtokmalloc = 0;
			exa->errnum = FORMERR;
			exa->errmess = "Expression too compilicated.";
			longjmp(cenv,1);
		} /* xtokd if */
		xtokmalloc = xtokmalloc+32; /* increase size of stack */
	} /* ntokd  if */

	xtp = &xtokd[ntokd];
	*xtp = *t; /* add to last slot in stack */ 
	xtp->nextt = 0;	/* pre-clear polish order chain pointers */
	xtp->nextr = 0;	/* pre-clear relational operator chain pointers */
	xtp->nextb = 0; /* pre-clear branch true/false chain pointers */
	xtp->nextw = 0; /* pre-clear working chain pointers */
	xtp->prevw = 0;
	xtp->loc = 0;
	xtp->result = tundef;	/* pre-set no result register */

	return(TRUE);

}  /* n_addtoken */

/* ******************************************************************* */

n_addop(op)	/* add operator to expression analyzer stack */ 
int op;		/* operator type code */

{	struct xtoken t;
 
	t.code = op;	/* set operator code */
	t.type = 0;
	t.ivalue = 0;
	t.fvalue = 0.0;
	t.global = TRUE;
	t.defloc = HNULL;  
	return(n_addtoken(&t));	/* add to expression analyzer stack */
	
}  /* n_addop */

/* ******************************************************************* */

n_yaddop(op)	/* add operator to stack, indicate not store-able */
int op;

{	
	exa->canstore = FALSE;	/* not storeable */
	return(n_addop(op));

} /* n_yaddop */

/* ******************************************************************* */

n_addlit(ad,vp)	/* add literal to expression analyzer stack */
int ad;  /* literal type code */
int FAR *vp; /* address of integer/floating value */

{	struct xtoken t;		/* token record */

	t.defloc = HNULL;
	t.global = TRUE;
	t.code = ad;         /* set global, local, etc. */
	t.ivalue = 0;
	t.fvalue = 0.0;
	t.constf = TRUE;	/* flag literal */
	exa->canstore = FALSE;	/* not storeable */

	if  (t.code == FLITERAL)  { /* floating literal */
		t.type = TFLOAT;
		t.fvalue = *(double FAR *)vp;
	}  /* fliteral if */

	else if  (t.code == ILITERAL) { /* integer literal */
		t.type = TINT;
		t.ivalue = *(long FAR *)vp;  /* integer value */
	}  /* integer if */

	else if ((t.code == MLITERAL) || (t.code == MLITC)) { /* string literal */
		t.type = TMARK;
		t.ivalue = *(long FAR *)vp;  /* index of literal */
	}  /* integer if */
	return(n_addtoken(&t));

}  /* n_addlit */

/* ******************************************************************* */

addad(ad,dp,addr)	/* add adtype to expression analyzer stack */
int ad;		/* operand type code */
long dp;	/* -1 or 16/set, 16/index of symbol */
long addr;	/* address of integer/floating value */

{	struct xtoken t; /* token record */
	Memh setH; /* handle on defined set */
	long index; /* index to defined symbol */
	struct defset FAR *setP; /* pointer to defined set */
	struct defvar FAR *symP; /* pointer to symbol table */
	struct defvar thevar; /* pointer to define info */
	long txtypet; /* TXTYPE code */

	t.defloc = dp;	/* set pointer to symbol define */
	t.constf = FALSE;	/* set not constant */
	t.type = TFLOAT;	/* pre-set floating */
	t.code = ad;	/* set global, local, etc. */
	if ((ad == GLOBALADDR) || (ad == GLOBALVAL) || tstga(ad)) 
		t.global = TRUE;
	else t.global = FALSE;
	t.ivalue = addr;
	t.fvalue = 0.0;

	if  (dp != -1)  { /* defined variable */
		index = dp & 0xffff; /* index of symbol */
		setH = (dp >> 16) & 0xffff; /* handle on defined set */
		setP = (struct defset FAR *)GetPtr(setH);
		symP = (struct defvar FAR *)GetPtr(setP->defvarH);
		thevar = *(symP+index); /* variable definition */
		ReleasePtr(setP->defvarH);
		KillPtr(symP);
		ReleasePtr(setH);
		KillPtr(setP);
		t.type = thevar.kind; /* set int/float etc from define record */
		if (t.ivalue == -1)  t.ivalue = thevar.loc;   /* address of variable */
	} else if (t.code == SYSVAR) {
		t.type = TFLOAT;
		exa->canstore = FALSE;
	} else if (t.code == ISYSVAR) {
		t.type = TINT;
		exa->canstore = FALSE;
	} else if (t.code == MSYSVAR) {
		t.type = TMARK;
		if ((t.ivalue != ZARROWM) && (t.ivalue != ZARROWSEL) && (t.ivalue != ZCLIPBOARD))
			exa->canstore = FALSE;
	} else if (t.code == TSYSVAR) {
		exa->canstore = FALSE;
		if (t.ivalue == ZEDIT)
			txtypet = TXEDIT;
		else if (t.ivalue == ZSLIDER)
			txtypet = TXSLIDER;
		else if (t.ivalue == ZBUTTON)
			txtypet = TXBUTTON;
		else if (t.ivalue == ZDDE)
			txtypet = TXDDE;
		t.type = (txtypet << 16)+(long)TXTYPE;
	} /* else if */

	return(n_addtoken(&t));

} /* addad */

/* ******************************************************************* */

add_byte(b) /* add single byte to pcodes */
int b;

{
	exa->pcode[(*exa->pcodepos)++] = b;

} /* add_byte */

/* ******************************************************************* */

add_word(n) /* add 2-byte integer to pcodes */
int n; 

{
	*((short FAR *)(exa->pcode+*exa->pcodepos)) = n;
	(*exa->pcodepos) += 2;

} /* add_word */

/* ******************************************************************* */

#ifndef long_align

add_long(n) /* add 4-byte integer to pcodes */
long n; 

{
	*((long FAR *)(exa->pcode+*exa->pcodepos)) = n;
	(*exa->pcodepos) += 4;

} /* add_long */

/* ------------------------------------------------------------------- */

add_flt(n) /* add double floating value to pcodes */
double n;

{
	*((double FAR *)(exa->pcode+*exa->pcodepos)) = n;
	(*exa->pcodepos) += sizeof(double);

} /* add_flt */
	
/* ------------------------------------------------------------------- */

#else /* long_align */

add_long(n) /* add 4-byte integer to pcodes */
long n;

{	short *vp; /* pointer in long value */
	short FAR *bp; /* pointer in pcodes */

	vp = (short *) &n; /* set pointer to floating value */
	bp = (short *)(&exa->pcode[*exa->pcodepos]);
	*bp++ = *vp++; /* add 4 bytes */
	*bp++ = *vp++;
	(*exa->pcodepos) += 4;

} /* add_long */

/* ------------------------------------------------------------------- */

add_flt(d) /* add double floating value to pcodes */
double d;

{	short *vp; /* pointer in floating value */
	short FAR *bp; /* pointer in pcodes */

	vp = (short *) &d; /* set pointer to floating value */
	bp = (short FAR *)(&exa->pcode[*exa->pcodepos]);
	*bp++ = *vp++; /* add 8 bytes */
	*bp++ = *vp++;
	*bp++ = *vp++;
	*bp++ = *vp++;
	(*exa->pcodepos) += 8;

} /* add_flt */

#endif /* long_align */

/* ******************************************************************* */

badtype() /* error exit for type errors */

{	
	exa->errnum = FORMERR;
	exa->errmess = "Operation on incompatible types."; 
	longjmp(cenv,1);

} /* badtype */

/* ******************************************************************* */
