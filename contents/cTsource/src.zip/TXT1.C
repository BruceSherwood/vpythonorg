
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* machinery for text blocks */

#include "baseenv.h"
#include "txt.h"

#ifdef ctproto
extern int TUTORget_lockcount(Memh hh);
int  StringToTBlock(unsigned int  doc);
int  TBlockToStringDoc(unsigned int  doc);
int  ChangeTBlock(struct  _ktd FAR *dp,long  pos,long  len,unsigned char  FAR *newP,long  newLen,int  *unlocked,int  *followP);
struct  _tblk FAR *FindTBlock(struct  _ktd FAR *dp,long  pos,long  *pOff,long  *eOff);
extern int  SplitBlock(struct  _ktd FAR *dp,struct  _dah FAR *dap,struct  _tblk FAR *curBlock,int  ind,int  *unlocked);
extern int  AddTBlock(struct  _ktd FAR *dp,struct  _dah FAR *dap,int  ind,long  len,int  *unlocked);
extern long  DefaultSplit(struct  _tblk FAR *sBlock);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORcompress_darray(unsigned int  da,int  offset);
int  TUTORinsert_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nIns);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
unsigned char  FAR *TUTORscan_bytes(unsigned char  FAR *bp,unsigned char  FAR *be,unsigned char  *tp,int  nTab);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
int  ChangedHandle(unsigned int  mm,int  stillPurge);
int  TUTORfree_handle(unsigned int  mm);
int  _TUTORload_buffer_doc(struct  _ktd FAR *dp,long  pos);
int  TUTORdump(char  *s);
int  TUTORtrace_n(char  *s,long  nn);
int  TUTORdelete_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nDel);
int  AllowHandlePurge(unsigned int  mm);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
#endif /* ctproto */

extern unsigned char FAR *TUTORscan_bytes();

/* maximum amount of text we will store in one block */
#define MAXBLOCKLEN 10000
/* # of extra bytes we usually want in each text handle */
#define TBLOCKBUFF 500

extern TextBlock FAR *FindTBlock();
static long DefaultSplit();

StringToTBlock(doc) /* change string type doc to textblock style */
Memh doc; /* we will be resizing this */
	{
	REGISTER DocP dp;	/* pointer to doc */
	DArrayHeader FAR *dap;	/* dynamic array header for textblocks */
	long tLen;	/* text length */
	long curPos;	/* current position in document */
	register long blockLen;	/* length of a block we are creating */
	register unsigned char FAR *tp;	/* pointer to doc's text buffer */
	unsigned char FAR *tpEnd;	/* just past end of doc's text buffer */
	unsigned char FAR *tpf;	/* pointer to a newline */
	unsigned char FAR *tBlockP;
	int unlocked;	/* set to TRUE by AddTBlock if doc is unlocked */
	int ind;	/* index of next text block */
	TextBlock FAR *curBlock;	/* pointer to current text block */
	
	if (TUTORget_lockcount(doc) != 0) 
		TUTORdump("incorrect lock count 6");	
		
	dp = (DocP) GetPtr(doc);
	dap = (DArrayHeader FAR *) ((char FAR *) dp + dp->offsets[DOCTBLOCK]);
	curBlock = (TextBlock FAR *) (dap+1); /* points at nothing right now */
	
	tp = (unsigned char FAR *) dp->text;
	tpEnd = tp + dp->totLen;
	curPos = 0;
	ind = 0;
	tLen = dp->totLen;
	if (tLen)
		{ /* normal case */
		while (tLen > 0)
			{ /* keep setting up blocks of a "reasonable" size */
			if (tLen > MAXBLOCKLEN)
				{ /* find a good boundary */
				tpf = TUTORscan_bytes(tp + MAXBLOCKLEN/2,tpEnd-1,
										(unsigned char *) NEWLINES,1);
				if (tpf)
					tpf++; /* to include NEWLINE */
				else
					tpf = tpEnd; /* whole block */
				blockLen = tpf - tp;
				if (blockLen >= MAXBLOCKLEN)
					blockLen = MAXBLOCKLEN; /* couldn't find NEWLINE in time */
				}
			else
				blockLen = tLen; /* all the rest of the text */
			
			/* add the block */
			AddTBlock(dp,dap,ind,blockLen,&unlocked);
			if (unlocked)
				{ /* need to recover pointers */
				dp = (DocP) GetPtr(doc);
				dap = (DArrayHeader FAR *) ((char FAR *) dp + dp->offsets[DOCTBLOCK]);
				tp = ((unsigned char FAR *) dp->text) +curPos;
				tpEnd = ((unsigned char FAR *) dp->text) + dp->totLen;
				curBlock = ((TextBlock FAR *) (dap+1)) + ind;
				}
			
			/* move text from string to new block */
			tBlockP = (unsigned char FAR *) GetPtr(curBlock->text);
			TUTORblock_move((char SHUGE *) tp,(char SHUGE *) tBlockP,blockLen);
			ReleasePtr(curBlock->text);
			KillPtr(tBlockP);
			
			tLen -= blockLen; /* to account for text already transferred */
			curBlock++;
			ind++;
			tp += blockLen;
			curPos += blockLen;
			}
		}
	else
		{ /* tLen is 0, we are setting up an empty doc */
		AddTBlock(dp,dap,ind,0L,&unlocked);
		if (unlocked)
			{ /* need to recover pointers */
			dp = (DocP) GetPtr(doc);
			dap = (DArrayHeader FAR *) ((char FAR *) dp + dp->offsets[DOCTBLOCK]);
			}
		}
	
	if (dp->txtH.dAnAlloc < TBUFFLEN)
		{ /* need to insert some items (so text buffer will be of size TBUFFLEN) */
		dp->txtH.dAnn = dp->txtH.dAnAlloc;
		dp->txtH.nBuff = 10;
		ind = TBUFFLEN - dp->txtH.dAnn; /* # of items to insert */
		ReleasePtr(doc);
		KillPtr(dp);
		TUTORinsert_darray(doc,FARNULL,DOCOFFSET,DOCTEXT,-1,ind);
		dp = (DocP) GetPtr(doc);
		dp->txtH.dAnn = dp->totLen;
		}
	else
		{ /* need to decrease size of text buffer */
		dp->txtH.dAnn = TBUFFLEN;
		dp->txtH.nBuff = 10; /* very small buffer - so compress_darray will do something */
		ReleasePtr(doc);
		KillPtr(dp);
		TUTORcompress_darray(doc,DOCOFFSET); /* make doc handle smaller */
		dp = (DocP) GetPtr(doc);
		dp->txtH.dAnn = dp->txtH.dAnAlloc;
		}
	
	dp->buffStart = 0L;
	dp->buffEnd = dp->txtH.dAnn;
	dp->shortText = FALSE;
	
	ReleasePtr(doc);
	KillPtr(dp);
	
	return 0;
	}

TBlockToStringDoc(doc) /* change doc from tblock to short text */
register Memh doc;	/* document we are changing */
	{
	REGISTER DocP dp;	/* pointer to doc */
	register int ii;
	register DArrayHeader FAR *dap;	/* dynamic array header for text blocks */
	register TextBlock FAR *curBlock;	/* current text block */
	
	dp = (DocP) GetPtr(doc);
	if (dp->totLen > MAXSTRINGLEN/2)
		{
		ReleasePtr(doc);
		KillPtr(dp);
		return 0; /* don't do it */
		}
	dp->txtH.nBuff = 1000;
	ii = dp->totLen - dp->txtH.dAnAlloc; /* # of chars we need to add */
	
	if (ii > 0)
		{
		ii += dp->txtH.dAnAlloc - dp->txtH.dAnn; /* so we will really add space */
		ReleasePtr(doc);
		KillPtr(dp);
		if (!TUTORinsert_darray(doc,FARNULL,DOCOFFSET,DOCTEXT,-1,ii))
			return 0; /* couldn't get memory! */
		dp = (DocP) GetPtr(doc);
		}
	
	_TUTORload_buffer_doc(dp,0L); /* this should put all text in dp->text */
	
	/* now dispose of text blocks */
	dap = (DArrayHeader FAR *) ((char FAR *) dp + dp->offsets[DOCTBLOCK]);
	curBlock = (TextBlock FAR *) (dap+1);
	for (ii=0; ii<dap->dAnn; ii++)
		{
		TUTORfree_handle(curBlock->text);
		curBlock->tLen = 0L;
		curBlock++;
		}
	dap->dAnn = 0; /* we are not using any text blocks anymore */
	dp->shortText = TRUE;
	
	ReleasePtr(doc);
	KillPtr(dp);
	
	return(0);
	}

ChangeTBlock(dp,pos,len,newP,newLen,unlocked,followP) /* change text of document */
REGISTER DocP dp;		/* pointer to doc */
long pos, len;	/* region we are changing */
unsigned char FAR *newP; /* new characters */
long newLen;	/* # of new chars */
int *unlocked; /* set to TRUE if we unlocked doc here */
int *followP;	/* if exists, set to true if char just before pos is NEWLINE */
	{
	register TextBlock FAR *curBlock;	/* current text block */
	TextBlock FAR *prevBlock;	/* previous text block */
	long pOff;	/* position in current text block */
	long eOff;	/* # of chars remaining in current text block */
	DArrayHeader FAR *dap; /* pointer to textblock darray (in document) */
	long tempL;
	long len2;	/* # of chars replaced in first block */
	unsigned char FAR *tp; /* pointer at text in handle */
	Memh doc;	/* the document (which dp refers to) */
	short ind;	/* index of current text block */
	int ii;

	if (TUTORget_lockcount(dp->self) != 1) 
		TUTORdump("incorrect lock count 7");	

	if (newLen > MAXBLOCKLEN)
		{ /* break up change so that it doesn't overflow 1st block */
		tempL = newLen/2;
		doc = dp->self;
		ChangeTBlock(dp,pos,len,newP,tempL,&ii,followP);
		if (ii)
			dp = (DocP) GetPtr(doc);
		ChangeTBlock(dp,pos+tempL,0L,newP+tempL,newLen-tempL,unlocked,NEARNULL);
		if (!*unlocked && ii)
			{
			ReleasePtr(doc); /* so caller's GetPtr doesn't unbalance things */
			KillPtr(dp);
			}
		*unlocked |= ii;	/* so caller knows whether we ever unlocked it */
	
		if (TUTORget_lockcount(doc) != ((*unlocked)? 0: 1)) 
			TUTORdump("incorrect lock count 1");
		
		return(0);
		}
	
	dp->buffEnd = -1L; /* invalidate CharAt buffer */
	*unlocked = FALSE;

	dap = (DArrayHeader FAR *) ((char FAR *) dp + dp->offsets[DOCTBLOCK]);
	
	curBlock = FindTBlock(dp,pos,&pOff,&eOff);
	ind = curBlock - (TextBlock FAR *) (dap+1); /* index of current text block */

	ChangedHandle(curBlock->text,TRUE); /* this block is changing - no longer purgeable */

	/* put all the text in the first block, then possibly split it */
	len2 = (len > eOff) ? eOff : len; /* # of chars replaced in first block */
	
	tp = (unsigned char FAR *) GetPtr(curBlock->text);

	if (followP)
		{ /* check char just before pos to see if it is a paragraph bound */
		if (pos == 0L)
			*followP = TRUE; /* begin of doc is a paragraph bound */
		else
			{
			if (pOff > 0)
				*followP = (*(tp+(pOff-1)) == NEWLINE); /* look at preceeding char */
			else
				{ /* get char directly from doc (bother!) */
				prevBlock = curBlock-1;
				if (*(GetPtr(prevBlock->text)+(prevBlock->tLen-1)) == NEWLINE)
					*followP = TRUE;
				else
					*followP = FALSE;
				ReleasePtr(prevBlock->text);
				}
			}
		}
	
	/* put in new text */

	if (len2 > newLen)
		{ /* move trailing text down */
		tempL = eOff-len2;
		if (tempL)
			TUTORblock_move((char SHUGE *) tp+pOff+len2,(char SHUGE *) tp+pOff+newLen,tempL);
		}
	
	/* adjust tExtra, possibly changing handle size */
	if ((newLen - len2 > curBlock->tExtra) ||
			(curBlock->tExtra + len2 - newLen > 2*TBLOCKBUFF))
		{ /* we need to make the text handle bigger, or smaller */
		ReleasePtr(curBlock->text);
		KillPtr(tp);
		tempL = curBlock->tLen + newLen - len2 + TBLOCKBUFF;
		TUTORset_hsize(curBlock->text,tempL,TRUE);
		curBlock->tExtra = TBLOCKBUFF;
		tp = (unsigned char FAR *) GetPtr(curBlock->text);
		}
	else
		curBlock->tExtra += len2 - newLen;
	
	if (len2 < newLen)
		{ /* move trailing text up */
		tempL = eOff-len2;
		if (tempL)
			TUTORblock_move((char SHUGE *) tp+pOff+len2,(char SHUGE *) tp+pOff+newLen,tempL);
		}
	
	/* move in new text */
	if (newLen)
		TUTORblock_move((char SHUGE *) newP,(char SHUGE *) tp+pOff,newLen);
	ReleasePtr(curBlock->text);
	KillPtr(tp);
	curBlock->tLen += newLen - len2;
	dp->totLen += newLen - len2;	

	if (curBlock->tLen > MAXBLOCKLEN)
		{ /* we need to split block */
		doc = dp->self; /* keep it in case SplitBlock unlocks doc */
		SplitBlock(dp,dap,curBlock,ind,unlocked); /* split block in half */
		if (*unlocked)
			{ /* recover pointers */
			dp = (DocP) GetPtr(doc);
			dap = (DArrayHeader FAR *) ((char FAR *) dp + dp->offsets[DOCTBLOCK]);
			ind += 2; /* to point at next block we have to consider */
			curBlock = ((TextBlock FAR *) (dap+1)) + ind;
			}
		}
	else if (curBlock->tLen <= 0)
		{ /* delete this block */
		TUTORfree_handle(curBlock->text);
		TUTORdelete_darray(dp->self,(char FAR *) dp,DOCOFFSET,DOCTBLOCK,ind,1);
		}
	else
		{ /* didn't do anything to block, just look at next block */
		ind++;
		curBlock++;
		}

	/* curBlock & ind now refer to next block */
	
	/* now do deletions for the rest of the blocks */
	len -= len2; /* account for what we've already deleted */
	while (len)	/* len is remaining amount to delete */
		{
		if (len > curBlock->tLen)
			{ /* just delete this block */
			dp->totLen -= curBlock->tLen;
			len -= curBlock->tLen;
			TUTORfree_handle(curBlock->text);
			TUTORdelete_darray(dp->self,(char FAR *) dp,DOCOFFSET,DOCTBLOCK,ind,1);
			/* ind & curBlock now refer to next block */
			}
		else
			{ /* shift chars down in block */
			tp = (unsigned char FAR *) GetPtr(curBlock->text);
			ChangedHandle(curBlock->text,TRUE); /* this block is changed, can't purge it */

			TUTORblock_move((char SHUGE *) tp+len,(char SHUGE *) tp,curBlock->tLen - len);
			ReleasePtr(curBlock->text);
			KillPtr(tp);
			curBlock->tLen -= len;
			dp->totLen -= len;
			curBlock->tExtra += len;
			if (curBlock->tExtra > 2*TBLOCKBUFF)
				{ /* block is too big, make it smaller */
				TUTORset_hsize(curBlock->text,curBlock->tLen+TBLOCKBUFF,TRUE);
				curBlock->tExtra = TBLOCKBUFF;
				}
			len = 0; /* we've deleted all the characters we have to */
			/* we don't need to worry about ind & curBlock because we're done */
			}
		}
	
	if (*unlocked)
		{
		ReleasePtr(dp->self); /* so that caller can recover pointer */
		KillPtr(dp);
		}

	return(0);
	}

TextBlock FAR *FindTBlock(dp,pos,pOff,eOff) /* return text block pointer for given text position */
DocP dp;	/* pointer to document we are searching in */
register long pos; /* the text position */
long *pOff; /* offset from block begin to sChar */
long *eOff; /* distance from pos to end of block */
	{
	register long cumLen;	/* cumulated length of text blocks preceeding current */
	register TextBlock FAR *tp;	/* pointer to current text block */
	register DArrayHeader FAR *dap;	/* dynamic array header for text blocks */
	
	if (pos < 0L || pos > dp->totLen)
		{
		TUTORdump("GetTBlock - bad pos");
		return(FARNULL);
		}
	
	dap = (DArrayHeader FAR *) ((char FAR *) dp + dp->offsets[DOCTBLOCK]);
	tp = (TextBlock FAR *) (dap+1);
	if (pos == dp->totLen)
		{ /* right at end, rather common */
		*pOff = tp[dap->dAnn-1].tLen;
		*eOff = 0;
		return(tp+(dap->dAnn-1));
		}
	
	cumLen = 0L;
	if (dap->dAnn > 1)
		{
		while(cumLen <= pos)
			{
			cumLen += tp->tLen;
			tp++;
			}
		tp--; /* since gone too far */
	
		cumLen -= tp->tLen; /* now char position at start of block */
		}
	
	*pOff = pos - cumLen;
	*eOff = tp->tLen - *pOff;
	
	return(tp);
	}

static SplitBlock(dp,dap,curBlock,ind,unlocked) /* split text block in half */
DocP dp;	/* pointer to document */
DArrayHeader FAR *dap;	/* points to TextBlock darray in doc */
register TextBlock FAR *curBlock;	/* TextBlock to split */
int ind;				/* index of TextBlock to split */
int *unlocked;			/* to be set to TRUE if we unlock doc, otherwise FALSE */
	{
	register long breakWhere;	/* position where we should break (relative to block start) */
	register long newLen;	/* length of first chunk of block */
	Memh doc;	/* to document that dp refers to */
	unsigned char FAR *tp1;	/* pointer to last half of existing block */
	unsigned char FAR *tp2;	/* pointer to beginning of new block */
	
	breakWhere = DefaultSplit(curBlock);
	newLen = curBlock->tLen - breakWhere; /* amount of text moved to new block */
	
	/* create new block (following block we are splitting) */
	doc = dp->self;
	AddTBlock(dp,dap,ind+1,newLen,unlocked);
	if (*unlocked)
		{ /* AddTBlock unlocked doc, we have to recover pointers */
		dp = (DocP) GetPtr(doc);
		dap = (DArrayHeader FAR *) ((char FAR *) dp + dp->offsets[DOCTBLOCK]);
		curBlock = ((TextBlock FAR *) (dap+1))+ind;
		}
	
	/* move text from old to new */
	tp1 = (unsigned char FAR *) GetPtr(curBlock->text)+breakWhere;
	tp2 = (unsigned char FAR *) GetPtr((curBlock+1)->text);
	TUTORblock_move((char SHUGE *) tp1,(char SHUGE *) tp2,newLen);
	ReleasePtr(curBlock->text);
	KillPtr(tp1);
	ReleasePtr(curBlock[1].text);
	KillPtr(tp2);
	curBlock->tExtra += (curBlock->tLen - breakWhere);
	curBlock->tLen = breakWhere;
	
	if (curBlock->tExtra > TBLOCKBUFF)
		{ /* need to downsize old handle, probably always happens */
		TUTORset_hsize(curBlock->text,curBlock->tLen,TRUE);
		curBlock->tExtra = 0;
		}
	
	if (*unlocked)
		{
		ReleasePtr(doc); /* so caller can call GetPtr */
		KillPtr(dp);
		}
	
	return 0;
	}

static AddTBlock(dp,dap,ind,len,unlocked)	/* add new text block */
DocP dp;	/* pointer to document */
DArrayHeader FAR *dap;	/* points at TBlock darray */
int ind;			/* index where we want new block */
long len;			/* length of new text */
int *unlocked;		/* to be set to TRUE if we unlock doc, FALSE otherwise */
	{
	Memh newText;	/* new handle for text of text block */
	register TextBlock FAR *curBlock;
	Memh doc;	/* document that dp refers to */
	
	doc = dp->self;
	if (dap->dAnn >= dap->dAnAlloc)
		{ /* we will need to resize document */
		ReleasePtr(doc);
		KillPtr(dp);
		*unlocked = TRUE;
		}
	else
		*unlocked = FALSE;
	
	/* create handle for text (at this point because document is likely to be unlocked) */
	newText = TUTORhandle("textblck",len,FALSE);
	if (!newText)
		TUTORdump("Couldn't allocate text block");
	TUTORpurge_info(newText,M_WORM,FARNULL,0);
	AllowHandlePurge(newText);

	/* put in new TBlock */
	TUTORinsert_darray(doc,(char FAR *) (*unlocked ? FARNULL : dp),DOCOFFSET,DOCTBLOCK,ind,1);
	if (*unlocked)
		{ /* recover pointers */
		dp = (DocP) GetPtr(doc);
		dap = (DArrayHeader FAR *) ((char FAR *) dp + dp->offsets[DOCTBLOCK]);
		}
	
	curBlock = ((TextBlock FAR *) (dap+1)) + ind;
	curBlock->text = newText;
	curBlock->tLen = len;
	curBlock->tExtra = 0;

	if (*unlocked)
		{
		ReleasePtr(doc); /* so caller can recover pointers */
		KillPtr(dp);
		}

	return 0;
	}

static long DefaultSplit(sBlock) /* find a place to break block */
register TextBlock FAR *sBlock; /* pointer to block */
/* returns length of text of first "half" of block */
	{
	unsigned char FAR *tp;	/* where we are looking in text block */
	unsigned char FAR *t0;	/* pointer to beginning of block */
	long retVal;	/* ther return value */
	
	t0 = (unsigned char FAR *) GetPtr(sBlock->text);
	tp = t0 + 2*sBlock->tLen/3; /* 2/3 thru sBlock */
	/* try to break on newline */
	tp = TUTORscan_bytes(tp,t0,(unsigned char *) NEWLINES,1);
	if (tp)
		retVal = 1L+(long) (tp-t0);
	else
		retVal = sBlock->tLen/2; /* couldn't find newline, just break it in half */

	ReleasePtr(sBlock->text);
	KillPtr(t0);
	return(retVal);
	}
