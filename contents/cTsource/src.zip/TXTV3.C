
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "baseenv.h"
#include "txt.h"
#include "txtv.h"
#include "tutor.h"
#include "editor.h"

#ifdef ctproto
int  _TUTORshrink_layout_tview(struct  _viewp FAR *tvp,int newTop,int newBot);
int  _TUTORpos2_line_tview(struct  _viewp FAR *tvp,long  pos);
long  _TUTORline_pos_tview(struct  _viewp FAR *tvp,int  lineN);
int  _TUTORinq_line_tview(unsigned int  theV,int  vv);
int  _TUTORline2_vv_tview(struct  _viewp FAR *tvp,int  nn);
int  _TUTORinfo_vbar_tview(struct  _viewp FAR *tvp,struct  _sbarinf *vb);
int  _TUTORinfo_hbar_tview(struct  _viewp FAR *tvp,struct  _sbarinf *sbh);
int  _TUTORnew_bottom_tview(unsigned int  theV,struct  _viewp FAR *tvp);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORdelete_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nDel);
#endif /* ctproto */

extern char FAR *GetPtr();
extern long _TUTORline_pos_tview();

_TUTORshrink_layout_tview(tvp,newTop,newBot)
register TViewP tvp;	/* pointer to tview */
register int newTop, newBot; /* new top & bottom lines of layout (where old topline is 0) */
	{
	/* make sure we don't shrink away any visible lines */
	if (newTop > tvp->topLine)
		newTop = tvp->topLine;
	if (newBot < tvp->botLine)
		newBot = tvp->botLine;
	
	if (newBot < tvp->txtvH.dAnn)
		{ /* we will delete tvp->txtvH.nn - newBot lines at the layout bottom */
		tvp->layoutBottom = _TUTORline_pos_tview(tvp,newBot+1);
		TUTORdelete_darray(tvp->self,(char FAR *) tvp,VIEWOFFSET,0,newBot+1,
				tvp->txtvH.dAnn - newBot);
		}
	if (newTop > 0)
		{ /* newTop equals the number of layout lines to delete */
		tvp->layoutTop = _TUTORline_pos_tview(tvp,newTop);
		TUTORdelete_darray(tvp->self,(char FAR *) tvp,VIEWOFFSET,0,0,newTop);
		tvp->topLine -= newTop;
		tvp->botLine -= newTop;
		tvp->anchor.nLine -= newTop;
		if (tvp->anchor.nLine < 0)
			tvp->anchor.nLine = 0;
		tvp->selA.nLine -= newTop;
		if (tvp->selA.nLine < 0)
			tvp->selA.nLine = 0;
		}
	
	return(0);
	}

_TUTORpos2_line_tview(tvp,pos) /* convert character position to line # */
register TViewP tvp;	/* pointer to tview */
register long pos; /* this position is assummed to be within existing layout */
	{
	register int ii;
	register LineLayout FAR *li;	/* pointer to line layouts */
	
	pos -= tvp->layoutTop;
	ii = 0;
	li = (LineLayout FAR *) tvp->ld;
	while (ii < tvp->txtvH.dAnn)
		{
		pos -= li->nc;
		if (pos < 0)
			break;
		ii++;
		li++;
		}
	return(ii);
	}

long _TUTORline_pos_tview(tvp,lineN) /* convert line number to character position */
register TViewP tvp;	/* pointer to tview */
register int lineN;	/* line number we want to convert */
	{
	register LineLayout FAR *llp;	/* pointer to line layouts */
	register long pos;	/* cumulated position */
	
	llp = ((LineLayout FAR *) tvp->ld);
	pos = tvp->layoutTop;
	while (lineN)
		{
		pos += (llp++)->nc;
		lineN--;
		}
	
	return(pos);
	}

_TUTORinq_line_tview(theV,vv)	/* convert vertical position to line # */
Memh theV;	/* tview */
register int vv;	/* the vertical position we want to convert */
 /* returns line # (relative to layout start!) of line at vv */
	{
	REGISTER TViewP tvp;	/* pointer to tview */
	register int ii;
	register LineLayout FAR *llp;	/* pointer to line layouts */
	
	/* no matter what vv is, we return a line # of a line that is currently displayed */
	tvp = (TViewP) GetPtr(theV);
	vv -= tvp->viewRect.top; /* now vv is distance from view top */
	llp = ((LineLayout FAR *) tvp->ld) + tvp->topLine;
	for (ii=tvp->topLine; ii< tvp->botLine; ii++,llp++)
		{
		vv -= llp->lineHeight;
		if (vv <= 0)
			break;
		}
	
	ReleasePtr(theV);
	KillPtr(tvp);
	
	return(ii);
	}

_TUTORline2_vv_tview(tvp,nn) /* convert line # to vertical position */
register TViewP tvp;	/* pointer to tview */
register int nn;	/* line number to be converted */
	{
	register int ii;	/* line index */
	register int vv;	/* cumulative vertical position */
	
	ii = tvp->topLine;
	vv = tvp->viewRect.top + tvp->ld[tvp->topLine].lineAsc;
	
	if (nn <= tvp->topLine)
		{ /* line is at or above top line showing */
        	while (ii > nn){
	   		vv -= tvp->ld[ii].lineAsc;
	    		if ((ii-1) >= 0)
				vv -= (tvp->ld[ii-1].lineHeight - tvp->ld[ii-1].lineAsc);
            		ii--;
            	}
		/* while (ii > nn)
			{
			vv -= tvp->ld[ii].lineAsc +
					(tvp->ld[ii-1].lineHeight - tvp->ld[ii-1].lineAsc);
			ii--;
			} */
		}
	else
		{ /* line is below top line showing */
        	while (ii < nn) {
	    		vv += (tvp->ld[ii].lineHeight - tvp->ld[ii].lineAsc);
	    		if ((ii+1) < tvp->txtvH.dAnAlloc)
		   		vv += tvp->ld[ii+1].lineAsc;
            		ii++;
            	}
		/* while (ii < nn)
			{
			vv += (tvp->ld[ii].lineHeight - tvp->ld[ii].lineAsc) +
							tvp->ld[ii+1].lineAsc;
			ii++;
			} */
		}
	return(vv);
	}

_TUTORinfo_vbar_tview(tvp,vb)	/* calculate vertical scroll bar information */
register TViewP tvp;	/* pointer to tview */
register SBarInfo *vb;	/* to be filled with vertical scroll bar info */
	{
	register long tempL;
	
	/* note that for scroll bar, position is relative to start of view.  So all the
		positions are offset from document positions by tvp->bounds.pos */
	vb->maxPos = tvp->bounds.len;
	vb->curPos = vb->rangePos = _TUTORline_pos_tview(tvp,tvp->topLine) - tvp->bounds.pos;
	vb->rangeLen = tvp->botPos - tvp->bounds.pos - vb->rangePos;
	tempL = (tvp->anchor.pos <= tvp->selA.pos) ? tvp->anchor.pos : tvp->selA.pos;
	vb->selPos = tempL - tvp->bounds.pos;
	vb->selLen = tvp->selA.pos - tvp->anchor.pos;
	if (vb->selLen < 0)
		vb->selLen = -vb->selLen;
	
	return(0);
	}

_TUTORinfo_hbar_tview(tvp,sbh)	/* calculate horizontal scroll bar info */
register TViewP tvp;	/* pointer to tview */
register SBarInfo *sbh;	/* to be filled with horizontal scroll bar info */
	{
	int ii;
	
	ii = tvp->viewRect.right - tvp->viewRect.left + 1; /* view width */
/* scroll-change */
/*	sbh->maxPos = tvp->destWidth; */
	sbh->maxPos = HSCROLL_WIDTH;
	sbh->curPos = sbh->rangePos = -tvp->leftOff;
	sbh->rangeLen = ii;
	
	return(0);
	}

_TUTORnew_bottom_tview(theV,tvp) /* recalculate bottom line */
Memh theV;	/* tview */
REGISTER TViewP tvp;	/* pointer to tview */
	{
	int gotPointer;	/* TRUE if we dereferenced tview */
	register int totHeight;	/* cumulative total height passed */
	register int ii;
	register LineLayout FAR *llp;	/* pointer to line layouts */
	
	if (!tvp)
		{
		tvp = (TViewP) GetPtr(theV);
		gotPointer = TRUE;
		}
	else
		gotPointer = FALSE;
	
	totHeight = tvp->viewRect.bottom - tvp->viewRect.top + 1;
	llp = ((LineLayout FAR *) tvp->ld) + tvp->topLine;
	tvp->botPos = _TUTORline_pos_tview(tvp,tvp->topLine);
	tvp->botV = tvp->viewRect.top-1;
	for (ii=tvp->topLine; ii<tvp->txtvH.dAnn; ii++,llp++)
		{
		totHeight -= llp->lineHeight;
		tvp->botPos += llp->nc;
		tvp->botV += llp->lineHeight;
		if (totHeight <= 0)
			break;
		}
	tvp->botLine = (ii < tvp->txtvH.dAnn) ? ii : ii-1;
	if (tvp->botLine < 0)
		tvp->botLine = 0; /* empty panel */
	if (gotPointer)
		{
		ReleasePtr(theV);
		KillPtr(tvp);
		}
	
	return(0);
	}
















