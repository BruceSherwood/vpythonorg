
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* less frequently used document manipulation routines */

#include "baseenv.h"
#include "txt.h"
#include "tglobals.h"

#ifdef ctproto
int  TUTORinit_doc(void);
int  TUTORsave_do_doc(unsigned int  doc,long  pos,long  len,int  op,long  newLen);
int  TUTORundo_doc(unsigned int  doc,long  *pos,long  *len,long  mpos,long  mlen,long  *newLen,long  *extraChange);
int  TUTORadd_inset_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,int  kind,unsigned int  dat,long  *extraPos);
int  _TUTORchange_stext_doc(struct  _ktd FAR *dp,long  pos,long  len,long  cLen,unsigned int  specialT,long  fromStart);
int  TUTORstyle_hot_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *ss,long  sLen);
int  TUTORinq_hot_doc(unsigned int  doc,long  pos,int  wSide);
int  TUTORchange_hot_text_doc(unsigned int  doc,int  id,char  FAR *ss,long  sLen);
int  AddParaLayout(struct  _paral *pl);
int  GetParaLayout(int  ii,struct  _paral *pl);
int  TUTORdelete_stext(unsigned int  st,long  pos,long  len);
unsigned int  TUTORnew_stext(void);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  TUTORadd_stext(unsigned int  st,long  pos,int  type,unsigned int  dat);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORchange_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,unsigned char  FAR *cp,long  cLen,long  fromOff,unsigned int  styles,unsigned int  specialT,long  *extraPos,int  eupFlag);
int  TUTORclear_doc(unsigned int  doc);
int  TUTORclose_doc(unsigned int  doc);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
unsigned int  TUTORnew_doc(int  string,int  honorP);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORinsert_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nIns);
int  _TUTORupdate_markers_doc(struct  _ktd FAR *dp,long  mpos,long  mlen,long  cpos,long  clen,long  newlen,long  sEnd);
unsigned char  FAR *GetHotstringTStyle(unsigned int  pd,int  id,long  *len,long  *spos,long  *slen,int  getS);
int  TUTORchange_hot_text(unsigned int  pd,int  id,char  FAR *ss,long  sLen);
int  FindBlockTypeTStyle(struct  _pdt FAR *pp,long  ps,int  type);
int  AddHotTStyle(unsigned int  pd,long  start,long  len,long  docLen,unsigned char  FAR *ss,long  sLen);
unsigned int  NewTStyle(void);
int  TUTORdump(char  *s);
int  TUTORclose_stext(unsigned int  st);
int  TUTORinsert_stext(unsigned int  st,long  pos,long  newLen);
int  TUTORsplice_stext(unsigned int  st,unsigned int  fromSt,long  pos,long  fromPos,long  fromLen);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
extern int sprintf(char *ss, char *form,...);
#endif

extern unsigned int TUTORnew_doc();
extern char FAR *GetPtr();
long TUTORget_len_doc();
unsigned int  TUTORnew_stext();
unsigned char FAR *GetHotstringTStyle();

/* for undoing */
typedef struct _undo
	{
	Memh undoScratch;
	long pos, newLen, oldLen;
	Memh undoDoc;
	short lastOp;
	} UndoDat;
static UndoDat undo1;

TUTORinit_doc() /* initialize text machinery */
	{
	REGISTER PLayoutTable FAR *plt;	/* pointer to global paragraph layouts */
	
	refhead = refnum = 0; /* no document-referenced chain yet */
	
	/* initialize paragraph layout table */
	plTable = TUTORhandle("pltable ",(long) sizeof(PLayoutTable), TRUE);
	plt = (PLayoutTable FAR *) GetPtr(plTable);
	plt->nArrays = 1;
	plt->totalSize = sizeof(PLayoutTable);
	plt->offsets = ((char FAR *) &plt->pHead) - ((char FAR *) plt);
	plt->pHead.dAnAlloc = 1;
	plt->pHead.dAnn = 0;
	plt->pHead.nBuff = 2;
	plt->pHead.itemSize = sizeof(ParagraphLayout);
	ReleasePtr(plTable);
	KillPtr(plt);
	
	/* put in default layout (the one used by -write-) */
	defaultLayout.tabSize = 60;
	defaultLayout.leftMar = defaultLayout.rightMar = 0;
	defaultLayout.paraIndent = 0;
	AddParaLayout(&defaultLayout);
	
	/* initialize undoing */
	undo1.undoDoc = HNULL; /* no previous doc */
	undo1.undoScratch = TUTORnew_doc(TRUE,TRUE);
	}

TUTORsave_do_doc(doc,pos,len,op,newLen) /* save an operation for later undo */
Memh doc;	/* the document upon which ther operation is being done */
register long pos, len; /* where operation is being done */
int op; /* operation to save: 0: key, 1: paste, 2: clear */
register long newLen; /* # of new chars */
/* returns TRUE on success */
	{
	long extraDumm; /* dummy variable */
	
	if (!doc)
		{ /* forcing can't undo state */
		TUTORclear_doc(undo1.undoScratch);
		undo1.undoDoc = HNULL;
		return(TRUE);
		}
	
	if (op == 0 && undo1.lastOp == 0 && !len &&
				pos == undo1.pos + undo1.newLen && doc == undo1.undoDoc)
		{ /* continuation of keys */
		undo1.newLen += newLen;
		return(TRUE);
		}
	
	/* this is a new operation... */
	
	undo1.undoDoc = doc;
	undo1.lastOp = op;
	undo1.pos = pos;
	undo1.newLen = newLen;
	undo1.oldLen = len;
	
	/* clear old save */
	TUTORclear_doc(undo1.undoScratch);
		
	if (len)
		{ /* need to make copy of text and styles in cleared region */
		TUTORchange_doc_doc(undo1.undoScratch,0L,0L,0L,0L,doc,pos,len,&extraDumm,FALSE);
		}
	
	return(TRUE);
	}

TUTORundo_doc(doc,pos,len,mpos,mlen,newLen,extraChange) /* undo last operation */
Memh doc;	/* document that is being undone */
long *pos; /* to be set to position of undoing */
long *len; /* to be set to length of text deleted by undo */
long mpos, mlen;	/* "marker" that this undo is affecting */
long *newLen; /* to be set to length of text inserted by undo */
long *extraChange; /* to be set to # of chars of extra linestarts (paragraph adjusts) */
/* returns TRUE on success */
	{
	long swapL;	/* long used for swapping */
	long extraDumm;	/* dummy variable */
	short ii;
	Memh tempDoc;	/* temporary document used for copy */
	
	if (doc != undo1.undoDoc)
		return(FALSE); /* wrong document or missing info */
	
	/* newLen is length of chars we are undoing,
		oldLen is length of chars we are restoring */
	
	if (undo1.newLen > 0)
		{ /* need to copy text from document (put in temporary place) */
		tempDoc = TUTORnew_doc(TRUE,TRUE);
		TUTORchange_doc_doc(tempDoc,0L,0L,0L,0L,doc,undo1.pos,
				undo1.newLen,&extraDumm,FALSE);
		}
	else
		tempDoc = HNULL;
	
	/* change document */
	TUTORchange_doc_doc(doc,undo1.pos,undo1.newLen,mpos,mlen,undo1.undoScratch,
				0L,undo1.oldLen,extraChange,FALSE);
	
	/* swap old & new */
	/* this is so the undo we just did can be undone */
	
	swapL = undo1.newLen;
	undo1.newLen = undo1.oldLen;
	undo1.oldLen = swapL;
	undo1.lastOp = 1; /* for redo (not a key) */
	
	if (tempDoc)
		{ /* switch saved text */
		TUTORclose_doc(undo1.undoScratch);
		undo1.undoScratch = tempDoc;
		}
	else
		TUTORclear_doc(undo1.undoScratch);
	
	*pos = undo1.pos;
	*len = undo1.oldLen;
	*newLen = undo1.newLen;
	
	return(TRUE);
	}

TUTORadd_inset_doc(doc,pos,len,mpos,mlen,kind,dat,extraPos) /* add graphic char */
Memh doc;	/* document being changed */
register long pos;	/* where (in the document) the inset is being added */
long len;	/* the number of characters the inset is replacing */
long mpos,mlen;	/* "marker" this is affecting */
int kind;	/* what kind of inset (BITMAPSPECIAL, etc) */
Memh dat;	/* data describing the inset */
long *extraPos;	/* to be set to position at end of all changes */
	{
	unsigned char ss[2];	/* string which represents inset in document text */
	REGISTER DocP dp;	/* pointer to doc */
	
	/* add text to doc (which takes care of all dependent changes) */
	ss[0] = kind;
	TUTORchange_doc(doc,pos,len,mpos,mlen,ss,1L,0L,HNULL,HNULL,extraPos,FALSE);
	
	/* add inset */
	dp = (DocP) GetPtr(doc);
	if (!dp->specialT)
		dp->specialT = TUTORnew_stext();
	
	TUTORadd_stext(dp->specialT,pos,kind,dat);
	
	ReleasePtr(doc);
	KillPtr(dp);
	
	return(0);
	}

/* handle special text effects of a document change: */
_TUTORchange_stext_doc(dp,pos,len,cLen,specialT,fromStart)
register DocP dp;	/* pointer to the changed document */
register long pos,len;	/* where change was made */
register long cLen;	/* length of new text */
Memh specialT;	/* special text strucure we are copying (a portion of) */
long fromStart;	/* position within styles we start looking at */
	{
	int stylesLeft;	/* TRUE if there is any special text left after change */
	
	if (!dp->specialT)
		{ /* start special text */
		dp->specialT = TUTORnew_stext();
		}
	
	stylesLeft = TRUE;
	if (len)
		stylesLeft = TUTORdelete_stext(dp->specialT,pos,len); /* delete old */
	
	if (specialT)
		stylesLeft |= TUTORsplice_stext(dp->specialT,specialT,pos,fromStart,cLen);
	else
		TUTORinsert_stext(dp->specialT,pos,cLen);
	
	if (!stylesLeft)
		{ /* we've deleted all special text */
		TUTORclose_stext(dp->specialT);
		dp->specialT = HNULL;
		}
	
	return(0);
	}

/* add hot style to document */
TUTORstyle_hot_doc(doc,pos,len,ss,sLen)
Memh doc;	/* document being changed */
long pos, len;			/* where style is going (on doc) */
unsigned char FAR *ss;	/* the hot info string */
long sLen;				/* length of the hot info string */
/* always returns FALSE */
	{
	REGISTER DocP dp;	/* pointer to doc */

	dp = (DocP) GetPtr(doc);

#ifdef DOCVERIFY
	if (pos < 0L || pos+len > dp->totLen)
		TUTORdump("TUTORstyle_hot_doc bad region");
#endif

	if (!dp->styles)
		{ /* no styles till now, add them */
		dp->styles = NewTStyle();
		}
	
	AddHotTStyle(dp->styles,pos,len,dp->totLen,ss,sLen);
	_TUTORupdate_markers_doc(dp,0L,dp->totLen,pos,0L,0L,pos+len);
	
	ReleasePtr(doc);
	KillPtr(dp);
	
	return(FALSE); /* we haven't added anything */
	}

TUTORinq_hot_doc(doc,pos, wSide) /* see whether text is hot at pos */
Memh doc;	/* the document */
long pos;	/* where to look for hotness */
int wSide; /* 1 if click was to right of pos, -1 if to left */
/* returns hot data id if text is hot, or 0 */
	{
	DocP dp;	/* pointer to doc */
	StyleDatP pp;	/* pointer to styles */
	register Style1 SHUGE *s1p;	/* pointer to current style block */
	int blockInd;	/* index of hot block in style data structure */
	int hotStyle;	/* relevant hotStyle */
	
	dp = (DocP) GetPtr(doc);
	if (dp->styles)
		{
		pp = (StyleDatP) GetPtr(dp->styles);
		blockInd = FindBlockTypeTStyle(pp,pos,HOTSTYLE);
		s1p = ((Style1 SHUGE *) pp->styles) + blockInd;
		if (s1p->pos != pos)
			{ /* there is no hot style starting or stopping at pos */
			hotStyle = s1p->dat;
			}
		else
			{ /* hot style changes at pos.  To decide whether the hit is hot, we
				have to consider which side of pos the hit is on */
			if (wSide == 1 || pos == 0)
				{ /* hit is just after pos, use style change at pos */
					/* or pos == 0, in which case there is no preceeding style */
				hotStyle = s1p->dat;
				}
			else
				{ /* hit is before pos, use style before that at pos */
				s1p--; /* go before the hotstyle we know about */
				while (s1p->type != HOTSTYLE)
					s1p--;
				hotStyle = s1p->dat;
				}
			}

		ReleasePtr(dp->styles);
		KillPtr(pp);
		}
	else
		hotStyle = DEFSTYLE; /* no styles, therefore no hot styles */
	
	ReleasePtr(doc);
	KillPtr(dp);
	
	return((hotStyle == DEFSTYLE) ? 0 : hotStyle);
	}

TUTORchange_hot_text_doc(doc,id,ss,sLen) /* change a hot text string */
Memh doc;	/* the document being changed */
register int id;	/* hot text id (the HOTSTYLE data) */
char FAR *ss;	/* new string (the hot info string) */
long sLen;	/* length of new character string */
	{
	DocP dp;	/* pointer to doc */
	long hotLen; /* length of hot info string */
	long stylePos, styleLen;	/* bounds of hot style on doc */
	
	dp = (DocP) GetPtr(doc);
	TUTORchange_hot_text(dp->styles,id,ss, sLen);
	
	/* we have made a change to the doc over the range of that hot text style */
	
	/* find out where the hot style is */
	GetHotstringTStyle(dp->styles,id,&hotLen,&stylePos,&styleLen,FALSE);
	_TUTORupdate_markers_doc(dp,0L,dp->totLen,stylePos,0L,0L,stylePos+styleLen);
	
	ReleasePtr(doc);
	KillPtr(dp);
	}

AddParaLayout(pl)	/* add a new paragraph layout */
register ParagraphLayout *pl;
/* returns index of layout, which may or may not be new */
	{
	REGISTER PLayoutTable FAR *plt;	/* pointer to paragraph layout table */
	register ParagraphLayout FAR *pl1; /* pointer to individual layout */
	register int ii;
	register int retVal;	/* index of layout */
	
	plt = (PLayoutTable FAR *) GetPtr(plTable);
	
	/* look for match */
	retVal = -1;
	for (ii=0, pl1=plt->layouts; ii<plt->pHead.dAnn; ii++,pl1++)
		{
		if (pl->tabSize == pl1->tabSize &&
				pl->leftMar == pl1->leftMar &&
				pl->rightMar == pl1->rightMar &&
				pl->paraIndent == pl1->paraIndent)
			break;
		}
	if (ii < plt->pHead.dAnn)
		retVal = ii;

	ReleasePtr(plTable);
	KillPtr(plt);
	
	if (retVal >= 0)
		return(retVal); /* we found a match already */
	
	/* we need to create a new entry */
	TUTORinsert_darray(plTable,FARNULL,LAYOUTOFFSET,0,-1,1);
	plt = (PLayoutTable FAR *) GetPtr(plTable);
	plt->layouts[ii] = *pl;
	ReleasePtr(plTable);
	KillPtr(plt);
	
	return(ii);
	}

GetParaLayout(ii,pl) /* given an index (such as style), return paragraph layout */
register int ii;	/* the index */
ParagraphLayout *pl;	/* to be set to paragraph layout */
	{
	REGISTER PLayoutTable FAR *plt;	/* pointer to global paragraph layout table */
	char tempS[100];	/* to construct debugging string */
	
	ii = (ii & PARALMASK) >> 3; /* we want index in table */
	if (ii == 0)
		*pl = defaultLayout;
	else
		{
		plt = (PLayoutTable FAR *) GetPtr(plTable);
		if (ii < 0 || ii >= plt->pHead.dAnn)
			{
			/* ii = 0; /* make it a reasonable value */
			sprintf(tempS,"Bad value to GetParaLayout: %d", ii);
			TUTORdump(tempS);
			}
		*pl = plt->layouts[ii];
		ReleasePtr(plTable);
		KillPtr(plt);
		}
	
	return(0);
	}

