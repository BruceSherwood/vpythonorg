
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>
#include "baseenv.h"
#include "kdefs.h"
#include "editmenu.h"
#include "tutor.h"
#include "editor.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "edglobal.h"
#include "commands.h"
#include "kglobals.h"
#ifndef CTEDIT
#include "cglobals.h"
#endif
#ifdef MAC
#ifdef THINKC5
#include <Packages.h>
#include <Memory.h>
#include <Fonts.h>
#include <OSUtils.h>
#include <Menus.h>
#include <Printing.h>
#else
#ifdef WERKS
#include <Packages.h>
#include <Memory.h>
#include <Fonts.h>
#include <OSUtils.h>
#include <Menus.h>
#include <Printing.h>
#include <Sound.h>
#else
#include <pascal.h>
#include <MenuMgr.h>
#include <PrintMgr.h>
#define ConstStr255Param char *
#endif
#endif
#endif

#include "txt.h"
#include "txtv.h"
#include "fkeys.h"

#ifdef ctproto
extern int About(void);
extern int UpdateWinPrefs(void);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,
 int ebsref,struct  _trect *theR,int  relInfo,int  mintw,int  wrap,
 unsigned int  doc,long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),
 int  ro,int  corner,int  erase,int  frame,int tabsz,int lm,int rm,int inhss,int type);
extern int  ActivatePanel(struct  _tvdat FAR *vp,int  aFlag,int  toView,int  setCursor);
extern int  startcaret(struct  _tvdat FAR *vp,long  btime);
static int UndoHilite(void);
extern int DebugClearStep(void);
extern int TUTORis_foreground(int wix);
int  TUTORclear_screen(void);
int  TUTORclip_window(int  wid);
extern int EditForward(void);
extern int DebugOpenWindow(void);
extern int VerifyFindUnits(void);
extern int TUTORlog(char *str);
extern int TUTORprint_dialog(int wix,int type);
Memh immediatePalette(Memh ppp);
extern int RealizeCTPalette(Memh newH,int allNew) ;
Memh initial_palette(void);
extern int InitialStack(void);
int TUTORset_dir(FileRef FAR  *path);
long  TUTORinq_msec_clock(void);
int  TUTORclose_view(struct  tutorview FAR *vp);
int  TUTORcopy_fileref_dir(struct  _fref FAR *dirname,struct  _fref FAR *fullname);
extern int TUTORtrace_n(char *s,long nn);
int  interact(int  block);
extern int UpdateWinPrefs(void);
extern int post_toedit(void);
int  TUTORset_cursor(int  cInd,int  cChar);
extern int PostEditQuit(void);
int EditWinMenu(int index,int addf);
static NoUnitsMsg(TextVDat FAR *vp);
int CheckEditOnFile(FileRef FAR *fRef,Memh *docHP,int Exclude);
char  FAR *strcatf(char  FAR *aa,char  FAR *bb);
int  strlenf(char  FAR *aa);
int  TUTORset_window(int  wid);
int  TUTORclose_panel(unsigned int  theV);
int  TUTORdefault_styles_doc(unsigned int  doc,short  FAR *defStyles);
int TUTORget_default_styles_doc(unsigned int doc,short FAR *defStyles); 
extern int TUTORzero(char SHUGE *ptr,long length);
extern int EditClose(Memh editH);
extern int SetCurEditWi(void);
extern int TUTORtrace_n(char *msg,long nn);
extern int TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
int  TUTORdealloc(char  FAR *ptr);
extern int TUTORsize_exec_window(int wX,int wY);
extern int TUTORcmp_fileref(FileRef FAR *f1,FileRef  FAR *f2);
int  TUTORset_menubar(unsigned int  barh,struct  tutorview FAR *newMenuView);
int  TUTORset_event_mask(int  eventc,int  value);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
int  TUTORset_window_title(int  wid,char  *wt);
extern int EditNewPrefs(int wix);
extern int TUTORprefs_dialog(int wn);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,int ebsref,
 struct  _trect *theR,int  relInfo,int  mintw,int  wrap,unsigned int  doc,long  pos,
 long  len,int  wantV,int  wantH,int  (*KeyF)(),int  ro,int  corner,int  erase,
  int  frame,int tabsz,int lm,int rm,int inhss,int type);
extern int EditOpen(struct  _fref FAR *filename,long spos,long slen);
int  TUTORcreate_window(int  top,int  left,int  xSize,int  ySize,int  type);
int  TUTORadd_inset_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,int  kind,unsigned int  dat,long  *extraPos);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
int AllowHandlePurge(Memh hh);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
extern int cvt_font_name(char *str);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int TUTORfree_handle(Memh mm);
int  getnum(char  *s,int  *floatf,long  *i,double  *d,char  * *errm,int  *errn);
extern int TUTORtrace(char *str);
extern int free_snapShot(void);
extern int TUTORdump(char *str);
int  procedit(unsigned int  editH,struct  tutorevent *cev);
extern int  CheckAllSaves(struct  _tvdat FAR *vp);
extern int  CheckSaves(int  editI,int ifAlt,int  *goOn,struct  _tvdat FAR *vp);
int  ChangeEditMenus(int  onOff);
extern int  EditorStartHelp(struct  _edat FAR *ep);
extern int  EditSaveas(struct  _edat FAR *ep,struct  _tvdat FAR *vp,struct  _fref FAR *filename,int  type);
extern int  EditSave(struct  _edat FAR *ep,struct  _tvdat FAR *vp);
extern int  EditSwitchFile(struct  _edat FAR *ep,struct  _tvdat FAR *vp,struct  _fref FAR *newFile);
int  EditCheckpoint(struct  _edat FAR *ep,struct  _tvdat FAR *vp);
int  editormsg(char  *ss,int  aFlag);
extern int  DoSearchUnit(struct  _tvdat FAR *vp);
extern int  EditSearchUnit(char  *unitName,struct  _tvdat FAR *vp,int  select,
              int  dopartial);
extern int  EditCompile(unsigned int  editH,struct  _edat FAR *ep,struct  _tvdat FAR *vp,int  binf);int  getnum(char  *s,int  *floatf,long  *i,double  *d,char  * *errm,int  *errn);
extern int  EditSelectUnit(struct  _edat FAR *ep,struct  _tvdat FAR *vp,long  StartSelect);
extern int  CantFindUnit(struct  _tvdat FAR *vp,char  FAR *uname);
int  EditConvert(void);
int  DictInsert(char  *s);
extern int  AddMore(unsigned int  doc,char  *ss,long  *pos);
int  LocateUnit(Memh doc,long  pos);
int  _TUTORset_state_internal_marker(int  ind,long  pos,long  len,int  altered);
char  FAR *GetPtr(unsigned int  mm);
int  myexit(void);
int  PrintEditDoc(struct  _tvdat FAR *et,char  *dName);
int  TUTORwait_cursor(void);
int  AfterDialog(struct  _tvdat FAR *vp,int  updateFlag);
int  TUTORsavefile_dialog(int  wn,char  *msg,struct  _fref *filename,int  maxRet);
int  BeforeDialog(struct  _tvdat FAR *vp);
int  TUTORfiletype_dialog(int  wn,int expect);
int  TUTORreadfile_dialog(int  wn,char  *msghdr,struct  _fref *filename,char *defname,int  maxRet,int  type,int  msgb,int  doRedraw);
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
int  TUTORinsert_file_tview(struct  _tvdat FAR *vp,struct  _fref FAR *newFile,int type);
int  TUTORinq_select_tview(unsigned int  theV,long  *pos,long  *len);
int  TUTORset_view(struct  tutorview FAR *vp);
int  TUTORshow_window(int  wix);
int  initdict(void);
int  TUTORdelete_menu(unsigned int  barh,char  *card,char  *item);
int  IndentOff(struct  _tvdat FAR *vp,long  pos,long  len,int  charOut);
int  IndentOn(struct  _tvdat FAR *vp,long  pos,long  len);
int  CommentOut(struct  _tvdat FAR *vp,long  pos,long  len);
int  ShowAllUnits(struct  _tvdat FAR *vp);
int  ShowUnits(struct  _tvdat FAR *vp,long  pos,long  len);
int  HideUnits(struct  _tvdat FAR *vp,long  pos,long  len, int all);
int  TUTORync_dialog(int  wn,char  *msg);
int  CTpalette(int  wn,unsigned int  newPal,int  newFlag,unsigned int  defPal);
int  TUTORmessage(struct  tutorview FAR *vp,int  eKind,int  eVal);
int  TUTORforward_window(int  wix);
int  TUTORpost_event(struct  tutorevent *event);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int  GetUnitName(int  unitn,unsigned char  *name);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  RestartPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  selStart,long  selLen);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORreset_text_sbar(unsigned int  sbi,struct  _sbarinf *sinf,int  doDraw);
int  TUTORset_select_tview(unsigned int  theV,long  pos,long  len,struct  _sbarinf *vb);
int  TUTORclear_window(int  wid);
int  TUTORchange_hot_text_doc(unsigned int  doc,int  id,char  FAR *ss,long  sLen);
int  TUTORedit_dialog(int  wn,char  *msg,char  FAR *retS1,char *msg2,char  FAR *retS2,int  maxRet);
int  FindWindowByType(int  type);
int  TUTORadd_menu(unsigned int  barh,char  *card,int  cp,char  *item,int  ip,int  keyBind,int  type,int  unit,double  unitArg,int  eType);
extern int TUTORclose_window(int wid);
int  writedoc(unsigned int  kdocp,struct  _fref FAR *filen,int mode);
int  TUTORclose(int  findx);
int  TUTORfwrite_be2_doc(int  sFlag,unsigned int  theD,long  sPos,long  ePos,int  fOut,char  FAR * FAR *mp,long  *mLen);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  TUTORflush(void);
int  openhelp(int  pid);
int  TUTORmodify_menu(unsigned int  barh,char  *card,char  *item,int  enableFlag,int  checkFlag,int  style);
int  CountNeedsCompiled(void);
char  *parse_env(void);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
int  _TUTORinq_state_internal_marker(int  ind,long  *pos,long  *len,int  *altered);
int  readbinary(struct  _fref FAR *fn,int issource);
int  settitles(char  *filename);
int  TUTORget_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  setmainfile(struct  _fref FAR *filename);
int  insertversion(void);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
int  _TUTORinternal_marker(struct  markvar FAR *mp,unsigned int  stackH,long  rloc);
int  readdoc(unsigned int  doc,struct  _fref FAR *fRef,int  *iswrite);
int  TUTORclear_doc(unsigned int  doc);
int  EditorDefaultStyles(unsigned int  doc);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  TUTORclose_doc(unsigned int  doc);
int  clearsrc(int  domkall);
int  exec_switch_fixup(void);
int  TUTORnormal_cursor(void);
int  TUTORdelete_file(struct  _fref FAR *fRef);
int  assoc_name(struct  _fref FAR *fn,struct  _fref FAR *bfilen,char  *extnNew);
int  TUTORstat(struct  _fref FAR *fRef,struct  stat *buff);
int  strncmpf(char  FAR *aa,char  FAR *bb,int  nn);
int  strcmpf(char  FAR *aa,char  FAR *bb);
int  FindUnits(void);
int  TUTORalert(int  wn,char  *msg);
int  TUTORarrow_cursor(int  isTemp);
long  TUTORsearch_string_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sLen,long  pos,long  posEnd);
char  FAR *strcatf(char  FAR *aa,char  FAR *bb);
int  EndCompileMsg(int  wn);
int  CompileProgram(int  wix,int  binf,int  mFlag);
int  StartCompileMsg(int  wn);
int  writebinary(void);
int  TMessage(char FAR  *s);
int  SetSelectPanel(struct  _tvdat FAR *vp,long  pos,long  len);
int  FullHalt(void);
struct  tutorview FAR *TUTORinq_view(void);
int CTset_foreground_color(int cn);
int CTset_background_color(int cn);
int CTset_window_color(int cn);
int  TUTORinsert_string_doc(unsigned int  doc,long  pos,unsigned char  FAR *ss,long  sLen);
int  TUTORdelete_doc(unsigned int  doc,long  pos,long  len,long  *extraPos);
int  RefreshPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  cpos,long  clen,long  newC,long  selStart,long  selLen,int  scroll,int force);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
extern char *strcat(char *aa, char *bb);
extern char *strcpy(char *aa, char *bb);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
#ifdef THINKC5
extern char *CtoPstr(char *ss);
extern char *PtoCstr(unsigned char *ss);
#endif

extern int TUTORforce_redraw(int wid);
extern int TellEventEditM(int ei);
extern int _CTmac_working_dir(FileRef FAR *fRef);
extern int DeactivateColor(void);
static int ChangeFaceMenu(long faceList, int onOff);
static int ChangeJustMenu(long oldJust, long newJust);
static int ChangeSizeMenu(long oldSize, long newSize);
static int ChangeFontMenu(long oldFont, long newFont);
extern int TUTORset_textfont(int jj);
extern long TUTORprint_doc(Memh doc, long pos, long len, int pageX, int pageY,
    int left, int *pStart, int pFlag);
#ifdef THINKC5
pascal void NumToString(long theNum,Str255 theString); 
#endif
#endif

extern char FAR *strcpyf();
extern char *machinename();
extern Memh TUTORnew_doc();
extern struct tutorview FAR *TUTORinq_view();
extern int proceditstub();
extern Memh TUTORinit_menubar();
extern char *strf2n();
extern long TUTORget_len_doc();
static long LineToPos();
extern TextBlock FAR *FindTBlock();
extern long TUTORsearch_string_doc();
extern long TUTORprint_doc();
extern char *parse_env();

#ifdef X11
extern char *aboutTxt;
#endif

/* ******************************************************************* */

static int editQuitI = -1; /* index of editor window quiting */
static int internalSelect = FALSE; /* did an internal error/step selection */

/* ******************************************************************* */

char *aboutMsg = "cT is a copyright (c) Carnegie Mellon University, 1989, 1992, 1995, 1999.\n\nPermission to reproduce and use cT for internal use is granted provided the\ncopyright and \"No Warranty\" statements are included with all reproductions.\ncT may also be redistributed without charge provided that the copyright and\n\"No Warranty\" statements are included in all redistributions.\n\nNO WARRANTY. cT IS FURNISHED ON AN \"AS IS\" BASIS. CARNEGIE MELLON\nUNIVERSITY MAKES NO WARRANTIES OF ANY KIND, EITHER EXPRESSED OR IMPLIED AS\nTO ANY MATTER INCLUDING, BUT NOT LIMITED TO, WARRANTY OF FITNESS FOR\nPURPOSE OR MERCHANTABILITY, EXCLUSIVITY OF RESULTS OR RESULTS OBTAINED FROM\nUSE OF cT. CARNEGIE MELLON UNIVERSITY DOES NOT MAKE ANY WARRANTY OF ANY\nKIND WITH RESPECT TO FREEDOM FROM PATENT, TRADEMARK OR COPYRIGHT\nINFRINGEMENT.";

/* ******************************************************************* */

procedit(editH,cev)
Memh editH;
struct tutorevent *cev; /* pointer to event */
    
{   int wid; /* window index */
    FileRef filename; /* source file name */
    FileRef famName; /* font family name */
    int ii, jj, sii;
    Memh NewPattern();
    int item, modifier;
    EditDat FAR *ep;    /* pointer to editable text info */
    TextVDat FAR *vp;
    Memh tempH;
    struct tutorview FAR *viewp;
    long startSelect, lenSelect;
    long newlineP, docLen;
    unsigned int lineN; /* line number to report or go to */
    int famiD,fsize; /* icon family id and size */
    Memh iconDatH; /* handle on icon stext data */
    int FAR *iconDatB; /* pointer to icon stext data */
    int FAR *iconDatP; /* pointer to icon stext data */
    long iconDatL; /* length of icon stext data */
    long extraPos;
    int iconN; /* icon number */
    int Nicons; /* number icons found */
    int nI; /* index in numeric input */
	int didDialog; /* TRUE if did a file save dialog */
    int runF; /* TRUE if should post run event */
    struct tutorevent xev; /* toexec event */
    char tempS[256];
    char FAR *sp;
    SBarInfo sbv;
    int floatf; /* getnum, true if floating value */
    long intv; /* getnum, integer value */
    double floatv; /* getnum, floating value */
    char *errp; /* getnum, pointer to error message */
    Memh openDocH; /* handle on file opened */
    Memh palH; /* handle on editor palette */
	TViewP tvp; /* pointer to text view info */
           
    ep = (EditDat FAR *) GetPtr(editH);
    wid = ep->wid;
    vp = (TextVDat FAR *) GetPtr(ep->textPanel);
    TUTORset_view(vp->view); /* make sure we have the right view */

    switch (cev->type) {
        
    case EVENT_LEFTDOWN:
    case EVENT_RIGHTDOWN:
    case EVENT_LEFTUP:
    case EVENT_RIGHTUP:
    case EVENT_DOWNMOVE:
    	UndoHilite(); /* clean up step, error highlight */
    	break;
    	
    case EVENT_MSG:
    case EVENT_MENU:
    	UndoHilite(); /* clean up after step, error */
        TUTORinq_select_tview(vp->textv,&startSelect,&lenSelect);
        item = cev->a1;
        modifier = cev->a2;

		/* convert Save to Save As if new untitled file */

		if ((fileSpecified == 7) && (item == edit_save))
			item = edit_saveas;

        switch (item) {
        
/* ------------------------------------- FILE ------------------------ */

        case edit_saveas:
            cev->type = -1; /* handled here */
            if (CurEditWi < 0) SetCurEditWi();
            TUTORcopy_fileref((FileRef FAR *) &filename,&ep->filename);
            TUTORcopy_fileref_dir((FileRef FAR *) currentDirP,(FileRef FAR *)&filename);
    		TUTORset_dir(currentDirP);
            BeforeDialog(vp);
            if (TUTORsavefile_dialog(vp->view->window,"Save To:",&filename,0))
                EditSaveas(ep,vp,(FileRef FAR *) &filename, cev->a2);
            AfterDialog(vp,TRUE);
            break;

		case edit_save:
            cev->type = -1; /* handled here */
            EditSave(ep,vp);
            break;
                  
        case edit_insertf:
            TUTORcopy_fileref_dir((FileRef FAR *) currentDirP,(FileRef FAR *)&ep->filename);
    		TUTORset_dir(currentDirP);
            BeforeDialog(vp);
            TUTORcopy_fileref((FileRef FAR *) &filename,&ep->filename);
            ii = TUTORreadfile_dialog(vp->view->window,"Insert:",&filename,NEARNULL,0,4,1,TRUE);
            AfterDialog(vp,TRUE);
            if (ii != 1)
                break; /* cancelled */
            BeforeDialog(vp);
            ii = TUTORfiletype_dialog(vp->view->window,-1);
            AfterDialog(vp,TRUE);
			TUTORwait_cursor();
			jj = TxtMemErr; /* save current out-of-memory count */
            TUTORinsert_file_tview(vp,(FileRef FAR *) &filename,ii);
			TUTORnormal_cursor();            
			if (jj != TxtMemErr) 
            	TUTORalert(vp->view->window,"Out of memory");
            break;
            
		case edit_switch:
			/* modifier = 0 = switch */
			/*            1 = new */
			/* 			  2 = jumpout */
            /*            3 = Apple Event, first file */
            /*            4 = open */
            cev->type = -1; /* handled here */
            runF = binaryOnly = FALSE;

			/* save all altered files */
			
			if (modifier != 4) { /* don't worry about open */
            	jj = CheckAllSaves(vp);
            	if (!jj)
                	break; /* user cancelled */
            }
                        
            /* set back to base editor */
            
            ReleasePtr(ep->textPanel);
            ReleasePtr(editH);
            wid = EditWn[0];
            editH = windowsP[wid].wH;
            ep = (EditDat FAR *) GetPtr(editH);
            vp = (TextVDat FAR *) GetPtr(ep->textPanel);
            TUTORset_view(vp->view); /* make sure we have the right view */
            CurEditWi = 0; /* set back to base editor */
                 
            /* close any aux editors */
          
          	if (modifier != 4) {
            	for(ii=1; ii<EDITWINDOWLIMIT; ii++) {
                	if (EditWn[ii] >= 0) {
                    	EditClose((Memh)windowsP[EditWn[ii]].wH);
                	}
            	} /* for */
			} /* modifier if */
                
            if ((modifier == 0) || (modifier == 1)) { /* switch, new */
                TUTORcopy_fileref_dir((FileRef FAR *) currentDirP,(FileRef FAR *)&ep->filename);
    			TUTORset_dir(currentDirP);
    		}
            if (modifier == 0) { /* switch file */
                TUTORcopy_fileref((FileRef FAR *) &filename,&ep->filename);
                BeforeDialog(vp);
#ifdef MAC
                ii = TUTORreadfile_dialog(vp->view->window,"Switch To:", &filename,NEARNULL,0,5,3,TRUE);
#else
                ii = TUTORreadfile_dialog(vp->view->window,"Switch To:", &filename,NEARNULL,0,1,3,TRUE);
#endif
                AfterDialog(vp,TRUE);
                if (ii != 1)
                    break; /* cancelled */
                fileSpecified = 5;
            } else if (modifier == 1) { /* new file */
#ifdef WINPC
				TUTORcopy_fileref((FileRef FAR *) &filename,&ep->filename);
				filename.path[filename.nameInd] = 0;
				strcat(filename.path,"untitled");
				fileSpecified = 7;
#else
                BeforeDialog(vp);
                ii = TUTORsavefile_dialog(vp->view->window,"New file:",&filename,0);
                AfterDialog(vp,TRUE);
                if (!ii)
                    break; /* cancelled */
                fileSpecified = 6;
#endif
            } else if ((modifier == 2) || (modifier == 3) || (modifier == 4)) { /* jumpout, switch, open */

                /* pick up new file name */
                
                if (cev->eDataP == FARNULL)
                    break; /* no file, treat as if cancelled */
                filename = *(FileRef FAR *)cev->eDataP;
                TUTORdealloc(cev->eDataP);
                cev->eDataP = FARNULL;
                
                /* set up run event */
                
                if (modifier == 2) {
                	xev = *cev;
                	xev.type = EVENT_MENU;
                	xev.a1 = edit_run; /* run from beginning */
                	xev.timestamp = 0;
                	runF = TRUE;
                }
            }
                
            /* pass run event to executor (if jumpout), switch */
                
			if (!runF) DebugClearStep(); /* clear step mode if not running */
            if (runF) /* post execute event */
                TUTORpost_event(&xev);

			if (modifier == 4) {
			    CurEditWi = EditOpen((FileRef FAR *)&filename,-1L,-1L);
			} else {
	    		EditSwitchFile(ep,vp,(FileRef FAR *) &filename);
	    	}

	    	if (modifier == 0) { /* swtich-file */

				/* after everything settles down, insure edit */
				/* window forward */

				if (ExecWn >= 0) /* blank out executor window */
					windowsP[ExecWn].winRedraw = TRUE;
				post_toedit();
	    	} /* runF if */

            break;
        
        case edit_open:
            cev->type = -1; /* handled here */
            TUTORcopy_fileref((FileRef FAR *) &filename,&ep->filename);
            TUTORcopy_fileref_dir((FileRef FAR *) currentDirP,(FileRef FAR *)&filename);
    		TUTORset_dir(currentDirP);
            BeforeDialog(vp);
            if (modifier == 1) /* new file */
            	ii = TUTORsavefile_dialog(vp->view->window,"New file:",&filename,0);
            else
            	ii = TUTORreadfile_dialog(vp->view->window,"Open:", &filename,NEARNULL,0,1,3,TRUE);
            AfterDialog(vp,TRUE);
            if (ii != 1)
                break; /* cancelled */
            TUTORwait_cursor();
    		TUTORflush();
            CurEditWi = EditOpen((FileRef FAR *)&filename,-1L,-1L);
            TUTORnormal_cursor();
            break;
            
        case edit_close:
            cev->type = -1; /* handled here */
			SetCurEditWi(); /* make this editor current */
            didDialog = CheckSaves(CurEditWi,FALSE,&jj,vp);
            if (!jj)
                break; /* user cancelled */
			if (!didDialog && (CurEditWi == 0)) {
                BeforeDialog(vp);
                ii = TUTORync_dialog(vp->view->window,"Quit cT?");
                AfterDialog(vp,TRUE);
                if (ii != 0) 
					break; /* Cancel */
			}
            ReleasePtr(ep->textPanel);
            ReleasePtr(editH);
            ep = FARNULL;
            vp = FARNULL;
            EditClose(editH);
            break;
            
        case edit_print: /* 0 for setup, 1 for print */
            cev->type = -1; /* handled here */
            if (modifier == 0)
                TUTORprint_dialog(CurrentWindow,0);
            else {
                /* generate print event - interact loop will */
                /* free up memory */
                xev = *cev; /* set up print event */
                xev.type = EVENT_PRINT;
                xev.value = xev.id = xev.timestamp = 0;
                TUTORpost_event(&xev);
            }
            break;
        
        case edit_quit: /* shutdown */
        	cev->type = -1; /* handled here */
        	jj = CheckAllSaves(vp);
        	if (!jj)
        		break; /* cancelled */
        	ReleasePtr(ep->textPanel);
            ReleasePtr(editH);
            ep = FARNULL;
            vp = FARNULL;
        	for(ii=EDITWINDOWLIMIT-1; ii>=0; ii--) {
        		jj = EditWn[ii];
        		if (jj >= 0) {
        	    	editH = windowsP[jj].wH;
        			EditClose(editH);
        		}
        	} /* for */
           	UpdateWinPrefs(); /* save window positions */
            myexit(); /* quit */
            break;
        
        case edit_prefer:
            BeforeDialog(vp);
            ii = TUTORprefs_dialog(vp->view->window);
            AfterDialog(vp,TRUE);
			TUTORwait_cursor();
           
			TUTORnormal_cursor();
            break;

#ifndef X11
		case edit_about:
			About();
			break;
#else
		case edit_about:
			TMessage(aboutTxt);
			break;
#endif
            
#ifdef CTEDIT
        case edit_linen:
            if (modifier == 0) /* get line number */
                {
                lineN = GetLineNumber(vp->textv);
                sprintf(tempS,"Line number %d\n",lineN);
                TUTORalert(vp->view->window,tempS);
                }
            else if (modifier == 1) /* go to line number */
                {
                tempS[0] = '\0';
                BeforeDialog(vp);
                TUTORedit_dialog(vp->view->window,"Which line?",(char FAR *) tempS,
                        NEARNULL,FARNULL,59);
                AfterDialog(vp,TRUE);
                sscanf(tempS,"%d",&lineN); /* get line number into lineN */
                startSelect = LineToPos(vp->textv,lineN);
                SetSelectPanel(vp,startSelect,0L);
                }
            break;
#endif



/* ------------------------------------ PANEL ----------------------- */

        case edit_clear:
            cev->type = EVENT_KEY; /* convert to backspace key */
            cev->nkeys = 1;
            cev->keys[0] = '\b'; 
            break;

        case edit_cut:
        case edit_copy:
        case edit_paste:
            ii = -1;
            if (item == edit_cut) 
            	ii = KCUT;
            else if (item == edit_copy) 
            	ii = KCOPY;
            else if (item == edit_paste) 
            	ii = KPASTE;
            cev->type = EVENT_FKEY; 
            cev->value = ii;
            break;
        
/* ------------------------------------ AUTHOR ----------------------- */

#ifndef CTEDIT
        case edit_searchu:
            cev->type = -1; /* handled here */
            DoSearchUnit(vp);
            break;
            
        case edit_rununit:
        case edit_run:
        case edit_runfrom:
		case edit_execcur:
		case edit_execfwd:
            cev->type = -1; /* handled here */

			/* clear selection so can use for error / debug */
                
			ep = (EditDat FAR *) GetPtr(editH);
            vp = (TextVDat FAR *) GetPtr(ep->textPanel);     
			ReleasePtr(ep->textPanel);
			ReleasePtr(editH);       
            	
            /* insure all units compiled before execution */
            
            if ((item != edit_execfwd) && (!binaryOnly)) {
                free_snapShot(); /* release current executor snapshot */
                if (TUTORinq_msec_clock() > (ep->checkTime+30000L))
					EditCheckpoint(ep,vp);
                EditCompile(editH,ep,vp,FALSE);
                /* EditCompile unlocks handles, so get pointers back */
                ep = (EditDat FAR *) GetPtr(editH);
                vp = (TextVDat FAR *) GetPtr(ep->textPanel);
                if (!allcompiled) {
                    break; /* exit if can't compile */
                }

                _TUTORset_state_internal_marker(mkall,-1L,-1L,FALSE);
            } /* edit_execfwd if */
 
 			/* see if have enough memory to get started */
 			
 			sii = InitialStack();
 			if (!sii) {
 				editormsg("Not enough memory to run",TRUE);
 				break;
 			}
 
            /* look up file in source table */
            
            sii = -1; /* don't know index yet */
			if (item == edit_run) {
				sii = 0; /* always use main file */
			} else {
            	for(ii=0; ii<sourcemalloc; ii++)
                	if (sourcetable[ii].valid && (sourcetable[ii].doc == vp->textd))
                    	sii = ii; /* set index */
			}
            if (sii < 0) 
                break; /* can't execute */
            
            /* set up event to start executor */
            
            xev.window = ExecWn;
            xev.view = FARNULL;
            xev.type = EVENT_MSG;
	    	xev.timestamp = 100;
            xev.eDataP = FARNULL;
            xev.a1 = edit_toexec;
            xev.a4 = -1; /* no unit number yet */
            if (item == edit_run)
                xev.a2 = exec_run; 
            else if ((item == edit_runfrom) ||
                (item == edit_rununit)) {
                if (item == edit_runfrom)
                    xev.a2 = exec_runfrom;
                else xev.a2 = exec_rununit;
                if (curSelUnit[0] == '\0') {
                    ii = LocateUnit(vp->textd,startSelect);
                    if ((ii == 0) || (ii == sourcetable[sii].ieu)) /* ieu */
                        ii = sourcetable[0].firstunit;
                    if ((ii < 0) || (ii > nunits))
                        ii = EditSelectUnit(ep,vp,startSelect);
                    if (ii < 0)
                        break; /* user cancelled or bad unit name */
                    GetUnitName(ii,(unsigned char *)tempS);
                    strcpyf(curSelUnit,(char FAR *)tempS);
                } else {
                    strcpyf((char FAR *)tempS,curSelUnit);
                    ii = EditSearchUnit(tempS,vp,FALSE,FALSE);
                    if (ii < 0) {
                        ii = EditSelectUnit(ep,vp,startSelect);
                        if (ii < 0)
                            break; /* user cancelled or bad unit name */
                    }
                }
                xev.a4 = ii; /* set unit number */
            } else if (item == edit_execcur) {
                ii = LocateUnit(vp->textd,startSelect);
                if ((ii == 0) || (sourcetable[sii].ieu == ii)) /* ieu */
                    ii = sourcetable[0].firstunit;
                if ((ii < 0) || (ii > nunits))
                    ii = EditSelectUnit(ep,vp,startSelect);
                if (ii < 0)
                    break; /* user cancelled or bad unit name */
                xev.a2 = exec_rununit;
                xev.a4 = ii; /* set unit number */
            } else if (item == edit_execfwd) {
                xev.a2 = edit_execfwd;
                xev.a4 = -1; /* no unit */
            } /* item else */

            /* deactivate editor */

			SetCurEditWi(); /* come back to this editor */
			TUTORset_view(vp->view); /* set to editor view */
            TUTORmessage(vp->view,EVENT_VFOCUS,FALSE);

            /* post event to start executor */

            TUTORforward_window(ExecWn); /* generate events for focus first */
            TUTORpost_event(&xev); /* send event to executor */
            break;

        case edit_selunit:
            cev->type = -1; /* handled here */
            EditSelectUnit(ep,vp,startSelect);
            break;
        
        case exec_quit: /* Quit running */
            cev->type = -1; /* handled here */
            /* don't need to do anything.  Processing menu cev will stop execution */
            break;

        case exec_toedit:   /* executor->editor transition */
            cev->type = -1; /* handled here */
            TUTORset_view(vp->view); /* set to editor view */
            TUTORforward_window(vp->view->window);
#ifndef MAC
            TUTORmessage(vp->view,EVENT_VFOCUS,TRUE);
#endif
#ifndef MAC
            TUTORnormal_cursor();
#endif
            break;
        
        case edit_compile:
            cev->type = -1; /* handled here */
            if (ep->savedc != vp->alteredc) {
                BeforeDialog(vp);
                ii = TUTORync_dialog(vp->view->window,"Save changes?");
                AfterDialog(vp,TRUE);
                if (ii == 2) break; /* Cancel */
                if (ii == 0) /* save */
                    if (!EditSave(ep,vp)) break; /* continue on succesful save */
            }
            EditCompile(editH,ep,vp,TRUE);
            /* get pointers back (EditCompile unlocked things) */
            ep = (EditDat FAR *) GetPtr(editH);
	    	vp = (TextVDat FAR *) GetPtr(ep->textPanel);
	    	if (allcompiled && CompileAndExit) {
				PostEditQuit(); /* post quit event */
	    	} else if (CurEditWi >= 0)
	    		TUTORforward_window(EditWn[CurEditWi]); /* focus on editor */
	    	CompileAndExit = 0; /* don't leave dangling */
            break;

        case edit_hideunits: /* hide units */
            cev->type = -1; /* handled here */
            if (cev->a2 == 0) /* hide selected units */
                ii = HideUnits(vp,startSelect,lenSelect,FALSE);
            else /* hide all units */
                ii = HideUnits(vp,startSelect,lenSelect,TRUE);
            if (ii < 0)
                NoUnitsMsg(vp);
            vp->alteredc++;
            break;
            
        case edit_showunits:
            cev->type = -1; /* handled here */
            ii = ShowUnits(vp,startSelect,lenSelect);
            if (ii < 0)
                NoUnitsMsg(vp);
            vp->alteredc++;
            break;
            
        case edit_showall:
            cev->type = -1; /* handled here */
            ShowAllUnits(vp);
            vp->alteredc++;
            break;
            
        case edit_comment: /* comment out source lines */
            cev->type = -1; /* handled here */
            if (vp->readOnly) break; /* exit if read only */
            CommentOut(vp,startSelect,lenSelect);
            vp->alteredc++;
            break;
            
        case edit_uncomment: /* un-comment source lines */
            cev->type = -1; /* handled here */
            if (vp->readOnly) break; /* exit if read only */
            IndentOff(vp,startSelect,lenSelect,'*');
            break;

        case edit_indent: /* indent source lines */
            cev->type = -1; /* handled here */
            if (vp->readOnly) break; /* exit if read only */
            IndentOn(vp,startSelect,lenSelect);
            vp->alteredc++;
            break;
        case edit_unindent: /* un-indent source lines */
            cev->type = -1; /* handled here */
            if (vp->readOnly) break; /* exit if read only */
            IndentOff(vp,startSelect,lenSelect,'\t');
            vp->alteredc++;
            break;
            
        case edit_command: /* open/close commands */
            cev->type = -1; /* handled here */
            if (modifier == 0) {
        		if (!DictVp) initdict();
            	else TUTORforward_window(DictWn);
            } else if (DictVp)
            	TUTORclose_view(DictVp);
            break;

        case edit_help: /* open help window */
            cev->type = -1; /* handled here */
            if (modifier == 0)
                { /* show help */
                openhelp(ep->wid);
                }
            else
                { /* close help */
                if (HelpVp)
                	TUTORclose_view(HelpVp);
                }
            break;
         
		case edit_message: /* show message window */
			cev->type = -1;
			if (MsgWn < 0)
				TMessage("No error(s)"); 
			if (MsgWn >= 0)
				TUTORforward_window(MsgWn);
			break;

        case edit_icon:
        
            /* get icon file and icon number(s) from dialog box */
            
            tempS[0] = tempS[80] = 0; /* pre-clear input */
            BeforeDialog(vp);
            ii = TUTORedit_dialog(vp->view->window,"Enter icon file name:",(char FAR *) tempS,
                        "Enter icon number(s):",(char FAR *)&tempS[80],59);
            AfterDialog(vp,TRUE);
            if ((!ii) || (!tempS[0]))
                break;
            tempS[60] = tempS[80+60] = '\0'; /* insure terminators */
            
            /* allocate handle for icon data */
            
            iconDatL = 1000L; /* more than needed */
            iconDatH = TUTORhandle("icontxt",iconDatL,TRUE);
            if (!iconDatH) {
                editormsg("Not enough memory",TRUE);
                break;
            }
            iconDatP = iconDatB = (int FAR *)GetPtr(iconDatH);
            
            /* parse icon number(s) input */
            
            Nicons = 0;
            nI = 80;
            iconDatP++; /* advance to first icon number */
            do {
                jj = nI; /* index at start of next entry */
                while ((tempS[nI] == ' ') || (tempS[nI] == '\t'))
                    nI++; /* skip leading white space */
                if (!tempS[nI])
                    break; /* end of input */
                ii = nI; /* start of non-blank input */
                while (tempS[nI] && (tempS[nI] != ' ') && (tempS[nI] != '\t') &&
                       (tempS[nI] != ',') && (tempS[nI] != NEWLINE))
                    nI++; /* advance to next separator */
                if (nI == ii) {
                    nI++; /* advance past terminator */
                    continue; /* empty string */
                }
                if (tempS[nI])
                    tempS[nI++] = NEWLINE; /* replace separator with newline */
                Nicons++; /* count number items in input */
                
                /* evaluate numeric value */
                
                floatf = FALSE; intv = -1; /* preset in case of error */
                ii = getnum(&tempS[jj],&floatf,&intv,&floatv,&errp,NEARNULL);
                if (floatf) 
                    iconN = floatv;
                else
                    iconN = intv;
                    
                /* handle error */
                
                if ((ii == FALSE) || (iconN < 0) || (iconN >= 0x10000L)) {
                    ReleasePtr(iconDatH);
                    TUTORfree_handle(iconDatH); /* release mmemory */
                    iconDatH = HNULL;
                    if (ii == FALSE)
                        editormsg(errp,TRUE); /* display error message */
                    else
                        editormsg("Icon number out of range",TRUE);
                    break; /* exit while */
                }       
                *iconDatP++ = iconN; /* set next icon value */
            } while (tempS[nI]);
            
            if (!iconDatH)
                break; /* parse failed, exit case */
                
            *iconDatB = Nicons; /* set number of icons */
            
            /* evaluate font name */
            
            *iconDatP++ = cvt_font_name(tempS); /* convert font name to index */
            strcpyf((char FAR *)iconDatP,(char FAR *)tempS); /* family name */
            
            ReleasePtr(iconDatH);
            TUTORpurge_info(iconDatH,M_WORM,FARNULL,0);
            AllowHandlePurge(iconDatH);
            iconDatL = ((2+Nicons)*sizeof(int))+strlen(tempS)+1;
            TUTORset_hsize(iconDatH,iconDatL,TRUE); /* downsize handle */
            
            /* add icons to text */
            
            if (Nicons == 0) {
                TUTORfree_handle(iconDatH); /* nothing to add */
            } else {
                TUTORadd_inset_doc(vp->textd,startSelect+lenSelect,lenSelect,
                     0L,TUTORget_len_doc(vp->textd),ICONSPECIAL,iconDatH,
                     &extraPos);
            }
            RefreshPanel(vp,startSelect,0L,startSelect,0L,startSelect,
                         startSelect+1L,0L,TRUE,TRUE);
            break;      

		case edit_window:
			if ((modifier < 0) || (modifier >= EDITWINDOWLIMIT))
				break;
			if (EditWn[modifier] < 0)
				break;
			CurEditWi = modifier;
			TUTORforward_window(EditWn[CurEditWi]);
			break;
			
#ifdef WINPC
		case edit_sewind:
			cev->type = -1;
			TUTORsize_exec_window(492,350);
			TUTORforce_redraw(ExecWn);
			break;
#endif

#ifdef MAC
        case edit_sewind:
            cev->type = -1; /* handled here */
            if (modifier == 0)
            	SizeWindow((WindowPtr)windowsP[ExecWn].wp,506,302,FALSE); /* set to SE window size */
			else
				SizeWindow((WindowPtr)windowsP[ExecWn].wp,634,439,FALSE); /* set to MAC-II window size */
            TUTORforce_redraw(ExecWn);
            break;
#endif

		case edit_debug:
			cev->type = -1; /* handled here */
			if (DebugWn >= 0) {
				TUTORforward_window(DebugWn);
			} else {
				DebugOpenWindow();
			}
			break;

#endif /* CTEDIT */

        default:
            break;
        }  /* end of menu switch */
        break;
        
    	case EVENT_KEY:
    	UndoHilite(); /* clean up step, error highlight */
#ifdef MAC_old_fkey
        if (cev->nkeys == 3 && cev->keys[0] == 1 && cev->keys[2] == 5)
            { /* help key */
            openhelp(ep->wid);
            cev->type = -1;
            }
#endif
		break;

	case EVENT_WMKILL:
		cev->type = -1; /* handled here */
        xev = *cev; /* set up event */
        xev.type = EVENT_MENU;
        xev.a1 = edit_close;
        xev.view = FARNULL;
        xev.value = xev.id = xev.timestamp = 0;
        TUTORpost_event(&xev);
		break;
		
    case EVENT_HOT:
        if (cev->a4 > 255)
            cev->eDataP[255] = '\0';
        strcpyf((char FAR *) tempS,cev->eDataP);
        BeforeDialog(vp);
        ii = TUTORedit_dialog(cev->window,"Change hot text:",(char FAR *)tempS,
                                NEARNULL,FARNULL,255);
        AfterDialog(vp,TRUE);
        if (ii)
            { /* change the hot text */
            TUTORchange_hot_text_doc(vp->textd,cev->value,(char FAR *) tempS,
                                    (long) strlen(tempS));
            }
        break;

    case EVENT_FKEY:
    	UndoHilite(); /* clean up step, error highlight */
        if (cev->value == KHELP)
            { /* help key */
            openhelp(ep->wid);
            cev->type = -1;
            }
        break;

    case EVENT_REDRAW:
	if (!windowsP[wid].paletteH) {
	    /* get a palette for this editor */
	    palH = initial_palette();
	    immediatePalette(palH); /* install the palette */
	}
		TUTORclip_window(wid);
        TUTORclear_screen();
        viewp = windowsP[wid].lastView;
        while (viewp) {
            TUTORset_view(viewp);
            (*viewp->vproc) (viewp->vh,cev);
            viewp = viewp->prevView;
        }
        cev->type = -1; /* we handled it already */
        break;

    case EVENT_FWD:
/* #ifdef MAC	*/
        viewp = windowsP[wid].firstView;
        while (viewp) {
            TUTORset_view(viewp);
            (*viewp->vproc) (viewp->vh,cev);
            viewp = viewp->nextView;
        }
/* #endif   */
        SetCurEditWi(); /* set index of current editor */
        ep->needCursor = TRUE;
		cev->type = -1;
        break;

        
    case EVENT_PRINT:
        TUTORwait_cursor();
#ifdef MAC
{       Str255 wStr;
        GetWTitle((WindowPtr)windowsP[vp->view->window].wp,wStr);
        PtoCstr((unsigned char *)wStr);
        strcpy(tempS,(char *)wStr);
}
#else
        tempS[0] = 0;
#endif
        PrintEditDoc(vp,tempS);
        TUTORnormal_cursor();
        break;
        
    case EVENT_TIME:
        switch (cev->value) {

		case time_blink:
			if (ep->needCursor && (CurrentWindow == wid)) {
				TUTORset_cursor(-1,-1); /* unset cursor */
				TUTORnormal_cursor();
				ep->needCursor = FALSE;
			}
			if (TUTORinq_msec_clock() > (ep->checkTime+30000L))
				EditCheckpoint(ep,vp);
			break; /* pass event on to text view */
			
        case time_checkpt:
            EditCheckpoint(ep,vp);
            cev->type = -1;
            break;

#ifndef CTEDIT
        case time_source: /* hilight source line */
		case time_err: /* hilight line containing error */

            /* a1 = TRUE if FindUnits error */
            /* a2 = index in sourcetable */
            /* a4 = selection position */
            /* a5 = selection length */
 
            cev->type = -1;
            internalSelect = TRUE; /* did a selection */

			/* display message if we have one */

			if (cev->eDataP) {
				TMessage((char FAR *)cev->eDataP);
				TUTORdealloc((char FAR *)cev->eDataP);
				cev->eDataP = FARNULL;
			}

            /* shift to editor on this file */

            if ((cev->a2 < 0) || (cev->a2 >= sourcemalloc))
                cev->a2 = 0; /* don't know file */
            ReleasePtr(ep->textPanel);
            ReleasePtr(editH);
			sii = CurEditWi; /* remember current editor */
            CurEditWi = sourcetable[cev->a2].editI; /* index of editor */
            if (CurEditWi < 0) /* open editor on file */
                CurEditWi = EditOpen(&sourcetable[cev->a2].fRef,-1L,0L);     
            if (CurEditWi < 0)
                CurEditWi = 0;  /* fall back to main editor */
            wid = EditWn[CurEditWi];
            editH = windowsP[wid].wH;
            ep = (EditDat FAR *) GetPtr(editH);
            vp = (TextVDat FAR *) GetPtr(ep->textPanel);
			tvp = (TViewP)GetPtr(vp->textv);
			tvp->hiInactive = TRUE;
			ReleasePtr(vp->textv);
            TUTORset_view(vp->view); /* make sure we have the right view */
			if ((sii != CurEditWi) || (!TUTORis_foreground(wid)))
				TUTORforward_window(wid);  /* display new edit window */
            
            /* set selection region on line */
            
            startSelect = cev->a4;
            lenSelect = cev->a5;
            TUTORset_select_tview(vp->textv,startSelect,lenSelect,&sbv);
            /* prevent recurrsive error - only show units */
            /* if not FindUnits error and units set up */
            if ((nunits > 0) && (!cev->a1) && (!vp->readOnly)) {
				jj = vp->alteredc;
                ShowUnits(vp,startSelect,lenSelect);
				vp->alteredc = jj; /* don't count this as a change */
                if (vp->scrollv)
                    TUTORreset_text_sbar(vp->scrollv,&sbv,TRUE);
            }
            if ((MsgWn >= 0) && (cev->value == time_err))
            	TUTORforward_window(MsgWn);
            break;
#endif

        case time_convert: /* source file conversion */
            cev->type = -1; /* handled here */
            BeforeDialog(vp);
            sprintf(tempS,"Convert to $syntaxlevel %d?",CURRENTV-19);
            ii = TUTORync_dialog(vp->view->window,tempS);
            AfterDialog(vp,TRUE);
            if (ii) {
                break; /* No/Cancel */
            }
            EditConvert(); /* do the conversion */      
            vp->alteredc++;
            RestartPanel(vp,0L,TUTORget_len_doc(source),0L,0L);
            break;
            
        } /* end of EVENT_TIME switch */

    } /* end of event switch */
    
    if (vp)
        {
        ReleasePtr(ep->textPanel);
        KillPtr(vp);
        }
    if (ep)
        {
        ReleasePtr(editH);
        KillPtr(ep);
        }

    /* pass on events we didn't handle */
    if (cev->type > 0 && cev->view) {
        TUTORset_view(cev->view);
        (*cev->view->vproc)(cev->view->vh,cev);
    } 
    return(0);
    
} /* procedit */

/* ******************************************************************* */

static int CheckAllSaves(dvP) /* check all files to see if should be saved */
                           /* returns TRUE if process should continue */
                           /*         FALSE if process canceled */
struct  _tvdat FAR *dvP; /* view for dialog box */
                           
{	int editI; /* index of current editor */
	int goOn; /* TRUE if should proceed */
	
	for(editI=EDITWINDOWLIMIT-1; editI>=0; editI--) {
		if (EditWn[editI] >= 0) {
			CheckSaves(editI,TRUE,&goOn,dvP);
			if (!goOn) return(FALSE); /* cancelled */
		}
	}
	return(TRUE);
	
} /* CheckAllSaves */

/* ******************************************************************* */

static CheckSaves(editI,ifAlt,goOn,dvP)
int editI; /* index of editor */
int ifAlt; /* TRUE if binary should be checked only if source altered */
int *goOn; /* set to FALSE if user cancels at some point */
TextVDat FAR *dvP;  /* view for dialog box */

{   int ii, jj, len;
    int binaryf; /* TRUE if should ask to save binary */
    int isok;
	FileRef tmpRef; 
    Memh editH;
    EditDat FAR *ep;
    TextVDat FAR *vp;
    char FAR *fnP; /* pointer to file name */
    int wid;
	int didDialog; /* TRUE if put up a save dialog box */
    char msg[60]; /* dialog message */
    
	didDialog = FALSE; /* no dialog yet */
    if ((editI < 0) || (EditWn[editI] < 0))
        return(didDialog); /* nothing to do */
    
    wid = EditWn[editI];    
    editH = windowsP[wid].wH;
    ep = (EditDat FAR *) GetPtr(editH);
    vp = (TextVDat FAR *) GetPtr(ep->textPanel);
    
    /* check if made changes, and had binary at some point */
    binaryf = (vp->alteredc != 0) && ep->didall; 
    *goOn = FALSE;
    isok = TRUE;
    if (ep->savedc != vp->alteredc) {

		/* locate file name */

		len = strlenf(ep->filename.path);
		fnP = ep->filename.path+len-1;
		while (fnP > &ep->filename.path[0]) {
			if ((*fnP == '/') || (*fnP == '\\')) {
				fnP++;
				break;
			}
			fnP--;
		} /* while */
		if (strlenf(fnP) >= 40)
			fnP = ep->filename.path+len-40;

		/* run dialog */

		didDialog = TRUE;
        BeforeDialog(dvP);
		if ((editI == 0) && (fileSpecified == 7)) {
			ii = TUTORync_dialog(dvP->view->window,
					     "The untitled file has changed.\nDo you want to save your changes?");
			if (ii == 0) { /* save changes */
				/* get name for untitled file */
				tmpRef = ep->filename;
				ii = TUTORsavefile_dialog(dvP->view->window,"Save To:",&tmpRef,0);
				ii = !ii; /* 0 = ok, have name, do save */
				if (ii) ii = 2; /* set as for cancel */
				if (ii == 0) {
					fileSpecified = 6; /* file name from "Save As" dialog */
					ep->filename = tmpRef; /* update file reference */
					isok = EditSave(ep,vp); /* save file */
				} 
			} else if (ii == 1) { /* no, abandon changes */
				ii = 0;
				binaryf = FALSE; /* don't bother with binary */
				isok = TRUE; /* exit happy */
			}
		} else {
			/* ask if want to save file */
			strcpy(msg,"Save changes to ");
			strcatf((char FAR *)msg,fnP);
			strcat(msg,"?");
			ii = TUTORync_dialog(dvP->view->window,msg);
			if (ii == 0) /* save */
				isok = EditSave(ep,vp);
		} /* else */  
        jj = (ii == 2) || (ii == 0 && !isok) || (ii < 0); /* TRUE if we're done */
        AfterDialog(dvP,jj);
        if (jj) {
            ReleasePtr(ep->textPanel);
            KillPtr(vp);
            ReleasePtr(editH);
            KillPtr(ep);
            return(didDialog); /* Cancel or failed save or failed dialog */
        }
        
        if (ii == 1) /* source dialog answered NO - don't bother with binary */ 
            binaryf = FALSE;
    } else { /* source not altered since last save */
        if (ifAlt) binaryf = FALSE; /* don't bother with binary */
    } /* savedc else */

    if (editI) binaryf = FALSE; /* only worry about binary on main window */
    
#ifndef CTEDIT
    if (binaryf && (!binaryFileCurrent || CountNeedsCompiled() > 0)) {
        /* check if user wants to save binary */
        BeforeDialog(dvP);
        ii = TUTORync_dialog(dvP->view->window,"Save binary?");
        if (ii == 0) {
            /* save binary */
            isok = EditCompile(editH,ep,vp,TRUE);
            /* EditCompile unlocked handles, recover them */
            ep = (EditDat FAR *) GetPtr(editH);
            vp = (TextVDat FAR *) GetPtr(ep->textPanel);
        }
        jj = (ii == 2) || (ii == 0 && !isok); /* TRUE if we're done */
        AfterDialog(dvP,jj);
        if (jj) {
            ReleasePtr(ep->textPanel);
            ReleasePtr(editH);
            return(didDialog); /* cancel or failed binary */
        }
    }
#endif

    *goOn = TRUE;
    ReleasePtr(ep->textPanel);
    ReleasePtr(editH);
    return(didDialog);
    
} /* CheckSaves */

/* ******************************************************************* */

ChangeEditMenus(onOff)
int onOff;
    
{
    TUTORmodify_menu(editmenus,NEARNULL,"Execute current unit",onOff,-1,-1);
    TUTORmodify_menu(editmenus,NEARNULL,"Execute selected unit",onOff,-1,-1);

#ifndef ANDREW
    TUTORmodify_menu(editmenus,NEARNULL,"Run from beginning",onOff,-1,-1);
    TUTORmodify_menu(editmenus,NEARNULL,"Select unit",onOff,-1,-1);
    TUTORmodify_menu(editmenus,NEARNULL,"Run from selected unit",onOff,-1,-1);
#ifdef WINPC
    if (onOff)
	TUTORdelete_menu(editmenus,"Option","Quit running");
    else
	TUTORadd_menu(editmenus,"Option",50,"Quit running",10,0,exec_quit,3,0.0,EVENT_MENU);
#else
    TUTORmodify_menu(editmenus,NEARNULL,"Quit running",!onOff,-1,-1);  
#endif
#else
    if (isx11) {
        TUTORmodify_menu(editmenus,NEARNULL,"Run from beginning",onOff,-1,-1);
        TUTORmodify_menu(editmenus,NEARNULL,"Select unit",onOff,-1,-1);
        TUTORmodify_menu(editmenus,NEARNULL,"Run from selected unit",onOff,-1,-1);
	TUTORmodify_menu(editmenus,NEARNULL,"Quit running",!onOff,-1,-1);
    }
#endif

} /* ChangeEditMenus */
    
/* ******************************************************************* */


#ifdef CTEDIT
static GetLineNumber(theV)
Memh theV;
    {
    TViewP tvp;
    DocP dp;
    int retVal;
    TextBlock FAR *curBlock;
    long pOff, eOff;
    unsigned char FAR *tp;
    long nLeft;

    /* we want to count the # of NEWLINES that preceed our position */
        /* relative to the start of the view... */

    tvp = (TViewP) GetPtr(theV);
    if (tvp->selA.pos == tvp->bounds.pos)
        { /* at beginning */
        ReleasePtr(theV);
        KillPtr(tvp);
        return(1);
        }

    dp = (DocP) GetPtr(tvp->doc);

    if (dp->shortText)
        {
        retVal = TUTORcount_bytes(dp->text+tvp->bounds.pos,
                dp->text + tvp->selA.pos-1,NEWLINE);
        }
    else
        { /* text in blocks, count newlines in preceeding blocks, etc. */
        retVal = 0;
        nLeft = tvp->selA.pos - tvp->bounds.pos;
        curBlock = FindTBlock(dp,tvp->bounds.pos,&pOff,&eOff);
        while (nLeft > 0)
            {
            tp = (unsigned char FAR *) GetPtr(curBlock->text);
            eOff = (eOff <= nLeft) ? eOff : nLeft;
            retVal += TUTORcount_bytes(tp+pOff,tp+(eOff-1),NEWLINE);
            ReleasePtr(curBlock->text);
            KillPtr(tp);
            nLeft -= eOff;
            if (nLeft > 0)
                { /* get another block */
                curBlock++;
                eOff = curBlock->tLen;
                }
            }
        }

    ReleasePtr(tvp->doc);
    KillPtr(dp);
    ReleasePtr(theV);
    KillPtr(tvp);

    return(retVal+1);
    }

static long LineToPos(theV,lineN)
Memh theV;
int lineN;
    {
    TViewP tvp;
    DocP dp;
    long curPos, viewEnd;

    tvp = (TViewP) GetPtr(theV);
    curPos = tvp->bounds.pos;
    viewEnd = tvp->bounds.pos + tvp->bounds.len;

    dp = (DocP) GetPtr(tvp->doc);
    lineN--;  /* because line 1 is after 0 newlines */
    while (lineN > 0)
        {
        /* find next newline */
        curPos = TUTORsearch_string_doc(dp,(unsigned char FAR *) NEWLINES,1L,curPos,viewEnd);
        if (curPos < 0)
            { /* couldn't find another newline, go to end of view */
            curPos = viewEnd;
            break;
            }
        lineN--;
        curPos++; /* get past newline */
        }

    ReleasePtr(tvp->doc);
    KillPtr(dp);
    ReleasePtr(theV);
    KillPtr(tvp);
    return(curPos);
    }
#endif

static EditSaveas(ep,vp,filename,type)
EditDat FAR *ep;    /* pointer to editable text info */
TextVDat FAR *vp;
FileRef FAR *filename; /* filename to save to */
int type; /* 0: normal, 1: be2 datastream */
    {
    int ii, ok;
    int fileInd;
    char mstr[FILEL*2]; /* message line string */
    struct stat fst; /* file status block */
	Memh dummyH;
	int txtErrN; /* current internal text-memory errors */
    
    TUTORwait_cursor();
    TUTORflush();

	ok = TRUE;
	txtErrN = TxtMemErr;	
	fileSpecified = 6;
    if (type == 1)
        { /* save copy with old format */
        fileInd = TUTORopen(filename,FALSE,TRUE,FALSE);
        if (fileInd)
            ok = TUTORfwrite_be2_doc(0, vp->textd,0L,TUTORget_len_doc(vp->textd),fileInd,
                                FARNULL,NEARNULL);
        else
            ok = FALSE;
        if (txtErrN != TxtMemErr)
        	ok = FALSE;
        TUTORclose(fileInd);
        }
    else
        { 
        if (CheckEditOnFile(filename,&dummyH,CurEditWi) >= 0) {
        	TUTORalert(vp->view->window,"Already editing file");
        	ok = FALSE;
        }
        if (ok) {
        	EditWinMenu(CurEditWi,FALSE); /* remove menu item */
        	/* save as file name given & switch to it */
        	ok = writedoc(vp->textd,filename,1);
        	if (txtErrN != TxtMemErr)
        		ok = FALSE;
        }
        if (ok)
            {
            ep->savedc = ep->checkptc = vp->alteredc;
            TUTORcopy_fileref(&ep->filename,filename);
            TUTORget_fileref_name(&ep->filename,(char FAR *) mstr);
            if (CurEditWi == 0) {
            	settitles(mstr);
                TUTORstat(&sourcetable[0].fRef,&fst);
                sourcetable[0].mtime = fst.st_mtime;
                setmainfile(filename);
            } else {
            	mstr[0] = '(';
    			TUTORget_fileref_name(&ep->filename,(char FAR *)&mstr[1]);
    			strcat(mstr,")");
    			TUTORset_window_title(vp->view->window,mstr); 
            }
            EditWinMenu(CurEditWi,TRUE); /* add menu item */
            /* switch to new file */
            vp->readOnly = FALSE; /* no longer read-only */
            binaryFileCurrent = FALSE; /* since old file has wrong name */
            }
        }
    
    if (!ok)
        {
        strcpy(mstr,"Error: File ");
        TUTORget_fileref_name(filename,(char FAR *) (mstr+strlen(mstr)));
        strcat(mstr," NOT saved!");
        editormsg(mstr,TRUE);
        }
    TUTORnormal_cursor();

    } /* EditSaveas */

static EditSave(ep,vp)
EditDat FAR *ep;    /* pointer to editable text info */
TextVDat FAR *vp;
/* returns flag indicating success */
    {
    int ii;
    FileRef filename;
    int txtMemN; 
#ifndef CTEDIT
    struct stat fst; /* file status block */
#endif
    
    TUTORwait_cursor();
    TUTORflush();
    
    ii = writedoc(vp->textd,&ep->filename,1);
    if (ii) {
        ep->savedc = ep->checkptc = vp->alteredc;
#ifndef CTEDIT
        TUTORstat(&sourcetable[0].fRef,&fst);
        sourcetable[0].mtime = fst.st_mtime;
#endif
        if (ep->chkpf) {
            assoc_name(&ep->filename,(FileRef FAR *) &filename,".CKP");
            TUTORdelete_file((FileRef FAR *) &filename); /* remove the .CKP file */
            ep->chkpf = FALSE;
        }
    } else
        editormsg("Error: File NOT saved!!",TRUE);
    TUTORnormal_cursor();
    
    return(ii);
    }

/* ******************************************************************* */
    
int EditForward() /* bring editor forward */

{
   	if (CurEditWi < 0)
		SetCurEditWi(); /* determine current editor */           
	TUTORforward_window(EditWn[CurEditWi]); /* focus on editor */  

} /* EditForward */

/* ******************************************************************* */

int EditNewPrefs(wix) /* force edit window to redraw */
int wix; /* index of window */
		
{	EditDat FAR *ep; /* pointer to editor info */
	TextVDat FAR *vp; /* pointer to text panel info */
	TViewP tvp; /* pointer to text view */
	Memh tempH;
	long txtlen;

	if (wix < 0) return(0);
	
    tempH = windowsP[wix].wH;
	windowsP[wix].winRedraw = TRUE;
    ep = (EditDat FAR *) GetPtr(tempH);
    vp = (TextVDat FAR *) GetPtr(ep->textPanel);
    TUTORset_view(EditVp[wix]); /* set to editor main view */
	fgndColor.palette = bgndColor.palette = winColor.palette = -4;
    CTset_foreground_color(prfP->fcolor);
    CTset_background_color(prfP->bcolor);
    CTset_window_color(prfP->bcolor);
	CurrentView->fgndColor = fgndColor;
	CurrentView->bgndColor = bgndColor;
	CurrentView->winColor = winColor;
	TUTORclip_window(wix);
	vp->ecolor = winColor; /* set erase color */
    TUTORclear_screen();
	TUTORset_view(vp->view);
    EditorDefaultStyles(vp->textd);
    TUTORget_default_styles_doc(vp->textd,(short FAR *) vp->defStyles); /* update panel */
	fgndColor.palette = bgndColor.palette = winColor.palette = -4;
    CTset_foreground_color(prfP->fcolor);
    CTset_background_color(prfP->bcolor);
    CTset_window_color(prfP->bcolor);
	CurrentView->fgndColor = fgndColor;
	CurrentView->bgndColor = bgndColor;
	CurrentView->winColor = winColor;
	tvp = (TViewP)GetPtr(vp->textv);
	tvp->wrap = prfP->wordWrap;
	ReleasePtr(vp->textv);
    txtlen = TUTORget_len_doc(vp->textd);
    RestartPanel(vp,0L,txtlen,0L,0L);					
	ReleasePtr(ep->textPanel);
	ReleasePtr(tempH);
	TUTORset_view(EditVp[wix]); /* flush view */

	return(0);

} /* EditNewPrefs */

/* ******************************************************************* */

static EditSwitchFile(ep,vp,newFile) /* switch to specified file */
EditDat FAR *ep;    /* pointer to editable text info */
TextVDat FAR *vp;
FileRef FAR *newFile;
    
{   int ii, jj,cc;
    char tempS[FILEL+1];
    char *pmsg; /* parse_env return */
    long txtlen;
    FileRef srcFile; /* source file name/info */
#ifndef CTEDIT
    int cwX,cwY; /* current (desired) executor window size */
    int drm;    /* document read-only mode */
    struct tutorevent event; /* switch/convert event for executor */
    struct markvar mtemp;
#endif
    
    TUTORwait_cursor();
    TUTORflush();
     
    EditWinMenu(0,FALSE); /* remove menu item */

#ifndef CTEDIT
    cwX = ExecWinX; /* current (desired) window size */
    cwY = ExecWinY;
    exec_switch_fixup(); /* make executor fix up its act */

    /* dump source document(s) and associated markers */

    gvarzero = TRUE; /* zero global vars on execute */
    clearsrc(FALSE); /* forget about previous file */
#else
    TUTORclose_all_markers(vp->textd);
#endif
    if (vp->textd)
        TUTORclose_doc(vp->textd); /* close old document */
    
    vp->textd = TUTORnew_doc(FALSE,TRUE);
    EditorDefaultStyles(vp->textd);
#ifndef CTEDIT
    source = defexp.srcH = sourcetable[0].doc = vp->textd;
    if (textpool) { /* get rid of existing text/string literals */
        TUTORclose_doc(textpool); /* dump document */
        textpool = TUTORnew_doc(TRUE,FALSE); /* text/string literals */
        defexp.text = textpool;
    }
#endif

    /* read new source file */
    
    TUTORcopy_fileref((FileRef FAR *)&srcFile,newFile);
    ii = strlen(srcFile.path);
    if ((ii > 4) && (strcmp(&srcFile.path[ii-4],".ctb") == 0)) {
    
        /* change binary file name to source file name */
        
        ii -= 4; /* index of period */
#ifndef MAC
        jj = ii-1;
        while (jj) {
            cc = srcFile.path[jj];
            if (cc == '.') {
                ii = jj; /* back up to first period */
                break;
            } else if ((cc == ':') || (cc == '/') || (cc == '\\'))
                break; /* no other component of name to remove */
            jj--;
        } /* while */
#endif
        srcFile.path[ii] = 0;
        strcat(srcFile.path,".t");
    }
    
    TUTORcopy_fileref_dir((FileRef FAR *) currentDirP,(FileRef FAR *)&srcFile);
    TUTORset_dir(currentDirP);
    ii = readdoc(vp->textd,(FileRef FAR *)&srcFile,&jj);
    TUTORcopy_fileref(&ep->filename,(FileRef FAR *)&srcFile);

#ifndef CTEDIT
    mtemp.doc = vp->textd;
    mtemp.pos = 0L;
    mtemp.len = TUTORget_len_doc(vp->textd);
    mtemp.alteredF = 0x10; /* sticky */
    mkall = _TUTORinternal_marker((struct markvar SHUGE *) &mtemp,HNULL,0L);
    
    newsrfile = FALSE; /* pre-set not new file */
    if ((ii == FALSE) || (TUTORget_len_doc(vp->textd) <= 0)) {
        InsertString(vp->textd,0L,(char FAR *) NEWLINES,1L);
        newsrfile = TRUE;
    }

    /* insure $version statement present */
    if (newsrfile){
        insertversion();
    }
#endif
    curSelUnit[0] = '\0'; /* no unit selected */
    curSelEdit = 0;
    ep->savedc = ep->compilc = ep->checkptc = vp->alteredc;
    ep->chkpf = ep->didall = FALSE;
    ep->needCursor = TRUE;
    pictur_id = 0; /* re-set unique id for picture */
    
#ifndef CTEDIT
    setmainfile((FileRef FAR *)&srcFile);
#endif
    TMessage(FARNULL); /* clear old error message */
    TUTORget_fileref_name((FileRef FAR *)&srcFile,(char FAR *) tempS);
    settitles(tempS);
    sourcetable[0].editI = 0; /* set index of editor on main file */

#ifndef CTEDIT
    /* read binary file if possible */

    if (!newsrfile) {
        if (!readbinary(newFile,TRUE)) {
            nunits = -1; /* force setup */
        } /* readbinary if */
		_TUTORinq_state_internal_marker(mkall,NEARNULL,NEARNULL,&ii);
		if (ii)
			vp->alteredc++;
	} /* newsrfile if */
          
    /* put selection at end of $syntaxlevel statement */

    ii = 0;
    if (TUTORcharat_doc(vp->textd,0L) == '$') 
        while (TUTORcharat_doc(vp->textd,(long) ii) != NEWLINE)
            ii++;
#endif

    /* check if need conversion */
    
#ifdef CTEDIT
    pmsg = NULL;
    ii = 0;
#else
    pmsg = parse_env();
    
    /* re-size executor window if neccessary */

    if ((cwX != ExecWinX) || (cwY != ExecWinY)) {
        TUTORsize_exec_window(ExecWinX,ExecWinY);
    }

    /* send convert message to editor window if neccessary */
    
    if ((pmsg == NULL) && (ctutv != CURRENTV)) { 
        event.window = EditWn[0];
        event.view = FARNULL; /* message sent to window */
        event.type = EVENT_TIME;
        event.value = time_convert;
        event.timestamp = 0;
        event.eDataP = FARNULL;
        TUTORpost_event(&event);
    }

    /* send switch event to executor window */

    if (ExecWn >= 0) {
        event.type = EVENT_MSG;
        event.window = ExecWn;
        event.value = event.id = event.timestamp = 0;
        event.view = FARNULL;
        event.a1 = exec_switch;
        event.eDataP = FARNULL;
        TUTORpost_event(&event);
    } /* ExecWn if */
#endif

    /* set display for new file */

    txtlen = TUTORget_len_doc(vp->textd);
    RestartPanel(vp,0L,txtlen,(long)ii,0L);
    EditWinMenu(0,TRUE); /* add window menu item */
     
    TUTORflush();
    TUTORnormal_cursor();
    return(0);

} /* EditSwitchFile */

/* ******************************************************************* */

static int EditOpen(fRef,sPos,sLen) /* open (or locate) editor on specified file */
FileRef FAR *fRef; /* file to edit */
long sPos; /* selection position */
long sLen; /* selection length */

{   Memh docH; /* handle on document containing file contents */
    struct sourcefile FAR *srcP; /* pointer in sourcetable */
    struct sourcefile FAR *foundsP; /* pointer to entry found in sourcetable */
    int cmpF;
    int sii; /* scratch index */
    int writeAble;
    Memh editorH;   /* handle on new editors data */
    int editorI;    /* index of editor in EditWn[] */
    EditDat FAR *ep; /* pointer to new editors data */
    TextVDat FAR *vp; /* pointer to text panel */
    int wid; /* index of new window */
    int wrap; /* TRUE if lines should wrap */
    int minWidth; /* minimum layout width */
    int corner; /* TRUE if need mac-style resize box */
    int info; /* edit rectangle info */
    struct tutorview FAR *cv; /* pointer to current view */
    char tempS[FILEL+2]; /* file name string */
    struct tutorevent edevent; /* initial checkpoint event */
    long docL; /* length of document */
    
    docH = HNULL; /* dont know document yet */
    foundsP = FARNULL; /* dont know sourcetable entry yet */
    if (sLen < 0) 
    	sPos = -1; /* no selection */
    
    /* check if already an editor on this file */
    
    editorI = CheckEditOnFile(fRef,&docH,-1);
    if (editorI >= 0) {
        wid = EditWn[editorI]; /* index of window */
        TUTORforward_window(wid); /* bring editor window forward */
        if (sPos >= 0) {
            editorH = windowsP[wid].wH; /* handle on edit data */
            ep = (EditDat FAR *) GetPtr(editorH);
            vp = (TextVDat FAR *) GetPtr(ep->textPanel);
            SetSelectPanel(vp,sPos,sLen);
            ReleasePtr(ep->textPanel);
            KillPtr(vp);
            ReleasePtr(editorH);
            KillPtr(ep);
        }
        return(editorI); /* return index of editor */
    }
    
    /* check if file is main source or use file */
    
    if (!docH) {
        srcP = sourcetable; /* pointer in source file table */
        for(sii=0; sii<sourcemalloc; sii++) {
            if (srcP->valid) { /* only look at valid files */
                cmpF = TUTORcmp_fileref(fRef,&srcP->fRef); /* check for match */
                if (cmpF == 0) { /* found a match */
                    foundsP = srcP;
                    docH = srcP->doc; /* get handle on source document */
                    break; /* exit for */
                } /* cmpF if */
            } /* valid if */
            srcP++;
        } /* for */
    }
    
    /* open new file */
    
    if (!docH) {
        docH = TUTORnew_doc(FALSE,TRUE);
        if (!docH)
            return(-1); /* can't do it */
        EditorDefaultStyles(docH);
        sii = readdoc(docH,fRef,&writeAble);
    }
        
    /* change current working directory */
    
    TUTORcopy_fileref_dir((FileRef FAR *) currentDirP,(FileRef FAR *)&fRef);
    TUTORset_dir(currentDirP);
    
    /* create and connect window+editor data */
    
    editorI = -1; /* don't know index yet */
    for(sii=0; sii<EDITWINDOWLIMIT; sii++) {
        if (EditWn[sii] < 0) {
            editorI = sii; /* found a slot */
            break;
        }
    } /* for */
    if (editorI < 0) return(-1); /* too many edit windows */
    if (foundsP)
        foundsP->editI = editorI; /* connect editor to sourcetable */
    wid = TUTORcreate_window(-1,-1,0,0,EDITW);
    if (wid < 0) return(-1); /* cant create window */
    editorH = TUTORhandle("edittxt",(long) sizeof(EditDat),TRUE);
    if (!editorH) return(-1); /* cant create panel */
    EditWn[editorI] = wid;
    windowsP[wid].wproc = proceditstub;
    windowsP[wid].wH = editorH;
    ep = (EditDat FAR *) GetPtr(editorH);
    ep->wid = wid;
    ep->needCursor = TRUE;
    
    /* create text panel */
    
    info = LEFTSTICK | TOPSTICK | RIGHTSTICK | BOTTOMSTICK;
    TUTORblock_move((char FAR *)fRef,(char FAR *)&ep->filename,(long)sizeof(FileRef));
#ifdef MAC
    corner = TRUE;
#else
    corner = FALSE;
#endif

#ifdef CTEDIT
    wrap = FALSE;
    minWidth = 0;
#else
    wrap = prfP->wordWrap;
    minWidth = 0;
#endif

    ep->textPanel = MakeTextPanel(wid,(long) wid,0,0,NEARNULL,info,minWidth,wrap,
                docH, 0L,-1L,TRUE,TRUE, FARNULL,FALSE,corner,FALSE,FALSE,-1,-1,-1,FALSE,0);
             
    vp = (TextVDat FAR *) GetPtr(ep->textPanel);      
#ifndef MAC
    TUTORmessage(vp->view,EVENT_VFOCUS,TRUE); /* activate view */
#endif 
    ep->savedc = ep->compilc = ep->checkptc = vp->alteredc;
    ep->chkpf = ep->didall = FALSE;
    tempS[0] = '(';
    TUTORget_fileref_name(&ep->filename,(char FAR *)&tempS[1]);
    strcat(tempS,")");
    TUTORset_window_title(vp->view->window,tempS);

    /* set up window */
    
    cv = TUTORinq_view();
    EditVp[editorI] = vp->view;
    ep->view = vp->view;
    TUTORset_view(vp->view); /* set to text view */
    TUTORset_key_focus(vp->view->window,vp->view,FALSE);
    TUTORset_event_mask(EVENT_KEY,TRUE);
    TUTORset_event_mask(EVENT_FKEY,TRUE);
    TUTORset_event_mask(EVENT_MENU,TRUE);
    TUTORset_event_mask(EVENT_MSG,TRUE);
    TUTORset_event_mask(EVENT_LEFTDOWN,TRUE);
    TUTORset_event_mask(EVENT_RIGHTDOWN,TRUE);
    TUTORset_event_mask(EVENT_LEFTUP,TRUE);
    TUTORset_event_mask(EVENT_RIGHTUP,TRUE);
    TUTORset_event_mask(EVENT_DOWNMOVE,TRUE);
    TUTORset_event_mask(EVENT_PASTE,TRUE);
    TUTORset_event_mask(EVENT_FWD,TRUE);
    TUTORset_event_mask(EVENT_WFOCUS,TRUE);
    TUTORset_event_mask(EVENT_SCROLL,TRUE);
    TUTORset_event_mask(EVENT_HOT,TRUE);
    TUTORset_event_mask(EVENT_VFOCUS,TRUE);
    TUTORset_event_mask(EVENT_PRINT,TRUE);

    /* attach editor menus to this window */
    
    TUTORset_menubar(editmenus,vp->view);
#ifdef MAC
    vp->styleMenu = editmenus;
#endif

    /* check selection reasonable */
    
    docL = TUTORget_len_doc(vp->textd);
    if (sPos >= 0) {
        if ((sPos+sLen) > docL)
            sPos = -1;
    }
    
    /* if no selection put selection at end of $syntaxlevel statement */
    
    if (sPos < 0) {
        sii = 0;
        if (TUTORcharat_doc(vp->textd,0L) == '$') 
            while ((sii < docL) && (sii < 0x7fffL) &&
                  (TUTORcharat_doc(vp->textd,(long) sii) != NEWLINE))
                sii++;
        if (sii >= 0x7FFFL) sii = 0;
        sPos = sii;
        sLen = 0;
    }
    SetSelectPanel(vp,sPos,sLen);
    
    /* set up 1st checkpoint event */
    
    edevent.type = EVENT_TIME;
    edevent.window = wid; /* edit window */
    edevent.view = FARNULL; /* goes to window */
    edevent.value = time_checkpt; /* checkpoint */
    edevent.timestamp = (long)prfP->checkTime * 1000L; /* n seconds from now */ 
    edevent.eDataP = FARNULL;
    ep->checkTime = TUTORinq_msec_clock()+edevent.timestamp;
    TUTORpost_event(&edevent);

    ReleasePtr(ep->textPanel);
    ReleasePtr(editorH);
    TUTORset_view(cv);


	EditWinMenu(editorI,TRUE); /* add window menu item */
	
    return(editorI);
        
} /* EditOpen */

/* ******************************************************************* */

static int EditClose(editH) /* close editor window */
Memh editH; /* handle on edit data */

{   struct  _edat FAR *ep;
    struct tutorevent cev;
    int tii;
    int wix; /* index of editor window */
    int eix; /* index of editor */
    Memh textPanel; /* handle on underlying text panel */

    ep = (EditDat FAR *) GetPtr(editH);
    wix = ep->wid; /* get index of window */
    textPanel = ep->textPanel;
    ReleasePtr(editH);
    KillPtr(ep);
    
    /* figure out which editor this is */
    
    eix = -1; /* don't know which editor yet */
    for(tii=0; tii<EDITWINDOWLIMIT; tii++) {
        if (wix == EditWn[tii]) {
            eix = tii;
            break; /* found the window */
        }
    } /* for */
    if (eix < 0)
        return(0); /* nothing to do */
    
    EditWinMenu(eix,FALSE); /* remove window menu item */
    
    if (eix == 0) { /* close on main edit window */
    
        /* post quit event to main edit window */
        /* event may never be processed if myexit() called */
        /* directly in edit_quit */
        TUTORzero((char FAR *)&cev,(long)sizeof(struct tutorevent));
        cev.window = EditWn[0];
        cev.view = EditVp[0];
        cev.type = EVENT_MENU;
        cev.a1 = edit_quit;
        cev.timestamp = 0;
        TUTORpost_event(&cev);
        return(0);
    }
    
    /* disconnect from sourcetable */
    
    for(tii=0; tii<sourcemalloc; tii++)
        if (sourcetable[tii].editI == eix)
            sourcetable[tii].editI = -1;
            
    /* close secondary edit window */
        
    TUTORclose_panel(textPanel);
    TUTORset_view(EditVp[0]); /* set to main edit window */
    CurEditWi = 0;
    TUTORclose_window(wix);
    TUTORfree_handle(editH); /* release editor data */
    EditWn[eix] = -1;
    EditVp[eix] = FARNULL;
    TUTORforward_window(EditWn[0]); /* focus on main edit window */
    
    return(0);
    
} /* EditClose */

/* ******************************************************************* */

int EditWinMenu(eIndex,addF) /* add/delete Window menu entry */
int eIndex; /* index of editor */
int addF; /* TRUE if adding, false if deleting */

{	int wid; /* index of window */
	Memh editorH; /* handle on editor data */
	EditDat FAR *ep; /* pointer to editors data */
	int fnL; /* length of file name */
	char FAR *fnP; /* pointer in file name */
	int cii; /* index in characters */
	char fileN[32]; /* file name */
	
	if (eIndex < 0)
		return(0);
		
	/* look up editor data, extract file name */
	
	wid = EditWn[eIndex];
	if (wid < 0) return(0);
	editorH = windowsP[wid].wH; /* handle on edit data */
    ep = (EditDat FAR *) GetPtr(editorH);
    fnL = strlenf(ep->filename.path);
	fileN[0] = 0; /* no file name yet */
   	if (fnL < 30) {
   		strcpyf((char FAR *)fileN,ep->filename.path); /* use whole name */
   	} else if (fnL > 0) {
   		fnP = ep->filename.path+fnL-1;
   		cii = 0;
   		while ((fnL > cii) && (cii < 30)) {
   			if ((*fnP == '/') || (*fnP == ':') || (*fnP == '\\')) {
   				fnP++; /* leave pointer past terminator */
   				break; /* exit while */
   			}
   			cii++; /* characters processed */
   			fnP--; /* back up to next character */
   		} /* while */
   		strcpyf((char FAR *)fileN,fnP); /* copy file name */
   	}
    ReleasePtr(editorH);
	
	if (!fileN[0])
		return(0);
		
	/* add or delete menu item */
	
	if (addF) 
	    TUTORadd_menu(editmenus,"Window",80,fileN,1,0,edit_window,eIndex,0.0,EVENT_MENU);
	else
		TUTORdelete_menu(editmenus,"Window",fileN);
	return(0);
	
} /* EditWinMenu */

/* ******************************************************************* */

int CheckEditOnFile(fRef,docHP,Exclude) /* check for editor on specified file */
FileRef FAR *fRef; /* file to edit */
Memh *docHP; /* set to handle on document */
int Exclude; /* -1 or index of editor to exclude from search */

{   int eii; /* index in editors */
    Memh editH; /* handle on edit data */
    struct  _edat FAR *ep; /* pointer to edit data */
    struct  _tvdat FAR *vp; /* pointer to textpanel data */
    int cmpF; /* result of fRef compare */
    
    for(eii=0; eii<EDITWINDOWLIMIT; eii++) {
        if ((EditWn[eii] >= 0) && (eii != Exclude)) { /* found an editor window */
            editH = windowsP[EditWn[eii]].wH;
            if (editH) {
                ep = (EditDat FAR *) GetPtr(editH);
                cmpF = TUTORcmp_fileref(fRef,&ep->filename); /* check for match */
                vp = (TextVDat FAR *) GetPtr(ep->textPanel);   
                *docHP = vp->textd; /* set handle on document */
                ReleasePtr(ep->textPanel);   
                ReleasePtr(editH);
                if (cmpF == 0)  /* found a match */
                    return(eii);
            } /* editH if */
        }
    } /* for */
    *docHP = HNULL; /* no document */
    return(-1); /* didn't find */
    
} /* CheckEditOnFile */

/* ******************************************************************* */

EditCheckpoint(ep,vp)
EditDat FAR *ep;    /* pointer to editable text info */
TextVDat FAR *vp; /* pointer to text panel data */
    {
    FileRef filename;   /* source file name */
    int ii;
    int chkf;   /* checkpoint/compile error flag */
	struct tutorevent event; /* event to process */
	long nextTime; /* time for next checkpoint */   
	struct tutorevent FAR *timeQ; 
	
    /* set up next checkpoint event */
   
    TUTORzero((char FAR *)&event,(long)sizeof(struct tutorevent));
    event.type = EVENT_TIME;
    event.window = ep->wid; /* edit window */
    event.view = FARNULL; /* goes to window */
    event.value = time_checkpt; /* checkpoint */
    event.timestamp = (long)prfP->checkTime*1000L; /*	n seconds from now */

    if (ExecWn >= 0) {
    	if (runflag != halt)
        	event.timestamp = 1L * 60L * 1000L; /* check again in 1 minute */
    }
    timeQ = (struct tutorevent FAR *) GetPtr(timeque);
    for(ii = 0; ii < ntiming; ii++, timeQ++) {
        if ((timeQ->type == EVENT_TIME) && (timeQ->window == ep->wid) &&
           (timeQ->value == time_checkpt)) {
            timeQ->type = -1; /* kill duplicate event(s) */
        }
    }
    ReleasePtr(timeque);
    nextTime = TUTORinq_msec_clock()+event.timestamp;
    TUTORpost_event(&event);

#ifndef CTEDIT
    if (runflag != halt) return(0); /* exit if executing */
#endif

	ep->checkTime = nextTime; /* reset backup timer */
	
   /* check if actually need to do checkpoint */
   
    if (vp->readOnly || (ep->checkptc == vp->alteredc))
        return(0); /* exit if read only, or no recent change */	
        
    /* write document to .CKP file */
    
    TUTORwait_cursor();
    TUTORflush();
    assoc_name(&ep->filename,(FileRef FAR *) &filename,".CKP");
    chkf = writedoc(vp->textd,(FileRef FAR *) &filename,0);
    if (chkf) ep->checkptc = vp->alteredc;
    ep->chkpf = TRUE;
    TUTORnormal_cursor();

    /* issue advisory message */
    if (!chkf)
        editormsg("Error: checkpoint failed!",TRUE);

    return(0);
    }

editormsg(ss,aFlag)
char *ss; /* the message */
int aFlag; /* TRUE if want to post alert (we don't do anything otherwise) */
    {
    int wid;
    EditDat FAR *ep;
    TextVDat FAR *vp;
    
    if (aFlag)
        {
        ep = (EditDat FAR *) GetPtr(ed1H);
        vp = (TextVDat FAR *) GetPtr(ep->textPanel);
        wid = vp->view->window;
        ReleasePtr(ep->textPanel);
        KillPtr(vp);
        ReleasePtr(ed1H);
        KillPtr(ep);
        TUTORalert(wid,ss);
        }
    
    return(0);
    }

#ifndef CTEDIT

static DoSearchUnit(vp)
TextVDat FAR *vp;
    {
    char tempS[256];
    int ii;
    
	TMessage(FARNULL); /* clear error message */
    TUTORarrow_cursor(TRUE);
    
    /* run dialog */
    tempS[0] = '\0';
    BeforeDialog(vp);
    ii = TUTORedit_dialog(vp->view->window,"Find unit:",(char FAR *) tempS,NEARNULL,FARNULL,256);
    AfterDialog(vp,TRUE);
    if (ii)
        {
        if ((ii = EditSearchUnit(tempS,vp,TRUE,TRUE)) < 0)
            {
                if (ii == -2) {
                    NoUnitsMsg(vp);
                    return(0);
                }
#ifdef MAC
            SysBeep(6);
#else
            /* FindUnits ok, but didnt find */
            TUTORalert(vp->view->window,"Couldn't find unit");
#endif
            }
        }
    
    return(0);
    }

/* ******************************************************************* */

static EditSearchUnit(unitName,vp,select,dopartial)
char *unitName; /* unit name (string long enough to be used as scratch!!) */
TextVDat FAR *vp;
int select; /* TRUE if should move selection to unit */
int dopartial; /* TRUE if should accept partial match on unit name */
/* returns unit number if found, -1 if not, -2 if not compilable */

{   int ii, unum;
    long pos;
    struct unitnames FAR *np;
    int partials;
    char tempS[FILEL+18];
    Memh docH; /* handle on text document */
    int srcI,srcJ; /* indexes in source table */
    
    if (unitName[0] == '\0')
        return(-1);
    TUTORwait_cursor();
    TUTORflush();
    FindUnits(); /* build unit table */

    if (nunits <= 0) { 
        TUTORnormal_cursor();
        return(-2);
    }
    	
    docH = vp->textd;
    srcI = -1;
    for(ii=0; ii<sourcemalloc; ii++) {
        if (sourcetable[ii].doc == docH)
            srcI = ii; /* found file in source table */
    }
    
    unum = -1; /* pre-set not found */
    np = (struct unitnames FAR *) GetPtr(unitNames);
    for(ii=0; ii<unitmalloc; ii++)
        if (strcmpf((char FAR *) unitName,(char FAR *) np->udata[ii].name) == 0) {
            partials = -1; /* not a partial match */
            unum = np->udata[ii].unitnum;
        }

    /* try for partial match if unit not found */
    if ((unum < 0) && dopartial) {
        if ((partials < 0) || (partials > nunits))
            partials = -1; /* not on-going search */
        else partials++; /* start from next unit */

        if (partials >= 0) {
            for(ii=partials; ii<unitmalloc; ii++) {
                if (strncmpf((char FAR *) unitName,(char FAR *) np->udata[ii].name,strlen(unitName)) == 0) {
                    unum = np->udata[ii].unitnum;
                    partials = ii; /* set for next search */
                    break;
                } /* strncmp if */
            } /* for */
        } /* partials if */
        if (unum < 0) {
            for(ii=0; ii<unitmalloc; ii++) {
                if (strncmpf((char FAR *) unitName,(char FAR *) np->udata[ii].name,strlen(unitName)) == 0) {
                    unum =  np->udata[ii].unitnum;
                    partials = ii; /* set for next search */
                    break;
                } /* strncmp if */
            } /* for */
        } /* unum if */
    } /* unum if */
    ReleasePtr(unitNames);
    KillPtr(np);
    TUTORnormal_cursor();

    if (unum < 0) {
        if (srcI < 0)
            return(-2); /* not part of current compile */
        return(-1);
    }
    _TUTORinq_state_internal_marker(unittab[unum].marki,&pos,NEARNULL,NEARNULL);
    
    /* handle unit in -use- file */
    
    srcJ = unittab[unum].beginfile;
    if (srcI != srcJ) {
        if (!select) pos = -1;
        EditOpen(&sourcetable[srcJ].fRef,pos,0L);
        return(unum);
    }
    
    if (select) 
        SetSelectPanel(vp,pos,0L);
    
    return(unum);

} /* EditSearchUnit */

/* ******************************************************************* */

static EditCompile(editH,ep,vp,binf) /* compile all units */
/* returns TRUE for succesful compile */
Memh editH; /* editor window data */
EditDat FAR *ep;
TextVDat FAR *vp;
int binf; /* TRUE if should produce binary */

{   int cmpi,pcmpi; /* compile unit table index */
    int chkf;   /* checkpoint/compile error flag */
    int window;
    int nUnitsNeeded;
    int mFlag;  /* TRUE if should show compiling message */
    int currEdit; /* current editor */
  
    if (binaryOnly && allcompiled) {
        ReleasePtr(ep->textPanel);
        ReleasePtr(editH);
        return(TRUE);
    }
    TUTORset_view(vp->view); /* insure using editor view */
    TMessage(FARNULL); /* clear old compile error message */
    TUTORwait_cursor(); 
    TUTORflush();
   	if (EditWn[0] >= 0) {        
   		currEdit = CurEditWi;            
    	TUTORforward_window(EditWn[0]); /* bring main edit window forward */
    	interact(FALSE); /* allow events to come thru */
    	CurEditWi = currEdit;
    }

    /* set up for compile */
   
    nUnitsNeeded = CountNeedsCompiled();
    
    if (nUnitsNeeded == 0 || nunits < 1)
        { /* everything already compiled, or FindUnits has an error */
        allcompiled = (nUnitsNeeded == 0);
        if (binf && allcompiled)
            chkf = writebinary();
        else
            chkf = allcompiled;
        TUTORnormal_cursor();
        ReleasePtr(ep->textPanel);
        ReleasePtr(editH);
        return(chkf);
        }
    
    allcompiled = FALSE;
    
    mFlag = (nUnitsNeeded != 1 || binf);
    if (mFlag)
        StartCompileMsg(vp->view->window);
    
    /* compile any un-compiled units */

    window = vp->view->window;
    
    /* we need to free handles for CompileProgram */
    ReleasePtr(ep->textPanel);
    ReleasePtr(editH);
    binaryFileCurrent = FALSE;
    chkf = CompileProgram(window,binf,mFlag);
    ep = (EditDat FAR *) GetPtr(editH);
    vp = (TextVDat FAR *) GetPtr(ep->textPanel);
    
    /* update editor status after compile */

    TUTORnormal_cursor();
    if (chkf) {
        allcompiled = ep->didall = TRUE;
        ep->compilc = vp->alteredc;
        if (binf)
            binaryFileCurrent = TRUE;
    } 
    
    if (mFlag)
        EndCompileMsg(vp->view->window);
    
    ReleasePtr(ep->textPanel);
    KillPtr(vp);
    ReleasePtr(editH);
    KillPtr(ep);
    /* caller will have to recover ep & vp pointers */  
    return(chkf);

} /* EditCompile */

/* ******************************************************************* */

static EditSelectUnit(ep,vp,StartSelect)
EditDat FAR *ep;
TextVDat FAR *vp;
long StartSelect;
/* returns unit number or -1 for failure */
    
{   char tempS[34];
    char msgS[64];
    int ii;
    int unitN;
    
    TUTORarrow_cursor(TRUE);
    FindUnits();
    
    /* set up default unit name */

    tempS[0] = '\0';
    ii = LocateUnit(vp->textd,StartSelect);
    if (ii == 0) /* ieu */
        ii = sourcetable[0].firstunit;
    if ((ii < 0) || (ii > nunits)) 
        ii = 0; 
    GetUnitName(ii,(unsigned char *)tempS);
    
    /* run dialog */

    BeforeDialog(vp);
    ii = TUTORedit_dialog(vp->view->window,"Specify unit to run/execute:",
              (char FAR *) tempS,NEARNULL,FARNULL,32);
    AfterDialog(vp,TRUE);
    if (ii) {
        curSelUnit[0] = '\0'; /* no unit selected */
        curSelEdit = 0;
		ii = -1;
        if ((unitN = EditSearchUnit(tempS,vp,FALSE,FALSE)) >= 0) {
            strcpyf(curSelUnit,(char FAR *)tempS);
            ii = unittab[unitN].beginfile; /* index in source table */
            ii = sourcetable[ii].editI; /* get index of editor */
            if ((ii >= 0) && (ii < EDITWINDOWLIMIT))
            	curSelEdit = ii;
        } else { /* didnt find unit */
            if (ii < 0) 
                CantFindUnit(vp,(char FAR *)tempS);
        }
    } else
        unitN = -1; /* user cancelled */
    
    return(unitN);

} /* EditSelectUnit */

/* ******************************************************************* */

static CantFindUnit(vp,uname)
TextVDat FAR *vp;
char FAR *uname;

{   char msgS[64];

    strcpy(msgS,"Couldn't find unit: ");
    strcatf((char FAR *)msgS,uname);
    TUTORalert(vp->view->window,msgS);

} /* CantFindUnit */

/* ******************************************************************* */

static NoUnitsMsg(vp)
TextVDat FAR *vp;

{
    TUTORalert(vp->view->window,"File not compiled: can't recognize units");
    return(0);
    
} /* NoUnitsMsg */

/* ******************************************************************* */

EditConvert() /* convert source file */

{   long docLen;
    long startSelect,lenSelect;
    long uSelStart;
    long newlineP;
    DocP dp;
    int hasrgb;
    char tempS[80];

    docLen = TUTORget_len_doc(source);
    dp = (DocP) GetPtr(source); 
            
    /* find and delete old $syntaxlevel */
            
    startSelect = TUTORsearch_string_doc(dp,(unsigned char FAR *)"$syntaxlevel",
                   12L,0L,docLen);
    if (startSelect < 0)
        return; /* couldn't find $syntaxlevel */
    newlineP = TUTORsearch_string_doc(dp,(unsigned char FAR *)NEWLINES,
                       1L,startSelect,docLen);
    ReleasePtr(source);
    dp = FARNULL;
    lenSelect = (newlineP-startSelect)+1;
    TUTORdelete_doc(source,startSelect,lenSelect,NEARNULL); 
    docLen = TUTORget_len_doc(source);
    if (ctutv == 20) {
        strcpy(tempS,"$writewrap");
        strcat(tempS,NEWLINES);
        TUTORinsert_string_doc(source,0L,(unsigned char FAR *)tempS,11L);
    }
    if ((ctutv == 120) || (ctutv == 20)) {
        strcpy(tempS,"$nostylemark");
        strcat(tempS,NEWLINES);
        TUTORinsert_string_doc(source,0L,(unsigned char FAR *)tempS,13L);

        /* check if program has -rgb- or -hsv- command(s) */

        dp = (DocP) GetPtr(source); 
        hasrgb = FALSE; /* no -rgb- yet */
        docLen = TUTORget_len_doc(source);
        strcpy(tempS,NEWLINES);
        strcat(tempS,"rgb"); 
        startSelect = TUTORsearch_string_doc(dp,(unsigned char FAR *)tempS,
                           4L,0L,docLen);
        if (startSelect >= 0)
            hasrgb = TRUE;
        else {
            tempS[1] = '\0';
            strcat(tempS,"hsv"); 
            startSelect = TUTORsearch_string_doc(dp,(unsigned char FAR *)tempS,
                               4L,0L,docLen);
            if (startSelect >= 0)
                hasrgb = TRUE;
        } /* else */
        if (!hasrgb) {
            tempS[0] = '\t';
            tempS[1] = '\0';
            strcat(tempS,"rgb"); 
            startSelect = TUTORsearch_string_doc(dp,(unsigned char FAR *)tempS,
                               4L,0L,docLen);
            if (startSelect >= 0)
                hasrgb = TRUE;
            else {
                tempS[1] = '\0';
                strcat(tempS,"hsv"); 
                startSelect = TUTORsearch_string_doc(dp,(unsigned char FAR *)tempS,
                                   4L,0L,docLen);
                if (startSelect >= 0)
                    hasrgb = TRUE;
            } /* else */
        } /* !hasrgb if */

        ReleasePtr(source);
        dp = FARNULL;
        if (hasrgb) {
            strcpy(tempS,"$oldcolor");
            strcat(tempS,NEWLINES);
            TUTORinsert_string_doc(source,0L,(unsigned char FAR *)tempS,10L);
        } /* hasrgb if */
    } /* ctutv if */

  if ((ctutv == 120) || (ctutv == 121) || (ctutv == 20)) {
        strcpy(tempS,"$pcoldcolor");
        strcat(tempS,NEWLINES);
        TUTORinsert_string_doc(source,0L,(unsigned char FAR *)tempS,12L);
        docLen = TUTORget_len_doc(source);
        
        /* insert -coarse- command before unit or define */
        
        dp = (DocP)GetPtr(source);
        strcpy(tempS,"unit\t");
        uSelStart = TUTORsearch_string_doc(dp,(unsigned char FAR *)tempS,
                               5L,0L,docLen);
        strcpy(tempS,"define\t");
        startSelect = TUTORsearch_string_doc(dp,(unsigned char FAR *)tempS,
                               7L,0L,docLen);
        if ((startSelect < 0) || (startSelect > uSelStart)) {
            startSelect = uSelStart;
        }
        if (startSelect < 0)
            startSelect = docLen; /* put at end of IEU? */
        ReleasePtr(source);
        dp = FARNULL;
        strcpy(tempS,"coarse\t8,16");
        strcat(tempS,NEWLINES);
        TUTORinsert_string_doc(source,startSelect,(unsigned char FAR *)tempS,12L);
    } /* ctutv if */


    insertversion(); /* insert new $syntaxlevel statement */
    sourcetable[0].ctutv = ctutv; /* set version for main file */

} /* EditConvert */

/* ******************************************************************* */

#endif /* CTEDIT */

char *faceNames[] =
    {
    "Plain", "Bold", "Italic", "Underline",
    "Outline", "Shadow", "Subscript", "Superscript", "Default"
    };

char *justNames[] =
    {
    "Left Justified",
    "Centered",
    "Right Justified",
    "Full Justified"
    };

char *sizeNames[] =
    {
    "Bigger",
    "Smaller",
    "Default Size"
    };

/* machine dependent routines */
#ifdef MAC

#include <TextUtils.h>

static ChangeFaceMenu(faceList,onOff)
long faceList; /* set of bit flags of face style: 1-bold, 2-italic, 4-underline, etc. */
int onOff; /* 0 turn checks off, 1 turn on */
    {
    short ii;
    long mask;
    
    /* if (faceList == NOSTYLE) return; /* nothing to do */
    if (faceList == 0)
        TUTORmodify_menu(editmenus,"Styles",faceNames[0],-1,onOff,-1); /* plain */
    else
        { /* non-plain style */

        mask = 1;
        for (ii=1; ii<8; ii++)
            {
            if (mask & faceList)
                TUTORmodify_menu(editmenus,"Styles",faceNames[ii],-1,onOff,-1);
            mask <<= 1;
            }
        }
    }

static ChangeJustMenu(oldJust,newJust)
long oldJust, newJust;
    {
    /* get rid of old just */
    /* if (oldJust != NOSTYLE) */
        TUTORmodify_menu(editmenus,"Styles",justNames[oldJust-1],-1,0,-1);
    /* show new just */
    /* if (newJust != NOSTYLE) */
        TUTORmodify_menu(editmenus,"Styles",justNames[newJust-1],-1,1,-1);
    }

static ChangeSizeMenu(oldSize,newSize)
long oldSize, newSize;
    {
    /* get rid of old size */
    /* if (oldSize != NOSTYLE) */
        TUTORmodify_menu(editmenus,"Styles",sizeNames[oldSize],-1,0,-1);
    /* show new size */
    /* if (newSize != NOSTYLE) */
        TUTORmodify_menu(editmenus,"Styles",sizeNames[newSize],-1,1,-1);
    
    return;
    }

static ChangeFontMenu(oldFont,newFont)
long oldFont, newFont;
    {
    Str255 tempS;
    
    /* uncheck old font */
    /* if (oldFont != NOSTYLE) */
        {
        GetFontName((int) oldFont,tempS);
        PtoCstr((unsigned char *)tempS);
        TUTORmodify_menu(editmenus,"Fonts",(char *)tempS,-1,0,-1);
        }
    /* check new font */
    /* if (newFont != NOSTYLE) */
        {
        GetFontName((int) newFont,tempS);
        PtoCstr((unsigned char *)tempS);
        TUTORmodify_menu(editmenus,"Fonts",(char *)tempS,-1,1,-1);
        }
    }

#endif

/***************************************************/

DictInsert(s) /* insert dictionary input, return new caret position */
char *s;
    {
    register char *string = s;
    long sPos, sLen;  /* for GetSelect */
    int dictcmd, ro;
    struct tutorview FAR *cv;
    EditDat FAR *editp; /* pointer to main editor data */
    TextVDat FAR *vp;
    Memh doc;
    long docLen;
    long insertPos; /* to keep track of our changes */
    int forceF; /* TRUE if should force full update */

    if (CurEditWi != 0)
        return(0);
    forceF = FALSE; /* don't need to force full update */
    editp = (EditDat FAR *) GetPtr(windowsP[EditWn[0]].wH);
    vp = (TextVDat FAR *) GetPtr(editp->textPanel);
    ro = vp->readOnly;
    doc = vp->textd;
    TUTORinq_select_tview(vp->textv,&sPos,&sLen);
    ReleasePtr(editp->textPanel);
    KillPtr(vp);
    ReleasePtr(windowsP[EditWn[0]].wH);
    KillPtr(editp);
    if (ro)
        return(FALSE); /* read-only file */

    cv = TUTORinq_view(); /* remember current view (presumable dictionary text) */
    TUTORset_view(ExecVp); /* set to executor view */
    FullHalt(); /* stop execution */
    TUTORset_view(EditVp[0]); /* switch to editor view */
    if (runflag != halt)
        return(0 /*1 << i for black hilite*/); /* currently executing */

    if (strcmp(string, "global:") == 0)
        strcpy(string, "merge,global:");
    dictcmd = -1;
    if (strlen(string) <= 15)
	{
        if ((string[0] >= 'a') && (string[0] <= 'z'))
            dictcmd = 1; /* assume legal command */
        if ((*(string+strlen(string)-1)) == ':') dictcmd = C_DEFINE;
        }

    /* adjust insertion position and possibly open a blank line: */
    
    docLen = TUTORget_len_doc(doc);
    insertPos = -1; /* indicates that it hasn't been set yet */
    
#ifdef KSWnomore
-- because of $syntaxlevel we never should add to begin of doc
    /* if caret is at the beginning of source document,
                open a blank line for this new command. */
    if (sPos == 0)
        { /* caret is at beginning of document, open a blank line for command */
        if (sPos < TUTORget_len_doc(doc) && TUTORcharat_doc(doc, sPos) != NEWLINE)
            {
            if (dictcmd < 0)
                return(FALSE);
            insertPos = sPos;
            AddMore(doc,NEWLINES, &sPos);
            }
        }
#endif
    if (sPos == 0)
        return(0);
    
    if (TUTORcharat_doc(doc, sPos-1) == NEWLINE &&
            sPos < docLen && TUTORcharat_doc(doc, sPos) != NEWLINE)
        { /* caret at beginning of existing command line, open blank line for this command */
        insertPos = sPos;
        forceF = TRUE;
        AddMore(doc,NEWLINES, &sPos);
        sPos--;
        docLen++;
        }

    else if (dictcmd >= 0 && !(TUTORcharat_doc(doc, sPos-1) == '\t' && sPos > 1 &&
            (TUTORcharat_doc(doc, sPos-2) == NEWLINE || TUTORcharat_doc(doc, sPos-2) == '\t')) )
        { /* caret is in the middle of a line; move to the end of that line, unless preceded by blank TAB */
        while (sPos < docLen && TUTORcharat_doc(doc,sPos) != NEWLINE)
            sPos++;
        if (TUTORcharat_doc(doc, sPos-1) != NEWLINE)
            {
            if (!((dictcmd == C_DEFINE) && (TUTORcharat_doc(doc, sPos-1) == '\t')))
                 {
                 insertPos = sPos;
                 AddMore(doc,NEWLINES, &sPos);
                 }
            }
        }

    /* now add the appropriate string: */
    
    if (insertPos < 0)
        insertPos = sPos;

    if ( strcmp(string, "unit") == 0 )
        {
        forceF = TRUE; /* adding more than one line - full update */
        AddMore(doc,"**********", &sPos);
        AddMore(doc,NEWLINES, &sPos);
        }
    else if ((dictcmd == C_DEFINE) && (TUTORcharat_doc(doc,sPos-1) != '\t') )
        {
        AddMore(doc,"\t", &sPos);
        }

    AddMore(doc,string, &sPos);
    if (dictcmd == C_DEFINE)
        {
        AddMore(doc," ", &sPos);
        }
    else if (dictcmd >= 0)
        AddMore(doc,"\t", &sPos);

    if ( strcmp(string, "text") == 0 ||
            strcmp(string, "gtext") == 0 || strcmp(string, "rtext") == 0 )
        {
        sLen = sPos;
        forceF = TRUE;
        AddMore(doc,NEWLINES, &sPos);
        AddMore(doc,"\\", &sPos);
        sPos = sLen;
        }
    else if ( strcmp(string, "arrow") == 0 ||
        strcmp(string, "garrow") == 0 || strcmp(string, "rarrow") == 0)
        {
        sLen = sPos;
        forceF = TRUE;
        AddMore(doc,NEWLINES, &sPos);
        AddMore(doc,"endarrow", &sPos);
        sPos = sLen;
        }

    else if (strcmp(string, "case") == 0)
        {
        sLen = sPos;
        forceF = TRUE;
        AddMore(doc,NEWLINES, &sPos);
        AddMore(doc,"endcase", &sPos);
        sPos = sLen;
        }
    else if ( strcmp(string, "if") == 0)
        {
        sLen = sPos;
        forceF = TRUE;
        AddMore(doc,NEWLINES, &sPos);
        AddMore(doc,"endif", &sPos);
        sPos = sLen;
        }
    else if ( strcmp(string, "loop") == 0)
        {
        sLen = sPos;
        forceF = TRUE;
        AddMore(doc,NEWLINES, &sPos);
        AddMore(doc,"endloop", &sPos);
        sPos = sLen;
        }

    else if (strcmp(string, "move") == 0)
        {
        AddMore(doc,"icons:", &sPos);
        }

    /* redraw source text */
    
    editp = (EditDat FAR *) GetPtr(windowsP[EditWn[0]].wH);
    vp = (TextVDat FAR *) GetPtr(editp->textPanel);
    RefreshPanel(vp,insertPos,0L,insertPos,0L,sPos - insertPos,sPos,0L,TRUE,forceF);
    ReleasePtr(editp->textPanel);
    KillPtr(vp);
    ReleasePtr(windowsP[EditWn[0]].wH);
    KillPtr(editp);
    TUTORset_view(cv); /* return to dictionary view */

    return(TRUE);
    }

/**************************************************/
static AddMore(doc,ss,pos)  /* add s to source at location Pos, update Pos */
Memh doc;
char *ss;
long *pos;
/* returns # of characters added */
    {
    long len;
    
    InsertString(doc, *pos, (char FAR *) ss, len = strlen(ss));
    *pos += len;
    
    return((int) len);
    }
    
/* ******************************************************************* */

int SetCurEditWi() /* set index of currently active editor */

{   int ii; /* index in edit windows */

    for(ii=0; ii<EDITWINDOWLIMIT; ii++) {
        if (EditWn[ii] == CurrentWindow) {
            CurEditWi = ii;
            return(ii); /* return index of editor */
        }
    } /* for */
    CurEditWi = 0; /* use editor #0 if don't know what's going on */
    return(0);
    
} /* SetCurEditWi */

/* ******************************************************************* */

static int UndoHilite() /* undo highlight after error or debugging */

{	int ii;
	int wid;
	EditDat FAR *ep;
	TextVDat FAR *vp;
	TViewP tvp;	
	Memh tempH;
	long startSelect,lenSelect;
	SBarInfo sbv;
	struct tutorview FAR *cv;
	int didAct;

	if (!internalSelect)
		return(0); /* get out quick if nothing to do */
	
	internalSelect = FALSE;
	cv = TUTORinq_view(); /* save current view */
	didAct = FALSE; /* haven't done anything yet */
	for(ii=0; ii<EDITWINDOWLIMIT; ii++) {
    	wid = EditWn[ii];
		if (wid >= 0) {
        	tempH = windowsP[wid].wH;
            ep = (EditDat FAR *) GetPtr(tempH);
            vp = (TextVDat FAR *) GetPtr(ep->textPanel);
			tvp = (TViewP)GetPtr(vp->textv);
			if (tvp->hiInactive) {
				didAct = TRUE;
				ReleasePtr(vp->textv); /* for SetupSomeLines way under set_select */
			    TUTORset_view(vp->view); /* set to editor view */
			    TUTORinq_select_tview(vp->textv,&startSelect,&lenSelect);
            	TUTORset_select_tview(vp->textv,startSelect+lenSelect,0L,&sbv);
				tvp = (TViewP)GetPtr(vp->textv);
				tvp->hiInactive = FALSE;
				/* generate redraw to be sure we don't get multiple */
				/* hilights */
				windowsP[wid].winRedraw = TRUE; 
				if (ii == CurEditWi) {
					ActivatePanel(vp,TRUE,TRUE,TRUE);
				}
			}
			ReleasePtr(vp->textv);
			ReleasePtr(ep->textPanel);
			ReleasePtr(tempH);
		} /* wid if */
	} /* for */
	if (didAct)
		TUTORset_view(cv); /* restore view */
	return(0);
	
} /* UndoHilite */

/* ******************************************************************* */

int PostEditQuit() /* post quit message to editor */

{   struct tutorevent cev;

    TUTORzero((char FAR *)&cev,(long)sizeof(struct tutorevent));
    cev.window = EditWn[0];
    cev.view = EditVp[0];
    cev.type = EVENT_MENU;
    cev.a1 = edit_quit;
    cev.timestamp = 0;
    TUTORpost_event(&cev);
    return(0);

} /* PostEditQuit */

/* ******************************************************************* */
