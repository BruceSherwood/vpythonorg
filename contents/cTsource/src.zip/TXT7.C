
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* document compare and search routines */

#include "baseenv.h"
#include "txt.h"
#include "tglobals.h"

#ifdef ctproto
static int ClearAliasValueSequence(void);
static int FirstChar(int useTable, unsigned char FAR *cTable, unsigned char *sNear,int s1,long sLen);
long  TUTORsearch_string_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sLen,long  pos,long  posEnd);
long  _TUTORsearch_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sGood,long  sLen,unsigned int  strSpecial,long  strSOff,long  pos,long  posEnd,unsigned char  FAR *cTable);
int  _TUTORcmp_doc(struct  _ktd FAR *dp,long  pos0,long  dLen0,long  *docUsed,unsigned char  FAR *ss,long  ssGood,long  *cLen0,unsigned int  strSpecial,long  strSOff,unsigned char  FAR *cTable,int  exactF);
extern int  AliasValue(unsigned char  FAR *ss,long  lenLeft,unsigned char  FAR *cTable,unsigned int  offset,unsigned char  *value, int key);
unsigned char  FAR *TUTORscan_bytes(unsigned char  FAR *bp,unsigned char  FAR *be,unsigned char  *tp,int  nTab);
char  FAR *GetPtr(unsigned int  mm);
struct  _tblk FAR *FindTBlock(struct  _ktd FAR *dp,long  pos,long  *pOff,long  *eOff);
int  TUTORdump(char  *s);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  _TUTORload_buffer_doc(struct  _ktd FAR *dp,long  pos);
#endif /* ctproto */

#ifdef macproto
extern int sprintf(char *ss, char *form,...);
#endif

extern unsigned int TUTORnew_doc();
extern char FAR *GetPtr();
long TUTORget_len_doc();
long  _TUTORsearch_doc();
long TUTORsearch_string_doc();
unsigned char  FAR *TUTORscan_bytes();
struct  _tblk FAR *FindTBlock();

/* ksw-documentation
	The compare/search alias table.
	
	When we are using a table a given character, or a multi-character string,
		is given a "value".  The compares & searches are done only with these
		values.  The values are unsigned bytes, so there are 256 possible values.
		The compare/search alias table associates each character and
		multi-character string with a value.  Note that many characters may have
		the same value - then they compare as equal.
	
	The data format of the table is:
	
	The first 256 entries are the values to be used in compare/search for each
		character.
	There is then a byte indicating the kind of multi-byte aliases:
		0: no aliases
		1: non-expanding aliases, meaning that for all multi-strings the values
			do not equal the values of any single characters.  (e.g. spanish ch)
		2: expanding aliases, meaning that some multi-strings have values equal
			to the values of single characters. (e.g. 'A' 'E' equal 'AE')
	Then there is a byte giving the maximum length of aliases.  For a table with
		no aliases this will be 1.  Otherwise it will be the length of the longest
		multi-byte alias.
	
	No more is needed for tables that have no aliases.  Otherwise,
	
	Then there are 256 shorts, one for each value, which are the byte offsets to the
		first AliasItem whose starting letter has that value.  These are offsets from
		the beginning of the table.
	There then follows a collection of AliasItems (structure defined below).  These
		AliasItems are linked, thru their nextOffsets for all aliases that have first
		letters that have the same value.  Each AliasItem is padded
		out to an even number of bytes.
*/

/* structure for use in defining compare/search aliases */
typedef struct _csali
	{
	short nextOff;		/* offset to next AliasItem with same starting letter (or 0) */
	unsigned char len;	/* length of alias string */
	unsigned char vlen;	/* length of the value sequence */
	unsigned char str[2];	/* the alias string (values of chars) (variable length) */
	unsigned char vstr[2];	/* the value sequence (variable length) */
	} AliasItem;

static unsigned char defaultCTable[258] = 
	{
	/* this table make comparisons case & diacritic insensitive */
	/* it maps the german ss character to s, places the icelandic D (eth)
		after d and the icelandic P (thorn) after the Z */
	/* the AE character is mapped to E */
	/* we also map non-breaking space to space and soft hyphen to hyphen */
	0,1,2,3,4,5,6,7,
	8,9,0xa,0xb,0xc,0xd,0xe,0xf,
	0x10,0x11,0x12,0x13,0x14,0x15,0x16,0x17,
	0x18,0x19,0x1a,0x1b,0x1c,0x1d,0x1e,0x1f,
	
	0x20,0x21,0x22,0x23,0x24,0x25,0x26,0x27, /* ' */
	0x28,0x29,0x2a,0x2b,0x2c,0x2d,0x2e,0x2f, /* / */
	0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37, /* 7 */
	0x38,0x39,0x3a,0x3b,0x3c,0x3d,0x3e,0x3f, /* ? */
	
	0x40,0x41,0x42,0x43,0x44,0x46,0x47,0x48, /* G */
	0x49,0x4a,0x4b,0x4c,0x4d,0x4e,0x4f,0x50, /* O */
	0x51,0x52,0x53,0x54,0x56,0x57,0x58,0x59, /* W */
	0x5a,0x5b,0x5c,0x5e,0x5f,0x60,0x61,0x62, /* _ */
	
	0x63,0x41,0x42,0x43,0x44,0x46,0x47,0x48, /* g */
	0x49,0x4a,0x4b,0x4c,0x4d,0x4e,0x4f,0x50, /* o */
	0x51,0x52,0x53,0x54,0x56,0x57,0x58,0x59, /* w */
	0x5a,0x5b,0x5c,0x64,0x65,0x66,0x67,0x68, /* del */
	
	0x69,0x6a,0x6b,0x6c,0x6d,0x6e,0x6f,0x70,
	0x71,0x72,0x73,0x74,0x75,0x76,0x77,0x78,
	0x79,0x7a,0x7b,0x7c,0x7d,0x7e,0x7f,0x80,
	0x81,0x82,0x83,0x84,0x85,0x86,0x87,0x88,
	
	0x20,0x89,0x8a,0x8b,0x8c,0x8d,0x8e,0x8f, /* section */
	0x90,0x91,0x92,0x93,0x94,0x2d,0x95,0x96, /* macron */
	0x97,0x98,0x99,0x9a,0x9b,0x9c,0x9d,0x9e, /* middle dot */
	0x9f,0xa0,0xa1,0xa2,0xa3,0xa4,0xa5,0xa6, /* inverse question */
	
	0x41,0x41,0x41,0x41,0x41,0x41,0x46,0x43, /* C cedilla */
	0x46,0x46,0x46,0x46,0x4a,0x4a,0x4a,0x4a, /* I diaresis */
	0x45,0x4f,0x50,0x50,0x50,0x50,0x50,0xa7, /* multiplication */
	0x50,0x57,0x57,0x57,0x57,0x5b,0x5d,0x54, /* german ss */
	
	0x41,0x41,0x41,0x41,0x41,0x41,0x46,0x43, /* c cedilla */
	0x46,0x46,0x46,0x46,0x4a,0x4a,0x4a,0x4a, /* i diaresis */
	0x45,0x4f,0x50,0x50,0x50,0x50,0x50,0xa8, /* division */
	0x50,0x57,0x57,0x57,0x57,0x5b,0x5d,0x5b, /* y diaresis */
	0x00,0x01	/* flags indicating no aliases */
	};

long TUTORsearch_string_doc(dp,ss,sLen,pos,posEnd) /* exact string search */
DocP dp;	/* pointer to document */
unsigned char FAR *ss;	/* string to search for */
long sLen;	/* length of string */
long pos, posEnd;	/* where to search in document (pos > posEnd for backwards search) */
	{
	return(_TUTORsearch_doc(dp,ss,sLen,sLen,HNULL,0L,pos,posEnd,FARNULL));
	}

long _TUTORsearch_doc(dp,ss,sGood,sLen,strSpecial,strSOff,pos,posEnd,cTable)
register DocP dp;	/* pointer to document */
unsigned char FAR *ss; /* string we are searching for */
long sGood;	/* # of chars for which ss is good */
register long sLen; /* length of string to check for (<= sGood) */
Memh strSpecial;	/* special text associated with string */
long strSOff;		/* offset into strSpecial at begin of ss */
long pos; /* where we start looking */
long posEnd; /* end of region where we will look */
			/* pos & posEnd bound the text that will be looked at */
			/* if pos > posEnd, we are searching backwards */
unsigned char FAR *cTable; /* ordering table of characters, if NULL, don't use,
							if -1, use default */
/* returns position if char is found, -1L if not */
	{
	TextBlock FAR *curBlock;	/* pointer to current text block */
	TextBlock FAR *endBlock;	/* pointer to last text block */
	long eOff;	/* dummy variable */
	int ii;
	long alwaysStart,alwaysEnd;	/* low & high end of search region (independent of direction) */
	long pos0; /* position of start of current text block */
	long relPos; /* offset from tp to start of current block */
	register unsigned char FAR *tp;	/* pointer to current text */
	register unsigned char FAR *tempP;	/* temporary pointer to text */
	unsigned char FAR *tEnd;	/* end of text that we can look at */
	unsigned char FAR *tp0;	/* beginning of current text */
	unsigned char FAR *saveTP;	/* to save & restore tp */
	DArrayHeader FAR *dap;	/* dynamic array header of text blocks */
	int dir;	/* if TRUE, look forwards, if FALSE look back */
	int lastBlock;	/* TRUE if we are looking at last possible text block */
	unsigned char sNear[256];	/* first char (any that match) we are looking for */
	short nFirst;	/* # of chars that can match first */
	register long matchLen;	/* # of characters of target we match, after we've found first */
	char useTable;	/* 0 if no table, 1 if simple table, 2 if table with aliases */
	long tempL, tempL2, tempL3;
	long curPos;	/* current position */
	
	dir = (posEnd > pos);
		
	/* is this a simple search or one using a ordering table? */
	if (!cTable)
		useTable = FALSE;
	else if (cTable == (unsigned char FAR *) -1L)
		{ /* default ordering table */
		cTable = (unsigned char FAR *) &defaultCTable[0];
		useTable = 1;
		}
	else
		useTable = 1; /* caller supplied ordering table */
	if (useTable && cTable[256] == 2)
		useTable = 2; /* expanding aliases (Note that non-expanding aliases are
						not interesting to search because search is only interested
						in exact matches) */
	
	if (!dir)
		{
		if (pos - posEnd < sLen && useTable != 2)
			return(-1L); /* not enough space */
		alwaysEnd = pos;
		alwaysStart = posEnd;
		if (useTable != 2)	
			pos = alwaysEnd - sLen; /* go back far enough to allow a possible match */
		else
			pos = alwaysEnd - 1;
		}
	else
		{
		if (posEnd - pos < sLen && useTable != 2)
			return(-1L); /* not enough space */
		alwaysEnd = posEnd;
		alwaysStart = pos;
		posEnd--;
		}
	
	if (alwaysStart < 0 || alwaysEnd > dp->totLen)
		return(-1L); /* search outside doc bounds */
	
	/* is this a simple search or one using a ordering table? */
	if (!cTable)
		useTable = FALSE;
	else if (cTable == (unsigned char FAR *) -1L)
		{ /* default ordering table */
		cTable = (unsigned char FAR *) &defaultCTable[0];
		useTable = 1;
		}
	else
		useTable = 1; /* caller supplied ordering table */
	if (useTable && cTable[256] == 2 && sLen > 1)
		useTable = 2; /* expanding aliases (Note that non-expanding aliases are
						not interesting to search because it does an exact match) */
	
	/* find set of first matching chars */
	nFirst = FirstChar(useTable,cTable,sNear,*ss,sLen);

	if (dp->shortText || (alwaysEnd <= dp->buffEnd && alwaysStart >= dp->buffStart))
		{ /* search in buffer */
		tp = ((unsigned char FAR *) dp->text) + (pos - dp->buffStart);
		tEnd = ((unsigned char FAR *) dp->text) + (posEnd - dp->buffStart);
			
		while (TRUE)
			{ /* keep trying until we find a match or we are done */
			tp = TUTORscan_bytes(tp,tEnd,sNear,nFirst);
			if (!tp)
				return(-1L); /* didn't find match */
			
			if (sLen == 1) /* already found whole string */
				return((tp - (unsigned char FAR *) dp->text) + dp->buffStart); /* found it */
			
			/* check the rest of the string */
			curPos = (tp - (unsigned char FAR *) dp->text)+dp->buffStart;
			if (!dir || alwaysEnd - curPos - sLen >= 0
					|| useTable == 2)
				{ /* there is space for the rest of the string */
				tp0 = tp++; /* we've already matched first char */
				if (!useTable)
					{ /* exact comparison */
					tempP = ss+1;
					for (matchLen=1; matchLen<sLen; matchLen++)
						if (*tp++ != *tempP++)
							break; /* not match */
					}
				else if (useTable == 1)
					{
					tempP = cTable;
					for (matchLen=1; matchLen<sLen; matchLen++)
						if (tempP[*tp++] != tempP[ss[matchLen]])
							break; /* not match */
					}
				else
					{ /* complex match (useTable == 2) */
					tempL = sLen;
					ii = _TUTORcmp_doc(dp,curPos,alwaysEnd - curPos,&tempL2,
								ss,sGood,&tempL,strSpecial,strSOff,cTable,TRUE);
					/* put results in terms of other cases */
					if (!ii)
						matchLen = sLen;
					else
						matchLen = -1;
					}
				
				if (matchLen == sLen)
					return((tp0 - (unsigned char FAR *) dp->text) + dp->buffStart); /* found it */
				else
					{ /* get ready for next search */
					if (dir)
						{
						tp = tp0+1;
						}
					else
						{
						if (tp0 <= tEnd)
							return(-1L); /* out of space on backwards search */
						tp = tp0 - 1;
						}
					}
				}
			else
				return(-1L); /* ran out of space on forward search */
			}
		}
	
	/* at this point we have to do search in textblock doc */
	
	dap = (DArrayHeader FAR *) ((char FAR *) dp + dp->offsets[DOCTBLOCK]);

	if (dir)
		endBlock = ((TextBlock FAR *) (dap+1)) + (dap->dAnn - 1); /* points at last block */
	else
		{
		endBlock = (TextBlock FAR *) (dap+1); /* first block */
		}

	curBlock = FindTBlock(dp,pos,&relPos,&eOff);
	pos0 = pos - relPos;  /* position at beginning of block */
	
	while (TRUE)
		{
		tp0 = (unsigned char FAR *) GetPtr(curBlock->text);
		tp = tp0 + relPos; /* look at char AT pos */
		lastBlock = FALSE;
		if (dir)
			{
			if (alwaysEnd > pos0 + curBlock->tLen)
				tEnd = tp0 + (curBlock->tLen - 1); /* search doesn't end in this block */
			else
				{
				tEnd = tp0 + ((alwaysEnd-pos0) - 1); /* stop before end of block */
				lastBlock = TRUE;
				}
			}
		else
			{
			if (pos0 <= alwaysStart)
				{
				tEnd = tp0 + (alwaysStart - pos0);
				lastBlock = TRUE;
				}
			else
				tEnd = tp0; /* search doesn't end in this block */
			}
		
		while (TRUE)
			{ /* search till we find, or get through block */
			tp = TUTORscan_bytes(tp,tEnd,sNear,nFirst);
		
			if (tp && sLen == 1)
				{
				relPos = tp - tp0;
				matchLen = 1; /* already done with this important special case */
				break;
				}
			else if (tp)
				{ /* found first char of multi-char target */
				relPos = tp - tp0;
				if (relPos + pos0 + sLen <= alwaysEnd || useTable == 2)
					{ /* there is space for the rest of the string */
		
					/* check the rest of the string */
					if (sLen <= curBlock->tLen - relPos && useTable != 2)
						{ /* all the text to compare is in this block */
						if (!useTable)
							{
							tempP = ss+1;
							saveTP = tp;
							tp++; /* because first char already matched */
							for (matchLen=1; matchLen<sLen; matchLen++)
								if (*tp++ != *tempP++)
									break;
							tp = saveTP;
							}
						else
							{
							tempP = cTable;
							saveTP = tp;
							tp++; /* because first char already compared */
							for (matchLen=1; matchLen<sLen; matchLen++)
								if (tempP[*tp++] != tempP[ss[matchLen]])
									break;
							tp = saveTP;
							}
						if (matchLen == sLen)
							break; /* we are done */
						}
					else
						{ /* comparison spans block boundaries or is complicated */
						curPos = pos0+relPos;
						tempL = sLen; /* string comparison length */
						tempL3 = (useTable == 2) ? (alwaysEnd - curPos) : sLen; /* doc comparison length */
						if (!_TUTORcmp_doc(dp,curPos,tempL3,&tempL2,
								ss,sGood,&tempL,strSpecial,strSOff,cTable,TRUE))
							{
							matchLen = sLen; /* so comparison below succeeds */
							break; /* we are done */
							}
						else
							matchLen = -1;
						}
					}
				
				/* at this point we weren't able to match target, so continue
					searching this block */
				matchLen = -1; /* signal not found in case we can't continue in this block */
				if (dir)
					{
					if (tp >= tEnd)
						break; /* can't continue in this block */
					tp++;
					}
				else
					{
					if (tp <= tEnd)
						break; /* can't continue in this block */
					tp--;
					}
				}
				
			else  /* didn't find first char of target at all */
				{
				matchLen = -1; /* so test below fails */
				break; /* we are done with this block */
				}
			}
		
		/* at this point we are done with current block.  Either we have found the
			target (in which case matchLen == sLen) or we didn't find it */
			
		ReleasePtr(curBlock->text);
		KillPtr(tp0);
		if (matchLen == sLen)
			{ /* found it */
			return(pos0+relPos);
			}
		else if (curBlock == endBlock || lastBlock)
			return(-1L); /* no more blocks, or run out of space */
		
		/* need to look at next block */
		if (dir)
			{
			pos0 += curBlock->tLen;
			curBlock++;
			relPos = 0L;
			}
		else
			{
			curBlock--;
			pos0 -= curBlock->tLen;
			relPos = curBlock->tLen-1;
			}
		} /* while */
	
	/* we shouldn't get here */

	}

static FirstChar(useTable,cTable,sNear,s1,sLen)
int useTable;	/* 0 if no table, 1 if simple table, 2 if table with aliases */
unsigned char FAR *cTable; /* ordering table of characters, if NULL, don't use,
							if -1, use default */
unsigned char *sNear;	/* to be filled with possible first chars */
int s1;	/* first char of search target */
long sLen;	/* length of search target */
/* returns # of characters that can be first char */
	{
	int ii, jj, kk;
	int nFirst;	/* # of characters that can be first (return value) */
	unsigned short FAR *offp;	/* pointer to offsets in comparison table */
	AliasItem FAR *aip;	/* pointer to an individual alias */
	short offset;	/* offset to next alias */
	unsigned char val;	/* value of first char of alias */
	unsigned char FAR *valstr;	/* pointer to value sequence of alias */
	
	if (useTable)
		{ /* we need to figure out what chars are acceptable as match of first char */
		nFirst = 0;
		for (ii=0; ii<256; ii++)
			{
			if (cTable[ii] == cTable[s1])
				sNear[nFirst++] = ii;
			}
		if (useTable == 2)
			{ /* we also need to look for 1st chars of appropriate expanding aliases */
			offp = (unsigned short FAR *) (cTable+258);
			for (ii=0; ii<256; ii++)
				{
				offset = offp[ii];
				while (offset)
					{ /* go thru linked list of aliases for this value */
					aip = (AliasItem FAR *) (cTable + offset);
					valstr = (unsigned char FAR *) (aip->str) + aip->len;
					offset = aip->nextOff;
					if (valstr[0] == cTable[s1] && aip->len <= sLen)
						{ /* we need to look for this alias */
							/* therefore all characters that have the same value
								as the first char of alias are possible first matches */
						val = cTable[aip->str[0]]; /* value of first char */
						for (jj=0; jj<256; jj++)
							{ /* find all chars with same value as 1st char of alias */
							if (cTable[jj] == val)
								{ /* make sure we don't already have this char */
								for (kk=0; kk<nFirst; kk++)
									if (jj == sNear[kk])
										break;
								/* if we don't have it, add it */
								if (kk >= nFirst)
									{
									sNear[nFirst++] = jj;
									}
								}
							}
						}
					} /* while offset */
				}
			}  /* if useTable == 2 */
		}
	else
		{ /* exact match, there is only 1 char that can match first */
		sNear[0] = s1;
		nFirst = 1;
		}
	
	return(nFirst);
	}

_TUTORcmp_doc(dp,pos0,dLen0,docUsed,ss,ssGood,cLen0,strSpecial, strSOff, cTable,exactF)	/* compare string to doc */
register DocP dp;	/* pointer to document */
long pos0;	/* position in doc to start comparing at */
long dLen0;	/* length in doc for which we compare */
long *docUsed;	/* to be set to # of chars used out of document in this compare */
register unsigned char FAR *ss;	/* characters to test for */
long ssGood;	/* length that ss is valid for */
long *cLen0;	/* length we should do comparison for (<= ssGood),
					returns # of chars used out of ss */
Memh strSpecial;	/* special text associated with string */
long strSOff;		/* offset into strSpecial at begin of ss */
register unsigned char FAR *cTable; /* ordering table of characters, if NULL, don't use,
							if -1, use default */
int exactF;	/* if TRUE we return 0 on match, non-zero otherwise.  Otherwise we
				return 0 for =, +1 if doc is bigger, -1 if doc is smaller */

/* docUsed && cLen0 are only set if we return 0 */

	{
	long pos;	/* current position */
	register unsigned char FAR *tp;	/* pointer to current text */
	register long tempL;
	long cmpLen;
	long docGood;
	int retVal, incr;
	char useTable;	/* 0 if no table, 1 if simple table, 2 if table with aliases */
	unsigned short FAR *offp;	/* pointer to alias list offsets */
	unsigned short tempSh;
	unsigned char val1, val2;
	int maxAliasLen;	/* maximum length of an alias string in the table */
	int moreString;	/* TRUE if there is more string to compare after what we have */
	unsigned char FAR *buffEndP;
	long cLen, dLen;
	long tempL2;
	
#ifdef DOCVERIFY
	if (pos0+dLen0 > dp->totLen) {
		TUTORdump("_TUTORcmp_doc: Too long compare");
	}
#endif

	cLen = *cLen0;
	dLen = dLen0;
	moreString = (*cLen0 < ssGood);
	pos = pos0;
	
	/* is this a simple compare or one using a ordering table? */
	if (!cTable)
		useTable = 0;
	else if (cTable == (unsigned char FAR *) -1L)
		{ /* default ordering table */
		cTable = (unsigned char FAR *) &defaultCTable[0];
		useTable = 1;
		}
	else /* caller supplied ordering table */
		useTable = 1;
	
	if (useTable && cTable[256])
		{
		if (cTable[256] == 2 || !exactF)
			{ /* we need full-blown comparison */
			useTable = 2; /* use aliases */
			offp = (unsigned short FAR *) (cTable+258); /* points to alias list offsets */
			maxAliasLen = cTable[257];
			ClearAliasValueSequence();
			}
		}
	
	if (exactF && dLen != cLen && useTable != 2)
		return(1); /* can't have exact match if not right # of chars */
		
	while (cLen && dLen)
		{
		if (!dp->shortText)
			_TUTORload_buffer_doc(dp,pos); /* load text into buffer */
		tp = ((unsigned char FAR *) dp->text) + (pos-dp->buffStart);
		
		if (!useTable)
			{ /* exact comparison */
			/* tempL = min(dLen,clen,buff chars past pos) */
			tempL = dp->buffEnd - pos;
			if (tempL > dLen)
				tempL = dLen;
			if (tempL > cLen)
				tempL = cLen;
			cmpLen = tempL;
			
			/* compare tempL chars */
			while (tempL--)
				{
				if (*tp++ != *ss++)
					{
					return((*(tp-1) > *(ss-1)) ? 1 : -1);
					}
				}
			
			cLen -= cmpLen;
			}
		else if (useTable == 1)
			{ /* simple table */
			/* tempL = min(dLen,clen,buff chars past pos) */
			tempL = dp->buffEnd - pos;
			if (tempL > dLen)
				tempL = dLen;
			if (tempL > cLen)
				tempL = cLen;
			cmpLen = tempL;
			
			/* compare tempL chars */
			while (tempL--)
				{
				if (cTable[*tp++] != cTable[*ss++])
					{
					return((cTable[*(tp-1)] > cTable[*(ss-1)]) ? 1 : -1);
					}
				tp++;
				ss++;
				}
			
			cLen -= cmpLen;
			}
		else
			{ /* table with aliases */
			tempL = dp->buffEnd - pos; /* # of chars we have left of doc */
			buffEndP = (unsigned char FAR *) dp->text + (dp->buffEnd - dp->buffStart);
			if (tempL < dLen) /* stop early because end of alias may be outside our buffer */
				tempL -= (maxAliasLen-1);
			cmpLen = tempL;
			tempL2 = cLen; /* original value of cLen (used in special text compare) */
			while (cLen && tempL)
				{
				tempSh = offp[cTable[*tp]];
				if (tempSh)
					{ /* there are aliases for char at tp */
					incr = AliasValue(tp,buffEndP - tp,cTable,tempSh,&val1,0);
					tp += incr;
					tempL -= incr;
					}
				else
					{
					tempL--;
					val1 = cTable[*tp++];
					}
				tempSh = offp[cTable[*ss]];
				if (offp[cTable[*ss]])
					{ /* there are aliases for char at ss */
					/* Note that this AliasValue can run through more characters
						of string than the comparison length.  It can run through
						up to ssGood chars */
					incr = AliasValue(ss,ssGood,cTable,tempSh,&val2,1);
					ssGood -= incr;
					ss += incr;
					cLen -= incr;
					}
				else
					{
					ssGood--;
					cLen--;
					val2 = cTable[*ss++];
					}
				if (val1 != val2)
					{
					return(val1 - val2);
					}
				}
			cmpLen -= tempL; /* number of chars of doc we used */
			} /* usetable if */
		
		pos += cmpLen;
		dLen -= cmpLen;
		}  /* while */

	if (!cLen && (!dLen || moreString))
		{ /* matched thru all chars, or matched thru what we could compare
				of string and there is more string */
		*docUsed = dLen0 - dLen; /* # of chars we used out of document */
		tempL = *cLen0;	/* copy of original length of string (used below) */
		*cLen0 -= cLen;			/* # of chars we used out of string */
		
		retVal = 0;
		}
	else
		{ /* matched but string or doc was too short */
		retVal = dLen ? 1 : -1;
		}
	
	return(retVal);
	}

/* tables for storing value sequences of length > 1 */
#define MAXALIASNVAL 256
static char aliasValues[2][MAXALIASNVAL];
static char aliasStrLen[2];
static char aliasSeq[2] = {0,0};

static ClearAliasValueSequence() /* initialize aliasValues table */
	{
	/* there are no multi-value sequences in effect yet */
	aliasSeq[0] = aliasSeq[1] = 0;
	}

/* compare using expanding aliases */
static AliasValue(ss,lenLeft,cTable,offset,value,key)
unsigned char FAR *ss;	/* string to calculate value of (we may use several chars) */
long lenLeft;	/* how many characters we can use */
unsigned char FAR *cTable;	/* the compare table */
unsigned int offset;	/* offset to first alias in compare table */
unsigned char *value;	/* to be set to value of the alias */
int key;	/* index to which string this is */
/* returns the number of characters to advance char pointer */
	{
	register AliasItem FAR *aip;	/* pointer to alias item */
	register unsigned char FAR *t1, FAR *t2;
	register int ii;
	int retVal;	/* # of chars we used in matching an alias */
	
	if (aliasSeq[key] > 0)
		{ /* we are in the middle of a multi-value sequence,
				return the next value */
		*value = aliasValues[key][aliasSeq[key]++];
		if (aliasSeq[key] < aliasStrLen[key])
			return(0); /* don't advance string pointer yet */
		else
			{ /* we are done with alias */
			aliasSeq[0] = aliasSeq[1] = 0;
			return(aliasStrLen[key]);	/* advance over string that was aliased */
			}
		}
	
	/* go thru a linked list of AliasItems.  The first item is at the offset
		handed to us.  Every item in the list will have a character with
		the same starting value (which is the value for *ss) */
	
	while (offset)
		{
		aip = (AliasItem FAR *) (cTable + offset); /* get the AliasItem */
		offset = aip->nextOff;		/* offset to next AliasItem */
		if (aip->len > lenLeft)
			continue; /* this item is too long */
		t1 = ss;
		t2 = (unsigned char FAR *) (aip->str);
		ii = aip->len;
		for (ii=aip->len; ii>0; ii--)
			{
			if (cTable[*t1] != *t2)
				break;
			t1++;
			t2++;
			}
		if (ii == 0)
			break; /* we found full match */
		}
	
	if (offset)
		{ /* we found a match */
		t1 = (aip->str) + aip->len;	/* pointer to value sequence */
		*value = t1[0];
		if (aip->vlen > 1)
			{ /* there are multiple values to this alias.  Store the value sequence
				in the aliasValues table.  We don't update the string pointer
				until all the values in the sequence have been returned */
			aliasStrLen[key] = aip->vlen;
			aliasSeq[key] = 1; /* next value to get */
			for (ii=0; ii<aip->vlen; ii++)
				aliasValues[key][ii] = t1[ii]; /* copy value sequence */
			return(0); /* we haven't used up the alias yet */
			}
		else
			{ /* single value alias, nothing fancy */
			retVal = aip->len;
			}
		}
	else
		{ /* no match, we just take 1 char with its usual translated value */
		*value = cTable[*ss];
		retVal = 1;
		}
	
	return(retVal);
	}


