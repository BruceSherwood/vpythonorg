/*
 * A component of the cT (TM) programming environment. (c) Copyright 1989
 * Carnegie Mellon University. cT is a trademark of Carnegie Mellon
 * University. All rights reserved. May not be copied without the written
 * consent of Carnegie Mellon University.
 */

/* Part of the TUTORgraphics package for cT - the portion for the executor */

#include <stdio.h>
#include "execdefs.h"
#include "tglobals.h"
#include "eglobals.h"
#include "commands.h"
#include "kglobals.h"


#ifdef ctproto
struct tutorview FAR *TUTORinq_touch_view(Memh tH);
extern int TellExecInt(void);
extern int plotText(Memh doc,long start,long end);
extern int free_snapShot(void);
extern int  TUTORdouble_click(short  *hh,short  *vv);
extern int TUTORset_sub_new(int sub,int new);
extern char FAR *TUTORalloc(long mm, int abort,char *label);
extern int TUTORset_touch_priority(Memh tH,int prior);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
extern int TUTORfree_handle(Memh hh);
extern  int TUTORpost_event(struct tutorevent *event);
extern int TUTORline_thick(int thickV);
extern double CoordToFloat(Coord xx);
extern int trig_arc(int type,int xcenter,int ycenter,double radius,
                    double startAngle,double stopAngle,int broken);
extern int abs(int ii);
extern int TUTORset_touch_unit(Memh tH,int index,int unitF,int unitN,double unitA);
int  ClearAuthorFile(long  vloc);
int  TUTORdraw_icons(char  *is,int  len);
int  TUTORthick_box(long  x1,long  y1,long  x2,long  y2,long  thick,long  thickx,long  thicky);
int  TUTORmove_to(long  x,long  y);
int  TUTORset_clip_rectangle(long  x1,long  y1,long  x2,long  y2);
int  SetFlushState(int  flag);
int  flush(void);
int  exec_switch_fixup(void);
int  TUTORdraw_dot(long  x1,long  y1);
int  TUTORdraw_line(long  x1,long  y1,long  x2,long  y2);
int  TUTORline_to(long  x,long  y);
int  TUTORend_line(long  x,long  y);
int  TUTORdraw_polyline(int  num_pts,long  *x,long  *y);
int  TUTORdraw_rectangle(long  x1,long  y1,long  x2,long  y2);
int  TUTORdraw_arc(int  calledby,long xc,long yc,double radius,long  x1,long  y1,long  x2,long  y2,
 double  startAngle,double  stopAngle,int  unbroken);
extern int  GetQuads(int  fullCircle,int  unbroken,int  x,int  y,int  startQuad,int  stopQuad,int  completeQuads,int  flipBool,int  startX,int  startY,int  stopX,int  stopY);
extern int  Set4Pixels(int  x,int  y,int  xc,int  yc,int  quads,int  coarse,double  sin_r,double  cos_r,double  rotation);
int  TUTORfill_rectangle(long  x1,long  y1,long  x2,long  y2);
int  TUTORerase_solid_rect(long  x1,long  y1,long  x2,long  y2);
int  TUTORfill_polygon(int  npoints,long  *fx,long  *fy);
int  TUTORfill_disk(int type,long xc,long yc,long  x1,long  y1,long  x2,long  y2);
int  writetext(unsigned int  textDoc,long  startSel,long  endSel,int  nDig,int  nMin);
unsigned int  dtextv(void);
int  write_abs_text(unsigned int  textDoc,long  startSel,long  endSel,int  xstart,int  ystart,struct  _trect FAR *marginR,int  wrap,int  *maxX,int  *maxY);
int  TUTORabs_move_to(int  x,int  y);
int  lclocy(long  q);
int  lclocx(long  q);
int  TUTORfill_abs_rect(struct  _trect FAR *tr,int  pattInd,int  pattC);
int  TUTORset_rect(struct  _trect *r,int  left,int  top,int  right,int  bottom);
int  TUTORdraw_graphic_icons(int  iconFont,char  *s,int  len);
int  TUTORdraw_alpha_icons(int  iconFont,char  *s,int  len);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
unsigned char SHUGE *LockStack(void);
int  TUTORabs_line_to(int  x,int  y);
int  TUTORabs_draw_dot(int  ix1,int  iy1);
extern int TUTORzero(char SHUGE *ptr,long lth);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
int  ReleaseStack(void);
int  TUTORflush(void);
int  TUTORset_abs_clip_rect(struct  _trect FAR *cr);
extern double fabs(double x);
int  TUTORframe_abs_rect(struct  _trect FAR *tr);
int  OrderRect(struct  _trect FAR *rp);
extern double sqrt(double x);
extern double sin(double x);
extern double cos(double x);
int  ShowTOffset(unsigned int  doc,long  pos,int  nDig,int  nMin);
int  TUTORdefault_styles_font_doc(int  font,unsigned int  doc);
int  TUTORabs_fill_disk(int type,long xc,long yc,struct  _trect *rp,int  pFont,int  pChar);
int  TUTORabs_fill_polygon(int  npoints,long  *fx,long  *fy);
int  TUTORabs_erase_rect(struct  _trect *tr,int  pattInd,int  pattC);
long  DivCoord(long  xx,long  yy);
long  IntToCoord(int  xx);
int  TUTORinq_abs_pen_pos(int  *x,int  *y);
int  TUTORdraw_doc(unsigned int  doc,long  pos,long  len,struct tutorColor FAR *fc,int	left,int  width,int  height,int  wordB,int  nLines,char  FAR *cliLay,int  pStart,int  *lastHeight,int  *maxH,int SupSubAdj);
int  TUTORintersect_rect(struct  _trect FAR *r1,struct  _trect FAR *r2,struct  _trect FAR *rdest);
int  TUTORinq_abs_clip_rect(struct  _trect *cr);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
int  TUTORinq_font_info(int  *ascent,int  *descent,int  *maxwidth,int  *leading);
int  RoundCoord(long  xx);
extern int TUTORnew_touch(int wn,Memh objH,int objR,struct _trect *rr);
extern int proctouch(Memh bH, struct tutorevent *event);
extern Memh TUTORhandle(char *name,long size, int purge);
extern  struct tutorview FAR *TUTORinit_view(int sW,unsigned int vDat,int (*vProc)());
extern  struct tutorview FAR *TUTORinq_view(void );
extern  int TUTORset_view(struct tutorview FAR *vp);
extern  int TUTORset_abs_view_rect(int x1,int y1,int w,int h);
extern int TUTORclose_touch(Memh tH);
extern int  TUTORclose_view(struct  tutorview FAR *vp);
extern int  procexecwstub(unsigned int  wh,struct  tutorevent *event);
extern int TUTORset_touch_unit(Memh tH,int index,int unitF,int unitN,double unitA);
#endif /* ctproto */

#ifdef macproto
extern int TUTORdump(char *msg);
#endif

static int GetQuads();
static int Set4Pixels();
extern int CurrentMode;
extern unsigned char SHUGE *LockStack();
extern Memh TextBoxKView();
extern Memh dtextv();
extern double CoordToFloat();
extern long  DivCoord();
extern long  IntToCoord();
extern double fabs();
extern double sqrt();
extern double sin();
extern double cos();
extern char  FAR *GetPtr();
extern unsigned char  SHUGE *LockStack();
extern int proctouchstub();
extern  struct tutorview FAR *TUTORinq_view();
extern int  procexecwstub();
extern  struct tutorview FAR *TUTORinit_view();

struct touchDat {
	int wn; /* index of window */
	struct tutorview FAR *view; /* touch area view */
	struct tutorview FAR *parent; /* parent view */
	Memh ebshdrH; /* handle on object header */
	int ebsRef; /* reference count on cT object header */
	int priority; /* priority of touch region */
	int doubleF; /* non-zero if processing double click */
	int ldownF; /* TRUE if have left-down but no up yet */
	int rdownF; /* TRUE if have right-down but no up yet */
	char unitF[9]; /* non-zero if cT unit to invoke */
                   /* = 0 = no unit */
                   /* = 1 = unit, no arguments */
                   /* = 2 = unit + value argument */
    int unitN[9]; /* unit number to invoke */
    double unitA[9]; /* argument to pass to unit */
}; /* touchDat */

/* ******************************************************************* */

int TUTORnew_touch(wix,objH,objR,tR)
int wix; /* index of window */
Memh objH; /* handle on object header */
int objR; /* object reference count */
struct _trect *tR; /* enclosing rectangle */

{	Memh tH; /* handle on touch region data */
	struct touchDat FAR *tP; /* pointer to touch region data */
	struct tutorview FAR *cV; /* current view */
	int width; /* width of touch area */
	int height; /* height of touch area */

	tH = TUTORhandle("touchdat",(long)sizeof(struct touchDat),TRUE);
	if (!tH)
		return(0); /* couldn't create data structure */
		
	tP = (struct touchDat FAR *)GetPtr(tH);
	TUTORzero((char SHUGE *)tP,(long)sizeof(struct touchDat));
	cV = TUTORinq_view();
	tP->wn = wix; /* window containing area */
	tP->view = TUTORinit_view(wix,tH,proctouchstub); /* view on area */
	TUTORset_view(tP->view);
	tP->ebshdrH = objH; /* cT object header */
	tP->ebsRef = objR; /* reference count on cT object header */
	width = tR->right-tR->left+1;
	height = tR->bottom-tR->top+1;
	TUTORset_abs_view_rect(tR->left,tR->top,width,height);
	tP->parent = cV; /* parent view */
	
	TUTORset_view(cV); /* restore the view */
	ReleasePtr(tH);
	return(tH);

} /* TUTORnew_touch */

/* ******************************************************************* */

int TUTORclose_touch(tH)
Memh tH; /* handle on touch region data */
	
{	struct touchDat FAR *tP; /* pointer to touch region dat (tH) */
	struct tutorview FAR *tV; /* pointer to touch region view */
	
	if (!tH)
		return(0);
	
	tP = (struct touchDat FAR *) GetPtr(tH);
	tV =  tP->view;
	ReleasePtr(tH);
	TUTORclose_view(tV); /* this will call proctouch with destroy message */
	
	return(0);
	
} /* TUTORclose_touch */

/* ******************************************************************* */

int TUTORset_touch_unit(tH,index,unitF,unitN,unitA)
Memh tH; /* handle on touch area info */
int index; /* event type (TR_LDOWN, etc) */
int unitF; /* 0 = no unit, 1 = unit, no argument, 2 = unit + argument */
int unitN; /* unit number */
double unitA; /* argument to unit */

{	struct touchDat FAR *tP; /* pointer to touch info */

	if (!tH)
		return(0); /* nothing to do */
	if ((index < 0) || (index > 8))
		return(0);
	tP = (struct touchDat FAR *)GetPtr(tH);
	tP->unitF[index] = unitF;
	tP->unitN[index] = unitN;
	tP->unitA[index] = unitA;
	ReleasePtr(tH);
	return(0);
	
} /* TUTORset_touch_unit */

/* ******************************************************************* */

int TUTORset_touch_priority(tH,priority) /* set front/back priority */
Memh tH; /* handle on touch data */
int priority; /* front/back priority of region */

{	struct touchDat FAR *tP; /* pointer to touch data */

	if (!tH)
		return(0); /* nothing to do */
	tP = (struct touchDat FAR *)GetPtr(tH);
	tP->priority = priority;
	tP->view->priority = priority;
	ReleasePtr(tH);
	return(0);
	
} /* TUTORset_touch_priority */

/* ******************************************************************* */

struct tutorview FAR *TUTORinq_touch_view(tH)
Memh tH; /* handle on touch data */

{	struct touchDat FAR *tP;
	struct tutorview FAR *viewP;

	if (!tH) return(FARNULL);
	
	tP = (struct touchDat FAR *)GetPtr(tH);
	viewP = tP->view;
	ReleasePtr(tH);
	return(viewP);
	
} /* TUTORinq_touch_view */

/* ******************************************************************* */

int proctouch(tH,event)
Memh tH;
struct tutorevent *event;

{	struct touchDat FAR *tP; /* pointer to touch area data */
	struct tutorevent cev; /* event to send to exector */
	int Index; /* index in unit tables */
	int dIndex; /* index in unit tables */
	struct tutorevent FAR *keventP; /* pointer to saved zkey event */
	short xx,yy; /* position of double-click */
	int isDouble; /* TRUE if double-click */
	struct ebshdr FAR *ebsP; /* pointer to object header */

	tP = (struct touchDat FAR *)GetPtr(tH);
	if (event->type != EVENT_DESTROY) {
    	if (tP->ebshdrH) {
    		ebsP = (struct ebshdr FAR *)GetPtr(tP->ebshdrH);
    		if (ebsP->inhibitF) 
    			event->type = -1; /* suppress event if object inhibited */
    		ReleasePtr(tP->ebshdrH);
    	}
    }
    	
	Index = dIndex = -1;
	switch (event->type) {
	
	case EVENT_LEFTDOWN:
	case EVENT_RIGHTDOWN:
		isDouble = TUTORdouble_click(&xx,&yy);
		if (event->type == EVENT_LEFTDOWN) {
			tP->ldownF = TRUE;
			if (isDouble)
				dIndex = TR_LDOUBLE;
		} else {
			tP->rdownF = TRUE;
			if (isDouble)
				dIndex = TR_RDOUBLE;
		}
		if (isDouble && tP->unitF[dIndex]) {
			tP->doubleF = dIndex;
		} else {
			if (event->type == EVENT_LEFTDOWN) {
				Index = TR_LDOWN;
			} else {
				Index = TR_RDOWN;
			}
		}
		break;
		
	case EVENT_LEFTUP:
	case EVENT_RIGHTUP:
		if (event->type == EVENT_LEFTUP) {
			if (!tP->ldownF) { /* up without down */
				tP->doubleF = 0;
				break; /* don't generate event */
			}
			tP->ldownF = FALSE;
		} else {
			if (!tP->rdownF) { /* up without down */
				tP->doubleF = 0;
				break; /* don't generate event */
			}
			tP->rdownF = FALSE;
		}
		if (tP->doubleF) {
			if (event->type == EVENT_LEFTUP) {
				dIndex = TR_LDOUBLE;
				windowsP[tP->wn].ldowntime1 = 0;
			} else {
				dIndex = TR_RDOUBLE;
				windowsP[tP->wn].rdowntime1 = 0;
			}
		}
		if (dIndex == tP->doubleF) {
			Index = tP->doubleF;
			tP->doubleF = 0;
		} else {
			if (event->type == EVENT_LEFTUP) 
				Index = TR_LUP;
			else
				Index = TR_RUP;
		}
		break;
		
	case EVENT_DOWNMOVE:
		if (!tP->doubleF) {
			if (tP->ldownF) Index = TR_LMOVE;
			if (tP->rdownF && tP->unitF[TR_RMOVE]) Index = TR_RMOVE;
		}
		break;
		
	case EVENT_UPMOVE:
		if ((event->x >= tP->view->rr.left) && (event->x <= tP->view->rr.right) &&
		    (event->y >= tP->view->rr.top) && (event->y <= tP->view->rr.bottom)) {
			if (!tP->doubleF) 
				Index = TR_UPMOVE;
		}
		break;
		
	case EVENT_VFOCUS:
		if (event->value) { /* actually set focus to owner's view */
			TUTORset_key_focus(tP->parent->window,tP->parent,FALSE);
			windowsP[tP->wn].MenuFocus = tP->view;
		}
		/* we don't care about losing focus */
		break;
		
	case EVENT_DESTROY:
		ReleasePtr(tH);
		TUTORfree_handle(tH); /* free memory associated with touch region */
		return(0);
	
	default:
		break;
		
	} /* switch */
	
	/* generate event to drive unit */
	
	if ((Index >= 0) && (tP->unitF[Index])) {
		TUTORzero((char SHUGE *)&cev,(long)sizeof(struct tutorevent));
		cev.type = EVENT_SIGNAL;
		cev.window = -1; /* not sent to window */
		keventP = (struct tutorevent FAR *)TUTORalloc((long)sizeof(struct tutorevent),TRUE,"touch");
		cev.eDataP = (char FAR *)keventP;
		*keventP = *event; /* save event for later zkey setting */
#ifdef THINKC5
		cev.vproc = (int(*)(...))(procexecwstub); /* procedure to invoke */
#else
		cev.vproc = (int(*)())(procexecwstub); /* procedure to call */
#endif
		cev.view = tP->view;
		cev.a5 = (long)tH; /* handle on touch data */
		cev.timestamp = 0;
		if (tP->unitF[Index] == 2) cev.a1 = BUTTONSIGNALA; /* unit has argument */
		else cev.a1 = BUTTONSIGNAL; /* no argument */
		cev.a2 = tP->ebshdrH; /* cT object header */
		cev.a6 = tP->ebsRef;
		cev.a3 = tP->unitA[Index]; /* unit argument */
		cev.value = tP->unitN[Index]; /* unit number */
		TUTORpost_event(&cev); /* post event to executor */
		TellExecInt(); /* tell executor to interrupt */
	}
	ReleasePtr(tH);
    return(0);
    
} /* proctouch */

/* ******************************************************************* */

ClearAuthorFile(vloc)		/* author file is closing, take care of stack */
long vloc;			/* stack offset of file variable */
{
    unsigned char FAR *cp;

    cp = LockStack();
    cp += vloc;			/* point to file variable */
    *((long FAR *) (cp)) = -1;	/* clear author variable */
    
}

/* ********************************************************** */

TUTORdraw_icons(is, len)
char *is;
int len;			/* # of chars to draw */
{
    struct tutorfont FAR *tf;
    short fType, fAlpha;

#ifdef NoASuch
    tf = exS.iconFont + (struct tutorfont FAR *) GetPtr(fonts);
    fType = tf->basicType;
    fAlpha = tf->alphaIcon;
    ReleasePtr(fonts);
    KillPtr(tf);
    if (fType == FONTF || fAlpha)
	TUTORdraw_alpha_icons(exS.iconFont, is, len);
    else
#endif
	TUTORdraw_graphic_icons(exS.iconFont, is, len);
}

/* *********************************************************** */
TUTORthick_box(x1, y1, x2, y2, thick, thickx, thicky)
/* the thick box is drawn of four filled rectangles (trapezoids) */
Coord x1, y1, x2, y2, thick, thickx, thicky;
{
    int ix1, iy1, ix2, iy2;	/* inner x,y */
    int ox1, oy1, ox2, oy2;	/* outer x,y */
    Coord hx, hy;
    TRect tr;

    /* set corners so x1,y1 is upper-left  */
    if (x2 < x1) {
	hx = x1;
	x1 = x2;
	x2 = hx;
    }
    if (y2 < y1) {
	hy = y1;
	y1 = y2;
	y2 = hy;
    }
    if (thick > coordZero) {	/* thickness added outwards */
	ix1 = lclocx(x1) + exS.OffsetX;
	iy1 = lclocy(y1) + exS.OffsetY;
	ix2 = lclocx(x2) + exS.OffsetX;
	iy2 = lclocy(y2) + exS.OffsetY;
	ox1 = lclocx(x1 - thickx) + 1 + exS.OffsetX;
	oy1 = lclocy(y1 - thicky) + 1 + exS.OffsetY;
	ox2 = ix2 + (ix1 - ox1);
	oy2 = iy2 + (iy1 - oy1);
    } else {
	ox1 = lclocx(x1) + exS.OffsetX;
	oy1 = lclocy(y1) + exS.OffsetY;
	ox2 = lclocx(x2) + exS.OffsetX;
	oy2 = lclocy(y2) + exS.OffsetY;
	ix1 = lclocx(x1 - thickx) - 1 + exS.OffsetX;
	iy1 = lclocy(y1 - thicky) - 1 + exS.OffsetY;
	ix2 = ox2 - (ix1 - ox1);
	iy2 = oy2 - (iy1 - oy1);
    }

	TUTORset_rect(&tr,ox1, oy1, ox2, iy1);
    TUTORfill_abs_rect(&tr, exS.patternFont, exS.patternChar);
    tr.top = iy2;
    tr.bottom = oy2;
    TUTORfill_abs_rect(&tr, exS.patternFont, exS.patternChar);
    tr.top = iy1+1;
    tr.bottom = iy2-1;
    tr.right = ix1;
    TUTORfill_abs_rect(&tr, exS.patternFont, exS.patternChar);
    tr.left = ix2;
    tr.right = ox2;
    TUTORfill_abs_rect(&tr, exS.patternFont, exS.patternChar);
}

TUTORmove_to(x, y)		/* set current screen location */
/* f fine coordinates */
Coord x, y;

{
    register int ix, iy;

    ix = lclocx(x);
    iy = lclocy(y);

    TUTORabs_move_to(ix + exS.OffsetX, iy + exS.OffsetY);

}				/* TUTORmove_to */

/* ******************************************************** */

TUTORset_clip_rectangle(x1, y1, x2, y2)
/* expects ordered corners of clip region */
Coord x1, y1, x2, y2;

{
    register int ix1, iy1, ix2, iy2;
    TRect tr;

    /* if clip region is entirely outside active region, set points to 0,0 */
    /* (0,0 is used for clip-everything, as in inhibit display) */

    if ((x2 < exS.RegionXmin) || (y2 < exS.RegionYmin))
	x1 = y1 = x2 = y2 = coordZero;
    else if ((x1 > exS.RegionXmax) || (y1 > exS.RegionYmax))
	x1 = y1 = x2 = y2 = coordZero;

    /* else check individual points */
    else {
	if (x1 < exS.RegionXmin)
	    x1 = exS.RegionXmin;
	if (y1 < exS.RegionYmin)
	    y1 = exS.RegionYmin;
	if (x2 > exS.RegionXmax)
	    x2 = exS.RegionXmax;
	if (y2 > exS.RegionYmax)
	    y2 = exS.RegionYmax;
    }

    ix1 = lclocx(x1);
    iy1 = lclocy(y1);
    ix2 = lclocx(x2);
    iy2 = lclocy(y2);

	tr.left = exS.OffsetX + ix1;
	tr.top = exS.OffsetY + iy1;
	tr.right = exS.OffsetX + ix2;
	tr.bottom = exS.OffsetY + iy2;
    TUTORset_abs_clip_rect((TRect FAR *) &tr);

#ifdef DOPSCRIPT
    if (pscript) {
	sprintf(PSbuff, "%d %d %d %d SetClipRectangle \n", ix1, iy1, ix2, iy2);
	PostScriptOutput(PSbuff);
    }
#endif
}

#ifdef MAC
#ifdef THINKC5
#include <Windows.h>
#include <Memory.h>
#else
#ifdef WERKS
#include <Windows.h>
#include <Memory.h>
#else
#include <WindowMgr.h>
#endif
#endif

static PicHandle bufferPict = NIL;

SetFlushState(arg)		/* inhibit or allow update KSW */
int arg;			/* 0: inhibit flushes, 1: restart flushes
				 * (draw what's done), -1: discard what's
				 * stored */
{
    WindowPtr curPort;

    GetPort(&curPort);
    switch (arg) {
    case 0:
	if (!bufferPict)
	    bufferPict = OpenPicture(&curPort->portRect);
	/* NOTE: clipRegion??, check for already open Picture?? */
	break;
    case 1:
    case -1:
	if (bufferPict) {
	    ClosePicture();
	    if (arg == 1)
		DrawPicture(bufferPict, &curPort->portRect);
	    KillPicture(bufferPict);
	    bufferPict = NIL;
	}
	break;
    }
}

flush()
{				/* flush out pending output */
    exS.outcnt = 0;
    if (bufferPict && GetHandleSize((Handle)bufferPict) > 10000L)
	TUTORdump("inhibit update picture too big");
    return;
}
#else
/*************************************************************************/

SetFlushState(flag)		/* inhibit or allow update KSW */
int flag;			/* 0: inhibit flushes, 1: restart flushes
				 * (draw what's stored), -1: discard what's
				 * stored */
{
    switch (flag) {
    case 0:
	flush();		/* to finish drawing previous stuff */
	exS.outcnt = -20000;	/* so future flushes do nothing */
	break;
    case 1:
    case -1:			/* andrew can't just toss the accummulated
				 * draws... */
	exS.outcnt = 1;	/* so the next flush does something */
	flush();
	break;
    }
}

/* ******************************************************************* */

flush()
{				/* flush out pending output */
    if (exS.outcnt < 0) {
	exS.outcnt = -20000;
	return(0);
    }
    exS.outcnt = 0;
    TUTORflush();

}				/* flush */


#endif

exec_switch_fixup() /* minimize executor stack for switch-file */

{	char FAR *stackp;

    free_snapShot(); /* release current executor snapshot */
	/* cut run-time stack down to small size */
	if (exS.stackmalloc > 1000) {
		exS.stackmalloc = 1000;
		ReleaseStack(); /* allow stack memory move */
		TUTORset_hsize(exS.stackH, 1000L, TRUE);	/* make the stack small */
		stackp = GetPtr(exS.stackH);
		TUTORzero((char SHUGE *) stackp, 1000L);	/* zero remaining stack */
		ReleasePtr(exS.stackH);
		KillPtr(stackp);
	} /* stackmalloc if */

} /* exec_switch_fixup */

/* ******************************************************************* */



TUTORdraw_dot(x1, y1)		/* make a dot */
Coord x1, y1;			/* fine coords */
{
    register int ix1, iy1;

    ix1 = lclocx(x1);
    iy1 = lclocy(y1);
    TUTORabs_draw_dot(ix1 + exS.OffsetX, iy1 + exS.OffsetY);

#ifdef DOPSCRIPT
    if (PostscriptFlag) {
	sprintf(PSbuff, "%d %d Dot \n", ix1, iy1);
	PostScriptOutput(PSbuff);
    }
#endif

    return(0);
}

/* ******************************************************************* */

TUTORdraw_line(x1, y1, x2, y2)	/* single line segment */
Coord x1, y1, x2, y2;		/* fine coords */
{
    register int ix1, iy1, ix2, iy2;

    ix1 = lclocx(x1);
    iy1 = lclocy(y1);
    ix2 = lclocx(x2);
    iy2 = lclocy(y2);

    TUTORabs_move_to(ix1 + exS.OffsetX, iy1 + exS.OffsetY);
    TUTORabs_line_to(ix2 + exS.OffsetX, iy2 + exS.OffsetY);
#ifdef DOPSCRIPT
    if (PostscriptFlag) {
	sprintf(PSbuff, "%d %d %d %d DrawLine \n", ix1, iy1, ix2, iy2);
	PostScriptOutput(PSbuff);
    }
#endif
}

/* ******************************************************************* */

TUTORline_to(x, y)		/* draw line from current screen location */
Coord x, y;			/* fine coords */
{
    register int ix, iy;

    ix = lclocx(x);
    iy = lclocy(y);

#ifdef DOPSCRIPT
    if (PostscriptFlag) {
	sprintf(PSbuff, " %d %d lineto", ix, iy);
	PostScriptOutput(PSbuff);
    }
#endif

    ix = ix + exS.OffsetX;
    iy = iy + exS.OffsetY;

    TUTORabs_line_to(ix, iy);

    return(0);

} /* TUTORline_to */

/* ******************************************************************* */

TUTORend_line(x, y)		/* finish line from current screen location */
Coord x, y;
{
    register int ix, iy;

    ix = lclocx(x);
    iy = lclocy(y);

    TUTORabs_line_to(ix + exS.OffsetX, iy + exS.OffsetY);

#ifdef DOPSCRIPT
    if (pscript) {
	sprintf(PSbuff, " %d %d lineto stroke \n", ix, iy);
	PostScriptOutput(PSbuff);
    }
#endif

    return(0);

} /* TUTORend_line */

/* ******************************************************************* */

TUTORdraw_polyline(num_pts, x, y)	/* several connected lines */
int num_pts;			/* number of points, not counting x[0],y[0],
				 * the starting loc. */
Coord x[], y[];
{
    register int ii, ix, iy;

    ix = lclocx(*x);
    iy = lclocy(*y);

    TUTORabs_move_to(ix + exS.OffsetX, iy + exS.OffsetY);

#ifdef DOPSCRIPT
    if (pscript) {
	sprintf(PSbuff, "%% polyline:\nnewpath %d %d moveto ", ix, iy);
	PostScriptOutput(PSbuff);
    }
#endif

    for (ii = 1; ii <= num_pts; ii++) {
	ix = lclocx(*(++x));
	iy = lclocy(*(++y));

	TUTORabs_line_to(ix + exS.OffsetX, iy + exS.OffsetY);
#ifdef DOPSCRIPT
	if (pscript) {
	    sprintf(PSbuff, " %d %d lineto", ix, iy);
	    PostScriptOutput(PSbuff);
	}
#endif
    }
#ifdef DOPSCRIPT
    if (pscript) {
	sprintf(PSbuff, " stroke\n");
	PostScriptOutput(PSbuff);
    }
#endif
}

/* ******************************************************************* */

TUTORdraw_rectangle(x1, y1, x2, y2)	/* open rectangle, 1 line thick */
Coord x1, y1, x2, y2;
{
    register int ix1, iy1, ix2, iy2;
    TRect rr;
    register TRect *rp;

    ix1 = lclocx(x1);
    iy1 = lclocy(y1);
    ix2 = lclocx(x2);
    iy2 = lclocy(y2);

#ifdef DOPSCRIPT
    if (pscript) {
	sprintf(PSbuff, "%d %d %d %d Box\n", ix1, iy1, ix2, iy2);
	PostScriptOutput(PSbuff);
    }
#endif

    rp = &rr;
    rp->left = ix1 + exS.OffsetX;
    rp->top = iy1 + exS.OffsetY;
    rp->right = ix2 + exS.OffsetX;
    rp->bottom = iy2 + exS.OffsetY;
    /* swap coords if neccesary */
    OrderRect((TRect FAR *) rp);
    TUTORframe_abs_rect((TRect FAR *) rp);
    TUTORabs_move_to(rr.left, rr.top);

    return(0);
}

/* ******************************************************** */

TUTORline_thick(thickV) /* set line thickness */
int thickV; /* 0 for normal line, +n thickness */

{
	lineThick = thickV;
	
} /* TUTORline_thick */

/* ********************************************************* */

#define QUAD_1 0x1
#define QUAD_2 0x2
#define QUAD_3 0x4
#define QUAD_4 0x8

static int lastx = -1;
static int lastquads = 0;

TUTORdraw_arc(calledby, xc,yc,xyradius,x1, y1, x2, y2, startAngle, stopAngle, unbroken)
/* draws full circles & arcs; solid or dashed */
/* rotation is not passed; it comes from a global variable */
int calledby; /* 1 = circle  (radius) */
              /* 2 = gcircle (radius) */
              /* 3 = rcircle (radius) */
              /* 4 = circle  (rectangle) */
              /* 5 = gcircle (rectangle) */
              /* 6 = rcircle (rectangle) */
Coord xc, yc, x1, y1, x2, y2; /* center and corners of bounding box */
double xyradius;
double startAngle, stopAngle;	/* expects angles in degrees */
int unbroken;			/* 1 if unbroken, 0 if dashed */

{   int tempi, ix1, ix2, iy1, iy2, xcenter, ycenter, xradius, yradius, x, y, fullCircle;
    int quads, completeQuads, stopQuad, startQuad, flipBool, flipCount, flipHz, startX;
    int startY, stopX, stopY, coarse;
    long xrsquared, yrsquared, two_xrsq, two_yrsq, d, dx, dy, templ;
    double tempd, rotation, sin_r, cos_r, arcAngle;
    int use_trig; 
    int relative; /* TRUE if relative */
    
    lastx = -1;
    lastquads = 0;
    ix1 = lclocx(x1) + exS.OffsetX;		/* get true screen location */
    ix2 = lclocx(x2) + exS.OffsetX;
    iy1 = lclocy(y1) + exS.OffsetY;
    iy2 = lclocy(y2) + exS.OffsetY;
    
    if (ix2 < ix1) {		/* make sure ix2 >= ixi */
		tempi = ix1;
		ix1 = ix2;
		ix2 = tempi;
	}
	if (iy2 < iy1) {		/* ditto for iy2 >= iy1 */
		tempi = iy1;
		iy1 = iy2;
		iy2 = tempi;
    }

    if (calledby >= 4) {
    	xradius = ((ix2-ix1)/2);
    	yradius = ((iy2-iy1)/2);
    	xcenter = ix1+xradius;
    	ycenter = iy1+yradius;
    	startAngle = 0.0;
    	stopAngle = 360.0;
    } else {
    	xcenter = lclocx(xc)+exS.OffsetX;
    	ycenter = lclocy(yc)+exS.OffsetY;
    	xradius = (ix2 - xcenter) ;	/* 0.5 pixels may be lost because of rounding */
		yradius = (iy2 - ycenter) ;
	}
	
    arcAngle = stopAngle-startAngle;
 	relative = ((calledby == 3) || (calledby == 6));
 	if (calledby == 3)
 		rotation = exS.RAngle;
	else
		rotation = 0.0; 

    /* too small/thin to draw */
	if ((xradius == 0) || (yradius == 0) || (arcAngle == 0.0))
		return(0);

	if ((xradius > 32) && (yradius > 32))
		coarse = 1;
	else
		coarse = 0;

	if (fabs(arcAngle) >= 360.0) {
		fullCircle = TRUE;	/* full ellipse */
		quads = (QUAD_1 | QUAD_2 | QUAD_3 | QUAD_4);
		if (relative) {	/* rcircle */
			if ((rotation == 180.0) || (xradius == yradius))
				rotation = 0.0;
			else if ((rotation == 90.0) || (rotation == 270.0)) {
				tempi = xradius;
				xradius = yradius;
				yradius = tempi;
				rotation = 0.0;
			}
			if (fabs(exS.RXsize) == fabs(exS.RYsize))
				rotation = 0.0; /* circle, not elipse */
		} else			/* Not rcircle */
			rotation = 0.0;

	    if (unbroken && (lineThick == 0) && 
	       ((!relative) || rotation == 0.0)) {
#ifdef MAC
			/* draw using Mac toolbox */
			Rect rr;
			
			if (calledby >= 4) { /* given as rectangle */
				SetRect(&rr,ix1,iy1,ix2+1,iy2+1);
			} else { /* given as center, radius */
				SetRect(&rr,xcenter-xradius,ycenter-yradius,
						xcenter+xradius+1,ycenter+yradius+1);
			}
			FrameOval(&rr);
			return(0);
#endif
#ifdef WINPC
			if (calledby >= 4) { /* given as rectangle */
				win_circle(ix1,iy1,ix2,iy2);
			} else { /* given as center, radius */
				win_circle(xcenter-xradius,ycenter-yradius,
			           xcenter+xradius,ycenter+yradius);
			}
			return(0);
#endif
        } /* unbroken if */
	} else {			/* Not a full circle */
		fullCircle = FALSE;
		use_trig = TRUE; /* short out bressenham for arcs */
		
		if (relative) {
			if (xradius == yradius) {
				/* startAngle += rotation; */  /* applied in trig-arc */
				rotation = 0.0;
			}
		} else			/* Not rcircle */
			rotation = 0.0;
		
		if (arcAngle < 0.0) {	/* adjust start Angle and arcAngle so we draw in a positive direction */
			startAngle = startAngle + arcAngle;
			arcAngle = -arcAngle;
		}
		while (startAngle >= 360.0) /* make 0.0 <= startAngle < 360.0 */
			startAngle -= 360.0;
			
		while (startAngle < 0.0)
			startAngle += 360.0;
		stopAngle = startAngle + arcAngle;
		
		/* check for cases bresenham can't handle */
	
		if ((relative) && ((exS.RXsize < 0) || (exS.RYsize < 0)))
			use_trig = TRUE;
		else if (!fullCircle)
			use_trig = TRUE;
		else if (lineThick)
			use_trig = TRUE;
		if (use_trig) {
			trig_arc(calledby,xcenter,ycenter,xyradius,startAngle,stopAngle,!unbroken);
			return(0);
		}

		startQuad = stopQuad = completeQuads = 0x0;

		/* calculate which quads can be drawn completely */
		if (((startAngle == 0.0) && (stopAngle >= 90.0)) || (stopAngle >= 450.0))
			completeQuads |= QUAD_1;
		if (((startAngle <= 90.0) && (stopAngle >= 180.0)) || (stopAngle >= 540.0))
			completeQuads |= QUAD_2;
		if (((startAngle <= 180.0) && (stopAngle >= 270.0)) || (stopAngle >= 630.0))
			completeQuads |= QUAD_3;
		if ((startAngle <= 270.0) && (stopAngle >= 360.0))
			completeQuads |= QUAD_4;

		/* determine which quad we start in */
		if (startAngle < 90.0)
			startQuad = QUAD_1;
		else if (startAngle < 180.0)
			startQuad = QUAD_2;
		else if (startAngle < 270.0)
			startQuad = QUAD_3;
		else
			startQuad = QUAD_4;

		if (stopAngle >= 360.0)	/* make 0.0 <= stopAngle < 360.0 */
			stopAngle -= 360.0;

		/* determine which quad we stop in */
		if (stopAngle < 90.0)
			stopQuad = QUAD_1;
		else if (stopAngle < 180.0)
			stopQuad = QUAD_2;
		else if (stopAngle < 270.0)
			stopQuad = QUAD_3;
		else
			stopQuad = QUAD_4;

		/* reduce startAngle and stopAngle to the first quadrant */
		while (startAngle >= 90.0)
			startAngle -= 90.0;
		while (stopAngle >= 90.0)
			stopAngle -= 90.0;

		if (startQuad & (QUAD_2 | QUAD_4))
			startAngle = 90.0 - startAngle;
		if (stopQuad & (QUAD_2 | QUAD_4))
			stopAngle = 90.0 - stopAngle;

		/* Find where on the x- and y-axes we want to start and stop.
			this is actually pretending we have a circle of radius 1,
			taking the point (0,1), and rotating it by the angle.  It
			has to be multiplied by the radius to compensate for the
			fact that the radius isn't really 1. */
		tempd = startAngle*pi/180.0;
		startX = xradius*(cos(tempd));
		startY = yradius*(sin(tempd));
		tempd = stopAngle*pi/180.0;
		stopX = xradius*(cos(tempd));
		stopY = yradius*(sin(tempd));
		if (stopQuad == startQuad) {
			if (stopX < startX) {
				tempi = stopX;
				stopX = startX;
				startX = tempi;
			}
			if (stopY < startY) {
				tempi = stopY;
				stopY = startY;
				startY = tempi;
			}
		}
    }

	if (rotation == 0.0) {
		sin_r = 0.0;
		cos_r = 1.0;
	} else {
		sin_r = exS.RsinAngle;
		cos_r = exS.RcosAngle;
	}

	/* initialize the algorithm */
	x = 0;
	y = yradius;

	xrsquared = (long)xradius*(long)xradius;
	yrsquared = (long)yradius*(long)yradius;

	two_xrsq = 2*xrsquared;
    two_yrsq = 2*yrsquared;

	if (!unbroken) {
		templ = (xrsquared + yrsquared);
		tempd = sqrt((double) templ);
		tempi = templ/tempd;
		if (tempi < 6)
			flipHz = 1;
		else if (tempi < 16)
			flipHz = 2;
		else if (tempi < 26)
			flipHz = 3;
		else
			flipHz = 5;

		flipCount = 0;
		flipBool = 1;
	}

	d = yrsquared - xrsquared*yradius + xrsquared/4L;
	dx = 0L;
	dy = two_xrsq*yradius;

	/* take care of quadrant boundaries for mode xor, top and bottom */
	if ((CurrentMode == SRC_XOR) && unbroken && (completeQuads || (startQuad != stopQuad))) {
		if (fullCircle || (completeQuads & (QUAD_1 | QUAD_2)) || (stopQuad == QUAD_2)) {
			TUTORabs_draw_dot(xcenter + (int) (yradius*exS.RsinAngle),
								ycenter - (int) (yradius*exS.RcosAngle));
		}
		if (fullCircle || (completeQuads & (QUAD_3 | QUAD_4)) || (stopQuad == QUAD_4)) {
			TUTORabs_draw_dot(xcenter - (int) (yradius*exS.RsinAngle),
								ycenter + (int) (yradius*exS.RcosAngle));
		}
	}
	
	while (dx < dy) {
		if (!fullCircle || !unbroken) {
			quads = GetQuads(fullCircle, unbroken, x, y, startQuad, stopQuad,
					completeQuads, flipBool,
					startX, startY, stopX, stopY);
			if (!unbroken) {
				if (flipCount == flipHz) {
					flipCount = 0;
					flipBool = !flipBool;
				} else
					flipCount++;
			}
		}

		Set4Pixels(x, y, xcenter, ycenter, quads, coarse, sin_r, cos_r, rotation);

		if (d > 0L) {
			y--;
			dy -= two_xrsq;
			d -= dy;
		}

		x++;
		dx += two_yrsq;
		d += yrsquared + dx;
	}

    d += (3L * (xrsquared - yrsquared)/2L - (dx + dy)) / 2L;

    while (y >= 0) {
	    if (!fullCircle || !unbroken) {
	        quads = GetQuads(fullCircle, unbroken, x, y, startQuad, stopQuad,
			     completeQuads, flipBool,
			     startX, startY, stopX, stopY);
	        if (!unbroken) {
		        if (flipCount == flipHz) {
		            flipCount = 0;
		            flipBool = !flipBool;
		        } else
		            flipCount++;
	        }
	    }

	    Set4Pixels(x, y, xcenter, ycenter, quads, coarse, sin_r, cos_r, rotation);

	    if (d < 0L) {
	       x++;
	       dx += two_yrsq;
	       d += dx;
	    }

	    y--;
	    dy -= two_xrsq;
	    d += xrsquared - dy;
    }

    /* finish drawing ellipse */
    Set4Pixels(0, 0, xcenter, ycenter, 0x0, coarse, sin_r, cos_r, rotation);

    /* take care of quadrant boundaries for mode xor */
    if ((CurrentMode == SRC_XOR) && unbroken && (completeQuads || (startQuad != stopQuad))) {
	    if (fullCircle || (completeQuads & (QUAD_1 | QUAD_4)) || (stopQuad == QUAD_1)) {
	          TUTORabs_draw_dot(xcenter + (int) (xradius*exS.RcosAngle),
	    					ycenter + (int) (xradius*exS.RsinAngle));
	    }
	    if (fullCircle || (completeQuads & (QUAD_2 | QUAD_3)) || (stopQuad == QUAD_3)) {
	        TUTORabs_draw_dot(xcenter - (int) (xradius*exS.RcosAngle),
	    					ycenter - (int) (xradius*exS.RsinAngle));
	    }
    } /* CurrentMode if */

	return(0);
	
} /* TUTORdraw_arc */

/* ******************************************************************* */

static int trig_arc(type,xcenter,ycenter,xyRadius,startAngle,stopAngle,broken)
int type;
int xcenter,ycenter;
double xyRadius,startAngle,stopAngle;
int broken;

{	double fromAngle,toAngle,stepAngle,angle,radians;
	double scaleX,scaleY;
	double Acos,Asin;
	double degcvt = 3.1415926535897932/180.0;
	int maxradius;
	int ix,iy,nx,ny,ox,oy;
	int first;
	int toggle;
	
	if ((xyRadius == 0.0) || (startAngle == stopAngle))
		return(0); /* nothing to do */
		
	if ((type == 1) || (type == 4)) { /* absolute */
		scaleX = scaleY = 1.0;
	} else if ((type == 2) || (type == 5)) { /* graphing */
		scaleX = exS.GXscale;
		scaleY = exS.GYscale;
	} else if (type == 3)  { /* relative, radius */
		scaleX = exS.RXsize;
		scaleY = exS.RYsize;
	} else if (type == 6) { /* relative, rectangle */
		scaleX = scaleY = 1.0;
	}
	if (exS.RescaleX) 
		scaleX *= CoordToFloat(exS.ScaleX);
	if (exS.RescaleY)
		scaleY *= CoordToFloat(exS.ScaleY); 
	
	if (stopAngle > startAngle) {
		fromAngle = startAngle;
		toAngle = stopAngle;
	} else {
		fromAngle = stopAngle;
		toAngle = startAngle;
	}	
	if (fabs(scaleX) > fabs(scaleY)) 
		maxradius = scaleX*xyRadius;
	else 
		maxradius = scaleY*xyRadius;
	maxradius = abs(maxradius);
	if ((toAngle-fromAngle) < 5.0)
		stepAngle = (toAngle-fromAngle)/3.0;
	else 
		stepAngle = 5.0;
  		
	angle = fromAngle;
	first = toggle = TRUE;
	while (angle <= toAngle) {
		radians = degcvt*angle;
		Acos = cos(radians);
		Asin = sin(radians);
		nx = ix = scaleX*xyRadius*Acos;
		ny = iy = scaleY*xyRadius*Asin;
		if (type == 3) { /* relative, radius */
			nx = ix*exS.RcosAngle-iy*exS.RsinAngle;
			ny = ix*exS.RsinAngle+iy*exS.RcosAngle;
		}
		if (!first) {
			if (!broken || toggle) {
				TUTORabs_move_to(xcenter+ox,ycenter+oy);
				TUTORabs_line_to(xcenter+nx,ycenter+ny);
			}
			if (angle < toAngle) { /* not done yet */
				angle += stepAngle;
				if (angle > toAngle)
					angle = toAngle; 
			} else angle += stepAngle; /* done, angle > toAngle */
			toggle = (toggle ? FALSE: TRUE);
		} else 
			first = FALSE;
		ox = nx;
		oy = ny;
	} /* angle while */

} /* trig_arc */

/* ******************************************************************* */

static int GetQuads(fullCircle, unbroken, x, y, startQuad, stopQuad, 
  completeQuads, flipBool, startX, startY, stopX, stopY)
int fullCircle, unbroken, x, y, startQuad, stopQuad, completeQuads;
int flipBool, startX, startY, stopX, stopY;

{   int quads, tempQuads;

    if (fullCircle) {
	    quads = (flipBool ? (QUAD_1 | QUAD_3) : (QUAD_2 | QUAD_4));
	    return(quads);
    }

    /* not fullCircle */
    if (unbroken) {
	    quads = completeQuads;
	    if (startQuad == stopQuad) {
	        if (completeQuads) {
		        if (((x >= stopX) && (y <= startY)) || ((x <= startX) && (y >= stopY))) {
		            quads |= startQuad;
		        }
	        } else {
		        if ((x >= startX) && (x <= stopX) && (y >= startY) && (y <= stopY)) {
		            quads |= startQuad;
		        }
	        }
	    } else {	/* startQuad != stopQuad */
	        if (stopQuad & (QUAD_1 | QUAD_3)) {
		        if ((x >= stopX) && (y <= stopY))
		            quads |= stopQuad;
	        } else {
		        if ((x <= stopX) && (y >= stopY))
		        quads |= stopQuad;
	        }
	        if (startQuad & (QUAD_1 | QUAD_3)) {
		        if ((x <= startX) && (y >= startY))
		            quads |= startQuad;
	        } else {
		    if ((x >= startX) && (y <= startY))
		        quads |= startQuad;
	        }
	    }
	    return(quads);
    }

    /* broken partial circle */

    tempQuads = (flipBool ? (QUAD_1 | QUAD_3) : (QUAD_2 | QUAD_4));
    quads = completeQuads & tempQuads;
    if (startQuad == stopQuad) {
	    if (completeQuads) {
	        if ((((x >= stopX) && (y <= startY)) || ((x <= startX) && (y >= stopY))) &&
		        ((startQuad & tempQuads) ||
		        ((x >= stopX) && (x <= stopX + 2) && (y >= startY - 2)) ||
		        ((x <= startX) && (x >= startX - 2) && (y <= stopY + 2))))
		        quads |= startQuad;
	    } else {
	        if ((x >= startX) && (y >= startY) && (x <= stopX) && (y <= stopY) &&
		        ((startQuad & tempQuads) ||
		        ((x <= startX + 2) && (y <= startY + 2)) ||
		        ((x >= stopX - 2) && (y >= stopY - 2))))
		        quads |= startQuad;
	    }
    } else {	/* startQuad != stopQuad */
	    if (stopQuad & (QUAD_1 | QUAD_3)) {
	        if ((x >= stopX) && (y <= stopY) &&
		       (flipBool || ((x <= stopX + 2) && (y >= stopY - 2))))
		        quads |= stopQuad;
	    } else {
	        if ((x <= stopX) && (y >= stopY) &&
		       (!flipBool || ((x >= stopX - 2) && (y <= stopY + 2))))
		        quads |= stopQuad;
	    }
	    if (startQuad & (QUAD_1 | QUAD_3)) {
	        if ((x <= startX) && (y >= startY) &&
		        (flipBool || ((x >= startX - 2) && (y <= startY + 2))))
		        quads |= startQuad;
	    } else {
	        if ((x >= startX) && (y <= startY) &&
		        (!flipBool || ((x <= startX + 2) && (y >= startY - 2))))
		        quads |= startQuad;
	    }
    } /* startQuad else */
    return(quads);

} /* GetQuads */

/* ******************************************************************* */

static int Set4Pixels(x, y, xc, yc, quads, coarse, sin_r, cos_r, rotation)
int x, y, xc, yc, quads, coarse;
double sin_r, cos_r, rotation;

{	static int lasty, newx, newy;
	int xr1,yr1,xr2,yr2;
 	int lastx_cos_r,lastx_sin_r,newx_cos_r,newx_sin_r;
 	int lasty_cos_r,lasty_sin_r,newy_sin_r,newy_cos_r;
 	
    if (lastx == -1) {
		if (quads) { 
	    	lastx = newx = x;
	    	lasty = newy = y;
		} 
		lastquads = quads;
		return(0);
    }
    
    if ((quads == lastquads) && ((x == lastx) || (y == lasty) || (coarse && (((x - lastx) < 3) || ((lasty - y) < 3))))) {
		newx = x;
		newy = y;
		return(0);
    }
    if (rotation == 0.0) {
		if (lastquads & QUAD_1) {
	    	TUTORabs_move_to(xc + (lastx), yc + (lasty));
	    	TUTORabs_line_to(xc + (newx), yc + (newy));
		}
		if (lastquads & QUAD_2) {
	    	TUTORabs_move_to(xc - (lastx), yc + (lasty));
	    	TUTORabs_line_to(xc - (newx), yc + (newy));
		}
		if (lastquads & QUAD_3) {
	    	TUTORabs_move_to(xc - (lastx), yc - (lasty));
	    	TUTORabs_line_to(xc - (newx), yc - (newy));
		}
		if (lastquads & QUAD_4) {
	    	TUTORabs_move_to(xc + (lastx), yc - (lasty));
	    	TUTORabs_line_to(xc + (newx), yc - (newy));
		}
    } else {
    	lastx_cos_r = lastx*cos_r;
    	lastx_sin_r = lastx*sin_r;
    	lasty_cos_r = lasty*cos_r;
    	lasty_sin_r = lasty*sin_r;
    	newx_cos_r = newx*cos_r;
    	newx_sin_r = newx*sin_r;
    	newy_cos_r = newy*cos_r;
    	newy_sin_r = newy*sin_r;
    	if (lastquads & QUAD_1) {
    		xr1 = lastx_cos_r-lasty_sin_r;
    		yr1 = lastx_sin_r+lasty_cos_r;
    		xr2 = newx_cos_r-newy_sin_r;
    		yr2 = newx_sin_r+newy_cos_r;
	    	TUTORabs_move_to(xc + (xr1), yc + (yr1));
	    	TUTORabs_line_to(xc + (xr2), yc + (yr2));
		}
		if (lastquads & QUAD_2) {
		   	xr1 = -lastx_cos_r-lasty_sin_r;
    		yr1 = -lastx_sin_r+lasty_cos_r;
    		xr2 = -newx_cos_r-newy_sin_r;
    		yr2 = -newx_sin_r+newy_cos_r;
	    	TUTORabs_move_to(xc +(xr1), yc + (yr1));
	    	TUTORabs_line_to(xc + (xr2), yc + (yr2));
		}
		if (lastquads & QUAD_3) {
		   	xr1 = -lastx_cos_r+lasty_sin_r;
    		yr1 = -lastx_sin_r-lasty_cos_r;
    		xr2 = -newx_cos_r+newy_sin_r;
    		yr2 = -newx_sin_r-newy_cos_r;
	    	TUTORabs_move_to(xc +(xr1), yc + (yr1));
	    	TUTORabs_line_to(xc +(xr2), yc + (yr2));
		}
		if (lastquads & QUAD_4) {
		    xr1 = lastx_cos_r+lasty_sin_r;
    		yr1 = lastx_sin_r-lasty_cos_r;
    		xr2 = newx_cos_r+newy_sin_r;
    		yr2 = newx_sin_r-newy_cos_r;
	    	TUTORabs_move_to(xc + (xr1), yc + (yr1));
	    	TUTORabs_line_to(xc + (xr2), yc + (yr2));
		}
#ifdef NoSucH
		lastx_sin_r = lastx * sin_r; lastx_cos_r = lastx * cos_r;
		lasty_sin_r = lasty * sin_r; lasty_cos_r = lasty * cos_r;
		if (lastx == newx) {
	    	newx_sin_r = lastx_sin_r;
	    	newx_cos_r = lastx_cos_r;
		} else {
	    	newx_sin_r = newx * sin_r;
	    	newx_cos_r = newx * cos_r;
		}
		if (lasty == newy) {
	    	newy_sin_r = lasty_sin_r;
	    	newy_cos_r = lasty_cos_r;
		} else {
	    	newy_sin_r = newy * sin_r;
	    	newy_cos_r = newy * cos_r;
		}
		if (lastquads & QUAD_1) {
	    	TUTORabs_move_to(xc + ((lastx_cos_r - lasty_sin_r)), yc + ((lasty_cos_r + lastx_sin_r)));
			TUTORabs_line_to(xc + ((newx_cos_r - newy_sin_r)), yc + ((newy_cos_r + newx_sin_r)));
		}
		if (lastquads & QUAD_2) {
	    	TUTORabs_move_to(xc - ((lastx_cos_r - lasty_sin_r)), yc + ((lasty_cos_r - lastx_sin_r)));
	    	TUTORabs_line_to(xc - ((newx_cos_r - newy_sin_r)), yc + ((newy_cos_r - newx_sin_r)));
		}
		if (lastquads & QUAD_3) {
	    	TUTORabs_move_to(xc - (flipX*(lastx_cos_r + lasty_sin_r)), yc - ((lasty_cos_r - lastx_sin_r)));
	    	TUTORabs_line_to(xc - ((newx_cos_r + newy_sin_r)), yc - ((newy_cos_r - newx_sin_r)));
		}
		if (lastquads & QUAD_4) {
	    	TUTORabs_move_to(xc + ((lastx_cos_r + lasty_sin_r)), yc - ((lasty_cos_r + lastx_sin_r)));
	    	TUTORabs_line_to(xc + ((newx_cos_r + newy_sin_r)), yc - ((newy_cos_r + newx_sin_r)));
		}
#endif
    }
    lastquads = quads;
    if (quads) {
		lastx = newx;
		newx= x;
		lasty = newy;
		newy = y;
    } else
    	lastx = -1;
    	
} /* Set4Pixels */

/* ********************************************************* */

TUTORfill_rectangle(x1, y1, x2, y2)	/* fill non-rotated rectangle */
Coord x1, y1, x2, y2;
{
    int ix1, iy1, ix2, iy2, sw;
    TRect tr;

    ix1 = lclocx(x1);
    iy1 = lclocy(y1);
    ix2 = lclocx(x2);
    iy2 = lclocy(y2);
    if (ix1 > ix2) {
	sw = ix1;
	ix1 = ix2;
	ix2 = sw;
    }				/* swap x */
    if (iy1 > iy2) {
	sw = iy1;
	iy1 = iy2;
	iy2 = sw;
    }
    /* postscript display doesn't do patterns or inverse */
#ifdef DOPSCRIPT
    if (pscript) {
	sprintf(PSbuff, "\n%d %d %d %d FillRectangle \n", ix1, iy1, ix2, iy2);
	PostScriptOutput(PSbuff);
    }
#endif

	TUTORset_rect(&tr,ix1 + exS.OffsetX, iy1 + exS.OffsetY, ix2 + exS.OffsetX, iy2 + exS.OffsetY);
    TUTORfill_abs_rect(&tr, exS.patternFont, exS.patternChar);

    return(0);
}

/* ********************************************************* */

TUTORerase_solid_rect(x1, y1, x2, y2)	/* erase rectangle with current
					 * pattern */
Coord x1, y1, x2, y2;		/* opposite corners */
{
	TRect tempR;
	
	TUTORset_rect(&tempR,
			(int) (lclocx(x1) + exS.OffsetX),
			(int) (lclocy(y1) + exS.OffsetY),
			(int) (lclocx(x2) + exS.OffsetX),
     (int) (lclocy(y2) + exS.OffsetY));
     TUTORabs_erase_rect(&tempR, exS.patternFont, exS.patternChar);

    return(0);
}

/* ********************************************************* */

TUTORfill_polygon(npoints, fx, fy)
/* Fills a polygon described by an array of points (fx[i], fy[i]) */
/* fx[i] & fy[i] are immediately converted to actual screen locations. */
/* KLUDGE NOTE: fx/fy start with fx[1] and fy[1] not fx[0] fy[0] */

int npoints;
Coord fx[];			/* arrays for -fill- */
Coord fy[];
{
    int ii;

    /* convert to screen coordinates */
    for (ii = 1; ii <= npoints; ii++) {
	fx[ii] = lclocx(fx[ii]) + exS.OffsetX;
	fy[ii] = lclocy(fy[ii]) + exS.OffsetY;

#ifdef DOPSCRIPT
	if (pscript) {
	    if (ii == 1)
		sprintf(PSbuff, "newpath %g %g moveto ", fx[1] - exS.OffsetX, fy[1] - exS.OffsetY);
	    else
		sprintf(PSbuff, "%g %g lineto ", fx[ii] - exS.OffsetX, fy[ii] - exS.OffsetY);
	    PostScriptOutput(PSbuff);
	}
#endif
    }

#ifdef DOPSCRIPT
    if (pscript) {
	sprintf(PSbuff, " closepath fill \n");
	PostScriptOutput(PSbuff);
    }
#endif

    TUTORabs_fill_polygon(npoints, fx, fy);

    return(0);
}

/* ********************************************************* */

TUTORfill_disk(type,xc,yc,x1, y1, x2, y2)
/* filled disk;  partial disks are not allowed  */
/* Mac's or Postscript can handle partial disks, but we (Tutor) can't */
/* rotate should be 0;  rotate not 0 doesn't work with wm */
/* for the time being angles are always 0 - 360 */
int type; /* 0 = from radius, center valid */
		  /* 1 = from rectangle, center not valid */
Coord xc, yc, x1, y1, x2, y2;

{
    long xcenter,ycenter,temp;
    TRect rr;

	xcenter = lclocx(xc)+exS.OffsetX;
	ycenter = lclocx(yc)+exS.OffsetY;
    rr.left = lclocx(x1) + exS.OffsetX;
    rr.top = lclocy(y1) + exS.OffsetY;
    rr.right = lclocx(x2) + exS.OffsetX;
    rr.bottom = lclocy(y2) + exS.OffsetY;
	if ((rr.left == rr.right) || (rr.top == rr.bottom)) {
		TUTORabs_draw_dot(rr.left,rr.top);
		return(0);
	}
    TUTORabs_fill_disk(type,xc,yc,&rr, exS.patternFont, exS.patternChar);

    return(0);
}


/* *********************** drawing text routines *********************** */

plotText(textDoc,startSel,endSel) /* plot text without any fudging */
Memh textDoc;
long startSel,endSel;

{	int xstart,ystart; /* start of draw, in pixels */
	TRect marginR;
	
	TUTORmove_to(exS.ScreenX, exS.ScreenY);
	
	/* change defaults of display */
	TUTORdefault_styles_font_doc(exS.baseFont,textDoc);
	TUTORset_sub_new(exS.SupSub,exS.newLine);

	marginR.left = lclocx(exS.MarginBeginX) + exS.OffsetX;
	xstart =  lclocx(exS.ScreenX) + exS.OffsetX;
	marginR.right = lclocx(exS.MarginEndX)+exS.OffsetX;
	ystart =  lclocy(exS.ScreenY)+exS.OffsetY; 
	marginR.top = lclocy(exS.MarginBeginY)+exS.OffsetY;
	marginR.bottom = lclocy(exS.MarginEndY)+exS.OffsetY; 
	
	/* checks */
	if (marginR.left >= RoundCoord(exS.ScreenW)) return(0);
	if (ystart >= RoundCoord(exS.ScreenH)) return(0);
	if (xstart >= marginR.right) return(0);
	
	write_abs_text(textDoc,startSel,endSel,xstart,ystart,(TRect FAR *) &marginR,
				FALSE,NEARNULL,NEARNULL);
		
} /* plotText */

/* --------------------------------------------------------------------- */
writetext(textDoc,startSel,endSel, nDig, nMin)
Memh textDoc;
long startSel, endSel;
int nDig, nMin; /* special indent for showt (# of digits, # of minus signs) */

 /* Output text from TextLayout->document in a rectangle.
Rectangle goes from (MarginBeginX, MarginBeginY) to (MarginEndX, MarginEndY).
This particular text starts at (ScreenX, ScreenY).
Update ScreenX/Y to ending location of text.
All of the above coordinates are author coordinates..

This is a bounding rectangle in window-manager coordinates
which corresponds to a box from
     (MarginBeginX, ScreenY) to (maximum-x-of-this-text, bottom-of-this-text).
The maximum x need not be MarginEndX
if there are short lines with explicit newlines. */

	{
	int xstart,ystart; /* start of draw, in pixels */
	int maxX, maxY, manyLine;
	int tFamily, tSize, tFace;
	TRect marginR, tr;
	int showTOff;  /* offset due to -showt- */
	int ascent, descent;

	TUTORmove_to(exS.ScreenX, exS.ScreenY);
	
	if ((endSel <= startSel) || (textDoc == 0))
		return(0); /* nothing to do */

	/* change defaults of display */
	TUTORdefault_styles_font_doc(exS.baseFont,textDoc);
	TUTORset_sub_new(exS.SupSub,exS.newLine);

	/* Want 1 pixel border at left margin */
	marginR.left = lclocx(exS.MarginBeginX) + exS.OffsetX + 1;
	xstart =  lclocx(exS.ScreenX) + exS.OffsetX + 1;
	if (xstart>marginR.left) xstart--; /* no border adjustment in middle of area */
	showTOff = ShowTOffset(textDoc,startSel+1,nDig,nMin); /* spacing for showt */
	xstart += showTOff;
	marginR.right = lclocx(exS.MarginEndX)+exS.OffsetX-1;
	
	ystart =  lclocy(exS.ScreenY)+exS.OffsetY+1; /* 1 pixel border at top */
	marginR.top = lclocy(exS.MarginBeginY)+exS.OffsetY+1;
	marginR.bottom = lclocy(exS.MarginEndY)+exS.OffsetY-1; /* 1 pixel border at bottom */
	
	/* checks */
	if (marginR.left >= RoundCoord(exS.ScreenW)) return(0);
	if (ystart >= RoundCoord(exS.ScreenH)) return(0);
	if (xstart >= marginR.right) return(0);

	if (showTOff && (exS.mode == rewritemode || exS.mode == inversemode))
    	{ /* we need to clear our special indentation */
    	/* note that ShowTOffset will have set the font to whatever the showt is in,
    		so the TUTORinq_font_info will work properly */
    	TUTORinq_font_info(&ascent,&descent,NEARNULL,NEARNULL);
    	if ((ascent+descent) < exS.newLine)
    		ascent += exS.newLine-(ascent+descent);
		TUTORset_rect(&tr,xstart-showTOff,ystart,xstart-1,ystart+ascent+descent-1);
		TUTORdraw_abs_solid_rect((TRect FAR *) &tr,-1);
    	}
	
	manyLine = write_abs_text(textDoc,startSel,endSel,xstart,ystart,(TRect FAR *) &marginR,
				exS.wrapWrite,(exS.arr.arrowunit >= 0) ? &maxX : NEARNULL,
				(exS.arr.arrowunit >= 0) ? &maxY : NEARNULL);
		
	/* set bounds of text for arrow (this is only grossly correct now) */
	if (exS.arr.arrowunit >= 0)
		{
		if ((exS.arr.arrowLastR.left == -1) || (exS.arr.arrowLastR.left > 29000))
			{ /* not accumulating bounds or this is first write */
			/* write boundaries are what we've just used */
			exS.arr.arrowLastR.left = manyLine ? marginR.left : xstart;
			exS.arr.arrowLastR.top = ystart;
			exS.arr.arrowLastR.right = maxX;
			exS.arr.arrowLastR.bottom = maxY;
			}
		else
			{ /* accumulating continued writes */
			if (maxX > exS.arr.arrowLastR.right)
				exS.arr.arrowLastR.right = maxX;
			if (maxY > exS.arr.arrowLastR.bottom)
				exS.arr.arrowLastR.bottom = maxY;
			}
		}
	
	return(0);
	}

Memh dtextv() /* return pointer to text layout document */

{
	return(exS.dTextLayout);

} /* dtextv */

write_abs_text(textDoc,startSel,endSel,xstart,ystart,marginR, wrap,maxX, maxY)
Memh textDoc;
long startSel, endSel;
int xstart,ystart;
TRect FAR *marginR;
int wrap;	/* TRUE if want to wrap on margin */
int *maxX, *maxY;
/* returns TRUE if drew more than 1 line */
	{
	int initialx, initialy;
	int width, height;
	TRect tr, clipRect;
	int newX,newY;
	int maxH, lastHeight;
	int retVal;
	int SupSubOff;
	
	TUTORinq_abs_pen_pos(&initialx,&initialy);

	width = marginR->right - marginR->left + 1;
	height = marginR->bottom - ystart + 1;

	/* set clip region properly */
	TUTORinq_abs_clip_rect(&clipRect);
	TUTORintersect_rect((TRect FAR *) marginR,(TRect FAR *) &clipRect,(TRect FAR *) &tr);
	if (!exS.ClipText)
		{
		tr.bottom = 32760;
		}
	TUTORset_abs_clip_rect((TRect FAR *) &tr);
	
	SupSubOff = ((exS.inhibbits & (1L << INHSUPSUB)) != 0);
	TUTORabs_move_to(xstart,ystart);
	TUTORdraw_doc(textDoc,startSel,endSel-startSel,
			(struct tutorColor FAR *)&fgndColor,marginR->left,width,height,wrap,-1,
			FARNULL,TRUE,maxX ? &lastHeight : NEARNULL,maxY ? &maxH : NEARNULL,
			SupSubOff);
	
	TUTORset_abs_clip_rect((TRect FAR *) &clipRect);

	/* at this point, pen is at top of line (where it belongs) */
	TUTORinq_abs_pen_pos(&newX,&newY);
	newY -= 1; /* account for ystart +1 offset */
	
	exS.ScreenX += DivCoord(IntToCoord(newX-initialx),exS.ScaleX);
	exS.ScreenY += DivCoord(IntToCoord(newY-initialy),exS.ScaleY);
	
	if (maxX)
		*maxX = maxH;
	if (maxY)
		*maxY = newY+1+lastHeight;
	
	retVal = (newY > ystart + lastHeight); /* TRUE if drew more than 1 line */
	
	return(retVal);
	}
