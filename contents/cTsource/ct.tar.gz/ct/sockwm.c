
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* ******************************************************************* */

#include <stdio.h>
#include <sys/param.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/signal.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <netdb.h>

#include "baseenv.h"
#include "tglobals.h"
#include "tfiledef.h"
#include "compute.h"

#undef ctproto /* lots of bugs here, block for now   dma 7/13/99 */

#ifdef ctproto
int TUTORzero(char FAR *ptr, long lth);
int  TUTORreset_sockets(void);
int  TUTORserver(char  *addr,int  aType,char  *info);
int  TUTORsocket_server(int  fInd);
int  TUTORhosts(char  *addr,int  nn,char  *info,int  infoSize,int  *nNames);
int  TUTORsocket_client(char  *addr,int  aType,int  nn);
long  TUTORwrite_socket(int  ss,char  FAR *buf,long  len);
long  TUTORread_socket(int  ss,char  FAR *buf,long  maxLen);
int  TUTORgetchar_socket(int  ss);
int  TUTORclose_socket(struct  tutorfile FAR *tfp);
int  TUTORungetc_socket(struct  tutorfile FAR *tfp,int  cc);
char  FAR *GetPtr(unsigned int  mm);
int  ReleasePtr(unsigned int  mm);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
extern TUTORblock_move(char FAR *sp, char FAR *dp, long lth);
int  TUTORdealloc(char  FAR *ptr);
/* extern accept(); */
/* extern bind() */
extern int close(int fh);
/* connect() */
int  file_slot(void);
extern char *TUTORgetenv(char *varname);
/* gethostbyname() */
/* gethostname() */
/* extern listen(); */
long  random(void);
extern int read(int fn, char *buffer, unsigned int count);
/* select() */
/* shutdown() */
/* extern signal(); */
extern sleep(int time);
/* socket() */
int  strcmpf(char  FAR *aa,char  FAR *bb);
extern char *strcpy(char *aa, char *bb);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
extern int strlen(char *str);
extern int strncmp(char *aa, char *bb, int nn);
extern int write(int fn, char *buffer, unsigned int count);
#ifdef IBMPROTO
int _CDECL fclose(FILE *);
int _CDECL fflush(FILE *);
FILE * _CDECL fopen(const char *, const char *);
int _CDECL fprintf(FILE *, const char *, ...);
int _CDECL fputc(int, FILE *);
size_t _CDECL fread(void *, size_t, size_t, FILE *);
int _CDECL fseek(FILE *, long, int);
long _CDECL ftell(FILE *);
size_t _CDECL fwrite(const void *, size_t, size_t, FILE *);
int _CDECL rename(const char *, const char *);
int _CDECL sprintf(char *, const char *, ...);
int _CDECL sscanf(const char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

static int sockSignal; /* set to TRUE on write error (via CatchSigpipe) */
static char *knownAddr;  /* last addr we did a -hosts- on (so we know what address we last did -hosts- on) */
static char *addrInfo;  /* info we got from last -hosts- */
static int nextID; /* next ID number to use for a socket */
static char *addrFile; /* path of address database */
static char *addrFileL; /* path of locked address database */

long TUTORread_socket();
long TUTORwrite_socket();
extern char FAR *GetPtr();
extern char FAR *TUTORalloc();
extern char *TUTORgetenv();

#define BUFFSIZE 512

/* KSWdocumentation  socket connections
The general scheme of the socket connection process is this
1) The server creates a socket and listens for connections on it (ListenSocket)
2) The client creates a socket and attempts to connect it to a server
	socket (ConnectSocket).
3) The server checks to see if a connection request has been made.  If so, it
	accepts the request and destroys its socket.  (AcceptSocket).

All communication between succesfully connected processes takes place using the
client's socket.
*/

TUTORinit_sockets()
	{
	int CatchSigpipe();

	/* set up to handle socket closings (by clients) */
	signal(SIGPIPE,CatchSigpipe);

	knownAddr = FARNULL;
	addrInfo = FARNULL;

	/* we will be choosing socket numbers sequentially, starting at some random number */
	/* note that port numbers below IPPORT_RESERVERD are reserved by the system */
	nextID = IPPORT_RESERVED + (random() % 9001);

	addrFile = TUTORgetenv("CT_SERVERS");
	addrFileL = TUTORgetenv("CT_SERVERL");

	return;
	}

TUTORreset_sockets() /* restart socket machinery for new program run */
	{
	/* need to dispose of -hosts- information */
	if (knownAddr)
		{
		TUTORdealloc(knownAddr);
		knownAddr = FARNULL;
		}
	return;
	}

TUTORserver(addr,aType,info)
char *addr; /* the address we are advertising */
int aType;  /* TRUE if logical, FALSE if absolute */
char *info;  /* additional information (may by NULL) */
/* returns tutor file slot # or 0 for failure */
	{
	int idN,sockN;
	char servhost[80];
	struct tutorfile FAR *tfp; /* pointer to file table entry */

	if (!aType)
		{ /* absolute address */
		if (*addr != 'N')
			return(0); /* we only handle a socket # address right now */
		/* we expect an absolute address containing the desired socket # */
		/* get desired socket # */
		sscanf(addr+1,"%d",&idN);
		/* now make socket */
		sockN = ListenSocket(idN,TRUE,FALSE);
		if (!sockN)
			tfilerr = FILEMISSING;
		return(sockN);
		}

	/* at this point we are looking at a logical address, need to communicate with address server */

	/* open our server socket */
	sockN = ListenSocket(++nextID,TRUE,TRUE);
	if (!sockN)
		{
		tfilerr = FILEMISSING;
		return(0); /* couldn't open socket */
		}

	/* tell address server our name & address */
	if (!info)
		info = "  ";
	gethostname(servhost, sizeof(servhost));
	if (!RegisterAddr(addr,info,servhost,nextID))
		{ /* couldn't register name */
		/* close the socket */
		tfp = sockN+(struct tutorfile FAR *) GetPtr(filesopen);
		close(tfp->stream);
		tfp->stream = -1;
		tfp->inuse = FALSE;
		ReleasePtr(filesopen);
		KillPtr(tfp);
		tfilerr = FILEMISSING;
		return(0);
		}

	return(sockN);
	}

TUTORsocket_server(fInd)
int fInd; /* index in tutor file structure */
/* returns success flag */
	{
	int connectStream;
	struct tutorfile FAR *tfp; /* pointer to file table entry */
	int retVal; /* return value */

	tfp = ((struct tutorfile FAR *) GetPtr(filesopen))+fInd;
	if (tfp->lastop != fop_server)
		{
		ReleasePtr(filesopen);
		tfilerr = FILEMISSING;
		return(FALSE); /* not a server waiting for connection */
		}

	connectStream = AcceptSocket(tfp->stream);
	if (connectStream >= 0)
		{
		/* shut down listening stream */
		shutdown(tfp->stream,2);
		close(tfp->stream);
		DestroyAddress(tfp->streamID);
		tfp->stream = connectStream;
		tfp->lastop = fop_open;
		retVal = TRUE;
		}
	else
		{
		retVal = FALSE; /* nothing tried to connect */
		tfilerr = FILEMISSING;
		}
	
	ReleasePtr(filesopen);
	return(retVal);
	}

TUTORhosts(addr,nn,info,infoSize,nNames)
char *addr;  /* address to look up (this must be a logical type) */
int nn;  /* we want nnth instance (1 based) */
char *info;  /* to be filled with extra info */
int infoSize; /* maximum amount of info */
int *nNames; /* to be filled with # of names found */
/* returns success flag (FALSE if no names found at all) */
	{
	if (nn == -1)
		info = NEARNULL; /* don't want info on refresh call */
	return(HostInfo(addr,nn,info,infoSize,NEARNULL,0,NEARNULL,nNames));
	}

TUTORsocket_client(addr,aType,nn)
char *addr;  /* address we are connecting to */
int aType; /* TRUE if logical address type */
int nn;  /* which instance (1 based) we want to connect to */
/* returns tutor file slot # or 0 for failure */
	{
	char hostName[80], *cp;
	int idN, ii;

	if (!aType)
		{ /* absolute connection */
		if (*addr != 'I')
			{
			tfilerr = FILENAMEERR;
			return(0); /* only handle INET absolute addresses */
			}
		/* we expect an address of the form
			workstation,idN  (note that this is different from the TUTORsocket_server form */
		/* if the workstation name is missing, use the name of host */
		/* get host name */
		cp = addr + 1;
		ii = 0;
		while (*cp && *cp != ',' && ii < 79)
			{
			hostName[ii++] = *cp++;
			}
		hostName[ii] = 0;
		if (ii == 0)
			{ /* no hostname provided, use the machine we are on ;*/
			gethostname(hostName, sizeof(hostName));
			}
		if (*cp != ',')
			{
			tfilerr = FILENAMEERR;
			return(0); /* bad address form */
			}
		sscanf(cp+1,"%d",&idN); /* get idN */
		}
	else
		{ /* logical address, get it from host info tables */
		if (!HostInfo(addr,nn,NEARNULL,0,hostName,80,&idN,NEARNULL))
			{
			tfilerr = FILEMISSING;
			return(0); /* couldn't get host info for that address */
			}
		}

	ii = ConnectSocket(hostName,idN,TRUE);
	if (!ii)
		tfilerr = FILEMISSING;
	return(ii);
	}


long TUTORwrite_socket(tfp,buf,len)
struct tutorfile FAR *tfp;
char FAR *buf;
long len;
/* returns # of chars actually written */
	{
	if (tfp->stream < 0 || tfp->lastop == fop_server)
		{ /* not connected */
		tfilerr = FILENOTOPEN;
		return(0L);
		}
	sockSignal = FALSE;
	len = write(tfp->stream,buf,len);

	if (sockSignal)
		{
		TUTORclose_socket(tfp); /* this socket is closed, shut it down! */
		tfilerr = FILENOTOPEN;
		}
	
	return(len);
	}

long TUTORread_socket(tfp,buf,maxLen)
struct tutorfile FAR *tfp;
char *buf;	/* the request buffer */
long maxLen;	/* maximum number of bytes we can read into buffer */
/* returns # of chars actually read */
	{
	long nCopied, nHave, nMove;

	if (tfp->stream < 0 || tfp->lastop == fop_server)
		{ /* not connected */
		tfilerr = FILENOTOPEN;
		return(0L);
		}
	nCopied = 0;
	while (nCopied < maxLen)
		{ /* keep going until we fill request buffer or run out of input */
		nHave = tfp->bEnd - tfp->bPos;
		if (nHave == 0)
			{ /* have exhausted buffer, get more */
			if (!FillBuffer_socket(tfp))
				break; /* nothing more to get */
			nHave = tfp->bEnd; /* the number of chars we managed to read */
			}
		/* move bytes from stream buffer to request buffer */
		nMove = (nHave <= maxLen - nCopied) ? nHave : maxLen - nCopied;
		TUTORblock_move(tfp->buffer+tfp->bPos,(char FAR *) buf+nCopied,nMove);
		tfp->bPos += nMove;
		nCopied += nMove;
		}

	return(nCopied);
	}

int TUTORgetchar_socket(tfp)
struct tutorfile FAR *tfp;
/* returns char or EOF */
	{
	char cc;
	
	if (tfp->stream < 0 || tfp->lastop == fop_server)
		{ /* not connected */
		tfilerr = FILENOTOPEN;
		return(EOF);
		}
	if (tfp->bPos >= tfp->bEnd)
		FillBuffer_socket(tfp); /* need to recharge our buffer */
	if (tfp->bPos < tfp->bEnd)
		return(tfp->buffer[tfp->bPos++]);
	else
		return(EOF); /* must not have gotten any chars from FillBuffer */
	}

int TUTORungetc_socket(tfp,cc)
struct tutorfile FAR *tfp;
int cc; /* char to unput */
	{
	if (tfp->stream < 0 || tfp->lastop == fop_server)
		{ /* not connected */
		tfilerr = FILENOTOPEN;
		return(0L);
		}
	if (cc == EOF || tfp->bPos == 0)
		return(EOF);
	tfp->buffer[--tfp->bPos] = cc;
	return(cc);
	}

static FillBuffer_socket(tfp)
struct tutorfile FAR *tfp;
/* returns TRUE if got anything at all */
	{
	int mask, tm, nFound;
	struct timeval aTime;
	long nRead;

	mask = 1 << tfp->stream;
	tm = mask;
	aTime.tv_sec = 0;  /* select timeout */
	aTime.tv_usec = 1000;
	nFound = select(32,&tm,NULL,NULL,&aTime);
	if (nFound > 0 && (tm & mask))
		{ /* something there to read */
		nRead = read(tfp->stream,tfp->buffer,(long) BUFFSIZE);
		tfp->bEnd = nRead;
		}
	else
		{
		tfp->bEnd = 0; /* nothing read */
		nRead = 0L;
		}
	tfp->bPos = 0;

	return(nRead > 0);
	}

TUTORclose_socket(tfp)
struct tutorfile FAR *tfp; /* pointer to file table entry */
	{
	if (tfp->lastop == fop_server)
		{ /* this is server waiting for connection */
		DestroyAddress(tfp->streamID); /* disadvertise ourselves */
		shutdown(tfp->stream,2);
		}
	else
		{ /* normal open socket */
		shutdown(tfp->stream,0); /* let what we've written be delivered */
		}
	close(tfp->stream);
	tfp->stream = -1;
	tfp->inuse = FALSE;
	if (tfp->buffer)
		TUTORdealloc(tfp->buffer);
	return;
	}

/* lower level socket machinery */

static ListenSocket(idN, tutorFile,aType) /* create a socket for server */
int idN;	/* socket id # (will be used as port number) */
int tutorFile; /* TRUE if this needs tutor setup */
int aType; /* address type, for tutor file */
 /* returns 0 for error, TUTOR file # or stream #+1*/
	{
	struct sockaddr_in listenAddr;
	int listenS;
	struct tutorfile FAR *tfp; /* pointer to file table entry */
	int ii;

	/* get a socket for connections */
	listenS = socket(AF_INET,SOCK_STREAM, 0);
	if (listenS < 0)
		return(0);

	/* fill up listening socket data structure */
	TUTORzero((char FAR *) &listenAddr, (long) sizeof(struct sockaddr_in));
	listenAddr.sin_family = AF_INET;
	listenAddr.sin_port = htons(idN);
	listenAddr.sin_addr.s_addr = INADDR_ANY;

	/* bind server address to socket */
	if (bind(listenS, &listenAddr, sizeof(listenAddr)) < 0)
		{
		close(listenS);
		return(0);
		}

	/* start listening for connection */
	if (listen(listenS,2) < 0)
		{
		close(listenS);
		return(0);
		}

	if (tutorFile)
		{
		/* set up file table entry */
		tfilerr = -1; /* no error yet */
		ii = file_slot(); /* locate free file table slot */
		tfp = ii+(struct tutorfile FAR *) GetPtr(filesopen);
		tfp->inuse = TRUE; /* mark file table entry in use */
		tfp->vloc = -1; /* no associated author variable yet */
		tfp->lastop = fop_server; /* no operations yet */
		tfp->ro = FALSE; /* set read-only flag */
		tfp->styles_allowed = FALSE; /* not styled text */
		tfp->kind = 2; /* socket */
		tfp->fp = 0;
		tfp->stream = listenS;
		tfp->streamID = idN;
		tfp->buffer = TUTORalloc(BUFFSIZE,TRUE,"sockbufs");
		tfp->bEnd = 0;
		tfp->bPos = 0;
		ReleasePtr(filesopen);
		}

	return(tutorFile ? ii : (listenS+1));
	}

static AcceptSocket(listenS)
int listenS; /* listening socket # */
/* returns new client socket # or <0  if nothing */
	{
	int mask, tRead, nFound;
	struct timeval aTime;
	int clientS;
	int jj;
	struct sockaddr_in client_addr;

	clientS = -1; /* asumme no connection */

	mask = 1 << listenS;
	tRead = mask;
	aTime.tv_sec = 0;  /* select timeout */
	aTime.tv_usec = 1000;
	nFound = select(32,&tRead,NULL,NULL,&aTime);

	if ((tRead & mask) && nFound > 0)
		{ /* accept new client */
		jj = sizeof(client_addr);
		clientS = accept(listenS,&client_addr,&jj);
		}

	return(clientS);
	}

static ConnectSocket(hname,idN,tutorFile)
char *hname;
int idN;
int tutorFile; /* TRUE if this is for a tutor file */
 /* returns 0 for error, TUTOR file # or stream #+1*/
	{
	struct sockaddr_in server_sock;
	int ss;
	struct hostent *hp;
	char servhost[80];
	int ii;
	struct tutorfile FAR *tfp;
	int err;

	/* figure out host */
	if (!hname) /* must be the machine where we are running */
		(void) gethostname(servhost, sizeof(servhost));
	else
		(void) strcpy(servhost, hname);

	hp = gethostbyname(servhost);
	if (hp == NULL)
		return(0);

	/* get a socket */
	ss = socket(AF_INET,SOCK_STREAM,0);
	if (ss < 0)
		return(0);

	/* fill up server socket data structure */
	TUTORzero((char FAR *) &server_sock,(long) sizeof(struct sockaddr_in));
#ifdef sunV3
	/* sun3 gethostbyname really returns hp->h_addr, not hp->h_addr_list */
	TUTORblock_move((char FAR *) (hp->h_addr_list), (char FAR *) &server_sock.sin_addr,
			(long) hp->h_length);
#else
	TUTORblock_move((char FAR *) (*(hp->h_addr_list)), (char FAR *) &server_sock.sin_addr,
			(long) hp->h_length);
#endif
	server_sock.sin_family = hp->h_addrtype;
	server_sock.sin_port = htons(idN);

	/* connect to server */
	err = connect(ss,&server_sock,sizeof(server_sock));
	if (err < 0)
		{
		close(ss);
		return(0);
		}

	if (tutorFile)
		{
		/* set up file table entry */
		tfilerr = -1; /* no error yet */
		ii = file_slot(); /* locate free file table slot */
		tfp = ii+((struct tutorfile FAR *) GetPtr(filesopen));
		tfp->inuse = TRUE; /* mark file table entry in use */
		tfp->vloc = -1; /* no associated author variable yet */
		tfp->lastop = fop_open; /* no operations yet */
		tfp->ro = FALSE; /* set read-only flag */
		tfp->styles_allowed = FALSE; /* not styled text */
		tfp->kind = 2; /* socket */
		tfp->fp = 0;
		tfp->buffer = TUTORalloc(BUFFSIZE,TRUE,"sockbufc");
		tfp->bEnd = 0;
		tfp->bPos = 0;
		tfp->stream = ss;
		ReleasePtr(filesopen);
		}

	return(tutorFile ? ii : (ss+1));
	}

static CatchSigpipe()
	{
	sockSignal = TRUE; /* tell write_socket that we've had error */
	return;
	}

/* KSWdocumentation  cT's logical socket addresses
Logical addresses are implemented within cT for unix.  This is done in a very
crude form.

When a server is created with a logical address an entry is made in a database,
which is stored in a file in the file system.  The exact pathname of the file
is specified in the environment variable CTSERVERS.  Each entry in the database
is 250 characters long and has the form:

	addr 100 chars (ADDRLEN)
	info 40 chars (INFOLEN)
	addrName 100 chars (ANAMELEN)
	addrNum 10 chars (ANUMLEN)

Every entry is padded out to its full size.  String fields are not guranteed to
be null terminated in file. There may be duplicate addr-info entries in the
database.

When a client wants to attempt to connect to a logical address, or a -gethosts-
command is executed, a call to HostInfo is made.  This reads the database and
searches for the desired information.

When a server succesfully connects it removes its entry from the database file.


Collisions on access to the database file are avoided by renaming the database file
to the pathname in CTSERVERL whenever it is being accessed.
*/

#define ADDRLEN 100
#define INFOLEN 40
#define ANAMELEN 100
#define ANUMLEN 10
#define ENTRYLEN (ADDRLEN+INFOLEN+ANAMELEN+ANUMLEN)
#define MAXENT 10

/* when we attempt an operation it may fail because the file is being used by someone else.  We
  will retry NTRIES times, waiting SLEEPTIME seconds before retrying each time */
#define NTRIES 5
#define SLEEPTIME 3

static RegisterAddr(addr,info,addrName,addrNum)
char *addr, *info, *addrName;
int addrNum;
/* returns success flag */
	{
	FILE *fp;
	int err, ii;

	if (!LockAddrFile())
		return(FALSE);
	
	/* open file, for appending */
	fp = fopen(addrFileL,"a");
	if (!fp)
		{
		UnlockAddrFile();
		return(FALSE);
		}

	/* write out our info */
	WriteAddrString(addr,ADDRLEN,fp);
	WriteAddrString(info,INFOLEN,fp);
	WriteAddrString(addrName,ANAMELEN,fp);
	WriteAddrNum(addrNum,ANUMLEN,fp);

	/* close file */
	fflush(fp);
	fclose(fp);

	UnlockAddrFile();

	return(TRUE);
	}

static HostInfo(addr,nn,info,infoSize,addrName,addrSize,addrNum,nNames)
char *addr;  /* address to look up (this must be a logical type) */
int nn;  /* we want nnth instance (1 based) */
char *info;  /* if exists, to be filled with extra info */
int infoSize; /* maximum amount of info */
char *addrName; /* if exists, to be filled with addr name */
int addrSize; /* maximum addr size */
int *addrNum; /* if exists, to be filled with address # */
int *nNames; /* if exists, to be filled with # of names found */
/* returns success flag (FALSE if no names found at all) */
	{
	FILE *fp;
	int err, ii, nRead;
	char entryBuff[ENTRYLEN];
	int count;

	if (nNames)
		*nNames = 0; /* default */
	if (!knownAddr || (nn == -1) || (strcmpf((char FAR *) addr,knownAddr) != 0))
		{ /* need to refresh addrInfo data */
		if (!LockAddrFile())
			return(FALSE);

		/* open addr file for reading */
		fp = fopen(addrFileL,"r");
		if (!fp)
			{
			UnlockAddrFile();
			return(FALSE);
			}

		if (knownAddr)
			TUTORdealloc(knownAddr);
		knownAddr = TUTORalloc((long) strlen(addr)+1,TRUE,"knwnaddr");
		strcpyf(knownAddr,(char FAR *)addr);

		if (!addrInfo)
			{ /* allocate a buffer for address info (holds maximum of MAXENT entries) */
			addrInfo = TUTORalloc((long) ENTRYLEN*MAXENT,TRUE,"saddinfo");
			}
		/* read addr file one entry at a time.  When find an addr match, add to our local list */
		count = 0;
		ii = 0;
		while (1)
			{
			fseek(fp,(long) ii*ENTRYLEN,0);
			nRead = fread(entryBuff,1,ENTRYLEN,fp);
			if (!nRead)
				break; /* out of entries */
			if (strncmp(addr,entryBuff,ADDRLEN) == 0)
				{ /* add to our local database */
				TUTORblock_move((char FAR *) entryBuff,addrInfo+count*ENTRYLEN, (long) ENTRYLEN);
				count++;
				if (count >= MAXENT)
					break; /* filled up our table */
				}
			ii++;
			}
		UnlockAddrFile();
		if (count < MAXENT)
			addrInfo[count*ENTRYLEN] = 0; /* null byte to indicate end of data */
		}
	else
		{ /* need to count entries again */
		count = 0;
		while (count < MAXENT && addrInfo[count*ENTRYLEN])
			count++;
		}

	/* at this point we have valid addrInfo & count, so fill out requested data */

	if (nNames)
		*nNames = count;
	if (nn > count)
		return(FALSE); /* we don't have that entry */

	nn--; /* change from 1 based to 0 based count */
	if (info)
		{
		nRead = (infoSize-1 > INFOLEN) ? INFOLEN : infoSize-1;
		TUTORblock_move(addrInfo+nn*ENTRYLEN+ADDRLEN, (char FAR *) info,(long) nRead);
		info[nRead] = 0; /* null terminate */
		}

	if (addrName)
		{
		nRead = (addrSize-1 > ANAMELEN) ? ANAMELEN : addrSize-1;
		TUTORblock_move(addrInfo+nn*ENTRYLEN+ADDRLEN+INFOLEN, (char FAR *) addrName, (long) nRead);
		addrName[nRead] = 0;
		}

	if (addrNum)
		sscanf(addrInfo+nn*ENTRYLEN+ADDRLEN+INFOLEN+ANAMELEN,"%d",addrNum);

	return(TRUE);
	}

static DestroyAddress(id) /* delete address from address server database */
int id; /* stream id to get rid of */
	{
	int ii, sockN;
	char servhost[80];
	FILE *fp;
	long fLen, offset;
	char *data;
	
	if (!LockAddrFile())
		return(FALSE); /* couldn't access file! */

	fp = fopen(addrFileL,"r");
	if (!fp)
		{
		UnlockAddrFile();
		return(FALSE);
		}

	/* read whole address database file into memory */
	fseek(fp,0L,2);
	fLen = ftell(fp);
	fseek(fp,0L,0);
	data = TUTORalloc(fLen,TRUE,"tempaddr");
	fread(data,1,fLen,fp);
	fclose(fp);

	/* now compare every entry with what needs to be deleted */
	gethostname(servhost, sizeof(servhost)); /* our addrName */
	offset = 0;
	while (offset < fLen)
		{
		if (0 == strncmp(servhost,data+offset+ADDRLEN+INFOLEN,ANAMELEN))
			{ /* matched our host, check socket # */
			sscanf(data+offset+ADDRLEN+INFOLEN+ANAMELEN,"%d",&sockN);
			if (sockN == id)
				break; /* matched */
			}
		offset += ENTRYLEN;
		}

	if (offset >= fLen)
		{ /* didn't find entry! */
		TUTORdealloc(data);
		UnlockAddrFile();
		return(FALSE);
		}

	/* we found match, now write file out with all data but old entry */
	fp = fopen(addrFileL,"w");
	if (!fp)
		{
		TUTORdealloc(data);
		UnlockAddrFile();
		return(FALSE);
		}
	if (offset > 0)
		fwrite(data,1,offset,fp); /* all data up to deleted entry */
	if (fLen-offset-ENTRYLEN > 0)
		fwrite(data+offset+ENTRYLEN,1,fLen-offset-ENTRYLEN,fp); /* data after deleted entry */
	fflush(fp);
	fclose(fp);

	TUTORdealloc(data);
	UnlockAddrFile();

	return(TRUE);
	}

static LockAddrFile()
	{
	int ii, err;

	/* attempt to move file */
	for (ii=0; ii<NTRIES; ii++)
		{
		err = rename(addrFile,addrFileL);
		if (!err)
			break;
		sleep(SLEEPTIME); /* wait for other process to finish */
		}
	return(!err);
	}

static UnlockAddrFile()
	{
	rename(addrFileL,addrFile);
	}
	
static WriteAddrString(ss,len,fp)
char *ss;  /* string to write out */
int len;  /* length we want in file */
FILE *fp;
	{
	int sLen; /* actual length of string */
	int wLen; /* # of chars to write from string */

	sLen = strlen(ss);
	wLen = (sLen < len) ? sLen : len;

	fprintf(fp,"%.*s",wLen,ss); /* write out chars from string */

	while (wLen < len)
		{
		fputc(0,fp); /* pad out field */
		wLen++;
		}

	return;
	}

static WriteAddrNum(nn,len,fp)
int nn;
int len; /* length we want in file */
FILE *fp;
	{
	char ns[20];
	int sLen;

	/* we assumme that len is longer than number! */

	sprintf(ns,"%d",nn);
	sLen = strlen(ns);
	fprintf(fp,"%s",ns);

	while (sLen < len)
		{
		fputc(' ',fp);
		sLen++;
		}

	return;
	}

int TUTORwait_socket()

{
	return(FALSE);
}
