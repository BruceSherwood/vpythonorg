
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "baseenv.h"
#include "kglobals.h"
#include "txt.h"
#include "tglobals.h"

#ifdef ctproto
int  CTinq_closest_color(int  wn,double  redF,double  greenF,double  blueF,int	hsvf);
long  TUTORget_hsize(unsigned int  mm);
int mvar_unref_doc(Memh doc);
int mvar_uncache(Memh doc);
int  TUTORclose_all_markers(unsigned int  doc);
int CTmap_color(int wn, int cn, int foreFlag);
extern int TUTORget_lockcount(Memh mm);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  TUTORclose_doc(unsigned int  doc);
int  TUTORclear_doc(unsigned int  doc);
int  TUTORinsert_string_doc(unsigned int  doc,long  pos,unsigned char  FAR *ss,long  sLen);
int  TUTORdelete_doc(unsigned int  doc,long  pos,long  len,long  *extraPos);
int  TUTORchange_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,unsigned char  FAR *cp,long  cLen,long  fromOff,unsigned int  styles,unsigned int  specialT,long  *extraPos,int  eupFlag);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
extern int  _TUTORchange_text_doc(struct  _ktd FAR *dp,long  pos,long  len,unsigned char  FAR *cp,long  cLen,int  *followP);
extern int  _TUTORchange_styles_doc(struct  _ktd FAR *dp,long  pos,long  len,long  cLen,unsigned int  styles,long  fromStart,int  followP,int  lastN,long  *extraPos,int  keyFlag);
int  TUTORstyle_doc(unsigned int  doc,long  pos,long  len,int  type,int  dat,int  canCombine,long  *extraPos);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
int  _TUTORload_buffer_doc(struct  _ktd FAR *dp,long  pos);
long  TUTORget_len_doc(unsigned int  doc);
extern int  FixParagraphStyles(struct  _ktd FAR *dp,long  pos,long  checkLen,long  *newEnd);
int  TUTORdefault_styles_font_doc(int  font,unsigned int  doc);
int  TUTORdefault_styles_doc(unsigned int  doc,short  FAR *defStyles);
int  TUTORget_default_styles_doc(unsigned int  doc,short  FAR *defStyles);
int  TUTORcompress_darray(unsigned int  da,int  offset);
int  TBlockToStringDoc(unsigned int  doc);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  TUTORclose_stext(unsigned int  st);
int  CloseTStyle(unsigned int  pd);
int  _TUTORupdate_markers_doc(struct  _ktd FAR *dp,long  mpos,long  mlen,long  cpos,long  clen,long  newlen,long  sEnd);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORfree_handle(unsigned int  mm);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORdump(char  *s);
int  TUTORmaintain_doc_view(struct  _ktd FAR *dp,long  pos,long  len,long  cpos,long  clen,long  newC);
int  _TUTORchange_stext_doc(struct  _ktd FAR *dp,long  pos,long  len,long  cLen,unsigned int  specialT,long  fromStart);
struct  _tblk FAR *FindTBlock(struct  _ktd FAR *dp,long  pos,long  *pOff,long  *eOff);
long  TUTORsearch_string_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sLen,long  pos,long  posEnd);
unsigned int  NewTStyle(void);
int  CheckKeepTStyle(unsigned int  pd);
int  DeleteTStyle(unsigned int  pd,long  start,long  len);
int  AddTStyle(unsigned int  pd,long  start,long  len,long  docLen,int  type,int  newDat,int  combF);
int  InsertTStyle(unsigned int  pd,long  start,long  len,int  expandEnd);
int  SpliceTStyle(unsigned int  pd,unsigned int  newPd,long  toStart,long  fromStart,long  fromLen,long  docLen);
int  ChangeTBlock(struct  _ktd FAR *dp,long  pos,long  len,unsigned char  FAR *newP,long  newLen,int  *unlocked,int  *followP);
int  StringToTBlock(unsigned int  doc);
int  TUTORreplace_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  replaceN,int  newN,char  FAR *datP);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
int  TUTORdelete_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nDel);
int  FindBlockTypeTStyle(struct  _pdt FAR *pp,long  ps,int  type);
int TUTORinq_foreground_color(struct tutorColor *fc);
int  TUTORinq_font_descr(int  fontN,long *fam,int  *siz,int  *fac);
#endif /* ctproto */

#ifdef macproto
extern int sprintf(char *ss, char *form,...);
#endif

extern unsigned int TUTORnew_doc();
extern char FAR *GetPtr();
long TUTORget_len_doc();
long TUTORsearch_string_doc();

extern Memh NewTStyle();
extern Memh TUTORnew_stext();
extern TextBlock FAR *FindTBlock();
extern long _TUTORsearch_doc();
extern unsigned char FAR *TUTORscan_bytes();

/* defined in txt.h: */
int DOCOFFSET; /* ought to be #define */
Memh plTable;	/* the global paragraph layout table */
ParagraphLayout defaultLayout; /* can be seen outside!! */
int TxtMemErr = 0; /* non-zero if out of memory processing text */
struct tutorColor txtFgndColor; /* current default foreground color */

/******************************************************************
	A note about document positions
	
	All of the positions that are referred to in the txt code are character positions.
	Each and every character (even bitmaps) are represented in the text portion of
	the document by one byte.  So character positions map to byte positions directly,
	one to one.  Also, the positions are OFF character coordinates.  Position 0 is
	the position just before the zeroth character in the document (note that this
	machinery is all coded in C and so a zero based enumeration is natural).  Position 1
	is the position between the 0th & 1th characters.  Often the documentation
	speaks of the character at a position.  This is the character that immediately
	follows a position.  So the character "at" position 3 is, in fact, the fourth
	character in the document.
	
	The region of a document spanned by a position and length is all those characters
	within the positions position thru position+length.  The number of such characters
	is equal to the length.
	
*******************************************************************/

Memh TUTORnew_doc(string, honorP) /* create a new document */
int string;		/* if TRUE, create this document as simply as possible */
int honorP;		/* if TRUE ensure paragraph styles match paragraph boundaries */
	{
	Memh doc;	/* the newly created document */
	REGISTER DocP dp;	/* pointer to doc */
	int si;  /* index in styles */
	
	/* create document from scratch */ 
	
	doc = TUTORhandle("textDoc ",(long) sizeof(Document), TRUE);
	if (!doc)
		return(HNULL);

	dp = (DocP) GetPtr(doc);

	/* minimal initializations: */

	dp->self = doc;

	dp->changed = FALSE;
	dp->shortText = TRUE;
	
	dp->totLen = 0L;

	dp->nArrays = 2;
	dp->totalSize = sizeof(Document);
DOCOFFSET = ((char FAR *) &dp->nArrays) - ((char FAR *) &dp->self); /* should be #define */
	dp->offsets[DOCTEXT] = ((char FAR *) &dp->txtH) - ((char FAR *) &dp->self);
	dp->offsets[DOCTBLOCK] = ((char FAR *) &dp->tBlockH) - ((char FAR *) &dp->self);

	dp->editPanel = HNULL;
	
	/* marker machinery */
	dp->nUsers = 0;
	dp->prevd = dp->nextd = dp->nextHandle = dp->unitMark = (Memh) 0;
	dp->headM = -1L; /* indicates no next */
	
	/* text array */
	dp->txtH.dAnn = 0;
	dp->txtH.dAnAlloc = 100; /* MUST match txt.h */
	dp->txtH.nBuff = TBUFFLEN;
	dp->txtH.itemSize = 1;

	dp->styles = HNULL;
	for(si=0; si<NSTYLES; si++) 
		dp->defStyles[si] = DEFSTYLE;

	dp->specialT = HNULL;	/* no special text */
	
	dp->buffStart = 0L;
	dp->buffEnd = 0L;

	/* text block array */
	dp->tBlockH.dAnn = 0;
	dp->tBlockH.dAnAlloc = 1;
	dp->tBlockH.nBuff = 3;
	dp->tBlockH.itemSize = sizeof(TextBlock);
	
	dp->updateM = TRUE;
	dp->honorP = honorP;
	
	ReleasePtr(doc);
	KillPtr(dp);
	
	return(doc);
	}

extern int dcachen;
extern Memh dcache[];

TUTORclose_doc(doc) /* throw away a document and all sub-data */
Memh doc;	/* the document to be closed */
	{
	REGISTER DocP dp;	/* pointer to doc */
	register int ii;
	register TextBlock FAR *tbp;	/* pointer to text blocks */
	SText FAR *stp;	/* pointer to special text */
	DArrayHeader FAR *dap;	/* dynamic array header for text blocks */
	
	if (!doc)
		return 0;
		
	mvar_unref_doc(doc); /* remove document from reference chain */
	mvar_uncache(doc); /* remove document from cache */
	TUTORclose_all_markers(doc); /* shut down markers on this document */
			
	dp = (DocP) GetPtr(doc);
	
	/* destroy styles */
	if (dp->styles)
		{
		CloseTStyle(dp->styles);
		dp->styles = HNULL;
		}
	
	/* text blocks */
	if (!dp->shortText)
		{
		dap = (DArrayHeader FAR *) ((char FAR *) dp + dp->offsets[DOCTBLOCK]);
		tbp = (TextBlock FAR *) (dap+1);
		for (ii=0; ii<dap->dAnn; ii++, tbp++)
			{ /* destroy all text in seperate blocks */
			TUTORfree_handle(tbp->text);
			}
		dap->dAnn = 0;
		}
		
	/* special text */
	if (dp->specialT)
		{
		TUTORclose_stext(dp->specialT);
		dp->specialT = HNULL;
		}
	
	ReleasePtr(doc);
	KillPtr(dp);
	TUTORfree_handle(doc);
	
	return 0;
	}

TUTORclear_doc(doc) /* remove the contents of a document */
Memh doc;	/* document to be cleared */
	{
	REGISTER DocP dp;	/* pointer to doc */
	
	dp = (DocP) GetPtr(doc);
	if (dp->totLen == 0)
		{ /* doc already clear */
		ReleasePtr(doc);
		KillPtr(dp);
		return(0);
		}

	_TUTORupdate_markers_doc(dp,0L,dp->totLen, 0L,dp->totLen, 0L, 0L);

	dp->totLen = 0;
	dp->buffStart = 0L;
	dp->buffEnd = 0L;

	if (dp->styles)
		{
		CloseTStyle(dp->styles);
		dp->styles = HNULL;
		}
	
	if (dp->specialT)
		{
		TUTORclose_stext(dp->specialT);
		dp->specialT = HNULL;
		}
	
	if (dp->shortText)
		{
		dp->txtH.dAnn = 0;
		ReleasePtr(doc);
		KillPtr(dp);
		}
	else
		{
		ReleasePtr(doc);
		KillPtr(dp);
		TBlockToStringDoc(doc);
		}

	TUTORcompress_darray(doc,DOCOFFSET);
	return(0);
	}

TUTORinsert_string_doc(doc,pos,ss,sLen) /* insert a non-styled string into doc */
Memh doc;	/* doc to be changed */
long pos;	/* position where insertion is done */
unsigned char FAR *ss;	/* pointer to string */
long sLen;	/* length of string */
	{
	long extraDumm;	/* dummy variable */
if (TUTORget_lockcount(doc) != 0) 
TUTORdump("incorrect lock count 2");	
	
	TUTORchange_doc(doc,pos,0L,0L,TUTORget_len_doc(doc),ss,sLen,0L,
			HNULL,HNULL,&extraDumm,FALSE);
	}

TUTORdelete_doc(doc,pos,len,extraPos)	/* delete chars from doc */
Memh doc;	/* document to be changed */
long pos,len;	/* position & length of region of doc to be deleted */
long *extraPos;	/* if exists, set to position where change actually ends */
	{
	long extraDumm;
	
	if (!extraPos)
		extraPos = &extraDumm;
if (TUTORget_lockcount(doc) != 0)
TUTORdump("incorrect lock count 3");	
	TUTORchange_doc(doc,pos,len,pos,len,FARNULL,0L,0L,HNULL,HNULL,extraPos,FALSE);
	}

TUTORchange_doc(doc,pos,len,mpos,mlen,cp,cLen,fromOff,styles,specialT,extraPos, eupFlag) /* change a doc */
Memh doc;	/* document being changed */
register long pos, len;	/* area that is being changed */
long mpos, mlen;	/* bounds of "marker" that is being changed */
unsigned char FAR *cp;	/* pointer to new text (could be NULL) */
long cLen;		/* length of new text */
long fromOff;	/* offset into styles & specialT handles that we start reading from */
Memh styles;	/* handle to styles.  0 if there are no styles but text has default style.
					If styles is -1 the new text will get the styles that exist at pos */
Memh specialT;	/* special text */
long *extraPos;	/* to be set to position where real end of change is
					(due to paragraph styles) - in terms of doc AFTER change */
int eupFlag;	/* if TRUE, handle updating of -edit- textviews */
/* returns success flag */
	{
	REGISTER DocP dp;	/* pointer to doc */
	int followP;	/* TRUE if char just before pos is NEWLINE */
	int lastN;		/* TRUE if last char of change is NEWLINE */
	int keyFlag;	/* TRUE if styles == -1.  We should propagate styeles at pos forward */
	
	if (extraPos == FARNULL)
		TUTORdump("TUTORchange_doc extraPos null"); /* dma trap */

	if (len == 0 && cLen == 0)
		{
		*extraPos = pos;
		return(TRUE); /* nothing to do */
		}
if (TUTORget_lockcount(doc) != 0)
TUTORdump("incorrect lock count 4");	
	dp = (DocP) GetPtr(doc);

#ifdef DOCVERIFY
	if (pos < 0L || pos+len > dp->totLen)
		TUTORdump("TUTORchange_doc bad region");
#endif

	_TUTORchange_text_doc(dp,pos,len,cp,cLen,&followP);
	dp = (DocP) GetPtr(doc); /* recover pointer (change_text unlocked it) */
	
	if (!dp->shortText && dp->totLen <= MAXSTRINGLEN/2)
		{ /* change doc from tblock to short text */
		ReleasePtr(doc);
		KillPtr(dp);
		TBlockToStringDoc(doc);
		dp = (DocP) GetPtr(doc);
		}
	
	if (cp)
		lastN = (*(cp+cLen-1) == NEWLINE);
	else
		lastN = followP; /* bit of trickery - this makes test paragraph bounds check in
				TUTORchange_styles_doc work with only two calls to
				FixParagraphStyles */

	*extraPos = pos + cLen; /* default */
	keyFlag = FALSE;
	if (styles == (Memh) -1)
		{ /* This was key input.  No styles, AND carry styles at pos forward */
		styles = 0;
		keyFlag = TRUE;
		}
		
	if (dp->styles || styles)
		_TUTORchange_styles_doc(dp,pos,len,cLen,styles,fromOff,followP,lastN,extraPos,keyFlag);
		
	if (dp->specialT || specialT)
		_TUTORchange_stext_doc(dp,pos,len,cLen,specialT,fromOff);

	_TUTORupdate_markers_doc(dp,mpos,mlen,pos,len,cLen,*extraPos);
	
	dp->changed = TRUE;
	
	if (eupFlag && dp->editPanel) /* maintain view on document */
		TUTORmaintain_doc_view(dp,pos,*extraPos-pos,pos,len,cLen);
			
	ReleasePtr(doc);
	KillPtr(dp);
	
	return(TRUE);
	}

TUTORchange_doc_doc(docD,pos,len,mpos,mlen,docS,posS,lenS,extraPos,eupFlag) /* change doc from doc */
Memh docD;	/* doc to be changed (destination) */
long pos,len;	/* where to change docD */
long mpos, mlen;	/* bounds of "marker" being changed */
Memh docS;	/* doc where change is coming from (source) */
long posS, lenS;	/* where change comes from */
long *extraPos;	/* position at end of additional (paragaph data) change */
int eupFlag;	/* if TRUE, handle updating of -edit- textviews */
/* returns success flag */
	{
	REGISTER DocP dps;	/* pointer to source document (docS) */
	REGISTER DocP dpd;	/* pointer to destination document (docD) */
	Memh tempDoc;	/* document used as scratch */
	unsigned char FAR *tp;	/* points to current source text (in text blocks) */
	int retVal;		/* success flag to return */
	int ii;
	DArrayHeader FAR *dap;	/* dynamic array header for text blocks */
	TextBlock FAR *curBlock, FAR *endBlock;	/* current & last text block of document */
	long relPos;	/* where, in block, current position is */
	long eOff;		/* # of chars left in current text block */
	long cLen;		/* # of chars we are adding in next call to change_text */
	long nextPos;	/* position of chars in next call to change_text */
	long nextLen;	/* # of chars we want to replace in next call to change_text */
	long tempL;
	register long lenLeft;	/* # of chars (of lenS) we have left to add to docD */
	int followP;	/* TRUE if new text is start of paragraph */
	int lastN;		/* TRUE if new text ends a paragraph */
	int lastB;		/* TRUE when we are on last text block of change */
	
	if (TUTORget_lockcount(docS) != 0) 
		TUTORdump("incorrect lock count 5");
	
	if (!docS || lenS <= 0)
		{ /* we are just deleting chars */
		return(TUTORchange_doc(docD,pos,len,mpos,mlen,FARNULL,0L,0L,(Memh) 0,
				(Memh) 0,extraPos,eupFlag));
		}
	
	if (docS == docD)
		{ /* changing ourselves, copy source to temporary doc and use it for change */
		tempDoc = TUTORnew_doc(TRUE,TRUE);
		TUTORchange_doc_doc(tempDoc,0L,0L,0L,0L,docS,posS,lenS,&tempL,FALSE);
		retVal = TUTORchange_doc_doc(docD,pos,len,mpos,mlen,tempDoc,0L,
				lenS,extraPos,eupFlag);
		TUTORclose_doc(tempDoc);
		
		return(retVal);
		}

	dps = (DocP) GetPtr(docS);

#ifdef DOCVERIFY
	if (posS < 0L || posS+lenS > dps->totLen)
		TUTORdump("TUTORchange_doc_doc bad regionS");
#endif
	
	if (dps->shortText || lenS < dps->txtH.dAnAlloc)
		{ /* this can be handled by TUTORchange_doc */
		if (!dps->shortText && (posS < dps->buffStart || posS+lenS > dps->buffEnd))
			_TUTORload_buffer_doc(dps,posS);  /* make sure buffer has change text */
		
		retVal = TUTORchange_doc(docD,pos,len,mpos,mlen,
						(unsigned char FAR *) dps->text+(posS-dps->buffStart),lenS,posS,
						dps->styles, dps->specialT,extraPos,eupFlag);
		
		}
	else
		{ /* text in tblocks */
		/* get each relevant tblock and change the text block by block */
		curBlock = FindTBlock(dps,posS,&relPos,&eOff);
		dap = (DArrayHeader FAR *) ((char FAR *) dps + dps->offsets[DOCTBLOCK]);
		/* endBlock = ((TextBlock FAR *) (dap+1)) + (dap->nn - 1); /* points at last block */
		dpd = (DocP) GetPtr(docD);

#ifdef DOCVERIFY
	if (pos < 0L || pos+len > dpd->totLen)
		TUTORdump("TUTORchange_doc_doc bad regionD");
#endif

		nextPos = pos;
		nextLen = len;
		lenLeft = lenS;
		while (lenLeft)
			{ /* keep going until we have put in all new chars */
			tp = (unsigned char FAR *) GetPtr(curBlock->text) + relPos;
			if (eOff >= lenLeft)
				{ /* this will be last block of change */
				lastB = TRUE;
				cLen = lenLeft;
				lastN = (*(tp+(cLen-1)) == NEWLINE);
				}
			else
				{
				lastB = FALSE;
				cLen = eOff;
				}
			_TUTORchange_text_doc(dpd,nextPos,nextLen,tp,cLen,lastB ? &followP : NEARNULL);
			dpd = (DocP) GetPtr(docD); /* recover pointer (change_text unlocked it) */
			ReleasePtr(curBlock->text);
			KillPtr(tp);
			
			lenLeft -= cLen;
			nextLen = 0; /* only want to replace text on first call to change_text */
			nextPos += cLen;
			if (lenLeft)
				{
				curBlock++; /* look at next block */
				eOff = curBlock->tLen;
				relPos = 0L;
				}
			}

		/* now take care of styles, etc. */
		*extraPos = pos+lenS; /* default */
		if (dpd->styles || dps->styles)
			_TUTORchange_styles_doc(dpd,pos,len,lenS,dps->styles,posS,followP,lastN,extraPos,FALSE);
		
		if (dpd->specialT || dps->specialT)
			_TUTORchange_stext_doc(dpd,pos,len,lenS,dps->specialT,posS);
	
		_TUTORupdate_markers_doc(dpd,mpos,mlen,pos,len,lenS,*extraPos);
	
		dpd->changed = TRUE;
	
		if (eupFlag && dpd->editPanel) /* maintain view on document */
			TUTORmaintain_doc_view(dpd,pos,*extraPos-pos,pos,len,lenS);
			
		ReleasePtr(docD);
		KillPtr(dpd);
		retVal = TRUE;
		}

	ReleasePtr(docS);	
	KillPtr(dps);
	return(retVal);
	}

static _TUTORchange_text_doc(dp,pos,len,cp,cLen,followP) /* change text of a document */
REGISTER DocP dp;	/* pointer to document (document is unlocked at end of this routine) */
register long pos, len;	/* position & length (in chars) where change takes place */
unsigned char FAR *cp;	/* new characters */
register long cLen;	/* length of new characters */
int *followP;	/* if exists, set to true if char just before pos is NEWLINE */
	{
	int unlocked2;	/* TRUE if ChangeTBlock unlocks doc */
	Memh doc;	/* document dp refers to */
	
	/* note that we are called with doc locked but the caller expects this routine
		to unlock the doc */

	doc = dp->self;
if (TUTORget_lockcount(doc) != 1)
TUTORdump("incorrect lock count in TUTORchange_text_doc");	
	if (dp->shortText && dp->totLen + cLen - len <= MAXSTRINGLEN)
		{ /* easy change for text */
		dp->totLen += cLen - len;
		dp->buffEnd = dp->totLen;
		if (followP)
			*followP = ((pos == 0) || (dp->text[pos-1] == NEWLINE));
		
		ReleasePtr(doc);
		KillPtr(dp);
		TUTORreplace_darray(doc,FARNULL,DOCOFFSET,DOCTEXT,(int) pos,
				(int) len, (int) cLen, (char FAR *) cp);
		}
	else
		{ /* change text thru textblocks */
		if (dp->shortText)
			{ /* need to convert to textblock doc */
			ReleasePtr(doc);
			KillPtr(dp);
			StringToTBlock(doc);
			dp = (DocP) GetPtr(doc);
			}
		ChangeTBlock(dp,pos,len,cp,cLen,&unlocked2,followP);
		if (!unlocked2)
			{ /* unlock (as caller expects) */
			ReleasePtr(doc);
			KillPtr(dp);
			}
		}
	
	return 0;
	}

/* update styles of document to reflect document change: */
static _TUTORchange_styles_doc(dp,pos,len,cLen,styles,fromStart,followP,lastN,extraPos,keyFlag)
register DocP dp;	/* pointer to document */
register long pos,len;	/* position & length of text that was replaced */
register long cLen;	/* length of new text */
Memh styles;	/* structure of styles being added */
long fromStart;	/* position within styles we start looking at */
int followP;	/* if TRUE, pos immediately follows a paragraph break */
int lastN;		/* TRUE if last char of new text was paragraph break */
long *extraPos; /* only reset if not == pos+cLen */
int keyFlag;	/* if TRUE styles of new text absorb preceeding styles.  Normally FALSE,
					in which case new text has DEFSTYLE for all styles */
	{
	long tempL;
	int ii;
	short addedStyles;	/* TRUE if styles are added in this routine */
	long oldLen; /* previous length of document */
	StyleDatP pp;	/* pointer to style structure */
	Style1 SHUGE *s1p; /* pointer to single style entry */
	
	/* bizarre stuff - dma 4/7/94 */
	/* AddTStyle deletes styles after end of document - since style positions are */
	/* brought up to date by adjusting for new text first, then adjusting for */
	/* deleted text, we want to give AddTStyle the maximum length possible during */
	/* the update, then clean up anything styles after the end of the document */
	/* after doing everything else */
	
	oldLen = dp->totLen+len+cLen; /* maximum length */
	if (!dp->styles && styles)
		{ /* don't have styles but we need to add them */
		dp->styles = NewTStyle();
		}
	addedStyles = FALSE;
	if (styles)
		{
		SpliceTStyle(dp->styles,styles,pos+len,fromStart,cLen,dp->totLen+len);
		addedStyles = TRUE;
		}
	else
		{
		InsertTStyle(dp->styles,pos+len,cLen,TRUE);	
		if (!keyFlag && cLen > 0)
			{ /* add DEFSTYLEs so that added text doesn't pick up the styles at pos.
				This is what is normally wanted.  The only exception is keystrokes */
/* oldLen used to be dp->totLen+cLen - this caused styles at end */
/* of document to be deleted in AddTStyle when document got shorter as */
/* style positions are still in terms of old document   dma 4/5/94 */
			for (ii=0; ii<NSTYLES; ii++) {
				AddTStyle(dp->styles,pos+len,cLen,oldLen,ii,DEFSTYLE,FALSE);
			}
			}
		}
	if (len)
		DeleteTStyle(dp->styles,pos,len);

	/*	ksw-documentation
		A note about paragraph styles.
		Paragraph styles are maintained so that they always start just after a newline
		(or the document start) and always end just after a newline (or the document
		end).  Note that there are a very few documents (such as cT's textpool) where
		this style propagation is undesired.  These documents have the flag dp->honorP
		set to FALSE.
		
		When we delete a newline the paragraph styles propagate forward; so the
		paragraph style before the deleted newline will be extended to cover what
		used to be a following paragraph (possibly overriding a previous style).
		
		Similarly, when we splice in text, paragraph styles propagate forward.  The
		paragraph style of the original text will propagate forward into the new
		text up to and including the first newline.  Unless the character just before
		the new text is a newline, which stops the style propagation.  And the style
		at the end of the new text propagates forward up to and including the following
		newline, unless the last character in the new text is a newline, which would
		stop the propagation there.
		
		When paragraph styles are added we allow them to operate like other styles
		and then we enforce the paragraph boundaries (using the propagation rules
		above) simply by deleting style blocks at the boundaries of our change that
		are not in line with newlines.  This gives the desired effect easily.
		
		Note that a very important side effect of all of this is that it is possible
		to change the style of text FOLLOWING a change (up to a newline in fact).  This
		is the point of the extraPos argument.  It is used so that the routines
		making the change can properly keep track of what portion of the document has
		been changed, since the change can extend outside the boundaries of a text
		replacement.  This extraPos is needed to properly update a text view, or marker
		changed flags, for instance.
		
	*/
	
	if (dp->honorP)
		{ /* make sure paragraph styles are at paragraph boundaries */
		if (addedStyles && !followP)
			{ /* look at position pos for superfluous paragraph style dat */
			FixParagraphStyles(dp,pos,cLen,NEARNULL);
			}
		if (!lastN) /* end of new text not paragraph boundary */
			{ /* look at position pos + cLen for superfluous paragraph style dat */
			tempL = pos+cLen;
			FixParagraphStyles(dp,tempL,dp->totLen - tempL,extraPos);
			}
		}

	/* get rid of any styles at or after document end */

	if (dp->styles) {
		pp = (StyleDatP) GetPtr(dp->styles);
		if (pp->sHead.dAnn) {
			s1p = ((Style1 SHUGE *) pp->styles) + (pp->sHead.dAnn-1); /* last style */
			while (s1p->pos && s1p->pos >= dp->totLen) {
				if (s1p == pp->styles)
					break; /* at begin of table */
				if ((s1p->type >= 0) && (s1p->type < NSTYLES))
					(pp->nStyles[s1p->type])--;
				s1p--;
			}
			pp->sHead.dAnn = (s1p-(Style1 SHUGE *)pp->styles)+1;
		} /* nn if */
		ReleasePtr(dp->styles);
		KillPtr(pp);
	} /* dp->styles if */
	
	if (!CheckKeepTStyle(dp->styles))
		{ /* get rid of the styles */
		CloseTStyle(dp->styles);
		dp->styles = HNULL;
		}

	
	return 0;
	}

TUTORstyle_doc(doc,pos,len,type,dat,canCombine,extraPos) /* add style to document */
Memh doc;	/* document getting new style */
register long pos, len;	/* position & length of new style */
int type;	/* type of the style (FONTSTYLE, SIZESTYLE, etc.) */
int dat;	/* data of style (font family index, SIZEBIGGER, etc.) */
int canCombine;	/* for face, if can xor the styles.
				/* for size, if this is relative change. */
				/* for para - which field, 0: all, else by mask */
long *extraPos;	/* if exists, set to where change actually ends */
/* always returns FALSE */
	{
	REGISTER DocP dp;	/* pointer to doc */
	unsigned char tempS[2];	/* target string to search for NEWLINEs */
	long foundNewline;	/* TRUE if a newline is found */
	register long styleEnd;	/* position of end of newly styled region */
	int retVal;	/* return value */
	
	retVal = FALSE; /* always the case */
	
	dp = (DocP) GetPtr(doc);

#ifdef DOCVERIFY
	if (pos < 0L || pos+len > dp->totLen)
		TUTORdump("TUTORstyle_doc bad region");
#endif

	if (!dp->styles)
		{ /* no styles till now, add them */
		dp->styles = NewTStyle();
		}
	
	if (type == PARASTYLE)
		{ /* make sure that style is added on paragraph boundary */
		tempS[0] = NEWLINE;
		foundNewline = TUTORsearch_string_doc(dp,tempS,1L,pos,0L);
		styleEnd = pos+len; /* original end of style region */
		if (foundNewline >= 0)
			pos = foundNewline+1; /* start of current paragraph */
		else
			pos = 0L; /* current paragraph starts at beginning of document */
		foundNewline = TUTORsearch_string_doc(dp,tempS,1L,
                                            styleEnd- ((len > 0) ? 1L : 0L),dp->totLen);
		if (foundNewline >= 0)
			len = foundNewline+1 - pos;
		else
			len = dp->totLen - pos;
		}
	
	if (extraPos)
		*extraPos = pos+len; /* the end of the style as we actually apply it */
	AddTStyle(dp->styles, pos, len, dp->totLen, type, dat, canCombine);

	_TUTORupdate_markers_doc(dp,0L,dp->totLen,pos,0L,0L,pos+len);
	
	if (!CheckKeepTStyle(dp->styles))
		{ /* get rid of the styles */
		CloseTStyle(dp->styles);
		dp->styles = HNULL;
		}
	
	ReleasePtr(doc);
	KillPtr(dp);
	
	return(retVal);
	}

TUTORcharat_doc(doc,pos)	/* get char at given position */
Memh doc;	/* document we are querying */
register long pos;	/* position we want char from */
	{
	register int retVal;	/* the returned value */
	REGISTER DocP dp;	/* pointer to doc */
	unsigned char tempS[8];	/* buffer for get_string call */
	register long pos2;	/* slightly backed up pos */
	
	dp = (DocP) GetPtr(doc);
	if (dp->shortText || (pos < dp->buffEnd && pos >= dp->buffStart))
		{
		retVal = dp->text[pos - dp->buffStart];
		ReleasePtr(doc);
		KillPtr(dp);
		}
	else
		{ /* load up buffer via get_string call */
		ReleasePtr(doc);
		KillPtr(dp);
		pos2 = (pos > 4) ? pos - 4 : 0; /* load buffer a little before pos */
		TUTORget_string_doc(doc,pos2,5L,(unsigned char FAR *) tempS);
		retVal = tempS[pos-pos2];
		}
	
	return(retVal);
	}

TUTORget_string_doc(doc,pos,len,destS) /* read text string from document */
Memh doc;	/* document to read from */
register long pos,len;		/* where to get text from */
unsigned char FAR *destS;	/* where to put text (needs to be of size len+1) */
/* returns # of chars actually put in string */
	{
	REGISTER DocP dp;	/* pointer to doc */
	register long cLen;		/* number of chars we can move from current buffer */
	long offset;	/* offset into destS where next block_move should copy */
	register long readLeft;	/* # of chars we still need to transfer */
	
	if (len <= 0)
		return(0);
	
	dp = (DocP) GetPtr(doc);
	if (pos + len > dp->totLen)
		len = dp->totLen - pos; /* clip to not go past document end */
	
	if (dp->shortText || (pos >= dp->buffStart && pos+len <= dp->buffEnd))
		TUTORblock_move(((char SHUGE *) dp->text) + (pos-dp->buffStart),(char FAR *) destS,len);
	else
		{ /* need to move proper text into buffer from text blocks */
		offset = 0L;
		readLeft = len;
		while (readLeft)
			{
			_TUTORload_buffer_doc(dp,pos);
			cLen = (dp->txtH.dAnn >= readLeft) ? readLeft : dp->txtH.dAnn;
			TUTORblock_move(((char SHUGE *) dp->text) + (pos-dp->buffStart),(char FAR *) (destS+offset),cLen);
			readLeft -= cLen;
			pos += cLen;
			offset += cLen;
			}
		}
	ReleasePtr(doc);
	KillPtr(dp);
	
	*(destS+len) = '\0'; /* null terminate */
	
	return(len);
	}

_TUTORload_buffer_doc(dp,pos) /* load document's buffer from text blocks */
register DocP dp;	/* pointer to document */
register long pos; /* where to start buffer load */
	{
	register long cLen;	/* # of chars to copy into buffer */
	register unsigned char FAR *cp;	/* pointer to text buffer */
	register TextBlock FAR *curBlock;	/* pointer to a text block */
	long pOff;	/* relative position in current text block */
	long eOff;	/* # of chars following pOff in current text block */
	register long nLeft;	/* # of chars left to copy */
	
	cLen = dp->txtH.dAnAlloc; /* space currently available in text buffer */
	if (pos+cLen > dp->totLen)
		pos = dp->totLen - dp->txtH.dAnAlloc;
	if (pos < 0)
		{
		pos = 0L;
		cLen = dp->totLen;
		}
	cp = (unsigned char FAR *) dp->text;
	curBlock = FindTBlock(dp,pos,&pOff,&eOff);
	nLeft = cLen;
	while (nLeft > 0L) /* copy chars from textblocks to cp */
		{
		if (eOff > nLeft)
			eOff = nLeft;
		TUTORblock_move(GetPtr(curBlock->text)+pOff,(char SHUGE *) cp,eOff);
		ReleasePtr(curBlock->text);
		nLeft -= eOff;
		cp += eOff;
		if (nLeft > 0L)
			{
			curBlock++;
			pOff = 0L;
			eOff = curBlock->tLen;
			}
		}
	dp->txtH.dAnn = cLen;
	dp->buffStart = pos;
	dp->buffEnd = pos+cLen;
	
	return 0;
	}

long TUTORget_len_doc(doc)
register Memh doc;	/* document we want length of */
	{
	REGISTER DocP dp;	/* pointer to document */
	register long len;	/* the returned length */
	
	dp = (DocP) GetPtr(doc);
	len = dp->totLen;
	ReleasePtr(doc);
	KillPtr(dp);
	
	return(len);
	}

/* make sure paragraph styles are aligned with paragraph boundaries */
static FixParagraphStyles(dp,pos,checkLen,newEnd)
register DocP dp;	/* pointer to document */
long pos;	/* position where there may be a superfluous style */
long checkLen;	/* range where we look for newline */
long *newEnd;	/* if exists, to be set to new end of change */
/* returns TRUE if did any fixing */
	{
	StyleDatP pp;	/* pointer to style structure */
	register Style1 SHUGE *s1p, SHUGE *s1End;	/* current & last style block */
	int ind;	/* index of current style block */
	short haveAfter;	/* TRUE if there is a following paragraph style block */
	int afterInd;	/* index of next paragraph style block */
	short afterDat;	/* data of next paragraph style block */
	long afterPos;	/* position (in doc) of next paragraph style block */
	short beforeDat;	/* data of preceeding paragraph style */
	long beforePos;		/* position (in doc) of preceeding paragraph style block */
	long foundNewline;	/* TRUE if we found a newline */
	unsigned char tempS[2];	/* newline search target string */
	
	pp = (StyleDatP) GetPtr(dp->styles);
	
	ind = FindBlockTypeTStyle(pp,pos,PARASTYLE);
	s1p = ((Style1 SHUGE *) pp->styles) + ind;
	if (s1p->pos != pos || s1p->pos == 0)
		{ /* no block at pos, or block is at beginning, so no work to do */
		ReleasePtr(dp->styles);
		KillPtr(pp);
		return(FALSE);
		}
	
	/* to maintain paragraph boundaries we want to shove this style forward to the
		next newline, but no further than checkLen.  If there isn't a newline
		by checkLen, then just delete block */
	
	/* we need to know style & position of preceeding block */
	s1p--;
	while (s1p->type != PARASTYLE)
		s1p--; /* go back to preceeding paragraph style */
	beforeDat = s1p->dat;
	beforePos = s1p->pos;
	
	/* we also want style & position of following block */
	s1p = ((Style1 SHUGE *) pp->styles) + (ind+1);
	s1End = ((Style1 SHUGE *) pp->styles) + pp->sHead.dAnn;
	while (s1p < s1End && s1p->type != PARASTYLE)
		s1p++; /* go forward to next paragraph style */
	if (s1p < s1End)
		{
		haveAfter = TRUE;
		afterDat = s1p->dat;
		afterInd = s1p - (Style1 SHUGE *)pp->styles;
		afterPos = s1p->pos;
		}
	else
		{
		haveAfter = FALSE; /* there wasn't a following paragraph style */
		afterPos = dp->totLen;
		}
	
	/* look for newline which occurs before end of region */
	tempS[0] = NEWLINE;
	foundNewline = TUTORsearch_string_doc(dp,tempS,1L,pos,pos+checkLen-1);
	
	if (foundNewline < 0)
		{ /* delete the superfluous style at pos */
		TUTORdelete_darray(dp->styles,(char FAR *) pp,STYLEOFFSET,0,ind,1);
		pp->nStyles[PARASTYLE]--;
		afterInd--; /* must adjust for block deleted */
		
		/* if needed, delete the following block also */
		if (haveAfter && afterDat == beforeDat)
			{
			s1p = ((Style1 SHUGE *)pp->styles)+afterInd;
			if (s1p->type == PARASTYLE) {
				TUTORdelete_darray(dp->styles,(char FAR *) pp,STYLEOFFSET,0,afterInd,1);
				pp->nStyles[PARASTYLE]--;
			}
			}
		
		if (newEnd)
			*newEnd = afterPos;

#ifdef DOCVERIFY
		if (pp->sHead.dAnn < NSTYLES)
			TUTORdump("Too few styles in FixParagraphStyles");
#endif
		ReleasePtr(dp->styles);
		KillPtr(pp);
		}
	else
		{ /* move the style to just after newline */
		ReleasePtr(dp->styles);
		KillPtr(pp);
		AddTStyle(dp->styles, pos, foundNewline+1 - pos, dp->totLen, PARASTYLE,
					beforeDat, 0);
		if (newEnd)
			*newEnd = foundNewline+1;
		}
	
	return(TRUE);
	}

/* ******************************************************************* */

TUTORdefault_styles_font_doc(font,doc) /* give a doc default styles from a font */
int font;	/* which font to use */
Memh doc;	/* document to have default styles set */
	
{   short defStyles[NSTYLES];	/* array of default styles we want */
    long fFamily;
    int fSize;	/* font family & size of font */
    struct tutorColor fc;
	
	TUTORinq_font_descr(font,&fFamily, &fSize, NEARNULL);
	TUTORinq_foreground_color(&fc);
	defStyles[FONTSTYLE] = fFamily;
	defStyles[SIZESTYLE] = fSize;
	defStyles[FACESTYLE] = 0;	/* plain */
	defStyles[PARASTYLE] = 0;	/* the default */
	defStyles[COLORSTYLE] = fc.palette; /* CvtTextColor((struct tutorColor FAR *)&fc);  */
	defStyles[HOTSTYLE] = 0;	/* not hot */
	TUTORdefault_styles_doc(doc,(short FAR *) defStyles);
	
} /* TUTORdefault_styles_font */

/* ******************************************************************* */

TUTORdefault_styles_doc(doc,defStyles) /* set document default styles */
register Memh doc;	/* document to have default styles set */
register short FAR *defStyles; /* array of new defaults (each item ignored if == DEFSTYLE) */
	{
	REGISTER DocP dp;	/* pointer to document */
	register int ii;
	
	dp = (DocP) GetPtr(doc);
	for (ii=0; ii<NSTYLES; ii++)
		if (defStyles[ii] != DEFSTYLE)
			dp->defStyles[ii] = defStyles[ii];
	
	ReleasePtr(doc);
	KillPtr(dp);
	}

TUTORget_default_styles_doc(doc,defStyles)	/* return document's default styles */
Memh doc;	/* the document whose styles we are interested in */
register short FAR *defStyles;	/* to be filled with doc's default styles */
	{
	REGISTER DocP dp;	/* pointer to document */
	register int ii;
	
	dp = (DocP) GetPtr(doc);
	for (ii=0; ii<NSTYLES; ii++)
		defStyles[ii] = dp->defStyles[ii];
	ReleasePtr(doc);
	KillPtr(dp);
	}
