
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* file i/o of documents */

#include <stdio.h>
#include "baseenv.h"
#include "txt.h"
#include "chardef.h"
#include "tutor.h"
#include "kglobals.h"
#include "tfiledef.h"
#include "tglobals.h" 

#ifdef WINPC
#define STRICT
#include <windows.h>
#include "ctmsw.h"
#endif

#ifdef MAC
#include <Quickdraw.h>
#ifdef THINKC5
#include <Windows.h>
#include <Quickdraw.h>
#include <Palettes.h>
#include <QDOffscreen.h>
#else
#ifdef WERKS
#include <Windows.h>
#include <Quickdraw.h>
#include <Palettes.h>
#include <QDOffscreen.h>
#else
#include <WindowMgr.h>
#include <Color.h>
#endif
#endif
#endif /* mac */

#ifdef X11
#include "x11i.h"
#endif

#define CURVERSION 1

#ifdef ctproto
extern int  TUTORrgb_to_hsv(double  red,double  green,double  blue,double  *hue,double  *saturation,double  *value);
extern int TUTORfree_palette(Memh palH);
int add_to_pal(struct CTcolorentry FAR *pp,unsigned int rr,unsigned int gg,unsigned int bb);
extern Memh TUTORalloc_palette(int pSlots);
extern Memh TUTORget_pal_region(long regionID);
extern Memh TUTORget_rgb_region(long regionID);
extern Memh palettize_pixmap(Memh regionH);
extern long ReadRawText(unsigned char FAR *buffP,long len);
extern int FontDat3(int dat);
extern int SimpleCRfix(void);
int TUTORtemp_file_name(FileRef FAR *baseN,FileRef FAR *tempN);
extern long TUTORmem_to_region(int type,int width,int height,Memh palH,unsigned char SHUGE *bP);
int  TUTORinsert_string_doc(unsigned int  doc,long  pos,unsigned char  FAR *ss,long  sLen);
int  TUTORdelete_doc(unsigned int  doc,long  pos,long  len,long  *extraPos);
long  TUTORsearch_string_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sLen,long  pos,long  posEnd);
static int FixDocCR(Memh hh);
extern int TUTORfwrite_bitmap(int fInd,SText FAR *st1p);
extern int TUTORfwrite_pixmap(int fInd,SText FAR *st1p);
extern int TUTORfwrite_icons(int fInd,SText FAR *st1p);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
extern int cvt_font_name(char *str);
extern int ReadBitmap(Memh doc,long pos);
extern int ReadPixmap(Memh doc,long pos);
extern int ReadIcons(Memh doc,long pos);
int  TUTORfwrite_native_doc(unsigned int  doc,long  pos,long  len,int  fInd);
int  TUTORfread_doc(unsigned int  doc,long  len,int  docKind,int  fInd);
extern int  ReadDatastream(unsigned int  doc,long  len);
extern int  GetSourceChars(char  *tempS,int  nc,int  breakC);
extern int  GetSourceCharsReal(char  *tempS,int  nc,int  breakC);
extern int  ReadText(int  exact);
extern int  DetermineKind(void);
extern int  ReadStyle(unsigned int  *styles,long  pos,short  *lastStyles,struct  _sty1 *lastS);
int  ReadHotText(unsigned int  styles);
int  FinishReadSpecial(char  *name);
extern int  TranslateStyle(int  readStyle,short  FAR *sTable,int  nTable,short  FAR *ourTable);
extern int  ReadFontTable(void);
extern int  ReadParaTable(void);
extern int  ReadSpecialChar(unsigned int  doc,long  pos);
extern int  TUTORfread_native_doc(unsigned int  doc,long  len);
int  _TUTORadd_tblock_doc(unsigned int  theD,unsigned int  textH,long  tLen);
extern long  StripCR(unsigned char  FAR *t0,long  len);
int  TUTORfwrite_doc(unsigned int  doc,long  pos,long  len,int  fInd,int  nativeF);
extern int  WriteHeader(int  ff,short  *curStyles,struct  _pdt FAR *sp,struct  _sty1 FAR *s1p,long  end);
extern int  AddTable(short  *tbl,int  nTable,int  dat);
extern int  WriteTrailer(int  ff);
extern int  WriteText(int  ff,unsigned char  FAR *t0,long  tLen);
extern int  WriteStyle(unsigned int  pd,int  ff,int  type,int  dat,unsigned int  *hotList);
extern int  TUTORfwrite_stext(int  fInd,struct  _stxt2 FAR *st1p);
int  WriteHottext(int  ff,unsigned int  hlist);
extern int  WriteLiteral(int  ff,char  *ss);
extern int  WriteEscape(int  ff,int  cc);
int  TUTORfree_handle(unsigned int  mm);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  TUTORseek(int  findx,long  pos);
long  TUTORinq_file_pos(int  findx);
int  TUTORread_be2_doc(int  infile,unsigned int  theD,unsigned char  FAR *memP,long  memLen);
long  TUTORwrite(char  FAR *ptr,int  pSize,long  count,int  findx);
unsigned char  FAR *TUTORscan_bytes(unsigned char  FAR *bp,unsigned char  FAR *be,unsigned char  *tp,int  nTab);
int  TUTORcvt_ct_chars(unsigned char  FAR *cp,long  clen);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORdump(char  *s);
int  TUTORclear_doc(unsigned int  doc);
int  CloseTStyle(unsigned int  pd);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
int  TBlockToStringDoc(unsigned int  doc);
int  TUTORinsert_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nIns);
int  CheckOrdering(struct  _pdt FAR *pp,char  *ss);
int  TUTORdealloc(char  FAR *ptr);
unsigned int  NewHotList(void);
int  AddTStyle(unsigned int  pd,long  start,long  len,long  docLen,int  type,int  newDat,int  combF);
unsigned int  NewTStyle(void);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  TUTORdelete_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nDel);
int  TUTORclose_doc(unsigned int  doc);
long  TUTORget_len_doc(unsigned int  doc);
unsigned int  TUTORnew_doc(int  string,int  honorP);
extern int TUTORzero(char SHUGE *ptr,long lth);
int  AllowHandlePurge(unsigned int  mm);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
int  AddParaLayout(struct  _paral *pl);
long TUTORadd_ffamily(struct  _fref *famName,int  isSys,int  isSwitch);
long TUTORinq_ffamily_id(struct  _fref *famName,int known);
int  TUTORsymbolic_fileref(struct  _fref FAR *fRef,char  FAR *syms);
int  TUTORcvt_native_chars(unsigned char  FAR *cp,long  clen);
int  TUTORadd_stext(unsigned int  st,long  pos,int  type,unsigned int  dat);
unsigned int  TUTORnew_stext(void);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
struct  _tblk FAR *FindTBlock(struct  _ktd FAR *dp,long  pos,long  *pOff,long  *eOff);
int  _TUTORsetup_layout(struct  _ktd FAR *dp,long  pos,long  len,int  *styleInd,struct  _pdt FAR * *styleP,short  *curStyles,struct  _paral *pLay,int  *stind,struct  _spt2 FAR * *stp,int  fillDef);
int  CloseHotList(unsigned int  hl);
int  GetParaLayout(int  ii,struct  _paral *pl);
int  TUTORinq_font_name(int  nn,char  *name,int  maxLen);
int  FontFamilyIndex(long  id);
int  AddHotList(unsigned int  hl,unsigned char  FAR *ss,long  len);
unsigned char  FAR *GetHotstringTStyle(unsigned int  pd,int  id,long  *len,long  *spos,long  *slen,int  getS);
#ifdef IBMPROTO
int _CDECL sscanf(const char *, const char *, ...);
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
#ifndef WERKS
extern int sscanf(char *ss, char *form,...);
extern int sprintf(char *ss, char *form,...);
#endif
extern Memh TUTORanything_to_pixmap(PicHandle pictH,long regionID);
#endif

#ifdef WINPC
extern int win_palettize_region(long regionID);
#endif

long  TUTORget_len_doc();
extern Memh TUTORnew_doc();
extern unsigned char FAR *GetHotstringTStyle();
extern TextBlock FAR *FindTBlock();
extern unsigned char FAR *TUTORscan_bytes();
extern long TUTORinq_file_pos();
extern long TUTORget_hsize();
extern long TUTORread();
static long StripCR();
extern long TUTORwrite();
extern long TUTORread();
extern Memh NewTStyle();
extern Memh TUTORhandle();
extern Memh TUTORnew_stext();

/* ksw-documentation  datastream format

Goal: A representation of styled text & embedded graphics that is 7-bit ascii and
    has a maximum of 70 characters per line.  This allows the files to be sent
    by even the most primitive mailers and file transfer mechanisms.

The basic idea:  Text is represented by itself, styles by escape sequences, special
    characters by other escape sequences.  The line size is limited by putting in
    special newlines when needed.

Details:
1) Ascii characters whose values are less than 127 are represented by themselves,
    with the exception of the character "@" (see rules 2 & 3).
2) The character "@" introduces an escape sequence.
3) The escape sequence "@@" represents the @ character.
4) There are two special escape sequences which delimit the beginning and end of
    the datastream.  "@cT datastream n" starts the datastream (with a version number
    of n).  And "@cT end" terminates the datastream.
5) The escape sequence "@newline" is a newline which has been added to the datastream
    to limit line size.  It is thrown away on input.  Any number of them can be
    placed in the output stream.
6) The escape sequence "@0xx" represents a single ascii character, whose hexadecimal
    encoding is xx.  For instance, the yen sign is "@0a5".  An @0 escape sequence
    always has exactly 4 characters.
7) The escape sequence "@1ssxxxx" indicates a style change.  The "ss" indicates the
    type of style.  The xxxx is a hexadecimal number which is the style data.  What
    the style data means is dependent on the style.  (See the documentation in
    tstyle.c)  An @1 escape sequence always has exactly 8 characters.
    Leading zeros in the xxxx may be replaced with spaces.
    a) fg: font group (or family)
    b) fs: font size
    c) ff: font face
    d) pl: paragraph
    e) cl: color
    f) ht: hot text
    Note that the most common xxxx is 8000, which is DEFSTYLE.  In datastream
    a bold cow is @1ff   1cow@1ff8000.
8) The escape sequence @4SSSS introduces a special data segment in the datastream.
    Such a data segment is terminated by @5SSSS.  The contents of the the data
    segment depend on what it is.  The types are:
    a) FONT: a font family table
        The font family table maps font names to the font family numbers of the
        original source.  This allows a font family style (an @1fg) to be refer
        to a font by name.  This is the only way to ensure cross-platform
        independence of font names.
        The font table format is simple.
        1) A line giving the number of entries in the table (decimal).
	2) For every entry in the table, the font family number (3 hex digits)
            followed by a space and then the font family name.
    b) PARA: a paragraph table
        The paragraph table maps paragraph layout numbers to the actual paragraph
        layout data.  This is needed because the actual layout numbers are assigned
        sequentially to layouts as they are created.  Two versions of cT with
        different histories will assign different layout numbers to the same layout
        data.  The format of the paragraph table is simple.
        1) A line giving the number of entries in the table (decimal).
        2) For every entry in the table (which takes up a line)
            a) paragraph layout number (hex)
            b) tab size (decimal)
            c) left margin (decimal)
            d) right margin (decimal)
            e) paragraph indent (decimal)
            f) extra line height (decimal)
    c) HOTT: a hot text table
        The hot text table contains the info text for each piece of hot text.
        It consists of
        1) The number of hot text items in the table.
        2) For each item, the length of the info text.
        3) A cT datastream which contains all the info text concatenated together,
            with the first item first, the second item second, etc.  Note that
            this results in a recursive call to the datastream read & write
            routines.  Currently the execution of hot text (what happens when the
            text is double-clicked) only handles plain text hot info strings but
            all the rest of the machinery supports fully styled info strings.  The
            datastream will handle styled and embedded graphic info strings just fine.
    d) STXT: a graphic character
        This is a machine independent representation of a graphic.
        It consists of (a thru f are each on a single seperate line)
            a) The kind of graphic character (decimal number).  (BITMAPSPECIAL, etc)
            b) Version number.  The version number is negative.  If a non-negative number
                is found, we assumme a version of -1 (the original) and that the read
                version is really the next item, the size.
            c) raster size, padded out to words
            d) pdx, pdy, bndx, bndy of character
            e) bnw, bnh, mapdx, mapdy of character
            f) mapw, maph of character
            g) the character raster.  The entire character image is written out, 4 hex
                characters to the word, 16 words per line.
    
    Note that the @1 styles for font group, paragraph and hot text reference the
    data from the @4 segment.  Without the @4 segment those styles have no real
    meaning.  The @4FONT and @4PARA segments are placed at the beginning of the
    datastream, the @4HOTT is placed at the end.  There can only be one of each
    type per datastream.  The @4STXT segments can be anywhere and there can be
    as many of them as desired in a datastream.

*/

#define HEADERTABLE 20
#define READSIZE 8000

/* BITMAPSPECIAL datastream version (must be negative) */
#define BITMAPVERS1 -1

#define PIXMAPVERS1 -1
#define PIXMAPVERS2 -2

/* reading globals */
/* these need to be saved & restored on recursive calls to TUTORread_doc */
static short FAR *familyTable=FARNULL;  /* table of font families in document */
static short FAR *ourFamilies=FARNULL;  /* our corresponding font family numbers */
static short nFamiliesL=0;  /* size of font tables */
static short FAR *paraTable=FARNULL;    /* table of paragraph styles in document */
static short FAR *ourPara=FARNULL;  /* our corresponding paragraph style numbers */
static short nPara=0;   /* size of paragraph tables */

static long readLeft;   /* # of chars we still want to read */

/* variables used to track reading of source file.  We don't want these variables duplicated on
    a recursive call to TUTORfread because a portion of the child document may already be in
    sourceH due to a call to ReadText made while processing the parent document */
static unsigned char FAR *source0, FAR *sourcep; /* pointers at chars we are reading from */
static long sourceLeft; /* # of chars in current source block that are left */
static Memh sourceH = HNULL;    /* the handle of current chunk of input characters */
static int sourceFile;  /* the input file index */
static char isMore; /* TRUE if there is more to read in the file */
static int crKind; /* 0 = 0x0a, 1 = 0x0d, 2 = 0x0d,0x0a */

/* variables we don't want duplicated when we do a recursive write: */
static short nUsed; /* # of chars used so far in current line */
static char ioErrV;  /* current io error */

static Memh rawBuffH = HNULL; /* input buffer for raw data */
#define RAWBUFFL 8192


/* size of temporary buffer to use for translating characters: */
#define TEMPBUFFS 8192L
static char FAR *tempS = FARNULL;

extern FileRef swapRef; /* swap file reference */

TUTORfwrite_native_doc(doc,pos,len,fInd) /* returns TRUE if worked, false if error */
Memh doc; /* the doc to write */
register long pos,len;  /* what portion of doc to write */
int fInd;   /* TUTOR file index */
    {
	int retF; /* return value */
    DocP dp;    /* pointer to document */
    char newLineS[2];   /* the newline sequence for IBMPCs */
    register long bufferLen;    /* # of characters we are currently translating & writing */
    register long buffPos;  /* position in buffer (tempS) */
    long tempL,retL;
    char FAR *cp;   /* set to position of found newline in buffer */
#ifdef MAC
    char saveIso; /* for saving state of isoAlphabet flag */
    extern char isoAlphabet; /* defined in tgraphmac.c */
#endif
    
	retF = TRUE; /* preset = worked */
    if (tempS == FARNULL)
        tempS = TUTORalloc(TEMPBUFFS+2L,TRUE,"tmp");
    dp = (DocP) GetPtr(doc);
    if (len < 0)
        len = dp->totLen;
    ReleasePtr(doc);
    KillPtr(dp);
    
#ifdef IBMPC
    newLineS[0] = 0x0d;
    newLineS[1] = 0x0a;
#endif

    while (len)
        {
        bufferLen = (len > TEMPBUFFS) ? TEMPBUFFS : len;
        TUTORget_string_doc(doc,pos,bufferLen, (unsigned char FAR *) tempS);
#ifdef MAC
        saveIso = isoAlphabet;
        isoAlphabet = 0; /* force conversion */
#endif
        TUTORcvt_ct_chars((unsigned char FAR *) tempS,bufferLen);
#ifdef MAC
        isoAlphabet = saveIso;
#endif
#ifdef IBMPC
        /* write out buffer, changing newlines to the newline sequence */
        buffPos = 0;
        while (buffPos < bufferLen)
            {
            cp = TUTORscan_bytes((unsigned char FAR *) (tempS+buffPos),(unsigned char FAR *) (tempS+bufferLen-1),
                                (unsigned char *) (newLineS+1),1);
            if (cp)
                { /* found a newline */
                tempL = (cp - (char FAR *) tempS) - buffPos; /* doesn't include NEWLINE */
                /* write up to newline */
                retL = TUTORwrite((char FAR *) (tempS+buffPos),1,tempL,fInd);
				if (retL != tempL) 
					retF = FALSE; /* something went wrong */
                retL = TUTORwrite((char FAR *) newLineS,1,2L,fInd); /* write newline sequence */
				if (retL != 2)
					retF = FALSE; /* something went wrong */
                tempL++; /* so that newline is skipped */
                }
            else
                { /* didn't find newline */
                tempL = bufferLen - buffPos; /* all the rest of the buffer */
                retL = TUTORwrite((char FAR *) (tempS+buffPos),1,tempL,fInd);
				if (retL != tempL)
					retF = FALSE; /* something went wrong */
                }
            buffPos += tempL;
            }
#else
        /* write out the buffer */
        retL = TUTORwrite((char FAR *) tempS,1,bufferLen,fInd);
		if (retL != bufferLen)
			retF = FALSE; /* something went wrong */
#endif
        len -= bufferLen;
        pos += bufferLen;
        }
    return(retF);
    }

TUTORfread_doc(doc,len,docKind,fInd)    /* read a document */
Memh doc;   /* existing, empty, document we want to fill */
long len;   /* # of chars we finally want (if < 0 read whole file) */
int docKind;    /* kind of document we are reading or -1 if not known, 0 = native, 1 = styled, 2 = be2 */
int fInd;   /* cT file index (assummed positioned at correct place) */
            /* correct place is either in middle of native file, or at begin of datastream */
/* returns success flag */
    {
    long tempL;
    int retVal;     /* the success flag to be returned */
    int ii;
    
    if (len < 0)
        len = 0x7fffffff; /* infinity, for our purposes */

    readLeft = len;
    sourceFile = fInd;
    
    
    if (sourceH) {
    	if (sourcep)
    		ReleasePtr(sourceH);
        TUTORfree_handle(sourceH);
    }   
    sourceH = HNULL;
    sourcep = FARNULL;

    ii = DetermineKind(); /* what kind of document is this? */

    if (docKind < 0)
	docKind = ii; /* set document kind */
    
    if (docKind == 2)
        { /* be2 - reset file & throw away what we've read */
        if (sourcep)
        	ReleasePtr(sourceH);
        sourcep = FARNULL;
        TUTORfree_handle(sourceH);
        sourceH = HNULL;
        TUTORseek(fInd,0L);
        ii = TUTORread_be2_doc(fInd,doc,FARNULL,0L); /* note that this always reads whole document */
		FixDocCR(doc);
		retVal = ii;
        goto fr_exit;
        }
    
    if (docKind == 0)
        { /* native */        
        TUTORfread_native_doc(doc,len);
		FixDocCR(doc);
        retVal = TRUE;
        goto fr_exit;
        }
    retVal = ReadDatastream(doc,len);
	FixDocCR(doc);
    if (sourceLeft > 0)
        { /* reposition file to right after what we've read */
        tempL = TUTORinq_file_pos(sourceFile);
		TUTORseek(sourceFile,tempL-sourceLeft);
        }

fr_exit:    
    if (sourceH)
        { /* free remaining source */
        if (sourcep)
        	ReleasePtr(sourceH);
        sourcep = FARNULL;
        TUTORfree_handle(sourceH);
        sourceH = HNULL;
        }
    return(retVal);
    }

static ReadDatastream(doc,len)  /* read a cT datastream */
Memh doc;   /* existing, empty, document we want to fill */
long len;   /* # of chars we finally want (if < 0 read whole file) */
/* returns success flag */
    {
    REGISTER DocP dp;   /* pointer to the document doc */
    Memh textH; /* handle of characters we are reading into */
    unsigned char FAR *dest0;   /* pointer to start of textH */
    unsigned char FAR *destP;   /* pointer to current position in textH */
    long textHLen;  /* # of characters transferred to textH */
    int ii;
    char tempS[30]; /* used to read the next couple of characters */
    register char cc;   /* most recently read character (or 0) */
    long pos0;  /* position (in document) of start of current text block */
    Memh styles;    /* the style structure */
    long tempL;
    int version;    /* cT datastream version we are reading */
    int retVal;     /* success flag to be returned */
    short lastStyles[NSTYLES];  /* the current style data */
    Style1 lastS;   /* the last style that was added */
    int needHot;    /* set to TRUE if we expect hot text immediately after
                        main portion of datastream */
    int getLen; /* length for GetSourceChars */

    /* when this routine is called, the reading machinery (sourceFile, sourceH, etc.)
        should already be set up */
    
    if (len < 0)
        len = 0x7fffffff; /* infinity, for our purposes */

    readLeft = len;
    needHot = FALSE;
    
    retVal = TRUE;
    
    /* initialize style stuff */
    styles = HNULL; /* no styles yet */
    
    for (ii=0; ii<NSTYLES; ii++)
        lastStyles[ii] = DEFSTYLE; /* for redundant style elimination */
    lastS.pos = -1; /* indicates nothing added yet */

    /* we will be writing into textH, translating as we go */
    textH = HNULL; /* so it will be allocated below */
    
    pos0 = 0L;

    /* we will read datastream until we have read in the number of characters that
        have been requested.  If, while reading those characters, we have encountered
        a hot text style, we will need to skip thru to the end of the document to read
        the hot text.  So if readLeft == 0 && needHot, we will be skipping.  In the
        code the normal mode (not skipping) is tested for with (readLeft > 0) */
    while (readLeft > 0 || needHot)
        {
        if (sourceLeft <= 0)
            { /* need to read more text */
            if (!sourceH)
                break; /* we've already run out of text */
            if (sourcep)
            	ReleasePtr(sourceH);
            sourcep = FARNULL;
            TUTORfree_handle(sourceH);
            sourceH = HNULL;
            ii = ReadText(FALSE);
            if (!ii)
                { /* no more to read */
                break;
                }
            }
        
        if (!textH)
            { /* need to allocate another textH */
            textH = TUTORhandle("textblck",9000L,FALSE);
            if (!textH)
                { /* can't proceed */
                if (sourcep)
                	ReleasePtr(sourceH);
                sourcep = FARNULL;
                TUTORfree_handle(sourceH);
                sourceH = HNULL;
                if (styles)
                    CloseTStyle(styles);
                TUTORclear_doc(doc);
                retVal = FALSE;
                break;
                }
            TUTORpurge_info(textH,M_WMRM,FARNULL,0);
    		AllowHandlePurge(textH);
            destP = dest0 = (unsigned char FAR *) GetPtr(textH);
            }

        if (*sourcep == '@')
            { /* special handling */
            sourcep++;  /* skip over at */
            sourceLeft--;
	    GetSourceChars(tempS,1,0); /* get next char */
	    cc = tempS[0];
            if (cc == '@')
                {
                if (readLeft > 0)
                    {
                    *destP++ = '@'; /* just an escaped at */
                    readLeft--;
                    }
                }
            else if (cc == NEWLINE) {
                if ((crKind == 2) && (NEWLINE == 0x0d)) {
                	GetSourceChars(tempS,1,0); /* finish skipping over 0x0d,0x0a */
                }
            } else if (cc == '0')
                { /* single char encoded in hex */
				GetSourceChars(tempS,2,0);
                if (readLeft > 0)
                    {
                    sscanf(tempS,"%x",&ii);
                    *destP++ = ii;
                    readLeft--;
                    }
                }
            else if (cc == '1')
                { /* style marker */
                if (readLeft > 0)
                    needHot |= ReadStyle(&styles,pos0 + (destP - dest0),lastStyles,&lastS);
                else
                    { /* we are skipping, just skip styles */
		    		GetSourceChars(tempS,6,0);
                    }
                }
            else if (cc == '4')
		{ /* table or special character entry */
			getLen = ((crKind == 2) ? 6: 5);
			GetSourceChars(tempS,getLen,0); /* table name and newline */
                if (!strncmp(tempS,"HOTT",4))
                    {
                    ReadHotText(styles);
                    needHot = FALSE; /* we've read hot text */
                    }
                else if (readLeft == 0)
                    { /* we are skipping, just scan over special text */
                    FinishReadSpecial(tempS);
                    }
                else if (!strncmp(tempS,"FONT",4))
                    ReadFontTable();
                else if (!strncmp(tempS,"PARA",4))
                    ReadParaTable();
                else if (!strncmp(tempS,"STXT",4))
                    {
                    if (readLeft > 0)
                        {
                        *destP = ReadSpecialChar(doc,pos0 + (destP - dest0));
                        destP++;
                        }
                    else {/* we are skipping, just skip over it */
                        FinishReadSpecial(tempS);
                        }
                    }
                else /* unrecognized special, just skip it */
                    FinishReadSpecial(tempS);
                }
            else if (cc == 'c')
                { /* datastream start or finish marker */
		GetSourceChars(tempS,29,NEWLINE);
                if (!strncmp(tempS,"T end",5))
                    { /* we have come to end of datastream - terminate */
                    readLeft = 0;
                    needHot = FALSE; /* we can't find hot text now... */
                    break;
                    }
                else if (!strncmp(tempS,"T datastream",12))
                    ; /* don't do anything (maybe we should read version?) */
                else TxtMemErr++; /* something went wrong */
		}
	    else if ((cc == 0x0d) && (crKind == 2)) {
		GetSourceChars(tempS,1,0); /* finish skipping over 0x0d,0x0a */
	    } else
                { /* incorrect escape, ignore it */
                if (readLeft > 0)
                    {
                    *destP++ = cc;
                    readLeft--;     
                    }       
                }
            cc = 0; /* for newline test below */
            }
        else if (*sourcep == 0)
            { /* skip nulls */
            sourcep++;
            sourceLeft--;
            cc = 0;
        } else if ((*sourcep == 0x0d) && (NEWLINE == 0x0a)) {
        	sourcep++; /* skip unused part of 0x0d, 0x0a */
        	sourceLeft--;
        } else if ((*sourcep == 0x0a) && (NEWLINE == 0x0d)) {
        	sourcep++; /* skip unused part of 0x0d, 0x0a */
        	sourceLeft--;
        } else {
            cc = *sourcep++;
            sourceLeft--;
            if (readLeft > 0)
                {
                *destP++ = cc;
                readLeft--;
                }
            }
        
        textHLen = destP - dest0;
        if (textHLen > 8900 || (cc == NEWLINE && textHLen > READSIZE))
            { /* we've got enough in this block and this is a good place to break */
            ReleasePtr(textH);
            KillPtr(destP);
            _TUTORadd_tblock_doc(doc,textH,textHLen);
            textH = HNULL; /* so we allocate another */
            pos0 += textHLen;
            }
        
        } /* end of while readLeft */
    
    /* if we have some text, we need to add it */
    if (textH)
        {
        textHLen = destP - dest0;
        ReleasePtr(textH);
        KillPtr(destP);
        _TUTORadd_tblock_doc(doc,textH,textHLen);
        }
    
    if (paraTable)
        {
        TUTORdealloc((char FAR *) ourPara);
        TUTORdealloc((char FAR *) paraTable);
        paraTable = FARNULL;
        }
    if (familyTable)
        {
        TUTORdealloc((char FAR *) ourFamilies);
        TUTORdealloc((char FAR *) familyTable);
        familyTable = FARNULL;
        }
    nFamiliesL = nPara = 0;
    
    /* clean up document */
    
    dp = (DocP) GetPtr(doc);
    dp->shortText = FALSE;
    if (styles)
        { /* add styles to doc */
        dp->styles = styles;
#ifdef DOCVERIFY
            {
            StyleDatP pp;
            pp = (StyleDatP) GetPtr(styles);
            CheckOrdering(pp,"fread_doc");
            ReleasePtr(styles);
            KillPtr(pp);
            }
#endif
        }
    
    if (dp->totLen < MAXSTRINGLEN-200)
        {
        ii = TRUE;
        ReleasePtr(doc);
        KillPtr(dp);
        }
    else
        {
        ii = FALSE;
        /* we need to make sure that document has large buffer */
        if (dp->txtH.dAnAlloc < TBUFFLEN)
            { /* need to insert some items (so text buffer will be of size TBUFFLEN) */
            dp->txtH.dAnn = dp->txtH.dAnAlloc;
            dp->txtH.nBuff = 10;
            ii = TBUFFLEN - dp->txtH.dAnn; /* # of items to insert */
            ReleasePtr(doc);
            KillPtr(dp);
            TUTORinsert_darray(doc,FARNULL,DOCOFFSET,DOCTEXT,-1,ii);
            } else {
                ReleasePtr(doc);
                KillPtr(dp);
            }
        }
    if (ii)
        TBlockToStringDoc(doc); /* convert to string doc */
    return(retVal);
    }

static GetSourceCharsReal(tempS,nc,breakC) /* get non-blank characters */
char *tempS; /* to be filled with the next nc characters */
int nc; /* # of chars wanted */
int breakC; /* character to break on */

{	int anyReal;
	int sI,cc;

	anyReal = FALSE; /* no real chars yet */
	do {
		if (!GetSourceChars(tempS,nc,breakC))
			return(FALSE); /* failed */
		for (sI=0; sI<nc; sI++) {
			cc = tempS[sI];
			if ((cc == ' ') || (cc == '\t') || (cc == 0x0d) || (cc == 0x0a)) {
				; /* not a real character */
			} else if (cc == 0) {
				break; /* exit for */
			} else {
				anyReal = TRUE; /* found a real character */
				break; /* exit for */
			}
		} /* for */	
	} while (!anyReal);
	return(TRUE);

} /* GetSourceCharsReal */

static GetSourceChars(tempS,nc,breakC)	/* get the next couple of characters */
register char *tempS;   /* to be filled with the next nc characters */
register int nc;    /* # of chars wanted */
int breakC; /* character to break on (stop before getting nc chars) */
/* returns TRUE on success */
    {
    register int nRead;     /* # of chars we have read */
    int retVal;             /* the success flag to be returned */
    register unsigned char cc;  /* next character */

    if ((crKind == 2) && (breakC == 0x0d))
	breakC = 0x0a; /* stop on 2nd half of newline */

    for (nRead=0; nRead<nc; nRead++)
        {
        if (sourceLeft <= 0)
            { /* we've run out of source characters, get some more */
            if (sourcep)
            	ReleasePtr(sourceH);
            sourcep = FARNULL;
            TUTORfree_handle(sourceH);
            sourceH = HNULL;
            retVal = ReadText(FALSE);
            if (!retVal)
                return(FALSE);
            }
	    cc = *sourcep++;
            *tempS++ = cc;
            sourceLeft--;
	    if (cc == breakC)
		break;
	}
    *tempS = 0;
    
    return(TRUE);
    }

/* ************************************************************************* */

long ReadRawText(buffP,len)
unsigned char FAR *buffP;
long len;
       
{	long filePos; /* current position in file */
	long nRead;
	   
    /* move file read position back to begin of raw text */
    
    if (sourceLeft) {
    	filePos = TUTORinq_file_pos(sourceFile);
    	TUTORseek(sourceFile,filePos-sourceLeft);
    	sourceLeft = 0; /* nothing left in memory */
    	isMore = TRUE;
    }
    nRead = TUTORread((char FAR *)buffP,1,len,sourceFile);
    return(nRead);
    
} /* ReadRawText */

/* ************************************************************************* */


static ReadText(exact)  /* read raw characters out of file */
int exact; /* if FALSE, read a bit extra, to account for possible styles */
/* returns TRUE if anything was read */
    {
    register long len;  /* number of characters we want to read from file */
    long nRead; /* # of characters we actually read */
    int badC,goodC; /* character values for newline conversion */
    int sI; /* index in string */
    struct tutorfile FAR *tfp; /* pointer to file table entry */

    if (readLeft > READSIZE)
        len = READSIZE;
    else
        len = readLeft;
    
    if (!exact)
        {
        len += 20 + len/10; /* a little extra for styles and such */
        if (len < 1000)
            len = 1000;
        }
    
    if (sourceH)
	TUTORdump("txt3 2");

    sourceH = TUTORhandle("readtxt",len,FALSE);
    if (!sourceH)
        return(FALSE);
	TUTORpurge_info(sourceH,M_WMRM,FARNULL,0);
    AllowHandlePurge(sourceH);    
    source0 = (unsigned char FAR *) GetPtr(sourceH);
    nRead = TUTORread((char FAR *) source0,1,len,sourceFile);
    isMore = (nRead == len);

    if (!nRead) { /* nothing read */
        ReleasePtr(sourceH);
        KillPtr(source0);
        TUTORfree_handle(sourceH);
        sourceH = HNULL;
        sourcep = source0 = FARNULL;
        sourceLeft = 0L;
        isMore = FALSE;
        return(FALSE);
    }
    sourceLeft = nRead;
    
	/* check if need to determine crKind */

    tfp = ((struct tutorfile FAR *) GetPtr(filesopen))+sourceFile;
	if (tfp->crKind >= 0) {
		crKind = tfp->crKind; /* type of newline already known */
	} else {
		sourcep = source0;
		crKind = -1;
    	for(sI=0; sI<nRead-1; sI++) {
			if ((*sourcep == 0x0d) && (*(sourcep+1) == 0x0a)) {
	    		crKind = 2;
	    		break;
			} else if (*sourcep == 0x0d) {
	    		crKind = 1;
	    		break;
			} else if (*sourcep == 0x0a) {
	    		crKind = 0;
	    		break;
			}
			sourcep++;
    	} /* for */
		if (crKind >= 0) {
			tfp->crKind = crKind;
		} else {
#ifdef MAC
			crKind = 1; /* default for Mac */
#else
			crKind = 0; /* default for PC, Unix */
#endif
		}
	} 
    ReleasePtr(filesopen);

    sourcep = source0;

    /* handle simple newline conversion */

    SimpleCRfix();

    return(TRUE);
    }

/* ************************************************************************* */

static int DetermineKind() /* determine document type, set crKind */
/* returns document kind -  0: native, 1: cT, 2: be2 */

{   int kind;  /* the kind to be returned */
    int sii;
    char FAR *cp;
    char tempS[152];    /* to be filled with a line of text */

    crKind = -1; /* set harmlessly, reset by ReadText */
    sii = ReadText(TRUE);
    if (!sii)
		return(0); /* nothing to read, we're done */

    /* check if document has datastream header */

    if (*sourcep != '\\' && *sourcep != '@') {
        kind = 0; /* native */
    } else {
		GetSourceChars(tempS,151,NEWLINE); /* read full line */
		if (!strncmp(tempS,"\\begindata{text",15)) {
            kind = 2; /* be2 datastream */
		} else if (!strncmp(tempS,"@cT datastream ",15)) {
            kind = 1;
		} else {
            kind = 0;
	    /* reset text to beginning of source */
	    /* (assummes that GetSourceChars didn't do a ReadText) */
            sourceLeft += (sourcep - source0);
            sourcep = source0;
		} /* strncmp else */
    } /* sourcep else */

    return(kind);

} /* DetermineKind */

/* ************************************************************************* */

static int SimpleCRfix() /* handle 0x0d <-> 0x0a conversion */

{   int badC,goodC;
    int sI;

    /* handle simple newline conversion */

    sourcep = source0; /* start at begin of source block */
    badC = 0;
    if ((crKind == 0) && (NEWLINE == 0x0d)) {
	badC = 0x0a;
	goodC = 0x0d;
    } else if ((crKind == 1) && (NEWLINE == 0x0a)) {
	badC = 0x0d;
	goodC = 0x0a;
    }
    if (badC) {
	for(sI=0; sI<sourceLeft; sI++) {
	    if (*sourcep == badC)
		*sourcep = goodC;
	    sourcep++;
	} /* sI for */
	sourcep = source0;
    } /* badC if */
    return(0);

} /* SimpleCRfix */

/* ************************************************************************* */

static ReadStyle(styles,pos,lastStyles, lastS)  /* read an @1 style */
Memh *styles;   /* style structure we are adding to */
long pos;   /* position style is being added to */
short *lastStyles;  /* last style read of each type.  We don't add redundant styles */
Style1 *lastS;  /* the last style that was added */
/* returns TRUE if style was a new hot text, false otherwise */
    {
    char tempS[6];  /* for reading the next couple of characters */
    Style1 newStyle;    /* the style we are reading in */
    int wasHot;     /* TRUE if the style was a hot style */
    int paraDat;    /* the paragraph layout style (translated) portion of a PARASTYLE */
    REGISTER StyleDatP sp;  /* pointer at style structure *styles */
    int newInd;         /* index of the new style block */
    int styledattmp;    /* int for doing sscanf machine independently (short doesn't work) */
    
    /* determine what kind of style this is */
    GetSourceChars(tempS,2,0);
    
    wasHot = FALSE;
    if (!strcmp(tempS,"fg"))
        newStyle.type = FONTSTYLE;
    else if (!strcmp(tempS,"fs"))
        newStyle.type = SIZESTYLE;
    else if (!strcmp(tempS,"ff"))
        newStyle.type = FACESTYLE;
    else if (!strcmp(tempS,"pl"))
        newStyle.type = PARASTYLE;
    else if (!strcmp(tempS,"cl"))
        newStyle.type = COLORSTYLE;
    else if (!strcmp(tempS,"ht"))
        {
        newStyle.type = HOTSTYLE;
        wasHot = TRUE;
        }
    else
        newStyle.type = -1; /* unknown style - ignored (though we read it) */
    
    /* read new data */
    GetSourceChars(tempS,4,0);
    
    if (newStyle.type == -1)
        return(FALSE); /* unknown style, we don't process */

    sscanf(tempS,"%x",&styledattmp); /* read into int for machine independence */
    newStyle.dat = styledattmp;

    /* translate, if necessary */
    if (newStyle.type == FONTSTYLE && newStyle.dat != DEFSTYLE)
        newStyle.dat = TranslateStyle(newStyle.dat,familyTable,nFamiliesL,ourFamilies);
    else if (newStyle.type == PARASTYLE && newStyle.dat != DEFSTYLE)
        {
        paraDat = newStyle.dat & PARALMASK;
        if (paraDat != PARADEFAULT)
            {
            paraDat = TranslateStyle(paraDat,paraTable,nPara,ourPara);
            paraDat <<= 3;
            }
        newStyle.dat = (newStyle.dat & ~PARALMASK) | paraDat;
        }
    else if (newStyle.type == HOTSTYLE && newStyle.dat == 0)
        return(FALSE); /* some mistake */

    /* eliminate redundant styles */
    if (newStyle.dat == lastStyles[newStyle.type])
        return(FALSE); /* redundant */
    else
        lastStyles[newStyle.type] = newStyle.dat;
    
    newStyle.pos = pos;
    
    /* add the style */
    if (!*styles)
        *styles = NewTStyle();  
    if (newStyle.pos != 0L)
        { /* insert new style */
        if (newStyle.pos != lastS->pos || newStyle.type > lastS->type)
            { /* normal case, the order is right */
            TUTORinsert_darray(*styles,FARNULL,STYLEOFFSET,0,-1,1);
            sp = (StyleDatP) GetPtr(*styles);
            newInd = sp->sHead.dAnn - 1; /* index of new style */
            sp->styles[newInd] = newStyle;
            sp->nStyles[newStyle.type]++;
            ReleasePtr(*styles);
            KillPtr(sp);
            }
        else
            { /* somehow the style type ordering is wrong */
                /* let addstyle take care of it */
            /* we add a style that goes "to doc end" so that no termination
                style block is left around */
            AddTStyle(*styles, pos, 100L, pos+99L, newStyle.type, newStyle.dat, 0);
            }
        }
    else
        { /* just change style at beginning */
        sp = (StyleDatP) GetPtr(*styles);
        sp->styles[newStyle.type].dat = newStyle.dat;
        ReleasePtr(*styles);
        KillPtr(sp);
        }

    lastS->pos = newStyle.pos;
    lastS->type = newStyle.type;
    
    return(wasHot);
    }

static ReadHotText(styles)  /* read the hot info strings for the document */
Memh styles;    /* the style structure */
    {
    StyleDatP pp;   /* pointer to style structure styles */
    char tempS[152]; /* buffer for reading a line of characters */
    unsigned char *tDest;
    int nItems;     /* # of pieces of hot text */
    int curPos;     /* current position in info string pool */
    int infoL;      /* length of next info string */
    int curid;      /* id for next hot text block */
    int ii;
    HotList FAR *hlp;   /* pointer to hot list (pp->hotList) */
    HotL1 FAR *hp;      /* pointer to current hot text block */
    Memh tempDoc;   /* we read info strings into this temporary document */
    long infoPoolLen;   /* total length of info string pool */
    unsigned char FAR *tp;  /* pointer to info string dynamic array */
    DArrayHeader FAR *textheadp;    /* pointer to darrayheader for text in hotlist */

    /* variables for saving & restoring read state,
        allowing recursive call to ReadDatastream */
    short FAR *sfamilyTable, FAR *sourFam, FAR *sparaTable, FAR *sourPara;
    short snFam, snPara;
    long sreadLeft;
	
    /* styles should exist by now because we've already read the hot styles */
    
    if (!styles)
        { /* there must not have been any hot styles, just skip HOT text */
        FinishReadSpecial("HOTT");
        return(0);
        }

    pp = (StyleDatP) GetPtr(styles);

#ifdef DOCVERIFY
if (pp->hotList)
   TUTORdump("txt3 3");
#endif

    pp->hotList = NewHotList();
    
    /* read the number of entries */
    GetSourceCharsReal(tempS,151,NEWLINE);
    sscanf(tempS,"%d",&nItems);
    /* expand array for this info: */
    TUTORinsert_darray(pp->hotList,FARNULL,HOTOFFSET,0,0,nItems);
    
    /* for every entry read the length (and infer position and id) */
    hlp = (HotList FAR *) GetPtr(pp->hotList);
    hp = (HotL1 FAR *) hlp->list;
    curPos = 0;
    infoPoolLen = 0;
    curid = 1;
    for (ii=0; ii<nItems; ii++, hp++)
        {
	GetSourceCharsReal(tempS,151,NEWLINE);
        sscanf(tempS,"%d",&infoL);
        hp->pos = curPos;
        hp->len = infoL;
        curPos += infoL;
        hp->id = curid++;
        infoPoolLen += infoL;
        }
    hlp->nextid = curid;  /* the next available id */
    ReleasePtr(pp->hotList);
    KillPtr(hlp);
    
    /* read the text */
    /* make recursive call to ReadDatastream */
    
    /* save variables for recursion */
    sfamilyTable = familyTable;
    snFam = nFamiliesL;

    sourFam = ourFamilies;
    sparaTable = paraTable;
    snPara = nPara;
    sourPara = ourPara;
    sreadLeft = readLeft;
    
    /* set tables to NULL so they don't get deallocated */
    paraTable = FARNULL;
    familyTable = FARNULL;
    
    /* read the datastream into a temporary document */
    tempDoc = TUTORnew_doc(TRUE,FALSE);
    ReadDatastream(tempDoc,-1L);
    
    /* transfer the text (only!) from the temporary document to the hotList */
#ifdef DOCVERIFY
    if (TUTORget_len_doc(tempDoc) != infoPoolLen)
	TUTORdump("txt3 4");
#endif
    if (infoPoolLen > 0x7fff)
        infoPoolLen = 0x7fff; /* clip! */
    
    /* expand the text array in the hot text handle */
    TUTORinsert_darray(pp->hotList,FARNULL,HOTOFFSET,1,-1,(int) infoPoolLen+1);
    /* note that we expand by infoPoolLen+1 to leave space for null terminator
        that comes from TUTORget_string_doc */
    
    /* now directly transfer text to the hot text handle */
    hlp = (HotList FAR *) GetPtr(pp->hotList);
    textheadp = (DArrayHeader FAR *) ((char FAR *) hlp + hlp->offsets[1]);
    tp = (unsigned char FAR *) ((char FAR *) textheadp+sizeof(DArrayHeader));
    TUTORget_string_doc(tempDoc,0L,infoPoolLen,tp);
    ReleasePtr(pp->hotList);
    KillPtr(hlp);
    TUTORclose_doc(tempDoc);
    
    /* TUTORget_string_doc put in a null terminator that we don't want,
        delete it. */
    TUTORdelete_darray(pp->hotList,FARNULL,HOTOFFSET,1,infoPoolLen,1);
    
    /* restore read variables */
    familyTable = sfamilyTable;
    nFamiliesL = snFam;

    ourFamilies = sourFam;
    paraTable = sparaTable;
    nPara = snPara;
    ourPara = sourPara;
    readLeft = sreadLeft;
    
    ReleasePtr(styles);
    KillPtr(pp);
    
    FinishReadSpecial("HOTT");
    
    return(0);
    }

FinishReadSpecial(name) /* skip over possible junk at end of @4 special */
char *name; /* name of special (should be 4 chars) */
    {
    int depth;  /* how deep we are in nested @4name styles */
    char tempS[152];    /* buffer for reading lines */
    
    /* special styles are bracketed by lines of the form
        @4NAME
        @5NAME
        The @4 has already been read, we will skip lines until we have
        read the @5.  To handle nesting of styles we will keep a depth
        count so that we match @4s with @5
    */

    depth = 1;
    while (depth > 0)
        {
	if (!GetSourceCharsReal(tempS,151,NEWLINE))
            break; /* ran out of source */
        if (tempS[0] == '@')
            {
            if (tempS[1] == '4' && strncmp(tempS+2,name,4) == 0)
                depth++; /* start of another one of unknown styles */
            else if (tempS[1] == '5' && strncmp(tempS+2,name,4) == 0)
                depth--; /* end of one of the unknown styles */
            }
        }
    }

static TranslateStyle(readStyle,sTable,nTable,ourTable)
register int readStyle; /* style read from disk */
register short FAR *sTable; /* table of style values read in */
register int nTable;    /* # of entries available for translation */
short FAR *ourTable;    /* our translated values */
    {
    register int ii;
    
    /* search for the readStyle in table */
    for (ii=0; ii<nTable; ii++)
        if (*sTable++ == readStyle)
            break;
    
    if (ii >= nTable)
        return(0); /* couldn't translate - use some default */
    
    return(*(ourTable+ii));
    }

static ReadFontTable()
/* returns success flag */
    {
    char tempS[152];    /* buffer for reading lines */
    int ii,ln;
    int nEntries;   /* # of entries in font table */
    int readN;  /* the family number read in */
    int ourN;   /* the corresponding family number that we use */
    FileRef fRef;   /* a symbolic file ref for figuring out font family number */
    
    if (nFamiliesL)
	TUTORdump("txt3 5");
    
    /* read # of entries */
    if (!GetSourceCharsReal(tempS,151,NEWLINE)) /* read a line */
        return(FALSE);
    sscanf(tempS,"%d",&nEntries);
    
    familyTable = (short FAR *) TUTORalloc((long) (nEntries*sizeof(short)),TRUE,"famtable");
    ourFamilies = (short FAR *) TUTORalloc((long) (nEntries*sizeof(short)),TRUE,"famtable");

    for (ii=0; ii<nEntries; ii++)
        {
	if (!GetSourceCharsReal(tempS,151,NEWLINE))
            return(FALSE);
	sscanf(tempS,"%3x",&readN);
	ln = strlen(tempS)-1;
	while (ln && ((tempS[ln] == 0x0d) || (tempS[ln] == 0x0a))) {
	    tempS[ln] = 0; /* get rid of NEWLINE */
	    ln--;
	}
        
        /* we only support symbolic font names... */
        TUTORsymbolic_fileref((FileRef FAR *) &fRef, (char FAR *) tempS+4);
        ourN = (int)TUTORinq_ffamily_id(&fRef,TRUE);
        if (ourN < 0)
            { /* need to add this font */
            ourN = (short)TUTORadd_ffamily(&fRef,TRUE,FALSE);
            }
        familyTable[nFamiliesL] = readN;
        ourFamilies[nFamiliesL++] = ourN;
        }
    
    FinishReadSpecial("FONT"); /* skip thru @5FONT */
    
    return(TRUE);
    }

static ReadParaTable()
/* returns success flag */
    {
    char tempS[152];    /* buffer for reading line of raw characters */
    register int ii;
    int nEntries;   /* # of entries in paragraph translation tables */
    int readStyle;  /* paragraph layout style number read in */
    int ourStyle;   /* our paragraph layout style number corresponding to the same layout */
    ParagraphLayout pLay;   /* the paragraph layout data */
    int i1, i2, i3, i4, i5; /* for doing sscanf */

    if (nPara)
	TUTORdump("txt3 6");
    
    /* read # of entries */
    if (!GetSourceChars(tempS,151,NEWLINE)) /* read a line */
        return(FALSE);
    sscanf(tempS,"%d",&nEntries);
    
    ourPara = (short FAR *) TUTORalloc((long) (nEntries*sizeof(short)),TRUE,"paratabl");
    paraTable = (short FAR *) TUTORalloc((long) (nEntries*sizeof(short)),TRUE,"paratabl");
    
    for (ii=0; ii<nEntries; ii++)
        {
	if (!GetSourceChars(tempS,151,NEWLINE))
            return(FALSE);
        /* read into integers for machine independence */
        sscanf(tempS,"%x %d %d %d %d %d",&readStyle,&i1, &i2, &i3, &i4, &i5);
        pLay.tabSize = i1;
        pLay.leftMar = i2;
        pLay.rightMar = i3;
        pLay.paraIndent = i4;
        pLay.extraLine = i5;
        ourStyle = AddParaLayout(&pLay);
        paraTable[nPara] = readStyle;
        ourPara[nPara++] = ourStyle;
        }
    
    FinishReadSpecial("PARA"); /* skip thru @5PARA */
    
    return(TRUE);
    }

/* ******************************************************************* */

static ReadSpecialChar(doc,pos) /* read in special character */
Memh doc;   /* document we are reading in for */
long pos;   /* position in document */
/* returns char value of special char */
    
{   char tempS[81];     /* buffer for reading in a line of characters */
    int retC;           /* the returned character value */
    
    /* read header */
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
	return('?');
    sscanf(tempS,"%d",&retC);
    
    if (retC == BITMAPSPECIAL)
        retC = ReadBitmap(doc,pos);
    else if (retC == PIXMAPSPECIAL)
        retC = ReadPixmap(doc,pos);
    else if (retC == ICONSPECIAL)
        retC = ReadIcons(doc,pos);
    else
	TUTORdump("txt3 7");
    return(retC);
    
} /* ReadSpecialChar */
    
/* ******************************************************************* */

static ReadBitmap(doc,pos)  /* read in bitmap special character */
Memh doc;   /* document we are reading in for */
long pos;   /* position in document */
/* returns char value of special char */
    {
    char tempS[81];     /* buffer for reading in a line of characters */
    int retC;           /* the returned character value */
    long cSize;         /* the size, in bytes of storage needed for character bitmap */
    long tempL;
    Memh cph;           /* handle in which we store special character  */
#ifdef LINUX
    struct pcfont816 FAR *fontp; /* pointer to font info in cph */
#else
    struct pcfont FAR *fontp;  /* pointer to font info in cph */
#endif
    register struct pccharl FAR *cp;    /* pointer to character info in cph */
    char FAR *cc;       /* pointer to raster portion of cph */
    unsigned char FAR *rastP;   /* pointer to raster portion of cph */
    DocP dp;            /* pointer to doc */
    register int ii,nc;
    int nWords;         /* total number of words in raster */
    int tempI, nBytes;
    int i1,i2,i3,i4;    /* for sscanf */
    int padByte;    /* TRUE if there is a pad byte per row */
    int irow, icol; /* indices within raster */
    int nRead; /* # of bytes we've read from current buffer */
    int rowBytes;   /* # of bytes per row of image */
    int version;    /* bitmap character datastream version */
    
    retC = BITMAPSPECIAL;
    /* read version (could be size) */
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%ld",&tempL);
    if (tempL < 0)
        { /* this is really version */
        version = tempL;
        /* read data size */
	if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
            return('?');
        sscanf(tempS,"%ld",&cSize);
        /* cSize is size of raster for rows padded out to words */
        }
    else
        { /* no version was specified, it is -1, the original */
        cSize = tempL;
        version = -1;
        }
    
    if (version != BITMAPVERS1)
	TUTORdump("txt3 8");
    
    /* allocate character */
#ifdef LINUX
    tempL = sizeof(struct pcfont816) + sizeof(struct pccharl) + cSize;
#else
    tempL = sizeof(struct pcfont) + sizeof(struct pccharl) + cSize;
#endif
    cph = TUTORhandle("spcltext",tempL,FALSE);
    TUTORpurge_info(cph,M_WORM,FARNULL,0);
    AllowHandlePurge(cph);
    
    /* fill out font fields */
#ifdef LINUX
    fontp = (struct pcfont816 FAR *) GetPtr(cph);
#else
    fontp = (struct pcfont FAR *) GetPtr(cph);
#endif
    TUTORzero((char SHUGE *) fontp,tempL);
    fontp->nchars8 = 1;
    fontp->first8 = 0;
    fontp->format = 1;
#ifdef LINUX
    fontp->ddef = sizeof(struct pcfont816);
    fontp->dmap = sizeof(struct pcfont816) + sizeof(struct pccharl);
    cp = (struct pccharl FAR *) ((char FAR *) fontp + sizeof(struct pcfont816));
#else
    fontp->ddef = sizeof(struct pcfont);
    fontp->dmap = sizeof(struct pcfont) + sizeof(struct pccharl);
    cp = (struct pccharl FAR *) ((char FAR *) fontp + sizeof(struct pcfont));
#endif
    cp->map = 0; /* offset to bitmap for this char */
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%d %d %d %d",&i1, &i2, &i3, &i4);
    cp->pdx = i1;
    cp->pdy = i2;
    cp->bndx = i3;
    cp->bndy = i4;
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%d %d %d %d",&i1, &i2, &i3, &i4);
    cp->bnw = i1;
    cp->bnh = i2;
    cp->mapdx = i3;
    cp->mapdy = i4;
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%d %d",&i1, &i2);
    cp->mapw = i1;
    cp->maph = i2;
    
    /* read raster */
    cc = (char FAR *)cp;
    cc += sizeof(struct pccharl);
    rastP = (unsigned char FAR *)cc; /* points at bitmap */
    nWords = ((cp->mapw - 1)/16 + 1)*cp->maph;
    
    /* there are an even number of bytes per row in the file */
#ifndef MAC
    if ((cp->mapw - 1) % 16 > 7)
        padByte = FALSE; /* rows have an even number of bytes */
    else
        padByte = TRUE; /* rows in bitmap have an odd number of bytes, we need skip pads */
#else
    padByte = FALSE; /* Mac has even number bytes/row */
#endif

    if (cSize < nWords * sizeof(short))
	TUTORdump("txt3 9");
    
    rowBytes = ((cp->mapw - 1) / 16 + 1)*2; 
    if (padByte)
        rowBytes--; /* because memory image isn't padded out to word boundary */

    nRead=32; /* to trigger reading of file */
    for (irow=0; irow < cp->maph; irow++)
        {
        for (icol=0; icol < rowBytes; icol++)
            {
            if (nRead >= 32)
                { /* we need to read more characters */
		if (!GetSourceChars(tempS,80,NEWLINE))
                    { /* couldn't read anymore from file! */
                    ReleasePtr(cph);
                    KillPtr(fontp);
                    TUTORfree_handle(cph);
                    return('?');
                    }
                nRead = 0;
                }
            sscanf(tempS+2*nRead,"%2x",&tempI);
            *rastP++ = tempI;
            nRead++;
            }
        if (padByte)
            nRead++; /* skip the pad byte */
        }

#ifdef LINUX
    /* swap bits so that our graphics server will understand */
    TUTORswap_bits_char((unsigned char FAR *) cc,cSize);
#endif

#ifdef ANDREW
    /* swap bits so that our graphics server will understand */
    if (isx11)
        TUTORswap_bits_char((unsigned char FAR *) cc,cSize);
#endif

    /* calculate correct size of handle */
    tempL = (long) rowBytes * cp->maph;
#ifdef LINUX
    tempL += sizeof(struct pcfont816) + sizeof(struct pccharl);
#else
    tempL += sizeof(struct pcfont) + sizeof(struct pccharl);    
#endif
    ReleasePtr(cph);
    KillPtr(fontp);
    
    /* resize handle to proper size */
    TUTORset_hsize(cph,tempL,TRUE);
    
    FinishReadSpecial("STXT");
    
    /* put special text in doc */
    dp = (DocP) GetPtr(doc);
    if (!dp->specialT)
        {
        dp->specialT = TUTORnew_stext();
        }
    TUTORadd_stext(dp->specialT,pos,retC,cph);
    ReleasePtr(doc);
    KillPtr(dp);
    
    return(retC);
    }

/* ******************************************************************* */

#ifdef MAC

static ReadPixmap(doc,pos)  /* read in pixmap special character */
Memh doc;   /* document we are reading in for */
long pos;   /* position in document */
/* returns char value of special char */
    
{   Memh regionH; /* handle on pixmap */
    struct saved_region FAR *regionP; /* pointer to region header */
    DocP dp; /* pointer to doc */
    int version; /* datastream version */
    long width,height; /* picture size */
    int pixelsLine; /* number pixels/line */
    int rr,gg,bb; /* red, green, blue components */
    long sizeH; /* size of cT handle */
    long rowBytes; /* bytes per row in pixmap */
    long rowI; /* index in rows */
    long pixelI; /* index in pixels */
    Memh rgbpixelH; /* handle on rgb pixel data */
    Memh palpixelH; /* handle on palettized pixel data */
    Memh palH; /* handle on palette data */
    struct CTcolorentry FAR *palP; /* pointer in palette */
    int pii,pjj; /* index in palette */
    unsigned char FAR *pixP; /* pointer to pixels */
    unsigned char FAR *pixelsP; /* pointer to pixels */
    int nColors; /* number colors in native palette */
    long *lP; 
    long tempL;
    int nInLine; /* number pixels left in current line */
    char *inP; /* pointer in input line */
    char tempS[81]; /* buffer for reading in a line of characters */
    double redD,greenD,blueD;
    double hue,saturation,value;
      
    /* read version  */
    
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%ld",&tempL);
    version = tempL;
    if ((version != PIXMAPVERS1) && (version != PIXMAPVERS2))
        return('?');
    
    /* get pixmap description */
    
    nColors = palH = palpixelH = 0;
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%ld",&width);
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%ld",&height);
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%d",&pixelsLine);
    if ((version == PIXMAPVERS1) && (pixelsLine != 8))
        return('?');
    else if (version == PIXMAPVERS2)
    	nColors = pixelsLine; /* number colors stored with picture */

    /* set up cT handle for rgb pixels */
    
    rowBytes = width*3; /* 3 bytes/pixel */
    sizeH = rowBytes*height;
    rgbpixelH = TUTORhandle("rgbpix",sizeH,TRUE);
    if (!rgbpixelH) {
    	TxtMemErr++;
        return('?'); /* couldn't get enough memory */
    }
    TUTORpurge_info(rgbpixelH,M_WORM,FARNULL,0);
    AllowHandlePurge(rgbpixelH);
    
    /* set up cT handle for palettized pixels */
    
    if (nColors) {
    	tempL = width*height;
    	palpixelH = TUTORhandle("palpix",tempL,TRUE);
    	if (palpixelH) {
	    TUTORpurge_info(palpixelH,M_WORM,FARNULL,0);
	    AllowHandlePurge(palpixelH);
	} else {
	    TxtMemErr++;
	    nColors = 0;
	}
    }
	
    /* read colors and palettized pixels */
    
    if (nColors) {
			
    	/* allocate palette */
    	
	palH = TUTORalloc_palette(256);
	if (!palH) {
	    TUTORfree_handle(rgbpixelH);
	    if (palpixelH)
		TUTORfree_handle(palpixelH);
	    TxtMemErr++;
	    return('?');
	}
		
	palP = (struct CTcolorentry FAR *)GetPtr(palH);

	/* read colors to palette */

	for(pii=0; pii<nColors; pii++) {
	    tempL = ReadRawText((unsigned char FAR *)tempS,7L);
	    if (tempL != 7)
		TxtMemErr++; /* something bad happened */
	    rr = ((tempS[1] << 8) & 0xff00) | (tempS[2] & 0xff);
	    gg = ((tempS[3] << 8) & 0xff00) | (tempS[4] & 0xff);
	    bb = ((tempS[5] << 8) & 0xff00) | (tempS[6] & 0xff);
	    pjj = tempS[0] & 0xff; /* index in palette */
	    (palP+pjj)->red = rr;
	    (palP+pjj)->green = gg;
	    (palP+pjj)->blue = bb;
	    redD = (((double) (palP+pjj)->red)/(double) 0xffff) * 100.0;
    	greenD = (((double) (palP+pjj)->green)/(double) 0xffff) * 100.0;
    	blueD = (((double) (palP+pjj)->blue)/(double) 0xffff) * 100.0;
    	TUTORrgb_to_hsv(redD,greenD,blueD,&hue,&saturation,&value);
    	(palP+pjj)->cHue = hue*4.0;
    	(palP+pjj)->cSaturation = saturation*4.0;
    	(palP+pjj)->cValue = value*4.0;
	    (palP+pjj)->isSet = TRUE;
	    (palP+pjj)->realV = pjj;
	}
	ReleasePtr(palH);
		
	/* read palettized pixels */
		    
	pixP = (unsigned char FAR *)GetPtr(palpixelH);
	tempL = ReadRawText(pixP,width*height);
	if (tempL != (width*height))
	    TxtMemErr++;
	ReleasePtr(palpixelH);
    }
	
    /* read pixels to cT handle */
        
    pixP = (unsigned char FAR *)GetPtr(rgbpixelH); /* pointer to cT handle */
    TUTORzero((char FAR *)pixP,sizeH);
    pixelsP = ((unsigned char FAR *)(pixP));

    if (version == PIXMAPVERS1) {
    	nInLine = 0; /* no pixels left in current line */
    	for(rowI=0; rowI<height; rowI++) {
	    for(pixelI=0; pixelI<width; pixelI++) {
		if (!nInLine) {
		    if (!GetSourceChars(tempS,80,NEWLINE)) {
                    	/* couldn't read anymore from file! */
                    	ReleasePtr(rgbpixelH);
			TUTORfree_handle(rgbpixelH);
			if (palpixelH)
			    TUTORfree_handle(palpixelH);
			return('?');
		    }
		    inP = tempS; /* read from begin of line */
		    nInLine = pixelsLine;
            	} /* nInLine if */
            	rr = (((*inP++)-'A') << 4)+((*inP++)-'A');
            	gg = (((*inP++)-'A') << 4)+((*inP++)-'A');
            	bb = (((*inP++)-'A') << 4)+((*inP++)-'A');
            	nInLine--;
            	*pixelsP++ = rr;
            	*pixelsP++ = gg;
            	*pixelsP++ = bb;
	    } /* pixelI for */
    	} /* rowI for */
    } else { /* PIXMAPVERS2 */
    	tempL = ReadRawText(pixelsP,sizeH);
    	if (tempL != sizeH) {
	    TxtMemErr++; /* flag some sort of error happened */
	    ReleasePtr(rgbpixelH);
	    TUTORfree_handle(rgbpixelH);
	    if (palpixelH)
		TUTORfree_handle(palpixelH);
            return('?');
    	}
    }
    
    /* convert pixel r,g,b data in memory to pixmap */
    
    regionH = TUTORmem_to_region(2,width,height,HNULL,pixP);
    ReleasePtr(rgbpixelH);
    
    if (!regionH) {
       	TxtMemErr++;
	TUTORfree_palette(palH);
	if (palpixelH)
	    TUTORfree_handle(palpixelH);
	TUTORfree_handle(rgbpixelH);
	return('?');
    }
    
    /* attach palette */
    
    if (regionH) {
    	regionP = (struct saved_region FAR *)GetPtr(regionH);
    	regionP->nativePal = palH; /* attach palette */
    	regionP->palDataH = palpixelH;
    	regionP->rgbDataH = rgbpixelH;
    	ReleasePtr(regionH);
    }
    
    FinishReadSpecial("STXT");
    
    /* put special text in doc */
    
    dp = (DocP) GetPtr(doc);
    if (!dp->specialT) {
        dp->specialT = TUTORnew_stext();
    }
    TUTORadd_stext(dp->specialT,pos,PIXMAPSPECIAL,regionH);
    ReleasePtr(doc);
    
    return(PIXMAPSPECIAL);

} /* ReadPixmap */
    
#endif /* MAC */

/* ******************************************************************* */

#ifdef WINPC

static ReadPixmap(doc,pos)  /* read in pixmap special character */
Memh doc;   /* document we are reading in for */
long pos;   /* position in document */
/* returns char value of special char */
    
{   Memh regionH; /* handle on region */
    struct saved_region FAR *regionP; /* pointer to region header */
    DocP dp; /* pointer to doc */
    int version; /* datastream version */
    long width,height; /* picture size */
    int pixelsLine; /* number pixels/line */
    int rr,gg,bb; /* red, green, blue components */
    long sizeH; /* size of cT handle */
    long rowBytes; /* bytes per row in pixmap */
    long rowI; /* index in rows */
    long pixelI; /* index in pixels */
    Memh palH; /* handle on palette data */
    struct CTcolorentry FAR *palP; /* pointer to palette data */
    int nColors; /* number colors stored with image */
    unsigned char SHUGE *pixP; /* pointer to pixels */
    unsigned char SHUGE *pixelsP; /* pointer to pixels */
    Memh rgbpixelH; /* handle on rgb pixel data */
    Memh palpixelH; /* handle on palettized pixel data */
    int pii,pjj;
    long *lP; 
    long tempL;
    int nInLine; /* number pixels left in current line */
    char *inP; /* pointer in input line */
    char tempS[81]; /* buffer for reading in a line of characters */
    double redD,greenD,blueD;
    double hue,saturation,value;
    
    palH = palpixelH = HNULL; /* no palette yet */
    nColors = 0;

    /* read version  */
    
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%ld",&tempL);
    version = tempL;
    if ((version != PIXMAPVERS1) && (version != PIXMAPVERS2))
        return('?');
    
    /* get size of pixmap */
    
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%ld",&width);
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%ld",&height);
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%d",&pixelsLine);
    if ((version == PIXMAPVERS1) && (pixelsLine != 8))
	return('?');
    if (version == PIXMAPVERS2)
	nColors = pixelsLine;

    /* set up cT handle for pixels */
    
    rowBytes = width*3; /* 3 bytes/pixel */
    sizeH = rowBytes*height;
    rgbpixelH = TUTORhandle("pixmap",sizeH,TRUE);
    if (!rgbpixelH) {
    	TxtMemErr++;
        return('?'); /* couldn't get enough memory */
    }
    TUTORpurge_info(rgbpixelH,M_WORM,FARNULL,0);
    AllowHandlePurge(rgbpixelH);

    /* set up cT handle for palettized pixels */
    
    if (nColors) {
    	tempL = width*height;
    	palpixelH = TUTORhandle("palpix",tempL,TRUE);
    	if (palpixelH) {
	    TUTORpurge_info(palpixelH,M_WORM,FARNULL,0);
	    AllowHandlePurge(palpixelH);
	} else {
	    TxtMemErr++;
	    nColors = 0;
	}
    }
	
    /* read colors and palettized pixels */
    
    if (nColors) {
			
    	/* allocate palette */
    	
	palH = initial_palette();
	if (!palH) {
	    TUTORfree_handle(rgbpixelH);
	    TUTORfree_handle(palpixelH);
	    TxtMemErr++;
	    return('?');
	}

	/* read colors to palette */

	palP = (struct CTcolorentry FAR *)GetPtr(palH);
	for(pii=0; pii<nColors; pii++) {
	    tempL = ReadRawText((unsigned char FAR *)tempS,7L);
	    if (tempL != 7)
		TxtMemErr++; /* something bad happened */
	    rr = ((tempS[1] << 8) & 0xff00) | (tempS[2] & 0xff);
	    gg = ((tempS[3] << 8) & 0xff00) | (tempS[4] & 0xff);
	    bb = ((tempS[5] << 8) & 0xff00) | (tempS[6] & 0xff);
	    pjj = tempS[0] & 0xff; /* index in palette */
	    (palP+pjj)->red = rr;
	    (palP+pjj)->green = gg;
	    (palP+pjj)->blue = bb;
	    redD = (((double) (palP+pjj)->red)/(double) 0xffff) * 100.0;
    	greenD = (((double) (palP+pjj)->green)/(double) 0xffff) * 100.0;
    	blueD = (((double) (palP+pjj)->blue)/(double) 0xffff) * 100.0;
    	TUTORrgb_to_hsv(redD,greenD,blueD,&hue,&saturation,&value);
    	(palP+pjj)->cHue = hue*4.0;
    	(palP+pjj)->cSaturation = saturation*4.0;
    	(palP+pjj)->cValue = value*4.0;	    
	    (palP+pjj)->isSet = TRUE;
	    (palP+pjj)->realV = pjj;
	}
	ReleasePtr(palH);
		
	 /* read palettized pixels */
		    
	pixP = (unsigned char FAR *)GetPtr(palpixelH);
	tempL = width*height;
	TUTORzero(pixP,tempL);
	tempL = ReadRawText(pixP,width*height);
	if (tempL != (width*height))
	    TxtMemErr++;
	ReleasePtr(palpixelH);
    } /* nColors if */

    /* read pixels to cT handle */
        
    pixP = (unsigned char FAR *)GetPtr(rgbpixelH); /* pointer to cT handle */
    TUTORzero((char FAR *)pixP,sizeH);
    pixelsP = ((unsigned char FAR *)(pixP));

    if (version == PIXMAPVERS1) {
    	nInLine = 0; /* no pixels left in current line */
    	for(rowI=0; rowI<height; rowI++) {
	    for(pixelI=0; pixelI<width; pixelI++) {
            	if (!nInLine) {
		    if (!GetSourceChars(tempS,80,NEWLINE)) {
                    	/* couldn't read anymore from file! */
			ReleasePtr(rgbpixelH);
			TUTORfree_handle(rgbpixelH);
			return('?');
		    }
		    inP = tempS; /* read from begin of line */
		    nInLine = pixelsLine;
            	} /* nInLine if */
            	rr = (((*inP++)-'A') << 4)+((*inP++)-'A');
            	gg = (((*inP++)-'A') << 4)+((*inP++)-'A');
            	bb = (((*inP++)-'A') << 4)+((*inP++)-'A');
            	nInLine--;
            	*pixelsP++ = rr;
            	*pixelsP++ = gg;
            	*pixelsP++ = bb;
	    } /* pixelI for */
    	} /* rowI for */
    } else { /* PIXMAPVERS2 */
    	tempL = ReadRawText(pixelsP,sizeH);
    	if (tempL != sizeH) {
	    TxtMemErr++; /* flag some sort of error happened */
	    ReleasePtr(rgbpixelH);
	    TUTORfree_handle(rgbpixelH);
            return('?');
    	}
    }
    ReleasePtr(rgbpixelH);

    if (palpixelH) {

	/* convert palettized pixel data in memory to pixmap */
        
	pixP = (unsigned char FAR *)GetPtr(palpixelH); /* pointer to cT handle */
	regionH = TUTORmem_to_region(1,(int)width,(int)height,palH,pixP);
	ReleasePtr(palpixelH);
    } else {

	/* convert pixel r,g,b data in memory to pixmap */
        
	pixP = (unsigned char FAR *)GetPtr(rgbpixelH); /* pointer to cT handle */
	regionH = TUTORmem_to_region(2,(int)width,(int)height,HNULL,pixP);
	ReleasePtr(rgbpixelH);
    } /* palpixelH else */

    if (!regionH)
	TxtMemErr++;

    /* attach palette */
    
    if (regionH) {
    	regionP = (struct saved_region FAR *)GetPtr(regionH);
    	regionP->nativePal = palH; /* attach palette */
    	regionP->palDataH = palpixelH;
    	regionP->rgbDataH = rgbpixelH;
    	ReleasePtr(regionH);
    }

    FinishReadSpecial("STXT");
    
    /* put special text in doc */
    
    dp = (DocP) GetPtr(doc);
    if (!dp->specialT) {
        dp->specialT = TUTORnew_stext();
    }
    TUTORadd_stext(dp->specialT,pos,PIXMAPSPECIAL,regionH);
    ReleasePtr(doc);
    
    return(PIXMAPSPECIAL);

} /* ReadPixmap */

#endif /* WINPC */

/* ******************************************************************* */

#ifdef X11

static ReadPixmap(doc,pos)  /* read in pixmap special character */
Memh doc;   /* document we are reading in for */
long pos;   /* position in document */
/* returns char value of special char */
    
{   Memh regionH; /* handle on region */
    struct saved_region FAR *regionP; /* pointer to region header */
    DocP dp; /* pointer to doc */
    int version; /* datastream version */
    long width,height; /* picture size */
    int pixelsLine; /* number pixels/line */
    int rr,gg,bb; /* red, green, blue components */
    long sizeH; /* size of cT handle */
    long rowBytes; /* bytes per row in pixmap */
    long rowI; /* index in rows */
    long pixelI; /* index in pixels */
    Memh palH; /* handle on palette data */
    struct CTcolorentry FAR *palP; /* pointer to palette data */
    int nColors; /* number colors stored with image */
    unsigned char SHUGE *pixP; /* pointer to pixels */
    unsigned char SHUGE *pixelsP; /* pointer to pixels */
    Memh rgbpixelH; /* handle on rgb pixel data */
    Memh palpixelH; /* handle on palettized pixel data */
    int pii,pjj;
    long *lP; 
    long tempL;
    int nInLine; /* number pixels left in current line */
    char *inP; /* pointer in input line */
    char tempS[81]; /* buffer for reading in a line of characters */
    double redD,greenD,blueD;
    double hue,saturation,value;

    palH = palpixelH = HNULL; /* no palette yet */
    nColors = 0;

    /* read version  */
    
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%ld",&tempL);
    version = tempL;
    if ((version != PIXMAPVERS1) && (version != PIXMAPVERS2))
        return('?');
    
    /* get size of pixmap */
    
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%ld",&width);
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%ld",&height);
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%d",&pixelsLine);
    if ((version == PIXMAPVERS1) && (pixelsLine != 8))
	return('?');
    if (version == PIXMAPVERS2)
	nColors = pixelsLine;

    /* set up cT handle for pixels */
    
    rowBytes = width*3; /* 3 bytes/pixel */
    sizeH = rowBytes*height;
    rgbpixelH = TUTORhandle("pixmap",sizeH,TRUE);
    if (!rgbpixelH) {
    	TxtMemErr++;
        return('?'); /* couldn't get enough memory */
    }
    TUTORpurge_info(rgbpixelH,M_WORM,FARNULL,0);
    AllowHandlePurge(rgbpixelH);

    /* set up cT handle for palettized pixels */
    
    if (nColors) {
    	tempL = width*height;
    	palpixelH = TUTORhandle("palpix",tempL,TRUE);
    	if (palpixelH) {
	    TUTORpurge_info(palpixelH,M_WORM,FARNULL,0);
	    AllowHandlePurge(palpixelH);
	} else {
	    TxtMemErr++;
	    nColors = 0;
	}
    }
	
    /* read colors and palettized pixels */
    
    if (nColors) {
			
    	/* allocate palette */
    	
	palH = initial_palette();
	if (!palH) {
	    TUTORfree_handle(rgbpixelH);
	    TUTORfree_handle(palpixelH);
	    TxtMemErr++;
	    return('?');
	}

	/* read colors to palette */

	palP = (struct CTcolorentry FAR *)GetPtr(palH);
	for(pii=0; pii<nColors; pii++) {
	    tempL = ReadRawText((unsigned char FAR *)tempS,7L);
	    if (tempL != 7)
		TxtMemErr++; /* something bad happened */
	    rr = ((tempS[1] << 8) & 0xff00) | (tempS[2] & 0xff);
	    gg = ((tempS[3] << 8) & 0xff00) | (tempS[4] & 0xff);
	    bb = ((tempS[5] << 8) & 0xff00) | (tempS[6] & 0xff);
	    pjj = tempS[0] & 0xff; /* index in palette */
	    (palP+pjj)->red = rr;
	    (palP+pjj)->green = gg;
	    (palP+pjj)->blue = bb;
	    redD = (((double) (palP+pjj)->red)/(double) 0xffff) * 100.0;
    	greenD = (((double) (palP+pjj)->green)/(double) 0xffff) * 100.0;
    	blueD = (((double) (palP+pjj)->blue)/(double) 0xffff) * 100.0;
    	TUTORrgb_to_hsv(redD,greenD,blueD,&hue,&saturation,&value);
    	(palP+pjj)->cHue = hue*4.0;
    	(palP+pjj)->cSaturation = saturation*4.0;
    	(palP+pjj)->cValue = value*4.0;	    
	    (palP+pjj)->isSet = TRUE;
	    (palP+pjj)->realV = pjj;
	}
	ReleasePtr(palH);
		
	 /* read palettized pixels */
		    
	pixP = (unsigned char FAR *)GetPtr(palpixelH);
	tempL = width*height;
	TUTORzero(pixP,tempL);
	tempL = ReadRawText(pixP,width*height);
	if (tempL != (width*height))
	    TxtMemErr++;
	ReleasePtr(palpixelH);
    } /* nColors if */

    /* read pixels to cT handle */
        
    pixP = (unsigned char FAR *)GetPtr(rgbpixelH); /* pointer to cT handle */
    TUTORzero((char FAR *)pixP,sizeH);
    pixelsP = ((unsigned char FAR *)(pixP));

    if (version == PIXMAPVERS1) {
    	nInLine = 0; /* no pixels left in current line */
    	for(rowI=0; rowI<height; rowI++) {
	    for(pixelI=0; pixelI<width; pixelI++) {
            	if (!nInLine) {
		    if (!GetSourceChars(tempS,80,NEWLINE)) {
                    	/* couldn't read anymore from file! */
			ReleasePtr(rgbpixelH);
			TUTORfree_handle(rgbpixelH);
			return('?');
		    }
		    inP = tempS; /* read from begin of line */
		    nInLine = pixelsLine;
            	} /* nInLine if */
            	rr = (((*inP++)-'A') << 4)+((*inP++)-'A');
            	gg = (((*inP++)-'A') << 4)+((*inP++)-'A');
            	bb = (((*inP++)-'A') << 4)+((*inP++)-'A');
            	nInLine--;
            	*pixelsP++ = rr;
            	*pixelsP++ = gg;
            	*pixelsP++ = bb;
	    } /* pixelI for */
    	} /* rowI for */
    } else { /* PIXMAPVERS2 */
    	tempL = ReadRawText(pixelsP,sizeH);
    	if (tempL != sizeH) {
	    TxtMemErr++; /* flag some sort of error happened */
	    ReleasePtr(rgbpixelH);
	    TUTORfree_handle(rgbpixelH);
            return('?');
    	}
    }
    ReleasePtr(rgbpixelH);

    if (palpixelH) {

	/* convert palettized pixel data in memory to pixmap */
        
	pixP = (unsigned char FAR *)GetPtr(palpixelH); /* pointer to cT handle */
	regionH = TUTORmem_to_region(1,(int)width,(int)height,palH,pixP);
	ReleasePtr(palpixelH);
    } else {

	/* convert pixel r,g,b data in memory to pixmap */
        
	pixP = (unsigned char FAR *)GetPtr(rgbpixelH); /* pointer to cT handle */
	regionH = TUTORmem_to_region(2,(int)width,(int)height,HNULL,pixP);
	ReleasePtr(rgbpixelH);
    } /* palpixelH else */

    if (!regionH)
	TxtMemErr++;

    /* attach palette */
    
    if (regionH) {
    	regionP = (struct saved_region FAR *)GetPtr(regionH);
    	regionP->nativePal = palH; /* attach palette */
    	regionP->palDataH = palpixelH;
    	regionP->rgbDataH = rgbpixelH;
    	ReleasePtr(regionH);
    }

    FinishReadSpecial("STXT");
    
    /* put special text in doc */
    
    dp = (DocP) GetPtr(doc);
    if (!dp->specialT) {
        dp->specialT = TUTORnew_stext();
    }
    TUTORadd_stext(dp->specialT,pos,PIXMAPSPECIAL,regionH);
    ReleasePtr(doc);
    
    return(PIXMAPSPECIAL);

} /* ReadPixmap */

#endif

/* ******************************************************************* */

#ifdef X11no

static ReadPixmap(doc,pos)  /* read in pixmap special character */
Memh doc;   /* document we are reading in for */
long pos;   /* position in document */
/* returns char value of special char */

{   Memh headerH; /* handle on region header */
#ifdef NOSUCH
    struct saved_region FAR *headerP; /* pointer to region header */
	Memh paletteH; /* handle on cT palette */
	struct CTcolorentry FAR *paletteP; /* pointer to cT palette */
	struct CTcolorentry FAR *rgbP; /* pointer in cT palette */
    DocP dp; /* pointer to doc */
    int version; /* datastream version */
    long width,height; /* picture size */
    int pixelsLine; /* number pixels/line */
    int rr,gg,bb; /* red, green, blue components */
    long sizeBits; /* bytes required for color bitmap */
    long sizeH; /* size of cT handle */
    long rowBytes; /* bytes per row in pixmap */
    long rowExtra; /* extra bytes required at end of row */
    long rowI; /* index in rows */
    long pixelI; /* index in pixels */
	Memh pInBuffH; /* handle on input buffer */
	unsigned char FAR *pInBuff; /* pointer to input buffer for pixels */
    unsigned char FAR *pixelsP; /* pointer in pixels */
	unsigned char FAR *pixelOutP; /* pointer in pixels */
	long tmpSize; /* size of pixels buffer during input */
	long finalSize; /* size of pixels buffer after conversion */
	int nColors; /* current number colors in color table */
	int cii; /* index in colors */
	long dist,curDist,bestDist;
	int pixelV; /* pixel color value */
	XImage *theImage; /* pointer to X11 image we'll build */
    int nInLine; /* number pixels left in current line */
    char *inP; /* pointer in input line */
	long tempL; /* temp for reading in a value */
    char tempS[82]; /* buffer for reading in a line of characters */

    /* read version  */

    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%ld",&tempL);
    version = tempL;
    if ((version != PIXMAPVERS1) && (version != PIXMAPVERS2))
        return('?');
    
    /* get size of pixmap */
    
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%ld",&width);
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%ld",&height);
    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
        return('?');
    sscanf(tempS,"%d",&pixelsLine);
    if ((version == PIXMAPVERS1) && (pixelsLine != 8))
        return('?');

    /* set up temporary storage for pixels */
    
    rowBytes = width*3; /* 3 bytes/pixel */
	tmpSize = rowBytes*height;
	pInBuffH = TUTORhandle("pixmap",tmpSize,TRUE);
    if (!pInBuffH)
        return('?'); /* couldn't get enough memory */
    TUTORpurge_info(pInBuffH,M_WORM,FARNULL,0);
    AllowHandlePurge(pInBuffH);
    
    /* set up cT handle for header */

    headerH = TUTORhandle("region",(long)sizeof(struct saved_region),TRUE);
    if (!headerH) {
        TUTORfree_handle(pInBuffH);
        return('?'); /* couldn't get enough memory */
    }
    headerP = (struct saved_region FAR *)GetPtr(headerH);
    TUTORzero((char FAR *)headerP,(long)sizeof(struct saved_region));
	headerP->format = 1; /* XImage */
	headerP->width = width;
	headerP->height = height;
	headerP->palDataH = pInBuffH; /* handle on intermediate data */
    ReleasePtr(headerH); /* done with header */
    KillPtr(headerP);

	/* read pixels to temporary buffer */
	
	pInBuff = (unsigned char FAR *)GetPtr(pInBuffH);
    pixelsP = pInBuff;
	if (version == PIXMAPVERS1) { /* ascii (old) format */
    	nInLine = 0; /* no pixels left in current line */
    	for(rowI=0; rowI<height; rowI++) {
        	for(pixelI=0; pixelI<width; pixelI++) {

				/* get new source line if needed */
			
            	if (!nInLine) {
					if (!GetSourceChars(tempS,80,NEWLINE)) {
                    	/* couldn't read anymore from file! */
                    	TUTORfree_handle(pInBuffH);
                    	TUTORfree_handle(headerH);
                    	return('?');
                	}
                	inP = tempS; /* read from begin of line */
                	nInLine = pixelsLine;
            	} /* nInLine if */

				/* extract next pixel from line */

            	rr = ((*inP++)-'A') << 4;
				rr |= (*inP++)-'A';
            	gg = ((*inP++)-'A') << 4;
				gg |= (*inP++)-'A';
            	bb = ((*inP++)-'A') << 4;
				bb |= (*inP++)-'A';
				*pixelsP++ = rr;
				*pixelsP++ = gg;
				*pixelsP++ = bb;
            	nInLine--;
        	} /* pixelI for */
    	} /* rowI for */
	} else {
	    tempL = ReadRawText(pixelsP,tmpSize);
    	if (tempL != tmpSize) {
    	   	TxtMemErr++; /* flag some sort of error happened */
    		ReleasePtr(pInBuffH);
            TUTORfree_handle(pInBuffH);
			TUTORfree_handle(headerH);
            return('?');
    	}
	} /* version else */

    /* build cT palette from raw pixels */
  
    headerP = (struct saved_region FAR *)GetPtr(headerH);
 /* wrong here ?? */
    headerP->palH = TUTORmake_pix_palette(1,pInBuff,width,height,width*3);
	paletteH = headerP->palH;
    ReleasePtr(headerH);
    KillPtr(headerP);
	if (!paletteH) { /* not enough memory */
		ReleasePtr(pInBuffH);
		TUTORfree_handle(pInBuffH);
		TUTORfree_handle(headerH);
		return('?');
	}
	nColors = TUTORget_hsize(paletteH)/sizeof(struct CTcolorentry);
	paletteP = (struct CTcolorentry FAR *)GetPtr(paletteH);
	
	/* convert R,G,B pixels to indexes in cT palette */
	/* do this in place in temporary bufffer as indexes are */
	/* smaller than r,g,b entries */
	
    pixelsP = pixelOutP = pInBuff;
    for(rowI=0; rowI<height; rowI++) {
        for(pixelI=0; pixelI<width; pixelI++) {
			rr = (*pixelsP++) << 8;
			gg = (*pixelsP++) << 8;
			bb = (*pixelsP++) << 8;
			if (rr == 0xff00) rr = 0xffff;
			if (gg == 0xff00) gg = 0xffff;
			if (bb == 0xff00) bb = 0xffff;	
			rgbP = paletteP;
			bestDist = 0x7fffffffL;
			for(cii=0; cii<nColors; cii++) {
				curDist = rr-rgbP->red;
				if (curDist < 0) curDist = -curDist;
				dist = gg-rgbP->green;
				if (dist < 0) dist = -dist;
				curDist += dist;
				dist = bb-rgbP->blue;
				if (dist < 0) dist = -dist;
				curDist += dist;
				if (curDist < bestDist) {
					bestDist = curDist;
					pixelV = cii;
					if ((curDist == 0) && (rr == rgbP->red) &&
					    (gg == rgbP->green) && (bb == rgbP->blue))
							break; /* exact match */
				}
				rgbP++;
			} /* cii for */				
			*pixelOutP++ = pixelV; /* set next pixel value */
		} /* pixelI for */
	} /* rowI for */
	ReleasePtr(pInBuffH);
	ReleasePtr(paletteH);
	
	finalSize = width*height;
	TUTORset_hsize(pInBuffH,finalSize,TRUE);
	
    FinishReadSpecial("STXT");
    
    /* put special text in doc */
    
    dp = (DocP) GetPtr(doc);
    if (!dp->specialT) {
        dp->specialT = TUTORnew_stext();
    }
    TUTORadd_stext(dp->specialT,pos,PIXMAPSPECIAL,headerH);
    ReleasePtr(doc);
    return(PIXMAPSPECIAL);
#endif
return('?');
} /* ReadPixmap */

#endif /* X11 */

/* ******************************************************************* */

static ReadIcons(doc,pos)   /* read in icon(s) special character */
Memh doc;   /* document we are reading in for */
long pos;   /* position in document */
/* returns char value of special char */
    
{   char tempS[81]; /* buffer for reading in a line of characters */
    int retC; /* the returned character value */
    long version; /* icon character datastream version */
    Memh iconDatH; /* handle on icon data */
    int FAR *iconDatP; /* pointer to icon data */
    int FAR *iconBaseP; /* pointer to icon data */
    long iconDatL; /* length of icon data */
    long iconDatA; /* length allocated for icon data */
    int nIcons; /* number icons (actually icon numbers) */
    int iconsRead; /* number icons read from file */
    int iconsLeft; /* number icons left to read */
    int iw[8]; /* for sscanf read */
    int wi;
    DocP dp; /* pointer to doc */
    
    /* read version */

    if (!GetSourceChars(tempS,80,NEWLINE)) /* read a line */
	return('?');
    sscanf(tempS,"%ld",&version);
    if (version != BITMAPVERS1)
	TUTORdump("txt3 10");

    /* read number of icons */
    
    GetSourceChars(tempS,80,NEWLINE);
    sscanf(tempS,"%d",&nIcons); /* get number of icons */
    if ((nIcons <= 0) | (nIcons >= 0x8000))
        return('?'); 
    
    /* allocate handle for icon data */
    
    iconDatA = 200L+nIcons*sizeof(int); /* more than will be needed */
    iconDatH = TUTORhandle("spcltext",iconDatA,TRUE);
    TUTORpurge_info(iconDatH,M_WORM,FARNULL,0);
    AllowHandlePurge(iconDatH);
    
    /* read icon numbers from file */

    iconsRead = 0;
    iconBaseP = (int FAR *)GetPtr(iconDatH);
    iconDatP = iconBaseP;
    *iconDatP++ = nIcons; /* set number icons */
    do {
	GetSourceChars(tempS,80,NEWLINE);
        iconsLeft = nIcons-iconsRead;
        if (iconsLeft < 8) {
            for(wi=iconsLeft; wi<8; wi++)
                strcat(tempS,"0 "); /* fill out to 8 numbers */
        } /* iconsLeft if */
        sscanf(tempS,"%d %d %d %d %d %d %d %d",
               &iw[0],&iw[1],&iw[2],&iw[3],&iw[4],&iw[5],&iw[6],&iw[7]);
        for(wi=0; wi<8; wi++)
            *iconDatP++ = iw[wi]; /* transfer (near) values read by sscanf */
        iconsRead += 8;
    } while (iconsRead < nIcons);
    
    /* read icon file/family name and set icon family id field */

    iconDatP = iconBaseP+nIcons+1; /* now point to id */
    GetSourceChars(tempS,80,NEWLINE);
    wi = strlen(tempS);
    if (wi && (tempS[wi-1] == NEWLINE)) /* remove terminating newline */
        tempS[wi-1] = 0;
    *iconDatP++ = cvt_font_name(tempS); /* convert font name to index */
    strcpyf((char FAR *)iconDatP,(char FAR *)tempS); 

    /* resize handle to proper size */
        
    ReleasePtr(iconDatH);
    iconDatL = (nIcons+2)*sizeof(int)+strlen(tempS)+1; /* length required */
    TUTORset_hsize(iconDatH,iconDatL,TRUE);
    
    FinishReadSpecial("STXT");
    
    /* put special text in doc */

    retC = ICONSPECIAL;
    dp = (DocP) GetPtr(doc);
    if (!dp->specialT)
        dp->specialT = TUTORnew_stext();
    TUTORadd_stext(dp->specialT,pos,retC,iconDatH);
    ReleasePtr(doc);

    return(retC);
    
} /* ReadIcons */
        
/* ******************************************************************* */

#ifdef Nosuch

static TUTORfread_native_doc(doc,len) /* read non-datastream */
Memh doc;   /* document we are reading */
long len;   /* the number of chars we finally want (if < 0, just keep reading) */
    {
    long filePos;   /* position in source file */
    long tempL, tempL2;
    unsigned char FAR *cp;  /* result of newline search */
    int ii;
    REGISTER DocP dp;       /* pointer to doc */
    unsigned char newlineS[2];  /* newline sequence */
    
   
    readLeft = len;
    ReadText(TRUE);
    
    while (readLeft > 0)
        {
        if (sourceLeft < readLeft && isMore) /* there is more following this block */
            { /* try to make this block end on newline */
            newlineS[0] = NEWLINE;
	    cp = TUTORscan_bytes((source0+(sourceLeft-1)),source0,newlineS,1);
            if (cp)
                {
                tempL = (cp - source0) + 1; /* include newline */
                /* move file read position so next read picks up after newline */
                filePos = TUTORinq_file_pos(sourceFile);
		TUTORseek(sourceFile,filePos - (sourceLeft - tempL));
                sourceLeft = tempL; /* change block length */
		}
            }
        
        if (sourceLeft > readLeft)
	    TUTORdump("txt3 11");
        
        /* convert chars */
        TUTORcvt_native_chars(source0,sourceLeft);

        /* add text to doc */
		if (sourceH) {
			if (sourcep)
 	    		ReleasePtr(sourceH);
        	sourcep = FARNULL;
        	_TUTORadd_tblock_doc(doc,sourceH,sourceLeft);
        	sourceH = HNULL;
		}
        readLeft -= sourceLeft;
        if (readLeft > 0)
            { /* read some more text */
            ReadText(TRUE);
            if (!isMore)
                readLeft = sourceLeft;
            }
        }
    
    dp = (DocP) GetPtr(doc);
    dp->shortText = FALSE;
    if (dp->totLen < MAXSTRINGLEN-200)
        {
        ii = TRUE;
        }
    else
        {
        ii = FALSE;
        }
    ReleasePtr(doc);
    KillPtr(dp);
    if (ii)
        TBlockToStringDoc(doc); /* convert to string doc */

    return(0);
    }
#endif



static TUTORfread_native_doc(doc,len) /* read non-datastream */
Memh doc;   /* document we are reading */
long len;   /* the number of chars we finally want (if < 0, just keep reading) */
    {
    long filePos;   /* position in source file */
    long tempL, tempL2;
    unsigned char FAR *cp;  /* result of newline search */
    int ii;
    REGISTER DocP dp;       /* pointer to doc */
    unsigned char newlineS[2];  /* newline sequence */
    
    /* note that this routine is called from TUTORfread_doc, so that we expect
        the first text to already be in sourceH */
    
    if (len < 0)
        {
        if (isMore)
            len = 0x7fffffff; /* infinity (we just keep reading) */
        else
            len = sourceLeft; /* we've already read all that's available */
        }
   
    readLeft = len;
    while (readLeft > 0)
        {
        if (sourceLeft < readLeft && isMore) /* there is more following this block */
            { /* try to make this block end on newline */
            newlineS[0] = NEWLINE;
	    cp = TUTORscan_bytes((source0+(sourceLeft-1)),source0,newlineS,1);
            if (cp)
                {
                tempL = (cp - source0) + 1; /* include newline */
                /* move file read position so next read picks up after newline */
                filePos = TUTORinq_file_pos(sourceFile);
		TUTORseek(sourceFile,filePos - (sourceLeft - tempL));
                sourceLeft = tempL; /* change block length */
		}
            }
        
        if (sourceLeft > readLeft)
	    TUTORdump("txt3 12");
        
        /* convert chars */
        TUTORcvt_native_chars(source0,sourceLeft);

        /* add text to doc */
		if (sourceH) {
			if (sourcep)
 	    		ReleasePtr(sourceH);
        	sourcep = FARNULL;
        	_TUTORadd_tblock_doc(doc,sourceH,sourceLeft);
        	sourceH = HNULL;
		}
        readLeft -= sourceLeft;
        if (readLeft > 0)
            { /* read some more text */
            ReadText(TRUE);
            if (!isMore)
                readLeft = sourceLeft;
            }
        }
    
    dp = (DocP) GetPtr(doc);
    dp->shortText = FALSE;
    if (dp->totLen < MAXSTRINGLEN-200)
        {
        ii = TRUE;
        }
    else
        {
        ii = FALSE;
        }
    ReleasePtr(doc);
    KillPtr(dp);
    if (ii)
        TBlockToStringDoc(doc); /* convert to string doc */

    return(0);
    }


_TUTORadd_tblock_doc(theD,textH,tLen) /* add text block to doc */
Memh theD; /* the document */
Memh textH; /* new text */
long tLen; /* length of text */
    {
    DocP dp;        /* pointer to document */
    DArrayHeader FAR *dap;  /* dynamic array header for text blocks */
    register TextBlock FAR *tbp;    /* pointer to new text block */

    /* size down the text to leave no extra */
    TUTORset_hsize(textH,tLen,TRUE);
    
    /* add another text block to doc */
    dp = (DocP) GetPtr(theD);
    ReleasePtr(theD);
    KillPtr(dp);
    TUTORinsert_darray(theD,FARNULL,DOCOFFSET,DOCTBLOCK,32760,1);

    dp = (DocP) GetPtr(theD);
    dap = (DArrayHeader FAR *) ((char FAR *) dp + dp->offsets[DOCTBLOCK]);
    tbp = ((TextBlock FAR *) (dap+1)) + (dap->dAnn - 1);
    tbp->tLen = tLen;
    tbp->tExtra = 0;
    tbp->text = textH;
    
    dp->totLen += tLen;

    /* make text of block purgeable */
    TUTORpurge_info(textH,M_WORM,FARNULL,0);
    AllowHandlePurge(textH);

    ReleasePtr(theD);
    KillPtr(dp);
    return(0);
    }

#ifdef IBMPCno
static long StripCR(t0,len) /* strip carriage returns */
unsigned char FAR *t0;  /* pointer to start to text */
long len;   /* # of chars in text chunk */
/* returns # chars that are left */
    {
    register unsigned char FAR *tp;
    register long lenLeft;
    register unsigned char FAR *destP;
    
    /* strip out carriage returns */
    tp = destP = t0;
    lenLeft = len;
    
    while (lenLeft > 0)
        {
        if (*tp != 0xd)
            *destP++ = *tp++;
        else
            tp++;
        lenLeft--;
        }

    return(destP - t0);
    }
#endif

static int FixDocCR(doc) /* fix up for various possible types of newline */
Memh doc; /* handle on source document */
   
{	long docLen; /* length of document */
    long foundPos,searchPos; /* where found, where to look */
	char wrongStr[4]; /* 0d, 0a or 0d+0a string for search */
    DocP dp;
  
    docLen = TUTORget_len_doc(doc);
    dp = (DocP) GetPtr(doc); 

	/* convert 0d+0a sequences to NEWLINE */
	
    searchPos = 0; /* start at begin of document */ 
	wrongStr[0] = 0x0d;
	wrongStr[1] = 0x0a;
	wrongStr[3] = 0;  
    while (TRUE) {
    	foundPos = TUTORsearch_string_doc(dp,(unsigned char FAR *)wrongStr,
						  2L,searchPos,docLen);
		if (foundPos < 0)
			break; /* exit while */
		searchPos = foundPos; /* start next search from here */
		if (NEWLINE == 0x0d) 
			foundPos++; /* delete 0a */
		ReleasePtr(doc);
		TUTORdelete_doc(doc,foundPos,1L,NEARNULL);
		dp = (DocP)GetPtr(doc);
		docLen--; /* removed one character from document */
	} /* while */

	/* convert 0d->0a or 0a->0d */
	
	searchPos = 0; /* start at begin of document */ 
	if (NEWLINE == 0x0d) wrongStr[0] = 0x0a;
	else wrongStr[0] = 0x0d;
	wrongStr[1] = 0;  
    while (TRUE) {
    	foundPos = TUTORsearch_string_doc(dp,(unsigned char FAR *)wrongStr,
						  1L,searchPos,docLen);
		if (foundPos < 0)
			break; /* exit while */
		searchPos = foundPos; /* start next search from here */
		ReleasePtr(doc);
		TUTORinsert_string_doc(doc,foundPos,(unsigned char FAR *)NEWLINES,1L);
		TUTORdelete_doc(doc,foundPos+1L,1L,NEARNULL);
		dp = (DocP)GetPtr(doc);
	} /* while */
	
	ReleasePtr(doc);
  	return(0);

} /* FixDocCR */

/* maximum # of normal chars that can be written to a line: */
/*      note that we need to allow for possible escape \ to be written at end of line */
#define MAXLINEC 70

TUTORfwrite_doc(doc,pos,len,fInd, nativeF)  /* write document to file */
Memh doc;   /* document we are writing */
long pos,len;   /* what portion of document to write */
int fInd;       /* tutor file index of file we are writing to */
int nativeF;    /* if TRUE, always write native */
/* returns success flag */
    {
    DocP dp;    /* pointer to document doc */
    StyleDatP sp;   /* pointer to style structure of doc */
    int styleInd;   /* index of current style block */
    short curStyles[NSTYLES];   /* styles at current position in document */
    register Style1 SHUGE *s1p;   /* pointer to current style block */
    register Style1 SHUGE *s1End; /* pointer to last style block */
    SpecialTP stp;      /* pointer to special text structure */
    int stind;      /* index of current special text block */
    SText FAR *st1p, FAR *st1End;   /* pointers to current & last special text blocks */
    TextBlock FAR *curBlock;    /* pointer to current text block */
    unsigned char FAR *t0;  /* points at current text */
    long tempL;
    long nextStylePos;  /* next position where style changes */
    long nextSTextPos;  /* next position where there is special text */
    long nextCharPos;   /* next block boundary position */
    long curPos;        /* current position in document */
int ii;
    long offset;    /* offset from t0 to where we should start writing text */
    Memh hotListOut;    /* handle to hot list we wil output (subset of document hotlist) */

    if (!doc)
        return(FALSE);

    if (nativeF)
        {
        return(TUTORfwrite_native_doc(doc,pos,len,fInd));
        }

    hotListOut = HNULL; /* no hot text yet */
    
    dp = (DocP) GetPtr(doc);
    _TUTORsetup_layout(dp,pos,len,&styleInd,&sp,curStyles,NEARNULL,&stind,&stp,FALSE);
    
    if (dp->shortText)
        {
        t0 = ((unsigned char FAR *) dp->text) + pos;
        nextCharPos = pos+len;
        offset = 0;
        }
    else
        {
        curBlock = FindTBlock(dp,pos,&offset,&tempL);
        t0 = (unsigned char FAR *) GetPtr(curBlock->text);
        if (tempL > len)
            tempL = len;
        nextCharPos = pos+tempL;
        }
    
    if (sp)
        {
        s1p = ((Style1 SHUGE *) sp->styles) + styleInd;
        s1End = ((Style1 SHUGE *) sp->styles) + (sp->sHead.dAnn - 1); /* pointer to last style */
        nextStylePos = s1p->pos;
        }
    else
        nextStylePos = pos+len+10; /* past end of write */
    
    if (stp)
        {
        st1p = ((SText FAR *) stp->text) + stind;
        st1End = ((SText FAR *) stp->text) + (stp->head.dAnn - 1); /* pointer to last special text */
        nextSTextPos = st1p->pos;
        }
    else
        nextSTextPos = pos+len+10; /* past end of write */
    
    /* start output */
    nUsed = 0;  /* we assumme we are just beginning a line */
    ioErrV = FALSE;  /* no errors so far */
    WriteHeader(fInd,curStyles,sp,s1p,pos+len);
    
    /* write out initial styles */
    for (ii=0; ii<NSTYLES; ii++)
        if (curStyles[ii] != DEFSTYLE)
            WriteStyle(dp->styles,fInd,ii,curStyles[ii],&hotListOut);
    
    curPos = pos;
    while (!ioErrV)
        {
        /* set tempL to next boundary position */
        tempL = (nextStylePos < nextCharPos) ? nextStylePos : nextCharPos;
        if (stp)
            tempL = (nextSTextPos < tempL) ? nextSTextPos : tempL;
        
        tempL -= curPos; /* convert to # of chars */
        
        if (tempL > 0)
            WriteText(fInd,t0+offset,tempL); /* write text up to next position */
        curPos += tempL;
        if (curPos >= pos+len)
            break; /* we're done */
        offset += tempL;
        
        if (curPos == nextStylePos)
            {
            while (s1p <= s1End && s1p->pos == curPos)
                {
                WriteStyle(dp->styles,fInd,s1p->type,s1p->dat,&hotListOut);
                s1p++;
                }
            if (s1p <= s1End)
                nextStylePos = s1p->pos;
            else
                nextStylePos = pos+len+10; /* no more styles */
            }
        if (curPos == nextCharPos)
            { /* we need text from next textblock */
            ReleasePtr(curBlock->text);
            KillPtr(t0);
            curBlock++;
            t0 = (unsigned char FAR *) GetPtr(curBlock->text);
            offset = 0;
            nextCharPos += curBlock->tLen;
            }
        
        if (curPos == nextSTextPos)
            {
            TUTORfwrite_stext(fInd,st1p);
            nUsed = 0; /* fwrite_stext ended with fake newline */
            curPos += st1p->len; /* assummes no intervening styles! */
            offset += st1p->len;
            st1p++;
            if (st1p <= st1End)
                nextSTextPos = st1p->pos;
            else
                nextSTextPos = pos + len + 10; /* no more stext */
            }
        
        }

    if (sp)
        {
        ReleasePtr(dp->styles);
        KillPtr(sp);
        }
    if (stp)
        {
        ReleasePtr(dp->specialT);
       KillPtr(stp);
        }
   if (!dp->shortText)
        {
        ReleasePtr(curBlock->text);
        KillPtr(t0);
        }
    
    if (hotListOut)
        {
        WriteHottext(fInd,hotListOut);
        CloseHotList(hotListOut);
        }
    
    WriteTrailer(fInd);
    
    ReleasePtr(doc);
    KillPtr(dp);
    return(!ioErrV);
    }

static WriteHeader(ff,curStyles,sp,s1p,end) /* write beginning of cT datastream */
int ff; /* file index */
short curStyles[NSTYLES]; /* styles where write begins */
StyleDatP sp;   /* pointer to styles structure (NULL if no more styles) */
register Style1 SHUGE *s1p;   /* pointer to next style */
long end;       /* position where write stops */
    {
    char tempS[FILEL];  /* buffer for assembling output */
    short newPara, oldPara; /* newest & most recently encountered paragraph layout styles */
    register Style1 SHUGE *s1End; /* current style block */
    ParagraphLayout pLay;   /* paragraph layout to output */
    register short ii;
    char *formatStr = "%3d%s";
    short familyTableW[HEADERTABLE], nFamiliesW; /* font family table to output */
    short paraTableW[HEADERTABLE],nParaW;   /* paragraph table to output */
    
    sprintf(tempS,"@cT datastream %d%s",CURVERSION,NEWLINES);
    WriteLiteral(ff,tempS);
    
    /* look thru styles & find out all fonts & paraStyles used */
    if (curStyles[FONTSTYLE] != DEFSTYLE)
        {
        familyTableW[0] = curStyles[FONTSTYLE];
        nFamiliesW = 1;
        }
    else
        nFamiliesW = 0;
    if (curStyles[PARASTYLE] != DEFSTYLE && 
            (curStyles[PARASTYLE] & PARALMASK) != PARADEFAULT)
        {
        paraTableW[0] = oldPara = curStyles[PARASTYLE] & PARALMASK;
        nParaW = 1;
        }
    else
        {
        nParaW = 0;
        oldPara = -1; /* so doesn't equal anything non-default */
        }
    
    if (sp)
        { /* look for more styles */
        s1End = ((Style1 SHUGE *) sp->styles) + (sp->sHead.dAnn - 1);
        
        /* fill tables.  If we have more than HEADERTABLE families or layouts
            we just won't show them... */
        while (s1p <= s1End && s1p->pos < end)
            {
            if (s1p->type == FONTSTYLE && s1p->dat != DEFSTYLE)
                nFamiliesW = AddTable(familyTableW,nFamiliesW,s1p->dat);
            if (s1p->type == PARASTYLE)
                {
                newPara = s1p->dat & PARALMASK;
                if (s1p->dat == DEFSTYLE || newPara == PARADEFAULT)
                    oldPara = -1; /* so won't match anything else */
                else if (newPara != oldPara)
                    {
                    nParaW = AddTable(paraTableW,nParaW,newPara);
                    oldPara = newPara;
                    }
                }
            s1p++;
            }
        } /* end of if (sp) */
    
    if (nFamiliesW)
        { /* write out font table */
       
        /* write out table start */
        WriteLiteral(ff,"@4FONT");
        WriteText(ff,(unsigned char FAR *) NEWLINES,1L);
        
        /* show # of entries */
        if (strcmp(formatStr,"%3d%s"))
		TUTORdump("txt3 13");
        sprintf(tempS,/* "%3d%s" */formatStr,nFamiliesW,NEWLINES);
        WriteLiteral(ff,tempS);
        
        /* for each entry, write out font # and font name */
        for (ii=0; ii<nFamiliesW; ii++)
            {
	    sprintf(tempS,"%3x ",FontDat3(familyTableW[ii]));
            if (TUTORinq_font_name(FontFamilyIndex((long)familyTableW[ii]),tempS+4,FILEL-5))
                { /* got name successfully */
                }
            else
                { /* name was too long (so we don't support paths...) */
                strcat(tempS,"zserif");
                }
            strcat(tempS,NEWLINES);
            WriteText(ff,(unsigned char FAR *) tempS,(long) strlen(tempS));
            }
        
        /* terminate table */
        WriteLiteral(ff,"@5FONT");
        WriteText(ff,(unsigned char FAR *) NEWLINES,1L);
        }
    
    if (nParaW)
        { /* write out paragraph layout table */
        
        /* write out table start */
        WriteLiteral(ff,"@4PARA");
        WriteText(ff,(unsigned char FAR *) NEWLINES,1L);
        
        /* show # of entries */
        sprintf(tempS,"%3d%s",nParaW,NEWLINES);
        WriteLiteral(ff,tempS);
        
        /* for each entry, write out paragraph layout */
        for (ii=0; ii<nParaW; ii++)
            {
            GetParaLayout(paraTableW[ii],&pLay);
            sprintf(tempS,"%x %d %d %d %d %d%s",paraTableW[ii],pLay.tabSize, pLay.leftMar,
                    pLay.rightMar,pLay.paraIndent,pLay.extraLine,NEWLINES);
            WriteLiteral(ff,tempS);
            }
        
        /* terminate table */
        WriteLiteral(ff,"@5PARA");
        WriteText(ff,(unsigned char FAR *) NEWLINES,1L);
        }
    
    return(0);
    }

static AddTable(tbl,nTable,dat) /* helper routine for WriteHeader */
register short *tbl;    /* table */
register int nTable;        /* current # of entries in table */
register int dat;   /* new data being added (if it isn't already in table) */
/* returns new size of table */
    {
    /* check to see whether data is in table already */
    register int nn;
    
    if (nTable >= HEADERTABLE)
        return(nTable); /* no more space */

    nn = nTable;
    while (nn)
        {
        if (*tbl == dat)
            return(nTable); /* found in table, table doesn't change size */
        tbl++;
        nn--;
        }
    
    /* wasn't in table, so add it */
    *tbl = dat;
    return(nTable+1);
    }

static WriteTrailer(ff) /* write tail of cT datastream */
int ff;
    {
    char tempS[50]; /* buffer for assembling trailer */
    
    sprintf(tempS,"@cT end%s",NEWLINES);
    WriteLiteral(ff,tempS);
    }

static WriteText(ff,t0,tLen)    /* output text in datastream */
int ff;     /* TUTOR file index */
unsigned char FAR *t0;  /* pointer to text we want to output */
register long tLen;             /* total length of text */
    {
    register unsigned char FAR *tp; /* pointer to next character to write */
    long writeLen;  /* # of chars we want to write */
    long wLen;      /* # of chars that were written */
    char tempS[10]; /* buffer for encoding chars > 0x7f */
#ifdef IBMPC
    char newlineString[2];  /* ibmpc newline sequence */
    
    newlineString[0] = 0xd;
    newlineString[1] = 0xa;
#endif

    /* t0 points to start of chars we haven't written out yet
        tp points to char we are currently thinking about */

    tp = t0;
    while (tLen > 0 && !ioErrV)
        {
        if (*tp == NEWLINE)
            {
#ifdef IBMPC
            /* write out text to newline */
            writeLen = tp-t0;
            if (writeLen)
                {
                wLen = TUTORwrite((char FAR *) t0,1,writeLen,ff);
                if (wLen != writeLen)
                    ioErrV = TRUE;
                }
            /* write out crlf */
            if (2 != TUTORwrite((char FAR *) newlineString,1,2L,ff))
                ioErrV = TRUE;
            t0 = tp+1; /* AFTER newline */
#endif
            nUsed = 0; /* since this starts a new line */
            }
        else if (*tp == '@')
            { /* have to escape this character */
            
            /* first write all text up to at */
            writeLen = tp - t0; /* length up to, not including, at */
            if (writeLen)
                {
                wLen = TUTORwrite((char FAR *) t0,1,writeLen,ff);
                if (wLen != writeLen)
                    ioErrV = TRUE;
                }

            /* now make sure there's space to write the escaped at */
            if (nUsed+2 > MAXLINEC)
                { /* not enough space, we need to break line first */
                WriteEscape(ff,NEWLINE);
                nUsed = 0;
                }
            
            /* and write escaped at */
           WriteEscape(ff,'@');
            nUsed += 2;
            t0 = tp+1; /* first char AFTER at */
            }
        else if (*tp > 0x7f)
            { /* write special character */
            
            /* write text up to here */
            writeLen = tp - t0;
            if (writeLen)
                {
                wLen = TUTORwrite((char FAR *) t0, 1, writeLen, ff);
                if (wLen != writeLen)
                    ioErrV = TRUE;
                }
            
            if (nUsed+4 > MAXLINEC)
                { /* not enough space, break line */
                WriteEscape(ff,NEWLINE);
                nUsed = 0;
                }
            
            /* create string encoding this special char */
            sprintf(tempS,"@0%x",*tp);
            /* write special character */
            TUTORwrite((char FAR *) tempS,1,4L,ff);
            nUsed += 4;
            t0 = tp+1; /* char after special char */
            }
        else
            { /* normal character */
            if (nUsed >= MAXLINEC)
                { /* we've used up our space already - put in an escaped newline */

                /* first write the text so far */
                writeLen = (tp - t0); /* we will write up to, and not including, current char */
                wLen = TUTORwrite((char FAR *) t0, 1, writeLen, ff);
                if (wLen != writeLen)
                    ioErrV = TRUE;
                t0 = tp;
                
                /* now put in fake newline */
                WriteEscape(ff,NEWLINE);
                nUsed = 0;
                }
            nUsed++;
            }
        tp++;
        tLen--; /* used up a character */
        }
    
    if (tp != t0 && !ioErrV)
        { /* there's still some text to be written */
        writeLen = tp - t0;
        wLen = TUTORwrite((char FAR *) t0,1,writeLen,ff);
        if (wLen != writeLen)
            ioErrV = TRUE;
        }
    
    return(0);
    }

/* on unix machines (4 byte integer machines, really) we can't print out a short
    hex value in 4 characters via printf! */
#ifndef MAC
#ifndef IBMPC
#define LONGHEX
#endif
#endif

static WriteStyle(pd,ff,type,dat,hotList)   /* output an @1 style */
Memh pd;    /* styles handle */
int ff;     /* TUTOR file index */
int type;   /* style type */
int dat;    /* new style dat */
Memh *hotList;  /* the hotlist (for info strings) being generated, may be created here */
    {
    char tempS[20]; /* buffer for assembling output */
    char *styleS;   /* 2 character style name */
    unsigned char FAR *hotText; /* hot text info string */
    long len;   /* length of hot text */
    long spos, slen;    /* dummy args for GetHotstring */
#ifdef LONGHEX
    char hexS[9];   /* buffer for making hex number */
    int hexOff;
#endif
    
    switch (type)
        {
        case FONTSTYLE:
	    styleS = "fg";
	    dat = FontDat3(dat); /* keep within 3 hex digits */
            break;
        case SIZESTYLE:
            styleS = "fs";
            break;
        case FACESTYLE:
            styleS = "ff";
            break;
        case PARASTYLE:
            styleS = "pl";
            break;
        case COLORSTYLE:
            styleS = "cl";
            break;
        case HOTSTYLE:
            styleS = "ht";
            break;
        default:
	    TUTORdump("txt3 14");
            break;
        }

    if (type == HOTSTYLE && dat != DEFSTYLE)
        { /* put text in our temporary hotlist */
        if (!*hotList)
            *hotList = NewHotList();
        hotText = GetHotstringTStyle(pd,dat,&len, &spos, &slen, TRUE);
        dat = AddHotList(*hotList,hotText,len);
#ifdef DOCVERIFY
        if (dat == 0)
	    TUTORdump("txt3 15");
#endif
        if (hotText)
            TUTORdealloc((char FAR *) hotText);
        /* note that dat has been changed.  The result is sequential ids for
            the hottext styles in the output */
        }
    
#ifdef LONGHEX
    sprintf(hexS,"%4x",dat);
    hexOff = strlen(hexS) - 4;
    sprintf(tempS,"@1%s%s",styleS,hexS+hexOff);
#else
    sprintf(tempS,"@1%s%4x",styleS,(int)(dat & 0x0ffffL));
#endif
    WriteLiteral(ff,tempS);
    
    return(0);
    }

/* ******************************************************************* */

static TUTORfwrite_stext(fInd,st1p) /* write special character */
register int fInd; /* index of TUTORfile */
register SText FAR *st1p;   /* pointer to special character description */

{
    if (st1p->type == BITMAPSPECIAL)
        TUTORfwrite_bitmap(fInd,st1p); /* write bitmap character */
    else if (st1p->type == PIXMAPSPECIAL)
        TUTORfwrite_pixmap(fInd,st1p); /* write pixmap character */
    else if (st1p->type == ICONSPECIAL)
        TUTORfwrite_icons(fInd,st1p); /* write icon(s) */
    else TUTORdump("txt3 16");
    
} /* TUTORfwrite_stext */

/* ******************************************************************* */

static TUTORfwrite_bitmap(fInd,st1p) /* write bitmap character */
register int fInd; /* index of TUTORfile */
register SText FAR *st1p;   /* pointer to special character block of bitmap char */
    
{   char tempS[70]; /* buffer for assembling output */
    REGISTER struct pccharl FAR *cp;    /* pointer to character info */
    register int nWords;    /* # of words in raster */
    register int ii;
    int jj;
    unsigned char FAR *dp0; /* pointer to beginning of raster */
    unsigned char FAR *dp;  /* pointer into raster */
    char hexS[5];   /* hex string generated for word of raster */
    int slen;   /* length of hex string generated */
    char *pad0; /* pointer to a string used for padding */
    long cSize; /* # of bytes of character bitmap data */
    int padByte;    /* TRUE if we need a pad byte per row */
    int inLine; /* count of bytes in current output line */
    int rowBytes;   /* # of bytes per row */
  
#ifdef LINUX
    cp = (struct pccharl FAR *) (GetPtr(st1p->dat) + sizeof(struct pcfont816));
#else
    cp = (struct pccharl FAR *) (GetPtr(st1p->dat) + sizeof(struct pcfont));
#endif

    /* start new line, & do header */
    WriteEscape(fInd,NEWLINE);
    sprintf(tempS,"@4STXT%s",NEWLINES);
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%d%s",BITMAPSPECIAL,NEWLINES); /* indicate what kind of special char */
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%d%s",BITMAPVERS1,NEWLINES); /* bitmap stream version */
    WriteLiteral(fInd,tempS);
    nWords = ((cp->mapw - 1)/16 + 1)*cp->maph;
    cSize = nWords * 2L; /* size (assumming padded out to words) of bitmap */
    sprintf(tempS,"%ld%s",cSize,NEWLINES);
    WriteLiteral(fInd,tempS);
    
    /* output char header data */
    
    sprintf(tempS,"%d %d %d %d %s",cp->pdx, cp->pdy, cp->bndx, cp->bndy,NEWLINES);
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%d %d %d %d %s",cp->bnw, cp->bnh, cp->mapdx, cp->mapdy,NEWLINES);
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%d %d %s",cp->mapw,cp->maph,NEWLINES);
    WriteLiteral(fInd,tempS);

    /* we want to output an even number of bytes per row */
#ifndef MAC
    if ((cp->mapw - 1) % 16 > 7)
        padByte = FALSE; /* rows have an even number of bytes */
    else
        padByte = TRUE; /* rows in bitmap have an odd number of bytes, we need to pad it out */
#else
    padByte = FALSE; /* Mac has an even number of bytes per row */
#endif

    /* output bitmap, 16 words per line */
    pad0 = "0000";
    dp0 = (unsigned char FAR *) ((char FAR *) cp + sizeof(struct pccharl)); /* points at bitmap */
#ifdef ANDREW
    /* need to swap bits so that they will be correct in file */
    if (isx11)
        TUTORswap_bits_char(dp0,cSize);
#endif
    dp = dp0;
    tempS[0] = 0;
    inLine = 0;
    rowBytes = ((cp->mapw - 1) / 16 + 1)*2;
    if (padByte)
        rowBytes--; /* because memory image isn't padded out to word boundary */
    
    for (jj=0; jj<cp->maph; jj++) { /* for every row */
        for (ii=0; ii<rowBytes; ii++) { /* for every byte in the row */
            if (inLine >= 32) {
                /* time to write out a line of output */
                strcat(tempS,NEWLINES);
                WriteLiteral(fInd,tempS);
                tempS[0] = '\0';
                inLine = 0;
            }
            sprintf(hexS,"%x",*dp);
            dp++;
            slen = strlen(hexS);
            if (slen < 2)
                strncat(tempS,pad0,2-slen);
            strcat(tempS,hexS);
            inLine++;
        } /* byte for */
        if (padByte) { /* add a pad byte for the row */
           strcat(tempS,"00");
            inLine++;
        }
    } /* row for */
    
    if (inLine) { /* still a bit left to write out */
        strcat(tempS,NEWLINES);
        WriteLiteral(fInd,tempS);
    }
    
#ifdef ANDREW
    /* swap the bits back */
    if (isx11)
        TUTORswap_bits_char((unsigned char FAR *) dp0,cSize);
#endif
    ReleasePtr(st1p->dat);
    KillPtr(cp);
    
    sprintf(tempS,"@5STXT%s",NEWLINES);
    WriteLiteral(fInd,tempS);
    
    return(0);
    
} /* TUTORfwrite_bitmap */

/* ******************************************************************* */

#ifdef MAC

static TUTORfwrite_pixmap(fInd,st1p) /* write pixmap character */
register int fInd; /* index of TUTORfile */
register SText FAR *st1p;   /* pointer to special character block of pixmap char */
    
{   Memh regionH; /* handle on saved region */
    struct saved_region FAR *regionP; /* pointer to saved region */
    Memh rgbpixH; /* handle on rgb pixmap info */
    Memh palDatH; /* handle on palettized pixel data */
    PixMapPtr FAR rgbpixP; /* pointer to rgb pixmap data */
    unsigned char FAR *palDatP; /* pointer to palettized pixel data */
    long width,height; /* width,height of pixmap */
    long bytesRow; /* bytes per row */
    long rowI; /* index of current row */
    long pixelI; /* index of current pixel */
    unsigned char FAR *rowBaseP; /* pointer to base of row */
    unsigned char FAR *pixelP; /* pointer to current pixel */
    Memh buffH; /* handle on temporary buffer */
    long buffSize; /* size of temporary buffer */
    unsigned char FAR *buffP; /* pointer to temporary buffer */
    unsigned char FAR *outP; /* pointer in output buffer */
    Memh nativePalH; /* handle on native palette, if any */
    struct CTcolorentry FAR *nativePalP; /* pointer to native palette */
    Memh copyPalH; /* reordered copy of native palette */
    struct CTcolorentry FAR *copyPalP; /* pointer to copy of native palette */
    int nColorsUsed; /* colors actually used in palette */
    int pii,pjj; /* index in palette */
    unsigned int rr,gg,bb; /* red, green, blue components */
    long tempL;
    char tempS[70]; /* buffer for assembling output */
    
    /* get region in pixmap form */
    
    regionH = st1p->dat;
    palDatH = HNULL; /* not known to be palettized yet */
    TUTORget_rgb_region((long)regionH);
    TUTORget_pal_region((long)regionH);
	
    /* check required pieces of region present */
	
    regionP = (struct saved_region FAR *)GetPtr(regionH);
    rgbpixH = regionP->rgbpixH;
    nativePalH = regionP->nativePal;
    palDatH = regionP->palDataH;
    ReleasePtr(regionH);
    KillPtr(regionP);
    if (!rgbpixH)
    	return(0); /* nothing there */
    	
    copyPalH = HNULL;
    rgbpixP = (PixMapPtr FAR) GetPtr(rgbpixH);
    width = rgbpixP->bounds.right-rgbpixP->bounds.left;
    height = rgbpixP->bounds.bottom-rgbpixP->bounds.top;
    
    buffSize = width*height*3L; /* size required for pixels */
    buffH = TUTORhandle("tmp",buffSize,FALSE);
    if (!buffH) {
       	TxtMemErr++; 
    	ReleasePtr(rgbpixH);
    	return(0); /* no go */
    }
    buffP = (unsigned char FAR *)GetPtr(buffH);
    
    /* see if can create palettized form of image */
    
    nColorsUsed = 0;
    if (nativePalH) {
    	copyPalH = TUTORalloc_palette(256);
    	if (!copyPalH)
    		nativePalH = HNULL; /* no memory ? */
    }
    if (nativePalH) {
    	if (!palDatH) {
	    	palettize_pixmap(regionH);
	    	regionP = (struct saved_region FAR *)GetPtr(regionH);
	    	palDatH = regionP->palDataH;
	    	ReleasePtr(regionH);
    	}
    	if (palDatH) {
	    	nativePalP = (struct CTcolorentry FAR *)GetPtr(nativePalH);
	    	for(pii=0; pii<256; pii++) {
				if ((nativePalP+pii)->isSet)
		    		nColorsUsed++;
	    	} /* for */
	    	ReleasePtr(nativePalH);
    	} /* pixpalH if */
    } /* nativePalH if */
    
/* since image is actually palettized to a 256 color palette */
/* we must pass on a 256 color palette even if the image doesn't */
/* really need that many colors - fix palettize? */

if (nColorsUsed)
	nColorsUsed = 256;
	
    if (!nColorsUsed) { /* don't have a usefull palette */
		palDatH = HNULL;
    }
	
    /* start new line, & do header */
    WriteEscape(fInd,NEWLINE);
    sprintf(tempS,"@4STXT%s",NEWLINES);
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%d%s",PIXMAPSPECIAL,NEWLINES); /* indicate what kind of special char */
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%d%s",PIXMAPVERS2,NEWLINES); /* bitmap stream version */
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%ld%s",width,NEWLINES);
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%ld%s",height,NEWLINES);
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%d%s",nColorsUsed,NEWLINES); /* colors in palette */
    WriteLiteral(fInd,tempS);
  
    if (palDatH) {
    
    	/* make a reordered copy of palette */
    	
    	nativePalP = (struct CTcolorentry FAR *)GetPtr(nativePalH);
    	copyPalP = (struct CTcolorentry FAR *)GetPtr(copyPalH);
    	for(pii=0; pii<256; pii++) {
    		pjj = (nativePalP+pii)->realV;
    		if (pjj < 0) pjj = pii;
    		*(copyPalP+pjj) = *(nativePalP+pii);
    	}
    	ReleasePtr(nativePalH);
    	
        /* write out color palette */
        
    	for(pii=0; pii<256; pii++) { /* always write 256 - see above */
			rr = (copyPalP+pii)->red;
			gg = (copyPalP+pii)->green;
			bb = (copyPalP+pii)->blue;
			tempS[0] = pii;
			tempS[1] = rr >> 8;
			tempS[2] = rr;
			tempS[3] = gg >> 8;
			tempS[4] = gg;
			tempS[5] = bb >> 8;
			tempS[6] = bb;
			tempL = TUTORwrite((char FAR *)tempS,1,7L,fInd);
			if (tempL != 7)
		    	TxtMemErr++;  
		} /* pii for */
       	ReleasePtr(copyPalH);
   	
		/* write palettized pixels */
       
    	palDatP = (unsigned char FAR *)GetPtr(palDatH); 
		tempL = TUTORwrite((char FAR *)palDatP,1,width*height,fInd);
		ReleasePtr(palDatH);
    	if (tempL != (width*height))
	    	TxtMemErr++;
    } /* palPixH if */
    
    if (copyPalH)
    	TUTORfree_palette(copyPalH);
   	
    /* copy pixmap to buffer, one pixel (red,green,blue) at a time */
    
    bytesRow = rgbpixP->rowBytes & 0x3fff;   
    rowBaseP = ((unsigned char FAR *)rgbpixP)+((long)rgbpixP->baseAddr); /* rel to absolute */
    outP = buffP; /* pointer in output buffer */
    for(rowI=0; rowI<height; rowI++) {
        pixelP = rowBaseP;
        for(pixelI=0; pixelI<width; pixelI++) {
	    *outP++ = *(pixelP+1);
	    *outP++ = *(pixelP+2);
	    *outP++ = *(pixelP+3);
	    pixelP += 4;
        }
        rowBaseP += bytesRow; /* advance to next row */
    } /* rowI for */
    
    /* write rgb pixels */
    
    tempL = TUTORwrite((char FAR *)buffP,1,buffSize,fInd);
    if (tempL != buffSize)
       	TxtMemErr++;
    ReleasePtr(buffH);
    TUTORfree_handle(buffH); /* dump temporary storage */
    
    /* write trailer */
    
    WriteLiteral(fInd,NEWLINES);
    sprintf(tempS,"@5STXT%s",NEWLINES);
    WriteLiteral(fInd,tempS);
    
    ReleasePtr(rgbpixH);
    
    return(0);
    
} /* TUTORfwrite_pixmap */

#endif /* MAC */

/* ******************************************************************* */

#ifdef WINPC

static TUTORfwrite_pixmap(fInd,st1p) /* write pixmap character */
int fInd; /* index of TUTORfile */
SText FAR *st1p;   /* pointer to special character block of bitmap char */
    
{   Memh headerH; /* handle on pixmap header */
    struct saved_region FAR *headerP; /* pointer to header */
    Memh dibH; /* handle on windows DIB */
    LPBITMAPINFOHEADER bInfoP; /* ptr to DIB bitmap description */
    LPRGBQUAD bColorP; /* pointer to dib's color table */
    LPRGBQUAD rgbP; /* pointer in dib's color table */
    long sizeColor; /* size of dib color table */
    long width,height; /* width,height of pixmap */
    long bytesRow; /* bytes per row */
    int bitsPixel; /* bits per pixel */
    long rowI; /* index of current row */
    long pixelI; /* index of current pixel */
    unsigned char SHUGE *pixBaseP; /* base of pixels */
    unsigned char SHUGE *rowBaseP; /* pointer to base of row */
    unsigned char SHUGE *pixelP; /* pointer to current pixel */
    unsigned char FAR *palDatP; /* pointer to palettized pixel data */
    long buffSize; /* size of temporary buffer */
    Memh buffH; /* handle on temporary buffer */
    unsigned char SHUGE *buffP; /* pointer in temporary buffer */
    int pixelV; /* current pixel value */
    Memh nativePalH; /* handle on image palette */
    struct CTcolorentry FAR *nativePalP; /* pointer to image palette */
    Memh copyPalH; /* reordered copy of image palette */
    struct CTcolorentry FAR *copyPalP; /* pointer in image palette */
    Memh palDatH; /* handle on palettized data */
    int nColorsUsed; /* colors used in native palette */
    char SHUGE *ccP;
    unsigned char SHUGE *outP; /* pointer in output line */
    char tempS[70]; /* buffer for assembling output */
    long tempL;
    int pii,pjj; /* index in palette */
    unsigned int rr,gg,bb; /* red, green, blue components */
    int nybble;

    nativePalH = copyPalH = palDatH = HNULL;
    nColorsUsed = 0;
    headerH = st1p->dat; /* pick up header handle */
    win_palettize_region((long)headerH); /* get palettized form if possible */

    headerP = (struct saved_region FAR *)GetPtr(headerH);
    width = headerP->width;
    height = headerP->height;
    palDatH = headerP->palDataH;
    nativePalH = headerP->nativePal;
    dibH = headerP->rgbdibH; /* try for rgb version */
    if (!dibH)
	dibH = headerP->paldibH; /* fall back on palettized version */
    buffSize = width*height*3L; /* size required for rgb pixels */
    buffH = TUTORhandle("tmp",buffSize,FALSE);
    if (!buffH) {
       	TxtMemErr++; 
	ReleasePtr(dibH);
	ReleasePtr(headerH);
    	return(0); /* no go */
    }

    /* see if have palettized form of image */
    /* the palettized form is difficult to derive from the rgb form */
    /* if we have a palettized image, we want to preserve it */
    
    nColorsUsed = 0;
    if (nativePalH) {
	copyPalH = TUTORalloc_palette(256); /* for reordered copy */
	if (!copyPalH)
	    nativePalH = HNULL;
    }
    if (nativePalH) {
    	if (palDatH) {
	    nativePalP = (struct CTcolorentry FAR *)GetPtr(nativePalH);
	    for(pii=0; pii<256; pii++) {
		if ((nativePalP+pii)->isSet)
		    nColorsUsed++;
	    }
	    ReleasePtr(nativePalH);
    	} /* pixpalH if */
    } /* nativePalH if */

    if (nColorsUsed)
	nColorsUsed = 256;
    if (!nColorsUsed) { /* don't have a usefull palette */
	palDatH = HNULL;
    }

    /* start new line, & do header */

    WriteEscape(fInd,NEWLINE);
    sprintf(tempS,"@4STXT%s",NEWLINES);
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%d%s",PIXMAPSPECIAL,NEWLINES); /* indicate what kind of special char */
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%d%s",PIXMAPVERS2,NEWLINES); /* bitmap stream version */
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%ld%s",width,NEWLINES);
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%ld%s",height,NEWLINES);
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%d%s",nColorsUsed,NEWLINES); /* colors in native palette */
    WriteLiteral(fInd,tempS);

    if (palDatH) {
    
    	/* make a reordered copy of palette */
    	
    	nativePalP = (struct CTcolorentry FAR *)GetPtr(nativePalH);
    	copyPalP = (struct CTcolorentry FAR *)GetPtr(copyPalH);
    	for(pii=0; pii<256; pii++) {
	    pjj = (nativePalP+pii)->realV;
	    if (pjj < 0) pjj = pii;
	    *(copyPalP+pjj) = *(nativePalP+pii);
	    (copyPalP+pjj)->realV = pjj;
    	}
    	ReleasePtr(nativePalH);
    
        /* write out color palette */
        
    	for(pii=0; pii<256; pii++) {
	    rr = (copyPalP+pii)->red;
	    gg = (copyPalP+pii)->green;
	    bb = (copyPalP+pii)->blue;
	    tempS[0] = pii;
	    tempS[1] = rr >> 8;
	    tempS[2] = rr;
	    tempS[3] = gg >> 8;
	    tempS[4] = gg;
	    tempS[5] = bb >> 8;
	    tempS[6] = bb;
	    tempL = TUTORwrite((char FAR *)tempS,1,7L,fInd);
	    if (tempL != 7)
		TxtMemErr++;
	} /* pii for */
	ReleasePtr(copyPalH);
   	
	/* write palettized pixels */
       
      	palDatP = (unsigned char FAR *)GetPtr(palDatH); 
	tempL = TUTORwrite((char FAR *)palDatP,1,width*height,fInd);
	ReleasePtr(palDatH);
    	if (tempL != (width*height))
	    TxtMemErr++;
    } /* palPixH if */
    if (copyPalH)
	TUTORfree_handle(copyPalH);

    /* get size of color table and size of pixel from DIB */

    ccP = GetPtr(dibH);
    bInfoP = (LPBITMAPINFOHEADER)(ccP+sizeof(BITMAPFILEHEADER));
    bColorP = (LPRGBQUAD)(ccP+sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER));

    sizeColor = bInfoP->biClrUsed;
    bitsPixel = bInfoP->biBitCount;
    switch (bitsPixel) {
	case 1:
	    if (!sizeColor) sizeColor = 2;
	    bytesRow = (((width >> 3)+3L) >> 2) << 2;
	    break;
	case 4:
	    if (!sizeColor) sizeColor = 16;
	    bytesRow = (((width >> 1)+3L) >> 2) << 2;
	    break;
	case 8:
	    if (!sizeColor) sizeColor = 256;
	    bytesRow = ((width+3L) >> 2) << 2;
	    break;
	default:
	    bytesRow = (((width*3L)+3L) >> 2) << 2;
	    break;
    } /* switch */
    sizeColor *= sizeof(RGBQUAD); /* size of color table in bytes */
    pixBaseP = ((unsigned char SHUGE *)bColorP)+sizeColor;

    /* copy to output buffer, one pixel (red,green,blue) at a time */
    
    rowBaseP = pixBaseP; /* start at base of pixels */
    buffP = (unsigned char FAR *)GetPtr(buffH);
    outP = buffP; /* pointer in output buffer */
    for(rowI=height-1; rowI>=0; rowI--) {
	pixelP = rowBaseP+(rowI*bytesRow);
	nybble = 0;
	for(pixelI=0; pixelI<width; pixelI++) {
	    if (bitsPixel == 24) {
		*(outP+2) = *pixelP++;
		*(outP+1) = *pixelP++;
		*outP = *pixelP++;
		outP += 3;
	    } else {
		if (bitsPixel == 8) {
		    pixelV = *pixelP++; /* pick up next pixel value */
		} else if (bitsPixel == 4) {
		    if (!nybble) {
			pixelV = (*pixelP >> 4) & 0xf;
			nybble = 1;
		    } else {
			pixelV = (*pixelP++) & 0xf;
			nybble = 0;
		    }
		} else {
		    pixelV = (*pixelP >> (7-nybble)) & 1;
		    nybble++;
		    if (nybble == 8) {
			nybble = 0;
			pixelP++;
		    }
		}
		*outP++ = bColorP[pixelV].rgbRed;
		*outP++ = bColorP[pixelV].rgbGreen;
		*outP++ = bColorP[pixelV].rgbBlue;
	    } /* bitsPixel else */
	} /* pixelI for */
    } /* rowI for */

    /* write pixels */
    
    tempL = TUTORwrite((char FAR *)buffP,1,buffSize,fInd);
    if (tempL != buffSize)
       	TxtMemErr++;
    ReleasePtr(buffH);
    TUTORfree_handle(buffH); /* dump temporary storage */
    
    /* write trailer */
    
    WriteLiteral(fInd,NEWLINES);
    sprintf(tempS,"@5STXT%s",NEWLINES);
    WriteLiteral(fInd,tempS);

    ReleasePtr(dibH);
    ReleasePtr(headerH);
    
    return(0);

} /* TUTORfwrite_pixmap */

#endif

/* ******************************************************************* */

#ifdef X11

static TUTORfwrite_pixmap(fInd,st1p) /* write pixmap character */
register int fInd; /* index of TUTORfile */
register SText FAR *st1p;   /* pointer to special character block of bitmap char */
    
{   Memh headerH; /* handle on pixmap header */
	struct saved_region FAR *headerP; /* pointer to pixmap header */
	Memh paletteH; /* handle on picture palette */
	struct CTcolorentry FAR *paletteP; /* pointer to picture palette */
	Memh imDataH; /* handle on (cT format) image data */
	unsigned char FAR *imDataP; /* pointer to image data */
	long width,height; /* width,height of pixmap */
    long rowI; /* index of current row */
    long pixelI; /* index of current pixel */
    unsigned char FAR *pixelP; /* pointer to current pixel */
	long pixelV; /* value of current pixel */
	unsigned long rr,gg,bb; /* pixel components */
	long buffSize; /* size of temporary buffer */
	Memh buffH; /* handle on temporary buffer */
	char FAR *buffP; /* pointer to temporary buffer */
	long tempL;
    char FAR *outP; /* pointer in output buff */
    char tempS[70]; /* buffer for assembling output */
    
	headerH = st1p->dat; /* handle on image header */
    headerP = (struct saved_region FAR *) GetPtr(headerH);
	paletteH = headerP->nativePal; /* handle on image palette */
	paletteP = (struct CTcolorentry FAR *)GetPtr(paletteH);
	imDataH = headerP->palDataH; /* handle on pixels */
	imDataP = (unsigned char FAR *)GetPtr(imDataH);
    width = headerP->width;
    height = headerP->height;
    
	buffSize = width*height*3L; /* size of temporary buffer */
	buffH = TUTORhandle("tmp",buffSize,FALSE);
	if (!buffH) {
		TxtMemErr++;
		ReleasePtr(headerH);
		ReleasePtr(paletteH);
		ReleasePtr(imDataH);
		return(0);
	}
	
    /* start new line, & do header */
    WriteEscape(fInd,NEWLINE);
    sprintf(tempS,"@4STXT%s",NEWLINES);
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%d%s",PIXMAPSPECIAL,NEWLINES); /* indicate what kind of special char */
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%d%s",PIXMAPVERS2,NEWLINES); /* bitmap stream version */
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%ld%s",width,NEWLINES);
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%ld%s",height,NEWLINES);
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%d%s",0,NEWLINES); /* unused */
    WriteLiteral(fInd,tempS);
    
    /* output pixmap, one pixel (red,green,blue) at a time */
    
    outP = buffP = GetPtr(buffH); /* pointer in output buffer */
	pixelP = imDataP; /* pointer to pixel values */
    for(rowI=0; rowI<height; rowI++) {
        for(pixelI=0; pixelI<width; pixelI++) {
			pixelV = *pixelP++; /* get next pixel value */
			rr = (paletteP+pixelV)->red >> 8;
			gg = (paletteP+pixelV)->green >> 8;
			bb = (paletteP+pixelV)->blue >> 8;
            *outP++ = rr;
            *outP++ = gg;
            *outP++ = bb;
        }
    } /* rowI for */

	tempL = TUTORwrite(buffP,1,buffSize,fInd);
 	ReleasePtr(buffH);
	TUTORfree_handle(buffH);
	
    WriteLiteral(fInd,NEWLINES);
    sprintf(tempS,"@5STXT%s",NEWLINES);
    WriteLiteral(fInd,tempS);
    
	ReleasePtr(imDataH);
	ReleasePtr(paletteH);
    ReleasePtr(headerH);
    
    return(0);
    
} /* TUTORfwrite_pixmap */

#endif /* X11 */

/* ******************************************************************* */

static TUTORfwrite_icons(fInd,st1p) /* write icons */
int fInd; /* index of TUTORfile */
SText FAR *st1p; /* pointer to special character header */
    
{   char tempS[70]; /* buffer for assembling output */
    char numstr[20]; /* string for next numeric value */
    Memh iconDatH; /* handle on icon data */
    int FAR *iconDatP; /* pointer to icon data */
    int nIcons; /* number icons to write */
    int iconI; /* index of icon */
    int iconN; /* current icon number */
    int nThisLine; /* number icons on this line */
    
    iconDatH = st1p->dat;
    iconDatP = (int FAR *)GetPtr(iconDatH);

    /* start new line, & do header */
    WriteEscape(fInd,NEWLINE);
    sprintf(tempS,"@4STXT%s",NEWLINES);
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%d%s",ICONSPECIAL,NEWLINES); /* indicate what kind of special char */
    WriteLiteral(fInd,tempS);
    sprintf(tempS,"%d%s",BITMAPVERS1,NEWLINES); /* use bitmap stream version */
    WriteLiteral(fInd,tempS);
    
    nIcons = *iconDatP++; /* get number icons */
    sprintf(tempS,"%d",nIcons); /* convert count to alpha */
    strcat(tempS,NEWLINES); /* append terminating newline */
    WriteLiteral(fInd,tempS); /* write icon count to file */
    
    nThisLine = tempS[0] = 0;
    for(iconI=0; iconI < nIcons; iconI++) {
        iconN = *iconDatP++; /* pick up next icon number */
        sprintf(numstr,"%d ",iconN); /* convert number to string */
        strcat(tempS,numstr); /* add to line building */
        nThisLine++; 
        if (nThisLine == 8) { /* limit to 8 icon numbers per line */
            strcat(tempS,NEWLINES); /* append terminating newline */
            WriteLiteral(fInd,tempS); /* write icon numbers to file */
            nThisLine = tempS[0] = 0;
        } /* nThisLine if */
    } /* for */
    
    if (nThisLine) { /* something left to write */
        strcat(tempS,NEWLINES); /* append terminating newline */
        WriteLiteral(fInd,tempS); /* write icon numbers to file */
    }
    
    iconDatP++; /* advance past font family id */
    strcpyf((char FAR *)tempS,(char FAR *)iconDatP); /* get family name */
    strcat(tempS,NEWLINES); /* append terminating newline */
    WriteLiteral(fInd,tempS); /* write family name to file */
    
    ReleasePtr(iconDatH);
    sprintf(tempS,"@5STXT%s",NEWLINES); /* write trailer */
    WriteLiteral(fInd,tempS);
    
    return(0);
    
} /* TUTORfwrite_icons */

/* ******************************************************************* */

WriteHottext(ff,hlist)  /* write out hottext structure for document */
int ff; /* file index */
Memh hlist; /* the hotlist */
    {
    char tempS[70]; /* buffer for assembling output */
    HotList FAR *hlp;   /* pointer to hottext structure */
    HotL1 FAR *hp;      /* pointer to individual hot text blocks */
    long totLen;        /* total length of hot text info strings */
    unsigned char FAR *t0;  /* pointer to hottext info string pool */
    short curStyles[NSTYLES];   /* dummy styles */
    int ii; 
    
    hlp = (HotList FAR *) GetPtr(hlist);
    
    /* start new line, & do header */
    WriteEscape(ff,NEWLINE);
    sprintf(tempS,"@4HOTT%s",NEWLINES);
    WriteLiteral(ff,tempS);
    sprintf(tempS,"%ld%s",hlp->listhead.dAnn,NEWLINES);
    WriteLiteral(ff,tempS);
    
    /* for every item output length */
    totLen = 0;
    hp = (HotL1 FAR *) hlp->list;
    for (ii=0; ii<hlp->listhead.dAnn; ii++, hp++)
        {
        sprintf(tempS,"%d%s",hp->len,NEWLINES);
        totLen += hp->len;
        WriteLiteral(ff,tempS);
        }
    
    /* now output all the text as a cT datastream */
    for (ii=0; ii<NSTYLES; ii++)
        curStyles[ii] = DEFSTYLE; /* so we don't get any style header */
    WriteHeader(ff,curStyles,FARNULL,FARNULL,0L);
    t0 = (unsigned char FAR *) ((char FAR *) hlp + hlp->offsets[1] + sizeof(DArrayHeader));
    WriteText(ff,t0,totLen);
    WriteTrailer(ff);
    
    ReleasePtr(hlist);
    KillPtr(hlp);
    
    /* finish up */
    WriteEscape(ff,NEWLINE);
    sprintf(tempS,"@5HOTT%s",NEWLINES);
    WriteLiteral(ff,tempS);
    
    return(0);
    }

static WriteLiteral(ff,ss)  /* low level datastream output routine */
int ff;     /* TUTOR file index */
char *ss;   /* literal (don't escape \, etc) */
            /* ss can have a newline in it, but only as the last character */
    {
    register long sLen; /* length of ss */
    register long wLen; /* # of chars written to file */
    int haveNewl;   /* TRUE if ss ends in newline */
    
    sLen = strlen(ss);
    haveNewl = (ss[sLen-1] == NEWLINE);
    
    if (nUsed + sLen > MAXLINEC)
        { /* this string will take us over the line limit.  Put in an escaped newline */
        WriteEscape(ff,NEWLINE);
    nUsed = 0;
        }
    wLen = TUTORwrite((char FAR *) ss,1,sLen-haveNewl,ff);
    nUsed += wLen;
    if (wLen != sLen-haveNewl)
        ioErrV = TRUE;
    
    if (haveNewl)
        WriteText(ff,(unsigned char FAR *) NEWLINES,1L);
    
    return(0);
    }

static WriteEscape(ff,cc)   /* write an escaped character */
int ff;     /* TUTOR file index */
int cc;     /* the character we want to write escaped */
    {
    char ss[3];
    register long sLen; /* # of chars we want to write */
    register long wLen; /* # of chars we wrote */
    
    ss[0] = '@';
#ifdef IBMPC
    if (cc == NEWLINE)
        {
        ss[1] = 0xd;    /* CR */
        ss[2] = 0xa;    /* LF */
        sLen = 3;
        }
    else
        {
        ss[1] = cc;
        sLen = 2;
        }
#else
    ss[1] = cc;
    sLen = 2;
#endif
    wLen = TUTORwrite((char FAR *) ss,1,sLen,ff);
    if (wLen < sLen)
        ioErrV = TRUE;
    
    return(0);
    }


/* ******************************************************************* */

/* for backwards compatibiltiy, font references in datastream must */
/* fit within 3 hex digits.  This routine managles font id's to achieve */
/* this */

static int FontDat3(dat) /* convert font family data */
int dat; /* family id to convert */

{
    if (dat == DEFSTYLE)
	return(dat); /* don't mangle DEFSTYLE */

    if ((long)dat & 0x0f000L) {
	dat = dat+((dat >> 4) & 0xfff);
    }
    dat &= 0xfff;
    if (dat == 0) dat = 0x2af; /* don't alow zero, pick something */
    return(dat);

} /* FontDat3 */

/* ******************************************************************* */
