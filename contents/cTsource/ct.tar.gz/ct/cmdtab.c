
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>

#ifdef MAC
#include <Menus.h>
#include <fonts.h>
#include <quickdraw.h>
#endif

#include "ctutor.h"
#include "exprdefs.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "ct_ctype.h"
#include "ctstring.h"
#include "exprdefs.h"
#include "yacc.h"
#include "cmdtab.h"

/* ******************************************************************* */

#ifdef ctproto
int WriteTables(char *fn);
#endif /* ctproto */

/* ******************************************************************* */

void main(void);

void main()

{   FILE *table;
    int wl;
    int tableL; /* size of table */
    char *tableP; /* pointer to table */
    char *msgP; /* pointer to message string */
    int nStr; /* number of strings */
    int cii;

    /* figure out total length of error message strings */

    nStr = sizeof(comperr)/sizeof(char *);
    tableL = 0;
    for(cii=0; cii<nStr; cii++) {
		tableL += strlen(comperr[cii])+1;
    }

    /* assemble message strings */

    tableP = malloc((size_t)tableL);
    if (!tableP) {
        printf("Not enough memory\n");
        exit(1);
    }
    TUTORzero(tableP,tableL);

    msgP = tableP; /* pointer in message strings */
    for(cii=0; cii<nStr; cii++) {
        strcpy(msgP,comperr[cii]);
        msgP += strlen(comperr[cii])+1;
    }

    /* write messages to file */
	
    table = fopen("messages.tab","wb");
    if (!table) {
		printf("can't create file messages.tab\n");
		exit(1); 
    }
    wl = fwrite(tableP,1,tableL,table); /* write file */
    fclose(table);

    /* write command data to file */
	
    table = fopen("commands.tab","wb");
    if (!table) {
		printf("can't create file commands.tab\n");
	/*	exit(1); */
		return;
    }
    tableL = sizeof(cmdtable);
    wl = fwrite(cmdtable,1,tableL,table); /* write next chunk */
    fclose(table);

    /* write functions data to file */
	
    table = fopen("function.tab","wb");
    if (!table) {
        printf("can't create file function.tab\n");
        return;
    }
    tableL = sizeof(zfcttab);
    wl = fwrite(zfcttab,1,tableL,table); /* write next chunk */
    fclose(table);
    
    /* add command + function data to resource forks */
 
#ifdef MAC
#ifdef __MC68K__ 
    WriteTables("ctauthor.68k.�.rsrc");
    WriteTables("ctexec.68k.�.rsrc");
#else
    WriteTables("ctauthor.ppc.�.rsrc");
    WriteTables("ctexec.ppc.�.rsrc"); 
#endif
#endif
 	return;
 	
} /* main */

/* ******************************************************************* */

#ifdef MAC

int WriteTables(fileName)
char *fileName;

{	Str255 resFileN;
	int vRefNum; /* reference number for resource fork */
	Handle resH; /* handle on CTcm or CTfn resource */
	long len; /* length of resource data */
	int cii; /* index in resource data */
	char *resP; /* pointer in resource data */
	char *dataP; /* pointer in original data */
	
	
	strcpy((char *)&resFileN[0],fileName);
	CtoPstr((char *)&resFileN[0]);
	vRefNum = OpenResFile(resFileN);
	if (vRefNum == -1)
		return(2); /* failed */
		
	/* add commands resource */
	
	resH = GetResource('CTcm',128);
	if (resH) {
		RemoveResource(resH);
		DisposeHandle(resH);
		len = sizeof(cmdtable);
		resH = NewHandle(len);
		HLock(resH);
		resP = (char *)*resH;
		dataP = (char *)cmdtable;
		for(cii=0; cii<len; cii++) 
			*resP++ = *dataP++;
		HUnlock(resH);
		AddResource(resH,'CTcm',128,"\pCommands");
	}
	
	/* add functions resource */
		
	resH = GetResource('CTfn',128);
	if (resH) {
		RemoveResource(resH);
		DisposeHandle(resH);
		len = sizeof(zfcttab);
		resH = NewHandle(len);
		HLock(resH);
		resP = (char *)*resH;
		dataP = (char *)zfcttab;
		for(cii=0; cii<len; cii++) 
			*resP++ = *dataP++;
		HUnlock(resH);
		AddResource(resH,'CTfn',128,"\pFunctions");
	}
	CloseResFile(vRefNum);
	return(0);
	
} /* WriteTables */

#endif

/* ******************************************************************* */

TUTORzero(ptr,len) /* zero block of memory */
register char FAR *ptr; /* address of block */
register long len; /* length of block */

{   char SHUGE *ptrH; /* huge pointer so arithmetic correct */

    if (len <= 0)
        return(0); /* nothing to do */
    ptrH = ptr;
    while(len-- > 0)
	*ptrH++ = 0;
    return(0);
		
} /* TUTORzero */

/* ******************************************************************* */

