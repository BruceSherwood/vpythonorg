
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#ifndef _tfiledefh
#define _tfiledefh

#include <stdio.h>

/*
The loc field provides a check that an author file pointer is valid.
This makes it possible to avoid having to initialize author file
pointers before execution, and it makes it easy to close local files,
by searching for loc >= lvars at the end of a subroutine.  It also
facilitates closing global files at the end of execution in author mode.
*/

struct tutorfile { /* information about open files */
    FileRef fRef;
    FILE *fp; /* file pointer */
    int stream; /* stream # (for socket or Mac serial port use) */
    int streamID; /* id # of stream (for socket use) */
    char FAR *buffer; /* char buffer for use by sockets on unix */
    long bPos; /* read position in buffer or document */
    int bEnd; /* end of valid chars in buffer (after buffer[bEnd-1] buffer is invalid) */
    char inuse; /* TRUE if file table slot in use */
    char kind; /* 0 = normal file */
               /* 1 = serial port */
               /* 2 = socket (Mac AppleTalk) */
               /* 3 = WM winout */
               /* 4 = PC EMS */
               /* 5 = PC XMS */
               /* 6 = socket (Mac Program-to-Program) */
    char ro; /* TRUE if read-only */
    char lastop; /* type of last operation */
    char dounget; /* TRUE if dangling ungetc */
    char styles_allowed; /* TRUE if may be read as styled */
    char format; /* -1 = unknown, 0 = native, 1 = cT, 2 = BE-II */
    char crKind; /* -1 = unknown,  0 = 0x0a, 1 = 0x0d, 2 = 0x0d,0x0a */
    char fileOpen; /* TRUE if file is open and ready for i/o */
    char lastC; /* last character (mac/pc serial) */
    long vloc; /* location of author file pointer variable */
#ifdef MAC
	short refNumO; /* serial output driver reference number */
	short refNumI; /* serial input driver reference number */
#endif
}; /* tfiletype */

#define fop_open 0  /* open file */
#define fop_begin 1 /* reset to begin of file */
#define fop_end 2   /* reset to end of file */
#define fop_empty 3 /* reset to empty file */
#define fop_read 4  /* read from file */
#define fop_write 5 /* wite to file */
#define fop_server 6    /* made this file a server */
#define fop_new 7   /* created new file */
#define fop_wait 8  /* blocked on this file */

#endif  /* _tfiledefh */
