
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <sys/param.h>
#include "baseenv.h"

#ifdef SYSV
#include <limits.h>
#ifndef hp700
#ifndef PATH_MAX
#define PATH_MAX 1024
#endif
#define MAXPATHLEN PATH_MAX
#endif
#endif

#include <pwd.h>

#ifndef NULL
#define NULL 0L
#endif

#ifdef ctproto
extern  char *FullName(char *path,char *basefile);
/* getwd(); */
/* index() */
/* rindex() */
extern char *strcat(char *aa, char *bb);
extern char *strcpy(char *aa, char *bb);
extern int strlen(char *str);
extern int strncmp(char *aa, char *bb, int nn);
extern char *strncpy(char *aa, char *bb, int nn);
#endif /* ctproto */

extern char *strcat();
extern char *strcpy();
extern int strlen();
extern int strncmp();
extern char *strncpy();
extern char *index_z();
extern char *rindex_z();
extern char *getwd();

/* FullName (path, basefile) computes the full path name of path and 
	returns a pointer to static storage containing the path.  If path  
	begins with /, the name is just folded to remove extraneous  
	dots.  If the path begins with ~, the appropriate home directory  
	is used.  If the name begins otherwise, it is made relative to  
	the directory containing basefile.    
	Basefile should be a full pathname.  If empty, or begins without a slash,
	the pathname is made relative to the current working directory. 
*/

char *FullName (path, basefile) register char *path, *basefile; 
{
    static char buf[MAXPATHLEN];
	int wii; char *cpF; char *cpT; int cpL;

    if (*path == '/')
		strcpy (buf, path);
    else if (*path == '~') {
		register struct passwd *pwent; 
		register char *tail;
		register char *p1;

		pwent = NULL;
		p1 = path+1;
		if (*p1=='\0') {
	    	pwent = getpwuid(geteuid());
	    	tail = p1;
		} else if (*p1=='/') {
	    	pwent = getpwuid(geteuid());
	    	tail = path+2;
		} else {  /* ~name/...  */
	    	tail = index_z(path, '/');
	    	if (tail==0) {
					pwent = getpwnam (p1);
				tail = "";
	    	} else {
				*tail = '\0';
				pwent = getpwnam (p1);
				*tail++ = '/';
	    	}
		}
		if (pwent==NULL) 
	    	buf[0] = '\0';
		else
	    	strcpy(buf, pwent->pw_dir);
		wii = strlen(buf);
		if (wii && (buf[wii-1] != '/'))
			strcat(buf, "/");
		strcat(buf, tail);
    } else {   /* find name relative to directory for basefile */
		register char *slash;
		if (basefile==NULL) basefile = "";
		if ((getwd(buf) != NULL) && (*basefile != '/')) {
			wii = strlen(buf);
			if ((wii == 0) || (buf[wii-1] != '/'))
	    		strcat (buf, "/");
		} else 
	    	*buf = '\0';    /* ??? discard error message if getwd==NULL */
		strcat (buf, basefile);
		slash = rindex_z(buf, '/');
		if (slash==0) {
	    	slash = buf+strlen(buf); 
			*slash = '/';
		}
		*++slash = '\0';
		strcat(buf, path);
    }
#ifndef SYSV
    be_FoldName(buf);
#endif
	cpF = buf;
	cpT = buf;
	cpL = 0;
	while (*cpF) { /* eliminate // */
		if ((*cpF == '/') && (cpL == '/')) {
			cpF++;
		} else {
			cpL = *cpT++ = *cpF++;
		}
	}
	*cpT = *cpF;

    return buf;
}


be_FoldName (path)
    register char *path;			/* path to fold */
{
    char   *pStart,		/* points to first char of a component */
	   *pEnd;		/* points to first char following
				   component */
    register char *dest;
    int     len;

    if (path == NULL)
	return;
    dest = path;
    pEnd = (*path == '/' ? path + 1 : path);
    for (;;) {
		pStart = pEnd;
		pEnd = index_z(pStart, '/');
		if (pEnd == NULL)
	    	pEnd = pStart + strlen (pStart);
		len = pEnd - pStart;
	if (len == 0) {}		/* ignore empty components */
	else if (len == 1 && strncmp (pStart, ".", 1) == 0)
	    {}   /* ignore single dots */
	else if (len == 2 && strncmp (pStart, "..", 2) == 0) {
	    switch (dest - path) {
	    case 0: /*  /.. => /   and   .. => .. */
		    if (*path != '/')  
			*dest++ = '.', *dest++ = '.';
		    break;
	    case 1: /*  ./.. => ..   and   x/.. => . */
		    if (*path == '.') 
			*dest++ = '.';
		    else *path = '.';
		    break;
	    case 2: /*  ../.. => ../..   and   x/.. => .  */
		    if (strncmp(path, "..", 2)==0)
			*dest++ = '/', *dest++ = '.', *dest++ = '.';
		    else *path = '.', dest = path+1;
		    break;
	    default: /*  y/x/..=>y   x/..=>.  /x/..=>/   ../../..=>../../..  */
		    if (strncmp(dest-3, "/..", 3)==0)
			*dest++ = '/', *dest++ = '.', *dest++ = '.';
		    else {  /* this is the principal case for .. */
			while (dest > path && *--dest != '/') {}
			if (dest == path && *path != '/')
			    *dest++ = '.';
		    }
		    break;
	    }
	}
	else {
	    if (dest>path || *path == '/') 
		*dest++ = '/';
	    strncpy (dest, pStart, len);
	    dest += len;
	}
	if (*pEnd++ == 0)
	    break;
    }
    if (dest==path)   /* inital path was  /  .  or empty */
	*dest++ = (*path == '/' ? '/' : '.');
    *dest++ = 0;
}

char *index_z(str,object) /* return first instance of character */
char *str;
int object;

{
    while (*str && (*str != object)) 
        str++;
    if (*str == object)
        return(str);
    return(NULL);

} /* index_z */

char *rindex_z(str,object) /* return last instance of character */
char *str;
int object;

{   char *pstr;
    int len;

    len = strlen(str);
    if (len <= 0)
		return(NULL);
    pstr = str+len-1;
    do {
        if (*pstr == object)
            return(pstr);
        pstr--;
    } while (pstr >= str);
    return(NULL);

} /* rindex_z */


		 
