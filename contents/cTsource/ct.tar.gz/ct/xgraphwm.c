
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/


/* TUTORgraphics package, executor subroutines  */

#include <stdio.h>
#include <signal.h>

#include "baseenv.h"

#ifndef SYSV
#include <sys/types.h>
#else
#define sys_typesh
#endif
#include <sys/time.h>

#ifdef SYSV
#include "wmx11.h"
#else
#ifdef WM
#include "wmclient.h"
#endif
#endif

#include <X11/Xatom.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <X11/cursorfont.h>

#include "kglobals.h"
#include "tglobals.h"
#include "ecglobal.h"

#ifdef ctproto
extern int  FillTrapezoid(int  x1,int  y1,int  dx1,int  x2,int  y2,int  dx2);
int  TUTORabs_fill_polygon(int  npoints,long  *fx,long  *fy);
extern void  PCfill_polygon(int  npoints,long  *xa,long  *ya);
extern struct  poly_edge *merge_sort(struct  poly_edge *list);
extern struct  poly_edge *merge_lists(struct  poly_edge *list1,struct  poly_edge *list2);
int  TUTORabs_fill_disk(int type,long xc,long yc,struct  _trect *rp,int  pFont,int  pChar);
int  displayffv(int  x,int  y,int  op,int  format,double  value);
long  AbsCoord(long  xx);
double  CoordToFloat(long  xx);
long  DivCoord(long  xx,long  yy);
extern int FillModeOff();
extern int FillModeOn();
long  FloatToCoord(double  zz);
long  IntToCoord(int  xx);
extern long MulCoord(long xx,long yy);
int  RoundCoord(long  xx);
long  TUTORinq_font_ptr(int  fontN);
int  TUTORset_comb_rule(int  rule);
/* XFillArc() */
/* XFillPolygon() */
extern double cos(double x);
extern double floor(double x);
extern double sin(double x);
extern double sqrt(double x);
extern int wxcp(int font);
#endif /* ctproto */

struct poly_edge {
	short y;	/* ymax */
	Coord x, rslope;
	char localMax;	/* TRUE if this edge's ymax is local maximum */
	struct poly_edge *next;
};

struct trap_edge {
	short x, length;
};

static struct poly_edge *merge_sort();
static struct poly_edge *merge_lists();

extern char *malloc();
extern char *realloc();
extern Coord AbsCoord();
extern long TUTORinq_font_ptr();

extern int pd_barheight; /* pull-down menu bar height */

extern Window wf[WINDOWLIMIT];
extern Display *display;
extern int screen;
extern Cursor cursor;
extern XGCValues gcv;
extern GC gc;
extern Colormap colormap0;
extern Drawable drawwindow;  /* the window to draw into */

/* *********************************************************** */

static FillTrapezoid(x1, y1, dx1, x2, y2, dx2)	/* fill horizontal trapezoid with current pattern */
     /* expects integers, screen coordinates */
int x1, y1, dx1, x2, y2, dx2; 

{	int sm; /* saved mode */
	long theFont;

	if (y1 > y2)
		return; /* nothing to draw */

	sm = CurrentMode;
	if (sm == SRC_COPY) { /* mode rewrite: erase, then write black */
		TUTORset_comb_rule(SRC_BIC);
		wm_FillTrapezoid(x1, y1, dx1, x2, y2, dx2,wxcp(TUTORinq_font_ptr(patternFont0)),patternChar0);
	} /* mode if */
	else if (sm == NOT_SRC_COPY) { /* mode erase: fill black, then write white */
		TUTORset_comb_rule(SRC_OR);
		wm_FillTrapezoid(x1, y1, dx1, x2, y2, dx2,wxcp(TUTORinq_font_ptr(patternFont0)),patternChar0);
	} /* else if mode */
	TUTORset_comb_rule(sm); /* restore mode */
	theFont = TUTORinq_font_ptr(patternFont);
	wm_FillTrapezoid(x1, y1, dx1, x2, y2, dx2,wxcp(theFont),patternChar);

} /* FillTrapezoid */

/* ******************************************************** */

TUTORabs_fill_polygon(npoints, fx, fy)

/*   Fills a polygon described by an array of points (fx[i], fy[i]).
fx[i] & fy[i] are already converted to actual screen locations. */

  int npoints ;
  long fx[] ;  /* arrays for -fill- */
  long fy[] ;
{ int i;
  XPoint ip[FILLPOINTS+2];

  if (!isx11) {
	WMfill_polygon(npoints, fx, fy);
	return;
	}

  for ( i = 1 ;  i <= npoints ;  ++i ) {
 	ip[i].x = (int) fx[i];
	ip[i].y = (int) fy[i]+pd_barheight ;
	} /* end for */

  FillModeOn();
  XFillPolygon(display,drawwindow,gc,
	ip+1,npoints,Complex,CoordModeOrigin);
  FillModeOff();

 } /* TUTORfill_polygon */

/* ******************************************************** */

WMfill_polygon(npoints, xa, ya)
/*
 * Fills a polygon described by an array of points (fx[i], fy[i]) by
 * decomposing it into a series of horizontal trapezoids (working from bottom
 * to top) and filling them with FillTrapezoid fx[i] & fy[i] are already
 * converted to actual screen locations.  This is based on the algorithm in
 * "Fundamentals of Interactive Computer Graphics" by Foley and Van Dam. The
 * major difference is breaking this down by trapezoids instead of
 * scan-lines.
 */
	int             npoints;
        long		*xa, *ya;
{
	short           ii, jj, kk, mm, nedges, ntraps, last_y;
	struct poly_edge edges[FILLPOINTS], *et[FILLPOINTS], *aet, temp_edge, *prev, *curr;
	short           y_list[FILLPOINTS];
	struct trap_edge traps[FILLPOINTS / 2];
	int bottomy;	/* y coord we use as bottom of trapezoid.  bottomy is sometimes
						one less than one would expect so that bottoms of polygons
						aren't filled (to be similar to mac, x11, etc.) */

	xa++;
	ya++;			/* this is bogus.  change
				 * TUTOR{abs,}fill_polygon */
	/* set up the edges */
	nedges = npoints;
	kk = 0;	/* index in edge table */
	for (ii = 0; ii < npoints; ii++) {
		/* ii is index of starting point, jj of ending point, for this edge */
		jj = (ii == npoints - 1) ? 0 : ii + 1;
		if (ya[ii] == ya[jj]) {	/* Horizontal edges are ignored */
			nedges--;
		} else {
			if (xa[ii] == xa[jj])
				edges[kk].rslope = coordZero;
			else
				edges[kk].rslope = FloatToCoord((float) (xa[ii] - xa[jj]) / (float) (ya[ii] - ya[jj]));

			if (ya[ii] > ya[jj]) { /* sloping down */
				edges[kk].y = ya[ii];	/* ymax */
				edges[kk].x = IntToCoord(xa[jj]); /* x at ymin */
				
				/* is this edge's ymax a local maximum? */
				mm = (ii == 0) ? npoints - 1 : ii-1; /* previous point */
				edges[kk].localMax = (ya[mm] <= ya[ii]);
				
				/* find the next point with a different y */
				mm = (jj == npoints - 1) ? 0 : jj + 1;
				while (ya[jj] == ya[mm]) {
					mm = (mm == npoints - 1) ? 0 : mm + 1;
				}
				if (ya[jj] > ya[mm]) {
					edges[kk].x += edges[kk].rslope;
					y_list[kk] = ya[jj] + 1;
				}
				else { /* jj is local minimum */
					y_list[kk] = ya[jj];
				}
			} else { /* sloping up */
				edges[kk].y = ya[jj];
				edges[kk].x = IntToCoord(xa[ii]);
				
				/* is this edge's ymax a local maximum? */
				mm = (jj == npoints - 1) ? 0 : jj+1; /* point after jj */
				edges[kk].localMax = (ya[mm] <= ya[jj]);
				
				mm = (ii == 0) ? npoints - 1 : ii - 1;
				while (ya[ii] == ya[mm]) {
					mm = (mm == 0) ? npoints - 1: mm - 1;
				}
				if (ya[ii] > ya[mm]) {
					edges[kk].x += edges[kk].rslope;
					y_list[kk] = ya[ii] + 1;
				}
				else {
					y_list[kk] = ya[ii];
				}		
			}
			edges[kk].next = NULL;
			kk++;
		}
	}
	if (nedges == 0)
		return; /* all horizontal lines, so there is only 1 line, which
					we don't draw because it is the bottom line and
					we don't draw the bottom line */

	/* sort y_list and edges */
	for (ii = 0; ii < nedges - 1; ii++)
		for (jj = ii + 1; jj < nedges; jj++) {
			if (y_list[ii] > y_list[jj]) {
			
				kk = y_list[ii];
				y_list[ii] = y_list[jj];
				y_list[jj] = kk;
				
				temp_edge.y = edges[ii].y;
				temp_edge.x = edges[ii].x;
				temp_edge.rslope = edges[ii].rslope;
				temp_edge.localMax = edges[ii].localMax;
				edges[ii].y = edges[jj].y;
				edges[ii].x = edges[jj].x;
				edges[ii].rslope = edges[jj].rslope;
				edges[ii].localMax = edges[jj].localMax;
				edges[jj].y = temp_edge.y;
				edges[jj].x = temp_edge.x;
				edges[jj].rslope = temp_edge.rslope;
				edges[jj].localMax = temp_edge.localMax;
			}
		}

	for (ii = 0; ii < nedges; ii++) {
		et[ii] = NULL;
	}

	/* compact y_list and construct edge table */
	/* nedges will now represent the number of rows in the edge table */
	kk = nedges;
	ii = jj = 0;
	while (jj < kk) {
		if ((ii != jj) && (y_list[ii] != y_list[jj])) {
			ii++;
			y_list[ii] = y_list[jj];
		}
		if (et[ii] == NULL)
			et[ii] = edges + jj;
		else if (et[ii]->x > edges[jj].x) {
			edges[jj].next = et[ii];
			et[ii] = edges + jj;
			nedges--;
		} else {
			prev = et[ii];
			curr = prev->next;
			while (curr && (curr->x < edges[jj].x)) {
				prev = curr;
				curr = curr->next;
			}
			if (curr)
				edges[jj].next = curr;
			prev->next = edges + jj;
			nedges--;
		}
		jj++;
	}

	/* start drawing, working our way up the edge table (et) */
	ii = 1;
	jj = last_y = y_list[0];
	aet = curr = et[0];
	for (ntraps = 0; curr; ntraps++) {
		traps[ntraps].x = RoundCoord(curr->x);
		traps[ntraps].length = RoundCoord(curr->next->x - curr->x);
		curr = curr->next->next;
	}
	for (curr = aet; curr; curr = curr->next) {
		curr->x += curr->rslope;
	}
	jj++;
	
	do {
		kk = 0;

		/* Step 1 */
		/* add new edges */
		if (ii < nedges && jj == y_list[ii]) {
			if (jj != last_y) {
				curr = aet;
				for (ntraps = 0; curr; ntraps++) {
					bottomy = jj;
					if (jj == curr->y && curr->localMax)
						{ /* the bottom of this trapezoid is a maximum, we
							don't want the last line.  Note that we really ought
							to adjust the x position and length of the bottom line
							(to be the position and length of the previous line)
						   */
						bottomy--;
						}
					FillTrapezoid(traps[ntraps].x, last_y, traps[ntraps].length,
						RoundCoord(curr->x), bottomy, RoundCoord(curr->next->x - curr->x));
					curr = curr->next->next;
			    	}
				last_y = jj + 1;
			}
			aet = merge_lists(aet, et[ii]);
			ii++;
		}
		if (last_y >= jj) {
			curr = aet;
			for (ntraps = 0; curr; ntraps++) {
				traps[ntraps].x = RoundCoord(curr->x);
				traps[ntraps].length = RoundCoord(curr->next->x - curr->x);
				curr = curr->next->next;
			}
		}

		/* Step 2 */
		/* draw */
		
		for (curr = aet; curr; curr = curr->next) {
			if (curr->y == jj) {
				kk++;
				break;
	 		}
		}
	    
		if (kk) {
			curr = aet;
			for (ntraps = 0; curr; ntraps++) {
				bottomy = jj;
				if (jj == curr->y && curr->localMax)
					{ /* the bottom of this trapezoid is a maximum, we
						don't want the last line.  Note that we really ought
						to adjust the x position and length of the bottom line
						(to be the position and length of the previous line)
					   */
					bottomy--;
					}
				FillTrapezoid(traps[ntraps].x, last_y, traps[ntraps].length,
					RoundCoord(curr->x), bottomy, RoundCoord(curr->next->x - curr->x));
				curr = curr->next->next;
		    	}
			last_y = jj + 1;
		}

		/* Step 3 & Step 4 */
		/* remove old entries & add 1/m to x */
	
		curr = aet->next;
		prev = aet;
		while (curr) {
			if (curr->y == jj)
				prev->next = curr->next;
			else {
				curr->x += curr->rslope;
				prev = prev->next;
			}
			curr = curr->next;
		}

		if (aet->y == jj)
			aet = aet->next;
		else
			aet->x += aet->rslope;
	    
		/* Step 5 */
		/* re-sort */
		aet = merge_sort(aet);
		
		/* Step 6 */
		/* increment jj */
		jj++;

	} while (aet || ii < nedges);
}

static struct poly_edge *merge_sort(list)
	struct poly_edge *list;
{
	struct poly_edge *temp1, *temp2, *prev;

	if (!list || !list->next)
		return (list);

	temp1 = temp2 = list;
	prev = temp1;
	while (temp2 && temp2->next) {
		temp2 = temp2->next->next;
		prev = temp1;
		temp1 = temp1->next;
	}
	prev->next = NULL;
	return (merge_lists(merge_sort(list), merge_sort(temp1)));
}

/* merge two pre-sorted lists. */
static struct poly_edge *merge_lists(list1, list2)
	struct poly_edge *list1, *list2;
{
	struct poly_edge *head, *curr;

	if (!list1)
		return (list2);
	if (!list2)
		return (list1);

	if (list1->x < list2->x) {
		head = list1;
		list1 = list1->next;
	} else {
		head = list2;
		list2 = list2->next;
	}
	curr = head;
	for (curr = head; list1 && list2; curr = curr->next) {
		if (list1->x < list2->x) {
			curr->next = list1;
			list1 = list1->next;
		} else {
			curr->next = list2;
			list2 = list2->next;
		}
	}
	curr->next = list1 ? list1 : list2;
	return (head);
}

/* ********************************************************** */
TUTORabs_fill_disk(type,xc,yc,rp,pFont,pChar)
int type; /* 0 = radius form, center valid */
          /* 1 = rectangle form, center not valid */
long xc,yc; /* center */
TRect *rp;
int pFont, pChar;
 {
  int xcenter, ycenter, radiusx, radius; 
  double rotate ; 
  int ix1, iy1, ix2, iy2 ;

  if (!isx11) {
	WMfill_disk(rp,pFont,pChar);
	return;
	}

  /* convert to screen coordinates */
  ix1 = rp->left;
  iy1 = rp->top;
  ix2 = rp->right;
  iy2 = rp->bottom;

  FillModeOn();
  XFillArc(display,drawwindow,gc,
    ix1,iy1+pd_barheight,ix2-ix1+1,iy2-iy1+1,0,64*360);
  FillModeOff();

} /* TUTORabs_fill_disk */

/* ********************************************************** */

WMfill_disk(rp,pFont,pChar)	
/* filled disk;  partial disks are not allowed  */
/* Mac's or Postscript can handle partial disks, but we can't */
/* rotate should be 0;  rotate not 0 doesn't work with wm */
/* for the time being angles are always 0 - 360 */
TRect *rp; /* in screen coords */
int pFont, pChar;
 {
  Coord xcenter, ycenter, radiusx, radius;
  double rotate;
  int nchords, n;
  Coord x, y, newx, newy;
  Coord cosphi, sinphi;
  double phi;
  int lastx, lasty, ix, iy ;
  Coord scalex, scale2;

  /* convert to screen coordinates */
  /* get center-radius description so can use algorithm below */
  xcenter = IntToCoord((rp->left+rp->right)/2);
  ycenter = IntToCoord((rp->top+rp->bottom)/2) ;
  radiusx = IntToCoord((rp->right - rp->left)/2);
  radius = IntToCoord((rp->bottom - rp->top)/2);
  scalex = DivCoord(radiusx,radius);
  /* number of trapezoid slices should depend on radius of y */
  if (radius == coordZero) return;

#ifdef DOPSCRIPT
  if(pscript)
       {sprintf( PSbuff, "\n%g %g %g %g %g FillDisk\n", 
                      xcenter-OffsetX, ycenter-OffsetY, radius, (radius/radiusx), rotate ) ;
         PostScriptOutput(PSbuff);
       }
#endif

  phi =  1.0/sqrt(CoordToFloat(AbsCoord(radius)));
  nchords = floor(pi/phi);
  phi = pi/nchords;
  cosphi = FloatToCoord(cos(phi));
  sinphi = FloatToCoord(sin(phi));
  x = coordZero;
  y = -radius;

  /* starting point for FillTrapezoid */
  lastx = RoundCoord(xcenter);
  lasty = RoundCoord(ycenter-radius);
  scale2 = 2*scalex;

  for (n=1; n<=nchords; ++n)
   {
    newx = MulCoord(x,cosphi) - MulCoord(y,sinphi);
    newy = MulCoord(y,cosphi) + MulCoord(x,sinphi);

    ix = RoundCoord(xcenter - MulCoord(scalex,newx));
    iy = RoundCoord(ycenter + newy) ;

    FillTrapezoid( lastx, lasty, RoundCoord(MulCoord(scale2,x)),
                         ix, iy, RoundCoord(MulCoord(scale2,newx))); 

    x = newx; y = newy;
    lastx = ix ;
    lasty = iy+1;
   }
} /* WMfill_disk */

/* ********************************************************** */


