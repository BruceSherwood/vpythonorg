
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* ******************************************************************* */

#include <stdio.h>

#include "baseenv.h"
#include "compute.h"
#include "ecglobal.h"
#include "tfiledef.h"
#include "tglobals.h"

#include <bios.h>
#include <dos.h>
#ifdef TURBOC
#include <dir.h>
#include <io.h>
#endif
#include <sys\stat.h>

#ifdef ctproto
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
int  TUTORcmp_fileref(struct  _fref FAR *f1,struct  _fref FAR *f2);
int  TUTORcopy_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  TUTORcopy_fileref_dir(struct  _fref FAR *dirname,struct  _fref FAR *fullname);
int  TUTORinq_fref(int  findx,struct  _fref FAR *fref);
int  TUTORget_fileref_dir(struct  _fref FAR *fRef,char  FAR *name);
int  TUTORsymbolic_fileref(struct  _fref FAR *fRef,char  FAR *syms);
int  TUTORget_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  file_slot(void);
int  TUTORclose(int  findx);
int  TUTORfile_exists(struct  _fref FAR *fRef);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
long  TUTORinq_file_pos(int  findx);
int  TUTORinq_file_err(int  findx);
int  TUTORstat(struct  _fref FAR *fRef,struct  stat *buff);
int  TUTORseek(int  findx,long  pos);
int  TUTORset_file_type(struct  _fref FAR *fRef,int  findx,int  type,int  xx,int  yy);
long  TUTORwrite(char  FAR *ptr,int  pSize,long  count,int  findx);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
int  TUTORwrite_int(int  ii,int  findx);
int  TUTORread_int(int  *ii,int  findx);
int  TUTORwrite_short(short  ss,int  findx);
int  TUTORread_short(short  *ss,int  findx);
int  TUTORwrite_char(int cc,int  findx);
int  TUTORread_char(unsigned char  *cc,int  findx);
int  TUTORget_char(int  findx,int  tryHard);
int  TUTORread_string(unsigned char  *str,int  length,int  findx);
long  TUTORread_number(int  findx);
int  TUTORungetc(int  findx,int  cc);
extern long  flrdwr(char  FAR *ptr,int  pSize,long  count,int  findx,int  rwFlag);
int  TUTORreset_file(int  findx,int  option);
int  TUTORtemp_file_name(struct  _fref FAR *baseN,struct  _fref FAR *tempN);
extern long  pc_rdwr_ems(long  length,char  FAR *memp,int  read);
extern void  pc_map_ems(int  handle,int  page);
extern long  pc_rdwr_xms(long  length,char  FAR *memp,int  read);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
int  ReleasePtr(unsigned int  mm);
/* extern _dos_setdrive(); */
char  *strf2n(char  FAR *strp);
/* extern _dos_getdrive(); */
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
extern int strlen(char *str);
int  killptr(char  FAR * FAR *ptr);
extern TUTORblock_move(char FAR *sp, char FAR *dp, long lth);
char  FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
int  TUTORdump(char  *s);
int  strlenf(char  FAR *aa);
int  strcmpf(char  FAR *aa,char  FAR *bb);
extern int stat(char *path, struct stat *buffer);
void  pc_close_xms(int  handle);
void  pc_close_ems(int  handle);
void  pc_close_serial(int  port);
int  ClearAuthorFile(long  vloc);
int  pc_rdwr_serial(int  port,char  FAR *ptr,long  count,int  rwFlag);
int  pc_ungetc_serial(int  cc,int  port);
/* extern pc_xms(); */
/* extern segread(); */
/* extern int86(); */
extern char FAR *pc_lp(long pp);
extern char *mktemp(char *path);
#ifdef IBMPROTO
FILE * _CDECL fopen(const char *, const char *);
int _CDECL fseek(FILE *, long, int);
long _CDECL ftell(FILE *);
int _CDECL fclose(FILE *);
int _CDECL fgetc(FILE *);
size_t _CDECL fread(void *, size_t, size_t, FILE *);
size_t _CDECL fwrite(const void *, size_t, size_t, FILE *);
int _CDECL fflush(FILE *);
int _CDECL ungetc(int, FILE *);
int _CDECL fscanf(FILE *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

extern char FAR *pc_lp();
extern long pc_pl();
static long flrdwr();
long TUTORwrite_socket();
long TUTORread_socket();
extern char *strf2n();
extern void pc_map_ems();
extern long pc_rdwr_ems();
extern void pc_close_ems();
extern long pc_rdwr_xms();
extern void pc_close_xms();

extern long ems_segment;
extern long ems_offset;
extern int xms_driver;
extern short xms_c_handle;
extern long xms_c_offset;

#define RMODE "rb"
#define RMODEB "rb"
#define WMODE "wb"
#define WMODEB "wb"
#define WRMODE "wb+"
#define RWMODE "rb+"
#define AMODE "ab"
#define AMODEB "ab"

#define EMS_PGSZ 0x4000

/* ******************************************************************* */

TUTORcopy_fileref(fDest,fSource)
FileRef FAR *fDest, FAR *fSource;

{
    strcpyf(fDest->path,fSource->path);
    fDest->nameInd = fSource->nameInd;
    fDest->drive = fSource->drive;

} /* TUTORcopy_fileref */

/* ******************************************************************* */

TUTORcmp_fileref(f1,f2)
FileRef FAR *f1, FAR *f2;
/* returns 0 if FileRefs are the same */

{
    if (f1->drive == f2->drive && f1->nameInd == f2->nameInd)
    return(strcmpf(f1->path,f2->path));
    else
    return(1); /* they are not the same */

} /* TUTORcmp_fileref */

/* ******************************************************************* */

TUTORcopy_fileref_name(fRef,name)
FileRef FAR *fRef; /* use directory reference from here */
char FAR *name; /* use this as file name */

{
    if (fRef->nameInd + strlenf(name) > FILEL)
        TUTORdump("file path too long in TUTORcopy_fileref_name");
    strcpyf(fRef->path + fRef->nameInd,name);

} /* TUTORcopy_fileref_name */

/* ******************************************************************* */

TUTORcopy_fileref_dir(dirname, fullname) /* copy directory path */
FileRef FAR *dirname;    /* path to have only directory set */
FileRef FAR *fullname;    /* full path */ 
    
{    int i, len;

    dirname->drive = fullname->drive;
    len = fullname->nameInd;
    strncpyf(dirname->path,fullname->path,len);
    dirname->path[len] = '\0'; /* null terminate, we have no name */
    dirname->nameInd = len;

} /* TUTORcopy_fileref_dir */

/* ******************************************************************* */
TUTORinq_fref(findx,fref)
int findx;  /* file index */
FileRef FAR *fref;  /* to be filled with fileref of file whose index is find */
    {
    struct tutorfile FAR *tfp;
    
    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to file table entry */

    TUTORblock_move((char FAR *) &(tfp->fRef),(char FAR *) fref,
                    (long) sizeof(FileRef));
    ReleasePtr(filesopen);
    KillPtr(tfp);
    
    return(TRUE);
    }

/* ******************************************************************* */

int  TUTORget_fileref_dir(fRef,name) /* get the directory of an fRef */
FileRef FAR *fRef;
char FAR *name;

{    char FAR *cp;
    
    strcpyf(name,fRef->path);
    cp = name+strlenf(name)-1;
    while ((cp != name) && (*cp != '\\') && (*cp != '/'))
        cp--;
    if (*cp == '\\' || *cp == '/') {
        *cp = '\0';
    } else {
        name[0] = '\0';
    }

} /* TUTORget_fileref_dir */
    
/* ******************************************************************* */

TUTORsymbolic_fileref(fRef,syms)
FileRef FAR *fRef; /* to be set up for symbolic fRef */
char FAR *syms; /* symbolic string */

{
    /* a symbolic string on the pc can be detected by noting that the */
    /* first char of path is NOT \ */
    strcpyf(fRef->path,syms);
    fRef->nameInd = 0;
    fRef->drive = ctDir.drive; /* use drive cT is on */
}

/* ******************************************************************* */
TUTORget_fileref_name(fRef,name) /* return the name of an fRef */
FileRef FAR *fRef;
char FAR *name;

{
    strcpyf(name,fRef->path+fRef->nameInd);
}

/* ******************************************************************* */

int TUTORopen(fRef,rf,wf,af) /* open file */
FileRef FAR *fRef;
int rf; /* TRUE if read access */
int wf; /* TRUE if write access */
int af; /* TRUE if append */

{   struct tutorfile FAR *tfp; /* pointer to file table entry */
    int ii;
    char *fstr; /* pointer to r/w/a string */
    int wrtf; /* write allowed flag */
    unsigned int curdrive, nDrives;

    /* set up file table entry */

    tfilerr = -1; /* no error yet */
    ii = file_slot(); /* locate free file table slot */
    tfp = ii+(struct tutorfile FAR *) GetPtr(filesopen);
    tfp->inuse = TRUE; /* mark file table entry in use */
    tfp->lastop = fop_open; /* no operations yet */
    tfp->ro = ((!wf) && (!af)); /* set read-only flag */
    tfp->kind = 0; /* normal file */
    TUTORcopy_fileref(&tfp->fRef,fRef);

    /* open file */

    if (af && rf) fstr = "ab+"; /* build file access type */
    else if (af) fstr = "ab";
    else if (wf && (!rf)) fstr = "wb";
    else if (wf) fstr = "rb+";
    else fstr = "rb";

    _dos_getdrive(&curdrive);
    _dos_setdrive((unsigned int) fRef->drive,&nDrives);
    tfp->fp = fopen(strf2n(fRef->path),fstr);
    _dos_setdrive(curdrive,&nDrives);  /* restore drive */
    if (tfp->fp == NULL) {
    tfp->inuse = FALSE;
    tfilerr = FILEPERMIT; /* permission not granted */
    ReleasePtr(filesopen);
    return(0);
    } /* fp if */

    ReleasePtr(filesopen);

    return(ii); /* return index in file table */

} /* TUTORopen */

/* ------------------------------------------------------------------- */

int file_slot() /* locate free file table slot */

{   struct tutorfile FAR *tfp;
    int ii;

    /* search for unused slot */

    tfp = ((struct tutorfile FAR *)GetPtr(filesopen))+1;
    for (ii = 1; ii < filesmalloc; ii++, tfp++) /* skip slot 0 */
    if (!tfp->inuse)
        break;

    /* allocate new slot */

    if (ii >= filesmalloc) {
    ReleasePtr(filesopen);
    filesmalloc++;
    TUTORset_hsize(filesopen,(long)(filesmalloc*sizeof(struct tutorfile)),TRUE);
    tfp = (struct tutorfile FAR *) GetPtr(filesopen);
    ii = filesmalloc-1; /* index of empty slot */
    tfp += ii; /* point to empty slot */
    tfp->inuse = FALSE;
    } /* ii if */
    tfp->vloc = -1;
    tfp->styled = FALSE;
    tfp->fp = 0L;
    tfp->stream = -1;
    tfp->buffer = FARNULL;
    ReleasePtr(filesopen);
    return(ii); /* always slot 1 or above */

} /* file_slot */

/* ******************************************************************* */

TUTORclose(findx) /* close file */
int findx; /* index in file table (returned by TUTORopen) */

{   struct tutorfile FAR *tfp;    
    FILE *ffp;
    char FAR *cp;

    if (findx <= 0)
		return;

    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    ffp = tfp->fp;

    if (tfp->vloc >= 0)
        ClearAuthorFile(tfp->vloc); /* author file, clear variable */

    switch (tfp->kind) {
    case 0: /* normal file */
        if (ffp) fclose(ffp);
        break;
    case 1: /* serial port */
        if (tfp->stream) 
            pc_close_serial(tfp->stream);
        break;
    case 2: /* socket */
/*      TUTORclose_socket(tfp);    */
        break;
    case 4: /* EMS */
        if (tfp->stream) 
            pc_close_ems(tfp->stream);
        break;
    case 5: /* XMS */
        if (tfp->stream) 
            pc_close_xms(tfp->stream);
        break;
    default:
        TUTORdump("Unknown type of file in TUTORclose");
        break;
    } /* switch */

    tfp->inuse = FALSE;
    tfp->fRef.path[0] = '\0';
    tfp->vloc = -1;
    tfp->fp = NULL;
    tfp->stream = 0;
    ReleasePtr(filesopen);

} /* TUTORclose */

/* ******************************************************************* */

TUTORfile_exists(fRef) /* return TRUE if file "s" exists */
FileRef FAR *fRef;

{   long length;

    if (fRef->path[0] == 0)
    return(FALSE);
    TUTORinq_file_info(fRef,NEARNULL,&length,NEARNULL,NEARNULL,NEARNULL);
    if (length >= 0)
    return(TRUE);
    else
    return(FALSE);

} /* TUTORfile_exists */

/* ******************************************************************* */

TUTORinq_file_info(fRef,waccess,length,modtim,posx,posy)
FileRef FAR *fRef;
int *waccess; /* TRUE if have write access to file */
long *length; /* length of file */
    /* -1 if file does not exist */
long *modtim; /* time of last modification */
int *posx; /* x position of file icon */
int *posy; /* y position of file icon */

{   struct stat fst; /* file status block */  
    int sr; /* stat return */ 

    /* get file status if neccessary */

    if (waccess || length || modtim) {
    sr = TUTORstat(fRef,&fst);
    if (sr) {
        fst.st_size = -1; /* clear fields if stat failed */
        fst.st_mode = 0;
        fst.st_mtime = 0;
    } /* sr if */
    } /* access if */

    /* return write permission status if requested */

    if (waccess) *waccess = TRUE;

    /* return file length if requested */

    if (length) *length = fst.st_size;

    /* return time of last modification if requested */

    if (modtim) *modtim = fst.st_mtime;

    /* return file icon position if requested */

    if (posx) *posx = -10000; /* no position for wm */
    if (posy) *posy = -10000;

} /* TUTORinq_file_info */

/* ******************************************************************* */

long TUTORinq_file_pos(findx) /* get current read/write position */
int findx; /* index of file */

{   struct tutorfile FAR *tfp; /* pointer to file table entry */
    long pos; /* file position */

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to file table entry */
    switch (tfp->kind) {
    case 0:
        pos = ftell(tfp->fp);
        break;
    default:
        TUTORdump("Invalid file type in TUTORinq_file_pos");
        break;
    } /* switch */
    
    ReleasePtr(filesopen);
    return pos;

} /* TUTORinq_file_pos */

/* ******************************************************************* */

int TUTORinq_file_err(findx) /* returns TRUE if error has occurred */
int findx;

{   struct tutorfile FAR *tfp; /* pointer to file table entry */
    int fret; /* error return */

    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    switch (tfp->kind) {
    case 0:
        fret = ferror(tfp->fp);
        break;
    default:
        TUTORdump("Invalid file type in TUTORinq_file_err");
        break;
    }
    ReleasePtr(filesopen);
    return(fret ? TRUE: FALSE);

} /* TUTORinq_file_err */

/* ******************************************************************* */

TUTORstat(fRef,buff)
FileRef FAR *fRef;
struct stat *buff;

{   unsigned int curdrive, nDrives;
    int sr;

    _dos_getdrive(&curdrive);
    _dos_setdrive((unsigned int) fRef->drive,&nDrives);
    sr = stat(strf2n(fRef->path),buff); /* get file status info */
    _dos_setdrive(curdrive,&nDrives); /* restore drive */
    return(sr);
}

/* ******************************************************************* */

TUTORseek(findx,pos) /* seek to specified position in file */
int findx; /* index of file in file table */
long pos; /* position */
{
    struct tutorfile FAR *tfp; /* pointer to file table entry */
    int page;

    tfp = findx + (struct tutorfile FAR *)GetPtr(filesopen);
    switch (tfp->kind) {
    case 0:        /* plain file */
        fseek(tfp->fp, pos,0);
        break;
    case 4:        /* EMS */
        page = pos / EMS_PGSZ;
        ems_offset = pos % EMS_PGSZ;
        pc_map_ems(tfp->stream, page);
        break;
    case 5:        /* XMS */
        xms_c_handle = tfp->stream;
    xms_c_offset = pos;
        break;
    } /* switch */
    
    ReleasePtr(filesopen);

} /* TUTORseek */

/* ******************************************************************* */

TUTORset_file_type(fRef,findx,type,xx,yy)  /* set file's operating system type */
FileRef FAR *fRef;
int findx; /* file index */
int type; /* 1: AUTHOR, 2: EXECUTOR */
int xx, yy; /* file icon location (-10000 if not to be used) */
    
{
    return 0; /* dos doesn't support file types... */

} /* TUTORset_file_type */

/* ******************************************************************* */

long TUTORwrite(ptr,pSize,count,findx)
char FAR *ptr; /* buffer to write out */
int pSize; /* size of item */
long count; /* # of items to write out */
int findx;
/* returns # of bytes written */
    
{
    return(flrdwr(ptr,pSize,count,findx,FALSE));

} /* TUTORwrite */

/* ******************************************************************* */

long TUTORread(ptr,pSize,count,findx)
char FAR *ptr; /* buffer to fill */
int pSize; /* size of item */
long count; /* # of items to write out */
int findx;
/* returns # of bytes read */
    
{
    return(flrdwr(ptr,pSize,count,findx,TRUE));

} /* TUTORread */

/* ******************************************************************* */

TUTORwrite_int(ii,findx)
int ii;
int findx;
{
    struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */

    switch (tfp->kind) {
    case 0:        /* plain file */
        tfp->lastop = fop_write;
        fwrite(&ii,sizeof(int),1,tfp->fp);
        break;
    default:
        TUTORdump("Invalid file type in TUTORwrite_int");
        break;
    }
    ReleasePtr(filesopen);
} /* TUTORwrite_int */

/* ******************************************************************* */

TUTORread_int(ii,findx)
int *ii;
int findx;
    
{
    struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *) GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    switch (tfp->kind) {
    case 0:
        tfp->lastop = fop_read;
        fread(ii,sizeof(int),1,tfp->fp);
        break;
    default:
        TUTORdump("Invalid file type in TUTORread_int");
        break;
    }
    ReleasePtr(filesopen);

} /* TUTORread_int */

/* ******************************************************************* */

TUTORwrite_short(ss,findx)
short ss;
int findx;
    
{
    struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */

    switch (tfp->kind) {
    case 0:
        tfp->lastop = fop_write;
        fwrite(&ss,sizeof(short),1,tfp->fp);
        break;
    default:
        TUTORdump("Invalid file type in TUTORwrite_short.");
        break;
    }
    ReleasePtr(filesopen);

} /* TUTORwrite_short */

/* ******************************************************************* */

TUTORread_short(ss,findx)
short *ss;
int findx;
    
{
    struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    switch (tfp->kind) {
    case 0:
        tfp->lastop = fop_read;
        fread(ss,sizeof(short),1,tfp->fp);
        break;
    default:
        TUTORdump("Invalid file type in TUTORread_short");
        break;
    }
    ReleasePtr(filesopen);

} /* TUTORread_short */

/* ******************************************************************* */

TUTORwrite_char(cc,findx)
unsigned char cc;
int findx;
    
{   struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    switch (tfp->kind) {
    case 0:
        tfp->lastop = fop_write;
        fwrite(&cc,sizeof(unsigned char),1,tfp->fp);
        break;
    case 1:
        tfp->lastop = fop_write;
        pc_rdwr_serial(tfp->stream, (char FAR *)&cc, 1L, FALSE);
        break;
    default:
        TUTORdump("Invalid file type in TUTORwrite_char");
        break;
    }

    ReleasePtr(filesopen);

} /* TUTORwrite_char */

/* ******************************************************************* */

TUTORread_char(cc,findx)
unsigned char *cc;
int findx;
    
{   struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    switch (tfp->kind) {
    case 0:
        tfp->lastop = fop_read;
        fread(cc,sizeof(unsigned char),1,tfp->fp);
        break;
    default:
        break;
    }
    ReleasePtr(filesopen);

} /* TUTORread_char */

/* ******************************************************************* */

int TUTORget_char(findx, tryHard) /* read+return character or EOF */
int findx;
int tryHard; /* if TRUE, try hard (retry io port) to get character */

{   struct tutorfile FAR *tfp;
    int cc = EOF, ii;
    char ch;

    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);

    switch (tfp->kind) {
    case 0: /* normal file */
        tfp->lastop = fop_read;
        cc = fgetc(tfp->fp); /* file */
        break;
    case 1: /* serial port */
        tfp->lastop = fop_read;
        for (ii = 0; ii < 5; ii++) {
        if (pc_rdwr_serial(tfp->stream, (char FAR *)&ch, 1L, TRUE) == 1)
            break; /* for */
        }
        if (ii < 5)
        cc = ch;
        break;
    default:
        TUTORdump("Invalid file type in TUTORget_char");
        break;
    } /* switch */

    ReleasePtr(filesopen);
    return(cc);

} /* TUTORget_char */

/* ******************************************************************* */

int TUTORread_string(str,length,findx) /* read newline-terminated string */
unsigned char *str; /* pointer to buffer to read into */
int length; /* maximum length to read */
int findx; /* file index */
    
{   struct tutorfile FAR *tfp; /* pointer to ct file table entry */
    int nc; /* number characters read */
    int cc; /* last character read */

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    switch (tfp->kind) {
    case 0:
        tfp->lastop = fop_read;
        if ((feof(tfp->fp)) || (length <= 0)) {
        ReleasePtr(filesopen);
        return(0); /* nothing read */
        } /* feof if */
        nc = 0;
        cc = 0; /* for top of while test */
    do {
        cc = fgetc(tfp->fp);
        if (cc == EOF) cc = NEWLINE;
        str[nc++] = cc;
        } while (cc != NEWLINE && nc < length);
        break;
    default:
        TUTORdump("Invalid file type in TUTORread_string");
        break;
    } /* switch */
    ReleasePtr(filesopen);
    return(nc);

} /* TUTORread_string */

/* ******************************************************************* */

long TUTORread_number(findx)
int findx;
    
{   struct tutorfile FAR *tfp;
    long lret;

    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    switch (tfp->kind) {
    case 0:
        tfp->lastop = fop_read;
        fscanf(tfp->fp,"%ld",&lret);
        break;
    default:
        TUTORdump("Invalid file type in TUTORread_number");
        break;
    }
    ReleasePtr(filesopen);
    return lret;

} /* TUTORread_number */

/* ******************************************************************* */

TUTORungetc(findx,cc)
int findx;
int cc;

{   struct tutorfile FAR *tfp;
    int ret;

    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    switch (tfp->kind) {
    case 0:
        ret = ungetc(cc,tfp->fp);
        break;
    case 1:
        ret = pc_ungetc_serial(cc,tfp->stream);
        break;
    default:
        TUTORdump("Invalid file type in TUTORungetc");
        break;
    }
    ReleasePtr(filesopen);

    return ret;
}

/* ******************************************************************* */

#define CHUNKSZE 1024

static long flrdwr(ptr,pSize,count,findx,rwFlag) /* long read or write */
char FAR *ptr;    /* where the read is going */
int pSize;    /* size of object */
long count;    /* # of objects */
int findx;    /* index in file table */
int rwFlag;    /* TRUE: read, FALSE: write */
    
{   int nReads,ii, nNew, toRead;
    long nIn;
    char FAR *fbuf; /* long pointer to local buffer */
    char buf[CHUNKSZE]; /* local buffer for read/write */
    FILE *fp;
    struct tutorfile FAR *tfp;
    int kind, stream;

    nIn = 0;
    tfp = (struct tutorfile FAR *) GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    fp = tfp->fp; /* get FILE pointer */
    tfp->lastop = (rwFlag ? fop_read: fop_write);
    kind = tfp->kind;
    stream = tfp->stream;
    count *= pSize; /* now just working in bytes */

    ReleasePtr(filesopen);
    if (!count)
    return(nIn);
    
    if (ptr == NULL)
    TUTORdump("flrdwr bad pointer");
    if (kind == 1)
    return pc_rdwr_serial(stream, ptr, count, rwFlag);
    if (kind == 4)
    return pc_rdwr_ems(count,ptr, rwFlag);
    if (kind == 5)
    return pc_rdwr_xms(count,ptr, rwFlag);
    if (fp == NULL)
    TUTORdump("flrdwr bad file pointer");

    nReads = (count-1)/CHUNKSZE;
    for (ii=0; ii<=nReads; ii++) {
    toRead = (ii == nReads) ? (count - nReads*CHUNKSZE) : CHUNKSZE;
    if (rwFlag) {
        nNew = fread(buf,1,toRead,fp);
        fbuf = buf; /* far pointer to local buffer */
        TUTORblock_move(fbuf,ptr,(long)toRead);
    } else {
        fbuf = buf; /* far pointer to local buffer */
        TUTORblock_move(ptr,fbuf,(long)toRead);
        nNew = fwrite(buf,1,toRead,fp);
    } /* else */
    if (nNew == 0) {
        if (feof(fp))
        return(nIn); /* read to end of file */
        return(0L); /* error */
    } /* nNew if */
    nIn += nNew;
    ptr += toRead;
    if (nNew < toRead)
        break;
    } /* for */
    if (!rwFlag && kind == 1)
    fflush(fp);
    return(nIn);

} /* flrdwr */

/* ******************************************************************* */

TUTORreset_file(findx,option) /* reset to begin, end, or empty */
int findx; /* index in file table */
int option; /* option = 0 for start, 1 for end, 2 for empty */

{   struct tutorfile FAR *tfp;
    unsigned int curDrive, nDrives;

    tfilerr = -1; /* no error yet */
    tfp = findx+(struct tutorfile FAR *) GetPtr(filesopen);

    switch (option) {

    case 0: /* start of file */
    if (tfp->kind == 0) { /* this only makes sense for normal file */
    fseek(tfp->fp, 0L, 0);
    tfp->lastop = fop_begin;
    }
    break;

    case 1: /* end of file */
    if (!tfp->ro) 
    fflush(tfp->fp); /* flush if write-able */
    if (tfp->kind == 0)
    fseek(tfp->fp,0L,2); /* seek to end if real file */
    tfp->lastop = fop_end;
    break;

    case 2: /* empty the file */
    if (tfp->ro) { /* read only */
    tfilerr = FILEPERMIT;
    ReleasePtr(filesopen);
    return(0);
    } /* filesopen if */
    if (tfp->kind == 1) { /* not meaningful for serial port */
    ReleasePtr(filesopen);
    return(0); 
    } /* serial port if */
    fclose(tfp->fp);
    _dos_getdrive(&curDrive);
    _dos_setdrive((unsigned int) tfp->fRef.drive,&nDrives);
    tfp->fp = fopen(strf2n(tfp->fRef.path),WRMODE); /* truncate the file */
    _dos_setdrive(curDrive, &nDrives);
    if (tfp->fp == NULL) {
    TUTORclose(findx); /* close file if re-open failed */
    tfilerr = FILEPERMIT;
    ReleasePtr(filesopen);
    return(0);
    } /* open failed if */
    tfp->lastop = fop_empty;
     break;

    } /* switch */

    ReleasePtr(filesopen);
    return(0);

} /* TUTORreset_file */

/* ******************************************************************* */

TUTORtemp_file_name(baseN,tempN)    /* create a temporary file name */
FileRef FAR *baseN; /* base name, used for directory path */
FileRef FAR *tempN; /* to be filled with a currently unused file name */
/* returns TRUE for success */

{    char tnm[FILEL];
    char FAR *result;
    int ret;

    /* we are creating a file name which will not overwrite any other file */

    TUTORcopy_fileref(tempN,baseN);
    TUTORcopy_fileref_name(tempN, (char FAR *) "cTXXXXXX");
    strcpyf((char FAR *)tnm,tempN->path);
    result = mktemp(tnm);
    ret = !(result == NULL);
    strcpyf(tempN->path,result);
    return (ret);

} /* TUTORtemp_file_name */

/* ******************************************************************* */

static long pc_rdwr_ems(length, memp, read)
long length;
char FAR *memp;
int read;

{   char FAR *temp;

    temp = pc_lp((ems_segment << 4)+ems_offset);

    /* now copy the info */
    if (read == TRUE) {
        TUTORblock_move(temp, memp, length);
    } else {
        TUTORblock_move(memp, temp, length);
    }
    return length;

} /* pc_rdwr_ems */

/* ******************************************************************* */

static void pc_map_ems(handle, page)
int handle;
int page;

{   union REGS inr, outr;
    int ii;

    inr.h.ah = 0x44;
    inr.x.dx = handle;
    for (ii = 0; ii < 4; ii++) {
        inr.h.al = ii;
        inr.x.bx = page + ii;
    int86(0x67, &inr, &outr);
    if (outr.h.ah)
        TUTORdump("EMS page map failed");
    }
}

/* ******************************************************************* */

/*
pc_rdwr_xms takes a length, a pointer to a block of memory,
and a boolean.  It reads from the current XMS handle at the
current offset and returns the length of the segment read.
*/

static long pc_rdwr_xms(length, memp, read)
long length;
char FAR *memp;
int read;
{
    union REGS regio;
    struct SREGS segr;
    void FAR *vp;
    struct {
        long length;
        short f_handle;
        long f_offset;
        short t_handle;
        long t_offset;
    } xinfo;

if (length & 1)
    TUTORdump("odd length in pc_rdwr_xms");
    if (xms_driver == FALSE) return 0L;

    vp = (void FAR *)&xinfo;
    xinfo.length = length;
    if (read == TRUE) {
        xinfo.f_handle = xms_c_handle;
        xinfo.f_offset = xms_c_offset;
        xinfo.t_handle = 0;
    xinfo.t_offset = (long)(memp);
    } else {
        xinfo.f_handle = 0;
    xinfo.f_offset = (long)(memp);
        xinfo.t_handle = xms_c_handle;
        xinfo.t_offset = xms_c_offset;
    }

    regio.h.ah = 0x0b;
    regio.x.si = FP_OFF(vp);
    segread(&segr);
    segr.ds = FP_SEG(vp);
    pc_xms(&regio, &segr);

    return length;
}

/* ******************************************************************* */
