/*

A component of the cT (TM) programming environment.

(c) Copyright 1989 Carnegie Mellon University.

cT is a trademark of Carnegie Mellon University.

All rights reserved.

May not be copied without the written consent

of Carnegie Mellon University.

*/



/*

Declarations for kernel (events, windows, etc.) of cT

*/



#ifndef _kglobalsh
#define _kglobalsh

#include "prefs.h"

extern Memh darrowv();

/* menu item states */

#define ITEMDISABLED 1
#define ITEMVISIBLE 2

/* menu item kinds */

#define MENUCARD 0
#define MENUITEM 1
#define UNUSED 2

/* font definitions */

extern long TUTORinq_font_ptrN();

extern char *strf2n();

/* definition of struct tutorfont is in tutor.h */

/* maximum # of font families */

#define MAXFAMILIES 80

long TUTORinq_msec_clock();

extern int CurrentMode; /* write/rewrite etc. mode */

extern long SpaceShim;  /* current space shim value */

extern int RealX, RealY;    /* current x/y position */

extern TRect tgclipR; /* clip rectangle */

extern int tgclipx,tgclipy; /* x/y of clip rectangle */

extern int tgclipw,tgcliph; /* width/height of clip rectangle */

extern short flushMenu; /* if false, wait to flush menus */

extern int lineThick; /* current line thickness */

extern int newlineH; /* current newline height */

extern int SupSub; /* current superscript/subscript */

extern struct tutorview FAR *CurrentView;       /* view currently selected */

extern struct tutorColor fgndColor,bgndColor, winColor; /* current foreground, background, window colors */

extern short CurrentPaletteSize;   /* size of cT palette */

extern Memh defaultPalette; /* the default cT palette */

extern Memh oldDefaultPalette;  /* default palette for executor with $oldcolor */

extern int paletteRef; /* counter identifying current palette */

extern struct tutorColor txtFgndColor;



extern int patternFont, patternChar; /* current drawing pattern */

extern int cursorFont, cursorChar; /* current cursor font */

extern int textFont; /* current text font */



extern int ntiming; /* number timing events currently queued */



extern Memh timeque;

extern int nfonts;  /* number of font table entries */

extern struct tutorevent FAR *eventque;



extern Memh fontFamilies; /* font family table */

extern short nFamilies; /* number of font family table entries */

extern int CurrentWindow;   /* window currently selected */



extern int evlogfi; /* file index of event log file */

extern int evplayfi; /* file index of event replay file */



/* preferences */

extern char FAR *pffamilynP; /* pointer to preferred font name */
extern long pffamily; /* index of preferred font */
extern int pfsize, pfface; /* preferred font (not for executor) */
extern struct PrefRec FAR *prfP; /* pointer to preferences */

#ifdef X11

/* X11 preferences */

extern char pprntr[]; /* print command */

#endif





#ifdef IBMPC

extern char pprntr[];

extern int psbport,psbint; /* SoundBlaster port and interrupt */

#endif





struct ebshdr { /* edit/button/slider object header */

    Memh objectH; /* handle on edit/button/slider data */

    int type; /* TXSLIDER, TXEDIT, etc. */

    int refcnt; /* unique id to identify object */

    Memh nextebsH; /* handle on next ebshdr */

    int inhibitF; /* TRUE if events for object inhibited */

    struct tutorview FAR *viewP; /* pointer to view associated with object */

}; /* ebshdr */


extern long quickLast,quickVal; /* timeslicing */


#endif

