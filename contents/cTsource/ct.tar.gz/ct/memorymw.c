

/* (c) Copyright Carnegie-Mellon University, 1988, 1992. */
/* May be used and copied freely for educational purposes, */
/* but may not be sold without the written consent of Carnegie-Mellon University. */


/* ******************************************************************* */

#include <io.h>
#include <stdio.h>
#include <sys/types.h>

#define STRICT
#include <windows.h>
#include "baseenv.h"
#include "memory.h"
#include "compute.h"
#include "tglobals.h"

#ifdef ctproto
extern int fpc_delete_bitmap_cache(Memh fH);
extern    int InitHandles(void );
extern    unsigned int TUTORhandle(char *name,long size,int purgewmrm);
int  TUTORfree_handle(Memh mm);
extern int TUTORzero(char FAR *ptr,long lth);
extern  struct htab SHUGE *TUTORget_entry_mem(Memh mm);
extern  char FAR *GetPtr(Memh mm);
extern  int ReleasePtr(Memh mm);
extern int TUTORdump(char *str);
extern  long TUTORget_hsize(Memh mm);
extern int  TUTORset_hsize(Memh mm,long newsize,int abort);
extern char FAR *TUTORalloc(long size,int abort,char *label);
extern char FAR *TUTORrealloc(char FAR *ptr,long oldsize,long newsize,
                              int  abort);
extern int TUTORdealloc(char  FAR *ptr);
extern int get_htab_slot(void);
extern int expand_sub_table(void);
extern int get_sub_chunk(long size,HANDLE *winH,long *offSet,long *realSize);
#endif /* ctproto */

/* ******************************************************************* */

extern long lastmsec; /* last millisecond clock value */
extern char *memStr;

static long hmallocN = 0; /* number handles allocated */
static HANDLE htabH; /* (windows) handle on table of (ct) handles */
static struct htab SHUGE *htabP; /* pointer to table of handles */
static short mLowest; /* index to start looking for empty slot */

static long nSubFreeAlloc = 0; /* number free table slots allocated */
static long nSubFree = 0; /* number free entries */
static HANDLE subH; /* (windows) handle on table of subchunks */
static struct subfree SHUGE *subP; /* pointer to subchunks table */

/* ******************************************************************* */

InitHandles() /* initialize handle memory management */

{   DWORD htabL; /* length (bytes) of handle table */
    int ii; /* index in table */
    struct htab SHUGE *hp; /* pointer to table entry */
    long sL; /* size to allocate for subfree table */

    if (hmallocN)
        return(0); /* already initialized */
    hmallocN = NMEMSTART; /* initial size of memory table */
    htabL = sizeof(struct htab)*hmallocN; /* size of table in bytes */
    htabH = GlobalAlloc(GMEM_MOVEABLE,htabL);
    htabP = (struct htab SHUGE *)GlobalLock(htabH); /* get pointer to table */
    for (ii=0, hp=htabP; ii<hmallocN; ii++, hp++)
        TUTORzero((char FAR *)hp,(long)sizeof(struct htab));
    /* zeroth slot should never be used */
    mLowest = 1; /* begin to look for empty spots at entry 1 */
    
    nSubFreeAlloc = 1000;
    nSubFree = 0;
    sL = nSubFreeAlloc*sizeof(struct subfree);
    subH = GlobalAlloc(GMEM_MOVEABLE,sL);
    subP = (struct subfree SHUGE *)GlobalLock(subH);
    TUTORzero((char FAR *)subP,sL);
    return(0);

} /* InitHandles */

/* ******************************************************************* */

Memh TUTORhandle(name,size,purgewmrm) /* allocate handle */
char *name; /* name for debugging */
long size; /* size to allocate */
int purgewmrm; /* TRUE if purgeable (WMRM) */

{    int ii; /* index in table */
    struct htab SHUGE *hp; /* pointer to handle table entry */
    HANDLE newH; /* handle on new item */
    long offSet; /* offset to sub-allocated chunk */
    long realSize; /* real size of sub-allocated chunk */
    
    ii = get_htab_slot(); /* get entry in ct handle table */
    if (ii < 0) 
	TUTORdump(memStr);
        /* return(HNULL); */ /* no go */

    hp = htabP+ii; /* get pointer to handle table entry */
#ifdef MEMVERIFY
    strncpyf(hp->label,(char FAR *)name,8);
#endif
    hp->size = size;
    hp->suballoc = FALSE; /* assume not suballocated */
    hp->realsize = hp->offset = 0; 
    hp->area = FARNULL;
    hp->lockcount = 0;
    if (get_sub_chunk(size,&newH,&offSet,&realSize)) {
        hp->realsize = realSize;
        hp->offset = offSet;
        hp->theH = newH;
        hp->suballoc = TRUE; /* flag suballocated chunk */
        return(ii); /* return Memh */
    }
    /* don't allow zero size as this would be marked as discarded */
    if (size == 0) size = 1;
    hp->theH = GlobalAlloc(GMEM_MOVEABLE,size);
    if (!hp->theH) 
	TUTORdump(memStr);
       /*  return(HNULL); */ /* no go */
    return(ii); /* Memh is index */

} /* TUTORhandle */

/* ******************************************************************* */

static int get_htab_slot() /* find or create handle table entry */

{    int ii;     /* index in table */
    struct htab SHUGE *hp; /* pointer to next table entry */
    DWORD wSize; /* size of table */
    HANDLE ntabH; /* handle on realloc-ed table */
    
    /* search for unused handle table entry */
    
    for (ii=1, hp=htabP+1; ii<hmallocN;ii++, hp++)
        if (!hp->theH) break;

    /* allocate new entries if can't find unused entry */
    
    if (ii >= hmallocN) { /* allocate more handles since table full */
        GlobalUnlock(htabH); /* allow table to move */
        wSize = ((long)(hmallocN+NMEMADD))*sizeof(struct htab);
        ntabH = GlobalReAlloc(htabH,wSize,GMEM_MOVEABLE);
        if (ntabH) 
            htabH = ntabH; /* update handle on table */
        htabP = (struct htab SHUGE *)GlobalLock(htabH);
        if (!htabP)
            TUTORdump("out of handles");
       if (!ntabH)
	    TUTORdump(memStr);
           /*  return(-1); */ /* can't expand table */
        hmallocN += NMEMADD; /* update number handle table entries */

        /* initialize new entries */
        
        for (ii=0, hp=htabP+hmallocN-NMEMADD; ii<NMEMADD; ii++, hp++) 
            TUTORzero((char FAR *)hp,(long)sizeof(struct htab));
        ii = hmallocN-NMEMADD; /* index of open entry */
        hp = htabP+ii;
    } /* ii >= hmallocN if */

    if ((ii+1) < hmallocN)
        mLowest = ii+1; /* next time, start looking just past here */

    /* zero new handle table entry */
    
    TUTORzero((char FAR *)hp,(long)sizeof(struct htab));
    return(ii);
    
} /* get_htab_slot */

/* ******************************************************************* */

static int get_sub_chunk(size,winH,offSet,realSize)
long size; /* size of subchunk required */
HANDLE *winH; /* windows handle containting subchunk */
long *offSet; /* offset within windows handle */
long *realSize; /* actual size of chunk (possibly > size) */

{   int fii; /* index in free subchunks list */
    struct subfree SHUGE *sP; /* pointer in free chunks table */
    long curFit; 
    long bestFit; /* best fit found */
    int bestI; /* index of best fit */
    HANDLE newH; /* handle on newly allocated table/item */
    DWORD newSize; /* size of new table/item */
    long actualSize; /* size actually allocated */

    if (size > 4192L)
        return(FALSE); /* don't try to allocate */
    actualSize = size;
    if (actualSize == 0) actualSize = 8;
    else if (actualSize & 0x7) 
        actualSize = (actualSize+8) & 0xffff8L;

    /* search for free space that best matches size */

    bestI = -1; /* haven't found a fit yet */
    bestFit = 0x10000L; /* impossibly large */
    sP = subP;
    for(fii=0; fii<nSubFree; fii++, sP++) {
        if ((curFit = sP->size-actualSize) >= 0) {
            if (bestFit > curFit) {
                bestFit = curFit;
                bestI = fii;
                if (curFit <= 16)
                    break; /* good enough, exit for */
            } /* bestFit if */    
        } /* curFit if */
    } /* for */

    /* create a new free space if didn't find anything */

    if (bestI < 0) { /* didn't find anything */
        if (nSubFree >= nSubFreeAlloc) {
            if (!expand_sub_table())
                return(FALSE); /* couldn't add table slots */
        } /* nSubFree if */
        newSize = 0xff00; /* near 64K, but not quite */
        newH = GlobalAlloc(GMEM_MOVEABLE,newSize);
        if (!newH)
            return(FALSE); /* couldn't create new space */
        bestI = nSubFree++; /* last entry has space */
        sP = subP+bestI; 
        sP->theH = newH; /* set up new free table entry */
        sP->offset = 0;
        sP->size = newSize;
    } /* bestI if */
    
    /* set up return values */

    sP = subP+bestI;
    *winH = sP->theH; /* return windows handle */
    *offSet = sP->offset; /* return offset within handle */
    *realSize = actualSize;

    /* adjust size of free space for space taken */

    sP->offset += actualSize;
    sP->size -= actualSize;
    if (sP->size <= 16) { /* too small - swallow it */
        *realSize += sP->size; 
        sP->size = 0;
    }
    
    /* remove free space table entry if nothing left */

    if (sP->size == 0) {
        for(fii=bestI; fii<(nSubFree-1); fii++) /* shove table down */
            subP[fii] = subP[fii+1];
        nSubFree--;
    }
    return(TRUE); /* exit happy */

} /* get_sub_chunk */

/* ******************************************************************* */

static int expand_sub_table() /* expand sub-chunk free table */

{   long newSize;
    HANDLE newH;

    GlobalUnlock(subH);
    newSize = (nSubFreeAlloc+100L)*sizeof(struct subfree);
    newH = GlobalReAlloc(subH,newSize,GMEM_MOVEABLE);
    if (newH)
        subH = newH; /* update handle on table */
    subP = (struct subfree SHUGE *)GlobalLock(subH);
    if (!subP)
	TUTORdump(memStr);
    if (!newH)
        return(FALSE); /* can't expand table */
    nSubFreeAlloc += 100; /* increment size of table */
    return(TRUE); 

} /* expand_sub_table */

/* ******************************************************************* */

int TUTORfree_handle(mm) /* destroy handle, release memory */
Memh mm;

{   struct htab SHUGE *hp; /* pointer to handle table entry */
    long nextOffset; /* offset to next suballocated chunk after this */ 
    int fii; /* index in suballoc table */
    struct subfree SHUGE *sP; /* pointer in suballoc table */
    int newFree; /* TRUE if a new free suballocated chunk */

    if (!mm)
	TUTORdump("attempt to free nonexistant handle");
    fpc_delete_bitmap_cache(mm);
    hp = htabP+mm; /* get pointer to handle table entry */
    if (hp->lockcount)
        TUTORdump("attempt to free locked handle");
#ifdef MEMVERIFY
    hp->label[0] = 0;
#endif
    if (hp->suballoc) {
        newFree = TRUE; /* assume we will need a new entry */
        nextOffset = (long)hp->offset+(long)hp->realsize;
        sP = subP;
        for(fii=0; fii<nSubFree; fii++, sP++) {
            if (sP->theH == hp->theH) {
                if ((sP->offset+sP->size) == hp->offset) {
                    /* collapse this chunk into previous */
                    sP->size += hp->realsize;
                    newFree = FALSE; /* don't need a new free entry */
                    break; /* exit for */
                } else if (sP->offset == nextOffset) {
                    /* collapse this chunk into next */
                    sP->offset = hp->offset; 
                    sP->size += hp->realsize;
                    newFree = FALSE; /* don't need a new free entry */
                    break; /* exit for */
                } /* else if */
            } /* theH if */
        } /* for */
        if (newFree) { /* need a new table entry */
            if (nSubFree >= nSubFreeAlloc) 
                expand_sub_table(); /* make more table entries */

            /* if expand_sub_table() fails, we lose a bit of memory */

            if (nSubFree < nSubFreeAlloc) { /* add to free table */
                sP = subP+nSubFree; 
                sP->theH = hp->theH;
                sP->offset = hp->offset;
                sP->size = hp->realsize;
                sP->uu1 = sP->uu2 = 0;
                nSubFree++; /* increment number table entries */
            }
        } /* newFree if */
    } else { /* normal Windows handle */
        GlobalFree(hp->theH); /* destroy the handle */
    }
    hp->theH = FARNULL;
    hp->area = FARNULL;
    return(0);
    
} /* TUTORfree_handle */

/* ******************************************************************* */

#pragma check_stack(on)

char FAR *GetPtr(mm) /* get pointer to contents of handle */
Memh mm; /* ct handle */

{    struct htab SHUGE *hp; /* pointer to handle table entry */
    char SHUGE *cp; /* pointer to handle contents */
   
    hp = TUTORget_entry_mem(mm); /* ptr to table entry */
    if (!hp->theH)
        TUTORdump("Invalid handle in GetPtr");
    if (hp->lockcount == 0) {
        cp = GlobalLock(hp->theH);
        if (hp->suballoc)
            cp += hp->offset;
        hp->area = cp;
    }
    hp->lockcount++; /* keep track of how many times handle locked */
    if (hp->area == FARNULL)
        TUTORdump("No pointer in GetPtr");
    return(hp->area);
    
} /* GetPtr */

#pragma check_stack(off)

/* ******************************************************************* */

extern int ReleasePtr(mm) /* release locked handle */
Memh mm; /* ct handle */

{    struct htab SHUGE *hp; /* pointer to handle table entry */

    hp = TUTORget_entry_mem(mm); 
    if (!hp->lockcount)
        TUTORdump("handle unlocked too many times");
    if (hp->lockcount == 1) {
        GlobalUnlock(hp->theH);
        hp->area = FARNULL;
    }
    hp->lockcount--;
    
} /* ReleasePtr */

/* ******************************************************************* */

struct htab SHUGE *TUTORget_entry_mem(mm) 
/* get pointer to handle table entry */
Memh mm; /* ct handle */

{
    if (!mm)
        TUTORdump("Invalid handle in GetEntry");
    return(htabP+mm); 
    
} /* TUTORget_entry_mem */

/* ******************************************************************* */

int TUTORset_hsize(mm,size,abort) /* set size of ct handle */
Memh mm; /* ct handle */
long size; /* new size for handle */
int abort; /* TRUE if should abort if can't find memory */

{   struct htab SHUGE *ourhP; /* pointer to handle table entry */
    long ourLen; /* current size of handle */
    Memh tempH; /* temporary cT handle */
    struct htab SHUGE *temphP; /* pointer to temp handle table entry */
    struct htab scrtab; /* scratch table entry */
    char FAR *fromP; /* from pointer for move */
    char FAR *toP; /* to pointer for move */
    long moveLen; /* amount to move */
   
    /* create (temporary) cT handle */

    tempH = TUTORhandle(" ",size,0); /* allocate new handle */
    if (tempH == HNULL) {
        if (abort)
	    TUTORdump(memStr);
        return(FALSE);
    } /* tempH if */

    /* copy contents of current handle to temporary */

    ourLen = TUTORget_hsize(mm);
    if (size > ourLen) 
        moveLen = ourLen; /* move existing data */
    else
        moveLen = size; /* move some of existing data */
    fromP = GetPtr(mm); /* point to current data */
    toP = GetPtr(tempH); /* point to new area */
    TUTORblock_move(fromP,toP,moveLen);
    ReleasePtr(mm);
    ReleasePtr(tempH);

    /* point handle to contents of temporary, dump temporary */

    ourhP = TUTORget_entry_mem(mm); 
    if (ourhP->lockcount)
        TUTORdump("attempt to resize locked handle");
    temphP = TUTORget_entry_mem(tempH);
#ifdef MEMVERIFY
    strncpyf(temphP->label,ourhP->label,8);
#endif
    scrtab = *ourhP;
    *ourhP = *temphP; /* swap contents of temp/current */
    *temphP = scrtab;
    TUTORfree_handle(tempH); /* release temporary handle */
    return(TRUE);

} /* TUTORset_hsize */

/* ******************************************************************* */

char FAR *TUTORalloc(size,abort,label) /* allocate fixed memory */
long size; /* amount of memory required */
int abort; /* TRUE if should abort on failure */
char *label; /* label for debugging */

{    Memh ii; /* index in memory table */
    
    ii = TUTORhandle(label,size,FALSE);
    if (!ii) {
        if (abort)
	    TUTORdump(memStr);
        return(FARNULL); /* didn't allocate memory */
    }
    return(GetPtr(ii)); /* return address */
    
} /* TUTORalloc */

/* ******************************************************************* */

int TUTORdealloc(ptr) /* deallocate fixed memory */
char FAR *ptr; /* pointer to region to deallocate */

{    int ii;
    struct htab SHUGE *hp; /* pointer in handle table */
    
    if (ptr == FARNULL)
        TUTORdump("attempt to deallocate null pointer");
    for (ii=1, hp=htabP+1; ii<hmallocN; ii++, hp++) {
        if ((long)(hp->area) == (long)(ptr)) {
            ReleasePtr(ii); /* unlock handle */
            TUTORfree_handle(ii); /* release this handle/memory */
            return(0);
        } /* area if */
    } /* for */
    TUTORdump("dealloc of bad pointer");
    return(0);
    
} /* TUTORdealloc */

/* ******************************************************************* */

char FAR *TUTORrealloc(ptr,oldsize,newsize,abort) 
/* change size of fixed memory area */
char FAR *ptr; /* pointer to area to reallocate */
long oldsize; /* previous size of area */
long newsize; /* new size for area */
int abort; /* TRUE if should abort on failure */

{    int ii;
    Memh theH; /* ct handle on area */
    struct htab SHUGE *hp; /* pointer in handle table */
    
    if (ptr == FARNULL)
        TUTORdump("attempt to reallocate null pointer");
        
    theH = HNULL; /* dont know handle yet */
    for (ii=1, hp=htabP+1; ii<hmallocN; ii++, hp++) {
        if ((long)(hp->area) == (long)(ptr)) {
            theH = ii; /* ct handle on area */
            break; /* exit for */
        } /* area if */
    } /* for */
    
    if (!theH)
        TUTORdump("realloc of bad pointer");
        
    ReleasePtr(theH); /* release handle */
    TUTORset_hsize(theH,newsize,TRUE); /* reallocate handle */
    hp->area = GetPtr(theH); /* freeze handle again */
    return(hp->area); /* return pointer to area */

} /* TUTORrealloc */

/* ******************************************************************* */

mw_mem_map() /* dump memory map to file */

{   FILE *mfp; /* memory map file */
    FileRef mapname; /* map file name */
    long hii; /* index in handles */
    struct htab SHUGE *hp; /* pointer in handle table */
    char label[16]; /* handle descriptive name */
    struct subfree FAR *sP;


    /* build map file name */

    assoc_name(&sourcetable[0].fRef,(FileRef FAR *)&mapname,".map");

    /* open map file */

    mfp = fopen(mapname.path,"w");
    if (mfp == NULL) return(0); /* couldn't open file */
   
    /* write handle information to file */

    for(hii=0; hii<hmallocN; hii++) {
        hp = htabP+hii;
        if (hp->theH) { /* handle exists */
            strncpyf((char FAR *)label,hp->label,8);
            label[8] = 0; /* ensure terminated */
            strcat(label,"        ");
            label[8] = 0; /* label is now space filled */
            fprintf(mfp,"%5lx %s %4x %8lx %6lx %2d \n",hii,label,(unsigned int)hp->theH,
                   (long)hp->area,(long)hp->size,hp->lockcount);
            if (hp->suballoc) 
                fprintf(mfp,"               %4x %4x\n",hp->offset,hp->realsize);
        }
    } /* hii for */
    fprintf(mfp,"\n");

    /* write free list information to file */

    for(hii=0; hii<nSubFree; hii++) {
        sP = subP+hii;
        fprintf(mfp,"%5lx %4x %4x %4x\n",hii,(unsigned int)sP->theH,sP->offset,sP->size);
    } /* for */
    fprintf(mfp,"\n");

    fclose(mfp);
    return(0);

} /* mw_mem_map */

/* ******************************************************************* */
