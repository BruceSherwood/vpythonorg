/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "baseenv.h"
#include "tglobals.h"
#include "exprdefs.h"
#include "yacc.h"
#include "compute.h"
#include "cglobals.h"
#include "ct_ctype.h"
#include "txt.h"
#include "commands.h"

#ifdef ctproto
int  Seekunit(unsigned int  sdoc,long  *loc);
int  n_StartTempCompile(unsigned int  doc,long  pos,long  len);
int  n_FinishTempCompile(int  savci);
int  FillBuffer(unsigned int  readDoc,long  readPos,long  maxRead);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
long  TUTORsearch_string_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sLen,long  pos,long  posEnd);
char  FAR *GetPtr(unsigned int  mm);
#endif /* ctproto */

extern long TUTORget_len_doc();
extern long  TUTORsearch_string_doc();


/* ******************************************************************* */

Seekunit(sdoc,loc) /* seek a -unit- / -use-  command */
			/* return TRUE if found a unit/use */
			/* sets seekcmd to last command found */
			/* loads command buffer with unit/use tag */
Memh sdoc; /* source document */
long *loc; /* position of command found */

{	int fnd;	/* TRUE if found a match */
	long doctst;	/* end test on source document */
	long doclen;	/* length of source document */
	long fstart;	/* start of found target */
	long flen;	/* length of found target */
	char ts[3];	/* target string */
	char fs[18];	/* found string */
	char *fsp;	/* pointer in found string */
	char ns[18];	/* normalized string */
	char *nsp;	/* pointer in normalized string */
	char cc;	/* current character code */
	DocP dp;

	ts[0] = NEWLINE; /* search for newline, u(nit) or u(se) */
	ts[1] = 'u';
	ts[2] = 0;
	seekcmd = 0; /* nothing yet - not unit, use */

	dp = (DocP) GetPtr(sdoc);
	doclen = dp->totLen;
	doctst = doclen - 3;
	ReleasePtr(sdoc);
	KillPtr(dp);

	while (srcPos < doctst) {

		/* search for next newline, u(nit) or u(se) */

		dp = (DocP) GetPtr(sdoc);
		fstart = TUTORsearch_string_doc(dp,(unsigned char FAR *) ts,2L,srcPos,doctst+3);
		ReleasePtr(sdoc);
		KillPtr(dp);
		if (fstart < 0)
			break; /* not found */

		/* extract and normalize possible command string */

		fstart++; /* advance past newline */
		TUTORget_string_doc(sdoc,fstart,16L,(unsigned char FAR *) fs);
		fsp = fs;	/* initialize pointers */
		nsp = ns;
		do {
			if ((cc = *fsp++) != ' ')
				*nsp++ = cc;
		} while (cc && (cc != '\t'));

		/* check for unit or use command */
		
		*loc = fstart;
		srcPos = fstart; /* advance for next search */
		if (strncmp(ns,"unit\t",5) == 0) {
			seekcmd = C_UNIT;
		} else if (strncmp(ns,"use\t",4) == 0) {
			seekcmd = USE;
		} /* use else if */
		if (seekcmd) {

			/* load command buffer with tag of unit/use */

			srcPos += nsp-ns; /* advance to tag */
 			FillBuffer(sdoc,srcPos,doclen-srcPos);
 			cI = 0;
			return(TRUE);
		} /* seekcmd if */
	} /* while */

	*loc = srcPos = doclen;

	return(FALSE);

} /* Seekunit */

/* ******************************************************************* */

n_StartTempCompile(doc,pos,len) /* start temp compile of other doc */
Memh doc;
long pos, len; /* position & length in doc */
/* returns old position of cI (to be restored in n_FinishTempCompile) */
	
{	int savci;

	savci = cI;
	srcPos = pos;
	FillBuffer(doc,pos,len);
	cI = 0;
	exa->src[len] = NEWLINE;
	
	return(savci);

} /* n_StartTempCompile */

/* ******************************************************************* */

n_FinishTempCompile(savci)
int savci;
	
{
	cI = savci;
}

/* ******************************************************************* */

FillBuffer(readDoc,readPos, maxRead) /* fill compile (source) buffer with 1 line */
Memh readDoc; /* document to read from */
long readPos; /* position to start reading */
long maxRead; /* maximum # of chars to read */
	
{	long nRead; /* # of chars to read */
	static int bufferSize; /* total # of chars still in buffer */
	static unsigned char saveChar; /* character saved (overwritten by NULL) */
	char isContinued;
	register unsigned char *cp, *ce;

	if (!readDoc) { /* initialization */
		lastBufferDoc = 0;
		bufferSize = 0;
		return(0);
	}

	buffFull = FALSE;
	ciStart = 0; /* always, with current implementation */

	if (maxRead <= 0) { /* out of input */
		nBuffChars = 0;
		return(0);
	}

	if (readDoc == lastBufferDoc && nextBufferPos == readPos) { 
		/* continued read */
		isContinued = TRUE;
		/* restore char overwritten by null */
		cp = cB+nBuffChars;
		ce = cB+bufferSize;
		*cp = saveChar;
		/* find next newline position */
		while(cp < ce && *cp && *cp != NEWLINE)
			cp++;
		if (cp >= ce)
			isContinued = FALSE;
	} else
		isContinued = FALSE;
	
	if (!isContinued || *cp != NEWLINE) { /* need to recharge buffer */
		lastBufferDoc = readDoc;
		nRead = (maxRead > CBUFFSIZE) ? ((long) CBUFFSIZE) : maxRead;
		/* copy text into string */
		bufferSize = TUTORget_string_doc(readDoc,readPos,nRead,
		                     (unsigned char FAR *)cB); 
		if (bufferSize <= 0) { /* end of document, no chars at all */
			cB[0] = '\0';
			nBuffChars = 0;
			return(0);
		}

		/* find newline */
		cp = cB;
		while (*cp && *cp != NEWLINE)
			cp++;
		
		if (*cp != NEWLINE) {
			/* didn't find NEWLINE.  Could be end of document, or too long line */
			if (cp - cB >= CBUFFSIZE) {
				buffFull = TRUE; /* too long line */
				cp--; /* to point at last char in line */
			} else if (bufferSize > 0) {
				/* end of document without newline at end, */
				/* append newline (in buffer) */
				*cp = NEWLINE;
				*(cp+1) = '\0';
				bufferSize++;
				srcEnd++; /* make source look 1 larger */
			} /* bufferSize else */
		} /* newline if */
	} else { /* shift line down to begin of buffer */
		TUTORblock_move((char SHUGE *)(cB+nBuffChars),(char SHUGE *)cB,
		               (long)(bufferSize-nBuffChars+1));
		bufferSize -= nBuffChars;
		cp -= nBuffChars;
	} /* isContinued else */
	
	/* at this point cp points at last char in line (usually NEWLINE) */
	nBuffChars = 1 + (int) (cp - cB);
	saveChar = *(++cp);
	*cp = '\0'; /* null terminate for compiler */
	nextBufferPos = readPos + nBuffChars;

	return(0);
	
} /* FillBuffer */

/* ******************************************************************* */


