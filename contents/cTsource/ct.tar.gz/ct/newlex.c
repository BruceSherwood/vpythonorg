/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "baseenv.h"
#include "tglobals.h"
#include "exprdefs.h"
#include "yacc.h"
#include "compute.h"
#include "cglobals.h"
#include "ct_ctype.h"
#include "txt.h"
#include "commands.h"
#include "fkeys.h"

#ifdef ctproto
extern int strncmpf(char FAR *aa,char FAR *bb,int nn);
int  pbscan(unsigned char  FAR *str,int  indx,char *target);
int TUTORchecksum(char FAR *addr,long length);
int  yylex(void);
extern int  lex_key(void);
extern int lex_style(void);
struct  keywdinf *GetKeyNames(void);
extern int  lex_normal(void);
int  n_restart(void);
extern int  lexaction(int  firstC,int  action);
extern int  lcompare(char  *ss);
extern int  lcompare2(char  *ss);
int  initlex(struct  expra *initcmp);
int  n_getkeyname(struct  expra *initcmp);
extern int  namelex(int  cc);
extern int  lexnum(int  firstC);
int  n_myinput(void);
int  n_myunput(int  nc);
extern int  badchar(void);
extern int  checkzk(void);
extern int  plstr(void);
extern int  pembed(void);
extern int  badembed(int  n);
extern int  touch_offset(void);
int  lexname(int  partial,char  *yytext,int  yyleng);
int  TUTORdump(char  *s);
int  getnum(char  *s,int  *floatf,long  *i,double  *d,char  * *errm,int  *errn);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
int  tdoc_is_string(unsigned int  theD,long  pos,long  len);
#endif /* ctproto */

extern long TUTORget_len_doc();
struct keywdinf *GetKeyNames();

#define YYLMAX 200

#define LBAD 0
#define LNOTEQ 1
#define LLEQ 2
#define LLT 3
#define LGEQ 4
#define LGT 5
#define LEQ 6
#define LNOT 7
#define LNUMBER 8

static char lexState; /* if 0 normal */
                      /*    1 processing zk argument */
                      /*    2 processing 1st zhasstyle argument */
                      /*    3 processing 2nd zhasstyle argument */
static short tokenLen;  /* length of current token (for some tokens), used for n_restart */
static short styleParencnt; /* parencnt at start of zhasstyle processing */

struct keyndat {
	char *name;
	short code;
};

static struct keywdinf keynames[] = {
	"all",KALL,
	"back",KBACK,
	"begin_line",KBEGLINE,
	"begin_line_extend",KBEGLINE+1,
	"begin_file",KBEGFILE,
	"begin_file_extend",KBEGFILE+1,
	"begin_file_scroll",KSBEGFILE,
	"begin_page",KBEGPAGE,
	"begin_page_extend",KBEGPAGE+1,
	"comma",',',
	"copy",KCOPY,
	"cr",KCR,
	"cut",KCUT,
	"down_arrow",KDOWN,
	"down_arrow_extend",KDOWN+1,
	"end_line",KENDLINE,
	"end_line_extend",KENDLINE+1,
	"end_file",KENDFILE,
	"end_file_extend",KENDFILE+1,
	"end_file_scroll",KSENDFILE,
	"end_page",KENDPAGE,
	"end_page_extend",KENDPAGE+1,
	"erase",KERASE,
	"erase_fwd",KFWDDEL,
	"escape",KESCAPE,
	"ext",KEXT,
	"fa",KFA,
	"fb",KFB,
	"fc",KFC,
	"fd",KFD,
	"help",KHELP,
	"left",KTOUCH+1,
	"left_arrow",KLEFT,
	"left_arrow_extend",KLEFT+1,
	"next",KNEXT,
	"page_up",KPAGEUP,
	"page_up_extend",KPAGEUP+1,
	"page_up_scroll",KSPAGEUP,
	"page_down",KPAGEDOWN,
	"page_down_extend",KPAGEDOWN+1,
	"page_down_scroll",KSPAGEDOWN,
	"paste",KPASTE,
	"right",KTOUCH+2,
	"right_arrow",KRIGHT,
	"right_arrow_extend",KRIGHT+1,
	"space",' ',
	"tab",KTAB,
	"tab_back",KBACKTAB,
	"timeup",KTIMEUP,
	"touch",KTOUCH,
	"transpose",KTRANSPOSE,
	"undo",KUNDO,
	"up_arrow",KUP,
	"up_arrow_extend",KUP+1,
	NULL,0
};

struct keywdinf stylelist[33] = { {"plain",KW_PLAIN}, 
       {"bold",KW_BOLD}, {"italic",KW_ITALIC}, {"hot",KW_HOTSTYLE},  
       {"plainest",KW_PLAINEST}, {"superscript",KW_SUPSCRIPT},
       {"subscript",KW_SUBSCRIPT}, {"full justify",KW_FULLJUST},
       {"left justify",KW_LEFTJUST}, {"right justify",KW_RIGHTJUST},
       {"center",KW_CENTER}, {"black",KW_BLACK}, {"white",KW_WHITE},
       {"red",KW_RED}, {"green",KW_GREEN}, {"blue",KW_BLUE},
       {"yellow",KW_YELLOW}, {"cyan",KW_CYAN}, {"magenta",KW_MAGENTA},
       {"default color",KW_DEFCOLORST}, 
       {"serif",KW_SERIF}, {"sans serif",KW_SANS}, {"fixed",KW_TYPEWRITER},
       {"symbol",KW_SYMBOL}, {"bigger",KW_BIGGER}, {"smaller",KW_SMALLER}, 
       {"icon",KW_ICON}, {"screen",KW_IMAGESTYLE},
       {"fulljustify",KW_FULLJUST}, {"leftjustify",KW_LEFTJUST},
       {"rightjustify",KW_RIGHTJUST}, {"sansserif",KW_SANS},
       {NULL,0} };
       
yylex()
	
{   int returnv;
    if (lexState == 0)
        returnv = lex_normal();
    else if (lexState == 1)
        returnv = lex_key();
    else if (lexState == 2)
    	returnv = lex_normal();
    else if (lexState == 3)
    	returnv = lex_style();
    return(returnv);

} /* yylex */

static lex_key()
	{
	int lexval;
	unsigned char FAR *sstr; /* source string */
	register unsigned char FAR *s1, *s2; /* temp pointers */
	unsigned char cSave;	/* for saving char that is replaced by null for termination */
	char c1,c2;
	unsigned char FAR *sSave;	/* where we got cSave */
	int listInd;
	
	lexState = 0; /* return to normal lexical state */
	lexval = 0; /* bad */
	
	/* what we are looking at: */
	sstr = exa->src + (*exa->srcpos);
	/* terminate it for string compare: */
	s1 = sstr;
	while (CTisalpha(*s1) || (*s1 == '_'))
		s1++;
	cSave = *s1;
	*s1 = '\0';
	sSave = s1;
	
	/* linear search thru keynames */
	listInd = 0;
	while (keynames[listInd].name)
		{
		s1 = sstr;
		s2 = (unsigned char *) keynames[listInd].name;
		while (*s2 && *s1 == *s2)
			{
			s1++;
			s2++;
			}
		if (!*s2 && !*s1)
			{ /* found complete match */
			*exa->srcpos += (s1 - sstr); /* skip over input we've used */
			break;
			}
		listInd++;
		}
	/* restore source */
	*sSave = cSave;
	
	lexval = keynames[listInd].value;
	if (lexval > 0)
		{ /* we found match */
		if (lexval == KTOUCH+1 || lexval == KTOUCH+2)
			{ /* special processing for left & right */
			c1 = n_myinput(); /* eat up optional : */
			if (c1 != ':')
				n_myunput(1);
			/* fix left & right */
			lexval = (lexval == KTOUCH+1) ? KTOUCH : KTOUCH+3;
			/* now handle down, move, up */
			lexval += touch_offset();
			}
		}
	else
		{ /* not a keyword, may still be zk(A) or whatever */
		/* make sure it is only one character */
		c1 = n_myinput(); /* get the possible character of zk */
		c2 = n_myinput(); /* peek at next char (should be right paren) */
		n_myunput(1);
		if (c2 == ')')
			lexval = c1;
		else
			{ /* more than 1 char - error */
			yylval.ival = -1;
			exa->errmess = "Unrecognized keyname.";
			exa->errnum = NAMEERR;
			return(NAMEERR);
			}
		}
	
	yylval.ival = lexval;
	return(previous = checkzk());
	}

static int lex_style()

{	unsigned char FAR *sstr; /* pointer to source string */
	char lstr[32]; /* local copy of string */
	char *strP; /* pointer in string */
	int ii,ni;
	
	lexState = 0; /* return to normal lexical state */
	
	/* what we are looking at: */
	sstr = exa->src + *exa->srcpos; /* point after comma */
	ni = 0;
	while (CTisalpha(*sstr) || (*sstr == ' ')) {
		lstr[ni++] = *sstr++;
		if (ni >= 30)
			break; /* string too long */
	} /* while */
	lstr[ni] = 0;
	
	if (ni) {
		strP = &lstr[ni-1];
		while ((*strP == ' ') && (strP > &lstr[0]))
			*strP-- = 0; /* remove trailing spaces */
	}
	strP = &lstr[0];
	while (*strP == ' ')
		strP++; /* remove leading spaces */
		
	/* search stylelist for this keyword */
	
	ii = 0;
	while (stylelist[ii].name) {
		if (strcmp(stylelist[ii].name,strP) == 0) {
			yylval.lval = stylelist[ii].value;
			*exa->srcpos += ni; 
			return(previous = ILITERAL);
		}
		ii++;
	} /* while */
	return(0);
}

struct keywdinf *GetKeyNames() /* so -pause- compilation can access keyname list */
	{
	return (&keynames[0]);
	}

static lex_normal()
	{
	unsigned char cc, c1, c2;
	int lexval;

	lexval = LBAD;
	cc = n_myinput(); /* first character of token */

	switch(cc)
		{
		/* case NEWLINE: */
		case '\n':
		case '\r':
			exa->lastchar = NEWLINE;
			return(0);	
		case '!':
			if (n_myinput() == '=')
				lexval = LNOTEQ;
			break;
		case '"':
			return(previous = plstr());
		case '#':
			lexval = LNUMBER;
			break;
		case '$':
			if (lcompare("and"))
				lexval = AND;
			else if (lcompare("di"))
				{
				if (lcompare("vr"))
					lexval = IDIVR;
				else if (lcompare("vt"))
					lexval = IDIVT;
				else if (lcompare("ff"))
					lexval = LDIFF;
				}
			else if (lcompare("mask"))
				lexval = LMASK;
			else if (lcompare("lsh"))
				lexval = LSHIFT;
			else if (lcompare("or"))
				lexval = OR;
			else if (lcompare("rsh"))
				lexval = RSHIFT;
			else if (lcompare("union"))
				lexval = LUNION;
			
			if (lexval != LBAD && n_myinput() != '$')
				lexval = LBAD; /* not properly terminated */
			if (lexval != LBAD)
				return(previous = lexval);
			break;
		case '%':
			if (parencnt == 0 && exa->tpercent)
				{
				exa->lastchar = '%';
				return(0);
				}
			return(badchar());
		case '&':
			return(previous = AND);
			break;
		case '(':
		case '[':
		case '{':
			if ((previous == FLITERAL) || (previous == ILITERAL) || 
					(previous == RIGHTPAREN) ||
					(exa->userc && previous == GLOBALVAL) ) 
				{
				n_myunput(1); /* so we will pick up # next time */
				return(previous=TIMES);
				}
			parencnt++;
			switch (cc)
				{
				case '(' : yylval.ival = 1; break;
				case '[' : yylval.ival = 2; break;
				case '{' : yylval.ival = 3; break;
				}
			return(previous=LEFTPAREN);
		case ')':
		case ']':
		case '}':
			if (parencnt==0 && (exa->tparen))
				{
				exa->lastchar = cc;
				return(0);
				}
       		parencnt--;
			switch (cc)
				{
				case ')' : yylval.ival = 1; break;
				case ']' : yylval.ival = 2; break;
				case '}' : yylval.ival = 3; break;
				}
			return(previous = RIGHTPAREN); 
		case '*':
			if (n_myinput() == '*')
				return(previous = EXPONENT);
			else
				{
				n_myunput(1);
				return(previous = TIMES);
				}
			break;
		case 0xd7:
			return(previous = TIMES);
		case '+':
			return(previous = PLUS);
		case ',':
			if ((parencnt!=0) || (embedcnt != 0)) {
				if ((lexState == 2) && (parencnt == (styleParencnt+1)))
					lexState = 3; /* process 2nd arg of zhasstyle */
				return(previous = COMMA);
			}
			exa->lastchar = ',';
			return(0);
		case '-':
			return(previous = MINUS);
			break;
		case '.':
			lexval = LNUMBER;
			break;
		case '/':
		case 0xf7:

			return(previous = DIVIDE);
		case '0': case '1': case '2': case '3': case '4':
		case '5': case '6': case '7': case '8': case '9':
		case 0xbc: case 0xbd: case 0xbe:
			lexval = LNUMBER;
			break;
		case ':':
			if (n_myinput() == '=')
				{ /* assignment */
				if (parencnt==0 && (exa->tassign))
					{
					exa->lastchar = '=';
					return(0);
					}
				return(previous = ASSIGN);
				}
			else
				{ /* bare colon */
				n_myunput(1);
				if (parencnt == 0 && exa->tcolon)
					{
					exa->lastchar = ':';
					return(0);
					}
				return(badchar());
				}
			break;
		case ';':
			exa->lastchar = ';';
			return(0);
		case '<':
			if (exa->src[(*exa->srcpos)] == '|')
				{ /* left embed */
				(*exa->srcpos)++; /* advance over | */
				return(pembed());
				}
			c1 = n_myinput();
			if (c1 == '=')
				lexval = LLEQ;
			else if (c1 == '>')
				lexval = LNOTEQ;
			else
				{
				n_myunput(1);
				lexval = LLT;
				}
			break;
		case '=':
			c1 = n_myinput();
			if (c1 == '<')
				{
				if (exa->src[*exa->srcpos] == '|')
					{ /* we are about to get an embed, but first do = */
					lexval = LEQ;
					n_myunput(1); /* undo "<" */
					}
				else
					lexval = LLEQ;
				}
			else if (c1 == '>')
				lexval = LGEQ;
			else
				{
				n_myunput(1);
				lexval = LEQ;
				}
			break;
		case '>':
			c1 = n_myinput();
			if (c1 == '=')
				lexval = LGEQ;
			else
				{
				n_myunput(1);
				lexval = LGT;
				}
			break;
		case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': case 'G': case 'H': 
		case 'I': case 'J': case 'K': case 'L': case 'M': case 'N': 
		case 'O': case 'P': case 'Q': case 'R': case 'S': case 'T': case 'U': case 'V': 
		case 'W': case 'X': case 'Y': case 'Z':
		case 'a': case 'b': case 'c': case 'd': case 'e': case 'f': case 'g': 
		case 'h': case 'i': case 'j': case 'k': case 'l': case 'm': 
		case 'n': case 'o': case 'p': case 'q': case 'r': case 't': 
		case 'u': case 'v': case 'w': case 'x': case 'y':
			lexval = namelex(cc);
			return(lexval);
			break;
		case '\\':
			if (parencnt==0 && (exa->tcond))
				{
				exa->lastchar = '\\';
				return(0);
				}
			return(badchar());
		case '^':
			return(previous = EXPONENT);
			break;
		case 's':
			if (lcompare2("kip"))
				return(SKIP);
			else
				return(namelex(cc));
			break;
		case 'z':
			if (lcompare("k("))
				{
				if (n_myinput() == ')')
					{
					if (exa->src[(*exa->srcpos) - 2] == ' ')
						{ /* zk( ), namely zk(space) */
						yylval.lval = ' ';
						return(previous = ILITERAL);
						}
					else if (n_myinput() == ')')
						{ /* zk()), namely zk(right paren) */
						yylval.lval = ')';
						return(previous = ILITERAL);
						}
					else
						{ /* bad form */
						n_myunput(1); /* put back attempt to find ')' */
						yylval.ival = -1;
						exa->errmess = "Unrecognized keyname.";
						exa->errnum = NAMEERR;
						return(NAMEERR);
						}
					}
				else
					{
					n_myunput(1);
					lexState = 1; /* we now want to look at keys */
					return(previous = ZK);	
					}
				}
			else {
				lexval = namelex(cc);
				if (lexval == ZHASSTYLE) {
					lexState = 2; /* first argument of zhasstyle */
					styleParencnt = parencnt;
				} /* zhasstyle if */
				return(lexval);
			}
			break;
		
		case '|':
			if (exa->src[(*exa->srcpos)] == '>')
				{
				(*exa->srcpos)++;
				if ((exa->tembed) && (embedcnt == 0))
					{
					if (parencnt)
						return(badembed(3));
					exa->lastchar = '>';
					return(0);
					}
				else
					{
					embedcnt--;
					yylval.ival = 0;
					return(previous = SRIGHTEMBED); 
					}
				}
			else
				return(previous = OR);
			break;
		case '~':
			c1 = n_myinput();
			if (c1 == '>' || c1 == '<')
				{
				c2 = n_myinput();
				if (c2 == '=')
					{
					if (c1 == '>')
						lexval = LLT;
					else
						lexval = LGT;
					}
				else
					{
					n_myunput(1);
					if (c1 == '>')
						lexval = LLEQ;
					else
						lexval = LGEQ;
					}
				}
			else if (c1 == '=')
				lexval = LNOTEQ;
			else
				{
				n_myunput(1);
				return(previous = UNOT);
				}
			break;
		} /* end of switch */
	
	if (lexval == LBAD)
		return(badchar());
	else
		return(lexaction(cc,lexval));
	}

n_restart()
	{
	n_myunput(tokenLen);
	}

static lexaction(firstC,action)
int firstC; /* first character of token */
int action;
	{
	switch(action)
		{
		case LNUMBER:
			if (previous == RIGHTPAREN)
				{
				n_myunput(1); /* so we will pick up # next time */
				return(previous = TIMES);
				}
			return(lexnum(firstC));
		case LLT:
			yylval.ival = LT;
			return(previous = RELOP);
		case LGT:
			yylval.ival = GT;
			return(previous = RELOP);
		case LLEQ:
			yylval.ival = LE;
			return(previous = RELOP);
		case LGEQ:
			yylval.ival = GE;
			return(previous = RELOP);
		case LEQ:
			yylval.ival = EQ;
			return(previous = RELOP);
		case LNOTEQ:
			yylval.ival = NE;
			return(previous = RELOP);
		default:
			break;
		}
	
	TUTORdump("Unrecognized token in lexaction");
	return(0);
	}
	
static lcompare(ss)
register char *ss;
	{
	register int count;
	
	count = 1;
	while (*ss)
		{
		if (n_myinput() != *ss++)
			{
			n_myunput(count);
			return(FALSE);
			}
		count++;
		}
	return(count); /* > 0 so TRUE */
	}

static lcompare2(ss)  /* do lcompare and also check whether this string could be variable */
char *ss;
	{
	int count;
	unsigned char cc;
	
	count = lcompare(ss);
	if (!count)
		return(FALSE);
		
	/* now look at next char, could this be a variable name? */
	cc = n_myinput();
	if (CTisalnum(cc) || cc == '_')
		{ /* really a variable name */
		n_myunput(count);
		return(FALSE);
		}
	
	n_myunput(1); /* put back the char we checked */
	return(TRUE); /* really just a literal */
	}

initlex(initcmp)
struct expra *initcmp;
	
{
    previous = 0;
    exa = initcmp;
    lexState = 0;

} /* initlex */

#ifndef EXECUTE

n_getkeyname(initcmp)
struct expra *initcmp;
	{
	exa = initcmp;
	lex_key();
	return( yylval.ival );
	}

#endif  /* end ifndef EXECUTE */


static namelex(cc)
int cc; /* first char of token */
	{
	unsigned char yytext[YYLMAX];
	int yyleng;
	int c2;
	int returnv;
	
	yytext[0] = cc;
	yyleng = 1;
	
	/* accumulate chars that are letters or digits */
	while (yyleng < YYLMAX-1)
		{
		c2 = n_myinput();
		if (!CTisalnum(c2) && c2 != '_')
			break;
		yytext[yyleng++] = c2;
		}
	n_myunput(1); /* put back char we didn't like */
	
	yytext[yyleng] = '\0'; /* null terminate */

	tokenLen = yyleng;  /* so a possible restart knows how many chars to put back */
	returnv = lexname(TRUE,(char *) yytext,yyleng);
	return(returnv);
	}

static lexnum(firstC)
int firstC;
	{
	unsigned char yytext[YYLMAX];
	register int cc;
	int len;
	int floatf;
	long inum;
	double fnum;
	char haveBase, haveDecimal, haveExp, haveExpNum, haveExpSign;
	int nc,cpos;

	
	if (firstC >= 0xbc && firstC <= 0xbe)
		{ /* vulgar fraction - single character number */
		if (firstC == 0xbc)
			yylval.dval = 0.25;
		else if (firstC == 0xbd)
			yylval.dval = 0.5;
		else
			yylval.dval = 0.75;
		return(previous = FLITERAL);
		}
	
	haveBase = haveDecimal = haveExp = haveExpNum = haveExpSign = FALSE;
	
	yytext[0] = firstC;
	len = 1;
	if (firstC == '#')
		haveBase = TRUE;
	else if (firstC == '.')
		haveDecimal = TRUE;
	
	/* accumulate appropriate chars in yytext */
	while(len < YYLMAX-1)
		{
		cc = n_myinput();
		if (CTisdigit(cc))
			{
			if (haveExp)
				haveExpNum = TRUE;
			}
		else if (cc == '+' || cc == '-')
			{
			if (haveExpSign || !haveExp || haveExpNum)
				break; /* already have sign or it isn't allowed */
			haveExpSign = TRUE;
			}
		else if (cc == '.')
			{
			if (haveDecimal) {
				exa->errnum = DECERR;
				exa->errmess = "Too many decimal points";
				return(DECERR);
			}
			if (haveBase || haveExp)
				break; /* we already have decimal point, or decimal point not allowed */
			haveDecimal = TRUE;
			}
		else if (cc == 'E' || cc == 'e') {
			if (!haveBase && haveExp)
				break; /* we already have exponent */
			if (!haveBase) {
				cpos = *exa->srcpos;
				nc = n_myinput();
				if ((nc == '-') || (nc == '+'))
					nc = n_myinput();
				*exa->srcpos = cpos;
				if (!CTisdigit(nc)) 
					break; /* name beginning with E/e */
				haveExp = TRUE;
			}
		} else if ((cc >= 'A' && cc <= 'F') || (cc >= 'a' && cc <= 'f'))
			{
			if (!haveBase)
				break; /* illegal char if we aren't in special base */
			}
		else if (cc == '#')
			{
			if (haveBase || haveDecimal || haveExp)
				break; /* already have base or base not allowed */
			haveBase = TRUE;
			}
		else
			break; /* character that can't be part of a number */
		yytext[len++] = cc;
		}
	n_myunput(1); /* put back character we didn't like */
	yytext[len] = '\0';
	
	if (len == 1 && (firstC == '.' || firstC == '#'))
		return(badchar()); /* not actually a number */
	
	/* get the number */
	getnum((char *) yytext, &floatf, &inum, &fnum,&exa->errmess,&exa->errnum);

	if (floatf)
		{
		yylval.dval = fnum;
		return(previous=FLITERAL);
		} 
	else
		{
		yylval.lval = inum;
		return(previous=ILITERAL);
		}
	}

/* ****************************************************************** */

/* read & unread the source.  Note that exa->srcpos always should point to the
   next character to be read */

int n_myinput()	/* read next character, skipping white space */
	{
	register unsigned char cc;
	
	do
		{
		cc = exa->src[(*exa->srcpos)++];
		} while (cc == ' ' || (cc == '\t' ));
	return (cc);
	}

n_myunput(nc)
int nc; /* # of chars to back up (we also back up over white space) */
	{
	register unsigned char cc;
	register long pos;
	
	pos = *exa->srcpos;
	while(nc >= 0 && pos > 0) /* pos check so we don't go too far */
		{
		cc = exa->src[--pos];
		if (cc != ' ' && cc != '\t')
			nc--;
		}
	
	if (nc < 0)
		*exa->srcpos = pos+1;
	else
		*exa->srcpos = 0L;
	}

static badchar()
	{
	exa->errnum = CHARERR;
	exa->errmess = "Illegal character.";
	return(CHARERR);
	}

/* ******************************************************************* */

static checkzk()  /* check that keyname ends properly */

{	unsigned char c;

	/* c = exa->src[(*exa->srcpos)-1]; -- old, after reading too far */
	c = n_myinput();
	switch (previous) {

	case ZK: 
		if (c==')') return(KEYNAME);
   		exa->errmess = "Missing right parenthesis.";
		exa->errnum = NAMEERR;
		return(NAMEERR);

	case QUOTE: 
		exa->errmess = "Missing quotation mark.";
		exa->errnum = NAMEERR;
		return(NAMEERR);

	default:
		if (c==',' || c== NEWLINE || c=='(') return(KEYNAME);
		yylval.ival = -1;
		return(NAMEERR);
	}  /* switch */

} /* checkzk */

/* ******************************************************************* */

static plstr()  /* process string literal */ 
	
{   long spos,epos; /* start/end positions */
    long cpos; /* current position */
    long lepos; /* left  embed position */
    long repos; /* right embed position */
    unsigned char c2[2];
    int legal; /* legal-so-far */
    int i; /* index in string */
    int lth; /* original length of string */
    int embed; /* within embed flag */
    int mlitcf; /* TRUE if optimized (in-line) form */
    register unsigned char c; 
    register unsigned char FAR *cp;
    long stringPos; /* position in source document where string starts */
    long extraPos;

    legal = TRUE;

    /* check if can handle strings */

    if (!exa->text)
        legal = FALSE;

    /* find begin of string literal */

    spos = (*exa->srcpos)-1;
    while (exa->src[spos] != '"') 
        spos--;

    /* advance to end of string literal */

    *exa->srcpos = spos+1;
    cp = exa->src + *exa->srcpos;
    while (legal && ((c = *cp) != '"')) {
        if (c == 0 || c == NEWLINE)
            legal = FALSE;
        else
            cp++;
    } 
    *exa->srcpos = epos = cp - exa->src;
    (*exa->srcpos)++; /* advance past quote */
	
    if (!legal) {
        exa->errmess = "Badly formed string";
        exa->errnum = NAMEERR;
        return(NAMEERR);
    }

    lth = (epos-spos)-1;
    if (lth >= 4096) {
        exa->errmess = "String too long";
        exa->errnum = NAMEERR;
        return(NAMEERR);
    }
    
    /* check if can produce optimized (in-line) form */

    stringPos = spos+1+*exa->srcbase;
    if (nostylemarkf) mlitcf = TRUE;
    else mlitcf = tdoc_is_string(exa->srcH,stringPos,(long)lth);

    if (mlitcf) {
        if (stringPos & 0xff000000L) /* 24 bits for addr */
            mlitcf = FALSE;
        if ((lth <= 0) || (lth >= 256)) /* 8 bits for length */
            mlitcf = FALSE;
#ifdef MAC
        /* if (lth > 126) */ /* Mac code generator cant handle long strings */
	    mlitcf = FALSE; /* suppress on Mac */
#endif
    } /* TUTORis_string_doc */

    /* generate in-line string literal */

    if (mlitcf) {
        yylval.lval = (((long)lth) << 24) | stringPos;
        return(MLITC);
    } /* mlitcf if */

    /* generate string literal in textpool */
    /* insert length of string literal at beginning */

    yylval.lval = TUTORget_len_doc(exa->text); /* addr of string */
    c2[1] = (lth & 0x3f)+' '; /* low byte of length */
    c2[0] = ((lth >> 6) & 0x3f)+' '; /* high byte of length */
    /* insert length */
    InsertString(exa->text,(long) (yylval.lval),(char FAR *) c2,2L); 
		
    /* insert string into document */

    TUTORchange_doc_doc(exa->text,(long)(yylval.lval+2),0L,0L,(long)(yylval.lval+2),
                exa->srcH,stringPos,(long)lth,&extraPos,FALSE);
	
    yylval.lval -= exa->textbase; /* make relative to unit/expr */

    return(MLITERAL);

} /* plstr */

/* ******************************************************************* */

static pembed() /* process embed within expression */
	{
	int cp; /* character position */
	int ch; /* current character */
	int done; /* loop flag */
	unsigned char keyword[20]; /* embed keyword (cr, show, etc) */
	unsigned char str[4]; /* string for <|cr|> etc. */

	cp = 0;
	done = FALSE;
	do {
		ch = exa->src[(*exa->srcpos)+cp];
		if ((ch == NEWLINE) || (cp >= 18))
			return(badembed(1));
		if ((ch == ',') || (ch == '|'))
			done = TRUE;
		else
			keyword[cp++] = ch;
	} while (!done);
	keyword[cp] = '\0'; /* add terminator */

	if (ch == '|')
		{ /* process <|cr|> <|tab|> <|quote|> forms */
		/* check for terminating embed - skip over */

		if (exa->src[(*exa->srcpos)+cp+1] != '>')
			badembed(2);
		(*exa->srcpos) += cp+2;

		if (strcmp((char *) keyword,"cr") == 0) ch = NEWLINE;
		else if (strcmp((char *) keyword,"tab") == 0) ch = '\t';
		else if (strcmp((char *) keyword,"quote") == 0) ch = '"';
		else badembed(1);

		/* add character to literals document */

		yylval.lval = TUTORget_len_doc(exa->text);
		str[0] = 0+' ';
		str[1] = 1+' '; /* set up length */
		str[2] = ch;
		str[3] = ' '; /* dummy to make even number of bytes */
		InsertString(exa->text,(long) (yylval.lval),(char *) str,4L);
		yylval.lval -= exa->textbase; /* make relative to unit/expr */
		return(MLITERAL);
		}

	/* process <|s,(expr)|> and <|show,(expr)|> forms */
		
	else if ((strcmp((char *) keyword,"s")==0) || (strcmp((char *) keyword,"show")==0))
		yylval.ival = 1;
	else if ((strcmp((char *) keyword,"t")==0) || (strcmp((char *) keyword,"showt")==0))
		yylval.ival = 4;
	else if ((strcmp((char *) keyword,"b")==0) || (strcmp((char *) keyword,"showb")==0))
		yylval.ival = 7;
	else if ((strcmp((char *) keyword,"o")==0) || (strcmp((char *) keyword,"showo")==0))
		yylval.ival = 10;
	else if ((strcmp((char *) keyword,"h")==0) || (strcmp((char *) keyword,"showh")==0))
		yylval.ival = 13;
	else if ((strcmp((char *) keyword,"z")==0) || (strcmp((char *) keyword,"showz")==0))
		yylval.ival = 16;
	else if ((strcmp((char *) keyword,"e")==0) || (strcmp((char *) keyword,"showe")==0))
		yylval.ival = 19;
	else return(badembed(1));

	if (previous != EFUNCT)
		{
		n_myunput(2); /* back up over <| */
		return(previous=EFUNCT);
		}
	(*exa->srcpos) += cp+1; /* skip over comma */
	embedcnt++;
	yylval.ival = 0;
	return(previous = SLEFTEMBED);
	} /* pembed */

static int badembed(n) /* error handling for embed in expression */
int n; /* error type */
	{
	switch (n) {

	case 0:
		exa->errmess = "Cannot use embeds in expressions.";
		break;

	case 1:
		exa->errmess = "Unrecognized embedded command.";
		break;

	case 2:
		exa->errmess = "Improperly terminated embed.";
		break;

	case 3:
		exa->errmess = "Unbalanced parens or embeds.";
		break;

	} /* switch */

	return(exa->errnum = CHARERR);

	} /* badembed */
	
/* ******************************************************************* */

int pbscan(str,indx,target) 
/* scan input for target tracking paren/quote balance */
/* returns position if found target, -1 otherwise */

unsigned char FAR *str; /* input string */
int indx; /* starting index in string */
char *target; /* character code(s) to scan for */

{   int parenc; /* current paren balance */
    int quotec; /* current quote balance */
    int embedc; /* current embed balance */
    int loc; /* index in string */
    int targetl; /* length of target string */
    char cc,pcc; /* current, previous character code */

    loc = indx; /* position in string */
    parenc = quotec = embedc = cc = 0;
    targetl = strlen(target);

    while (TRUE) {
    	pcc = cc;
        cc = str[loc++];
        if ((cc == '\0') || (cc == NEWLINE)) return(-1);
        if ((!parenc) && (!quotec) && (!embedc) && (cc == target[0])) {
            if (strncmpf((char FAR *) &str[loc-1],(char FAR *)target,targetl) == 0)
                return(loc-1);
        } /* target if */
        if (!quotec && (cc == '(')) parenc++;
        if (!quotec && (cc == ')')) parenc--;
        if (!quotec && (cc == '|') && (pcc == '<')) embedc++;
        if (!quotec && (cc == '>') && (pcc == '|')) embedc--;
        if (cc == '"') quotec = (quotec ? 0: 1);
    } /* while */

} /* pbscan */

/* ******************************************************************* */


#ifdef EXECUTE

static touch_offset() 
/* used in -pause- compile */
/* not relevant to executor */
	{ 
	return; 
	} 

#else 

static touch_offset()
/* return 0 thru 2 for down, up, move */
	{
	unsigned char cc;
	
	cc = n_myinput();
	if (cc == 'd' && lcompare("own"))
		return(0);
	else if (cc == 'u' && lcompare("p"))
		return(1);
	else if (cc == 'm' && lcompare("ove"))
		return(2);
	
	exa->errmess = "Touch actions are down, up, or move.";
	exa->errnum = NAMEERR;
	return(0);
	}

#endif

/* ******************************************************************* */

#ifdef NoSuch

extern short yyact[];
extern short yypact[];
extern short yyr1[];
extern short yyr2[];
extern short yychk[];
extern short yydef[];

static int prec_debugF = 0;
static int prec_chksum[6];

extern int prec_debug(void);

int prec_debug() 

{
	if (prec_debugF == 0) {
		prec_chksum[0] = TUTORchecksum((char FAR *)&yyact[0],874L);
		prec_chksum[1] = TUTORchecksum((char FAR *)&yypact[0],452L);
		prec_chksum[2] = TUTORchecksum((char FAR *)&yyr1[0],180L);
		prec_chksum[3] = TUTORchecksum((char FAR *)&yyr2[0],180L);
		prec_chksum[4] = TUTORchecksum((char FAR *)&yychk[0],452L);
		prec_chksum[5] = TUTORchecksum((char FAR *)&yydef[0],452L);
		prec_debugF = 1;
	}
	
		
	if ((prec_chksum[0] != TUTORchecksum((char FAR *)&yyact[0],874L)) ||
	    (prec_chksum[1] != TUTORchecksum((char FAR *)&yypact[0],452L)) ||
	    (prec_chksum[2] != TUTORchecksum((char FAR *)&yyr1[0],180L)) ||
	    (prec_chksum[3] != TUTORchecksum((char FAR *)&yyr2[0],180L)) ||
	    (prec_chksum[4] != TUTORchecksum((char FAR *)&yychk[0],452L)) ||
	    (prec_chksum[5] != TUTORchecksum((char FAR *)&yydef[0],452L)))
	    TUTORdump("prec tables corrupted");
		
	return(0);
	
} /* prec_debug */

#endif

/* ******************************************************************* */
