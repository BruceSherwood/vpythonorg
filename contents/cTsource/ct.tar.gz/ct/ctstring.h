
#ifndef ctstring_h

#define ctstring_h

#ifdef MAC
#ifdef LSC4
#include <string.h>
#else
#include <strings.h>
int strcmp(char *,char *);
int strlen(char *);
int strncmp(char *, char *, int);
char *strncpy(char *, char *, int);
char *strncat(char *,char *,int);
#endif /* LSC4 */
#endif /* MAC */

#endif /* ctstring_h */
