
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>
#include "baseenv.h"
#include "kdefs.h"
#include "editmenu.h"
#include "tutor.h"
#include "editor.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "edglobal.h"
#include "txt.h"
#include "txtv.h"
#include "ct_ctype.h"
#include "help.h"

#ifdef ctproto
int TUTORforward_window(int wii);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,
 int ebsref,struct  _trect *theR,int  relInfo,int  mintw,int  wrap,
 unsigned int  doc,long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),
 int  ro,int  corner,int  erase,int  frame,int tabsz,int lm,int rm,int inhss,int type);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORclose_doc(unsigned int  doc);
int  TUTORclose_panel(unsigned int  theV);
extern int TUTORclose_window(int wid);
int  TUTORclose_view(struct  tutorview FAR *vp);
extern  int TUTORset_abs_clip_rect(TRect FAR *cr);
int  TUTORinq_abs_clip_rect(struct  _trect *cr);
int  TUTORclip_window(int  wid);
int  DrawPanel(unsigned int  edH);
extern int TUTORdraw_abs_solid_rect(TRect FAR *tr,int color);
struct  tutorview FAR *TUTORinit_view(int  sW,unsigned int  vDat,int  (*vProc)());
int  initdict(void);
int  procdict(unsigned int  dictH,struct  tutorevent *event);
extern int  HideDict(struct  _dictdat FAR *dt);
extern int  procdictclick(struct  _dictdat FAR *dt);
extern int  DictReadFile(struct  _dictdat FAR *ded,unsigned int  dmenus);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORset_view(struct  tutorview FAR *vp);
int  TUTORclear_window(int  wid);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  procdictstub(unsigned int  wh,struct  tutorevent *event);
int  TUTORset_menubar(unsigned int  barh,struct  tutorview FAR *newMenuView);
struct  tutorview FAR *TUTORinq_view(void);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,int ebsref,
 struct  _trect *theR,int  relInfo,int  mintw,int  wrap,unsigned int  doc,long  pos,
 long  len,int  wantV,int  wantH,int  (*KeyF)(),int  ro,int  corner,int  erase,
 int  frame,int tabsz,int lm,int rm,int inhss,int type);
int  TUTORset_event_mask(int  eventc,int  value);
int  TUTORadd_menu(unsigned int  barh,char  *card,int  cp,char  *item,int  ip,int  keyBind,int  type,int  unit,double  unitArg,int  eType);
unsigned int  TUTORinit_menubar(int  nItems);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORset_program_name(char  *pname);
int  TUTORcreate_window(int  top,int  left,int  xSize,int  ySize,int  type);
int  EditorDefaultStyles(unsigned int  doc);
int  TUTORdelete_doc(unsigned int  doc,long  pos,long  len,long  *extraPos);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORclose(int  findx);
int  TUTORfread_doc(unsigned int  doc,long  len,int  docKind,int  fInd);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  TUTORcopy_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  TUTORcopy_fileref_dir(struct  _fref FAR *dirname,struct  _fref FAR *fullname);
int  DictInsert(char  *s);
int  TUTORset_select_tview(unsigned int  theV,long  pos,long  len,struct  _sbarinf *vb);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
int  TUTORword_bounds2_doc(unsigned int  doc,long  pos,long  *wordSp,long  *wordEp,int  wSide);
int  TUTORinq_select_tview(unsigned int  theV,long  *pos,long  *len);
int  TUTORclick_done_tview(unsigned int  theV,struct  _sbarinf *vb);
int  TUTORdelete_menu(unsigned int  barh,char  *card,char  *item);
int  SetSelectPanel(struct  _tvdat FAR *vp,long  pos,long  len);
char  FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
int  CTisascii(int  cc);
int  TUTORdefault_styles_doc(unsigned int  doc,short  FAR *defStyles);
int  AddParaLayout(struct  _paral *pl);
#endif /* ctproto */

#ifdef macproto
int  TUTORmodify_menu(unsigned int  barh,char  *card,char  *item,int  enableFlag,int  checkFlag,int  style);
#endif


Memh dictmenus = HNULL;  /* dictionary menu definitions */

extern int procdict();
extern Memh TUTORinit_menubar();
extern long TUTORget_len_doc();

extern Memh TUTORnew_doc();
extern struct tutorview FAR *TUTORinit_view();
extern struct tutorview FAR *TUTORinq_view();
extern int procdictstub();
extern Memh MakeTextPanel();

static Memh dictDatH; /* handle on dictionary data */

/* ******************************************************************* */

initdict()  /* initializations for dictionary */
    {
    int dwidth; /* x display width */
    int i, jj;  /* work variables */
    long tempL;
    int wheight; /* dictionary window height */
    char info;
    DictData FAR *dp;
    TextVDat FAR *vp;
    struct tutorview FAR *cv;
    Memh dictH;
    Memh panelH; /* handle on text panel */

	if (DictWn >= 0) return;
	
    cv = TUTORinq_view(); /* remember current view */
    TUTORset_view(FARNULL); /* save current view */
    wheight = 100;
#ifdef WINPC
    wheight += 30; /* adjust for menu bar */
#endif
    DictWn = TUTORcreate_window(-1,-1,windowsP[EditWn[0]].wxsize,wheight,DICTW);
    TUTORset_program_name("ctcmds");
    dictDatH = TUTORhandle("dictdata",(long) sizeof(DictData),TRUE);
    if (!dictDatH) {
    	TUTORset_view(cv);
    	return;
    }
    dictH = dictDatH;
    dp = (DictData FAR *) GetPtr(dictH);
    dp->wid = DictWn;
    
    /* initialize window and main view */

	if (!dictmenus)
    	dictmenus = TUTORinit_menubar(NDICTMENU);
    windowsP[DictWn].menus = 0L; /* no menus yet */
    DictReadFile(dp,dictmenus);
#ifdef MAC
    TUTORadd_menu(dictmenus,NIL,10,"-",40,0,0,0,0.0,EVENT_MENU);
    TUTORmodify_menu(dictmenus,NIL,"-",0,-1,-1);
#endif
    TUTORadd_menu(dictmenus,NIL,10,"Close",60,0,edit_command,1,0.0,EVENT_MENU); 
    DictVp = TUTORinit_view(DictWn,0,procdictstub);
    TUTORset_view(DictVp);
    TUTORset_menubar(dictmenus,DictVp);

    /* initialize dictionary event mask */
    TUTORset_event_mask(EVENT_LEFTDOWN,TRUE);
    TUTORset_event_mask(EVENT_LEFTUP,TRUE);
    TUTORset_event_mask(EVENT_RIGHTDOWN,TRUE);
    TUTORset_event_mask(EVENT_RIGHTUP,TRUE);
    TUTORset_event_mask(EVENT_DOWNMOVE,TRUE);
    TUTORset_event_mask(EVENT_MENU,TRUE);
    TUTORset_event_mask(EVENT_MSG,TRUE);
    TUTORset_event_mask(EVENT_FWD,TRUE);
    TUTORset_event_mask(EVENT_VFOCUS,TRUE);
    TUTORset_event_mask(EVENT_WFOCUS,TRUE);
    TUTORset_event_mask(EVENT_SCROLL,TRUE);
	TUTORset_event_mask(EVENT_KEY,TRUE);


    /* set up text panel */
    info = LEFTSTICK | RIGHTSTICK | TOPSTICK | BOTTOMSTICK;
    dp->tPanel = MakeTextPanel(DictWn,(long) dictH,0,0,NEARNULL,info,
            100,TRUE,dp->textd,0L, -1L,TRUE,FALSE,FARNULL,TRUE,FALSE,FALSE,FALSE,
        -1,-1,-1,FALSE,0);

    panelH = dp->tPanel;
    vp = (TextVDat FAR *) GetPtr(panelH);
    dp->textv = vp->textv;
    dp->view = vp->view;
    TUTORset_view(vp->view);
    TUTORset_menubar(dictmenus,vp->view);
#ifdef THINKC5
    windowsP[DictWn].wproc = (int(*)(...))(procdictstub);
#else
    windowsP[DictWn].wproc = (int(*)())(procdictstub);
#endif
    windowsP[DictWn].wH = dictH;
    windowsP[DictWn].KeyFocus = dp->view;
    TUTORset_view(cv);
    ReleasePtr(panelH);
    KillPtr(vp);
    ReleasePtr(dictH);

    DrawPanel(panelH);

    return(0);
    
} /* initdict */

/* ******************************************************************* */

static char activated = FALSE;

procdict(dictH,event)   /* event processor for dictionary */
Memh dictH;
struct tutorevent *event; /* event to process */

{   int wn; /* window index */
    long selbegin;  /* begin of selection region */
    DictData FAR *dt;   /* pointer to text info */
    struct tutorview FAR *viewp;
    TextVDat FAR *vp;
    TViewP tvp;
    TRect cr;
    TRect eRect; /* rectangle to erase */

    if (!dictH) {
    	/* special handling - destroy goes to DictVp view */
    	/* not (DictData FAR *)->view */
    	if (event->type == EVENT_DESTROY)
    		dictH = dictDatH;
    }
    if (!dictH) return(0); /* nothing to do */

    dt = (DictData FAR *) GetPtr(dictH);
    wn = dt->wid;

    /* process dictionary events */

    switch (event->type) {

    case EVENT_REDRAW:
    	TUTORset_view(dt->view);
        TUTORinq_abs_clip_rect(&cr); /* save clip */
		TUTORclip_window(wn); /* clip to entire window */
		eRect.top = eRect.left = 0;
		eRect.bottom = windowsP[wn].wysize;
		eRect.right = windowsP[wn].wxsize;
        TUTORdraw_abs_solid_rect((TRect FAR *)&eRect,PAT_BACKGROUND);
        TUTORset_abs_clip_rect((TRect FAR *) &cr); /* restore clip */
        viewp = windowsP[wn].lastView;
        while (viewp) {
            TUTORset_view(viewp);
            (*viewp->vproc) (viewp->vh,event);
            viewp = viewp->prevView;
        }
        event->type = -1; /* we handled it already */
        break;

	case EVENT_KEY:
		event->type = -1; /* handled event */
    	if (EditWn[0] >= 0) { /* switch to editor */
            TUTORset_view(EditVp[0]); /* set to editor view */
            TUTORforward_window(EditWn[0]);
#ifndef MAC
            TUTORmessage(EditVp[0],EVENT_VFOCUS,TRUE);
            TUTORnormal_cursor();
#endif
		}
    	break;

    case EVENT_FWD:
        if (!activated)
            {
            viewp = windowsP[wn].firstView;
            while (viewp)
                {
                TUTORset_view(viewp);
                (*viewp->vproc) (viewp->vh,event);
                viewp = viewp->nextView;
                }
            activated = TRUE;
            }
        event->type = -1;
        break;

    case EVENT_VFOCUS:
        event->type = -1;
        break;
        
    case EVENT_WMKILL: /* window closed by window manager */    
    	if (DictVp) {
    		ReleasePtr(dictH);
    		KillPtr(dt);
    		TUTORclose_view(DictVp);
    		dictH = HNULL;
    	}
    	event->type = -1;
    	break;
    	
    case EVENT_DESTROY:
    	if (DictVp && (event->view == DictVp)) {
    		TUTORset_view(dt->view);
			TUTORdelete_menu(dictmenus,"Option",NEARNULL); 
			TUTORclose_panel(dt->tPanel);
			dt->tPanel = HNULL;
			TUTORclose_doc(dt->textd);
			dt->textd = HNULL;
			ReleasePtr(dictH);
			KillPtr(dt);
			TUTORfree_handle(dictH);
			viewp = windowsP[DictWn].lastView;
			while (viewp) {
				if (viewp->vh == dictH)
					viewp->vh = HNULL; /* clean out references to data */
				viewp = viewp->prevView;
			} /* while */
			dictDatH = dictH = HNULL;
			DictVp = FARNULL; /* block reccursive calls */
        	TUTORclose_window(DictWn);
        	DictWn = -1;
        }
        event->type = -1;
        break;

    case EVENT_RIGHTUP: /* process mouse up event */
    case EVENT_LEFTUP:
        if (event->view == dt->view) {
            TUTORset_view(dt->view);
            procdictclick(dt);
            event->type = -1; /* all done */
        }
        break;
    
    case EVENT_MSG:
    case EVENT_MENU:
        switch (event->a1) {

        case dict_select: 
            TUTORset_view(dt->view);
            selbegin = event->a2;
            vp = (TextVDat FAR *) GetPtr(dt->tPanel);
            SetSelectPanel(vp,selbegin,0L);
            ReleasePtr(dt->tPanel);
            KillPtr(vp);
            event->type = -1;
            break;
        
        case edit_command: /* hide commands */
        	if (DictVp) {
        		ReleasePtr(dictH);
        		KillPtr(dt);
            	TUTORclose_view(DictVp);
            	dictH = FARNULL;
            }
            event->type = -1;
            break;
        }
        break;
    } /* event switch */
    
    if (dictH) {
    	ReleasePtr(dictH);
    	KillPtr(dt);
    }

    /* pass on events we didn't handle */
    if (event->type > 0 && event->view) {
        TUTORset_view(event->view);
        (*event->view->vproc)(event->view->vh,event);
    }
    return(0);
    
} /* procdict */

/* ******************************************************************* */

static procdictclick(dt)
DictData FAR *dt;   /* pointer to text info */
{
    long selbegin;  /* begin of selection region */
    long selend;    /* end of selection region */
    long sellth;    /* length of selection region */
    long ebegin;    /* begin of editor selection region */
    char dstr[102]; /* dictionary word string */
    SBarInfo sbi;
    
    TUTORclick_done_tview(dt->textv,&sbi);

    /* locate word indicated by click */
    TUTORinq_select_tview(dt->textv,&ebegin,&sellth);
    
    /* figure out word boundaries */
    TUTORword_bounds2_doc(dt->textd,ebegin,&selbegin,&selend,1);
    
    sellth = selend-selbegin;
    
    if (sellth > 100) sellth = 100; /* insure legal length */
    if (selbegin == 0 || TUTORcharat_doc(dt->textd,selbegin-1) == NEWLINE)
        return(FALSE); /* exit if title */
    
    /* extract word string from document */
    TUTORget_string_doc(dt->textd,selbegin,sellth,(unsigned char FAR *) dstr);
    while (sellth > 1 && (dstr[sellth-1] == ' ' || dstr[sellth-1] == NEWLINE))
        {
        sellth--;
        dstr[sellth] = '\0';
        }

    TUTORset_select_tview(dt->textv,selbegin,sellth,NEARNULL);

    /* insert dictionary string in source document */
    DictInsert(dstr);
    
    return(TRUE);

} /* DictWordClick */

/* ******************************************************************* */
        
static DictReadFile(ded,dmenus) /* fill dictionary document */
DictData FAR *ded;
Memh dmenus; /* dictionary menu bar */

{   int fp; /* dictionary source file index */
    FileRef dname;  /* dictionary file name */
    long tempL, tempL2;
    char FAR *wp;
    int ii,jj;
    char item[DICTITEML+2]; /* menu item string */
    long dbuffl; /* length of text in buffer */
    char dbuff[1500]; /* buffer for dictionary text */
    char FAR *sourcep;
    char FAR *sp;
    long sourcel;
    int dFamily, dSize;
    short curStyles[NSTYLES];
    ParagraphLayout layout;
    DocP dp;
    
    TUTORcopy_fileref_dir((FileRef FAR *) &dname,sourceDirP);
    TUTORcopy_fileref_name((FileRef FAR *) &dname,(char FAR *) "commands.dct");

    /* read dictionary source file */
    /* try to read cmututor.dct in author directory then */
    /* use file specified by environment var if not found */

    fp = TUTORopen((FileRef FAR *) &dname,TRUE,FALSE,FALSE);
    if (fp == 0)
        {
        /* try finding file in special cT directory */

	TUTORcopy_fileref_dir((FileRef FAR *) &dname,ctDirP);
        TUTORcopy_fileref_name((FileRef FAR *) &dname,(char FAR *) "commands.dct");
        fp = TUTORopen((FileRef FAR *) &dname,TRUE,FALSE,FALSE);
        }
    if (fp)
        TUTORinq_file_info((FileRef FAR *) &dname,NEARNULL,&tempL,NEARNULL,NEARNULL,NEARNULL);
    else
        tempL = 0; /* no file */

    /* set up styled text document */

    ded->textd = TUTORnew_doc(FALSE,FALSE);

    if (fp && tempL > 0)
        {
        ii = TUTORfread_doc(ded->textd,-1L,-1,fp);
        TUTORclose(fp); /* close source file */
        if (ii == FALSE)
            tempL = 0; /* don't understand file */
        else if ((tempL2 = TUTORget_len_doc(ded->textd)) > MAXSTRINGLEN-1000)
            { /* document too big, clip it */
            TUTORdelete_doc(ded->textd,MAXSTRINGLEN-1000,
                            tempL2-(MAXSTRINGLEN-1000),&tempL2);
            }
        }

    EditorDefaultStyles(ded->textd);
    for (ii=0; ii<NSTYLES; ii++)
        curStyles[ii] = DEFSTYLE;
    layout.tabSize = 60;
    layout.leftMar = 30;
    layout.paraIndent = -20;
    layout.rightMar = 10;
    ii = AddParaLayout(&layout);
    curStyles[PARASTYLE] = (ii << 3) | LEFTJUST;
    TUTORdefault_styles_doc(ded->textd,(short FAR *) curStyles);
    

    /* set up menus */

    dp = (DocP) GetPtr(ded->textd);
    sourcel = dp->totLen;
    sourcep = (char FAR *) dp->text;
    
    wp = sourcep;
    while ((long)(wp) < ((long)(sourcep)+sourcel)) {
        /* build menu card */
        if (CTisascii(*wp) && CTisalnum(*wp)) {
            sp = (char FAR *) wp; /* find end of word */
            while ((((long)sp) < ((long)sourcep)+sourcel) && 
                   CTisascii(*sp) && CTisalnum(*sp))
                sp++;
            ii = sp-wp+1; /* set up menu card */
            if (ii < 64) {
                /* 64 is MENUNAMEL in tgraph */
                strncpyf((char FAR *) item,wp,ii);
                item[ii] = '\0';
                jj = wp-(char FAR *)sourcep;
                TUTORadd_menu(dmenus,"Option",30,item,0,0,dict_select,jj,0.0,EVENT_MENU);
            } /* ii (length) if */
        } /* isascii if */

        /* skip to next line */
        while ((wp < (char FAR *) (sourcep+sourcel)) && (*wp != NEWLINE)) wp++;
        wp++;
    } /* fp if */
    ReleasePtr(ded->textd);
    KillPtr(dp);

} /* DictReadFile */
