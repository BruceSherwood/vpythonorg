
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Definitions for eglobals.c
*/

#ifndef _eglobalh
#define _eglobalh

extern long *iresP; /* pointer to current top of integer stack */
extern long istack[EX_STACKL]; /* stack of intermediate integer results */
extern double *fresP; /* pointer to current top of floating stack */
extern double fstack[EX_STACKL]; /* stack of intermediate floating results */
extern struct markvar FAR *markP; /* pointer to current top of marker stack */
extern struct markvar FAR *markstack; /* stack of intermediate marker results */
extern int execrun; /* continue execution/return flag */

/* ******************************************************************* */

/* executor main data structure */

typedef struct s_ExecuteState {

short ExecInit; /* = 0 before initializations */
                /*   1 if executor state initialized */
                /*   2 if executor is/has run */
short ExecQuit; /* TRUE if quit menu has been selected */
long ExecQuitTime; /* time quit menu selected */
struct tutorview FAR *baseView; /* initial view of executor */

/* relative coord variables */
Coord RXorigin, RYorigin ;
double RXsize, RYsize, RAngle ;
double RsinAngle, RcosAngle ;
char RXsizeFlag, RYsizeFlag, RAngleFlag; /* TRUE if need transforming */
double zrtouchx, zrtouchy;

/* graphics coord variables */
Coord GXorigin, GYorigin;  /* origin x,y */
double GXoffset, GYoffset;
double GXscale, GYscale;
int GLogXflag;   /* flags for log scales */
int GLogYflag;
int GPolar;        /* flag for polar coords */
int DXneg, DYneg ;  /* x axis lengths */
int DXplus, DYplus ;  /* y axis lengths */
double GminorX, GminorY ;  /* spacing of minor tick marks */
double GDelta ;
double zgtouchx, zgtouchy;

/* fine coord variables */
int desX,desY; /* desired window size */
Coord RegionXmin, RegionYmin, RegionXmax, RegionYmax; /* -fine- */
Coord ScreenX, ScreenY; /* current screen location */
Coord ScreenW, ScreenH; /* current execution screen size */
int OffsetX, OffsetY; /* offsets from upper-left window corner */
Coord ScaleX, ScaleY; /* -rescale- factors */
Coord ztouchx, ztouchy;
Coord FineW, FineH; /* by -fine- command */
char FineDone; /* TRUE if a -fine- has been executed */
char RoundCircles; /* true if want circles to be circular */
char ConstrainScale; /* if true, scaling constrained by available font sizes */
int rescaleCharHeight; /* CharHeight in effect when -rescale- or -fine- executed */
short rescaleFont; /* index of font baseFont in effect when -rescale- or -fine- executed */

/* other graphics variables */
int newLine; /* current newline height */
int SupSub; /* current superscript/subscript height */
int outcnt; /* rough count of output bytes for fflush(winout) */
int RescaleX, RescaleY, RescaleT; /* rescale x, y, text */
char ClipText; /* if true, clip text output to bottom margin */
char wrapWrite; /* if TRUE, wrap -write- commands, & shows */
char oldcolor; /* TRUE if old -rgb- and color scheme */
char didPalette; /* TRUE if have altered palette */
int CoarseW, CoarseH; /* by -coarse- command */
int mode; /* write, rewrite, erase, xor */
int unClip; /* TRUE if blank clip */
Coord ClipX, ClipY, ClipX2, ClipY2; /* executor clip region */
Coord cx, cy; /* set by readcoord() */
Coord MarginBeginX, MarginBeginY, MarginEndX, MarginEndY;
int ScreenX0, ScreenY0; /* location of upper-left corner of execution display */
int CharHeight; /* measured in paper coords */
int startdrawcnt; /* number of draw or move starts to inhibit */
Memh dTextLayout; /* executor text document */
long inhibbits; /* set by -inhib- */
int optionInhib; /* TRUE if option menu inhibitied */
/* int forcebits;  *//* set by -force- */
short baseFont; /* index of font selected with -font- command */
short patternFont, patternChar; /* current fill parameters */
short cursorFont, cursorChar; /* font of current cursor */
short iconFont; /* current icon font */
short textFont; /* currently selected FONT */
Coord yfudge; /* IBM-PC EGA scale factor */
int Thick; /* current line thickness */
int imPalF; /* first slot available for image palette */
int imPalL; /* last slot available for image palette */

Memh snapShotH; /* handle on executor snapshot */
int sswx,sswy; /* window size at time of snapshot */
int ssx1,ssy1,ssx2,ssy2; /* snapshot bounds */
/* marker variable modifiers */
char exactMatch;    /* when TRUE, searches & compares are exact */
Memh sortTable; /* user's sort table for non-exact searches & compares */
Memh iconStextH; /* handle on icon stext info for -style- command */
Memh imageStextH; /* handle on image stext info for -style- command */
int vidX1,vidX2,vidY1,vidY2; /* current video rectangle */
int vidMode; /* current video mode (scale, no scale, center) */
Memh controllerH; /* handle on movie controller if present */

/* events */
int zkey, zdevice;
int zreshape; /* TRUE in a main unit that was started by reshape */
int inieu; /* TRUE if currently executing IEU */
int needredraw; /* TRUE if we have buffered a redraw during ieu execution */
int enabled;    /* current touch, etc. that is enabled */
int enablebits; /* what -enable- enables */
  /* enable ext,touch(left:down,up,move;right:down,up,move) */
int pictF; /* non-zero if execute window picture-create in progress */
           /* = 1 = drawing picture */
           /* = 2 = before redraw event */
int zeditkey; /* key value for edit panel */
Coord zeditx; /* x value for edit panel event */
Coord zedity; /* y value for edit panel event */
int post_unitN; /* post-event unit number */
int post_unitF; /* post-event unit/argument flag */
double post_unitA; /* post-event argument */   
Memh hold_objectH; /* handle on text panel held event is for */
struct tutorevent hold_event; /* event held during pre-event unit processing */

int modal_dialog_redraw; /* TRUE if redraw during modal dialog */
int dialog_redraw_x; /* x size of redraw event */
int dialog_redraw_y; /* y size of redraw event */

Memh last_edit; /* last edit panel active (zedit) */
int last_edit_ref; /* unique id for edit header */
Memh last_button; /* last button active (zbutton) */
int last_button_ref; /* unique id for button header */
Memh last_slider; /* last slider active (zslider) */
int last_slider_ref; /* unique id for slider header */
Memh last_touch; /* last touch region active */
int last_touch_ref; /* unique id for touch region */
Memh last_dde; /* last dde conversation active */
int last_dde_ref; /* unique id for dde conversation */
Memh next_objH; /* handle on next object header */
Memh proc_obj_unit; /* unit currently being processed for object event */
int nobjects; /* number edit/button/slider objects active */

/* the stack */
unsigned long stackmalloc; /* amount of stack malloc-ed */
Memh stackH; /* handle to stack memory */
unsigned char SHUGE *stackpntr;
unsigned char SHUGE *stackP; /* pointer to stack (when stackH locked) */
short stackLocked; /* TRUE stack is locked */
long LockStackRel; /* current depth in stack between unlock/lock */
unsigned char SHUGE *lvarP; /* pointer to local variables for current unit */
long mainlvars; /* base in stack of main unit local vars */
long lvars; /* base in stack of current local vars */
int arrExtra; /* amount extra to pad arrow data to multiple of 64 bytes */

/* units & execution state */
long cmdloc; /* starting location of current command */
unsigned short uloc; /* command pointer within a unit */
int execunit;  /* unit now being executed */
int startunit; /* unit to do after unit 0 */
int nextunit, backunit; /* set by next and back commands */
int mainunit; /* current main unit */
int imainunit; /* specified -imain- unit */
int finishunit;     /* specified -finishu- unit */
int loopcounter;    /* count backward branches taken */
char shouldint; /* TRUE if should interrupt (return to interact) */
char errexit;   /* TRUE if halted on execution error */
char useCompiled; /* TRUE if should use compiled form of unit */
char dddu;
unsigned short markpt; /* location of last markpt command */
unsigned short condt_uloc; /* location of conditional cmd exit */
int dynLocked; /* number dynamic arrays currently locked */
int inText; /* TRUE while executing embedded writes */
int inOver; /* TRUE while executing a block of commands to step over */
int stepMode; /* 0 = not in step mode */
              /* 1 = step mode */
              /* 2 = skiping over -do- */
long stepStackTarget; /* stack level to return to after -do- */

/* menus */
Memh execmenus; /* pointer to executor menu bar */
short menusmade; /* TRUE if execution-time menus already made */
short execmenu; /* TRUE if have executed a -menu- command */

/* pause */

int pausetype; /* -1 if not waiting at a -pause- */
unsigned short pauseuloc; /* location of -pause- command */
unsigned short pauseuloca; /* location after -pause- command */
int pausetimer; /* handle on -pause- time event */
int pausetouch; /* -pause- touch/ext bits */
unsigned char pausekeys[38]; /* bit list of allowed keys */

/* -do- machinery */
int ndoval, ndoaddr; /* value and addr args passed by -do- */
int docounter; /* count no. of -do-s performed */
/* special status for -do- execution errors */
/* may also be used for other errors where pcode pointer or */
/* location not current */
int do_errunit; /* -1 or unit number */
long do_errpos; /* position of -do- */

/* -jumpout- machinery */
int JargN; /* number arguments */
Memh JinfoH; /* handle on -jumpout- arguments info */
FileRef fromRef; /* calling program */

struct arrows arr; /* all arrow info */

int video_kind; /* type of video system attached */

/* returns to user */
int zreturn; /* error return for various commands */
long zretinf; /* additional info return for various commands */
} ExecuteState;

extern ExecuteState exS;

/* ******************************************************************* */

/* data structure for window data */
typedef struct _exDat {
    int wid;    /* window index */
} ExecuteDat;

/* variables we only need one of for all executors: */

extern Memh grapheditmenus; /* pointer to graph edit menus */

extern char FAR *exec_err_msg; /* execution error message buffer */

#ifdef THINKC5
extern int (FAR * FAR *exs_addr)(...); /* routines to process commands/expression elements */
#else
extern int (FAR * FAR *exs_addr)(); /* routines to process commands/expression elements */
#endif


extern short FAR *ex_binP; /* execution pointer */

extern int store_kind; /* type of storeable item */
extern long store_addr; /* address of storeable item */
extern long store_items; /* number of storeable items */

#endif  /* _eglobalh */
