
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>

#define STRICT
#include <windows.h>
#include <commdlg.h>
#include <string.h>
#include "ctmsw.h"

#include "baseenv.h"
#include "tutor.h"
#include "kdefs.h"
#include "editor.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "edglobal.h"
#include "kglobals.h"
#include "txt.h"
#include "txtv.h"
#include "eglobals.h"

#ifdef ctproto   
extern void cTReleaseDC(HWND hWnd,HDC hDC);
extern HDC cTGetDC(HWND hWnd);
extern int PreDialog(void); 
extern int PostDialog(void);
extern int DocBuffer(Memh doc);
extern int TUTORfree_region(long rr);
extern int TUTORabs_restore_region(long rr,int xx,int yy); 
extern long TUTORabs_save_region(int x1,int y1,int x2,int y2);    
extern int TUTORcharat_doc(Memh doc,long pos);
int get_line_doc(Memh Doc,long Pos,char *Buff,int BuffL,long *endPos);
int  TUTORdefault_styles_font_doc(int  font,unsigned int  doc);  
extern int TUTORset_view(struct tutorview FAR *vv);
extern int TUTORzero(char SHUGE *pr,long len);
extern int TUTORinvalidate_font(void); 
extern int TUTORabs_move_to(int xx,int yy);
extern int TUTORset_textfont(int ff); 
extern int TUTORset_comb_rule(int mode); 
extern long TUTORget_len_doc(Memh hh);
int  ReleasePtr(unsigned int  mm);
int  _TUTORlayout_lines(struct  _ktd FAR *dp,long  pos,long  len,int  width,int  wordB,int  curX,struct  _pdt FAR *sp,int  styleInd,struct  _linelay FAR *liLay,short  *curStyles,struct  _paral *pLay,struct  _spt2 FAR *stp,int  stind);
int  _TUTORsetup_layout(struct  _ktd FAR *dp,long  pos,long  len,int  *styleInd,struct  _pdt FAR * *styleP,short  *curStyles,struct  _paral *pLay,int  *stind,struct  _spt2 FAR * *stp,int  fillDef);
int  _TUTORset_textfont_doc(struct  _ktd FAR *dp,short  *curStyles);
int  _TUTORload_buffer_doc(struct  _ktd FAR *dp,long  pos);
int  _TUTORlayout_lines0(unsigned int  theV,long  pos,int  height,int  redo);
int  TUTORdraw_doc(unsigned int  doc,long  pos,long  len,struct tutorColor FAR *fc,int	left,int  width,int  height,int  wordB,int  nLines,char  FAR *cliLay,int  pStart,int  *lastHeight,int  *maxH,int SupSubAdj);
extern int TUTORfree_handle(Memh hh);
int TUTORdevice_color(HDC hdc);
long TUTORprint_doc(Memh doc,long pos,long len,int pageX,int pageY,int left,
		   int *pStart,int pFlag);
int  printdoc(struct  _tvdat FAR *et,char  *dName);
int  editormsg(char  *ss,int  aFlag);
/* extern int86x(); */
/* extern segread(); */
/* extern int86(); */
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
int  tdoc_getstyles(unsigned int  theD,long  pos,short  *styles);
int  _TUTORinq_state_internal_marker(int  ind,long  *pos,long  *len,int  *altered);
int  assoc_name(struct  _fref FAR *fn,struct  _fref FAR *bfilen,char  *extnNew);
int  FindUnits(void);
HDC cTGetDC(HWND win);
void cTReleaseDC(HWND win,HDC dc);
#ifdef IBMPROTO
int _CDECL fclose(FILE *);
size_t _CDECL fwrite(const void *, size_t, size_t, FILE *);
FILE * _CDECL fopen(const char *, const char *);
#endif /* IBMPROTO */
#endif /* ctproto */

/* ******************************************************************** */

BOOL CALLBACK AbortProc(HDC hPrinterDC,short nCode);
BOOL CALLBACK PrintDlgProc(HWND hDlg,UINT message,UINT wParam,LONG lParam);

/* ******************************************************************** */

extern HDC CurrentDC; /* current window's device context */
extern int HaveDC; /* TRUE if have device context */
extern HANDLE hcTInst; /* current instance of cT */
extern HWND CurrentWinH; /* handle on current window */
extern HANDLE hcTInst; /* current instance of cT */
extern BOOL fMovieOpen; /* TRUE if VFW movie currently open */
extern int qtMovieOpenF; /* TRUE if QuickTime movie currently open */
extern int mControllerHasPalette; /* TRUE if movie controller controls palette */

int inPrint = 0;
int pageX; /* width of paper */
int pageY; /* height of paper */

static BOOL bUserAbort;
static HWND hDlgPrint;
static int pdValid = 0;
static PRINTDLG pd;
static DOCINFO di = {sizeof(DOCINFO),"",NULL};

/* ******************************************************************** */

HDC cTGetDC(hWnd) /* get graphics context for current window (or printer) */
HWND hWnd; /* window handle */

{
	HaveDC = TRUE;
	if (inPrint) return(pd.hDC);
	return(GetDC(hWnd));

} /* cTGetDC */

/* ******************************************************************* */

void cTReleaseDC(hWnd,hDC) /* release graphics context */
HWND hWnd; /* window handle */
HDC hDC; /* graphics context */

{
	if (!HaveDC) return;
	HaveDC = FALSE;
	if (inPrint) return;
	ReleaseDC(hWnd,hDC); 

} /* cTReleaseDC */

/* ******************************************************************* */

PrintEditDoc(et,dName) /* print source document */
TextVDat FAR *et; /* text view */
char *dName; /* name of document */

{   int wIx; /* index of owner's window */
    HWND hWnd; /* owner's window */
    int uIndex; /* index in unit table */
    long up,ul; /* position, length of unit */
    long firstp; /* position of 1st char in unit */
    long nextp; /* position of next line in unit */
    int lineL; /* length of current line */
    int nTotalLines; /* total number of lines to print */
    int fwl,errf; /* error flags */
    FileRef pfilen; /* listing file name */
    short styles[NSTYLES]; /* style flags */
    FILE *pfile; /* listing file */
    TEXTMETRIC tM; /* printer text metrics */
    int bSuccess; /* TRUE if print worked */
    char szJobName[20]; /* name assigned to print job */
    FARPROC lpfnPrintDlgProc; /* dialog procedure */
    int yChar; /* height of line */
    int nCharsPerLine;
    int nLinesPerPage;
    int nTotalPages;
    int nPage; /* current page */
    int nLine; /* current line */
    int nLineNum;
    int nColCopy; /* current collated copy */
    int numColCopy; /* number collated copies to do */
    int nNonColCopy; /* current non-collated copy */
    int numNonColCopy; /* number non-collated copies to do */
    long pBuffL; /* length of data in print buffer */
    char pBuff[1002]; /* print buffer */
    char *cP; /* pointer in buffer */
    int cL; /* length in buffer */

    wIx = et->view->window;
    hWnd = (HWND)windowsP[wIx].wp; /* get handle on edit window */

    TUTORzero((char FAR *)&pd,(long)sizeof(PRINTDLG));
    pd.lStructSize = sizeof (PRINTDLG);
    pd.hwndOwner = hWnd;
    pd.Flags = PD_NOPAGENUMS | PD_NOSELECTION | PD_RETURNDC;
    pd.nCopies = 1;

    if (!PrintDlg(&pd))
		return(TRUE);

    /* locate units, open list file */

    FindUnits();
    if (nunits<0)
        return(FALSE); /* unit setup failed */
    assoc_name(&sourcetable[0].fRef,(FileRef FAR *) &pfilen, ".lst");
    pfile = fopen(&pfilen.path[pfilen.nameInd],"wt");
    if (pfile == NULL)
	return(FALSE); /* failed to open listing file */

    /* output to list file, unit-by-unit */

    errf = FALSE; /* no error yet */
    nTotalLines = 0;
    pBuffL = 1000;
    for(uIndex=0; (uIndex<=nunits) && (!errf); uIndex++) {
        /* print only units in main file */
	if ((unittab[uIndex].beginfile == 0) && (unittab[uIndex].marki >= 0)) {
	    _TUTORinq_state_internal_marker(unittab[uIndex].marki,&up,&ul,NEARNULL);

            /* determine if unit hidden */

	    lineL = get_line_doc(source,up,pBuff,(int)pBuffL,&firstp);
	    if (tdoc_getstyles(source,firstp,styles)) {
		if (styles[PARASTYLE] & VISMASK) {
		    fwl = fwrite(pBuff,1,lineL,pfile); /* print unit command */
		    if (!fwl) errf = TRUE;
		    nTotalLines++;
		    fwl = fwrite(" -------\n",1,9,pfile);
		    if (!fwl) errf = TRUE;
		    nTotalLines++;
		    ul = -1; /* skip rest of unit */
		} /* styles if */
	    } /* getstyles if */

	    /* output body of unit */

            while ((ul > 0) && !errf) {
		lineL = get_line_doc(source,up,pBuff,(int)pBuffL,&nextp);
		fwl = fwrite(pBuff,1,lineL,pfile);
		if (!fwl) errf = TRUE;
		nTotalLines++; /* count number lines in buffer */
		ul -= nextp-up; /* decrement length */
		up = nextp;
            } /* ul while */
        } /* beginfile if */
    } /* uIndex for */
    fprintf(pfile,"\n");
    nTotalLines++;
    fclose(pfile); /* close listing file */

    /* figure out lines per page, number pages */

    GetTextMetrics (pd.hDC,&tM);
    yChar = tM.tmHeight+tM.tmExternalLeading;
    nCharsPerLine = GetDeviceCaps(pd.hDC,HORZRES)/tM.tmAveCharWidth;
    nLinesPerPage = GetDeviceCaps (pd.hDC,VERTRES)/yChar;
    nTotalPages = (nTotalLines+nLinesPerPage-1)/nLinesPerPage;
    pBuffL = ((nCharsPerLine < 1000) ? nCharsPerLine: 1000);
    EnableWindow(hWnd,FALSE);

    bSuccess = TRUE;
    bUserAbort = FALSE;
    strcpy(szJobName,&pfilen.path[pfilen.nameInd]);
    lpfnPrintDlgProc = MakeProcInstance((FARPROC)PrintDlgProc,hcTInst);
    hDlgPrint = CreateDialog((HINSTANCE)hcTInst,(LPCSTR)"PrintDlgBox",hWnd,(DLGPROC)lpfnPrintDlgProc);
    SetDlgItemText(hDlgPrint,ID_PRINTNM,szJobName);
    numColCopy = numNonColCopy = 1; /* pre-set for one copy */
    if (pd.Flags & PD_COLLATE) numColCopy = pd.nCopies;
    else numNonColCopy = pd.nCopies;
	SetAbortProc(pd.hDC,(ABORTPROC)AbortProc);

    /* read and print listing file */

    pfile = fopen(&pfilen.path[pfilen.nameInd],"rb");
    if (pfile == NULL)
		return(FALSE); /* failed to open listing file */

	if (StartDoc(pd.hDC,&di) > 0) {
	for (nColCopy = 0; nColCopy < numColCopy; nColCopy++) {
	    for (nPage = 0 ; nPage < nTotalPages ; nPage++) {
			if (StartPage(pd.hDC) < 0) {
					bSuccess = FALSE;
					break;
			}
		for (nNonColCopy = 0; nNonColCopy < numNonColCopy; nNonColCopy++) {
		    for (nLine = 0;nLine < nLinesPerPage;nLine++) {
			nLineNum = nLinesPerPage*nPage+nLine;
			if (nLineNum > nTotalLines)
			    break; /* exit if out of lines */
			fgets(pBuff,(int)pBuffL,pfile); /* get next line */
			cL = strlen(pBuff);
			cP = pBuff+cL-1;
			while (cL && ((*cP == 0x0d) || (*cP == 0x0a))) {
			    *cP-- = 0; /* remove terminator */
			    cL--;
			}
			TextOut(pd.hDC,0,yChar*nLine,pBuff,cL);
		    } /* nLine for */
			if (EndPage(pd.hDC) < 0) {
				bSuccess = FALSE;
				break;
		    }
		    if (bUserAbort)
			break ;
		} /* nNonColCopy for */
		if (!bSuccess || bUserAbort)
		    break;
	    } /* nPage for */
	    if (!bSuccess || bUserAbort)
		break;
	} /* nColCopy for */
    } else /* escape else */
	bSuccess = FALSE;

    if (bSuccess)
		EndDoc(pd.hDC);

    if (!bUserAbort) {
	  EnableWindow(hWnd,TRUE);
	  DestroyWindow(hDlgPrint);
    }

    fclose(pfile);

    FreeProcInstance(lpfnPrintDlgProc);
    DeleteDC(pd.hDC);

    return(bSuccess && !bUserAbort);

} /* PrintEditDoc */

/* ******************************************************************* */

int get_line_doc(Doc,Pos,Buff,BuffL,endPos) /* get next line, convert tabs  */
Memh Doc; /* handle on source document */
long Pos; /* starting position */
char *Buff; /* buffer to fill */
int BuffL; /* maximum length */
long *endPos; /* ending position */

{   int cc; /* current character */
    int len; /* length read */
    int nextTab; /* position of next tab stop */

    nextTab = prfP->nTabs;
    len = 0;
    do {
	if (len == nextTab)
	    nextTab += prfP->nTabs;
	cc = TUTORcharat_doc(Doc,Pos++);
	if (cc == '\t') {
	    while ((len < nextTab) && (len < (BuffL-1)))
		Buff[len++] = ' ';
	} else {
	    Buff[len++] = cc;
	}
    } while ((len < BuffL-1) && (cc != NEWLINE));
    Buff[len] = 0;
    *endPos = Pos;
    return(len);

} /* get_line_doc */

/* ******************************************************************* */

int TUTORprint_dialog(wix,type)
int wix; /* window index */
int type; /* 0 = page setup, 1 = print dialog */
/* returns 0: ok, 1: cancel */
/* in executor window can also have error returns: */
/* -1 = window not big enough */
/* -2 = can't save display */
/* -3 = not front window */

{   int retf;
    HWND hWnd;
	
	bUserAbort = FALSE;
    hWnd = (HWND)windowsP[wix].wp;
    if (hWnd != GetActiveWindow())
		return(-3);
		
    /* prepare for dialog */
	
    retf = PreDialog();
	if (!retf)
		return(-2); /* apparently couldn't save region */

    if (!pdValid)
		TUTORzero((char FAR *)&pd,(long)sizeof(PRINTDLG));
    pd.lStructSize = sizeof (PRINTDLG);
    pd.hwndOwner = hWnd;
    pd.Flags = PD_NOPAGENUMS | PD_NOSELECTION | PD_RETURNDC;
    if (type == 0) {
		pd.Flags |= PD_PRINTSETUP;
    } else {
		pd.Flags |= PD_HIDEPRINTTOFILE;
    }
    pd.nCopies = 1;
    pdValid = TRUE;

    retf = 0; /* 0 = ok */
    if (!PrintDlg(&pd))
		retf = 1; /* 1 = cancel */

    PostDialog(); /* handle after dialog */

    return(retf);
	
} /* TUTORprint_dialog */

/* ******************************************************************* */

BOOL CALLBACK PrintDlgProc(hDlg,message,wParam,lParam)
HWND hDlg;
UINT message;
UINT wParam;
LONG lParam;

{
    switch (message) {

	case WM_INITDIALOG:
	    EnableMenuItem(GetSystemMenu(hDlg,FALSE),SC_CLOSE,MF_GRAYED);
	    return(TRUE);

	case WM_COMMAND:
	    bUserAbort = TRUE;
	    EnableWindow(GetParent(hDlg),TRUE);
	    DestroyWindow(hDlg);
	    hDlgPrint = 0;
	    return(TRUE);
     }
     return(FALSE);

} /* PrintDlgProc */

/* ******************************************************************* */

BOOL CALLBACK AbortProc(hPrinterDC,nCode)
HDC hPrinterDC;
short nCode;

{   MSG msg;

    while (!bUserAbort && PeekMessage(&msg,NULL,0,0,PM_REMOVE)) {
	if (!hDlgPrint || !IsDialogMessage(hDlgPrint,&msg)) {
	       TranslateMessage(&msg);
	       DispatchMessage(&msg);
	}
    }
    return(!bUserAbort);

} /* AbortProc */

/* ******************************************************************* */

int PrintDoc(doc,pos,len)
Memh doc; /* document to print from */
long pos; /* starting position */
long len; /* length */
/* returns zreturn value */

{   int ii;
    int firstPage; /* first page to print */
    int lastPage; /* last page to print */
    int left; /* bias to left edge of print area */
    int pStart; /* TRUE if on paragraph boundary */
    FARPROC lpfnPrintDlgProc;
    HWND hWnd; /* handle on window */
    long viewStart,viewEnd,printPos;
    int retF;
	struct tutorview FAR *printView; /* view print started in */  
	RECT wRect; /* window rectangle */
	
    if (!pd.hDC)
		return(FILENOTOPEN);

    /* set up document, get range to print */

    DocBuffer(doc); /* be sure doc set up for view */
	if (CurrentWindow == ExecWn) {
    	/* make sure doc is set up with correct default styles */
		TUTORdefault_styles_font_doc(exS.baseFont,doc);
    }
    viewEnd = TUTORget_len_doc(doc);
    if (pos >= viewEnd)
		pos = viewEnd-1;
    if (pos < 0)
		pos = 0;
    if (len < 0)
		len = 0;
    if ((pos+len) > viewEnd)
		len = viewEnd-pos;
    if (len == 0)
		return(FILERANGE);

    viewStart = pos;
    viewEnd = pos+len;

    /* save the current window */ 
    
	SetFocus(CurrentWinH);
	ii = PreDialog(); /* set up for dialog box */
	if (!ii)
		return(FILEREGION); /* apparently couldn't save display */
	printView = CurrentView;

    /* deactivate our windows during printing */

    for(ii=0; ii<WINDOWLIMIT; ii++) {
		hWnd = (HWND)windowsP[ii].wp;
		if (hWnd)
	    	EnableWindow(hWnd,FALSE);
    }            

	inPrint = 1;
	CurrentDC = cTGetDC(NULL);
    TUTORdevice_color(CurrentDC);
    pageX = GetDeviceCaps(pd.hDC,HORZRES);
    pageY = GetDeviceCaps (pd.hDC,VERTRES);

    bUserAbort = FALSE;
    hWnd = (HWND)windowsP[CurrentWindow].wp;
    lpfnPrintDlgProc = MakeProcInstance ((FARPROC)PrintDlgProc,hcTInst);
    hDlgPrint = CreateDialog ((HINSTANCE)hcTInst,(LPCSTR)"PrintDlgBox",(HWND)hWnd,(DLGPROC)lpfnPrintDlgProc);
    SetDlgItemText (hDlgPrint, ID_PRINTNM, "Print");
	SetAbortProc(pd.hDC,(ABORTPROC)AbortProc);

    printPos = viewStart;
    pStart = TRUE;
	firstPage = pd.nFromPage;
	lastPage = pd.nToPage;
	if ((!firstPage) && (!lastPage)) {
		firstPage = 1;
		lastPage = 9999;
	}

    /* skip over pages that aren't to be printed */

    for (ii=1; ii<firstPage; ii++) {
		printPos = TUTORprint_doc(doc,printPos,viewEnd-printPos,pageX,pageY,
                        left,&pStart,FALSE);
        if (printPos >= viewEnd)
            break;
    } /* for */

	retF = StartDoc(pd.hDC,&di);
    if (retF <= 0) {
		retF = FILENOTOPEN;
		goto pEnd;
    }

	/* print the pages */

	TUTORinvalidate_font(); /* not set in this DC */
	TUTORset_textfont(exS.textFont);
	for (ii=firstPage; ii<=lastPage; ii++) {
		retF = StartPage(pd.hDC);
		if (retF < 0) {
			retF = FILENOTOPEN;
			goto pEnd;
		}
		TUTORabs_move_to(0,0);
		TUTORset_comb_rule(SRC_COPY);
	    printPos = TUTORprint_doc(doc,printPos,viewEnd - printPos,
        						pageX,pageY,left,&pStart,TRUE);
        retF = EndPage(pd.hDC);
	    if (retF < 0) {
			retF = FILENOTOPEN;
			goto pEnd;
	    }
		if (printPos >= viewEnd)
        	break; /* printed all there is */
		if (bUserAbort)
			break;
	} /* for */

	EndDoc(pd.hDC);
    retF = -1; /* exit happy */

pEnd:
    if (!bUserAbort)
		DestroyWindow(hDlgPrint);
    FreeProcInstance(lpfnPrintDlgProc);
   
    /* reactivate windows after printing */

    for(ii=0; ii<WINDOWLIMIT; ii++) {
		hWnd = (HWND)windowsP[ii].wp;
		if (hWnd)
	    	EnableWindow(hWnd,TRUE);
    }

    /* restore window settings */

    DeleteDC(pd.hDC);
    pd.hDC = 0;
	inPrint = 0; /* not drawing to printer */
    CurrentDC = cTGetDC(CurrentWinH);
	TUTORset_view(printView);
    TUTORdevice_color(CurrentDC);
	SetFocus(CurrentWinH);
    if (windowsP[CurrentWindow].winPalH && (!fMovieOpen) &&
       (!mControllerHasPalette)) {
		/* select current palette into device context */
		SelectPalette(CurrentDC,(HPALETTE)windowsP[CurrentWindow].winPalH,0);
		RealizePalette(CurrentDC);
    }
	if ((CurrentWindow == EditWn[0]) && (EditWn[0] >= 0))
		windowsP[EditWn[0]].winRedraw = TRUE; /* try full redraw */

	/* restore window contents */
	
    PostDialog(); /* finish cleanup after dialog */   
        
 	GetClientRect(CurrentWinH,(LPRECT)&wRect);
	ValidateRect(CurrentWinH,&wRect);
   
    return(retF);
}

/* ******************************************************************* */

/* printing routine */

long TUTORprint_doc(doc,pos,len,pageX,pageY,left,pStart,pFlag)
Memh doc;	/* document to be printed */
long pos, len;	/* portion of document to be printed */
int pageX, pageY; /* width & height of paper (portion to be drawn in) */
int left;	/* left edge of where we draw */
int *pStart;	/* set to TRUE if next page starts at paragraph boundary */
int pFlag;	/* TRUE if we want to actually draw */
/* returns position at end of printing */

{   REGISTER DocP dp;	    /* pointer to doc */
    int nLines;     /* # of lines laid out */
    int usedHeight; /* count of vertical space used */
    register int ii;
    Memh layoutH;   /* allocated memory for line layouts */
    LineLayout FAR *liLay;  /* pointer to line layouts (layoutH) */
    LineLayout FAR *llp;    /* used to scan thru layouts */
    StyleDatP sp;   /* pointer to styles */
    int styleInd;   /* index of current style block */
    ParagraphLayout pLay;   /* current paragraph layout */
    SpecialTP stp;  /* pointer to special text info */
    int stind;	    /* index of current special text block */
    short curStyles[NSTYLES];	    /* array of current styles */
    long printPos;  /* current printing position */
    int finished;   /* set to TRUE when we have filled the page */
    struct tutorColor fgndC; /* foreground color (black) */

    fgndC.palette = color_black;
    dp = (DocP) GetPtr(doc);
    while (TRUE) { /* until we've done enough for this page */
	nLines = (int)( (len > MAXLAYOUTLINES) ? MAXLAYOUTLINES : len);
	layoutH = TUTORhandle("printLay",(long) (sizeof(LineLayout)*nLines), FALSE);
	if (!(layoutH)) {
	    ReleasePtr(doc);
	    KillPtr(dp);
	    return(pos+len); /* terminate printing */
	}
	
	/* do the layout */
		
	liLay = (LineLayout FAR *) GetPtr(layoutH);
	_TUTORsetup_layout(dp,pos,len,&styleInd,( struct  _pdt FAR * *)&sp,curStyles,&pLay,&stind,&stp,TRUE);
/* not right, try to patch so output does go to printer */
if (!HaveDC) {
		CurrentDC = pd.hDC;
		HaveDC = TRUE;
}	
	_TUTORset_textfont_doc(dp,curStyles);
	if (!dp->shortText)
	    _TUTORload_buffer_doc(dp,pos);
		
	nLines = _TUTORlayout_lines(dp,pos,len,pageX,TRUE,0,sp,styleInd,
			liLay,curStyles,&pLay,stp,stind);
		
	if (sp) {
	    ReleasePtr(dp->styles);
	    KillPtr(sp);
	}
	if (stp) {
	    ReleasePtr(dp->specialT);
	    KillPtr(stp);
	}
		
	/* how far through the document does this page go */
	printPos = pos;
	printPos += liLay->nc; /* we always do first line */
	usedHeight = liLay->lineHeight;
	finished = FALSE;
	llp = liLay+1;
	for (ii=1; ii<nLines; ii++, llp++) {
	    if (usedHeight+llp->lineHeight >= pageY) {
		finished = TRUE;
		break; /* not enough room for next line */
	    }
	    usedHeight += llp->lineHeight;
	    printPos += llp->nc;
	} /* for */
		
	if (ii > 1 && ii < nLines -1 && llp->lineAsc == 0) {
	    /* back up, so that first line on next page isn't invisible */
	    ii--;
	    printPos -= (llp-1)->nc;
	}
/* not right, try to patch so output does go to printer */
if (!HaveDC) {
		CurrentDC = pd.hDC;
		HaveDC = TRUE;
}		
	if (pFlag) { /* actually draw it */
	    TUTORdraw_doc(doc,pos,printPos - pos,(struct tutorColor FAR *)&fgndC,left,pageX,pageY,TRUE,ii,
			 (char	FAR *) liLay,*pStart, NEARNULL,NEARNULL,FALSE);
	}
		
	*pStart = liLay[ii-1].endNewline;

	ReleasePtr(layoutH);
	KillPtr(liLay);
	TUTORfree_handle(layoutH);
		
	if (finished || printPos >= pos+len)
	    break; /* no more to do */
    } /* while */
	
    ReleasePtr(doc);
    KillPtr(dp);
	
    return(printPos);

} /* TUTORprint_doc */

/* ******************************************************************* */
