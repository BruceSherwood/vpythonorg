
/* #include <X11/Xatom.h> */
/* #include <X11/Xlib.h> */
/* #include <X11/Xutil.h> */
/* #include <X11/Xresource.h> */
/* #include <X11/cursorfont.h> */
/* #include <X11/keysym.h> */
