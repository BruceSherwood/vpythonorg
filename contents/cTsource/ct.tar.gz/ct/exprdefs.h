/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#ifndef _exprdefsh
#define _exprdefsh

#ifdef IBMPC
#define ARRAYHDR 64
#else
#ifdef hp700
#define ARRAYHDR (4*sizeof(long))
#else
#ifdef SOLARIS
#define ARRAYHDR (4*sizeof(long))
#else
#define ARRAYHDR (3*sizeof(long))
#endif
#endif
#endif

/* special codes for simple arithmetic tags */

#define ILIT 1  /* long (32-bit) integer literal */
#define ILITW 2 /* short (16-bit) integer literal */
#define ILITB 3 /* short (8-bit) integer literal */
#define FLIT 4  /* floating literal */
#define FLITS 5 /* short (24-bit) floating literal */
#define CCODE 6 /* compiled code */
#define DCODE 7 /* compiled code + pad for 32-bit alignment */

/* defined variable types */

#define NOTDEFINED 8    /* address var in unit args */
#define IARRAY 9        /* integer array */
#define BARRAY 10       /* integer (byte) array */
#define FARRAY 11       /* floating array */
#define MARRAY 12       /* marker array */
#define XARRAY 13       /* file, bitmap, etc array */
#define TBYTE 14        /* integer variable type */
#define TINT 15         /* integer variable type */
#define TFLOAT 16       /* floating variable type */
#define TMARK 17        /* string marker variable type */
#define TXTYPE 18       /* file, bitmap, etc */

/* expression token codes */

#define XGLOBALVAL 19   /* file, bitmap, etc global variable */
#define XLOCALVAL 20    /* file, bitmap, etc local variable */
#define XPASSVAL 21     /* file, bitmap, etc pass-by-address variable */
#define XGARRAYVAL 22   /* file, bitmap, etc global array element value */
#define XLARRAYVAL 23   /* file, bitmap, etc local array element value */
#define XPARRAYVAL 24   /* file, bitmap, etc pass-by-address array value */
#define XGARRAY 25      /* file, bitmap, etc unsubscripted global array */
#define XLARRAY 26      /* file, bitmap, etc unsubscripted local array */
#define XPARRAY 27      /* file, bitmap, etc unsubscripted pass array */
#define IGLOBALVAL 28   /* integer global variable */
#define BGLOBALVAL 29       /* byte global variable */
#define MGLOBALVAL 30       /* marker global variable */
#define IGLOBALADDR 31      /* integer global variable address */
#define BGLOBALADDR 32      /* byte global variable address */
#define MGLOBALADDR 33  /* marker global variable address */
#define ILOCALVAL 34    /* integer local variable */
#define BLOCALVAL 35        /* byte local variable */
#define MLOCALVAL 36        /* marker local variable */
#define ILOCALADDR 37       /* integer local variable address */
#define BLOCALADDR 38   /* byte local variable address */
#define MLOCALADDR 39   /* marker local variable address */
#define IPASSVAL 40     /* integer pass-by-address variable */
#define BPASSVAL 41         /* byte pass-by-address variable */
#define MPASSVAL 42     /* marker pass-by-address variable */
#define IPASSADDR 43        /* integer pass-by-address variable address */
#define BPASSADDR 44        /* byte pass-by-address variable address */
#define MPASSADDR 45        /* marker pass-by-address variable address */
#define IGARRAYVAL 46   /* integer global array element value */
#define BGARRAYVAL 47   /* byte global array element value */
#define MGARRAYVAL 48   /* marker global array element value */
#define IGARRAYADDR 49      /* integer global array element address */
#define BGARRAYADDR 50      /* byte global array element address */
#define MGARRAYADDR 51  /* marker global array element address */
#define ILARRAYVAL 52       /* integer local array element value */
#define BLARRAYVAL 53       /* byte local array element value */
#define MLARRAYVAL 54       /* marker local array element value */
#define ILARRAYADDR 55      /* integer local array element address */
#define BLARRAYADDR 56      /* byte local array element address */
#define MLARRAYADDR 57      /* marker local array element address */
#define IPARRAYVAL 58       /* integer pass-by-address array element value */
#define BPARRAYVAL 59       /* byte pass-by-address array element value */
#define MPARRAYVAL 60       /* marker pass-by-address array element value */
#define IPARRAYADDR 61      /* integer pass-by-address array element address */
#define BPARRAYADDR 62      /* byte pass-by-address array element address */
#define MPARRAYADDR 63  /* marker pass-by-address array element address */
#define IGARRAY 64      /* unsubscripted integer global array */
#define BGARRAY 65          /* unsubscripted byte global array */
#define MGARRAY 66          /* unsubscripted marker global array */
#define ILARRAY 67          /* unsubscripted integer local array */
#define BLARRAY 68          /* unsubscripted byte local array */
#define MLARRAY 69          /* unsubscripted marker local array */
#define IPARRAY 70          /* unsubscripted integer pass-by-address array */
#define BPARRAY 71          /* unsubscripted byte pass-by-address array */
#define MPARRAY 72          /* unsubscripted marker pass-by-address array */
#define ILT 73              /* integer lt */
#define ISPLT 74            /* linked integer lt */
#define IGT 75              /* integer gt */
#define ISPGT 76            /* linked integer gt */
#define ILE 77              /* integer le */
#define ISPLE 78            /* linked integer le */
#define IGE 79              /* integer ge */
#define ISPGE 80            /* linked integer ge */
#define IEQ 81              /* integer eq */
#define ISPEQ 82            /* linked integer eq */
#define INE 83              /* integer ne */
#define ISPNE 84            /* linked integer ne */
#define MLT 85          /* string lt */
#define MSPLT 86        /* linked string lt */
#define MGT 87          /* string gt */
#define MSPGT 88        /* linked string gt */
#define MLE 89          /* string le */
#define MSPLE 90        /* linked string le */
#define MGE 91          /* string ge */
#define MSPGE 92        /* linked string ge */
#define MEQ 93          /* string eq */
#define MSPEQ 94        /* linked string eq */
#define MNE 95          /* string ne */
#define MSPNE 96        /* linked string ne */
#define IBRANCHT 97 /* branch on integer true */
#define IBRANCHF 98 /* branch on integer false */
#define ITOF 99 /* integer-to-floating */
#define FTOI 100    /* floating-to-integer */
#define ENDI 101    /* integer end-expression */
#define ENDF 102    /* floating end-expression */
#define ENDM 103    /* string end-expression */
#define ENDC 104    /* continued -calc- end-expression */
#define MUNIT 105   /* marker expression to unit number conversion */
#define ISIGN 106
#define TXEQ 107    /* TXTYPE equals */
#define TXNEQ 108   /* TXTYPE not-equal */
#define IASSIGN 109 /* assign to integer */
#define BASSIGN 110 /* assign to byte */
#define MASSIGN 111 /* assign to marker */
#define IPLUS 112   /* integer add */
#define IINC 113    /* integer increment */
#define IMINUS 114  /* integer subtract */
#define IDEC 115    /* integer decrement */
#define ITIMES 116  /* integer multiply */
#define IUMINUS 117 /* integer unary minus */
#define EXPONIC 118 /* value to small integer power */
#define TCOORD 119  /* co-ordinate expression type */
#define ITOC 120    /* integer-to-coordinate */
#define FTOC 121    /* floating-to-coordinate */
#define COTOFN 122  /* coarse-grid to fine-grid conversion */
#define ZXYA 123    /* current absolute x/y position (Coord) */
#define ZXYR 124    /* current relative x/y position (floating) */
#define ZXYG 125    /* current graphing x/y position (floating) */
#define ZXYI 126    /* current absolute x/y position (integer) */
#define STORINF 127 /* return storeability info */
#define TPOINT 128
#define TDOT 129
#define TKEYWORD 130    /* keyword value */
#define TEXTARG 131 /* complex text */
#define TEXTARG1 132    /* simple text */
#define FRAC 133
#define INT 134
#define ROUND 135
#define ZPOSITION 136
#define SIGN 137
#define BITCNT 138
#define COMP 139
#define MCAT 140    
#define ZCODE 141
#define ZCHAR 142
#define ZFIRST 143
#define ZLAST 144
#define ZBASE 145
#define ZNEXT 146
#define ZPREVIOUS 147
#define ZCOPY 148
#define ZALTERED 149
#define ZSTART 150
#define ZEND 151
#define ZKS 152
#define XGDYARRAYVAL 153  /* global file, bitmap, etc dynamic array */
#define IGDYARRAYVAL 154  /* global integer dynamic array */
#define BGDYARRAYVAL 155  /* global byte dynamic array */
#define MGDYARRAYVAL 156  /* global marker dynamic array */
#define XGDYARRAYADDR 157 /* global file, bitmap, etc dynamic array addr */
#define IGDYARRAYADDR 158 /* global integer dynamic array addr */
#define BGDYARRAYADDR 159 /* global byte dynamic array addr */
#define MGDYARRAYADDR 160 /* global marker dynamic array addr */
#define XGDYARRAY 161 /* global unsubscripted file, bitmap etc dynamic array */
#define IGDYARRAY 162 /* global unsubscripted integer dynamic array */
#define BGDYARRAY 163 /* global unsubscripted byte dynamic array */
#define MGDYARRAY 164 /* global unsubscripted marker dynamic array */
#define XLDYARRAYVAL 165  /* local file, bitmap, etc dynamic array */
#define ILDYARRAYVAL 166  /* local integer dynamic array */
#define BLDYARRAYVAL 167  /* local byte dynamic array */
#define MLDYARRAYVAL 168  /* local marker dynamic array */
#define XLDYARRAYADDR 169 /* local file, bitmap, etc dynamic array addr */
#define ILDYARRAYADDR 170 /* local integer dynamic array addr */
#define BLDYARRAYADDR 171 /* local byte dynamic array addr */
#define MLDYARRAYADDR 172 /* local marker dynamic array addr */
#define XLDYARRAY 173 /* local unsubscripted file, bitmap etc dynamic array */
#define ILDYARRAY 174 /* local unsubscripted integer dynamic array */
#define BLDYARRAY 175 /* local unsubscripted byte dynamic array */
#define MLDYARRAY 176 /* local unsubscripted marker dynamic array */
#define XPDYARRAYVAL 177  /* pass file, bitmap, etc dynamic array */
#define IPDYARRAYVAL 178  /* pass integer dynamic array */
#define BPDYARRAYVAL 179  /* pass byte dynamic array */
#define MPDYARRAYVAL 180  /* pass marker dynamic array */
#define XPDYARRAYADDR 181 /* pass file, bitmap, etc dynamic array addr */
#define IPDYARRAYADDR 182 /* pass integer dynamic array addr */
#define BPDYARRAYADDR 183 /* pass byte dynamic array addr */
#define MPDYARRAYADDR 184 /* pass marker dynamic array addr */
#define XPDYARRAY 185 /* pass unsubscripted file, bitmap etc dynamic array */
#define IPDYARRAY 186 /* pass unsubscripted integer dynamic array */
#define BPDYARRAY 187 /* pass unsubscripted byte dynamic array */
#define MPDYARRAY 188 /* pass unsubscripted marker dynamic array */

/* symbols in range 200-299 in yacc.h */
#define SQRT 300
#define ABS 301
#define EXP 302
#define LOG 303
#define LN 304
#define SINH 305
#define COSH 306
#define TANH 307
#define GAMMA 308
#define ALOG 309
#define ZTEXTSEL 310
#define ZTEXTVIS 311
#define LOOPCHK 312
#define ULOCADDR 313
#define ULOCTABL 314
#define CASETAB 315
#define ZVALUEB 316
#define ZVALUES 317
#define ZVALUEDDE 318
#define ZHOTINFOE 319
#define ZHOTSEL 320
#define ZNEXTWORD 321
#define SIN 322
#define COS 323
#define TAN 324
#define CSC 325
#define SECANT 326
#define COT 327
#define ARCSIN 328
#define ARCCOS 329
#define ARCCSC 330
#define ARCSEC 331
#define ARCCOT 332
#define ZNEXTLINE 333
#define ZFILENAME 334
#define ZFILEPATH 335
#define ZNICONS 336
#define ZNEXTNUM 337
#define ZNEXTEXPR 338
#define ZHOTINFOM 339
#define ZEDITBASE 340
#define ZSWIDTH 341
#define ZSHEIGHT 342
#define ZFACTORIAL 343

/* 344-349 unused */

/* codes for routines called from compiled code */
    
#define EXS_SPNE 350
#define EXS_MSPLT 351
#define EXS_MSPGT 352
#define EXS_MSPLE 353
#define EXS_MSPGE 354
#define EXS_MSPEQ 355
#define EXS_MSPNE 356
#define EXS_ISPLT 357
#define EXS_ISPGT 358
#define EXS_ISPLE 359
#define EXS_ISPGE 360
#define EXS_ISPEQ 361
#define EXS_ISPNE 362
#define EXS_TEXTARG1 363
#define EXS_MPASSVAL 364
#define EXS_MPASSADDR 365
#define EXS_STOREADDR 366
#define EXS_FLOATINIT 367
#define EXS_XGLOBALVAL 368
#define EXS_XLOCALVAL 369
#define EXS_XPASSVAL 370
#define EXS_MLITC 371
#define EXS_TSYSVAR 372
#define EXS_ARRAYERR 373
#define EXS_LOCALP 374
#define EXS_GLOBALP 375
#define EXS_ISTACK 376
#define EXS_IRESP 377
#define EXS_FSTACK 378
#define EXS_FRESP 379
#define EXS_BINP 380
#define EXS_PCODEP 381
#define EXS_EXPONIC 382
#define EXS_PARRAY 383
#define EXS_GARRAYVAL 384
#define EXS_GARRAYADDR 385
#define EXS_IGARRAYVAL 386
#define EXS_IGARRAYADDR 387
#define EXS_BGARRAYVAL 388
#define EXS_BGARRAYADDR 389
#define EXS_MGARRAYVAL 390
#define EXS_MGARRAYADDR 391
#define EXS_LARRAYVAL 392
#define EXS_LARRAYADDR 393
#define EXS_ILARRAYVAL 394
#define EXS_ILARRAYADDR 395
#define EXS_BLARRAYVAL 396
#define EXS_BLARRAYADDR 397
#define EXS_MLARRAYVAL 398
#define EXS_MLARRAYADDR 399
#define EXS_MLITERAL 400
#define EXS_MGLOBALVAL 401
#define EXS_MLOCALVAL 402
#define EXS_STORINF 403
#define EXS_PARRAYVAL 404
#define EXS_IPARRAYVAL 405
#define EXS_BPARRAYVAL 406
#define EXS_MPARRAYVAL 407
#define EXS_PARRAYADDR 408
#define EXS_IPARRAYADDR 409
#define EXS_BPARRAYADDR 410
#define EXS_MPARRAYADDR 411
#define EXS_SPLT 412
#define EXS_SPGT 413
#define EXS_SPLE 414
#define EXS_SPGE 415
#define EXS_SPEQ 416
#define EXS_GDYARRAYVAL 417
#define EXS_GDYARRAYADDR 418
#define EXS_IGDYARRAYVAL 419
#define EXS_IGDYARRAYADDR 420
#define EXS_BGDYARRAYVAL 421
#define EXS_BGDYARRAYADDR 422
#define EXS_MGDYARRAYVAL 423
#define EXS_MGDYARRAYADDR 424
#define EXS_XGDYARRAYVAL 425
#define EXS_XGDYARRAYADDR 426
#define EXS_LDYARRAYVAL 427
#define EXS_LDYARRAYADDR 428
#define EXS_ILDYARRAYVAL 429
#define EXS_ILDYARRAYADDR 430
#define EXS_BLDYARRAYVAL 431
#define EXS_BLDYARRAYADDR 432
#define EXS_MLDYARRAYVAL 433
#define EXS_MLDYARRAYADDR 434
#define EXS_XLDYARRAYVAL 435
#define EXS_XLDYARRAYADDR 436
#define EXS_PDYARRAYVAL 437
#define EXS_PDYARRAYADDR 438
#define EXS_IPDYARRAYVAL 439
#define EXS_IPDYARRAYADDR 440
#define EXS_BPDYARRAYVAL 441
#define EXS_BPDYARRAYADDR 442
#define EXS_MPDYARRAYVAL 443
#define EXS_MPDYARRAYADDR 444
#define EXS_XPDYARRAYVAL 445
#define EXS_XPDYARRAYADDR 446
#define EXS_GDYARRAY 447
#define EXS_LDYARRAY 448
#define EXS_SYSVAR 449
#define EXS_ISYSVAR 450
#define EXS_MSYSVAR 451
#define EXS_MSYSVARA 452
#define EXS_EFUNCT 453

/* 454-459 unused */

#define XT_MAX 460 /* maximum value for xt[] table */

/* symbols 450+ in commands.h */

#define ZXMIN 1 /* numeric reserved words */
#define ZXMAX 2
#define ZYMIN 3
#define ZYMAX 4
#define ZCLOCK 5
#define ZDAY 6
#define ZDEVICE 7
/* 8 unused */
#define ZKEY 9
/* 10 unused */
#define ZRETINF 11
#define ZRETURN 12
#define ZRESHAPE 13
#define ZTOUCHX 14
#define ZTOUCHY 15
#define ZGTOUCHX 16
#define ZGTOUCHY 17
#define ZRTOUCHX 18
#define ZRTOUCHY 19
#define ZWHEREX 20
#define ZWHEREY 21
#define ZJCOUNT 22
#define ZJUDGED 23
#define ZANSCNT 24
#define ZCAPS 25
#define ZENTIRE 26
#define ZEXTRA 27
#define ZNTRIES 28
#define ZOPCNT 29
#define ZVARCNT 30
#define ZORDER 31
#define ZSPELL 32
#define ZWCOUNT 33
#define ZHEIGHT 34
#define ZWIDTH 35
#define ZXPIXELS 36
#define ZYPIXELS 37
#define ZNCOLORS 38
#define ZCOLORF 39
#define ZCOLORB 40
#define ZWCOLOR 41
#define ZVTIME 42
#define ZLEFTDOWN 43
#define ZRIGHTDOWN 44
#define ZEDITKEY 45
#define ZEDITX 46
#define ZEDITY 47
#define ZVWIDTH 48
#define ZVHEIGHT 49
#define ZVLENGTH 50
#define ZDBLCLICK 51
#define ZFORWARD 52
#define ZMODE 53
#define ZVCHEIGHT 54
#define ZVPLAYING 55
#define ZMOUSEX 56
#define ZMOUSEY 57

/* string reserved words */

#define ZEMPTY 1
#define ZARROWM 2
#define ZHOMEDIR 3
#define ZUSER 4
#define ZSANS 5
#define ZSERIF 6
#define ZFIXED 7
#define ZSYMBOL 8
#define ZPATTERNS 9
#define ZICONS 10
#define ZCURSORS 11
#define ZMACHINE 12
#define ZMAINU 13
#define ZCURRENTU 14
#define ZARROWSEL 15
#define ZFROMPROG 16
#define ZDATE 17
#define ZTIME 18
#define ZCURRENTDIR 19

/* TXTYPE reserved words */

#define ZEDIT 1
#define ZSLIDER 2
#define ZBUTTON 3
#define ZDDE 4

/* TXTYPE subtypes */

#define TXFILE 1001
#define TXSCREEN 1002
#define TXBUTTON 1003
#define TXSLIDER 1004
#define TXEDIT 1005
#define TXTOUCH 1006
#define TXDDE 1007

/* relocation table entry types */

/* branch types */

#define R_COND 1        /* conditional command */
#define R_IF1 2         /* -if- initial branch */
#define R_IF2 3         /* -if- terminal branch */
#define R_CASE1 4       /* -case- pointer to else */
#define R_CASE2 5       /* -case- pointer to table */
#define R_CASE3 6       /* -case- pointer to endcase */
#define R_CASE4 7       /* -case- table entry */
#define R_CLAUSE 8      /* -case- command clause initial branch */
#define R_CLAUSEB 9     /* -case- command (caset) branch to clause body */
#define R_LOOP1 10      /* -loop- command forward ref to body */
#define R_LOOP2 11      /* -loop- command forward ref to exit */
#define R_LOOP3 12      /* -loop- command backwards ref to loop */
#define R_ARROW1 13     /* -arrow- command forward ref to ifmatch */
#define R_ARROW2 14     /* -arrow- command forward ref to endarrow */
#define R_PREANS 15     /* answer type command forward ref to exdent */
#define R_EXPRES 16     /* internal branch within expression */

/* destination types */

#define RD_MIN 20       /* minimum destination code */
#define RD_NULL 20      /* unused label */
#define RD_COND1 21     /* conditional command end */
#define RD_COND2 22     /* conditional command table */
#define RD_COND3 23     /* conditional command clause */
#define RD_ELSE 24
#define RD_ELSEIF 25
#define RD_ENDIF 26 
#define RD_CLAUSE 27    /* -case- command clause */
#define RD_CLAUSEB 28   /* body of -case- clause */
#define RD_CASEELSE 29  /* -else- in case structure */
#define RD_ENDCASE 30
#define RD_CASET 31     /* -case- command table */
#define RD_PREANS 32
#define RD_ENDANS 33    /* answer type command */
#define RD_ARROW 34     /* all internal -arrow- commands */
#define RD_IFMATCH 35   /* -ifmatch- command */
#define RD_ENDARROW 36  /* -endarrow- command */
#define RD_LOOP1 37     /* body of loop */
#define RD_LOOP2 38     /* end of loop */
#define RD_LOOP3 39     /* top of loop */
#define RD_EXPRES 40    /* destination within expression */
 
struct locref { /* local (within unit) cross-reference */
    char kind; /* kind of reference or label */
    char reloc; /* kind of relocation (unit relative, pc relative) */
    int label; /* id of label or label referenced */
    unsigned short aref; /* address of reference or label */
    unsigned short adest; /* address of destination */
}; /* locref */


/* tokens for keyword/argument format commands */

#define KW_EDITABLE 1
#define KW_CORNER 2
#define KW_ERASE 3
#define KW_DEFMENU 4
#define KW_FACEMENU 5
#define KW_FONTMENU 6
#define KW_SIZEMENU 7
#define KW_COLORMENU 8
#define KW_JUSTMENU 9
#define KW_HSCROLL 10
#define KW_VSCROLL 11
#define KW_FRAME 12
#define KW_ROUNDBOX 13
#define KW_CHECK 14
#define KW_RADIO 15
#define KW_VALUE 16
#define KW_ACTIVE 17
#define KW_WRITEONLY 18 
#define KW_PAGE 19
#define KW_LINE 20
#define KW_RANGE 21
#define KW_NUMERIC 22
#define KW_READWRITE 23
#define KW_READONLY 24
#define KW_STYLED 25
#define KW_THREED 26        /* new motif-ish button, BJM 6/3/91 */
#define KW_SELECT 27
#define KW_VISIBLE 28
#define KW_PLAIN 29
#define KW_BOLD 30
#define KW_ITALIC 31
#define KW_HOTSTYLE 32
#define KW_PLAINEST 33
#define KW_SUPSCRIPT 34
#define KW_SUBSCRIPT 35
#define KW_FULLJUST 36
#define KW_LEFTJUST 37
#define KW_RIGHTJUST 38
#define KW_CENTER 39
#define KW_BLACK 40
#define KW_WHITE 41
#define KW_RED 42
#define KW_GREEN 43
#define KW_BLUE 44
#define KW_YELLOW 45
#define KW_CYAN 46
#define KW_MAGENTA 47
#define KW_DEFCOLORST 48
#define KW_HOTUNIT 49
#define KW_SERIF 50
#define KW_SANS 51
#define KW_TYPEWRITER 52
#define KW_SYMBOL 53
#define KW_BIGGER 54
#define KW_SMALLER 55
#define KW_TAB 56
#define KW_FICONS 57
#define KW_LEFTMAR 58
#define KW_RIGHTMAR 59
#define KW_ICON 60
#define KW_BEFORE 61
#define KW_AFTER 62
#define KW_TOUCH 63
#define KW_TUNIT 64
#define KW_TPRIORITY 65
#define KW_SINGLESEL 66
#define KW_FOCUSCLK 67
#define KW_HIGHLIGHT 68
#define KW_SYSFONTHT 69
#define KW_DEFCOLOR 70
#define KW_DEFRGB 71
#define KW_PALETTESZ 72
#define KW_DALERT 73
#define KW_DCOLOR 74
#define KW_DYNC 75
#define KW_DOK 76
#define KW_DINPUT 77
#define KW_NEWLINEH 78
#define KW_SUPSUB 79
#define KW_DEFFGND 80
#define KW_DEFBGND 81
#define KW_UPHOT 82
#define KW_DPRINTS 83
#define KW_DPRINTX 84
#define KW_IMAGESTYLE 85
#define KW_SUPSUBADJ 86    
#define KW_FNAME 87

#endif /* exprdefsh */
