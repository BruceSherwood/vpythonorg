
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
 Routines auxiliary to the cT lexical analyzer.
*/

#include "ctutor.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "exprdefs.h"
#include "yacc.h"

#ifdef ctproto
extern int TUTORalert(int wn, char *msg);
extern int strncmpf(char FAR *aa,char FAR *bb,int nn);
int  StopProgram(char  *s);
extern Memh LoadTable(char *tableFile,int *tableSize);
void get_fct_table(void);
int find_def_sym(Memh topSetH,char *s,Memh *retSet,int *retIndex);
int  lexname(int  partial,char  *yytext,int  yyleng);
int  seekvar(int  partial,char  *yytext,int  yyleng);
extern int  mystrcmp(char  *suser,char  *svar);
int  deflook(char  *s,int  glf,int  symi);
extern int  retfunct(int  fct,int  type,char  *yytext,int  yyleng);
extern int  mretsys(int  svar,char  *yytext,int  yyleng);
extern int  tretsys(int  svar,char  *yytext,int  yyleng);
extern int  retsys(int  svar,char  *yytext,int  yyleng);
extern int  iretsys(int  svar,char  *yytext,int  yyleng);
extern int  ifretsys(int  svar,char  *yytext,int  yyleng,int  floatf);
extern int  retnum(int partial,char  *yytext,int yyleng);
char  FAR *GetPtr(unsigned int  mm);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  n_myunput(int  nc);
char  *strf2n(char  FAR *strp);
int  n_restart(void);
extern int TUTORzero(char SHUGE *ptr,long lth);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
long  TUTORget_len_doc(unsigned int  doc);
extern int set_wk_defset(Memh setH);
extern int strcmpf(char FAR *aa,char FAR *bb);
int chop_def_sym(struct defset FAR *setP,char *str);
int find_def_sym(Memh topSetH,char *s,Memh *retSet,int *retIndex);
int  lexname(int  partial,char  *yytext,int  yyleng);
int  seekvar(int  partial,char  *yytext,int  yyleng);
extern int  mystrcmp(char  *suser,char  *svar);
int  deflook(char  *s,int  glf,int  symi);
char  FAR *GetPtr(unsigned int  mm);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  n_myunput(int  nc);
char  *strf2n(char  FAR *strp);
int  n_restart(void);
extern int TUTORzero(char SHUGE *ptr,long lth);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
long  TUTORget_len_doc(unsigned int  doc);
#endif /* ctproto */

#ifdef IBMPC
extern char *strcpy(char *aa, char *bb);
#endif

extern long TUTORget_len_doc();
extern double lcitof();
extern int yyForceErr;

/* ******************************************************************* */

struct zfctd {			/* reserved function definition */
	char name[12];
	short code;
	short type;
};

/* 0 = retfunct  (FUNCT) */
/* 1 = retcfunct (function code) */
/* 2 = retsys    (SYSVAR) */
/* 3 = iretsys   (ISYSVAR) */
/* 4 = mretsys   (MSYSVAR) */
/* 5 = integer   (ILITERAL) */

static Memh zfcttabH = HNULL;
static struct zfctd FAR *zfcttab = FARNULL;

char *kUnrecStr = "Unrecognized variable name: ";

/* ******************************************************************* */

void get_fct_table()

{
    if (!zfcttabH) {
		zfcttabH = LoadTable("function.tab",NEARNULL);
		if (!zfcttabH) {
			TUTORalert(-1,"Can't find file function.tab");
			StopProgram("");
		}
	}
    if (!zfcttab)
		zfcttab = (struct zfctd FAR *)GetPtr(zfcttabH);

} /* get_fct_table */

/* ******************************************************************* */

lexname(partial,yytext,yyleng)		/* identify name in yytext */
int partial;
char *yytext;
int yyleng;

{	int found;
	int ii; /* index in functions table */

	/* search for simple reserved function */

	ii = 0;
	while (zfcttab[ii].type >= 0) {
		if (strncmpf((char FAR *)yytext, zfcttab[ii].name, 10) == 0) {
			if (zfcttab[ii].type == 0)
				return (retfunct(zfcttab[ii].code,0,yytext,yyleng));
			if (zfcttab[ii].type == 1)
				return (retfunct(zfcttab[ii].code,1,yytext,yyleng));
			if (zfcttab[ii].type == 2) {
				found = retsys(zfcttab[ii].code,yytext,yyleng);
				return(found);
			} if (zfcttab[ii].type == 3)
				return (iretsys(zfcttab[ii].code,yytext,yyleng));
			if (zfcttab[ii].type == 4)
				return (mretsys(zfcttab[ii].code,yytext,yyleng));
			if (zfcttab[ii].type == 5) {
				yylval.lval = zfcttab[ii].code;
				return(previous = ILITERAL);
			}
			if (zfcttab[ii].type == 6) {
				return (tretsys(zfcttab[ii].code,yytext,yyleng));
			}
		} /* strncmp if */
		ii++;
	} /* while */

	found = seekvar(partial,yytext,yyleng);
	if (found == NAMEERR) { /* eliminate less-likely possibilities */
		found = retnum(partial,yytext,yyleng);
		if (found == NAMEERR)
			yyForceErr = TRUE; /* not identified */
	} /* found if */
	
	return(found);

} /* lexname */

/* ******************************************************************* */


#define UNDEFMSGL 32+NAMEL
static char undefmsg[UNDEFMSGL];

static seekvar(partial,yytext,yyleng)
	/* seek yytext name in user defines */
	/* return variable type, set yylval appropriately */
	/* return NAMEERR if do not find name *
int partial; /* TRUE if partial match for user variables desired */
char *yytext; /* name string */
int yyleng; /* length of name string */

{	int dii; /* index in symbol table */
	int matchlth; /* length of best match so far */
	int compare; /* result of last symbol compare */
	int retcod; /* return value */
	Memh fSetH; /* handle on found set */
	int fIndex; /* index of symbol found */
	Memh udH; /* handle on user define set */
	struct defset FAR *udP; /* pointer to user define set */
	struct defvar FAR *uvP; /* pointer to user variable names */
	struct defvar FAR *symP; /* pointer to next symbol */
	struct defvar FAR *matchP; /* pointer to symbol that best matches */

	if ((previous == FLITERAL) || (previous == ILITERAL) ||
	    (previous == RIGHTPAREN)) {
		n_restart();
		return (previous = TIMES); /* implied multiplication */
	}
	
	retcod = 0; /* havent found anything yet */
	if (exa->userc) {
		
		/* run time, search "user" defines, allow possible partial match */
	
		if (previous == GLOBALVAL) {
			n_restart();
			return(previous = TIMES); /* implied multiplication */
		} 
		symP = FARNULL; /* no symbol table yet */
		matchlth = 0; /* no match yet */
		matchP = FARNULL;
	
		/* check if can find exact match */
		
		if (find_def_sym(userSetH,yytext,&fSetH,&fIndex)) {
			udP = (struct defset FAR *)GetPtr(fSetH);
			symP = (struct defvar FAR *)GetPtr(udP->defvarH);
			uvP = symP;
			symP += fIndex;
			matchP = symP;
			matchlth = yyleng;
		} /* find_def_sym if */

		/* if no exact match, search user set for partial */

		/* this probably isnt right - should look for best */
		/* partial match in all merged sets */

		if (!matchP) {
			fSetH = userSetH; /* set to base user set */
			udP = (struct defset FAR *)GetPtr(fSetH);
			if (udP->defvarH) {
				uvP = (struct defvar FAR *)GetPtr(udP->defvarH);
				symP = uvP; /* pointer to next symbol */
			}

			for(dii=0; dii<udP->defvarN; dii++) {
		
				/* compare yytext to next defined symbol */
	
				compare = mystrcmp(yytext,strf2n(symP->name));
				if (compare < 0) {	/* strings match exactly */
					matchlth = -compare;
					matchP = symP;
					break;
				}

				/* yytext starts with defined name */

				if (partial && (compare > matchlth)) {	
					matchlth = compare;
					matchP = symP; /* best match so far */
				}
				symP++; /* advance to next symbol */
			} /* for */
		} /* matchP if */
		
		/* handle partial match */
		
		if (matchP && (yyleng > matchlth)) {
			n_myunput(yyleng-matchlth);
		} /* matchP if */
		
		/* determine type of find, if any */
		
		if (matchP) {	/* found a match */
			if (matchP->literal) {
				yylval.dval = matchP->dvalue;
				retcod = FLITERAL;
			} else { 
				/* return defloc = 16/set, 16/index */
				yylval.defloc = matchP-uvP; /* index in symbols */
				yylval.defloc |= ((long)(userSetH)) << 16;
				if (matchP->arrayinfo >= 0) { /* if global array */
					retcod = GARRAYVAL;
				} else {/* ordinary global variable */
					retcod = GLOBALVAL;
				}
			}
		} /* matchP if */

		if (udP->defvarH)
			ReleasePtr(udP->defvarH);
		KillPtr(uvP);
		ReleasePtr(fSetH);
		KillPtr(udP);
	} else {
	
		/* compile time, search current define set */
		
		if (find_def_sym(wkSetH,yytext,&fSetH,&fIndex)) {
			/* return defloc = 16/set, 16/index */
			yylval.defloc = fIndex; /* index in symbols */
			yylval.defloc |= ((long)fSetH) << 16;
			udP = (struct defset FAR *)GetPtr(fSetH);
			if (!udP->local) { /* global variable */
				if (compunit)
					unittab[compunit].hasglobals = TRUE; /* unit references globals */
			}
			symP = (struct defvar FAR *)GetPtr(udP->defvarH);
			matchP = symP+fIndex;
			if (matchP->literal) {
				yylval.dval = matchP->dvalue;
				retcod = FLITERAL;
			} else if (udP->local) { /* local variable */
				if (matchP->receive) { /* pass-by-address */
					if (matchP->arrayinfo >= 0) { /* if passed array */
						if (matchP->dynamic)
							retcod = PDYARRAYVAL;
						else
							retcod = PARRAYVAL;
					} else { /* pass-by-addr variable */
						retcod = PASSVAL;
					}
				} else if (matchP->arrayinfo >= 0) { /* if local array */
					if (matchP->dynamic) /* dynamic array */
						retcod = LDYARRAYVAL;
					else
						retcod = LARRAYVAL;
				} else { /* ordinary local variable */
					retcod = LOCALVAL;
				}
			} else { /* global variable */
				if (matchP->arrayinfo >= 0) { /* if global array */
					if (matchP->dynamic) /* dynamic array */
						retcod = GDYARRAYVAL;
					else
						retcod = GARRAYVAL;
				} else { /* ordinary global variable */
					retcod = GLOBALVAL;
				}
			} /* global else */
			ReleasePtr(udP->defvarH);
			KillPtr(symP);
			ReleasePtr(fSetH);
			KillPtr(udP);
		} /* find_def if */
		
	} /* user else */
	
	if (retcod) {
		return(previous = retcod); /* return type code */
	}
	
	/* error return - didn't find anything */
	
	TUTORzero((char SHUGE *)undefmsg,(long)(UNDEFMSGL-1));
	strcpy(undefmsg,kUnrecStr);
	strncat(undefmsg,yytext,NAMEL);
	exa->errmess = undefmsg;
	exa->errnum = NAMEERR;
	return (NAMEERR);

} /* seekvar */

/* ******************************************************************* */

static mystrcmp(suser, svar) /* if suser identical to svar, return -strlen(svar) */
                      /* if suser starts with svar, return strlen(svar) */
                      /* else return 0 */
register char *suser;	/* symbol to search for */
register char *svar; 	/* current defined name to compare against */

{	register int len;

	len = 0;
	while (*svar == *suser) {
  		if (*svar == 0) return(-len); /* full match */
  		svar++; suser++;
  		len++;
	} /* while */
	if (*svar == 0) return(len); /* partial match */
	return(0); /* no match */

} /* mystrcmp */

/* ******************************************************************* */

static retfunct(fct, type, yytext, yyleng)   /* used for sin/cos/etc. */
int fct;
int type;
char *yytext;
int yyleng;

{	int var;	
	char c;		/* current character code */
	long dp;	/* starting position for delete */
	long dn;	/* number chars to delete */
	int drm;	/* document read/write mode */
	int retval;  /* value to be returned */

	/* check for implied multiply */

	if ((previous == FLITERAL) || (previous == ILITERAL) || 
	   (previous == RIGHTPAREN) ||
	   (exa->userc && previous == GLOBALVAL)) {
		n_restart(); return(previous=TIMES);
	} /* if */

	/* check for user-defined expression */

	var = seekvar(FALSE,yytext,yyleng);
	if (var != NAMEERR) return(previous = var);

	exa->errnum = 0;
	if (type != 1)
		yylval.ival = fct;

	if (type == 0)
		retval = FUNCT;
	else if (type == 1)
		retval = fct;

	return(previous = retval);

} /* retfunct */

/* ******************************************************************* */

static mretsys(svar,yytext,yyleng)	/* process string reserved word */
int svar; 	/* index of string reserved word */
char *yytext;
int yyleng;

{	int var;

	var = seekvar(FALSE,yytext,yyleng);	/* check if user-defined */
	if (var != NAMEERR) {
		return(previous = var);
	}
	exa->errnum = 0;
	if (exa->userc) {
		exa->errmess = "Unrecognized variable name.";
		exa->errnum = NAMEERR;
		return(NAMEERR);
	} /* if */


	/* zempty - set up zero length string literal */

	if (svar == ZEMPTY) {
		yylval.lval = TUTORget_len_doc(exa->text); /* addr of string */
		InsertString(exa->text,(long) (yylval.lval),(char FAR *)"  ",2L);
		yylval.lval -= exa->textbase; /* make relative to unit/expr */
		return(MLITERAL);
	} /* zempty if */

	yylval.lval = svar;
	return(previous = MSYSVAR);

} /* mretsys */

/* ******************************************************************* */

static tretsys(svar,yytext,yyleng) /* process TXTYPE reserved word */
int svar; /* index of string reserved word */
char *yytext;
int yyleng;

{	int var;

	var = seekvar(FALSE,yytext,yyleng);	/* check if user-defined */
	if (var != NAMEERR) {
		return(previous = var);
	}
	exa->errnum = 0;
	if (exa->userc) {
		exa->errmess = "Unrecognized variable name.";
		exa->errnum = NAMEERR;
		return(NAMEERR);
	} /* if */

	yylval.lval = svar;
	return(previous = TSYSVAR);

} /* tretsys */

/* ******************************************************************* */

static retsys(svar,yytext,yyleng) /* floating reserved word */
int svar;
char *yytext;
int yyleng;

{
	return(ifretsys(svar,yytext,yyleng,TRUE));
	
} /* retsys */

/* ******************************************************************* */

static iretsys(svar,yytext,yyleng) /* integer reserved word */
int svar;
char *yytext;
int yyleng;

{
	return(ifretsys(svar,yytext,yyleng,FALSE));
	
} /* iretsys */

/* ******************************************************************* */

static ifretsys(svar,yytext,yyleng,floatf)
int svar;
char *yytext;
int yyleng;
int floatf; /* TRUE if floating reserved word */

{	int var;

	if ((previous == FLITERAL) || (previous == ILITERAL) ||
	   (previous == RIGHTPAREN)) { 
		n_restart(); 
		return(previous=TIMES); 
	}
	var = seekvar(FALSE,yytext,yyleng);
	if (var != NAMEERR) {
		return(previous = var);
	}
	exa->errnum = 0;
	if (exa->userc) {
		exa->errmess = "Unrecognized variable name.";
		exa->errnum = NAMEERR;
		return(NAMEERR); 
	}
	yylval.lval = svar;

	if (floatf)
		return(previous = SYSVAR); 
	return(previous = ISYSVAR);
	
} /* ifretsys */

/* ******************************************************************* */

static retnum(partial,yytext,yyleng) /* check for TRUE, PI, FALSE, DEG */
int partial; /* TRUE if should accept partial match */
char *yytext; /* name to recognize */
int yyleng; /* length of yytext */
	
{	char cc;
	int retval;
	int matched; /* for PI/DEG: 0 = no match, 1 = full match, 2 = partial match */
	int matchlth; /* length of partial match */

	cc = yytext[0];
	retval = NAMEERR; /* normal return */
	matched = 0;
	
	switch(cc) {
		case 'T':
			if (strcmp(yytext,"TRUE") == 0) {
				retval = FLITERAL;
				yylval.dval = -1.0;
			}
			break;
		case 'F':
			if (strcmp(yytext,"FALSE") == 0) {
				retval = FLITERAL;
				yylval.dval = 0.0;
			}
			break;
		case 'D':
			if (strcmp(yytext,"DEG") == 0) 
				matched = 1; /* full match */
			else if (partial && (strncmp(yytext,"DEG",3) == 0)) {
				matched = 2; /* partial match */
				matchlth = 3;
			}
			if (matched) {
				retval = FLITERAL;
				yylval.dval = 3.1415926535897932/180.0;
			}
			break;
		case 'P':
			if (strcmp(yytext,"PI") == 0) 
				matched = 1;
			else if (partial && (strncmp(yytext,"PI",2) == 0)) {
				matched = 2; /* partial match */
				matchlth = 2;
			}
			if (matched) {
				retval = FLITERAL;
				yylval.dval = 3.1415926535897932;
			}
			break;
	} /* switch */
	
	/* handle partial match */
		
	if ((matched == 2) && (yyleng > matchlth)) {
			n_myunput(yyleng-matchlth);
	} /* match if */
	
	if (retval == FLITERAL) { /* found literal, clear error */
		exa->errnum = 0;
		previous = retval;
	}

	return(retval);
	
} /* retnum */

/* ******************************************************************* */

int find_def_sym(topSetH,s,retSet,retIndex) /* search for defined name */
/* returns TRUE if found, FALSE if not */
Memh topSetH; /* handle on top define set for search */
char *s; /* pointer to defined symbol name */
Memh *retSet; /* handle on set symbol found in */
int *retIndex; /* +n = position of name if found */
               /* -n = -(insert position+1) if not found */

{	int wkfound; /* index of name in current working define set */
	int mgfound; /* index of name in merged define set */
	int mii; /* index in merged define sets */
	struct defset FAR *topSetP; /* ptr to top level set for search */
	long FAR *mtabP; /* pointer to table of merged sets */
	Memh msetH; /* handle on next merged define set */
	struct defset FAR *msetP; /* pointer to next merged define set */

	/* first search symbols in current define set */
	
	wkfound = -1; /* not found in current set yet */
	mgfound = -1; /* not found in merged set yet */
	topSetP = (struct defset FAR *)GetPtr(topSetH);
	if (topSetP->defvarN) {
		wkfound = chop_def_sym(topSetP,s); /* search in current set */
		if (wkfound >= 0) {
			*retIndex = wkfound; /* index in set */
			*retSet = topSetH; /* handle on set */
			ReleasePtr(topSetH);
			return(TRUE); /* found in current set */
		} /* wkfound if */
	} /* defvarN if */
	
	/* search merged sets if not in current set */

	if (topSetP->mergeN) {
		mtabP = (long FAR *)GetPtr(topSetP->mergeH);
		for(mii=0; mii<topSetP->mergeN; mii++) {
		
			/* search next merged define set */
			
			msetH = mtabP[mii];
			msetP = (struct defset FAR *)GetPtr(msetH);
			mgfound = chop_def_sym(msetP,s); 
			ReleasePtr(msetH); /* release define set */
			KillPtr(msetP);
			if (mgfound >= 0) /* found in merged set */
				break; /* exit for */
		} /* for */
		ReleasePtr(topSetP->mergeH);
		KillPtr(mtabP);
	} /* wkfound if */
	
	ReleasePtr(topSetH); /* release top level define set */
	KillPtr(topSetP);
	
	if (mgfound >= 0) {
		*retIndex = mgfound; /* index in set */
		*retSet = msetH; /* handle on merged set */
		return(TRUE); /* found in merged set */
	} /* mgfound if */
		
	*retIndex = wkfound; /* index where name should go */
	*retSet = topSetH; /* handle on set */
	return(FALSE); /* not found */

} /* find_def_sym */

/* ******************************************************************* */

int chop_def_sym(setP,str) /* binary chop search for defined symbol */
			/* returns +n = position of name if found */
			/*         -n = -(insert position+1) if not found */
struct defset FAR *setP; /* pointer to define set */
char *str; /* defined name to search for */

{	int low,mid,high; /* binary chop */
	int result; /* location of find */
	int compare; /* result of string compare */
	struct defvar FAR *dP; /* pointer to defined name table */

	if (!setP->defvarN || (setP->defvarH == HNULL))
		return(-1); /* no symbols to search */
		
	dP = (struct defvar FAR *)GetPtr(setP->defvarH); /* ptr to names */
	low = mid = 0;
	high = setP->defvarN-1;
	result = -1;

	/* binary chop search for defined name */

	while (low <= high) {
		mid = (low + high) / 2;
		compare = strcmpf((char FAR *)str,dP[mid].name);
		if (compare < 0)
			high = mid - 1;
		else if (compare > 0)
			low = mid + 1;
		else {
			result = mid;
			break;
		}
	} /* while */
	
	ReleasePtr(setP->defvarH); /* release defined names */
	if (result >= 0) return(result);
	if (compare < 0) return (-(mid + 1));
	else return (-(mid + 2));

} /* chop_def_sym */
	
/* ******************************************************************* */

set_wk_defset(setH) /* set define set being compiled or used */
Memh setH; /* hande on set to compile */

{
	/* check if setting to current set */
	
	if (setH && (wkSetH == setH))
		return(0);
	
	/* close currently compiling define set */
	
	if (wkSetP) {
		ReleasePtr(wkSetH);
		wkSetP = FARNULL;
	} /* wkSetP if */
	
	/* set new define set */
	
	wkSetH = setH; 
	if (wkSetH)		
		wkSetP = (struct defset FAR *)GetPtr(wkSetH);
	
} /* set_wk_defset */

/* ******************************************************************* */

/* ******************************************************************* */
