
/* A component of the cT (TM) programming environment. (c) Copyright 1989
 * Carnegie Mellon University. cT is a trademark of Carnegie Mellon
 * University. All rights reserved. May not be copied without the written
 * consent of Carnegie Mellon University. */


/* TUTORgraphics package for old Andrew wm and for X11 */

/* /usr/lib/X11/fonts points to /usr/andrew/X11fonts X11 documentation:
 * /afs/andrew/asa/src/mit/X.V11R3/doc bdf fonts:
 * /afs/andrew/asa/src/mit/X.V11R3/fonts/bdf/75dpi
 * 
 * ATK interact:  /afs/andrew/itc/src/andrew/atk/basics/x/xim.c
 * 
 * To convert an fwm file to X11 snf file: wmfdb file.fwm > file.fdb fdbbdf
 * file.fdb > file.bdf /usr/bin/X11/bdftosnf file.bdf > file.snf Run
 * /usr/bin/X11/mkfontdir to construct fonts.dir file.
 * 
 * /usr/bin/X11/xlsfonts lists fonts, xfd displays fonts, xset set path
 * 
 * 
 */

/* #define SELECTION_PASTE */


#include <X11/Xatom.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <X11/cursorfont.h>
#include <X11/keysym.h>

#include <stdio.h>
#include <signal.h>

#include "baseenv.h"

#ifdef GENERICSYS
#include "wmx11.h"
#endif

#ifndef WM
#include "wmx11.h"
#endif

#ifndef SYSV
#include <sys/types.h>
#include <sys/file.h>
#define sys_typesh
#endif

#ifdef SOLARIS
#include <sys/unistd.h>
#define hp_byte_order
#endif

#ifdef hp700
#include <sys/unistd.h>
#define hp_byte_order
#endif

#ifdef SYSV
#define sys_typesh
#include "wmx11.h"
#else
#include <sys/wait.h>
#include <sys/time.h>
#ifdef WM
#include "wmclient.h"
#endif
#endif

#include "ct_ctype.h"

/* sound generation */
#ifdef ibm032
#include <machineio/speakerio.h>
static int speakerfd = -1;	/* i/o # of speaker device */

#endif
#ifdef sunV3
#include <sys/file.h>
#include <sundev/kbd.h>
#include <sundev/kbio.h>
#endif

#include "kglobals.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "tfiledef.h"
#include "commands.h"
#include "txt.h"
#include "chardef.h"
#include "fkeys.h"
#include "editmenu.h"
#include "editor.h"

#ifdef ctproto
int  TUTORabs_fill_polygon(int  npoints,long  *fx,long  *fy);
int  main(int  argc,char  * *argv);
char FAR *CTzks(int code, char *tempS);
int TUTORswap_bits_char(unsigned char FAR *cp, long nn);
int  TUTORinit_palette(void);
int  TUTORsystem_tasks(void);
int TUTORunlock_code(void);
int  TUTORcvt_native_chars(unsigned char  FAR *cp,long  clen);
int  TUTORcvt_ct_chars(unsigned char  FAR *cp,long  clen);
int  TUTORcvt_toascii_chars(unsigned char  FAR *cp,long  clen);
int  TUTORpoll_events(int  block);
int EscapeSequence(char *seq);
int ControlKey(int key);
int  keybd_ready(void);
int  keybd_read(void);
int  TUTORforce_redraw(int  wix);
int  TUTORshould_interrupt(void);
int  TUTORnew_window(int  wid);
int TUTORsize_exec_window(int xx,int yy);
int  TUTORselect_window(int  wix);
int  TUTORresize_window(int  wid,int  newX,int  newY);
int  TUTORgrab_focus(int  wix);
int  TUTORframe_window(int  wid);
int  TUTORforward_window(int  wix);
int  TUTORclose_copyright(void);
int  TUTORdone_startup(void);
int  TUTORset_program_name(char  *pname);
int  TUTORset_window_title(int  wid,char  *wt);
int  TUTORhide_window(int  wInd);
int  TUTORshow_window(int  wix);
int  TUTORwindow_init(int  wix);
int  TUTORsync(void);
int  TUTORflush(void);
int  machineflush(void);
int  TUTORset_event_mask(int  eventc,int  value);
int  TUTORscroll_rect(struct  _trect *r,int  dh,int  dv);
int  TUTORset_rect(struct  _trect *r,int  left,int  top,int  right,int  bottom);
int  TUTORmove_rect(struct  _trect FAR *rr,int  xx,int  yy);
int  TUTORinset_rect(struct  _trect FAR *rr,int  xx,int  yy);
int  TUTORpoint_in_rect(struct  _tpoint pt,struct  _trect *r);
int  TUTORabs_move_to(int  x,int  y);
int  TUTORabs_move(int  x,int  y);
int  TUTORabs_draw_dot(int  ix1,int  iy1);
extern int  setoutcodes(union  coutcode *u,struct  cregion *r,int  x,int  y);
extern int  swap_ints(int  *pa,int  *pb);
int  TUTORabs_line_to(int  x,int  y);
int  pc_trapezoid(int  x1,int  y1,int  w1,int  x2,int  y2,int  w2,long  fh,int  c);
extern struct  pcfont816 FAR *pc_fix_font(long  fh);
extern int  pc_normalize_rect(int  *px1,int  *py1,int  *px2,int  *py2);
int  TUTORframe_abs_rect(struct  _trect FAR *tr);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
int  TUTORabs_erase_solid_rect(int  x1,int  y1,int  x2,int  y2,int  pFont,int  pChar);
int  TUTORabs_erase_rect(struct  _trect *tr,int  pattInd,int  pattC);
int  TUTORfill_abs_rect(struct  _trect FAR *tr,int  pattInd,int  pattC);
int  TUTORinvert_abs_rect(int  x1,int  y1,int  x2,int  y2);
int  TUTORset_abs_clip_rect(struct  _trect FAR *cr);
int  TUTORset_abs_clip_rectangle(int  x1,int  y1,int  x2,int  y2);
int  TUTORclear_screen(void);
int  TUTORabs_restore_region(long  id,int  x1,int  y1);
int TUTORfree_region(long id);
long  TUTORabs_save_region(int  x1,int  y1,int  x2,int  y2);
int  TUTORmove_abs_rect(int  x1,int  y1,int  x2,int  y2,int  newx,int  newy);
int  TUTORbeep(int  *ff,int  *dur,int  *volume,int  nbeep);
int  TUTORstop_sound(void);
int  TUTORset_comb_rule(int  rule);
int  TUTORseed_random(int  value);
int  TUTORinq_abs_screen_size(int  *x,int  *y,int  *dx,int  *dy);
int  TUTORinq_abs_pen_pos(int  *x,int  *y);
int  TUTORstart_menubar(unsigned int  barh);
int  TUTORis_symbolic(char  *ss);
long  TUTORparse_font_family(struct  _fref *fontTag,struct  _fref *familyName,int  isFont,int  oneTag,int  *fontSize);
int  TUTORset_textfont(int  jj);
int  TUTORset_textfont2(long  family,int  size,int  face);

int  TUTORfont_ptr(int  fInd,int  size,unsigned int  face,int cid);
long  TUTORinq_font_ptr(int  fontN);
long  MyFontID(struct  _fref *famName,int  isSys,int  *iso,int *ctK);
int  TUTORround_font_size(int  size);
int  TUTORfont_sizes(long  id,int  fontN);
int  TUTORmouse_off(void);
int  TUTORmouse_on(void);
int  TUTORset_cursor(int  cInd,int  cChar);
extern char  FAR *fontchrmap(struct  pcfont816 FAR *f,int  cc,int  *bytesx,int  *bytesy,int  *hotx,int  *hoty);
int  TUTORarrow_cursor(int  isTemp);
int  TUTORhilite(int  x1,int  y1,int  x2,int  y2);
int  TUTORdraw_text(unsigned char  FAR *buf,int  count);
int  TUTORtext_flush(void);
int  TUTORnormal_cursor(void);
int  TUTORwait_cursor(void);
int  TUTORresume_cursor(void);
int  TUTORobscure_cursor(void);
int  TUTORdraw_graphic_icons(int  iconFont,char  *s,int  len);
int  TUTORdraw_alpha_icons(int  iconFont,char  *s,int  len);
int  TUTORinq_font_info(int  *ascent,int  *descent,int  *maxwidth,int  *leading);
int  TUTORinq_abs_string_width(unsigned char  FAR *s,int  lth,int  *dx);
int  TUTORexit(void);
int  wmg_on(void);
int  wmg_off(void);
extern unsigned int  wmg_load_font(struct  _fref FAR *fontPath,int  index);
int  wmg_restore_font(unsigned int  fonth,char  FAR *area,long  size,int  index);
int  wmg_font(long  fonth);
unsigned int  wmg_inq_current_font(void);
int  wmg_layout(void);
int  wmg_fwd(int wwwx);
int  wmg_arrange(int  focus);
int  wmg_frame(int  wix);
int  wmg_outline(int  x1,int  y1,int  x2,int  y2,int  md);
int  wmg_focus(int  fwix);
int  wmg_hide(int  wix);
int  wmg_window_pt(int  x,int  y);
int  wmg_wipe(void);
int  wmg_color(int  fc,int  bc);
int  TUTORtrace(char  *s);
int  TUTORtrace_d(char  *s,double  nn);
int  TUTORtrace_n(char  *s,long  nn);
int  TUTORtrace_n_n(char  *s,long  nn,long  mm);
int  TUTORtrace_x(char  *s,long  nn);
int  TUTORtrace_dd(long  nn);
int  windmp(void);
int  TUTORdump(char  *s);
extern int  crash_checkpt(void);
extern   char *FullName(char *path,char FAR *basefile);
char  FAR *GetPtr(unsigned int  mm);
int  ReleasePtr(unsigned int  mm);
long  TUTORadd_ffamily(struct  _fref *famName,int  isSys,int  isSwitch);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  TUTORclose(int  findx);
int  TUTORcompose_char(unsigned char  *cCompose);
int  TUTORcompose_fkey(unsigned char  *cCompose);
struct keywdinf *GetComposeFKey(void);
int GetCompose(int code, char *tempS);
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
int  TUTORcopy_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  TUTORcvt_path(char  *ssx,struct  _fref FAR *fRef,struct  _fref FAR *baseRef,int isFile);
int  TUTORdealloc(char  FAR *ptr);
int  TUTORdump(char  *s);
int  TUTORfile_exists(struct  _fref FAR *fRef);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORget_font2(long  fam,int  size,unsigned int  face,int cid);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
long TUTORinq_ffamily_id(struct  _fref *famName,int known);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
long  TUTORinq_msec_clock(void);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  TUTORpoll_event_log(void);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
int  TUTORset_view(struct  tutorview FAR *vp);
int  TUTORset_window(int  wid);
int  TUTORsymbolic_fileref(struct  _fref FAR *fRef,char  FAR *syms);
int  TUTORtrace(char  *s);
int  TUTORtrace_n(char  *s,long  nn);
/* XFreeFontNames() */
/* XResizeWindow() */
extern int access(char *path,int mode);
extern int close(int fh);
int  execerr(char  *msgstr);
extern void exit(int status);
int  extend_font_table(int  nnew);
extern char *TUTORgetenv(char *varname);
/* ioctl() */
int  log_event(struct  tutorevent *ev);
/* open() */
int  pd_flush(void);
int  pd_init(void);
int  pd_menukey(struct  tutorevent *event);
int  pd_menumouse(struct  tutorevent *event);
int  pd_menuredraw(struct  tutorevent *event);
/* select() */
/* srandom() */
extern char *strcat(char *aa, char *bb);
extern int strcmp(char *aa, char *bb);
extern char *strcpy(char *aa, char *bb);
extern int strlen(char *str);
extern int strncmp(char *aa, char *bb, int nn);
int  system2(char  *shellcmd,int  waitflag);
/* usleep() */
/* wm_DrawString() */
/* wm_flsbuf() */
#ifdef IBMPROTO
int _CDECL _filbuf(FILE *);
int _CDECL fprintf(FILE *, const char *, ...);
size_t _CDECL fwrite(const void *, size_t, size_t, FILE *);
int _CDECL printf(const char *, ...);
int _CDECL sprintf(char *, const char *, ...);
int _CDECL sscanf(const char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

extern char *malloc();
extern char *realloc();
extern char *TUTORgetenv();
extern long getpid();
extern long wxcp();
extern long TUTORinq_font_ptr();
extern unsigned int wmg_load_font();
extern long TUTORinq_msec_clock();
extern char *machinename();
extern char *rindex_z();
char FAR *CTzks();
struct keywdinf *GetComposeFKey();
extern long  TUTORadd_ffamily();
extern long GetX11PixelValue();
XColor FAR *lookBestColor();
extern Colormap cTdefMap,X11defMap;
extern char FAR *TUTORalloc();

#ifdef SYSV
#ifdef CTEDIT
int pgen;
#endif
#endif

/* ******************************************************************* */

struct ctx11font  { /* x11/ct font info */
	int kind;   /* 0 = wm, 1 = x11, 2 = x11 16 bit font, 3 = ct internal format */
	long ptr;   /* index/descriptor/pointer to underlying font structure */
	long *mapcache;	/* non-zero = x11 bitmap id for character */
}; /* ctx11font */

static long wmFont = 0;		/* current font pointer */
/* current font characteristics */
static textFontFamily = -1, textFontSize = -1, textFontFace = -1;
	
static long polltime;		/* time of last poll_events */

/* wmFirst will be used if a font is not found due to server down */
static long wmFirst = 0;	/* first font actually found */
static int pastewindow;		/* window of paste event */

static int cont_scroll_w = -1; /* window for continuous scroll */
static struct tutorview FAR *cont_scroll_v; /* scroll bar view */
static int cont_scroll_t; /* scroll type */
static double cont_scroll_n; /* amount to scroll */

extern long colorsAvail; /* number colors available */
extern int pd_menualt[WINDOWLIMIT];	/* menus altered table */
extern int pd_barheight;	/* pull-down menu bar height */
extern int wmg_xo[WINDOWLIMIT];	/* window x origin */
extern int wmg_yo[WINDOWLIMIT];	/* window y origin */
extern int wmg_xs[WINDOWLIMIT];	/* window x size */
extern int wmg_ys[WINDOWLIMIT];	/* window y size */
extern int MillionsColor; /* TRUE if truecolor display */

FILE *wf[WINDOWLIMIT];		/* wm input files */
char *cTCmdLineP; /* pointer to cT command line */
int anyDown = 0;

/* ******************************************************************* */

/* X-specific status */

Display *display = NULL;
int Xfilenum;			/* X socket number */
int screen;
int X11_server_bug = FALSE;
Visual *visual; /* default visual */

static XWMHints xwmh = {
	(InputHint | StateHint),/* flags */
	True,			/* input */
	NormalState,		/* initial_state */
	0, 0,			/* icon pixmap, window */
	0, 0,			/* icon location */
	0,			/* icon mask */
	0			/* window group */
};				/* xwmh inits */

static Window noticeWindow;
static GC noticeGC;
static struct pcfont816 FAR *noticeP = FARNULL;
static int noticeW,noticeH; /* width, height of icon */
static char *noticeBits; /* pointer to bitmap */
static Pixmap noticePix;
static XGCValues noticeGCv;
static Cursor arrowcursor, waitcursor;
static Cursor newcursor = NULL;
int cursordx, cursordy;		/* adjust hot spot of X11 mouse cursor */
XGCValues gcv;
GC gc, gcpatt;
XColor whiteX, blackX;
Pixmap zpats[128];		/* stipple patterns for zpatterns */
Pixmap makepattern[WINDOWLIMIT];/* used to make stipple for pattern fill */
Drawable drawwindow;		/* the window to draw into */
int currentXwindow;		/* index into cT window list */

#define MAXNAMES 300		/* max number of font names to list */
extern char **XListFonts();
char **fontlist;
int nXfonts;
static int focusWindow;		/* window where key focus is (or -1) */
static char x11ColorInited = FALSE;
static char focussed;		/* TRUE if key focus is locked */

/*******************************************************/
/* conversion table for ct characters to map to wm. Because of the extreme
 * poverty of the wm character set, this table mostly maps letters with
 * diacritics to the bare letters.  Characters that don't map to anything wm
 * knows about are mapped to a question mark '?' */

static unsigned char ct2wm[] =
{				/* table to convert ct character codes to wm
				 * codes */
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x3f, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x20, 0x21, 0x3f, 0x4c, 0x3f, 0x59, 0x7c, 0x3f,	/* a7 */
	0x22, 0x43, 0x61, 0x3c, 0x7e, 0x2d, 0x52, 0x3f,	/* af */
	0x3f, 0x3f, 0x32, 0x33, 0x27, 0x75, 0x3f, 0x2e,	/* b7 */
	0x2c, 0x31, 0x6f, 0x3e, 0x3f, 0x3f, 0x3f, 0x3f,	/* bf */
	0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x41, 0x43,	/* c7 */
	0x45, 0x45, 0x45, 0x45, 0x49, 0x49, 0x49, 0x49,	/* cf */
	0x44, 0x4e, 0x4f, 0x4f, 0x4f, 0x4f, 0x4f, 0x78,	/* d7 */
	0x4f, 0x55, 0x55, 0x55, 0x55, 0x59, 0x50, 0x53,	/* df */
	0x61, 0x61, 0x61, 0x61, 0x61, 0x61, 0x61, 0x63,	/* e7 */
	0x65, 0x65, 0x65, 0x65, 0x69, 0x69, 0x69, 0x69,	/* ef */
	0x64, 0x6e, 0x6f, 0x6f, 0x6f, 0x6f, 0x6f, 0x2f,	/* f7 */
	0x6f, 0x75, 0x75, 0x75, 0x75, 0x79, 0x70, 0x79	/* ff */
};

/* ******************************************************************* */

int ConnectX11()

{
	if ((display = XOpenDisplay(NULL)) == NULL) {
		isx11 = FALSE;
	} else
		isx11 = TRUE;
	return(0);

} /* ConnectX11 */

/* ******************************************************************* */

FlagRedraw(op, w)
int op;
long w;

{	int i;

	/* find the window that needs to be redrawn */

	for (i = 0; i < WINDOWLIMIT; i++) {
		if (windowsP[i].wp == w)
			windowsP[i].winRedraw = TRUE;
	} /* for */

} /* FlagRedraw */

/* ******************************************************************* */

TUTORstartup(argc, argv, filenameR)
int argc;
char **argv;
FileRef FAR *filenameR;

{	char **a, *cp;
	int i, j;		/* work variables */
	char fpath[CTPATHLEN]; /* path to source file */

	/* global refs */
	extern int lforkf;	/* layout fork flag (-d option) */
	extern int twf;		/* dma debug option */
	extern int spyf;	/* profiling flag */
	extern int codegen;	/* compiled code flag */
	extern struct sourcefile *sourcetable;	/* source file names/pointers */

	/* initialization of variables altered by command line options */
	
#ifdef EXECUTE
printf("cT is a registered trademark of Carnegie Mellon University\n");
printf("cT Executor (c) copyright 1989-1995 Carnegie Mellon University\n");
#endif
	ConnectX11();
	
	cTCmdLineP = argv[0];
	nosourcelayout = 0;
	lforkf = TRUE;
	twf = FALSE;		/* turn off trace window debug stuff */
	spyf = FALSE;		/* turn off profiling */
	codegen = TRUE;		/* default is compiled codes */
	logevents = playevents = FALSE;	/* no event log/replay */
#ifdef DOPSCRIPT
	PostscriptFlag = FALSE;	/* don't make postscript output */
#endif
	fileSpecified = 0; /* don't know file name yet */
	pd_init();

	/* argc == 1 only for "% ct" with no file name */
	/* #! ct gives argc == 2 with both args being the file name */

#ifdef CTEDIT
	strcpy(filenameR->path, FullName("untitled.c", (char FAR *) ""));
#else
	strcpy(filenameR->path, FullName("untitled.t", (char FAR *) ""));
#endif
	if (argc == 2 && strcmp(*argv, *(argv + 1)) == 0)
	{
		fileSpecified = 1; /* file name given */
		strcpy(filenameR->path, FullName(argv[0], (char FAR *) ""));
		nosourcelayout++;
	} else if (argc != 1)
		for (a = argv + 1, i = argc; --i; a++)
		{
			j = **a;
			if ((j != '-') && (j != '+')) {
				strcpy(filenameR->path, FullName(*a, (char FAR *) ""));
				fileSpecified = 1;
			} else
			{
				char *c;

				c = *a;
				c++;
				switch (*c)
				{
				case 'x':
					if (j != '-')
						TUTORtrace("bad + switch");
					nosourcelayout++;
					break;
				case 'd':
					if (j != '-')
						TUTORtrace("bad + switch");
					lforkf = FALSE;
					break;
				case 'c':
					codegen = (j == '+');
					break;
				case 'a':
					twf = TRUE;	/* turn on debug stuff */
					break;
				case 's':
					spyf = TRUE;	/* turn on profiling */
					break;
				case 'p':
#ifdef DOPSCRIPT
					PostscriptFlag = TRUE;	/* turn on PS output */
					PSbuff = TUTORalloc((long) 100, TRUE, "psbuff");
					/* can't put header code here because
					 * no ScreenW yet */
#endif
					break;
				case 'l':
					logevents = TRUE;
					break;
				case 'r':
					playevents = TRUE;
					break;
				case 'z':
					/* dmaf = TRUE; /* turn on debugging */
					break;
				default:
					printf("bad switch %c\n", *c);
					break;
				}	/* switch */
			}	/* - option else */
		}		/* for */

	/* finish off fileNameR */

	cp = filenameR->path + strlen(filenameR->path) - 1;
	while (*cp != '/')
		cp--;
	filenameR->nameInd = (cp - filenameR->path) + 1;

	SetupCTDir();		/* set up ctDir */

	if (isx11) {
		for(i=0; i<128; i++) zpats[i] = NULL;
		Xfilenum = ConnectionNumber(display);	/* X socket number */
		screen = DefaultScreen(display);
		currentXwindow = -1;	/* not set yet */

		/* FindXFonts(); */

		/* Add zpatterns etc. to X11 font path */

		strcpyf((char FAR *)fpath,filenameR->path);
		fpath[filenameR->nameInd] = '\0'; /* remove file name */

		AddToFontPath(fpath);

	/*	AddToFontPath(getenv("C T F O N T S")); */

		if ((arrowcursor = XCreateFontCursor(display,XC_left_ptr))
		    == NULL) {
			fprintf(stderr, "Couldn't create arrow cursor.\n");
			exit(-1);
		}
		if ((waitcursor = XCreateFontCursor(display, XC_watch))
		    == NULL) {
			fprintf(stderr, "Couldn't create clock cursor.\n");
			exit(-1);
		}

		X11defMap = DefaultColormap(display, screen);
		blackX.pixel = BlackPixel(display, screen);
		whiteX.pixel = WhitePixel(display, screen);
		XQueryColor(display, X11defMap, &blackX);
		XQueryColor(display, X11defMap, &whiteX);
#ifdef mips
		if (DisplayCells(display,screen) > 2)
			X11_server_bug = TRUE;
#endif
		InitialNotice();
	} else { /* wm */
#ifdef WM
		blackX.pixel = f_black;
		whiteX.pixel = f_white;
#endif
	}

	fgndColor.palette = color_black;
	bgndColor.palette = color_white;
	winColor.palette = bgndColor.palette;

} /* TUTORstartup */

/* ******************************************************** */

static int InitialNotice()

{   char *envP; /* pointer to font path env variable */
	char logoN[CTPATHLEN]; /* name of logo file */
	FILE *logoF; /* icons file handle */
	struct stat statB; 
	int fileRet; /* return from status operation */
	long fileSize; /* size of logo icons file */
	struct pccharl *defP; /* pointer to character definition */
	XSetWindowAttributes attributes;
	XEvent event;
	int iconN; /* icon number to plot */

#ifdef EXECUTE
	return(0);
#endif

	/* read icons file containing cT logo(s) */
				
	envP = TUTORgetenv("CT_FONTS");	
	if (envP) strcpy(logoN,envP);
	else logoN[0] = 0;
	strcat(logoN,"logo.");
	strcat(logoN,machinename());
	strcat(logoN,".fct");
	logoF = fopen(logoN,"r");
	if (!logoF) {
		return(0); /* can't find logo(s) */
	}
	fileRet = stat(logoN,&statB);
	if (fileRet) {
		fclose(logoF);
		return(0);
	}
	fileSize = statB.st_size;
	noticeP = (struct pcfont816 *)malloc(fileSize);
	if (!noticeP) {
		fclose(logoF);
		return(0);
	}
	fileRet = fread(noticeP,1,fileSize,logoF);
	fclose(logoF); /* close file after read */
	if (fileRet != fileSize) {
		free(noticeP); /* release memory */
		noticeP = FARNULL;
		return(0);
	}
	
	/* get icon size and location of bitmap */
	
	defP = (struct pccharl *)(((char FAR *)(noticeP))+noticeP->ddef);
	iconN = 1; /* assume icon #1 */
	envP = TUTORgetenv("CT_TITLE");
	if (envP) {
		iconN = *envP-'0';
		if ((iconN < 0) || (iconN > 9)) iconN = 1;
	}
	defP += iconN;/* use specified character */
	noticeW = defP->bnw;
	noticeH = defP->bnh;
	noticeBits = ((char FAR *)(noticeP))+noticeP->dmap+defP->map;
	
    attributes.background_pixel = WhitePixel(display, DefaultScreen(display));
    attributes.border_pixel = BlackPixel(display, DefaultScreen(display));
    attributes.event_mask = ButtonPressMask | ButtonReleaseMask | ExposureMask;
    attributes.cursor = waitcursor;

    if ((noticeWindow = XCreateWindow(display, 
         RootWindow(display, DefaultScreen(display)), 
         50, 50,noticeW+4, noticeH+4, 2, CopyFromParent, CopyFromParent, CopyFromParent, 
         CWBackPixel | CWBorderPixel | CWEventMask | CWCursor, 
         &attributes)) == NULL) 
		return(0); /* couldn't open window */
    noticeGCv.foreground = BlackPixel(display, DefaultScreen(display));
    noticeGCv.background = WhitePixel(display, DefaultScreen(display));
    noticeGCv.font = XLoadFont(display, "variable");
	noticeGCv.function = GXcopy;

    noticeGC = XCreateGC(display, noticeWindow, 
			GCFunction | GCForeground | GCBackground | GCFont,
            &noticeGCv);

	XStoreName(display,noticeWindow,"About cT");
	XMapRaised(display, noticeWindow);
	
#ifdef hp_byte_order
	{	int mii,bii,bjj;
		int nbyte,byte;
		int cbytew;
		char *topt; /* to pointer for bitmap copy */
		
		cbytew = (noticeW >> 3);
		if (noticeW != (cbytew << 3))
			cbytew++; /* handle last (fractional) byte */	
		for(mii=0; mii<noticeH; mii++) {	
			topt = noticeBits+(mii*cbytew);
			for(bii=0; bii<cbytew; bii++) {
				byte = *(topt+bii);
				nbyte = 0;
				for(bjj=0; bjj<8; bjj++) {
					nbyte |= ((byte & (0x80 >> bjj)) >> (7-bjj)) << bjj;
				}
				*(topt+bii) = nbyte;
			} /* bii for */
		} /* mii for */
	} /* hp range */
#endif

	noticePix = XCreateBitmapFromData(display,noticeWindow,noticeBits,
	                       noticeW,noticeH);
	InitialIcon();	
	
	/* local event loop till icon displayed */
	
	do {
		XNextEvent(display, &event);
		if ((event.xany.window == noticeWindow) &&
			(event.type == Expose)) {
			InitialIcon();
			break; /* exit while */
		}
	} while (TRUE);
	
	return(0);
	
} /* InitialNotice */

/* ******************************************************** */

static int InitialNoticeProc(wid,event)
Window wid; /* X11 window id */
XEvent *event;  /* X11 event to process */

{	
	if (noticeWindow && (wid == noticeWindow)) {
		if ((event->type == Expose))
			InitialIcon();																																												
	}
	return(0);

} /* InitialNoticeProc */

/* ******************************************************** */

static int InitialIcon() /* display initial icon */

{
	XClearArea(display,noticeWindow,0,0,noticeW+4,noticeH+4,False);
	XCopyPlane(display,noticePix,noticeWindow,noticeGC,0,0,
			       noticeW,noticeW,2,2,1L);	
	XSync(display, False);
	return(0);
			
} /* InitialIcon */

/* ******************************************************** */

AddToFontPath(newdir)		/* add directory to X11 font path */
char *newdir;

{	char **oldfontdirs;
	char **newfontdirs;
	char **pp, **qq;
	int nn, npaths, neednew;
	char fontdir[FILEL]; /* fonts.dir full path */
	FILE *ffp; /* fonts.dir file handle */

	if (newdir == NULL)
		return;		/* nothing to add */

	oldfontdirs = XGetFontPath(display, &npaths);
	newfontdirs = (char **) TUTORalloc((long) (npaths + 1) * sizeof(char *), TRUE, "fontdir");
	pp = oldfontdirs;
	qq = newfontdirs;
	neednew = TRUE;
	for (nn = 0; nn < npaths; nn++) {
		if (!strcmp(*pp, newdir))
			neednew = FALSE;
		*(qq++) = *(pp++);
	} /* for */
	*qq = newdir;
	if (neednew) {
		strcpy(fontdir,newdir); /* get path */
		strcat(fontdir,"fonts.dir"); /* append file name */
		ffp = fopen(fontdir,"r"); /* attempt to open fonts.dir file */
		if (ffp) {
			fclose(ffp);
			XSetFontPath(display, newfontdirs, npaths + 1);
		}
	}

	TUTORdealloc(newfontdirs);
	XFreeFontPath(oldfontdirs);

} /* AddToFontPath */

#ifdef LISTXFONTS

/* ******************************************************** */

FindXFonts()
{
	int ii, size;
	char family[30];

	fontlist = XListFonts(display, "*", MAXNAMES, &nXfonts);
	for (ii = 0; ii < nXfonts; ii++)
	{
		/* printf(":%s:\n", *(fontlist+ii)); */
		/* Many but not all the new X11 fonts start with '-': cf.
		 * dec-adobe- */
		if (**(fontlist + ii) != '-')
			continue;
		getXfontinfo(*(fontlist + ii), family, &size);
		/* printf("[%s].%d\n", family, size); */
	}
}

/* ************************************************************* */

getXfontinfo(fontname, family, size)
char *fontname;			/* full X font name */
char *family;			/* family name contained in fontname */
int *size;			/* pixel size contained in fontname */
{
	char sizestr[5], *p;
	int loc;

	loc = 0;
	getXfield(fontname, &loc, 2, family);
	getXfield(fontname, &loc, 5, sizestr);
	*size = 0;
	p = sizestr;
	while (*p != '\0')
		*size = 10 * (*size) + (*(p++) - '0');
}

/* ************************************************************* */

getXfield(fontname, loc, nthfield, field)
char *fontname;			/* full X font name */
int *loc;			/* location within fontname */
int nthfield;			/* nth field to locate starting from loc */
char *field;			/* alphanumeric field contained in fontname */
{
	int ii;

	/* skip initial -'s */
	while (*(fontname + (*loc)) == '-')
		(*loc)++;
	/* skip over nthfield-1 fields */
	for (ii = 1; ii < nthfield; ii++)
		while (*(fontname + ((*loc)++)) != '-');
	while (*(fontname + (*loc)) != '-')
		*(field++) = *(fontname + ((*loc)++));
	*field = '\0';
}

#endif				/* LISTXFONTS */

/* ************************************************************* */

#ifdef KSWdebug
static 
ReportFocus(report)
XEvent *report;
{
	char reportS[100];
	char *mode, *detail;

	switch (report->xfocus.mode)
	{
	case NotifyNormal:
		mode = "NotifyNormal";
		break;
	case NotifyGrab:
		mode = "NotifyGrab";
		break;
	case NotifyUngrab:
		mode = "NotifyUngrab";
		break;
	default:
		mode = "??";
		break;
	}
	switch (report->xfocus.detail)
	{
	case NotifyAncestor:
		detail = "NotifyAncestor";
		break;
	case NotifyVirtual:
		detail = "NotifyVirtual";
		break;
	case NotifyInferior:
		detail = "NotifyInferior";
		break;
	case NotifyNonlinear:
		detail = "NotifyNonlinear";
		break;
	case NotifyNonlinearVirtual:
		detail = "NotifyNonlinearVirtual";
		break;
	case NotifyPointer:
		detail = "NotifyPointer";
		break;
	case NotifyPointerRoot:
		detail = "NotifyPointerRoot";
		break;
	case NotifyDetailNone:
		detail = "NotifyDetailNone";
		break;
	default:
		detail = "???";
		break;
	}
	sprintf(reportS, "    mode is %s detail is %s", mode, detail);
	TUTORtrace(reportS);
}

static 
ReportEnter(report)
XEvent *report;
{
	char reportS[100];
	char *mode, *detail;

	switch (report->xcrossing.mode)
	{
	case NotifyNormal:
		mode = "NotifyNormal";
		break;
	case NotifyGrab:
		mode = "NotifyGrab";
		break;
	case NotifyUngrab:
		mode = "NotifyUngrab";
		break;
	default:
		mode = "??";
		break;
	}
	switch (report->xcrossing.detail)
	{
	case NotifyAncestor:
		detail = "NotifyAncestor";
		break;
	case NotifyVirtual:
		detail = "NotifyVirtual";
		break;
	case NotifyInferior:
		detail = "NotifyInferior";
		break;
	case NotifyNonlinear:
		detail = "NotifyNonlinear";
		break;
	case NotifyNonlinearVirtual:
		detail = "NotifyNonlinearVirtual";
		break;
	case NotifyPointer:
		detail = "NotifyPointer";
		break;
	case NotifyPointerRoot:
		detail = "NotifyPointerRoot";
		break;
	case NotifyDetailNone:
		detail = "NotifyDetailNone";
		break;
	default:
		detail = "???";
		break;
	}
	sprintf(reportS, "    mode is %s detail is %s, focus is %d", mode, detail, report->xcrossing.focus);
	TUTORtrace(reportS);
}

#endif

/* buffer size for event to ascii conversion: */
#define BUFSIZE 21

int TUTORpoll_events(block) /* queue up any pending events */
/* c returns TRUE if found an event */
int block; /* TRUE if want to block on events */

{	KeySym keysymbol;	/* current keysymbol */
	char buffer[BUFSIZE+1];	/* for decoding keypresses */
	int charcount;		/* actual number of chars in this key event */
	Window wp;		/* window structure */
	XWindowAttributes wattributes;	/* window attributes */
	XEvent report;		/* X11 event report */
	int reportvalid;	/* TRUE if event in report */
	long readmask;		/* for select() */
	struct tutorview FAR *sview;	/* view selected on entry */
	int cutl;		/* length of cut buffer item */
	struct tutorevent ev;	/* current event */
	int lastwindow;		/* window of last event */
	int lastevent;		/* type of last event */
	int i, j;
	struct tutorevent FAR *timeQ;	/* pointer to time queue */
	int newevents = FALSE;	/* TRUE if added a new event to queue */

#ifndef SYSV
	struct timeval selt;	/* wait time for select() */
	union wait status;	/* status for wait3 */

#endif
	static char composeInd = 0;	/* index+1 of compose char sequence
					 * (0 if not composing) */
	static char composeChar[4];

	if ((nevents >= (EVENTLIMIT-8)) || 
            (nevents && eventque[0].type == -1)) {
		TUTORcompress_events();
		if (nevents >= (EVENTLIMIT-2))
			return (FALSE);	/* exit if queue full */
	}

	sview = CurrentView;	/* save current view */

	if (!isx11) {
		lastevent = WMpoll_events(block);
		if (sview != CurrentView)
			TUTORset_view(sview);
		return (lastevent);
	} /* wm */
	polltime = TUTORinq_msec_clock(); /* time of last TUTORpoll() */
	ev.type = -1; /* pre-set no event */
	ev.id = 0;
	ev.eDataP = FARNULL;
	
	TUTORpoll_event_log();	/* process re-play events */

	lastevent = lastwindow = -1;

	/* check for timing events */
	timeQ = (struct tutorevent FAR *) GetPtr(timeque);
	j = 0;
	while (j < ntiming && (timeQ->timestamp <= polltime)) {
		j++;
		if (modalW != -1 && (!timeQ->view || !timeQ->view->dialogV)) {
			timeQ++;
			continue;	/* dialog is forward, this is
					 * non-dialog time event, just ignore
					 * it for now */
		}
		if (timeQ->type >= 0) {
			eventque[nevents].pressed = FALSE;
			eventque[nevents++] = *timeQ;
			newevents = TRUE;
		}
		ntiming--;
		j--;		/* to make up for deletion of event */
		for (i = 0; i < ntiming; i++, timeQ++)
			*timeQ = *(timeQ + 1);
	} /* while */
	ReleasePtr(timeque);
	KillPtr(timeQ);

	/* check for expose/mouse/keyboard/paste events */

#ifdef WM
	selt.tv_sec = 0;	/* set up short time interval */
	if (block) {
		selt.tv_usec = 1000;	/* timeout after blocking */
		wait3(&status, WNOHANG, 0);	/* non-blocking wait for
						 * child zombies */
	} else
		selt.tv_usec = 0;
#endif

	/* allow up event thu quickly if continuous scroll */

	if ((cont_scroll_w >= 0) && (nevents == 0))
		if (isx11)
			XSync(display, False);

	if (nevents)
		block = FALSE;	/* don't block if something to do */
	while (TRUE)
	{
		reportvalid = FALSE; /* no event yet */
		if (nevents >= EVENTLIMIT)
			return (newevents);	/* exit if q full */
		if (XPending(display) || block)
		{
			if (!QLength(display))
			{	/* block -- wait for input */
				while (TRUE)
				{
					readmask = (1 << Xfilenum);
#ifdef WM			/* andrew wm+x11 version */
					select(32, &readmask, 0, 0, &selt);	/* wait */
#else
#ifdef SYSV
					if (!nevents && display)
						XSync(display, False);
#else				/* SYSV */
					selt.tv_sec = 0;	/* set up short time
								 * interval */
					selt.tv_usec = 1000;	/* timeout after
								 * blocking */
					select(32, &readmask, 0, 0, &selt);	/* wait */
#endif				/* SYSV */
#endif				/* WM else */
					if (XPending(display))
						break;
					if (ntiming)
						break;
				}
			}
			if (XPending(display)) {
				reportvalid = TRUE;
				XNextEvent(display, &report);
			}
		} 


		if (!reportvalid) break; /* exit while */

		report.type &= 0177;	/* Mask out high order bit, which
					 * distinguishes between server
					 * generated events and client
					 * generated (simulated) events --
					 * they should look the same to us */
		wp = report.xany.window;
		for (i = 0; i < WINDOWLIMIT; i++) {
			if (windowsP[i].wp == (long) wp)
				break;
		}		/* for */
		if (i >= WINDOWLIMIT) { /* not a normal cT window */
			InitialNoticeProc(wp,&report);
			return(0); 
		}
		ev.window = i;	/* set window of event */
		ev.type = -1;	/* view, type not known yet */
		ev.view = FARNULL;
		ev.eDataP = FARNULL;
		ev.timestamp = polltime;
		ev.pressed = FALSE; /* not a pressed event */
	
		switch (report.type) {

			/* process window exposure */

		case Expose:
			if (nevents >= EVENTLIMIT)
				return (newevents);	/* exit if queue full */
			/* ignore all but final expose */
			if (report.xexpose.count > 0)
			{
				ev.type = -1;
				break;
			}
			windowsP[ev.window].winRedraw = FALSE;	/* clear redraw */
			ev.id = 0;
			ev.type = EVENT_REDRAW;
			pd_menualt[ev.window] = TRUE;
			flushMenu = TRUE;
			XGetWindowAttributes(display, wp, &wattributes);
			ev.x = wattributes.width;
			ev.y = wattributes.height - pd_barheight;
			wmg_xs[ev.window] = ev.x;
			wmg_ys[ev.window] = ev.y;
			pd_menuredraw(&ev);
			break;

			/* key focus events */

		case EnterNotify:
		case FocusIn:
			if (report.type == FocusIn)
			{
				if (report.xfocus.detail == NotifyPointer)
					break;
			} else if (report.xcrossing.detail == NotifyPointer)
				break;

#ifdef KSWdebug
			if (report.type == EnterNotify)
			{
				TUTORtrace_n_n("EnterNotify", focussed, focusWindow);
				ReportEnter(&report);
			} else
			{
				TUTORtrace_n_n("FocusIn", focussed, focusWindow);
				ReportFocus(&report);
			}
#endif
			if (report.type == FocusIn)
				focussed = TRUE;
			if (focusWindow != ev.window && (!focussed || report.type == FocusIn))
			{	/* we have received focus */
#ifdef KSWdebug
				TUTORtrace_n_n("Activate", focussed, ev.window);
#endif
				focusWindow = ev.window;
				if (nevents >= EVENTLIMIT)
					return (newevents);	/* event queue full */
				ev.type = EVENT_FWD;
				ev.value = TRUE;
			}
			break;
		case LeaveNotify:
			if (report.xcrossing.detail == NotifyPointer)
				break;
#ifdef KSWdebug
			TUTORtrace_n_n("LeaveNotify", focussed, focusWindow);
			ReportEnter(&report);
#endif
			if (!focussed)
				focusWindow = -1;	/* we could also
							 * generate a FALSE
							 * EVENT_FWD */
			break;
		case FocusOut:
			if (report.xfocus.detail == NotifyPointer)
				break;
#ifdef KSWdebug
			TUTORtrace_n_n("FocusOut", focussed, focusWindow);
			ReportFocus(&report);
#endif
			focussed = FALSE;
			focusWindow = -1;	/* we could also generate a
						 * FALSE EVENT_FWD here */
			break;

			/* process mouse event */

		case ButtonPress:
			ev.x = report.xbutton.x;
			ev.y = report.xbutton.y - pd_barheight;
			ev.leftdown = ev.rightdown = FALSE;
			switch (report.xbutton.button)
			{

			case Button1:
				ev.type = EVENT_LEFTDOWN;
				ev.leftdown = TRUE;
				windowsP[ev.window].ldowntime2 = windowsP[ev.window].ldowntime1;
				windowsP[ev.window].ldowntime1 = ev.timestamp;
				break;

			case Button2:
			case Button3:
				ev.type = EVENT_RIGHTDOWN;
				ev.rightdown = TRUE;
				windowsP[ev.window].rdowntime2 = windowsP[ev.window].rdowntime1;
				windowsP[ev.window].rdowntime1 = ev.timestamp;
				break;
			}
			if (pd_menumouse(&ev))
			{	/* menu event */
				pastewindow = ev.window;
				ev.type = -1;	/* kill event */
			}
			break;

		case ButtonRelease:
			ev.x = report.xbutton.x;
			ev.y = report.xbutton.y - pd_barheight;
			ev.leftdown = ev.rightdown = FALSE;
			switch (report.xbutton.button)
			{

			case Button1:
				ev.type = EVENT_LEFTUP;
				windowsP[ev.window].luptime = ev.timestamp;
				break;

			case Button2:
			case Button3:
				ev.type = EVENT_RIGHTUP;
				windowsP[ev.window].ruptime = ev.timestamp;
				break;
			}
			if (pd_menumouse(&ev))
			{	/* menu event */
				pastewindow = ev.window;
				ev.type = -1;	/* kill event */
			}
			break;

		case MotionNotify:
			ev.x = report.xmotion.x;
			ev.y = report.xmotion.y - pd_barheight;
			ev.leftdown = ev.rightdown = FALSE;
			switch (report.xmotion.state)
			{

			case Button1Mask:
				ev.type = EVENT_DOWNMOVE;
				ev.leftdown = TRUE;
				break;

			case Button2Mask:
			case Button3Mask:
				ev.type = EVENT_DOWNMOVE;
				ev.rightdown = TRUE;
				break;
			}	/* state switch */
			if (pd_menumouse(&ev))
			{	/* menu event */
				pastewindow = ev.window;
				ev.type = -1;	/* kill event */
			}
			break;

			/* handle keyboard remapping */

		case MappingNotify:
			XRefreshKeyboardMapping((XMappingEvent *)&report);
			break;

			/* process keyboard event */

		case KeyPress:
			/* special check - reroute keys from */
			/* command window to edit window */
			if (ev.window == DictWn)
				ev.window = EditWn[0];
			
			charcount =
				XLookupString((XKeyReleasedEvent *)&report, buffer, BUFSIZE,
					      &keysymbol, NULL);
			j = (report.xkey.state & ShiftMask) ? 1 : 0; /* extend flag */
			switch (keysymbol) {
			case XK_Shift_L:
			case XK_Shift_R:
			case XK_Control_L:
			case XK_Control_R:
			case XK_Caps_Lock:
			case XK_Shift_Lock:
			case XK_Meta_L:
			case XK_Meta_R:
			case XK_Alt_L:
			case XK_Alt_R:
				break; /* keys to ignore */
			case XK_Left:
				ev.type = EVENT_FKEY;
				ev.value = KLEFT + j;
				break;
			case XK_Up:
				ev.type = EVENT_FKEY;
				ev.value = KUP + j;
				break;
			case XK_Right:
				ev.type = EVENT_FKEY;
				ev.value = KRIGHT + j;
				break;
			case XK_Down:
				ev.type = EVENT_FKEY;
				ev.value = KDOWN + j;
				break;
#ifdef sunV3
			/* for sun, shifted arrow keys come in as R8-R14 function keys */
			case	XK_R8:
				ev.value = KUP+1;
				if (j) /* make sure we are really shifted */
					ev.type = EVENT_FKEY;
				break;
			case	XK_R10:
				ev.value = KLEFT+1;
				if (j) /* make sure we are really shifted */
					ev.type = EVENT_FKEY;
				break;
			case	XK_R12:
				ev.value = KRIGHT+1;
				if (j) /* make sure we are really shifted */
					ev.type = EVENT_FKEY;
				break;
			case	XK_R14:
				ev.value = KDOWN+1;
				if (j) /* make sure we are really shifted */
					ev.type = EVENT_FKEY;
				break;
#endif sunV3

			case XK_Next:
				ev.type = EVENT_FKEY;
				ev.value = KPAGEDOWN + j;
				break;
			case XK_Prior:
				ev.type = EVENT_FKEY;
				ev.value = KPAGEUP + j;
				break;
			case XK_Help:
				ev.type = EVENT_FKEY;
				ev.value = KHELP + j;
				break;
			case XK_Undo:
			case XK_Redo:
				ev.type = EVENT_FKEY;
				ev.value = KUNDO + j;
				break;
			case XK_Home:
			case XK_Begin:
				ev.type = EVENT_FKEY;
				ev.value = KBEGLINE + j;
				break;
			case XK_End:
				ev.type = EVENT_FKEY;
				ev.value = KENDLINE + j;
				break;
			case XK_Insert:
				ev.type = EVENT_FKEY;
				ev.value = KPASTE;
				break;
			case XK_Escape:
				if (j)
					{ /* shift escape is the escape key because
							escape is used to start special key sequence */
					ev.type = EVENT_FKEY;
					ev.value = KESCAPE;
					}
				else
					{ /* start of special key sequence */
					composeInd = -1;
					}
				break;
			case XK_F1:
				ev.type = EVENT_FKEY;
				ev.value = KFA;
				break;
			case XK_F2:
				ev.type = EVENT_FKEY;
				ev.value = KFB;
				break;
			case XK_F3:
				ev.type = EVENT_FKEY;
				ev.value = KFC;
				break;
			case XK_F4:
				ev.type = EVENT_FKEY;
				ev.value = KFD;
				break;
			case XK_Multi_key:
				composeInd = 1; /* start character composition */
				break;
			case XK_Tab:
				if (j)
					{ /* shifted tab is back tab */
					ev.type = EVENT_FKEY;
					ev.value = KBACKTAB;
					break;
					}
				/* otherwise we just fall thru and process as normal key */
			case XK_BackSpace:
			case XK_Return:
			default: /* normal key */
				if (charcount == 0) {
					break; /* key didn't get ascii translation */
				}
				ev.keys[0] = buffer[0];
				if (ev.keys[0] == 127 || ev.keys[0] == 4)
					ev.keys[0] = 8;	/* del */
				else if (ev.keys[0] == RETURN)
					ev.keys[0] = NEWLINE;
				else if (ev.keys[0] == 26)
				{	/* control-z start character compose */
					composeInd = 1;
					break;
				}
				if (composeInd > 0)
				{	/* we are composing a character */
					composeChar[composeInd - 1] = ev.keys[0];
					composeInd++;
					if (composeInd >= 3 && composeChar[0] != ';')
					{
						ev.keys[0] = TUTORcompose_char(composeChar);
						composeInd = 0;
					} else if (composeInd >= 5)
					{ /* composition of function key */
						composeInd = 0; /* we are done composing */
						ev.value = TUTORcompose_fkey(composeChar);
						if (ev.value > 0)
						{ /* really have function key */
							ev.type = EVENT_FKEY;
							break;
						}
						else
							break; /* didn't actually have function key */
					} else
						break; /* compose sequence not done yet */
				} else if (composeInd < 0)
				{ /* we are composing a special key sequence */
					composeChar[0] = ev.keys[0];
					composeChar[1] = '\0';
					ev.value = EscapeSequence(composeChar);
					if (ev.value)
					{
						ev.type = EVENT_FKEY;
					}
					composeInd = 0; /* no longer composing a sequence */
					break;
				} else if (ev.keys[0] < 32 && ev.keys[0] != '\t' && 
						ev.keys[0] != '\b' && ev.keys[0] != NEWLINE)
				{ /* possible control key macro */
					ev.value = ControlKey(ev.keys[0]);
					if (ev.value)
					{ /* a function key */
						ev.type = EVENT_FKEY;
						break;
					}
				}
				ev.type = EVENT_KEY;
				break; /* end of normal key (default case) */
			}  /* end of keysymbol switch */
			
			if (ev.type == -1)
				break; /* no key we want */
			
			ev.nkeys = 1;
 
			break;

#ifdef SELECTION_PASTE
		case SelectionRequest:  /* received request for our selection */
			HandleSelectionRequest(&report);
			break;
			
		case SelectionNotify: /* received the result of our paste request */
			if (report->xselection.property == None)
			{ /* selection doesn't exist or was refused */
				/* get bytes from cut buffer */
				ev.dp = XFetchBytes(display,&ev.value);
				if (ev.value <= 0)
					break; /* nothing in cut buffer */
				ev.a1 = 0; /* be2 datastream */
				ev.type = EVENT_PASTE;
				ev.window = pastewindow;
				break;
			} else
			{
				Atom actual_type;
				int actual_format, retval;
				unsigned long nitems, bytes_after;
				unsigned char *prop, *pasteB;
				

				/* get the property */	
				retval = XGetWindowProperty(display,report.xselection.requestor,report.xselection.property,
					0L,10000L,True,AnyPropertyType,&actual_type,&actual_format,&nitems,
					&bytes_after,&prop);
				
				if (retval !=  Success || nitems <= 0 || actual_format != 8)
					break; /* some problem */
				ev.dp = prop;
				ev.value = nitems;
				ev.a1 = 1; /* string */
				ev.type = EVENT_PASTE;
				ev.window = pastewindow;
			}
			break;
		
		case SelectionClear:  /* we no longer own selection */
			HandleSelectionClear(&report);
			break;
#endif
		
		default:
			printf("Unknown Xevent type=%d\n", report.type);
			break;

		}		/* switch on event type */

		/* process keyboard interface to menus */

		pd_menukey(&ev);

		/* burst keys for same window */

		if (ev.nkeys && (lastevent == EVENT_KEY) &&
		    (lastwindow == ev.window) &&
		    (eventque[nevents - 1].nkeys < 16))
		{
			i = nevents - 1;
			eventque[i].keys[eventque[i].nkeys] = ev.keys[0];
			eventque[i].nkeys++;
			lastevent = ev.type;
			ev.type = -1;	/* dont add to que */
		}		/* burst */
		/* e * suppress multiple move events */

		if (nevents && (ev.type == EVENT_DOWNMOVE) &&
		    (eventque[nevents - 1].type == EVENT_DOWNMOVE) &&
		    (eventque[nevents - 1].window == ev.window))
			nevents--;

		if (ev.type >= 0) {
			eventque[nevents++] = ev;
			newevents = TRUE;
			lastevent = ev.type;
			lastwindow = ev.window;
		}
		if (!QLength(display))
			break; /* while */

	} /* end while */

	if (cont_scroll_w >= 0) { /* continuous scrolling in effect */

		/* generate timing event for continouous scroll */

		ev.type = EVENT_TIME;
		ev.window = cont_scroll_w; 
		ev.view = cont_scroll_v; /* goes to scrollbar view */
		ev.value = cont_scroll_t;
		ev.eDataP = FARNULL;
		ev.a3 = cont_scroll_n;
		ev.timestamp = polltime; 
		if (nevents == 0) {
			eventque[nevents++] = ev;
			newevents = TRUE;
		} 
	} /* continuous scroll if */

	if (sview != CurrentView)
		TUTORset_view(sview);
	return (newevents);

} /* TUTORpoll_events */

/* ******************************************************************* */

TUTORset_cont_scroll(window,view,type,sn) /* set continuous scroll */
int window; /* window of scroll bar */
struct tutorview FAR *view; /* scroll bar view */
int type; /* sbLineUp, sbLineDown, etc */
double sn; /* amount to scroll */

{
	cont_scroll_w = window;
	cont_scroll_v = view;
	cont_scroll_t = type;
	cont_scroll_n = sn;

} /* TUTORset_cont_scroll */

/* ******************************************************************* */

TUTORforce_redraw(wix)		/* force redraw of specified window */
int wix;

{
	Window wp;		/* window structure */
	XWindowAttributes wattributes;	/* window attributes */
	struct tutorevent ev;	/* current event */

	if (!isx11)
		windowsP[wix].winRedraw = TRUE;
	else {
		ev.window = wix;/* set window of event */
		ev.view = FARNULL;
		ev.timestamp = TUTORinq_msec_clock();
		ev.id = 0;
		ev.eDataP = FARNULL;
		ev.type = EVENT_REDRAW;
		pd_menualt[ev.window] = TRUE;
		flushMenu = TRUE;
		wp = (Drawable) (windowsP[wix].wp);
		XGetWindowAttributes(display, wp, &wattributes);
		ev.x = wattributes.width;
		ev.y = wattributes.height - pd_barheight;
		wmg_xs[ev.window] = ev.x;
		wmg_ys[ev.window] = ev.y;
		eventque[nevents++] = ev;
		pd_menuredraw(&ev);
	}

} /* TUTORforce_redraw */

/* ******************************************************************* */

int WMpoll_events(block) /* queue up any pending events */
int block; /* TRUE if want to block on events */

{
#ifdef WM
	struct timeval selt;	/* wait time for fselect */
	union wait status;	/* status for wait3 */
	int key;		/* current key code */
	int action;		/* current mouse action code */
	int wix;		/* index in window table */
	int cutl;		/* length of cut buffer item */
	struct wm_window *cwp;	/* pointer to current window structure */
	struct wm_window *wp;	/* pointer to window structure */
	struct tutorevent ev;	/* current event */
	int lastwindow;		/* window of last event */
	int lastevent;		/* type of last event */
	int i, j;
	Memh theM;		/* menu bar of current window */
	TutorMenuBar FAR *theMp;/* used in processing menu event */
	struct tutorevent FAR *timeQ;	/* pointer to time queue */
	int newevents = FALSE;	/* TRUE if added a new event to queue */
	static char composeInd = 0;	/* index+1 in composeChar buffer
									(0 if not composing char, < 0 for escape seq) */
	static unsigned char composeChar[12];

	if (nevents >= (EVENTLIMIT - 2))
		return (FALSE);	/* exit if queue full */
	cwp = (struct wm_window *) (windowsP[CurrentWindow].wp);
	polltime = TUTORinq_msec_clock();	/* time of last TUTORpoll() */
	lastevent = lastwindow = -1;

	TUTORpoll_event_log();	/* process re-play events */

	/* check for redraw events */

	for (wix = 0; wix < WINDOWLIMIT; wix++)
	{
		if (windowsP[wix].winRedraw)
		{
			if (nevents >= EVENTLIMIT)
				return (FALSE);	/* exit if queue full */
			wp = (struct wm_window *) (windowsP[wix].wp);
			wm_SelectWindow(wp);
			windowsP[wix].winRedraw = FALSE;	/* clear redraw */
			ev.window = wix;	/* set up event fields */
			ev.view = FARNULL;
			ev.id = 0;
			ev.eDataP = FARNULL;
			ev.type = EVENT_REDRAW;
			ev.timestamp = polltime;
			wm_GetDimensions(&ev.x, &ev.y);
			wmg_xs[ev.window] = ev.x;
			wmg_ys[ev.window] = ev.y;
			eventque[nevents++] = ev;
			newevents = TRUE;
			pd_menuredraw(&ev);
		} /* redraw if */
	} /* for */

	/* check for timing events */

	timeQ = (struct tutorevent FAR *) GetPtr(timeque);
	j = 0;
	while (j < ntiming && (timeQ->timestamp <= polltime))
	{
		j++;
		if (modalW != -1 && (!timeQ->view || !timeQ->view->dialogV))
		{
			timeQ++;
			continue;	/* dialog is forward, this is
					 * non-dialog time event, just ignore
					 * it for now */
		}
		if (timeQ->type >= 0)
		{
			eventque[nevents].pressed = FALSE;
			eventque[nevents++] = *timeQ;
			newevents = TRUE;
		}
		ntiming--;
		j--;		/* to make up for deletion of event */
		for (i = 0; i < ntiming; i++, timeQ++)
			*timeQ = *(timeQ + 1);
	}			/* while */
	ReleasePtr(timeque);
	KillPtr(timeQ);

	/* initialize window input file pointers */

	for (wix = 0; wix < WINDOWLIMIT; wix++)
	{
		wp = (struct wm_window *) (windowsP[wix].wp);
		if (wp != NIL)
			wf[wix] = wm_infile(wp);
		else
			wf[wix] = NIL;
	}			/* for */

	/* check for mouse/keyboard/paste events */

	selt.tv_sec = 0;	/* set up short time interval */
	if (block && !newevents)
	{
		selt.tv_usec = 100;	/* timeout after blocking */
		wait3(&status, WNOHANG, 0);	/* non-blocking wait for
						 * child zombies */
	} else
		selt.tv_usec = 0;

	while (fselect(WINDOWLIMIT, wf, 0, 0, &selt) > 0)
	{
		for (wix = 0; wix < WINDOWLIMIT; wix++)
		{
			ev.type = -1;	/* pre-set no event */
			ev.id = 0;
			ev.dp = FARNULL;
			if (wf[wix])
			{
				if (nevents >= EVENTLIMIT)
					return (newevents);	/* exit if q full */
				wp = (struct wm_window *) (windowsP[wix].wp);
				wm_SelectWindow(wp);
				ev.window = wix;	/* set window of event */
				ev.view = FARNULL;	/* view not known yet */
				ev.timestamp = polltime;
				ev.pressed = FALSE;
				switch (key = (getc(winin)))
				{

					/* process mouse event */

				case wm_MouseInputToken:
					wm_SawMouse(&action, &ev.x, &ev.y);
					ev.leftdown = ev.rightdown = FALSE;
					switch (action)
					{

					case MouseMask(LeftButton, DownTransition):
						ev.type = EVENT_LEFTDOWN;
						ev.leftdown = TRUE;
						windowsP[ev.window].ldowntime2 = windowsP[ev.window].ldowntime1;
						windowsP[ev.window].ldowntime1 = ev.timestamp;
						break;

					case MouseMask(RightButton, DownTransition):
						ev.type = EVENT_RIGHTDOWN;
						ev.rightdown = TRUE;
						windowsP[ev.window].rdowntime2 = windowsP[ev.window].rdowntime1;
						windowsP[ev.window].rdowntime1 = ev.timestamp;
						break;

					case MouseMask(LeftButton, UpTransition):
						ev.type = EVENT_LEFTUP;
						ev.leftdown = FALSE;
						windowsP[ev.window].luptime = ev.timestamp;
						break;

					case MouseMask(RightButton, UpTransition):
						ev.type = EVENT_RIGHTUP;
						ev.rightdown = FALSE;
						windowsP[ev.window].ruptime = ev.timestamp;
						break;

					case MouseMask(LeftButton, DownMovement):
						ev.type = EVENT_DOWNMOVE;
						ev.leftdown = TRUE;
						break;

					case MouseMask(RightButton, DownMovement):
						ev.type = EVENT_DOWNMOVE;
						ev.rightdown = TRUE;
						break;

					}	/* action switch */
					break;

					/* process paste event */

				case (0200 | GR_HEREISCUTBUFFER):
					cutl = getc(winin);	/* 2nd byte of lth */
					cutl = cutl + (getc(winin) & 0xff) * 256;
					if (cutl <= 0)
						return (newevents);
					/* i = ((cutl >> 1) << 1) + 4; */
					ev.dp = (char *) (TUTORalloc((long) cutl, TRUE, "cut"));
					ev.value = cutl;
					for (i = 0; i < cutl; i++)
					{
						*(ev.dp + i) = getc(winin);
					}	/* for */
					/* *(ev.dp + i) = getc(winin);	/*
					 * add zero byte */

					ev.type = EVENT_PASTE;
					ev.a1 = 0; /* indicates wm cut buffer kind of PASTE */

					break;

				case 31:	/* menu selection */
					windowsP[wix].menuf = TRUE;
					break;

					/* process keyboard event */

				default:

					/* process menu event */

					if (windowsP[wix].menuf)
					{
						windowsP[wix].menuf = FALSE;
						ev.value = key - 32; /* also is index in menu bar items list */
						theM = windowsP[wix].menus;
						theMp = (TutorMenuBar FAR *) GetPtr(theM);
						ev.a1 = theMp->items[ev.value].type;
						
						/* some menus are really FKEYs */
						switch(ev.a1) {
						case edit_cut:
						case exec_cut:
							i = KCUT; break;
						case edit_copy:
						case exec_copy:
							i = KCOPY; break;
						case edit_paste:
						case exec_paste:
							i = KPASTE; break;
						case edit_undo:
							i = KUNDO; break;
						case edit_clear:
							i = -8; /* indicates key rather than fkey */
							break;
						default:
							i = 0; /* really is a menu */
						}
						
						if (i == 0) { /* menu */
							ev.type = theMp->items[ev.value].eventType;
							ev.a2 = theMp->items[ev.value].unit;
							ev.a3 = theMp->items[ev.value].unitArg;
							ev.a4 = (long) theM;
						} else { /* fkey or key */
							ev.type = (i > 0) ? EVENT_FKEY : EVENT_KEY;
							ev.nkeys = 1;
							ev.value = i;
							ev.keys[0] = -i;
						}
						ReleasePtr(theM);
						KillPtr(theMp);
					}
					/* process ordinary key */

					else
					{
						/* special check - reroute keys from 
							 command window to edit window */
						if (wix == DictWn)
							ev.window = EditWn[0];
						ev.nkeys = 1;
						if (key == 127 || key == 4)
							key = 8;	/* del */
						else if (key == RETURN)
							key = NEWLINE;
						else if (key == 26)
						{	/* start character
							 * composition  */
							composeInd = 1;
							break;
						} else if (composeInd > 0)
						{	/* accumulate chars for
							 * composition */
							composeChar[composeInd - 1] = key;
							composeInd++;
							if (composeInd >= 3 && composeChar[0] != ';')
							{ /* normal character */
								key = TUTORcompose_char(composeChar);
								composeInd = 0;
							} else if (composeInd >= 5)
							{ /* compose of function key */
								composeInd = 0;
								ev.value = TUTORcompose_fkey(composeChar);
								if (ev.value <= 0)
									break; /* invalid sequence */
								ev.type = EVENT_FKEY;
								break;
							} else
								break;
						} else if (composeInd < 0)
						{	/* accumulate characters for escape sequence */
							composeChar[-composeInd-1] = key;
							composeInd--;
#ifdef sunV3
							if (composeChar[0] != '[' || composeInd <= -6 ||
								(composeChar[0] == '[' && composeInd == -3 &&
									(key >= 'A' && key <= 'D')))
#else /* presumably decstation */
							if (composeChar[0] != '[' ||
								((key >= 'A' && key) <= 'D' || key == '~'))
#endif
							{ /* have complete sequence, see if we recognize it */
								composeChar[5] = '\0';
								key = EscapeSequence(composeChar);
								if (key)
								{ /* we recognized it, its a function */
									ev.type = EVENT_FKEY;
									ev.value = key;
								}
								composeInd = 0; /* no longer composing */
							}
							break;
						} else if (key == 27)
						{	/* start of escape sequence */
							composeInd = -1;
							break; /* no event generated */
						} else if (key < 32)
						{ /* control keys */
							j = ControlKey(key);
							if (j)
							{ /* key was a valid function */
								ev.type = EVENT_FKEY;
								ev.value = j;
								break;
							}
							/* otherwise we let control char thru as a key */
						}

						ev.type = EVENT_KEY;
						ev.keys[0] = key;



					}	/* else */
					break;

				}	/* key switch */

				/* burst keys for same window */

				if (ev.nkeys && (lastevent == EVENT_KEY) &&
				    (ev.type == EVENT_KEY) &&
				    (lastwindow == ev.window) &&
				    (eventque[nevents - 1].nkeys < 16))
				{
					i = nevents - 1;
					eventque[i].keys[eventque[i].nkeys] = ev.keys[0];
					eventque[i].nkeys++;
					lastevent = ev.type;
					ev.type = -1;	/* dont add to que */
				} else
					lastevent = ev.type;
				lastwindow = ev.window;

			}	/* wf if */
			/* suppress multiple move events */

			if (nevents && (ev.type == EVENT_DOWNMOVE) &&
			    (eventque[nevents - 1].type == EVENT_DOWNMOVE) &&
			    (eventque[nevents - 1].window == ev.window))
				nevents--;

			if (ev.type >= 0)
			{
				eventque[nevents++] = ev;
				newevents = TRUE;
			} /* ev.type (namely event valid) if */



		}		/* for */
	}			/* fselect while */



	if (cwp != wp)
		wm_SelectWindow(cwp);	/* restore window */
	return (newevents);

#endif /* WM */
} /* WMpoll_events */

/* ******************************************************************* */
TUTORfree_event_memory(event)
struct tutorevent FAR *event;
	{
	switch(event->type)
		{
	case EVENT_PASTE:
		if (isx11)
			XFree(event->eDataP);
		else
			TUTORdealloc(event->eDataP);
		break;
	
	case EVENT_HOT:
		TUTORdealloc(event->eDataP);
		break;
	
	default:
		break;
		}
	
	return(0);
	}

/* ******************************************************************* */
EscapeSequence(seq)
char *seq;
	{
	int val;
	int key; /* the return value */
	char *pp;
	
	key = 0;
	if (!isx11 && seq[0] == '[')
		{ /* start of sun special key sequence */
		switch (seq[1])
			{
			case 'A':
				key = KUP; break;
			case 'B':
				key = KDOWN; break;
			case 'C':
				key = KRIGHT; break;
			case 'D':
				key = KLEFT; break;
			}
		if (key)
			return(key); /* was an arrow key */
		
#ifdef sunV3
		/* other special key sequences: */
		if (seq[4] != 'z')
			return(0); /* bad sequence */
		seq[4] = '\0';
		sscanf(seq+1,"%d",&val);
		
		switch(val)
			{
			case 224:
				key = KFA; break;
			case 225:
				key = KFB; break;
			case 226:
				key = KFC; break;
			case 227:
				key = KFD; break;
			}
		}
#else /* presumably decstation */
		/* we want to terminate at the tilde */
		pp = seq;
		while (*pp != '~')
			pp++;
		*pp = '\0';
		sscanf(seq+1,"%d",&val);
		switch(val)
			{
			case 28:
				key = KHELP; break;
			case 2: /* insert */
				key = KPASTE; break;
			case 3: /* remove */
				key = KCUT; break;
			case 5: /* page up */
				key = KPAGEUP; break;
			case 6: /* page down */
				key = KPAGEDOWN; break;
			case 17: /* f6 */
				key = KFA; break;
			case 18: /* f7 */
				key = KFB; break;
			case 19: /* f8 */
				key = KFC; break;
			case 20: /* f9 */
				key = KFD; break;
			}
		}
#endif

	else
		{ /* simple escape sequence */
		switch (seq[0])
			{
			case 'v':
				key = KSPAGEUP; break;
			case 'w':
				key = KCOPY; break;
			case '<':
				key = KSBEGFILE; break;
			case '>':
				key = KSENDFILE; break;
			default:
				break;
			}
		}
	
	return(key);
	}
	

/* ******************************************************************* */
ControlKey(key)
int key;
	{
	int retKey;
	
	retKey = 0;
	switch (key)
		{
		case 1:
			retKey = KBEGLINE; break;
		case 2:
			retKey = KLEFT; break;
		case 5:
			retKey = KENDLINE; break;
		case 6:
			retKey = KRIGHT; break;
		case 14:
			retKey = KDOWN; break;
		case 16:
			retKey = KUP; break;
		case 20:
			retKey = KTRANSPOSE; break;
		case 21:
			retKey = KUNDO; break;
		case 22:
			retKey = KSPAGEDOWN; break;
		case 23:
			retKey = KCUT; break;
		case 25:
			retKey = KPASTE; break;
		
		}
	
	return(retKey);
	}
	

/* ******************************************************************* */

char FAR *CTzks(code,tempS) /* convert key code to name */
int code;
char *tempS;
	{
	char FAR *ss;
	struct keywdinf *keyseq;
	int ii;
	
	if (code > 350)
		return(""); /* not a key */
	
	if (code > 32 && code < 127)
		{ /* perfectly normal key */
		tempS[0] = code;
		tempS[1] = '\0';
		return(tempS);
		}
	else if (code >= 0xa0 && code < 256)
		{ /* extended characters.  These are composed */
#ifndef sunV3
		if (isx11) {
			strcpy(tempS,"compose ");
			ii = 8;
		}
		else {
			ii = 6;
			strcpy(tempS,"ctl-z ");
		}
#else
		strcpy(tempS,"ctl-z ");
		ii = 6;
#endif
		GetCompose(code, tempS+ii);
		return(tempS);
		}
	
	/* otherwise string is complicated */
	
	tempS[0] = '\0'; /* for assembly of strings */
	ss = FARNULL; /* not set yet */
	switch (code)
		{
		case KNEXT:
			ss = "enter"; break;
		case KTAB:
			ss = "tab"; break;
		case 32:
			ss = "space"; break;
		case KERASE:
			ss = "delete"; break;
		case KCUT:
#ifdef sunV3
			ss = "ctl-w";
#else
			if (isx11)
				ss = "remove";
			else
				ss = "ctl-w";
#endif
			break;
		case KCOPY:
			ss = "esc w"; break;
		case KPASTE:
#ifdef sunV3
			ss = "ctl-y";
#else
			if (isx11)
				ss = "insert";
			else
				ss = "ctl-y";
#endif
			break;
		case KUNDO:
			ss = "ctl-u";
			break;
		
		case KLEFT:
			ss = "leftarrow"; break;
		case KLEFT+1:
			if (isx11)
				ss = "shift-leftarrow";
			break;	
		case KRIGHT:
			ss = "rightarrow"; break;
		case KRIGHT+1:
			if (isx11)
				ss = "shift-rightarrow";
			break;
		case KUP:
			ss = "uparrow"; break;
		case KUP+1:
			if (isx11)
				ss = "shift-uparrow";
			break;
		case KDOWN:
			ss = "downarrow"; break;
		case KDOWN+1:
			if (isx11)
				ss = "shift-downarrow";
			break;
	
		case KBEGLINE:
			ss = "ctl-a"; break;
		case KBEGFILE:
			ss = "esc <"; break;
			
		case KENDLINE:
			ss = "ctl-e"; break;
		case KENDFILE:
			ss = "esc >"; break;
		
#ifdef sunV3
		case KPAGEUP:
			ss = "esc v"; break;
		case KPAGEDOWN:
			ss = "ctl-v"; break;
#else /* sunV3 */
		case KPAGEUP:
			ss = "pageup"; break;
		case KPAGEUP+1:
			if (isx11)
				ss = "shift-pageup";
			break;
		case KPAGEDOWN:
			ss = "pagedown"; break;
		case KPAGEDOWN+1:
			if (isx11)
				ss = "shift-pagedown";
			break;
#endif

		case KESCAPE:
			ss = "escape"; break;

		case KTRANSPOSE:
			ss = "ctl-t"; break;
	
		case KHELP:
#ifdef sunV3
			break;
#else
			ss = "help"; break;
#endif
		case KFWDDEL:
			break;
		
#ifdef sunV3
		case KFA:
			ss = "F1"; break;
		case KFB:
			ss = "F2"; break;
		case KFC:
			ss = "F3"; break;
		case KFD:
			ss = "F4"; break;
#else
		case KFA:
			if (isx11)
				ss = "F1";
			else
				ss = "F6";
			break;
		case KFB:
			if (isx11)
				ss = "F2";
			else
				ss = "F7";
			break;
		case KFC:
			if (isx11)
				ss = "F3";
			else
				ss = "F8";
			break;
		case KFD:
			if (isx11)
				ss = "F3";
			else
				ss = "F9";
			break;
#endif
		}
	
	if (!ss)
		{ /* we don't have this key on this keyboard,
				get the composition sequence */
#ifndef sunV3
		if (isx11)
			strcpy(tempS,"compose ");
		else
			strcpy(tempS,"ctl-z ");
#else
		strcpy(tempS,"ctl-z ");
#endif
		keyseq = GetComposeFKey(); /* get composition sequences */
		while (keyseq->value > 0)
			{
			if (keyseq->value == code)
				break;
			keyseq++;
			}
		if (keyseq->value > 0)
			{
			strcat(tempS,";");
			strcat(tempS,keyseq->name);
			ss = tempS;
			}
		}
	
	if (!ss)
		{ /* we couldn't figure this out at all */
		ss = "";
		}
	
	return(ss);
	}

/* ******************************************************************* */

TUTORshould_interrupt()
{
	return (polltime + 750 < TUTORinq_msec_clock());
}

/**********************************************************************/

#ifdef ctproto
int peek_expose(Display *,XEvent *,char *);
#endif

int peek_expose(display,event,arg)
Display *display;
XEvent *event;
char *arg;

{	
	if (event->type == Expose)
		return(True);
	return(False);

} /* peek_expose */

/**********************************************************************/

TUTORnew_window(wid)	/* open new window */
/* windows[].wxsize/wysize = initial size */
/* if 0 = window managers default */
int wid;			/* id # in window table */

{	Window win;
	XWindowAttributes wattributes;	/* window attributes */
	XSizeHints xsh;
	int width, height, xorigin, yorigin, maxwidth,maxheight;
	int dtop, dleft, dwidth, dheight;	/* default window position */
	char *wName;
	XEvent pevent;
	int top = 0; int left = 0;
	TRect *pR;  /* window size / position preference */

	if (!isx11) {
		if ((windowsP[wid].wp = (long) (wm_NewWindow(0))) == NIL) {
			TUTORdump("Unable to open new window");
			exit(-1);
		}
		windowsP[wid].winRedraw = TRUE;
		if (windowsP[wid].wxsize)
			wm_SetDimensions(0, windowsP[wid].wxsize,
					 0, windowsP[wid].wysize);
		wm_GetDimensions(&windowsP[wid].wxsize,
				 &windowsP[wid].wysize);
		if (!x11ColorInited) {
			CTinit_color();
			x11ColorInited = TRUE;
		}
		return;
	}
	/* default screen position */
	yorigin = 40;
	xorigin = 0;
	width = ((maxwidth = DisplayWidth(display, screen)) >> 1) - 10;
	if ((width > 300) && (width < 512))
		width = 512; /* prefer a 512 wide window by default */
	height = ((maxheight = DisplayHeight(display, screen)) - 80) >> 1;

	if (windowsP[wid].type == EXECW) {
		if (ExecWinX) {
			if ((ExecWinX >= 20) && (ExecWinX < maxwidth) && 
			    (ExecWinY >= 20) && (ExecWinY < maxheight)) {
				width = ExecWinX;
				height = ExecWinY;
			}
		}
		if (!nosourcelayout)
			xorigin = width + 10;
		wName = " cT ";
	} else if (windowsP[wid].type == DICTW) {
		yorigin = height + 100;
		height = 60;
		wName = "cT Commands";
	} else if (windowsP[wid].type == HELPW) {
		yorigin = height + 120;
		height -= 120;
		wName = "cT Help";
	} else if (windowsP[wid].type == SEARCHW){
		wName = "cT Search";
		xorigin = width + 5;
	} else {			/* edit window */
		wName = "cT Edit";
	}

	/* if a certain position was requested, honor it */
	if (top > 0)
		xorigin = top;
	if (left > 0)
		yorigin = left;
	if (windowsP[wid].wxsize > 0)
		width = windowsP[wid].wxsize;
	if (windowsP[wid].wysize > 0)
		height = windowsP[wid].wysize;

	win = XCreateSimpleWindow(display,
	    RootWindow(display, screen), xorigin, yorigin, width, height, 2,
		  BlackPixel(display, screen), WhitePixel(display, screen));

	drawwindow = win;

	gcv.foreground = BlackPixel(display, screen);
	gcv.background = WhitePixel(display, screen);
	gcv.fill_rule = WindingRule;
	gcv.fill_style = FillSolid;
	gcv.font = XLoadFont(display, "variable");
	gcv.graphics_exposures = FALSE;	/* not interested in these */
	gcv.plane_mask = 0xffffffff;

	gc = XCreateGC(display, drawwindow, GCForeground |
		       GCBackground | GCFont | GCGraphicsExposures |
		       GCFillStyle | GCFillRule | GCPlaneMask, &gcv);

	/* create pixmap for pattern tile, initially solid */
	makepattern[wid] = XCreatePixmap(display, drawwindow, 16, 16, 1);
	gcpatt = XCreateGC(display, makepattern[wid], GCForeground |
			   GCBackground | GCFont | GCGraphicsExposures |
			   GCFillStyle | GCFillRule, &gcv);

	XSetBackground(display, gcpatt, 0);
	XSetForeground(display, gcpatt, 0);
	XFillRectangle(display, makepattern[wid], gcpatt, 0, 0, 16, 16);
	XSetStipple(display, gc, makepattern[wid]);

	XSelectInput(display, win, ExposureMask | ButtonPressMask | ButtonReleaseMask | KeyPressMask | PointerMotionMask | EnterWindowMask | LeaveWindowMask | FocusChangeMask);

	XSetIconName(display, win, wName);
	XStoreName(display, win, wName);
	XSetWMHints(display, win, &xwmh);

	xsh.flags = (PSize /* | PMinSize | PMaxSize */ );
	xsh.width = xsh.min_width = xsh.max_width = width;
	xsh.height = xsh.min_height = xsh.max_height = height;
	XSetNormalHints(display, win, &xsh);
	XSetZoomHints(display, win, &xsh);

	XMapWindow(display, win);

	/* block till expose event comes thru */
	/* can't draw on window till exposed */

	XPeekIfEvent(display,&pevent,peek_expose,NULL);

	XGetWindowAttributes(display, win, &wattributes);
	windowsP[wid].wxsize = wattributes.width;
	windowsP[wid].wysize = wattributes.height - pd_barheight;

	currentXwindow = wid;
	windowsP[wid].wp = (long) win;
	windowsP[wid].winRedraw = FALSE;	/* X11 gives redraw events */

	if (!x11ColorInited)
		CTinit_color();	/* initialize color for x11 for all
					 * windows */
	x11ColorInited = TRUE;
	
	XSetWindowColormap(display,win,cTdefMap);

} /* TUTORnew_window */
	
/**********************************************************************/

#ifdef NOSUCH

TUTORnew_window(wid)	/* open new window */
/* windows[].wxsize/wysize = initial size */
/* if 0 = window managers default */
int wid;			/* id # in window table */

{	Window win;
	XWindowAttributes wattributes;	/* window attributes */
	XSizeHints xsh;
	int width, height, xorigin, yorigin, maxwidth,maxheight;
	int dtop, dleft, dwidth, dheight;	/* default window position */
	char *wName;
	XEvent pevent;
	TRect *pR; /* pointer to window (preference) rectangle */

	/* default screen position */
	
	yorigin = 40;
	xorigin = 0;
	width = ((maxwidth = DisplayWidth(display, screen)) >> 1) - 10;
	if ((width > 300) && (width < 512))
		width = 512; /* prefer a 512 wide window by default */
	height = ((maxheight = DisplayHeight(display, screen)) - 80) >> 1;

	pR = FARNULL;
	if (windowsP[wid].type == EDITW) {
		pR = &prfP->editWp;
	} else if (windowsP[wid].type == EXECW) {
		if (ExecWinX) {
			if ((ExecWinX >= 20) && (ExecWinX < maxwidth) && 
			    (ExecWinY >= 20) && (ExecWinY < maxheight)) {
				width = ExecWinX;
				height = ExecWinY;
			}
		}
		if (!nosourcelayout)
			xorigin = width + 10;
		wName = " cT ";
#ifndef EXECUTE
		pR = &prfP->execWp;
#endif
	} else if (windowsP[wid].type == MESGW) {
		pR = &prfP->msgWp;
	} else if (windowsP[wid].type == DEBUGW) {
		pR = &prfP->debugWp;
	} else if (windowsP[wid].type == DEBUGAUXW) {
		pR = &prfP->stackWp;
	} else if (windowsP[wid].type == DICTW) {
		yorigin = height + 100;
		height = 60;
		wName = "cT Commands";
	} else if (windowsP[wid].type == HELPW) {
		yorigin = height + 120;
		height -= 120;
		wName = "cT Help";
	} else if (windowsP[wid].type == SEARCHW){
		wName = "cT Search";
		xorigin = width + 5;
	} else {			/* edit window */
		wName = "cT Edit";
	}

	/* if a certain size was requested, honor it */
	
	if (windowsP[wid].wxsize > 0) {
		width = windowsP[wid].wxsize;
		if (windowsP[wid].wysize > 0)
			height = windowsP[wid].wysize;
	} else if (pR) {
		xorigin = pR->left;
		yorigin = pR->top;
		width = (pR->right-pR->left)+1;
		height = (pR->bottom-pR->top)+1;
	}

	win = XCreateSimpleWindow(display,
	    RootWindow(display, screen), xorigin, yorigin, width, height, 2,
		  BlackPixel(display, screen), WhitePixel(display, screen));

	drawwindow = win;

	gcv.foreground = BlackPixel(display, screen);
	gcv.background = WhitePixel(display, screen);
	gcv.fill_rule = WindingRule;
	gcv.fill_style = FillSolid;
	gcv.font = XLoadFont(display, "variable");
	gcv.graphics_exposures = FALSE;	/* not interested in these */
	gcv.plane_mask = 0xffffffff;

	gc = XCreateGC(display, drawwindow, GCForeground |
		       GCBackground | GCFont | GCGraphicsExposures |
		       GCFillStyle | GCFillRule | GCPlaneMask, &gcv);

	/* create pixmap for pattern tile, initially solid */
	makepattern[wid] = XCreatePixmap(display, drawwindow, 16, 16, 1);
	gcpatt = XCreateGC(display, makepattern[wid], GCForeground |
			   GCBackground | GCFont | GCGraphicsExposures |
			   GCFillStyle | GCFillRule, &gcv);

	XSetBackground(display, gcpatt, 0);
	XSetForeground(display, gcpatt, 0);
	XFillRectangle(display, makepattern[wid], gcpatt, 0, 0, 16, 16);
	XSetStipple(display, gc, makepattern[wid]);

	XSelectInput(display, win, ExposureMask | ButtonPressMask | ButtonReleaseMask | KeyPressMask | PointerMotionMask | EnterWindowMask | LeaveWindowMask | FocusChangeMask);

	XSetIconName(display, win, wName);
	XStoreName(display, win, wName);
	XSetWMHints(display, win, &xwmh);

	xsh.flags = (PSize /* | PMinSize | PMaxSize */ );
	xsh.width = xsh.min_width = xsh.max_width = width;
	xsh.height = xsh.min_height = xsh.max_height = height;
	XSetNormalHints(display, win, &xsh);
	XSetZoomHints(display, win, &xsh);

	XMapWindow(display, win);

	/* block till expose event comes thru */
	/* can't draw on window till exposed */

	XPeekIfEvent(display,&pevent,peek_expose,NULL);

	XGetWindowAttributes(display, win, &wattributes);
	windowsP[wid].wxsize = wattributes.width;
	windowsP[wid].wysize = wattributes.height - pd_barheight;

	currentXwindow = wid;
	windowsP[wid].wp = (long) win;
	windowsP[wid].winRedraw = FALSE;	/* X11 gives redraw events */

	if (!x11ColorInited)
		CTinit_color();	/* initialize color for x11 for all
					 * windows */
	x11ColorInited = TRUE;
	
	XSetWindowColormap(display,win,cTdefMap);

} /* TUTORnew_window */

#endif

int TUTORclose_window(wix) 
int wix; /* index of window to close */

{	struct tutorevent FAR *evp;
	int ii;
	
	if (wix < 0) 
		return(0); /* nothing to do */
	
	XDestroyWindow(display,(Window)windowsP[wix].wp);
	windowsP[wix].wp = FARNULL;
	if (CurrentWindow == wix)
		CurrentWindow = -1; /* no window */
	
	/* cancel pending events for this window */
	
	for(ii=0; ii<nevents; ii++) {
		if (eventque[ii].window == wix)
			eventque[ii].type = -1; /* kill event */
	} /* for */
	evp = (struct tutorevent FAR *) GetPtr(timeque);
    for(ii = 0; ii < ntiming; ii++, evp++) {
        if (evp->window == wix) 
            evp->type = -1; /* kill event */
    } /* for */
    ReleasePtr(timeque);
	
} /* TUTORclose_window */

/* ******************************************************************* */

int TUTORsize_exec_window(xx,yy) /* resize execution window */
int xx; /* new x size for window */
int yy; /* new y size for window */

{	int maxwidth,maxheight;
	Window wp;

	maxwidth = DisplayWidth(display, screen);
	maxheight = DisplayHeight(display, screen);
	if ((xx >= 20) && (xx < maxwidth) && (yy >= 20) && (yy < maxheight)) {
		wp = (Window) (windowsP[ExecWn].wp);
		XResizeWindow(display, wp, xx, yy);
		TUTORforce_redraw(ExecWn);
	}
	return(0);
	
} /* TUTORsize_exec_window */

/* ******************************************************************* */

TUTORframe_window(int wid)

{				/* no-op on wm/x11/mac */
}

/* ******************************************************************* */

TUTORselect_window(wix) /* machine dependent portion of TUTORset_window */
int wix; /* index in window table */
{
	struct tutorfont FAR *fp;
	int wFont;

	wFont = windowsP[wix].FontIndex;
	if (isx11)
	{
		currentXwindow = wix;
		drawwindow = (Drawable) (windowsP[wix].wp);
		if (windowsP[wix].type == EXECW)
		{
			SetXFill();
			XSetWindowColormap(display, drawwindow, cTdefMap);
		} else
		{
			XSetFillStyle(display, gc, FillSolid);
			XSetWindowColormap(display, drawwindow, cTdefMap);
		}
		SetX11PixelValues(wix); /* set pixel values for this window */
		if (TRUE /* textFont != wFont */)
		{		/* adjust the graphics context (only 1 for
				 * all cT) */
			TUTORset_textfont(wFont);
		}
	} else
	{			/* wm */
		wm_SelectWindow((struct wm_window *) (windowsP[wix].wp));
		if (textFont != wFont)
		{		/* adjust our variables to what is in the
				 * window */
			fp = wFont + (struct tutorfont FAR *) GetPtr(fontsH);
			wmFont = fp->ptr;
			textFontFamily = fp->fID;
			textFontSize = fp->size;
			textFontFace = fp->textface;
			ReleasePtr(fontsH);
			KillPtr(fp);
			textFont = wFont;
		}
	}

} /* TUTORselect_window */

/* ******************************************************************* */

TUTORforward_window(wix)
int wix;			/* index in window table */
{
	if ((wix < 0) || (!windowsP[wix].wp)) return;
	
	if (isx11)
	{
		XMapRaised(display, (Window) (windowsP[wix].wp));
		XSync(display,FALSE);
		TUTORgrab_focus(wix); 
	}
}

TUTORgrab_focus(wix)
int wix;
{	XWindowAttributes wAttrib;

#ifndef sunV3
	if (isx11)
	{
		TUTORflush();	/* make sure output is flushed */
		XGetWindowAttributes(display,(Window)windowsP[wix].wp,&wAttrib);
		if (wAttrib.map_state == IsViewable)
			XSetInputFocus(display, (Window) (windowsP[wix].wp),
			       RevertToPointerRoot, CurrentTime);
	}
#endif

	return;
}

/* ******************************************************************* */

int TUTORget_AE_win()

{   int wix; /* index of window */
    Window wp;		/* window structure */
    XWindowAttributes wAttributes;	/* window attributes */
    
    if (EditWn[0] < 0)
	return(0); /* no go */

    wix = EditWn[0];	
    wp = (Drawable) (windowsP[wix].wp);
    XGetWindowAttributes(display, wp, &wAttributes);
    prfP->editWp.left = wAttributes.x;
    prfP->editWp.top = wAttributes.y;
    prfP->editWp.right = wAttributes.x+wAttributes.width;
    prfP->editWp.bottom = wAttributes.y+wAttributes.height;

    if (ExecWn >= 0) {
    	wix = ExecWn;
        wp = (Drawable) (windowsP[wix].wp);
        XGetWindowAttributes(display, wp, &wAttributes);
        prfP->execWp.left = wAttributes.x;
        prfP->execWp.top = wAttributes.y;
        prfP->execWp.right = wAttributes.x+wAttributes.width;
        prfP->execWp.bottom = wAttributes.y+wAttributes.height;
    }

#ifdef NOSUCH
    HWND hWnd;
    RECT wRect; /* window rectangle */

    if (EditWn[0] < 0)
	return(0); /* no go */

    wix = EditWn[0];
    hWnd = (HWND)windowsP[wix].wp;
    GetWindowRect(hWnd,(RECT FAR *)&wRect);
    prfP->editWp.left = wRect.left;
    prfP->editWp.top = wRect.top;
    prfP->editWp.right = wRect.right;
    prfP->editWp.bottom = wRect.bottom;

	if (ExecWn >= 0) {
    	wix = ExecWn;
    	hWnd = (HWND)windowsP[wix].wp;
    	GetWindowRect(hWnd,(RECT FAR *)&wRect);
		prfP->execWp.left = wRect.left;
		prfP->execWp.top = wRect.top;
		prfP->execWp.right = wRect.right;
		prfP->execWp.bottom = wRect.bottom;
    }

    if (MsgWn >= 0) {
		wix = MsgWn;
		hWnd = (HWND)windowsP[wix].wp;
		GetWindowRect(hWnd,(RECT FAR *)&wRect);
		prfP->msgWp.left = wRect.left;
		prfP->msgWp.top = wRect.top;
		prfP->msgWp.right = wRect.right;
		prfP->msgWp.bottom = wRect.bottom;
    }

    if (DebugWn >= 0) {
		wix = DebugWn;
		hWnd = (HWND)windowsP[wix].wp;
		GetWindowRect(hWnd,(RECT FAR *)&wRect);
		prfP->debugWp.left = wRect.left;
		prfP->debugWp.top = wRect.top;
		prfP->debugWp.right = wRect.right;
		prfP->debugWp.bottom = wRect.bottom;
    }

    if (AuxWn >= 0) {
		wix = AuxWn;
		hWnd = (HWND)windowsP[wix].wp;
		GetWindowRect(hWnd,(RECT FAR *)&wRect);
		prfP->stackWp.left = wRect.left;
		prfP->stackWp.top = wRect.top;
		prfP->stackWp.right = wRect.right;
		prfP->stackWp.bottom = wRect.bottom;
    }    
#endif    
    return(0);

} /* TUTORget_AE_win */

/* ******************************************************************* */

TUTORset_program_name(pname)	/* set program name of current front window */
char *pname;			/* program name string */
{
	if (isx11)
		XStoreName(display, (Window) drawwindow, pname);
	else
		wm_SetProgramName(pname);
}

/* ******************************************************************* */

TUTORset_window_title(wid, wt)	/* set title of window */
char *wt;			/* window title string */
int wid;			/* window to set */
{

	if (isx11)
	{
		XStoreName(display, (Window) windowsP[wid].wp, wt);
	} else
	{
		wm_SelectWindow((struct wm_window *) (windowsP[wid].wp));
		wm_SetTitle(wt);
		wm_SelectWindow((struct wm_window *) (windowsP[CurrentWindow].wp));
	}
}

/* ******************************************************************* */
TUTORhide_window(wid)
int wid;
{
	int curW;

	if (isx11)
		XUnmapWindow(display, (Window) (windowsP[wid].wp));
	else
	{
		curW = CurrentWindow;
		TUTORset_window(wid);
		wm_HideMe();
		TUTORset_window(curW);
	}
}

/* ******************************************************************* */

TUTORshow_window(wid)
int wid;

{	int curW;

	if (isx11)
		XMapRaised(display, (Window) (windowsP[wid].wp));
	else {
		curW = CurrentWindow;
		TUTORset_window(wid);
		wm_ExposeMe();
		TUTORset_window(curW);
	}
	
} /* TUTORshow_window */

/* ******************************************************************* */
TUTORwindow_init(wix)
int wix;

{
	if (!isx11)
	{
		wm_SetRawInput();
		wm_DisableNewlines();
		wm_ClearWindow();
	}
}				/* TUTORwindow_init */

/* ******************************************************************* */
TUTORresize_window(wid, newX, newY)
int wid;			/* which window to resize */
int newX, newY;			/* new window size */
{
	XSizeHints sHints;
	XWindowAttributes wattributes;	/* window attributes */
	Window win;

	if (windowsP[wid].wxsize == newX &&
	    windowsP[wid].wysize == newY)
		return;		/* nothing to do */

	if (!isx11)		/* no resizing on wm */
		printf("Attempt to size window %d to %d %d\n", wid, newX, newY);
	else
	{
		/* give the window manager a hint, in case it ignores the
		 * redirected configuration request */
		/* note: if min/max stuff set for window, these hints may not
		 * do any good... */
		sHints.width = newX;
		sHints.height = newY + pd_barheight;
		sHints.flags = PSize;	/* we are only specifying a size */
		win = (Window) (windowsP[wid].wp);
		XSetNormalHints(display, win, &sHints);

		/* do the resize */
		XResizeWindow(display, win, newX, newY + pd_barheight);

		/* find out what we really got */
		XGetWindowAttributes(display, win, &wattributes);
		windowsP[wid].wxsize = wattributes.width;
		windowsP[wid].wysize = wattributes.height - pd_barheight;
		wmg_xs[wid] = wattributes.width;
		wmg_ys[wid] = wattributes.height;
	}

	return;
}

/* ******************************************************************* */

TUTORclose_copyright()
{ /* clear copyright notice early */ ;
}

/* ********************************************************* */

TUTORdone_startup()
{				/* finish startup tasks */

	if (noticeWindow) {
		if (noticePix) 
			XFreePixmap(display,noticePix);
		XDestroyWindow(display,noticeWindow);
		noticeWindow = 0;
		free(noticeP);
	}
	if (EditWn[0] >= 0)	/* the Edit window should be frontmost at
				 * program start */
		TUTORforward_window(EditWn[0]);
}

/* ********************************************************** */

TUTORsystem_tasks()
{				/* do periodic tasks from root segment */

	if (isx11) {
		;
	} else {
		;			/* nothing to do in wm */
	}
}

/* ********************************************************** */

TUTORunlock_code()
{				/* unlock or otherwise free code segments */
	;			/* nothing to do in wm */
}

/* ******************************************************************* */

TUTORsync()
{				/* synchronize with window manager */
	TUTORflush();		/* cannot sync with Andrew wm */

}				/* TUTORsync */

/* ******************************************************************* */

TUTORflush()
{
	if (CurrentWindow < 0)
		return;
	if (isx11)
		pd_flush();
	machineflush();

}				/* TUTORflush */

/* ******************************************************************* */

machineflush()
{				/* machine-specific flush routine */
	if (isx11)
		XFlush(display);
#ifdef WM
	else
		fflush(winout);
#endif
}

/* ******************************************************************* */

TUTORset_event_mask(eventc, value)	/* set specified event mask entry */
int eventc;			/* event type to set */
int value;			/* TRUE or FALSE for this event */

{
	unsigned long m;	/* cumulative mouse mask */
	struct tutorwindow FAR *wp;	/* pointer to current window data */
	XSetWindowAttributes attributes;	/* window attributes */

	wp = &windowsP[CurrentWindow];
	wp->eventMask[eventc] = value;

	m = 0;			/* initialize mouse mask */
	if (isx11)
	{
		if (wp->eventMask[EVENT_LEFTDOWN])
			m = m | ButtonPressMask;
		if (wp->eventMask[EVENT_LEFTUP])
			m = m | ButtonReleaseMask;
		if (wp->eventMask[EVENT_RIGHTDOWN])
			m = m | ButtonPressMask;
		if (wp->eventMask[EVENT_RIGHTUP])
			m = m | ButtonReleaseMask;
		if (wp->eventMask[EVENT_DOWNMOVE])
			m = m | PointerMotionMask;
		if (m == 0)
			return;

		attributes.event_mask = m | KeyPressMask | ExposureMask | EnterWindowMask |
			LeaveWindowMask | FocusChangeMask;

		XChangeWindowAttributes(display,
					(Window) (windowsP[CurrentWindow].wp),
					CWEventMask, &attributes);
	} else {
		;
#ifdef WM
		if (wp->eventMask[EVENT_LEFTDOWN])
			m = m | MouseMask(LeftButton, DownTransition);
		if (wp->eventMask[EVENT_LEFTUP])
			m = m | MouseMask(LeftButton, UpTransition);
		if (wp->eventMask[EVENT_RIGHTDOWN])
			m = m | MouseMask(RightButton, DownTransition);
		if (wp->eventMask[EVENT_RIGHTUP])
			m = m | MouseMask(RightButton, UpTransition);
		if (wp->eventMask[EVENT_DOWNMOVE])
		{
			m = m | MouseMask(RightButton, DownMovement);
			m = m | MouseMask(LeftButton, DownMovement);
		}		/* downmove if */
		if (m == 0)
			return;
		wm_SetMouseInterest(m);
#endif
	}

}				/* TUTORset_event_mask */

/* ******************************************************************* */

TUTORscroll_rect(r, dh, dv)	/* scroll specified area of screen */
TRect *r;			/* rectangular area to scroll */
int dh;				/* amount to scroll right */
int dv;				/* amount to scroll down */

{
	TRect er;		/* rectangle to erase */

	if (dh == 0 && dv == 0)
		return (0);	/* nothing to do */

	/* move specified area */
	TUTORmove_abs_rect(r->left, r->top, r->right, r->bottom, r->left + dh, r->top + dv);

	/* clear previous area */
	er = *r;
	/* make sure erase doesn't overlap new area.  Note that this assumes
	 * that one of dh and dv are 0 */
	if (dh > 0)
		er.right = r->left + dh - 1;
	if (dh < 0)
		er.left = r->right + dh;
	if (dv > 0)
		er.bottom = r->top + dv - 1;
	if (dv < 0)
		er.top = r->bottom + dv;
	TUTORdraw_abs_solid_rect((TRect FAR *) & er, PAT_BACKGROUND);

}				/* TUTORscroll_rect */

/* ******************************************************************* */

TUTORset_rect(r, left, top, right, bottom)	/* set up rectangle */
TRect *r;			/* rectangle to set up */
int left, top, right, bottom;

{
	r->top = top;
	r->left = left;
	r->right = right;
	r->bottom = bottom;

}				/* TUTORset_rect */

/* ******************************************************************* */
TUTORmove_rect(rr, xx, yy)	/* move a rectangles coordinates */
register TRect FAR *rr;
int xx;
int yy;
{
	rr->top += yy;
	rr->bottom += yy;
	rr->left += xx;
	rr->right += xx;
}

/* ******************************************************************* */
TUTORinset_rect(rr, xx, yy)	/* inset a rectangles coordinates */
register TRect FAR *rr;
int xx;
int yy;
{
	rr->top += yy;
	rr->bottom -= yy;
	rr->left += xx;
	rr->right -= xx;
}

/* ******************************************************************* */

TUTORpoint_in_rect(pt, r)	/* determine if point in specified rectangle */
TPoint pt;			/* x/y co-ordinates to check */
TRect *r;			/* rectangle to check within */

{
	if ((pt.hh < r->left) || (pt.vv < r->top))
		return (FALSE);
	if ((pt.hh > r->right) || (pt.vv > r->bottom))
		return (FALSE);
	return (TRUE);

}				/* TUTORpoint_in_rect */

/* *********     line  based  routines     ************ */

TUTORabs_move_to(x, y)		/* set current screen location */
int x, y;

{
	/* screen position doesn't seem to be tracking -- arrow gets extra
	 * line */
	/* if ((RealX == x) && (RealY == y)) return;  */

	RealX = x;
	RealY = y;
	if (!isx11)
		wm_MoveTo(RealX, RealY);

#ifdef DOPSCRIPT
	if (pscript)
	{
		sprintf(PSbuff, "newpath %d %d moveto ", x - OffsetX, y - OffsetY);
		PostScriptOutput(PSbuff);
	}
#endif

}				/* TUTORabs_move_to */

/* ******************************************************************* */

TUTORabs_move(x, y)		/* move x/y co-ordinate by specified amount */
int x, y;

{
	TUTORabs_move_to(RealX + x, RealY + y);

}				/* TUTORabs_move */

/* ******************************************************** */

TUTORabs_draw_dot(x1, y1)	/* make a dot */
int x1, y1;

{
	register int ix1, iy1;

	if (lineThick) {
		TUTORabs_move_to(x1,y1);
		TUTORabs_line_to(x1,y1);
		return;
	}
	
	if (isx11)
	{
		XDrawPoint(display, drawwindow, gc,
			   RealX = x1, (RealY = y1) + pd_barheight);
	} else
	{
		wm_MoveTo(x1, y1);
		wm_DrawTo(RealX = x1, RealY = y1);
	}

#ifdef DOPSCRIPT
	if (pscript)
	{
		sprintf(PSbuff, "%d %d Dot \n", ix1, iy1);
		PostScriptOutput(PSbuff);
	}
#endif

}				/* TUTORabs_draw_dot */

/* ******************************************************************* */

TUTORabs_line_to(x, y)		/* draw line from current screen location */
int x, y;

{	int dxy,axy; 
	int x1,y1,x2,y2;
	long fx[8],fy[8]; /* points for thick-line polygon */

	if (lineThick) {
		dxy = lineThick-1;
		axy = lineThick >> 1;
		if (RealX < x) {
			x1 = RealX-axy;		y1 = RealY-axy;
			x2 = x-axy;			y2 = y-axy;
		} else {
			x1 = x-axy;			y1 = y-axy;
			x2 = RealX-axy;		y2 = RealY-axy;
		}
		if (y1 > y2) {
			fx[1] = x1;		fy[1] = y1;
			fx[2] = x1;		fy[2] = y1+dxy;
			fx[3] = x1+dxy;	fy[3] = y1+dxy;
			fx[4] = x2+dxy;	fy[4] = y2+dxy;
			fx[5] = x2+dxy;	fy[5] = y2;
			fx[6] = x2;		fy[6] = y2;
			fx[7] = x1;		fy[7] = y1;
		} else {
			fx[1] = x1;		fy[1] = y1;
			fx[2] = x1;		fy[2] = y1+dxy;
			fx[3] = x2;		fy[3] = y2+dxy;
			fx[4] = x2+dxy;	fy[4] = y2+dxy;
			fx[5] = x2+dxy;	fy[5] = y2;
			fx[6] = x1+dxy;	fy[6] = y1;
			fx[7] = x1;		fy[7] = y1;
		}
		TUTORabs_fill_polygon(7,fx,fy);
		RealX = x;
		RealY = y;
		return;
	} /* lineThick */
	
	if (isx11)
	{
		XDrawLine(display, drawwindow, gc,
			  RealX, RealY + pd_barheight, x, y + pd_barheight);
		if (CurrentMode == SRC_XOR)
			XDrawLine(display, drawwindow, gc,
				  x, y + pd_barheight, x, y + pd_barheight);
		RealX = x;
		RealY = y;
	} else
	{
		wm_DrawTo(RealX = x, RealY = y);
		if (CurrentMode == SRC_XOR)
			wm_DrawTo(x, y);
	}			/* x11 else */

#ifdef DOPSCRIPT
	if (pscript)
	{
		sprintf(PSbuff, " %d %d lineto", x - OffsetX, y - OffsetY);
		PostScriptOutput(PSbuff);
	}
#endif

}				/* TUTORabs_line_to */

/* ******************************************************************* */

TUTORframe_abs_rect(tr)
register TRect FAR *tr;
{
	int temp1, temp2;

	TUTORinq_abs_pen_pos(&temp1, &temp2);	/* frame operation shouldn't */
						/* move pen */
	TUTORabs_move_to(tr->left, tr->top);
	TUTORabs_line_to(tr->left, tr->bottom);
	TUTORabs_line_to(tr->right, tr->bottom);
	TUTORabs_line_to(tr->right, tr->top);
	TUTORabs_line_to(tr->left, tr->top);

	TUTORabs_move_to(temp1, temp2);
}

/* ******************************************************************* */

TUTORdraw_abs_solid_rect(tr, color)
/* fill rectangle with specified color */
TRect FAR *tr;
int color;

/* Historical -- here PAT_BLACK really means foreground, PAT_WHITE really
 * means background, and PAT_BACKGROUND means background */

{	int setfcolor, setbcolor;
	int x1, y1, x2, y2;

	x1 = tr->left;
	y1 = tr->top;
	x2 = tr->right;
	y2 = tr->bottom;

	/* if color is unknown (e.g. -1), determine color based on current
	 * mode */
	/* NOT_SRC_COPY is mode inverse */
	if (color != PAT_BLACK && color != PAT_WHITE)
		color = (CurrentMode == NOT_SRC_COPY) ? PAT_BLACK : PAT_WHITE;

	switch (color) {
	case PAT_BLACK:
		setfcolor = GetX11PixelValue(fgndColor.palette);
		if (isx11) {
			gcv.foreground = setfcolor;
			XChangeGC(display, gc, GCForeground, &gcv);
		} else
			wm_SetFunction(setfcolor);
		break;
	case PAT_WHITE:
		setbcolor = GetX11PixelValue(bgndColor.palette);
		if (isx11) {
			gcv.foreground = setbcolor;
			XChangeGC(display, gc, GCForeground, &gcv);
		} else
			wm_SetFunction(setbcolor);
		break;
	} /* switch */

	if (isx11) {
		XFillRectangle(display, drawwindow, gc,
			   x1, y1 + pd_barheight, x2 - x1 + 1, y2 - y1 + 1);
	} else
		wm_RasterSmash(x1, y1, x2 - x1 + 1, y2 - y1 + 1);
	TUTORset_comb_rule(CurrentMode);	/* restore mode */

} /* TUTORdraw_abs_solid_rect */

/* ******************************************************************* */

TUTORabs_erase_rect(tr, pattInd, pattC)
TRect *tr;
int pattInd; /* index of fill pattern in font table */
int pattC; /* pattern character # */

{	int savemode;

	savemode = CurrentMode;
	TUTORset_comb_rule(SRC_BIC);
	TUTORfill_abs_rect(tr, pattInd, pattC);
	CurrentMode = savemode;
	TUTORset_comb_rule(CurrentMode);	/* restore mode */

} /* TUTORabs_erase_rect */

/* ******************************************************************* */

extern int dma_debug;

TUTORfill_abs_rect(tr, pattInd, pattC)
TRect *tr;			/* rect we want filled */
int pattInd;			/* index of fill pattern in font table */
int pattC;			/* pattern character # */
{
	short savepatfont, savepatchar;
	int sm;
	int dx1;
	int x1, y1, x2, y2;	/* ordered screen coords */

	x1 = tr->left;
	y1 = tr->top;
	x2 = tr->right;
	y2 = tr->bottom;
	if (x1 > x2 || y1 > y2)
	{
		return;		/* incorrectly ordered coords (kills X11) */
	}
	if (isx11)
	{
		if (pattInd == patternFont && pattC == patternChar)
		{
			FillModeOn();
			XFillRectangle(display, drawwindow, gc,
			   x1, y1 + pd_barheight, x2 - x1 + 1, y2 - y1 + 1);
		} else
		{
			savepatfont = patternFont;
			savepatchar = patternChar;
			patternFont = pattInd;
			patternChar = pattC;
			SetXFill();
			FillModeOn();
			XFillRectangle(display, drawwindow, gc,
			   x1, y1 + pd_barheight, x2 - x1 + 1, y2 - y1 + 1);
			patternFont = savepatfont;
			patternChar = savepatchar;
			SetXFill();
		}
		FillModeOff();
	} else
	{
		dx1 = x2 - x1 + 1;
		sm = CurrentMode;
		if (sm == SRC_COPY)
		{		/* erase, then write black */
			TUTORset_comb_rule(SRC_BIC);
			wm_FillTrapezoid(x1, y1, dx1, x1, y2, dx1, wxcp(TUTORinq_font_ptr(patternFont0)), patternChar0);
		}
		 /* mode if */ 
		else if (sm == NOT_SRC_COPY)
		{		/* fill black, then write white */
			TUTORset_comb_rule(SRC_OR);
			wm_FillTrapezoid(x1, y1, dx1, x1, y2, dx1, wxcp(TUTORinq_font_ptr(patternFont0)), patternChar0);
		}		/* else if mode */
		TUTORset_comb_rule(sm);	/* restore mode */
		wm_FillTrapezoid(x1, y1, dx1, x1, y2, dx1,
		   (struct font *) wxcp(TUTORinq_font_ptr(pattInd)), pattC);
	}			/* x11 else */

}				/* TUTORfill_abs_rect */

/* ******************************************************************* */

TUTORinvert_abs_rect(x1, y1, x2, y2)	/* invert specified rectangle */
int x1, y1, x2, y2;

{
	int savemode;

	if (x1 > x2 || y1 > y2)
		return;		/* nothing to invert */
	savemode = CurrentMode;
	TUTORset_comb_rule(SRC_XOR);
	if (isx11)
	{
		XFillRectangle(display, drawwindow, gc,
			   x1, y1 + pd_barheight, x2 - x1 + 1, y2 - y1 + 1);
	} else
	{
		wm_RasterSmash(x1, y1, (x2 - x1) + 1, (y2 - y1) + 1);
	}
	TUTORset_comb_rule(savemode);	/* restore mode */

}				/* TUTORinvert_abs_rect */

/* ******************************************************************* */

TUTORhilite(x1, y1, x2, y2)	/* hilite text (usually an inversion) */
int x1, y1, x2, y2;		/* coords to hilite */
{
	TUTORinvert_abs_rect(x1, y1, x2, y2);
}

/* ******************************************************************* */

TUTORmove_abs_rect(x1, y1, x2, y2, newx, newy)	/* move rectangle to new
						 * position */
int x1, y1, x2, y2;		/* rectangle to move */
int newx, newy;			/* new position */

{
	int w, h;		/* rectangle size */

	if (newy < 0) { /* adjust if move off-screen */
		y1 = y1 - newy;
		newy = 0;
	} /* newy if */
	w = x2 - x1 + 1;	/* set size of rectangle */
	h = y2 - y1 + 1;
	if (isx11) {
		gcv.function = GXcopy;
		XChangeGC(display, gc, GCFunction, &gcv);
		XCopyArea(display, drawwindow, drawwindow, gc,
		    x1, y1 + pd_barheight, w, h, newx, newy + pd_barheight);
	} else {
		;
#ifdef WM
		wm_SetFunction(f_copy);
		wm_RasterOp(x1, y1, newx, newy, w, h);
#endif
	}
	TUTORset_comb_rule(CurrentMode);

} /* TUTORmove_abs_rect */


/* ******************************************************************* */

TUTORoptimize_rect()

{
	return; /* dummy routine on WM/X11 */

} /* TUTORoptimize_rect */

/* ******************************************************************* */

TUTORset_abs_clip_rect(cr)	/* set clip region */
TRect FAR *cr;
{	XRectangle rectangle;
	int x1, y1, x2, y2;		/* corners of clip region */

	x1 = cr->left;
	x2 = cr->right;
	y1 = cr->top;
	y2 = cr->bottom;
	
	/* keep upper left of clip inside window */
	if (x1 < 0)
		x1 = 0;
	if (isx11 && y1 < -pd_barheight)
		y1 = -pd_barheight;
	else if (!isx11 && y1 < 0)
		y1 = 0;

	if ((tgclipx == x1) && (tgclipy == y1) && (tgclipw == (x2 - x1 + 1)) &&
	    (tgcliph == (y2 - y1 + 1)))
		return;
 
	tgclipx = tgclipR.left = x1;
	tgclipy = tgclipR.top = y1;
	tgclipR.right = x2;
	tgclipR.bottom = y2;
	tgclipw = (x2 - x1) + 1;
	tgcliph = (y2 - y1) + 1;
	if (isx11) {
		rectangle.x = 0;
		rectangle.y = 0;
		if ((tgclipw < 0) || (tgcliph < 0))
			tgclipw = tgcliph = 0;
		/* make sure clip rectangle is within window boundaries */
		if (tgclipw > wmg_xs[currentXwindow]) {
			tgclipw = wmg_xs[currentXwindow];
		}
		if (tgcliph > wmg_ys[currentXwindow]+pd_barheight) {
			tgcliph = wmg_ys[currentXwindow]+pd_barheight;
		}
		rectangle.width = tgclipw;
		rectangle.height = tgcliph;

		XSetClipRectangles(display, gc,
				   tgclipx, tgclipy + pd_barheight,
				   &rectangle, 1, YSorted);
	} else
		wm_SetClipRectangle(x1, y1, tgclipw, tgcliph);

} /* TUTORset_abs_clip_rectangle */

/* ******************************************************* */

TUTORclear_screen() 
/* full screen erase (clipped) to background color */

{	int setwcolor;

	setwcolor = GetX11PixelValue(winColor.palette);

	if (isx11) {
		gcv.foreground = setwcolor;
		XChangeGC(display, gc, GCForeground, &gcv);
	} else
		wm_SetFunction(setwcolor);

	if (isx11) {
		XFillRectangle(display, drawwindow, gc,
			       0, pd_barheight, 10000, 10000);
	} else
		wm_RasterSmash(0, 0, 10000, 10000);
	TUTORset_comb_rule(CurrentMode);	/* restore mode */

#ifdef DOPSCRIPT
	if (pscript) {
		sprintf(PSbuff, "\nerasepage\n");
		PostScriptOutput(PSbuff);
	}
#endif

} /* TUTORclear_screen */

/* ********************************************************* */

FillModeOn()			/* x11 setup for filling areas */
{

	/* If default fill, fillstyle is FillSolid */
	if (patternFont == patternFont0 &&
	    patternChar == patternChar0)
	{	
		XSetFillStyle(display, gc, FillSolid);
		return;
	}
	switch (CurrentMode)
	{
	case SRC_COPY:		/* mode rewrite */
	case NOT_SRC_COPY:	/* mode inverse */
		XSetFillStyle(display, gc, FillOpaqueStippled);
		break;
	case SRC_OR:		/* mode write */
	case SRC_XOR:		/* mode xor */
	case SRC_BIC:		/* mode erase */
		XSetFillStyle(display, gc, FillStippled);
		break;
	}			/* switch */
}

/* ********************************************************** */

FillModeOff()

{
	XSetFillStyle(display, gc, FillSolid);
}

/* ******************************************************************* */

TUTORset_comb_rule(rule)	/* set display mode (write, erase etc.) */
int rule;

{	unsigned long setfcolor; /* foreground color */
	unsigned long setbcolor; /* background color */
	unsigned int redC,greenC,blueC;
	int paletteF; /* TRUE if color is index in palette */
 
	if (rule == -1)
		rule = SRC_OR; /* mode write if unset */
		
	paletteF = TRUE; /* assume palette-based color */
	if (colorsAvail <= 2) {
		setfcolor = (fgndColor.palette == color_white) ?
			whiteX.pixel : blackX.pixel;
		setbcolor = (bgndColor.palette == color_white) ?
			whiteX.pixel : blackX.pixel;
	} else {
		setfcolor = GetX11PixelValue(fgndColor.palette);
		setbcolor = GetX11PixelValue(bgndColor.palette);
		if (fgndColor.palette == color_rgb) {
			setfcolor = fgndColor.value;
		}
		if (bgndColor.palette == color_rgb) {
			setbcolor = bgndColor.value;
		}
	}
	
	if (isx11) {
		gcv.function = GXcopy;
		gcv.fill_style = FillSolid;
		gcv.foreground = setfcolor;
		gcv.background = setbcolor;
	}
	switch (rule) {
	case SRC_COPY:		/* mode rewrite */
	case SRC_OR:		/* mode write */
		if (!isx11)
			wm_SetFunction(setfcolor);
		break;
	case SRC_XOR:		/* mode xor */
		if (isx11) {
			gcv.function = GXxor;
			gcv.foreground = setfcolor ^ setbcolor;
		} else {
			;
#ifdef WM
			wm_SetFunction(f_invert);
#endif
		}
		break;
	case SRC_BIC:		/* mode erase */
	case NOT_SRC_COPY:	/* mode inverse */
		if (isx11) {
			gcv.foreground = setbcolor;
			gcv.background = setfcolor;
		} else {
			;
#ifdef WM
			wm_SetFunction(setbcolor);
#endif
		}
		break;
	default:
		TUTORtrace_n("unrecognized mode", (long) rule);
		TUTORdump("bad rule in TUTORset_comb_rule");
		return;
	} /* switch */

	if (isx11) {
		XChangeGC(display, gc, GCFunction | GCFillStyle |
			  GCForeground | GCBackground, &gcv);
	}
	CurrentMode = rule;
	return;

} /* TUTORset_comb_rule */

/* ********************************************************** */

#ifdef ibm032
TUTORbeep(ff, dur, volume, nbeep)	/* create sound for a batch of beeps */
int *ff;			/* frequency (in cycles/second) */
int *dur;			/* length of sound, in milliseconds */
int *volume;			/* % of max machine volume (0-100) */
int nbeep;			/* number of beeps in this batch */
{
	int ii;
	int frq, dr, vl;

	if (speakerfd < 0)
	{			/* open speaker device */
		speakerfd = open("/dev/speaker", 1);

		/* NOTE:  When do we close the speaker???!!! */

		if (speakerfd < 0)
			return;	/* couldn't open */
	}
	if (!nbeep)
	{			/* blank tag beep, do something defaultish */
		frq = 880;
		dr = 200;
		vl = 50;
		TUTORbeep_one(frq, dr, vl);
		return;
	} else
	{
		for (ii = 0; ii < nbeep; ii++)
			TUTORbeep_one(ff[ii], dur[ii], volume[ii]);
	}
	return;
}

/* ********************************************************** */

static TUTORbeep_one(ff, dur, volume)
int ff, dur, volume;
{
	struct spk_blk note;
	unsigned char freqhigh, freqlow;
	long durTemp;		/* for properly calculating the duration */

	ConvertFreq(ff, &freqhigh, &freqlow);

	/* RT has only 3 volume settings... */
	if (volume < 0)
		volume = 0;
	if (volume > 100)
		volume = 100;
	note.volume = (volume + 32) / 33;
	note.freqhigh = freqhigh;
	note.freqlow = freqlow;
	durTemp = (dur * 16) / 125;	/* ibm duration is in 1/128 of
					 * seconds */
	note.duration = durTemp;

	write(speakerfd, (char *) &note, sizeof(note));

	return;
}

/* ********************************************************** */

static 
ConvertFreq(freq, freqhigh, freqlow)	/* convert frequency to parameters
					 * for RT speaker */
int freq;
unsigned char *freqhigh, *freqlow;
{

	if (freq < 23)
	{
		*freqhigh = 0;
		*freqlow = SPKOLOMIN;
	} else if (freq < 46)
	{
		*freqhigh = 64;
		*freqlow = (char) ((6000.0 / (float) freq) - 9.31);
	} else if (freq < 91)
	{
		*freqhigh = 32;
		*freqlow = (char) ((12000.0 / (float) freq) - 9.37);
	} else if (freq < 182)
	{
		*freqhigh = 16;
		*freqlow = (char) ((24000.0 / (float) freq) - 9.48);
	} else if (freq < 363)
	{
		*freqhigh = 8;
		*freqlow = (char) ((48000.0 / (float) freq) - 9.71);
	} else if (freq < 725)
	{
		*freqhigh = 4;
		*freqlow = (char) ((96000.0 / (float) freq) - 10.18);
	} else if (freq < 1433)
	{
		*freqhigh = 2;
		*freqlow = (char) ((192000.0 / (float) freq) - 11.10);
	} else if (freq < 12020)
	{
		*freqhigh = 1;
		*freqlow = (char) ((384000.0 / (float) freq) - 12.95);
	} else
	{
		*freqhigh = 0;
		*freqlow = SPKOLOMIN;
	}
}

#else
#ifdef sunV3
/* ********************************************************** */

TUTORbeep(ff, dur, volume, nbeep)	/* create sound for a batch of beeps
					 * (sun version) */
int *ff;			/* frequency (in cycles/second) */
int *dur;			/* length of sound, in milliseconds */
int *volume;			/* % of max machine volume (0-100) */
int nbeep;			/* number of beeps in this batch */
{
	int dev, ii;

	dev = open("/dev/kbd", O_RDWR, 0);	/* open "file" to keyboard */
	if (dev >= 0)
	{			/* we can talk to keyboard */
		if (nbeep == 0)
		{		/* simple beep */
			Beep_one(880, 200, 100, dev);
		} else
		{		/* play a batch of beeps */
			for (ii = 0; ii < nbeep; ii++)
				Beep_one(ff[ii], dur[ii], volume[ii], dev);
		}
		close(dev);	/* shut down our connection to keyboard */
	}
	return;
}

static 
Beep_one(ff, dur, vol, dev)	/* make one beep - Sun3 */
int ff;
int dur;			/* length in milliseconds */
int vol;
int dev;			/* keyboard device */
{
	int ioSignal;

	/* all the sun can do is make a single tone beep (of variable length) */
	if (ff > 0 && vol > 0)
	{			/* make a sound */
		ioSignal = KBD_CMD_BELL;
		if (ioctl(dev, KIOCCMD, &ioSignal) >= 0)	/* start the bell */
		{
			usleep(dur * 1000);
			ioSignal = KBD_CMD_NOBELL;
			ioctl(dev, KIOCCMD, &ioSignal);	/* end the bell */
		}
	} else
	{			/* silence for awhile */
		usleep(dur * 1000);
	}

	return;
}

#else
/* ********************************************************** */

TUTORbeep(ff, dur, volume, nbeep)	/* create sound for a batch of beeps */
int *ff;			/* frequency (in cycles/second) */
int *dur;			/* length of sound, in milliseconds */
int *volume;			/* % of max machine volume (0-100) */
int nbeep;			/* number of beeps in this batch */

{   char str[2];
	
    str[0] = 7; /* ascii bell */
    str[1] = 0;

#ifdef hp700
	XBell(display,100);
	return(0);
#endif

#ifdef mipszz
    printf(str);
	fflush(stdout);
#endif

#ifdef sparczz
    printf(str);
	fflush(stdout);
#endif

	if (isx11)
		XBell(display,100);

} /* TUTORbeep */

#endif				/* sunV3 */
#endif				/* ibm032 */


#ifdef KSWdecstation
TUTORbeep(ff, dur, volume, nbeep)	/* create sound for a batch of beeps */
int *ff;			/* frequency (in cycles/second) */
int *dur;			/* length of sound, in milliseconds */
int *volume;			/* % of max machine volume (0-100) */
int nbeep;			/* number of beeps in this batch */
{
	int ii;

	if (!nbeep)
		Beep_one(90);
	else
	{
		for (ii = 0; ii < nbeep; ii++)
			Beep_one(*volume++);
	}

	return (0);
}

static 
Beep_one(vol)
int vol;			/* desired volume (0-100) */
{
	struct qv_kpcmd ioc;

	if (vol == 0)
		return (0);	/* silence */

	/* enable bell & set volume */
	ioc.nbytes = 1;
	ioc.cmd = LK_BELL_ENABLE;
	/* bell volume: 7 - loud, 0 - quiet */
	ioc.par[0] = vol / 12;
	if (ioctl(DisplayFD, QIOCKPCMD, (char *) &ioc) < 0)
		return;

	ioc.nbytes = 0;
	ioc.cmd = LK_RING_BELL;
	ioctl(DisplayFD, QIOCKPCMD, (char *) &ioc);

	return (0);
}

#endif


/* ************************************************** */
TUTORstop_sound()
{				/* attempt to stop queued sound */
	;			/* not possible on any workstation */
}

/* *************   questions  about  size   ************* */

TUTORinq_abs_screen_size(x, y, dx, dy)
/* return location of upper-left corner of screen, width, height */
/* in author mode, x, y are not zero */

int *x, *y, *dx, *dy;

{
	*x = 0;
	*y = 0;
	*dx = windowsP[CurrentWindow].wxsize;
	*dy = windowsP[CurrentWindow].wysize;
}

/* *********************************************************** */

TUTORinq_abs_pen_pos(x, y)	/* return current screen location */
int *x, *y;

{
	*x = RealX;
	*y = RealY;

}				/* TUTORinq_abs_pen_pos */

/* ************ machine dependent menu routines ************* */

TUTORstart_menubar(barh)
Memh barh;

{
	TutorMenuBar FAR *bar;

	bar = (TutorMenuBar FAR *) GetPtr(barh);
	bar->theBar = 0;	/* this bar isn't showing yet */
	ReleasePtr(barh);
	KillPtr(bar);

}				/* TUTORstart_menubar */

/*************** font routines *********************** */

TUTORis_symbolic(ss)
char *ss;			/* possible symbolic name */

/* returns TRUE if it is symbolic */
{
	int sLen;
	char cc, *cp;
	int ret, nFonts;
	char **fontList;

	sLen = strlen(ss);

	/* temporarily get rid of trailing digits and other stuff */
	cp = ss;
	while (*cp && !CTisdigit(*cp))
		cp++;
	cc = *cp;
	*cp = '\0';

	/* we should compare against system font list, but for now just
	 * compare against z* */
	ret = FALSE;

	if (*ss == 'z')
	{			/* could be a cT zwhatsit */
		if (!strcmp(ss, "zsans"))
			ret = TRUE;
		else if (!strcmp(ss, "zserif"))
			ret = TRUE;
		else if (!strcmp(ss, "zfixed"))
			ret = TRUE;
		else if (!strcmp(ss, "zsymbol"))
			ret = TRUE;
		else if (!strcmp(ss, "zicons"))
			ret = TRUE;
		else if (!strcmp(ss, "zpatterns"))
			ret = TRUE;
		else if (!strcmp(ss, "zcursors"))
			ret = TRUE;
	}
	if (!ret)
		{ /* check for old wm symbolic names */
		if (!strcmp(ss, "andy"))
			ret = TRUE;
		else if (!strcmp(ss, "andysans"))
			ret = TRUE;
		else if (!strcmp(ss, "andysymbol"))
			ret = TRUE;
		else if (!strcmp(ss, "andytype"))
			ret = TRUE;
		else if (!strcmp(ss, "shape"))
			ret = TRUE;
		}
	if (!ret && isx11)
	{			/* check for x11 symbolic names */
		fontList = XListFonts(display, ss, 2, &nFonts);
		if (nFonts > 0)
			ret = TRUE;	/* this is a known name */
		XFreeFontNames(fontList);
	} else if (!ret && !isx11)
	{			/* check for wm symbolic names */
		if (!strcmp(ss, "courier"))
			ret = TRUE;
		else if (!strcmp(ss, "hel"))
			ret = TRUE;
		else if (!strcmp(ss, "helvetica"))
			ret = TRUE;
		else if (!strcmp(ss, "tim"))
			ret = TRUE;
		else if (!strcmp(ss, "times"))
			ret = TRUE;
		else if (!strcmp(ss, "sym"))
			ret = TRUE;
	}
	*cp = cc;		/* restore the font string */
	return (ret);
}

long TUTORparse_font_family(fontTag, familyName, isFont, oneTag, fontSize)
FileRef *fontTag;		/* either full path, or a system reference */
				
FileRef *familyName;		/* to be set to the font's family name
				 * (possibly including full path) */
int isFont;			/* TRUE if this is from a -font- command
				 * (unused) */
int oneTag;			/* TRUE if this is from a one-tag font type
				 * command */
int *fontSize;			/* if exists, set to font size derived from
				 * fontTag */

/* returns font family id */
{
	char *cp;
	int ii;
	int fSize;
	FileRef tempRef;
	long famId;
	int isSys, isSymbolic;

	fSize = -1;
	isSymbolic = fontTag->path[0] != '/';

	if (oneTag)
	{
		/* get rid of possible .fwm extension */
		ii = strlen(fontTag->path) - 1;	/* index to last char */
		if (strcmp(&fontTag->path[ii - 3], ".fwm") == 0)
		{
			ii -= 4;
			fontTag->path[ii + 1] = '\0';
		}
		/* get rid of (and parse) trailing size */
		while (ii > 1 && CTisdigit(fontTag->path[ii]))
			ii--;
		if (fontTag->path[ii + 1])
		{		/* if we backed up at all */
			sscanf(fontTag->path + ii + 1, "%d", &fSize);
			if (isSymbolic)
				fontTag->path[ii + 1] = '\0';
		}
	}
	
	
	if (strcmp(fontTag->path, "andysans") == 0)
		cp = "zsans";
	else if (strcmp(fontTag->path, "andy") == 0)
		cp = "zserif";
	else if (strcmp(fontTag->path, "andytype") == 0)
		cp = "zfixed";
	else if (strcmp(fontTag->path, "andysymbol") == 0)
		cp = "zsymbol";
	else if (strcmp(fontTag->path, "shape") == 0)
		cp = "zpatterns";
	else if (isx11)
	{			/* x11 zname conversions */
		if (strcmp(fontTag->path, "helv") == 0)
			cp = "zsans";
		else if (strcmp(fontTag->path, "time") == 0)
			cp = "zserif";
		else if (strcmp(fontTag->path, "cour") == 0)
			cp = "zfixed";
		else if (strcmp(fontTag->path, "symb") == 0)
			cp = "zsymbol";
		else
			cp = NEARNULL;
	} else /* end of isx11 */
			cp = NEARNULL;
	
	if (cp)  /* found symbolic name */
		TUTORsymbolic_fileref((FileRef FAR *) familyName,(char FAR *) cp);
	else /* not symbolic, just copy fontTag */
		TUTORcopy_fileref((FileRef FAR *) familyName, (FileRef FAR *) fontTag);

	if (fontSize)
		*fontSize = fSize;
	famId = TUTORinq_ffamily_id(familyName,FALSE);	/* look for already
							 * existing family */

	if (famId < 0)
	{			/* this is a new family */
		isSys = TRUE;
		if (isSymbolic)
		{	/* system reference */
			TUTORcopy_fileref((FileRef FAR *) & tempRef, (FileRef FAR *) sourceDirP);
			TUTORcopy_fileref_name((FileRef FAR *) & tempRef, familyName->path);
			if (TUTORfile_exists((FileRef FAR *) & tempRef))
			{	/* in sourceDir */
				TUTORcopy_fileref((FileRef FAR *) familyName, &tempRef);
				isSys = FALSE;
			} else
				isSys = TRUE;	/* must be reference to
						 * system font */
		}
		famId = TUTORadd_ffamily(familyName, isSys, TRUE);
	}
	return (famId);
}

TUTORset_textfont(ii)		/* set to known font by index in font table */
int ii;

{
	struct tutorfont FAR *fp;

	if (ii < 0)
		ii  = textFont0;
		
#ifdef KSWfastfont
	if (ii == textFont)
		return;		/* font already set */
#endif

	fp = ii + (struct tutorfont FAR *) GetPtr(fontsH);
	wmFont = fp->ptr;

	textFontFamily = fp->fID;
	textFontSize = fp->size;
	textFontFace = fp->textface;
	ReleasePtr(fontsH);
	KillPtr(fp);

	if (wmFont && (CurrentWindow >= 0))
	{			/* cant do this if no font yet */
		if (isx11)
		{
			gcv.font = ((XFontStruct *) wxcp(wmFont))->fid;
			XChangeGC(display, gc, GCFont, &gcv);
		} else
			wm_SelectFont((struct font *) wxcp(wmFont));
	}			/* wmFont if */
	textFont = ii;

	return;

}				/* TUTORset_textfont */

TUTORset_textfont2(family, size, face)	/* set to possibly unknown font by
					 * characteristics */
long family;			/* id, not index */
int size;			/* system size */
int face;			/* face code */
{
#ifdef KSWfastfont
	if (family != textFontFamily || size != textFontSize || face != textFontFace)
#endif
		TUTORset_textfont(TUTORget_font2(family, size, face,111));	/* set to new font */
	return;
}


/* ******************************************************************* */

int TUTORfont_ptr(fInd,size,face,cid) /* get font pointer for item */
/* returns index of font in font table */
int fInd; /* index of family in family table */
int size; /* system size */
unsigned int face; /* size & face of desired font */
int cid; /* caller id */

{	int fi; /* font index */

	if (isx11) fi = TUTORfont_ptr_x11(fInd,size,face);
	else fi = TUTORfont_ptr_wm(fInd,size,face);
	return(fi); /* return font index */
	
} /* TUTORfont_ptr */

/* ******************************************************************* */

int TUTORfont_ptr_x11(fInd, size, face) /* get font pointer for item */
/* returns index of font in font table */
int fInd; /* index of family in family table */
int size; /* system size */
unsigned int face; /* size & face of desired font */

/* returns index of new font entry */

{	char fullName[CTPATHLEN];
	char wkname[CTPATHLEN];
	char tempS[8];
	FileRef *envp; /* pointer to getenv string */
	struct tutorfont FAR *theF;
	struct ctx11font *ctfontptr; /* ptr to wm/x11/ct-pc font descriptor */
	XFontStruct *xfp; /* pointer to X11 font description */
	Memh ctfontH; /* handle on ct-format font */
	int ii, fi;
	FontFamily FAR *ffp;
	char *famN; /* on pc would have to be FAR * */
	FileRef fontPath;
	int	stranger; /* if unrecognized font */
	long nchars; /* number characters in font */
	struct pcfont816 *ctfontP; /* pointer to ct internal format font */

	if (fInd < 0)
		TUTORdump("bad family to TUTORfont_ptr_x11");
	ffp = fInd + (FontFamily FAR *) GetPtr(fontFamilies);

	/* construct full font name */

	stranger = FALSE; /* assume normal X11 font */
	envp = (FileRef FAR *) ctDirP;
	famN = ffp->familyRef.path;
	if (*famN == '/') { /* full path, not a symbolic name */
		strcpy(fullName,famN); /* use file name */
	} else if (strcmp(famN, "zicons") == 0) {
		strcpy(fullName, "zicons12");
	} else if (strcmp(famN, "zcursors") == 0) {
		strcpy(fullName, "zcursors10");
	} else if (strcmp(famN, "zpatterns") == 0) {
#ifdef SYSVzzzz /* ancient, Interactive v3.2 */
#ifndef hp700
		strcpy(fullName, "zpatterns");
#else
		strcpy(fullName,"zpatterns10");
#endif
#else
		strcpy(fullName, "zpatterns10");
#endif		
	} else if (size >= 0) { 
	
	    /* normal x11 font */
		
		/* See /usr/lib/X11/fonts/75dpi/fonts.dir: medium or */
		/* bold r for non-italic, or symbol italic is i */
		/* except o (oblique) for courier and helvetica */

		if (!strcmp(famN, "zsans"))
			strcpy(fullName, "-*-helvetica-");
		else if (!strcmp(famN, "zfixed"))
			strcpy(fullName, "-*-courier-");
		else if (!strcmp(famN, "zsymbol"))
			strcpy(fullName, "-*-symbol-");
		else if (!strcmp(famN, "zserif"))
			strcpy(fullName, "-*-times-");
		else {	
			stranger = TRUE;
			strcpy(fullName,famN);
		}
		if (!stranger) {
			if ((face & style_bold) && strncmp(famN, "zsymb", 5))
				strcat(fullName, "bold-");
			else
				strcat(fullName, "medium-");

			if (face & style_italic) {
				if (!strcmp(famN, "zsans") || !strcmp(famN, "zfixed"))
					strcat(fullName, "o-");
				else if (!strcmp(famN, "symb"))
					strcat(fullName, "r-");
				else
					strcat(fullName, "i-");
			} else
				strcat(fullName, "r-");	/* normal face */
				
			strcat(fullName, "normal--*-");
				sprintf(tempS, "%d", 10 * size);
			strcat(fullName, tempS);
			strcat(fullName, "-*-*-*-*-*-*");	
		} /* stranger if */
	} else {
		strcpy(fullName,famN); /* assume proper font name */
	} /* size else */

	/* at this point fullName has proper string for fetching font */

	/* get a font table entry */
	theF = (struct tutorfont FAR *) GetPtr(fontsH);
	for (fi = 0; (fi < nfonts && theF->fID >= 0); fi++, theF++); /* scan for unused entry */
	if (fi >= nfonts) {
		/* need to make font table bigger */
		ReleasePtr(fontsH);
		KillPtr(theF);
		extend_font_table(4);
		theF = fi + (struct tutorfont FAR *) GetPtr(fontsH);
	}
	
	/* initialize font header, get font pointer */
	
	ctfontptr = (struct ctx11font *)
		TUTORalloc((long) sizeof(struct ctx11font), TRUE, "ctx11font");
	ctfontptr->mapcache = (long *)TUTORalloc((long)sizeof(long)*256L,TRUE,"mapcache");
	ctfontptr->ptr = NULL;
	for (ii = 0; ii < 255; ii++)
		ctfontptr->mapcache[ii] = 0;
	ctfontptr->kind = 1;	/* x11 font */
	
	/* full name has full path to file, or font name */
	/* x11 will not accept path, so try symbolic name first */
	
	if (fullName[0] == '/') {
		ii = strlen(fullName);
		do {
			ii--;
		} while (fullName[ii] != '/');
		strcpyf(wkname,&fullName[ii+1]);
	} else strcpyf(wkname,fullName);
	ctfontptr->ptr = (long) XLoadQueryFont(display,wkname);

	if (ctfontptr->ptr) {
	
		/* check if 16-bit x11 font */
		
		xfp = (XFontStruct FAR *)ctfontptr->ptr; /* pointer to x11 structure */
		if (xfp->max_byte1) {
			ctfontptr->kind = 2; /* 16 bit x11 font */
			theF->codeSize = 1;
		}
	} /* ptr if */

	if (!ctfontptr->ptr) {
	
		/* didn't find x11 font, look for ct format font */

		TUTORcvt_path(fullName,&fontPath,sourceDirP,TRUE);
		ctfontptr->ptr = wmg_load_font((FileRef FAR *) &fontPath,0);
		if (ctfontptr->ptr) {
			ctfontptr->kind = 3; /* ct internal format font */
			ctfontP = (struct pcfont816 *)GetPtr(ctfontptr->ptr);
			if (ctfontP->nchars8 == 0) { /* 16-bit encoding */
				theF->codeSize = 1;
				nchars = ctfontP->nchars16;
				TUTORdealloc(ctfontptr->mapcache); /* dump cache table */
				ctfontptr->mapcache = (long *)TUTORalloc((long)sizeof(long)*nchars,
				                              TRUE,"mapcache");
				for(ii=0; ii<nchars; ii++)
					ctfontptr->mapcache[ii] = 0; /* pre-zero cache table */
			}
			ReleasePtr(ctfontptr->ptr);
		} else {
		
			/* missing font, try to patch up with zserif plain */
		
			ctfontptr->ptr = (long) XLoadQueryFont(display,
				     "-*-times-medium-r-normal--*-140-*-*-*-*-*-*");
			if (!ctfontptr->ptr) {
				TUTORdealloc(ctfontptr); /* drop header if failed */
				ctfontptr = NULL;
			} /* !ctfontptr->ptr if */
		} /* ctfontptr->ptr else */
	} /* !ctfontptr->ptr if */
	theF->ptr = (long) ctfontptr; /* set pointer to font hdr */

	/* decide whether it is alphabetic for use by -plot- and -move- */
	
	if (strncmp(fullName, "andy", 4) == 0)
		theF->alphaIcon = 1;
	else
		theF->alphaIcon = 0;

	/* fill out the rest of the font table entry */
	
	theF->family = fInd;
	theF->fID = ffp->fID;
	theF->textface = face;
	theF->size = size;
	theF->sysFlag = FALSE;

	ReleasePtr(fontFamilies);
	KillPtr(ffp);
	ReleasePtr(fontsH);
	KillPtr(theF);

	return (fi);
	
} /* TUTORfont_ptr_x11 */

/* ******************************************************************* */

int TUTORfont_ptr_wm(fInd, size, face) /* get font pointer for item */
/* returns index of font in font table */
int fInd; /* index of family in family table */
int size; /* system size */
unsigned int face; /* size & face of desired font */

{	char fullName[CTPATHLEN];
	char tempS[8];
	FileRef *envp; /* pointer to getenv string */
	struct tutorfont FAR *theF;
	struct ctx11font *ctfontptr; /* ptr to wm/x11/ct-pc font descriptor */
	int ii, fi;
	FontFamily FAR *ffp;
	char *famN;		/* on pc would have to be FAR * */

	if (fInd < 0)
		TUTORdump("bad family to TUTORfont_ptr");
	ffp = fInd + (FontFamily FAR *) GetPtr(fontFamilies);

	/* construct full font name */

	envp = (FileRef FAR *) ctDirP;
	famN = ffp->familyRef.path;
	if (strcmp(famN, "zicons") == 0) {
		/* look in COMMON directory */
		strcpy(fullName, envp->path);
		strcat(fullName, "zicons12.fwm");
	} else if (strcmp(famN, "zcursors") == 0) {
		/* look in COMMON directory */
		strcpy(fullName, envp->path);
		strcat(fullName, "zcursors10.fwm");
	} else if (strcmp(famN, "zpatterns") == 0) {
		/* look in COMMON directory */
		strcpy(fullName, envp->path);
		strcat(fullName, "zpatterns10.fwm");	
	} else { /* normal font */
		if (!strcmp(famN, "zsans"))
			strcpy(fullName, "andysans");
		else if (!strcmp(famN, "zfixed"))
			strcpy(fullName, "andytype");
		else if (!strcmp(famN, "zsymbol"))
			strcpy(fullName, "andysymbol");
		else if (!strcmp(famN, "zserif"))
			strcpy(fullName, "andy");
		else
			strcpy(fullName, famN);
		if (size >= 0 && fullName[0] != '/') {
			 /* there is a size field in this sybmolic font name */
			sprintf(tempS, "%d", size);
			strcat(fullName, tempS);
		}
		if (face & style_bold)
			strcat(fullName, "b");
		if (face & style_italic)
			strcat(fullName, "i");

		/* if full pathname, want to make sure it ends in  .fwm */
		if (fullName[0] == '/')
			if (strcmp(fullName + strlen(fullName) - 4, ".fwm") != 0)
				strcat(fullName, ".fwm");
	} /* normal font */

	/* at this point fullName has proper string for fetching font */

	/* get a font table entry */
	theF = (struct tutorfont FAR *) GetPtr(fontsH);
	for (fi = 0; (fi < nfonts && theF->fID >= 0); fi++, theF++);	/* scan for unused entry */
	if (fi >= nfonts) {
		/* need to make font table bigger */
		ReleasePtr(fontsH);
		KillPtr(theF);
		extend_font_table(4);
		theF = fi + (struct tutorfont FAR *) GetPtr(fontsH);
	}
	
	/* initialize font header, get font pointer */
	
	ctfontptr = (struct ctx11font *)
		TUTORalloc((long) sizeof(struct ctx11font), TRUE, "ctx11font");
	ctfontptr->mapcache = (long *)TUTORalloc((long)sizeof(long)*256,
	                                          TRUE,"mapcache");
	ctfontptr->ptr = NULL;
	for (ii = 0; ii < 255; ii++)
		ctfontptr->mapcache[ii] = 0;

	ctfontptr->kind = 0;	/* wm font */
	ctfontptr->ptr = (long) wm_DefineFont(fullName);	/* normal case */
	if (!ctfontptr->ptr)
		ctfontptr->ptr = wmFirst;
	else if (!wmFirst)  /* set wmFirst so have a font in case server down */
		wmFirst = ctfontptr->ptr;
	if (!ctfontptr->ptr) {
		TUTORdealloc(ctfontptr);	/* drop header if failed */
		ctfontptr->ptr = NULL;
	}
	theF->ptr = (long) ctfontptr;	/* set pointer to font hdr */

	/* decide whether it is alphabetic for use by -plot- and -move- */
	if (strncmp(fullName, "andy", 4) == 0)
		theF->alphaIcon = 1;
	else
		theF->alphaIcon = 0;

	/* fill out the rest of the font entry */
	theF->family = fInd;
	theF->fID = ffp->fID;
	theF->textface = face;
	theF->size = size;
	theF->sysFlag = FALSE;
	/* TUTORcopy_fileref(&theF->fontfile,???); -- we are only handling
	 * system files right now */

	ReleasePtr(fontFamilies);
	KillPtr(ffp);
	ReleasePtr(fontsH);
	KillPtr(theF);

	return (fi);
	
} /* TUTORfont_ptr_wm */

/* ******************************************************************* */

static int otherID = 2;	/* start at 2 because 1 is "default" font */

long MyFontID(famName, isSys,iso,cTk)
FileRef *famName;		/* either a complete path (file reference),
				 * or reference to system font */
int isSys;			/* TRUE if is a system font */
int *iso;
int *cTk;
{

	*iso = FALSE; 
	*cTk = TRUE;
	return (otherID++);
}
/* ******************************************************************* */

int DummyFontID() /* return an unused font id */

{
	return(otherID++);
	
} /* DummyFontID */

/***********************************************************/

long wxcp(wxci) 
/* return system font ptr for wm/x11/ct font index */
long wxci;

{
	return ((long)(((struct ctx11font *) (wxci))->ptr));

} /* wxcp */

/* ********************************************************** */

int TUTORrelease_font(findx,fam,size,face,forget) /* forget about previously known font */
int findx; /* index in font family table (use fam/size/face if -1) */
long fam; /* font family id (not index) */
int size; /* system size */
unsigned int face; /* face code */
int forget; /* forget this instance of font */

{   REGISTER struct tutorfont FAR *fp;
    int ii;

    fp = (struct tutorfont FAR *) GetPtr(fontsH);
    if (findx >= 0) {
    	fp += findx; /* select table entry */
    } else {
    	/* look up font in table */
    	for (ii=0; ii<nfonts; ii++,fp++) {
        	if (fp->fID == fam && fp->size == size && fp->textface == face) {
        		findx = ii; /* found the font */
        		break;
			} 
		} /* for */
	} /* findx else */
	if (findx >= 0) {
		fp->nusers--; /* decrement users of this font */
		if (forget) {
			if (fp->nusers == 0)
				fp->fID = 0; /* recycle this slot */
			else 
				fp->fID = DummyFontID(); /* invalidate this slot */
		}
	} /* findx if */
    ReleasePtr(fontsH);
   
 	return(0);

} /* TUTORrelease_font */

/***********************************************************/

TUTORmouse_on()
{				/* restore mouse cursor on IBM-PC */
	return;			/* no-op on wm/x-11 */

}

/***********************************************************/

TUTORmouse_off()
{				/* suppress mouse cursor on IBM-PC */
	return;			/* no-op on wm/x-11 */

}

/* ******************************************************************* */

TUTORset_cursor(cInd, cChar)	/* set current cursor */
int cInd, cChar;

{	long fcursor;
	struct ctx11font *fhdr; /* pointer to wm/x11/ct font hdr */
	struct pcfont816 *cfptr; /* pointer to ct format font */
	struct pccharl *cld; /* pointer to large-format char table */
	struct pcchars *csd; /* pointer to small-format char table */
	struct pccharl *clp; /* pointer to large-format character def */
	struct pcchars *csp; /* pointer to small-format character def */
	char *fmap; /* pointer to base of bit-maps for font */
	char *cmap; /* pointer to character bit-map */
	int large; /* TRUE if large-format font */
	long cc; /* character code */
	int mapw,maph; /* width, height of character bitmap */
	int bndw,bndh; /* width, height of character bounding box */
	int hx,hy; /* bias to hot spot */
	Pixmap pixm; /* pixmap id of bitmap */
	char *chp; 

	if (cInd == cursorFont && cChar == cursorChar)
		return; /* already set */

	cursorFont = cInd;
	cursorChar = cChar;
	if ((cChar > 255) || (cChar < 0) || (cInd < 0))
		return; /* ignore reset or x11 16-bit font */
	if (cInd == cursorFont0 && cChar == cursorChar0) {
		TUTORnormal_cursor();
		return;
	}
	fcursor = TUTORinq_font_ptr(cursorFont);
	fhdr = (struct ctx11font *)fcursor;
	if (!isx11)
		wm_SetCursor((struct font *) wxcp(fcursor),cursorChar);
	else {
		switch (fhdr->kind) {

		case 0: /* wm font */
			break;

		case 1: /* x11 font */
			newcursor = XCreateGlyphCursor(display,
			   ((XFontStruct *) wxcp(fcursor))->fid, NULL,
			   cursorChar, NULL,&blackX, &whiteX);
			XDefineCursor(display, drawwindow, newcursor);
			XFreeCursor(display, newcursor);
			break;

		case 2: /* 16-bit x11 font */
			break; /* do nothing for now */
			
		case 3: /* internal ct font */
			cfptr = (struct pcfont816 *)GetPtr(fhdr->ptr);
			large = cfptr->format & 1; 
			chp = (char *)cfptr+cfptr->ddef;
			fmap = (char *)cfptr+cfptr->dmap;
			if (large) 
				cld = (struct pccharl *)chp;
			else 
				csd = (struct pcchars *)chp;
		
			/* get description of this character */
			
			cc = (unsigned int)(cursorChar)-cfptr->first8;
			if ((cc < 0) || (cc > cfptr->nchars8) || (cfptr->format & 4)) {
				set_null_cursor();
				return;
			} /* cc if */
			if (large) {
				clp = &cld[cc]; /* pointer to character definition */
				cmap = clp->map+fmap; /* pointer to bitmap */
				mapw = clp->mapw;
				maph = clp->maph;
				bndw = clp->bnw;
				hx = -clp->bndx;
				hy = -clp->bndy;
			} else {
				csp = &csd[cc]; /* pointer to character definition */
				cmap = csp->map+fmap; /* pointer to bitmap */
				mapw = csp->mapw;
				maph = csp->maph;
				bndw = csp->bnw;
				hx = -csp->bndx;
				hy = -csp->bndy;
			} /* small else */
			if ((bndw == 0) || (mapw == 0)) {
				set_null_cursor();
				return;
			} /* bndw if */	
	
			pixm = fhdr->mapcache[cc];
			if (!pixm) {
 				pixm = XCreateBitmapFromData(display,drawwindow,
				       cmap,mapw,maph);
				fhdr->mapcache[cc] = pixm;
			} /* pixm if */	   

			if (hx < 0) hx = 0;
			if (hx > mapw) hx = mapw;
			if (hy < 0) hy = 0;
			if (hy > maph) hy = maph;
			newcursor = XCreatePixmapCursor(display,pixm,pixm,
		                    &blackX,&whiteX,hx,hy);
			XDefineCursor(display,drawwindow,newcursor);
			XFreeCursor(display,newcursor);
			break;

		default:
			TUTORdump("TUTORset_cursor bad font type");

		} /* switch */
	}

} /* TUTORset_cursor */

/* ******************************************************************* */

static Pixmap nullpix = 0; /* ID of null cursor pixmap */

static set_null_cursor()

{	long data = 0; /* fake bitmap data for null cursor */

	if (nullpix == 0) {
		nullpix = XCreateBitmapFromData(display,drawwindow,
		          (char *)&data,1,1);
	} /* nullpix if */

	newcursor = XCreatePixmapCursor(display,nullpix,None,
		          &whiteX,&blackX,0,0);
	XDefineCursor(display,drawwindow,newcursor);
	XFreeCursor(display,newcursor);

} /* set_null_cursor() */

/* ******************************************************************* */

TUTORarrow_cursor(isTemp)	/* set cursor to arrow for non-execute window */
int isTemp;			/* if TRUE, restore cursor to what it was on
				 * next event loop */

{
	/* wm non-execute windows always have arrow cursor */

	if (isx11)
	{
		XDefineCursor(display, drawwindow, arrowcursor);
	}
}

/* ******************************************************************* */

TUTORdraw_text(buf, count)	/* output text string */
unsigned char FAR *buf;		/* pointer to buffer containing text */
int count;			/* number characters to plot */

{
	register unsigned char FAR *wbuf;	/* pointer to characters */
	register int wcount;	/* number of characters */
	int dx;			/* change in x position */
	int start, tcount;	/* start and count of non-space text in buf */
	int spacewidth;
	int cc;

	/* Note: tutor doc never calls with newlines in text  */

	if (isx11)
	{
		spacewidth = -1;/* flag that we haven't set it */
		start = 0;
		while (TRUE)
		{
			while (start < count && buf[start] == ' ')
			{
				if (spacewidth < 0)	/* need to calculate
							 * width of space
							 * character */
					spacewidth = SpaceShim +
						MyXTextWidth((XFontStruct *) wxcp(wmFont), " ", 1);
				RealX += spacewidth;
				start++;
			}
			tcount = 0;
			while ((start + tcount) < count && buf[start + tcount] != ' ')
				tcount++;
			if (tcount == 0)
				return;	/* we've finished drawing the string */
			XDrawString(display, drawwindow, gc,
			  RealX, RealY + pd_barheight, buf + start, tcount);
			TUTORinq_abs_string_width((unsigned char FAR *) buf + start, tcount, &dx);
			RealX += dx;
			start += tcount;
		}
	}
	 /* end of x11 */ 
	else
	{			/* wm */
		wcount = count;	/* pick up count and pointer */
		wbuf = buf;
		while (wcount)
		{
			cc = *wbuf;
			if (cc > 127)	/* need a conversion */
				cc = ct2wm[cc - 128];
			putc(cc, winout);
			wbuf++;
			wcount--;
		}		/* while */

		TUTORinq_abs_string_width((unsigned char FAR *) buf, count, &dx);
		RealX += dx;
	}

} /* TUTORdraw_text */

/* ************************************************************* */

TUTORtext_flush()
{ /* done drawing text in this piece */ ;
}

/* ******************************************************************* */

TUTORswap_bits_char(ss,nn) /* swap bits within bytes */
unsigned char FAR *ss; /* the bytes */
long nn;	/* # of bytes */
	{
	register unsigned char cidata, codata;
	register unsigned char *p32; /* pointer at current byte */
	int ii;
	register int bi;
	
	p32 = ss;
	for (ii=0; ii<nn; ii++,p32++) {
		cidata = *p32;
		codata = 0;
		for (bi=0; bi < 8; bi++) {
			if (cidata & (1 << bi))
				codata |= 0x80 >> bi;
		} /* bi for */
		*p32 = codata;
	} /* ii for */
	
	return(0);

} /* TUTORswap_bits_char */

/* ******************************************************************* */

TUTORdraw_pcchar(pch, cc)
Memh pch;			/* pc font handle */
int cc;				/* which char to draw */
{
	int xx, yy, rowBytes, row2Bytes;
	char FAR *pp;
	int ii, jj;
	long cacheTemp;
	struct pcfont816 FAR *cfptr;
	XRectangle rectangle;

	if (!isx11)
		{
		TUTORdraw_pcchar_wm(pch,cc);
		return(0);
		}
	
	cfptr = (struct pcfont816 FAR *)GetPtr(pch);
	
	/* at present we send the bits for each char to the server each time we plot the
		character.  We could use cacheTemp to cache the characters, somehow */
	cacheTemp = 0L;
	DrawCTChar(cfptr,0,&cacheTemp,NULL);
	if (cacheTemp)
		XFreePixmap(display,cacheTemp);	/* free the pixmap we created */
	
	ReleasePtr(pch);
	KillPtr(cfptr);
	
	/* clean up */

	rectangle.x = 0;
	rectangle.y = 0;
	rectangle.width = tgclipw;
	rectangle.height = tgcliph;
	XSetClipRectangles(display,gc,tgclipx,tgclipy+pd_barheight,
	                   &rectangle,1,YSorted);
	gcv.function = GXcopy;
	XChangeGC(display,gc,GCFunction,&gcv); 
	TUTORset_comb_rule(CurrentMode);
	return (0);
	}

TUTORdraw_pcchar_wm(pch,cc)
Memh pch;
int cc;
	{
	struct pccharl FAR *cp;
	int xx, yy, rowBytes, row2Bytes;
	char FAR *pp;
	int ii, jj;

	/* create offscreen buffer */
	cp = (struct pccharl FAR *) (GetPtr(pch) + sizeof(struct pcfont816));
	wm_BitsToRegion(37, cp->mapw, cp->maph);

	/* write raster to winout */
	/* this is a little messy because the char is padded to words but wm
	 * expects padding to bytes... */

	rowBytes = 1 + (cp->mapw - 1) / 8;
	row2Bytes = 2 * (1 + (cp->mapw - 1) / 16);
	pp = (char FAR *) cp + sizeof(struct pccharl);
	for (jj = 0; jj < cp->maph; jj++)
	{			/* for every row */
		fwrite(pp, 1, rowBytes, winout);
		pp += row2Bytes;
	}

	/* draw to screen */
	TUTORinq_abs_pen_pos(&xx, &yy);
	wm_RestoreRegion(37, xx+cp->bndx+cp->mapdx, yy +cp->bndy + cp->mapdy);
	TUTORabs_move_to(xx+cp->pdx,yy+cp->pdy);

	/* clean up */
	ReleasePtr(pch);
	KillPtr(cp);
	wm_ForgetRegion(37);

	return (0);
}


/* ************************************************************* */

displayffv(x, y, op, format, value)	/* display formatted floating value */
/* w used for putting labels on graphs */
int x;				/* x co-ordinate */
int y;				/* y co-ordinate */
int op;				/* 0 = top, between left and right */

/* 1 = bottom, between left and right */
/* 2 = left, between top and bottom */
/* 3 = right, between top and bottom */
int format;			/* 1 = G, 2 = E */
double value;			/* floating value to display */

{
	int wmalign;		/* wm alignment option */
	char s[30];
	int slen, ascent, descent, dx;

	sprintf(s, "%G", value);
	if (isx11)
	{
		slen = strlen(s);
		TUTORinq_abs_string_width((unsigned char FAR *) s, slen, &dx);
		ascent = ((XFontStruct *) wxcp(wmFont))->max_bounds.ascent;
		descent = ((XFontStruct *) wxcp(wmFont))->max_bounds.descent;
	}
	switch (op)
	{
	case 0:
		if (isx11)
		{
			x -= (dx >> 1);
			y += ascent;
		} else
			wmalign = wm_BetweenLeftAndRight | wm_AtTop;
		break;
	case 1:
		if (isx11)
		{
			x -= (dx >> 1);
			y -= descent;
		} else
			wmalign = wm_BetweenLeftAndRight | wm_AtBottom;
		break;
	case 2:
		if (isx11)
			y += (ascent >> 1);
		else
			wmalign = wm_AtLeft | wm_BetweenTopAndBottom;
		break;
	case 3:
		if (isx11)
		{
			x -= dx;
			y += (ascent >> 1);
		} else
			wmalign = wm_AtRight | wm_BetweenTopAndBottom;
		break;
	}			/* switch */

	if (isx11)
		XDrawString(display, drawwindow, gc,
			    x, y + pd_barheight, s, slen);
	else
		wm_DrawString(x, y, wmalign, s);

	/* Probably needs to be something to force all labels to be in
	 * exponential format if any of them are, but this here does not give
	 * a pleasing display.  Ignore "format" for now. if( format == 1)
	 * wm_printf(x,y,wmalign,"%G",value); else
	 * wm_printf(x,y,wmalign,"%E",value); */
}

TUTORcvt_ct_chars(cp, clen)
register unsigned char FAR *cp;
long clen;
{
	int retVal;
	register unsigned char FAR *cEnd;

	if (isx11)
		return (FALSE);	/* no conversion neccesary */

	retVal = FALSE;
	cEnd = cp + clen;
	while (cp < cEnd)
	{
		if (*cp & 0x80)
		{		/* need to convert character */
			*cp = ct2wm[*cp - 128];
			retVal = TRUE;
		}
		cp++;
	}
	return (retVal);
}

TUTORcvt_native_chars(cp, clen)
unsigned char FAR *cp;
long clen;
{
	return;			/* unix native chars are all ascii (wm) or
				 * iso 8859 (x11), in either case they are
				 * already in cT character set */
}

TUTORcvt_toascii_chars(cp, clen)/* convert all chars to ascii */
register unsigned char FAR *cp;
long clen;
{
	int retVal;
	register unsigned char FAR *cEnd;

	/* this is almost the same routine as TUTORcvt_ct_chars */

	cEnd = cp + clen;
	while (cp < cEnd)
	{
		if (*cp & 0x80)
		{		/* need to convert character */
			if (*cp < 0xa0)
				*cp = '?';	/* special character */
			else
				*cp = ct2wm[*cp - 128];
		}
		cp++;
	}
	return;
}

/* ************************************************************* */

TUTORnormal_cursor()
{
	if (isx11)
	{
		XDefineCursor(display, drawwindow, arrowcursor);
	} else
		wm_SetStandardCursor('a');
}

/* ************************************************************* */

TUTORwait_cursor()
{
	long cursorfont;

	if (isx11)
	{
		XDefineCursor(display, drawwindow, waitcursor);
	} else
	{
		cursorfont = TUTORinq_font_ptr(cursorFont0);
		wm_SetCursor((struct font *) wxcp(cursorfont), wm_HourglassCursor);
	}
}

/* ************************************************************* */

TUTORresume_cursor()
{				/* restore cursor after a wait */
	/* no!!! what if there was a cursor set before wait? */
	if (isx11)
	{
		XDefineCursor(display, drawwindow, arrowcursor);
	} else
		wm_SetStandardCursor('a');
}

/* ************************************************************* */

TUTORobscure_cursor()		/* make cursor go away until it is moved */
{
	return (0);
}

/* ************************************************************* */

extern int dma_debug;

SetXFill() /* establish X pattern fill character */

{	long fillfont;
	int dx, dy;
	int direction, ascent, descent;
	unsigned char cc;
	XCharStruct overall;
	Pixmap *xmap;
	Pixmap cTpatMap; /* pixmap for cT format character */
	struct ctx11font *fhdr; /* pointer to wm/x11/ct font header */
	struct pcfont816 *cfptr; /* pointer to cT internal-format font */
	int ispat,large;
	int icc; /* index of character in cT-format font */
	char *chp; /* pointer to character definition */
	struct pccharl *clp; /* pointer to large-format definition */
	struct pcchars *csp; /* pointer to small-format definition */

	cc = patternChar;
	xmap = &makepattern[currentXwindow];
	if (patternFont == patternFont0) {
		if (patternChar == patternChar0) {
			XSetFillStyle(display, gc, FillSolid);
			return;
		}
		if (cc > 126)
			return; /* don't go off end of table */
		if (zpats[cc]) {
			XSetStipple(display, gc, zpats[cc]);
			return;
		}
		xmap = &zpats[cc];
	} /* patternFont if */
	
	fillfont = TUTORinq_font_ptr(patternFont);
	fhdr = (struct ctx11font *)fillfont;
	if (fhdr->kind == 1) { /* normal x11 font */
	    XTextExtents((XFontStruct *) wxcp(fillfont),
		     &cc, 1, &direction, &ascent, &descent,
		     &overall);
	    dx = overall.rbearing - overall.lbearing;
	    dy = overall.ascent + overall.descent;
	} else if (fhdr->kind == 3) { /* ct internal format font */
		cfptr = (struct pcfont816 *)GetPtr(fhdr->ptr);
		large = cfptr->format & 1; 
		chp = (char *)cfptr+cfptr->ddef;
		if (large) 
			clp = (struct pccharl *)chp;
		else 
			csp = (struct pcchars *)chp;
		
		/* get description of this character */		
		icc = cc-cfptr->first8;
		if ((icc < 0) || (icc > cfptr->nchars8) || (cfptr->format & 4)) {
			ReleasePtr(fhdr->ptr);
			return(0); /* exit if this character not in font */
		}
		if (large) {
			clp = &clp[icc]; /* pointer to character definition */
			dx = clp->bnw;
			dy = clp->bnh;
		} else {
			csp = &csp[icc]; /* pointer to character definition */
			dx = csp->bnw;
			dy = csp->bnh;
		} /* small else */
		if (dx && dy) {
			cTpatMap = XCreatePixmap(display, drawwindow, dx, dy, 1);
			*xmap = cTpatMap;
			XSetFillStyle(display, gcpatt, FillSolid);
			XSetForeground(display, gcpatt, 0);
			XFillRectangle(display, cTpatMap, gcpatt, 0, 0, dx, dy);
			XSetForeground(display, gcpatt, 1);
			DrawCTChar(cfptr,(int)cc,NULL,cTpatMap);
			XSetStipple(display,gc,cTpatMap);
	/*		XFreePixmap(display,cTpatMap); */
		}
		ReleasePtr(fhdr->ptr);
		return(0);
	} else {
		dx = dy = 0;
	} /* kind else */
	ispat = TRUE;
	if (dx == 0 || dy == 0) {
		ispat = FALSE;
		dx = dy = 16;
	}
	if (*xmap)
		XFreePixmap(display, *xmap);
	*xmap = XCreatePixmap(display, drawwindow, dx, dy, 1);
	XSetForeground(display, gcpatt, 0);
	XFillRectangle(display, *xmap, gcpatt, 0, 0, dx, dy);
	if (ispat) {
		XSetForeground(display, gcpatt, 1);
		XSetFont(display, gcpatt,
			 ((XFontStruct *) wxcp(fillfont))->fid);
		XDrawString(display, *xmap,
			    gcpatt, -overall.lbearing, overall.ascent,
			    &cc, 1);
	}
	XSetStipple(display, gc, *xmap);

} /* SetXFill */

/* ************************************************************* */

TUTORdraw_graphic_icons(iconFont, s, len)	
/* plot a string of characters at current position, update */
/* screen position */
int iconFont; /* font to use */
char *s; /* string of characters */
int len; /* number characters (bytes = 2 for 1 16-bit character) */

{	char *t;
	int c,cc;
	int dx;
	long savefont;
	struct ctx11font *fhdr; /* pointer to wm/x11/ct font hdr */
	struct pcfont816 *cfptr; /* pointer to ct format font */
	long first,nchars; /* first character, number characters */
	int encoding; /* TRUE if 16-bit encoding */
	XRectangle rectangle;
	int i,si;

	if (!isx11) {
		WMdraw_graphic_icons(iconFont, s);
		return;
	}

	/* setup for drawing icons */

	savefont = wmFont;	/* save current font */
	wmFont = TUTORinq_font_ptr(iconFont);
	fhdr = (struct ctx11font *)wmFont;
	encoding = 0;
	
	switch (fhdr->kind) {
	
	case 0: /* wm font */
		TUTORdump("attempt to display WM font under X11");
		
	case 1: /* normal (8-bit codes) X11 font */
	case 2: /* 16-bit codes X11 font */
	
		/* set up new text font */
		
		gcv.font = ((XFontStruct *) wxcp(wmFont))->fid;
		XChangeGC(display, gc, GCFont, &gcv);
		
		/* loop to display characters */
		
		t = s;
		si = 0;
		if (fhdr->kind != 2) { /* 8-bit chars */
			while (c = *(t++)) {
				XDrawString(display, drawwindow, gc,
					RealX, RealY + pd_barheight, &c, 1);
				TUTORinq_abs_string_width((unsigned char FAR *) &c, 1, &dx);
				RealX += dx;
			} /* while */
		} else {
			while (si < len) {
				XDrawString16(display, drawwindow, gc,
					RealX, RealY + pd_barheight, t, 1);
			/*	TUTORinq_abs_string_width((unsigned char FAR *) t, 1, &dx); */
				dx = MyXTextWidth16(t,2);
				RealX += dx;
				si += 2;
				t += 2; /* 16-bit codes */
			} /* while */
		}
		break;
		
	case 3: /* cT internal format font */

		cfptr = (struct pcfont816 *)GetPtr(fhdr->ptr);
		if (encoding = (cfptr->nchars8 == 0)) {
			first = cfptr->first16;
			nchars = cfptr->nchars16;
		} else {
			first = cfptr->first8;
			nchars = cfptr->nchars8;
		}

		/* loop to display characters */
		
		t = s;
		if (encoding) len = len >> 1; /* 16-bit chars */
		for (i=0; i<len; i++) {
			if (encoding) {
				c = ((*t++) & 0xff) << 8; /* build 16-bit code */
				c += (*t++) & 0xff;
			} else  c = *t++; /* 8-bit encoding */
			if ((c >= first) && (c < (first+nchars)))
				DrawCTChar(cfptr,c,&(fhdr->mapcache[c-first]),NULL);
		} /* while */
		
		ReleasePtr(fhdr->ptr);
		KillPtr(cfptr);

		rectangle.x = 0; /* restore clip */
		rectangle.y = 0;
		rectangle.width = tgclipw;
		rectangle.height = tgcliph;
		XSetClipRectangles(display,gc,tgclipx,tgclipy+pd_barheight,
	                   &rectangle,1,YSorted);
		gcv.function = GXcopy;
		XChangeGC(display,gc,GCFunction,&gcv); 
		TUTORset_comb_rule(CurrentMode); /* restore mode */
		break;
		
	} /* fhdr switch */
	
	/* restore text font */

	wmFont = savefont;
	gcv.font = ((XFontStruct *) wxcp(wmFont))->fid;
	XChangeGC(display, gc, GCFont, &gcv);
	
} /* TUTORdraw_graphic_icons */


/* ******************************************************************* */

int TUTORinq_icon_size(fontid,iconN,dx,dasc,ddes)
/* returns width of icon */
int fontid; /* index in font table */
int iconN; /* index of icon */
int *dx; /* returned, width of icon */
int *dasc; /* returned, ascent of icon */
int *ddes; /* returned, descent of icon */

{	int width,ascent,descent;
	long fhdrL; /* (long) pointer to wm/x11/ct font hdr */
	struct ctx11font *fhdr; /* pointer to wm/x11/ct font hdr */
	struct pcfont816 *cfptr; /* pointer to ct format font */
	struct pccharl *cld; /* pointer to large-format char table */
	struct pcchars *csd; /* pointer to small-format char table */
	struct pccharl *clp; /* pointer to large-format character def */
	struct pcchars *csp; /* pointer to small-format character def */
	char *chp; /* pointer to (untyped) character def */
	XFontStruct *fp; /* pointer to x11 font header */
	XCharStruct *xcp; /* pointer to x11 character info */
	int nrow; /* number characters/row in font */
	int large; /* large/small format font flag */
	int first,nchars; /* first char, number chars */
	int code16; /* TRUE if 16-bit encoding */
	int c1,c2,cc;

	width = ascent = descent = code16 = 0;
	if (!isx11) {
		if (dx)
			*dx = 32;
		if (dasc)
			*dasc = 0;
		if (ddes)
			*ddes = 0;
		return(32);
	}

	fhdrL = TUTORinq_font_ptr(fontid);
	fhdr = (struct ctx11font *)fhdrL;

	switch (fhdr->kind) {
	
	case 0: /* wm font */
		TUTORdump("attempt to measure WM font under X11");
		break;
		
	case 1: /* normal (8-bit codes) X11 font */
	case 2: /* 16-bit codes X11 font */
		fp = (XFontStruct *) wxcp(fhdrL);
		ascent = fp->ascent;
		descent = fp->descent;		
		if (fhdr->kind != 2) { /* 8-bit chars */
			if (!fp->per_char) { /* fixed width font */
					width = fp->min_bounds.width;
			} else {
				xcp = fp->per_char;
				if (iconN >= fp->min_char_or_byte2 && 
				    iconN <= fp->max_char_or_byte2)
					width = (xcp + iconN)->width;	
			}
		} else { /* 16-bit chars */
			code16 = TRUE;
			if (!fp->per_char) { /* fixed width font */
					width = fp->min_bounds.width;
			} else {
				xcp = fp->per_char;
				nrow = fp->max_char_or_byte2+1-fp->min_char_or_byte2;
				c1 = (iconN >> 8) & 0xff; /* row */
				c2 = iconN & 0xff; /* icon in row */
				if (c1 >= fp->min_byte1 && c1 <= fp->max_byte1 &&
		    		c2 >= fp->min_char_or_byte2 && c2 <= fp->max_char_or_byte2) {
					cc = ((c1-fp->min_byte1)*nrow)+c2-fp->min_char_or_byte2;
					width = (xcp + cc)->width;
				} 
			} /* fixed width else */
		} /* kind else */
		break;
		
	case 3: /* cT internal format font */
		cfptr = (struct pcfont816 *)GetPtr(fhdr->ptr);
		ascent = cfptr->ascent;
		descent = cfptr->descent;
		large = cfptr->format & 1; 
		chp = (char *)cfptr+cfptr->ddef;
		if (large) 
			cld = (struct pccharl *)chp;
		else 
			csd = (struct pcchars *)chp;
		if (cfptr->nchars8 == 0) {
			code16 = TRUE;
			first = cfptr->first16; /* 16-bit encoding */
			nchars = cfptr->nchars16;
		} else { /* 8-bit encoding */
			first = cfptr->first8;
			nchars = cfptr->nchars8;
		}
		
		/* get description of this character */	
			
		cc = iconN-first;
		if ((cc >= 0) && (cc < nchars)) {
			if (large) {
				clp = &cld[cc]; /* pointer to character definition */
				width = clp->pdx;
			} else {
				csp = &csd[cc]; /* pointer to character definition */
				width = csp->pdx;
			} /* small else */
		} /* cc if */
		ReleasePtr(fhdr->ptr);
		break;
		
	} /* fhdr switch */
	
	if (dx)
		*dx = width;
	if (dasc)
		*dasc = ascent;
	if (ddes)
		*ddes = descent;

	return(width);

} /* TUTORinq_icon_size */

/* ******************************************************************* */

static MyXTextWidth16(ss, nn)
register unsigned char FAR *ss;	/* 16-bit characters to be measured */
int nn;				/* length of string (in 8-bit bytes) */

{	XFontStruct *fp;
	unsigned char FAR *sEnd;
	int width;
	XCharStruct *xcp;
	int nrow; /* number characters/row in font */
	int c1,c2,cc;

	fp = (XFontStruct *) wxcp(wmFont);
	if (!fp->per_char) { /* fixed width font */
		return ((nn/2) * fp->min_bounds.width);
	}
	sEnd = ss + nn;
	width = 0;
	xcp = fp->per_char;
	nrow = fp->max_char_or_byte2+1-fp->min_char_or_byte2;
	while (ss < sEnd) {
		c1 = *ss++ & 0xff;
		c2 = *ss++ & 0xff;
		if (c1 >= fp->min_byte1 && c1 <= fp->max_byte1 &&
		    c2 >= fp->min_char_or_byte2 && c2 <= fp->max_char_or_byte2) {
			cc = ((c1-fp->min_byte1)*nrow)+c2-fp->min_char_or_byte2;
			width += (xcp + cc)->width;
		}
	}

	return (width);
}

/* ******************************************************************* */

static DrawCTChar(cfptr,c,cache,patm)
struct pcfont816 FAR *cfptr;
int c;
long *cache;
Pixmap patm; /* pixmap id if generating pattern, not actual draw */
	
{	struct pccharl *cld; /* pointer to large-format char table */
	struct pcchars *csd; /* pointer to small-format char table */
	struct pccharl *clp; /* pointer to large-format character def */
	struct pcchars *csp; /* pointer to small-format character def */
	char *fmap; /* pointer to base of bit-maps for font */
	char *cmap; /* pointer to character bit-map */
	char *frompt; /* from pointer for bitmap copy */
	char *topt; /* to pointer for bitmap copy */
	char *memmapp; /* pointer to bitmap in memory */
	long memmapl; /* size of bitmap in memory */
	int cbytew,mbytew; /* width of bitmaps in bytes */
	int mapw,maph; /* width, height of character bitmap */
	int bndw,bndh; /* width, height of character bounding box */
	int bndx,bndy; /* displacement from pen to bounding box */
	int penx,peny; /* displacement from pen */
	int cx,cy; /* x,y for character */
	int clipdx,clipdy; /* x,y displacement for clip */
	int clipw,cliph; /* width, height for clip */
	int memmapw; /* pixel width for bitmap data in memory */
	int mii; /* index in bitmap */
	int bii,bjj; /* indexes in bitmap */
	int byte,nbyte; /* next byte of bitmap */
	Pixmap pixm; /* pixmap id of bitmap */
	int large; /* TRUE if large-format font */
	int encoding; /* TRUE if 16-bit encoding */
	int first; /* first character in font */
	int nchars; /* number characters in font */
	char *chp;
	int cc;
	int setfcolor,setbcolor;
	unsigned long coloralt; /* color bits for XChangeGC */
	int cdx,cdy; /* x, y displacement for clip */
	TRect iconr; /* rectangle for entire (uncliped) icon */
	TRect clipr; /* rectangle for clip region */
	TRect drawr; /* rectangle for part of icon drawn */
	int draww,drawh; /* width, height to actually draw */

	coloralt = 0; /* havent tampered with colors yet */
	if (!patm) { /* drawing to screen */
		setfcolor = GetX11PixelValue(fgndColor.palette);
		setbcolor = GetX11PixelValue(bgndColor.palette);
	} /* patm if */

	large = cfptr->format & 1; 
	encoding = (cfptr->nchars8 == 0);

	chp = ((char *)(cfptr))+cfptr->ddef;
	fmap = ((char *)(cfptr))+cfptr->dmap;
	if (large) 
		cld = (struct pccharl *)chp;
	else 
		csd = (struct pcchars *)chp;
	if (encoding) {
		first = cfptr->first16;
		nchars = cfptr->nchars16;
	} else {
		first = cfptr->first8;
		nchars = cfptr->nchars8;
	}	
		
	/* get description of this character */	

	cc = c-first;
	if ((cc < 0) || (cc > nchars)) {
		return(0); /* skip this character if not in font */
	}
	if (large) {
		clp = &cld[cc]; /* pointer to character definition */
		cmap = clp->map+fmap; /* pointer to bitmap */
		mapw = clp->mapw;
		maph = clp->maph;
		penx = clp->pdx;
		peny = clp->pdy;
		bndw = clp->bnw;
		bndh = clp->bnh;
		bndx = clp->bndx;
		bndy = clp->bndy;
	} else {
		csp = &csd[cc]; /* pointer to character definition */
		cmap = csp->map+fmap; /* pointer to bitmap */
		mapw = csp->mapw;
		maph = csp->maph;
		penx = csp->pdx;
		peny = csp->pdy;
		bndw = csp->bnw;
		bndh = csp->bnh;
		bndx = csp->bndx;
		bndy = csp->bndy;
	} /* small else */

	if (bndw == 0) 
		return(0); /* skip if no character */

	cx = RealX+bndx;
	cy = RealY+pd_barheight+bndy;
				
	/* build x11 bitmap from ct character bitmap */
			
	if ((cache == FARNULL) || (!*cache)) {
	
		/* re-format character data so width is multiple of 16 */
	
		memmapw = mapw >> 4; /* make map width multiple of 16 */
		if (mapw != (memmapw << 4))
			memmapw++; /* round up by 16 bits */
		mbytew = memmapw << 1; /* width in bytes */
		memmapw = memmapw << 4; /* size is multiple of 16 */
		memmapl = (memmapw+8)*(maph+8); /* size in pixels */
		memmapl = memmapl >> 3; /* size in bytes */
		memmapp = TUTORalloc(memmapl,TRUE,"bitmap");
		TUTORzero(memmapp,memmapl); /* pre-zero bitmap */
		cbytew = (mapw >> 3);
		if (mapw != (cbytew << 3))
			cbytew++; /* handle last (fractional) byte */		
		frompt = cmap;
		topt = memmapp;
		for(mii=0; mii<maph; mii++) { /* copy next row */
			TUTORblock_move(frompt,topt,(long)cbytew); /* transfer row */
#ifdef hp_byte_order
			for(bii=0; bii<cbytew; bii++) {
				byte = *(topt+bii);
				nbyte = 0;
				for(bjj=0; bjj<8; bjj++) {
					nbyte |= ((byte & (0x80 >> bjj)) >> (7-bjj)) << bjj;
				}
				*(topt+bii) = nbyte;
			}
#endif
			frompt += cbytew;
			topt += mbytew;
		} /* mii for */
		pixm = XCreateBitmapFromData(display,drawwindow,
				       memmapp,memmapw,maph); 
		if (cache)
			*cache = (long)pixm;
		TUTORdealloc(memmapp); /* dump temporary map */
	} /* cache if */

	if (cache)
		pixm = *cache;
			
	/*  display icon */
		
	if (patm) {
		XCopyPlane(display,pixm,patm,gcpatt,0,0,
			    mapw,maph,0,0,1L);
		if (!cache) 
			XFreePixmap(display,pixm);
	} else { /* drawing to screen */	
	
		switch(CurrentMode) {
	
		case SRC_COPY: /* mode rewrite */
			gcv.function = GXcopy;
			break;
				
		case SRC_OR: /* mode write */
			XSetClipMask(display,gc,pixm); 
			XSetClipOrigin(display,gc,cx,cy); 
			gcv.function = GXcopy; 
			break;
				
		case SRC_XOR: /* mode xor */
			XSetClipMask(display,gc,pixm);
			XSetClipOrigin(display,gc,cx,cy);  
			gcv.function = GXxor;
			break;
				
		case SRC_BIC: /* mode erase */
			XSetClipMask(display,gc,pixm);
			XSetClipOrigin(display,gc,cx,cy);
			gcv.function = GXcopy;
			gcv.foreground = setbcolor;
			coloralt = GCForeground;
			break;
				
		case NOT_SRC_COPY: /* mode inverse */
			gcv.function = GXcopy;
			gcv.foreground = setbcolor;
			gcv.background = setfcolor;
			coloralt = GCForeground | GCBackground;
			break;
			
		default:
			break;
			
		} /* switch */

		/* determine intersection of clip rectangle and icon */

		iconr.top = cy;
		iconr.bottom = cy+maph-1;
		iconr.left = cx;
		iconr.right = cx+mapw;
		clipr.top = tgclipy+pd_barheight;
		clipr.bottom = clipr.top+tgcliph-1;
		clipr.left = tgclipx;
		clipr.right = tgclipx+tgclipw;
		TUTORintersect_rect(&iconr,&clipr,&drawr); /* find intersection */

		/* adjust area to plot for intersection with clip */

		cdx = drawr.left-iconr.left;
		cdy = drawr.top-iconr.top;
		draww = drawr.right-drawr.left+1; 
		drawh = drawr.bottom-drawr.top+1; 

		/* change function/color in GC and plot */
		
		XChangeGC(display,gc,GCFunction | coloralt,&gcv); 
		XCopyPlane(display,pixm,drawwindow,gc,cdx,cdy,
			    draww,drawh,cx+cdx,cy+cdy,1L);
		RealX += penx;
		RealY += peny;

		/* restore colors */

		if (coloralt) { 
			gcv.foreground = setfcolor;
			gcv.background = setbcolor;
			XChangeGC(display,gc,coloralt,&gcv);
		} /* coloralt if */
	} /* patm if */
		
	return(0);

} /* DrawCTChar */

/* ************************************************************* */

static TUTORdraw_alpha_icons(iconFont, s, len)	/* start text at upper left corner */
int iconFont; /* font to use */
char *s;
int len; /* not used */

{	
	if (!isx11) {
		WMdraw_alpha_icons(iconFont, s);
		return;
	}

	TUTORdraw_graphic_icons(iconFont,s,len);
	
#ifdef NOSUCH

int offdx, offdy, dx, ascent, descent;
	long savefont;
	TRect tr;

	if (!isx11) {
		WMdraw_alpha_icons(iconFont, s);
		return;
	}

	/* setup for drawing icons */

	savefont = wmFont;	/* save current font */
	wmFont = TUTORinq_font_ptr(iconFont);
	gcv.font = ((XFontStruct *) wxcp(wmFont))->fid;
	XChangeGC(display, gc, GCFont, &gcv);
	ascent = ((XFontStruct *) wxcp(wmFont))->ascent;
	descent = ((XFontStruct *) wxcp(wmFont))->max_bounds.descent;
	offdx = 1;
	offdy = ascent + 2;

	TUTORinq_abs_string_width((unsigned char FAR *) s, strlen(s), &dx);
	if (CurrentMode == SRC_COPY || CurrentMode == NOT_SRC_COPY)
	{
		TUTORset_rect(&tr, RealX + 1, RealY + 1, RealX + dx + 1, RealY + ascent + descent);
		TUTORdraw_abs_solid_rect((TRect FAR *) & tr, PAT_BACKGROUND);
	}
	XDrawString(display, drawwindow, gc,
		 RealX + offdx, RealY + pd_barheight + offdy, s, strlen(s));
	RealX += dx;

	/* restore text font */

	wmFont = savefont;
	gcv.font = ((XFontStruct *) wxcp(wmFont))->fid;
	XChangeGC(display, gc, GCFont, &gcv);

	/* adjust for offset */
	TUTORabs_move_to(RealX - offdx, RealY - offdy);
#endif

} /* TUTORdraw_alpha_icons */

/* ************************************************************* */

WMdraw_graphic_icons(iconFont, s)	/* plot a string of characters at
					 * current position, update screen
					 * position  */
int iconFont;			/* the font to use */
char *s;

{
#ifdef WM
	char c, *t;
	register struct IconGenericPart *icon;
	long iconFP;
	TRect tr;

	/* setup for drawing icons */
	iconFP = TUTORinq_font_ptr(iconFont);
	wm_SelectFont((struct font *) wxcp(iconFP));

	t = s;
	while (c = *(t++))
	{
		if (c < 32 || c > 126)
			continue; /* skip illegal character */
		icon = (struct IconGenericPart *) & ((struct font *) iconFP)->chars[c];
		icon = GenericPart(((struct icon *) icon));
		if (CurrentMode == SRC_COPY || CurrentMode == NOT_SRC_COPY)
		{		/* rewrite and inverse need background filled
				 * first */
			TUTORset_rect(&tr,
				      RealX - icon->NWtoOrigin.x - 1,
				      RealY - icon->NWtoOrigin.y - 1,
			      RealX - icon->NWtoOrigin.x + icon->WtoE.x + 1,
			     RealY - icon->NWtoOrigin.y + icon->NtoS.y + 1);
			TUTORdraw_abs_solid_rect((TRect FAR *) & tr, PAT_BACKGROUND);
		}
		putc(c, winout);
		RealX += icon->Spacing.x;
		RealY += icon->Spacing.y;
	}			/* while */

	/* restore text font */
	wm_SelectFont((struct font *) wxcp(wmFont));
#endif
}

/* ************************************************************* */

WMdraw_alpha_icons(iconFont, s)	/* start text at upper left corner */
int iconFont;			/* icon font to use */
char *s;

{
#ifdef WM
	int offdx, offdy;
	char c, *t;
	register struct IconGenericPart *icon;
	long iconFP;
	TRect tr;

	/* setup for drawing icons */
	iconFP = TUTORinq_font_ptr(iconFont);
	wm_SelectFont((struct font *) wxcp(iconFP));

	t = s;
	offdx = ((struct font *) iconFP)->NWtoOrigin.x + 1;
	offdy = ((struct font *) iconFP)->NWtoOrigin.y + 1;
	TUTORabs_move_to(RealX + offdx, RealY + offdy);

	while (c = *(t++))
	{
		if (c < 32 || c > 126)
			continue; /* skip illegal character */
		icon = (struct IconGenericPart *) & ((struct font *) iconFP)->chars[c];
		icon = GenericPart(((struct icon *) icon));
		if (CurrentMode == SRC_COPY || CurrentMode == NOT_SRC_COPY)
		{
			TUTORset_rect(
				      RealX - offdx,
				      RealY - offdy,
				      RealX - offdx + icon->Spacing.x,
				      RealY - offdy + ((struct font *) wxcp(iconFP))->NtoS.y);
			TUTORdraw_abs_solid_rect((TRect FAR *) & tr, PAT_BACKGROUND);
		}
		putc(c, winout);
		RealX += icon->Spacing.x;
		RealY += icon->Spacing.y;
	}			/* while */

	/* readjust for offset */
	TUTORabs_move_to(RealX - offdx, RealY - offdy);

	/* restore text font */
	wm_SelectFont((struct font *) wxcp(wmFont));
#endif
}

/* ************************************************************* */

TUTORinq_font_info(ascent, descent, maxwidth, leading)
int *ascent;   /* maximum ascent above base line */
int *descent;  /* maximum descent below base line */
int *maxwidth; /* maximum character width */
int *leading;  /* leading (extra fill between lines) */

{	FontFamily *fFam;
	short ii, family, size;
	int dd;
	struct tutorfont FAR *tf;
	long fontp;
	int lascent,ldescent,lmaxwidth;

	tf = textFont + (struct tutorfont FAR *) GetPtr(fontsH);
	fontp = tf->ptr;

	if (isx11) {
		lascent = ((XFontStruct *) wxcp(fontp))->max_bounds.ascent;
		ldescent = ((XFontStruct *) wxcp(fontp))->max_bounds.descent;
		lmaxwidth = ((XFontStruct *) wxcp(fontp))->max_bounds.width;
	} else {
		lascent = ((struct font *) wxcp(fontp))->NWtoOrigin.y;
		ldescent = (((struct font *) wxcp(fontp))->NtoS.y) - (lascent);
		lmaxwidth = ((struct font *) wxcp(fontp))->WtoE.x;
	}

	if (ascent)
		*ascent = lascent;
	if (descent)
		*descent = ldescent;
	if (maxwidth)
		*maxwidth = lmaxwidth;

	/* adjust leading so that total font height equals the size in the
	 * font family table */
	/* Are we sure that textFont has been set? */
	family = tf->family;
	size = tf->size;
	ReleasePtr(fontsH);
	KillPtr(tf);

	if (!leading) return; /* we are done */

	fFam = family + (FontFamily FAR *)
		GetPtr(fontFamilies);	/* pointer to family information */
	ii = 0;
	while (fFam->famSizes[0][ii] != size) {
		ii++; /* scan through table looking for this font size */
		if (ii >= NFSIZES) {
			ii = 0; /* something wrong - didn't find size */
			break;
		}
	}

	*leading = fFam->famSizes[2][ii] - (lascent + ldescent);
#ifdef WM
	if (!isx11 && !NewFontSize) {
		*leading = (((struct font *) wxcp(fontp))->newline.y) -
		    (((struct font *) wxcp(fontp))->NtoS.y);
	} /* x11 if */
#endif
	ReleasePtr(fontFamilies);
	KillPtr(fFam);

} /* TUTORinq_font_info */

/* ******************************************************************* */

long TUTORinq_font_ptr(fontN)
int fontN;
{
	struct tutorfont FAR *tf;
	long fontp;

	tf = fontN + (struct tutorfont FAR *) GetPtr(fontsH);
	fontp = tf->ptr;
	ReleasePtr(fontsH);
	KillPtr(tf);

	return (fontp);
}

/* ******************************************************************* */

#ifdef NoSuch
TUTORinq_abs_string_width16(s,lth,dx)
unsigned char FAR *s;
int lth;
int *dx;

{
	*dx = MyXTextWidth16(s,lth*2);
	
} /* TUTORinq_abs_string_width16 */
#endif

/* ******************************************************************* */

TUTORinq_abs_string_width(s, lth, dx)	/* find width of string */
unsigned char FAR *s;
int lth;
int *dx;

{
	register struct icon *ci;	/* pointer to current character info */
	register struct IconGenericPart *gi;
	register int x;		/* current x position, in current line */
	int maxX;		/* maximum line width (which will be string
				 * width) */
	register int c;		/* character code */
	int width;

	if (isx11)
	{
		if (currentXwindow < 0) {
			if (dx)
				*dx = 10 * lth;
			return;
		}
		if (lth && (s[lth - 1] == NEWLINE))
			lth--;	/* ignore newline at end of string */
		width = MyXTextWidth((XFontStruct *) wxcp(wmFont), s, lth);
		if (dx)
			*dx = width;
		return (width);
	}
	if (wmFont == 0)
	{
		/* cant look up if no font */
		if (dx)
			*dx = 10;
		return;
	}
	x = maxX = 0;
	while ((c = *s++) && (lth--))
	{
		if (c > 127)	/* need to convert a ct character */
			c = ct2wm[c - 128];
		ci = &((struct font *) wxcp(wmFont))->chars[c];	/* description of this
								 * char */
		if (ci->OffsetToGeneric)
		{
			gi = (struct IconGenericPart *) (((int) ci) + ci->OffsetToGeneric);
			x += gi->Spacing.x;
		}		/* ci if */
		if (c == ' ')
			x += (SpaceShim >> 16);	/* add integer portion of
						 * space shim */
		else if (c == NEWLINE)
		{
			if (x > maxX)
				maxX = x;
			x = 0;	/* reset x, starting new line */
		}		/* NEWLINE if */
	}			/* while */
	if (x > maxX)
		maxX = x;	/* account for last line */

	if (dx)
		*dx = maxX;
	return maxX;

} /* TUTORinq_abs_string_width */

/* ************************************************************* */
static MyXTextWidth(fp, ss, nn)
register XFontStruct *fp;
register unsigned char FAR *ss;	/* characters to be measured */
int nn;				/* length of string */
{
	register unsigned char FAR *sEnd;
	register int width;
	XCharStruct *xcp;

	if (!fp->per_char)
	{			/* fixed width font */
		return (nn * fp->min_bounds.width);
	}
	sEnd = ss + nn;
	width = 0;
	xcp = fp->per_char - fp->min_char_or_byte2;
	while (ss < sEnd)
	{
		if (*ss >= fp->min_char_or_byte2 && *ss <= fp->max_char_or_byte2)
			width += (xcp + *ss)->width;
		ss++;
	}

	return (width);
}

/* ************************************************************* */

static short fAvailSizes[] = {8, 10, 12, 16, 22, 22};

/* note that the # of font sizes should == NFSIZES */
/* oldCR is Yy font size, newCR is newline font size */
static short oldCR[] = {10, 12, 13, 17, 22, 22, 10, 12, 14, 18, 24, 24};	/* serif info, sans info */
static short newCR[] = {11, 13, 15, 19, 25, 25, 11, 13, 15, 20, 26, 26};

static short fAvailSizesX[] = {8, 10, 12, 14, 18, 24};

static short oldserifCRX[] = {7, 9, 12, 13, 17, 22};	/* serif info */
static short newserifCRX[] = {11, 12, 15, 17, 22, 29};
static short oldsansCRX[] = {7, 10, 12, 14, 18, 24};	/* sans info */
static short newsansCRX[] = {10, 14, 16, 18, 23, 30};
static short oldfixedCRX[] = {7, 8, 11, 12, 15, 19};	/* fixed info */
static short newfixedCRX[] = {11, 13, 15, 20, 24, 32};
static short oldsymbolCRX[] = {8, 9, 12, 13, 17, 22};	/* symbol info */
static short newsymbolCRX[] = {12, 15, 17, 21, 26, 33};

/* in TUTORfont_sizes, if there are not copies of the font for all sizes,
 * fill out the size table for what exists, then finish the size table with
 * -1 in all places */

TUTORround_font_size(size)
int size;
/* returns proper system size corresponding to size */
	{
	short *sz;
	int ii;
	
	if (isx11)
		sz = fAvailSizesX;
	else
		sz = fAvailSizes;
	
	for (ii=1; ii<6; ii++)
		if (size < sz[ii])
			return(sz[ii-1]);
	
	return(sz[ii-1]); /* largest size */
	}

TUTORfont_sizes(id, fontN)	/* fill out font family sizes */
/* wm and X11 version */
/* e called by ctgraph.c */
long id;				/* font id - unused */
int fontN;			/* index in fontFamilies table */

/* In the following table, Yy is the height from top of Y to bottom of y, CR
 * is height of newline (top of Y to top of Y on next line), and leading is
 * space between lines (using BE1 display routines). If NewFontSize is TRUE,
 * CharHeight represents CR rather than Yy. "n" is width of n; "avg." is
 * average width of lower-case letters. In parentheses are shown hypothetical
 * CR and leading values based on proportional scaling from the 12-point
 * font.
 * 
 * BE1 format.c calculated CR from the font info on NorthToSouth (total height
 * including allowance for leading) plus extra space to allow for a
 * 5-dot-high editing caret not to hit the line beneath it.  That is, extra
 * leading was added if necessary so that descenders plus leading was enough
 * for the editing caret. NWtoOrigin is the height of an upper-case letter.
 * BE1 format.c checked for NtoS - NWtoOrigin being >= 5 for the editing
 * caret.
 * 
 * FONT		Yy	CR	leading	n	avg.	avg/CR	NtoS
 * WtoOrigin andy8	09	12 (11)	3 (2)	5	4.81	.40 (.44) 11
 * (+1 for CR)	7 andy10	12	14 (13)	2 (1)	6	5.58 .40
 * (.43)	13 (+1 for CR)	9 andy12	13	15 (15)	2 (2)	7
 * 6.50	.43 (.43)	15		10 andy16	17	18 (19)	1 (2)
 * 10	8.35	.46 (.44)	18		13 andy22	22	24
 * (25)	2 (3)	13	11.08	.46 (.44)	24		18
 * 
 * andysans8	10	12 (11)	2 (1)	6	5.15	.43 (.47)	10
 * (+2 for CR)	7 andysans10	12	13 (13)	1 (1)	7	6.11	.47
 * (.47)	12 (+1 for CR)	8 andysans12	14	15 (15)	1 (1)	8
 * 6.96	.46 (.46)	14 (+1 for CR)	10 andysans16	18	18 (20)	0 (2)
 * 10	9.23	.51 (.46)	18		13 andysans22	24	25
 * (26)	1 (2)	14	12.19	.49 (.47)	25		19 */

{
	short ii, offset;
	FontFamily FAR *fFam;
	short *p1, *p2;

	fFam = fontN + (FontFamily FAR *) GetPtr(fontFamilies);
	offset = 0;
	if (isx11)
	{
		if (!strcmp("zsans", fFam->familyRef.path))
		{
			p1 = oldsansCRX;
			p2 = newsansCRX;
		} else if (!strcmp("zfixed", fFam->familyRef.path))
		{
			p1 = oldfixedCRX;
			p2 = newfixedCRX;
		} else if (!strcmp("zsymbol", fFam->familyRef.path))
		{
			p1 = oldsymbolCRX;
			p2 = newsymbolCRX;
		} else
		{
			p1 = oldserifCRX;
			p2 = newserifCRX;
		}
		for (ii = 0; ii < NFSIZES; ii++)
		{
			fFam->famSizes[0][ii] = fAvailSizesX[ii];
			fFam->famSizes[1][ii] = *(p1 + ii);	/* Yy height definition */
			fFam->famSizes[2][ii] = *(p2 + ii);	/* newline height
								 * definition */
		}
	} else
	{
		ii = strlen(fFam->familyRef.path);
		if (!strncmp("sans", fFam->familyRef.path + ii - 4, 4))
			offset += NFSIZES;	/* look at sans data rather
						 * than serif data */
		for (ii = 0; ii < NFSIZES; ii++)
		{
			fFam->famSizes[0][ii] = fAvailSizes[ii];
			fFam->famSizes[1][ii] = oldCR[ii + offset];	/* Yy height definition */
			fFam->famSizes[2][ii] = newCR[ii + offset];	/* newline height
									 * definition */
		}
	}

	ReleasePtr(fontFamilies);
	KillPtr(fFam);

} /* TUTORfont_sizes */

/* ******************************************************************* */

Memh wmg_load_font(fontPath, fontInd) /* read specified font from disk */
FileRef FAR *fontPath; /* font file name */
int fontInd; /* font index (unused) */
	
{	FileRef tryPath;
	int fontfi; /* font file index */
	int fret; /* file operations error return */
	long fsize; /* file size */
	Memh fonthandle; /* handle on font */
	struct pcfont816 *fontptr; /* pointer to font in memory */
	int exti; /* index of file extension if present */
	int sysF; /* TRUE if system font (zicons,zcursors,zpatterns) */
	char *envp; /* pointer to environment string */
	int ci;
	char *cp;

	/* build fileref for font */

	exti = 0; /* no extension yet */
	
	/* open font file */
	
	fontfi = TUTORopen(fontPath,TRUE,FALSE,FALSE);
	if (fontfi == 0) {
		if (cp = rindex_z(fontPath->path,'/'))
			cp++;
		else
			cp = fontPath->path;
		sysF = strcmp(cp,"zcursors10") == 0;
		if (!sysF)
			sysF = strcmp(cp,"zicons12") == 0;
		if (!sysF)
			sysF = strcmp(cp,"zpatterns10") == 0;
		if (sysF) {
			TUTORblock_move((char FAR *) fontPath, (char FAR *) &tryPath,(long) sizeof(FileRef));
			tryPath.path[0] = '\0';
			envp = TUTORgetenv("CT_FONTS");	
			if (envp) 
				strcpy(tryPath.path,envp); /* path to cT fonts */	
			tryPath.nameInd = strlen(tryPath.path);
			strcat(tryPath.path,cp); /* font name */
			/* reset font path */
			TUTORblock_move((char FAR *) &tryPath, (char FAR *) fontPath,(long) sizeof(FileRef));
		} /* sysF if */
	}
	if (fontfi == 0) {

		/* try to add "fct" extension and look again */

		TUTORblock_move((char FAR *) fontPath, (char FAR *) &tryPath,(long) sizeof(FileRef));
		ci = strlen(tryPath.path);
		cp = tryPath.path+ci-1;
		while ((cp > tryPath.path) && (*cp != '.') && (*cp != '/')) 
			cp--;
		if (*cp == '.')  {
			exti = cp-tryPath.path; /* index of extension */
			*cp = 0; /* remove extension */
		}
		if ((*cp != '.') && (ci < (FILEL-4))) {
			strcat(tryPath.path,".");
			strcat(tryPath.path,machinename());
			strcat(tryPath.path,".fct");
			fontfi = TUTORopen(&tryPath,TRUE,FALSE,FALSE);
			if (fontfi)  {
				TUTORblock_move((char FAR *) &tryPath, (char FAR *) fontPath,
						(long) sizeof(FileRef));
			}
		} /* cp if */
	} /* fontfi if */
	if (fontfi == 0) {

		/* try to add "fdb" extension and convert file */

		TUTORblock_move((char FAR *) fontPath, (char FAR *) &tryPath,(long) sizeof(FileRef));
		if (exti) /* remove extension */
			tryPath.path[exti] = '\0'; 
		strcat(tryPath.path,".fdb");
		fret = wmg_cvt_fdb(tryPath.path);
		if (fret) {
			fontfi = TUTORopen(&tryPath,TRUE,FALSE,FALSE);
			if (fontfi) {
				TUTORblock_move((char FAR *) &tryPath, (char FAR *) fontPath,
						(long) sizeof(FileRef));
			}
		} /* fret if */
	} /* fontfi if */

	if (fontfi == 0)
		return(HNULL);

	/* determine size of font file */

	TUTORinq_file_info(fontPath,NEARNULL,&fsize,NEARNULL,NEARNULL,NEARNULL);
	if (fsize <= 0) {
		TUTORclose(fontfi);
		return(HNULL);
	}

	/* allocate memory and read font from disk */

	fonthandle = TUTORhandle("font",(long)fsize,FALSE);
	fontptr = (struct pcfont816 *)GetPtr(fonthandle);
	fret = TUTORread((char *)fontptr,1,(long)fsize,fontfi);
	TUTORclose(fontfi);

	/* check if contents of file make sense */

	if (strcmp("ct",fontptr->ident))
		fret = -1;
	if (fret != fsize) {
		ReleasePtr(fonthandle);
		TUTORfree_handle(fonthandle);
		return(HNULL);
	}

	ReleasePtr(fonthandle);
	KillPtr(fontptr);
	return(fonthandle);

} /* wmg_load_font */

/* ******************************************************************* */

static int fidc = 0; /* unique id for /tmp font */

static int wmg_cvt_fdb(fN) /* convert fdb file to fct file */
char *fN; /* fdb file name - altered if convert successfull */

{	int fret;
	int sl;
	char *penv; /* pointer to environment string */
	char fullcmd[3*FILEL+20]; /* full fdbct statement */
	char cfdbct[2*FILEL+20]; /* fdbct command statement */
	char newname[FILEL+2]; /* new file name */
	char *cp;
	long fid;
	char *tmpName;

	/* build new file name with .fct extension */

	strcpy(newname,fN);
	sl = strlen(newname);
	if (sl < 5) 
		return(FALSE);
	cp = &newname[sl-4];
	if (strcmp(cp,".fdb"))
		return(FALSE);
	*cp = '\0'; /* remove .fdb extension */
	strcat(newname,".");
	strcat(newname,machinename());
	strcat(newname,".fct");
#ifdef SYSV
#ifdef hp700
    fret = access(fN,W_OK);
#else
#ifdef SOLARIS
    fret = FALSE;
#else
	fret = TRUE;
#endif
#endif
#else
	fret = access(fN,R_OK | W_OK);
#endif
	if (fret) { 
		tmpName = TUTORgetenv("CT_TEMP");
		if (!tmpName)
			tmpName = "/tmp/";
		strcpy(newname,tmpName);
		sl = strlen(newname);
		if (sl && (newname[sl-1] != '/'))
			strcat(newname,"/");
		sl = strlen(newname);
		fid = (getpid()*128)+(fidc++);
		sprintf(&newname[sl],"f%ld.fct",fid);
	}
	
	/* build fdbct command */
	
	fullcmd[0] = 0;
	penv = TUTORgetenv("CT_UTIL"); /* get path to utilities */
	if (penv) 
		strcpy(fullcmd,penv); /* set path to fdbct */
	sl = strlen(fullcmd);
	if (sl && (fullcmd[sl-1] != '/'))
		strcat(fullcmd,"/"); /* slash before command */
	sprintf(cfdbct,"fdbct %s %s g",fN,newname);
	strcat(fullcmd,cfdbct); /* finish command */
		
	/* execute fdbct to convert fdb file */

TUTORtrace(fullcmd);
	system2(fullcmd,TRUE);
	strcpy(fN,newname);
	return(TRUE);

} /* wmg_cvt_fdb */

/* ******************************************************************* */

#ifdef LEADINGSTUFF

static 
AdjustLeading(fi)		/* adjust leading to get "reasonable" aspect
				 * ratio for font */
FontInfo *fi;
{
	static char *testS = "abcdefghijklmnopqrstuvwxyz";
	short width, height, aspect, maxLead;

	width = StringWidth(testS);
	height = fi->ascent + fi->descent + fi->leading;
	maxLead = (fi->ascent + fi->descent) / 3;
	aspect = ((long) width * 100) / ((long) height * 26);
	if (aspect > 46)
	{
		while (aspect > 46 && fi->leading <= maxLead)
		{
			height++;
			fi->leading++;
			aspect = ((long) width * 100) / ((long) height * 26);
		}
	} else if (aspect < 44 && fi->leading > 1)
	{
		while (aspect < 44 && fi->leading > 1)
		{
			height--;
			fi->leading--;
			aspect = ((long) width * 100) / ((long) height * 26);
		}
	}
	/* at this point fi->leading has been modified appropriately */
	return;
}

#endif				/* LEADINGSTUFF */

/* ******************************************************************* */

int TUTORinq_mouse_xy(xx,yy)
long *xx;
long *yy;

{	Window theW;
	Window rootW,childW;
	int root_x,root_y;
	int win_x,win_y;
	int bStatus;
	unsigned int mask;

	if (CurrentWindow < 0)
		return(0);
	theW = (Window)windowsP[CurrentWindow].wp;
	XQueryPointer(display,theW,&rootW,&childW,
                      &root_x,&root_y,&win_x,&win_y,&mask);
	*xx = win_x;
	*yy = win_y;
	return(0);

} /* TUTORinq_mouse_xy */

/* ******************************************************************* */

int TUTORinq_left_down() /* returns TRUE if left button down */

{
	if (windowsP[CurrentWindow].ldowntime1 > windowsP[CurrentWindow].luptime)
		return(TRUE);
	return(FALSE);

} /* TUTORinq_left_down */

/* ******************************************************************* */

int TUTORinq_right_down() /* returns TRUE if right button down */

{
	if (windowsP[ExecWn].rdowntime1 > windowsP[ExecWn].ruptime)
		return(TRUE);
	return(FALSE);
	
} /* TUTORinq_right_down */
  
/* ******************************************************************* */

TUTORseed_random(value)		/* seed random number generator */
int value;

{
	srandom(value);

}				/* TUTORseed_random */

/* ******************************************************************* */

static SetupCTDir()	 /* set up global variable ctDir */

{
	char *envp;
	FileRef fRef;

	envp = TUTORgetenv("CT_COMMON");
	if (envp == NULL)
		ctDirP->path[0] = '\0';
	else
		strcpy(ctDirP->path, envp);
	ctDirP->nameInd = strlen(ctDirP->path);

} /* SetupCTDir */


/* ******************************************************************* */

TUTORread_assoc()
{				/* read associated (.cta) file info */
}				/* TUTORread_assoc - no-op on x11/wm */

/* ******************************************************************* */

TUTORwrite_assoc()
{				/* write associated (.cta) file info */
}				/* TUTORread_assoc - no-op on x11/wm */

/* ******************************************************************* */

TUTORexec_assoc()
{				/* process associated (.cta) file info */
}				/* TUTORexec_assoc - no-op on x11/wm */

/* ******************************************************************* */

extern int TUTORsound(fRef,soundid) /* play sound file */
/* returns zero if worked, non-zero otherwise */
FileRef FAR *fRef;
long soundid;

{
    return(FILEIMPROPERTYPE); /* didn't work */

} /* TUTORsound */

/* ********************************************************** */

int TUTORis_foreground() /* TRUE if executor is front window */

{	Window focusW; /* keyboard focus window */
	Window ExecW;
	int revert;

	if (ExecWn < 0) return(FALSE);
	ExecW = (Window)windowsP[ExecWn].wp;
	XGetInputFocus(display,&focusW,&revert);
	if (ExecW == focusW)
		return(TRUE);
	return(FALSE);
	
} /* TUTORis_foreground */

/* ******************************************************************* */

int chkDebExeOverlap() /* check if executor and debugger windows overlap */

{	Window xW; /* executor window */
	Window dW; /* debug window */
	
} /* chkDebExeOverlap */
	
/* ******************************************************************* */

#ifdef SYSV

extern char *getcwd(); /* SYSV get current working directory */

static char cwdbuf[258];

char *getwd(buf)  /* get current working directory */
char *buf;

{
	getcwd(cwdbuf, 255);
	strcpy(buf, cwdbuf);
	return (cwdbuf);

} /* getwd */

#endif /* SYSV */

/* ******************************************************************* */


/* ****************** debugging aids ********************** */


/* ******************************************************************* */

/* dummy routines to satisfy references in pulldown menu support */

wmg_outline(int  x1,int  y1,int  x2,int  y2,int  md)
{
	return;
}

wmg_wipe()
{
	return;
}

wmg_frame(int  wix)
{
	return;
}

wmg_focus(int  fwix)
{
	return;
}

wmg_arrange(int  focus)
{
	return;
}

wmg_on()
{
	return;
}

wmg_off()
{
	return;
}

wmg_fwd(int  wix)
{
	return;
}

wmg_layout()
{
	return;
}

/* ******************************************************************* */


/* dummy routines for non-WM (non-AFS) Unix compilations */

#ifndef WM

GR_SEND()
{
	return;
}

GR_WAITFOR()
{
	return;
}

wm_SelectWindow()
{
	return;
}
struct wm_window *
wm_NewWindow()
{
	return;
}

wm_flsbuf()
{
	return;
}

wm_fflush()
{
	return;
}
struct font *
wm_DefineFont()
{
	return;
}

wm_DrawString()
{
	return;
}

short wm_uarg[6];

wm_GR_send() { return; }
wm_GR_waitfor() {return; }

vfclose(fp)
FILE *fp;
{
	fclose(fp);
}


#endif				/* not-WM */

#ifdef SYSV


CloseVideo()
{
	return (0);
}


InitVideo()
{
	return (0);
}

#endif				/* SYSV */

