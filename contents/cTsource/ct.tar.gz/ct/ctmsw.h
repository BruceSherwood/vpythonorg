
#ifndef ctmsw_d
#define ctmsw_d

#include "baseenv.h"

#define IDM_CT 100			/* start of cT-specific menus */

#define IDC_CT        200   /* start of cT-specific commands */
#define ID_ABOUT      200   /* about dialog box */
#define ID_STDINP     201   /* input text from standard dialog */
#define ID_STDINPTXT  202   /* message text for standard dialog */
#define ID_MULMSGTXT1 203   /* message text for multi-line dialog */
#define ID_MULMSGTXT2 204
#define ID_MULMSGTXT3 205
#define ID_MULMSGTXT4 206
#define ID_MULMSGTXT5 207
#define ID_MULMSGTXT6 208
#define ID_MULMSGTXT7 209
#define ID_MULMSGTXT8 210
#define ID_ALTINP     211   /* alternate input text from dual-input dialog */
#define ID_ALTINPTXT  212   /* alternate message text for dual-input dialog */
#define ID_SNAPSHOT   213   /* snapshot check-box in prefs dialog */
#define ID_PRINTNM    214   /* list file name in print dialog box */
#define ID_WINPOS     215   /* window position check-box in prefs dialog */
#define ID_WRAP       216   /* word wrap check-box in prefs dialog */
#define ID_MARKER     217   /* debug marker window check-box in prefs dialog */

#define IDB_CT 300	    /* start of cT-specific buttons */

#define CTM_INIT WM_USER+1	/* cT-internal messages */
#define CTM_INTERACT CTM_INIT+1

struct cTwinInf{
    HWND hWnd; /* handle on window */
    int type; /* type of window */
    int index; /* index in cT table (windows[]) */
    int cmdN; /* command this window (button) will send */
    unsigned int infH; /* cT handle on additional information */
}; /* cTwinInf */

#define cTw_Overlap 8	/* independant overlapped window - edit, exec, etc */
#define cTw_Scroll 9	/* vertical or horizontal scroll bar child window */
#define cTw_Button 10	/* button child window */
#define cTw_Server 11	/* invisible server window */


#endif /* ctmsw_d */
