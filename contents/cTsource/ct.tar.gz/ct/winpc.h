
/* (c) Copyright Carnegie-Mellon University, 1987. */
/* May be used and copied freely for educational purposes, */
/* but may not be sold without the written consent of Carnegie-Mellon University. */

#ifndef WINPC
#define WINPC

/* #define TURBOC 1  */
#define MSC 1

#ifndef Ptr_Def
typedef char *Ptr;
#endif

#define NEWLINE '\n'
#define NEWLINES "\n"
#define RETURN '\r'

#ifndef FAR
#define FAR
#endif

#ifndef SHUGE
#define SHUGE
#endif

#define Farp(x) ((char FAR *) (x))

#define NEARNULL ((void *)0)
#define FARNULL ((char *)0)


#define BADPOINTER -3

#define HPurge(x) /* purge */
#define HNoPurge(x) /* nopurge */

#define FILEL 94  /* max file name length */

#define EVENTLIMIT 20 /* maximum number events to stack up */

#define MAXNEARLEN 1024 /* max size for far->near conversion */

/* file reference structure: */
typedef struct _fref {
    char path[FILEL+2]; /* full path, including name */
    unsigned char nameInd;  /* index in path where bare file name starts */
    char drive;     /* 1 - a:,  2 - b:, etc. */
} FileRef;

#define ctproto

/* machine-dependent graphics definitions */

/* text face definitions */

#define style_plain 0
#define style_bold 1        
#define style_italic 2

/* text/pattern mode definitions */

#define SRC_COPY 0  /* mode rewrite */
#define SRC_OR  1   /* mode write */
#define SRC_XOR 2   /* mode xor */
#define SRC_BIC 3   /* mode erase */
#define NOT_SRC_COPY 4  /* mode inverse */
#define NOT_SRC_OR 5
#define NOT_SRC_XOR 6
#define NOT_SRC_BIC 7

  /* for filling a solid rect */
#define PAT_BLACK  1
#define PAT_WHITE  20
#define PAT_BACKGROUND -1

#define NFSIZES 6

/* scroll bar part codes */
#define inButton 10
#define inCheckBox 11
#define inUpButton 20
#define inDownButton 21
#define inPageUp 22
#define inPageDown 23
#define inThumb 129

struct saved_region {
	int format; /* 0 = native screen format, 1 = dib */
	long bmapH; /* handle on bitmap */
	int width,height; /* size of image */
	unsigned int rgbdibH; /* handle on rgb DIB */
	unsigned int paldibH; /* handle on palettized DIB */
	unsigned int rowBytes; /* bytes/row in image */
	unsigned int nativePal; /* handle on image palette */
	unsigned int rgbDataH; /* handle on 3-byte RGB format pixels */
	unsigned int palDataH; /* handle on palette format pixels */
	int palpixRef; /* palette # used for palettized data */
}; /* saved_region */

#endif	/*  WINPC */
