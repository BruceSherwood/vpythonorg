
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Part of the command compiler.
*/

#include "ctutor.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "txt.h"
#include "exprdefs.h"
#include "yacc.h"
#include "ct_ctype.h"
#include "fkeys.h"

#ifdef ctproto
extern int killptr(char FAR * FAR *pp);
extern int  textpool_string(long  len,long  loc);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
extern int  extract_unit(char  *unitn,int  *term,int  iFlag);
extern int compile_unit_and_arg(void);
int  identify_keyword(struct  keywdinf *klist,int  *term);
int compile_buffer_len(int allow_mark);
extern int compile_numeric_array(void);
int  compile_single_keyword(struct  keywdinf *klist,int  *term);
int  compile(struct  expra *exap);
int  cmpbuf_word(int  n);
extern int skip_white_cB(void);
int  compile_keyword_and_args(struct keywdinf *klist,int  *term);
int compile_long_value(long vv);
char  FAR *GetPtr(unsigned int  mm);
int ReleasePtr(unsigned int mm);
int  extract_keyword_cB(char  *kname,int  maxl,int  spaces,int  *term);
int  pbscan(unsigned char  FAR *str,int  indx,char  *target);
extern int find_def_sym(Memh topSetH,char *s,Memh *retSet,int *retIndex) ;
int  compile3(void);
int  cerror(int  errnumber,char  *execstr);
int  compile_short_value(int  vv);
int  compile_simple_numeric(int  nmask,int  fmask,int  stopl);
int  compile_marker(int  storef,int  semic);
int  compile_points(int  min,int  limit,int  type,int  stopl,int  cont,int  czxy,int  blank,int  coarse,int  skip);
int  compile_txtype(int  type,int storef);
#endif /* ctproto */

extern long TUTORget_len_doc();
extern char *strf2n();
extern long tdoc_diffstyle();
extern struct keywdinf *GetKeyNames();

extern struct keywdinf stylelist[];

static struct keywdinf forgetlist[2] = { {"icons",KW_FICONS}, {NULL,0} };

static struct keywdinf sysinfolist[7] = { {"default newline",KW_SYSFONTHT}, 
              {"default colors",KW_DEFCOLOR}, {"palette size",KW_PALETTESZ},
              {"default rgb",KW_DEFRGB}, 
              {"foreground",KW_DEFFGND}, {"background",KW_DEFBGND}, {NULL,0} };
        	
static struct keywdinf dialoglist[6] = { {"ok",KW_DOK},
              {"yes no cancel",KW_DYNC}, {"input",KW_DINPUT}, {"page setup",KW_DPRINTS}, 
              {"print",KW_DPRINTX}, {NULL,0} };
              
static struct keywdinf getlist[3] = { {"palette",1}, {"rgb",2}, {NULL,0} };
              
/* ******************************************************************* */

compile3() 

{   int term; /* terminating character code */
    int unitn; /* unit number */
    int argt; /* 0 = absolute, 1 = relative, 2 = graphing */
    int coarsef; /* TRUE if coarse grid allowed */
    int lpI; /* index of left paren */
    int rpI; /* index of right paren */
    Memh fSetH; /* handle on define set */
    int fIndex; /* index in defined symbols */
    int localSet; /* TRUE if local define set */
    struct defset FAR *udP; /* pointer to define set */
    struct defvar FAR *symP; /* pointer to symbol definition */
    char ws[DEFNAMEL+2]; /* defined name buffer */
    struct defvar symDef; /* symbol definition */
    struct array_desc FAR *adsc; /* pointer to array descriptor */
    struct expra wkexa; /* scratch analyzer params */
	int uii; /* index of unit */
    int ii,cii,cjj;
    long loc;

switch(newcmd) {

case C_GET:
case C_RGET:
case C_GGET:

	/* get  screen variable */
    /* get  screen variable;x1,y1;x2,y2 */
    /* get  screen variable;file */
    /* get  screen variable;palette;data size,width,height,array */
    /* get  screen variable;rgb;data size,width,height,array */
    /* get  screen variable;in-line picture */
    
    coarsef = FALSE; /* coarse grid not allowed */
    if (newcmd == C_GET) argt = 0; /* absolute */
    else if (newcmd == C_RGET) argt = 1; /* relative */
    else if (newcmd == C_GGET) argt = 2; /* graphing */
    term = compile_txtype(TXSCREEN,TRUE);
    if (term == NEWLINE) {
    	compile_short_value(0);
    	break; /* done */
	}
	
	/* determine command type */
	/*    = 1 = coordinate form */
	/*    = 2 = file form */
	/*    = 3 = palette or rgb form */
	/*    = 4 = in-line picture


	/* check for in-line image */
	
	loc = startofline+cI;
	do {
		ii = TUTORcharat_doc(source,loc);
		if ((ii == ' ') || (ii == '\t'))
			loc++;
		else break;
	} while (TRUE);
	if (ii == PIXMAPSPECIAL) {
		if (cB[cI] == PIXMAPSPECIAL) cI++;
		skip_white_cB();
		compile_short_value(4);
		textpool_string(1L,loc);
		break; /* finish up command */
	}

	skip_white_cB(); /* skip over white space */
	if (cB[cI] == ';') { /* coordinate form, no first coordinate */
		ii = 1;
	} else {
		cii = pbscan(cB,cI,","); /* check if comma present */
    	cjj = pbscan(cB,cI,";"); /* check if semicolon present */
    	if ((cii >= 0) && (cjj >= 0)) {
    		if (cjj < cii)
    			ii = 3; /* semicolon first, must be palette form */
    		else
    			ii = 1; /* comma first, must be coordinate form */
    	} else {
    		ii = 2; /* don't have semicolon+comma, must be file */
    	}
    }
    
    if (ii == 1) { /* coordinate form */
       	compile_short_value(1);
		compile_points(2,2,argt,TRUE,FALSE,FALSE,0,coarsef,FALSE);
    } else if (ii == 2) { /* file form */
    	compile_short_value(2);
    	compile_marker(FALSE,FALSE); /* evaluate marker expr */
    } else { /* palette or rgb form */
    	compile_short_value(3);
    	cii = identify_keyword(getlist,&term);
		if (term != ';')
        	cerror(NEEDSEMI,NEARNULL);
		compile_short_value(cii); /* add keyword value */
		compile_simple_numeric(0x80,0x00,TRUE); /* data size */
    	compile_simple_numeric(0x80,0x00,TRUE); /* width */
    	compile_simple_numeric(0x80,0x00,TRUE); /* height */
    	wkexa = defexp; 
        wkexa.rtype = 0;
        wkexa.arrayok = TRUE; /* allow unindexed array */
        wkexa.reqstore = TRUE;
        compile(&wkexa); /* compile first expression */
        if (!wkexa.canstore) 
        	cerror(NOTSTORABLE,NEARNULL); 
        cii = wkexa.warray; /* TRUE if undimensioned array */
        compile_short_value(cii); /* undimensioned array flag */
        cjj = wkexa.exprtype;
        if ((cjj != TBYTE) && (cjj != TINT) && (cjj != IARRAY) &&
            (cjj != BARRAY))
            cerror(SPECIFICERR,"Must use integer or byte array.");
	} /* ii else */
    break;

case C_PUT:
case C_RPUT:
case C_GPUT:

    /* put  screen variable;x,y */
    /* put  screen variable;file */
    
    coarsef = FALSE; /* r/g forms do not allow coarse */
    if (newcmd == C_PUT) {
        argt = 0; /* absolute */
        coarsef = TRUE;
    } else if (newcmd == C_RPUT) argt = 1; /* relative */
    else if (newcmd == C_GPUT) argt = 2; /* graphing */
    term = compile_txtype(TXSCREEN,TRUE);
/* does this really need to be storeable?  */
/* if not, put in a few extra integers to keep binary compatability */

	/* determine command type */
	/* ii = 1 = coordinate form */
	/*    = 2 = file form */
	
	skip_white_cB(); /* skip over white space */
	if (cB[cI] == ';') { /* coordinate form, no first coordinate */
		ii = 1;
	} else {
		cii = pbscan(cB,cI,","); /* check if comma present */
		if (cii >= 0) ii = 1; /* comma present, must be coordinate */
		else ii = 2; /* file */
    }
    if (ii == 1) { /* coordinate form */
       	compile_short_value(1);
		compile_points(1,1,argt,TRUE,FALSE,FALSE,0,coarsef,FALSE);
    } else if (ii == 2) { /* file form */
    	compile_short_value(2);
    	compile_marker(FALSE,FALSE); /* evaluate marker expr */
    }
    break;

case C_SOUND:
    term = compile_marker(FALSE,FALSE); /* evaluate marker expr */
    if (term == ',')
        compile_simple_numeric(0x80,0x00,FALSE);
    else compile_short_value(0);
    break;

case C_ALLOC:
	lpI = pbscan(cB,cI,"("); /* find left paren */
	rpI = pbscan(cB,lpI+1,")"); /* find right paren */
	if ((lpI < 0) || (rpI < 0))
		cerror(SPECIFICERR,"Expected array(..dimensions..)");
	ii = cI; /* save current position */
	cI = rpI+1; /* set to just after right paren */
	skip_white_cB();
	if (cB[cI] != NEWLINE)
		cerror(TOOMANY,NEARNULL);
	cI = ii; /* restore position */
	cB[lpI] = ','; /* replace left paren with comma */
	cB[rpI] = ' '; /* replace right paren with space */
	
	/* first argument should now be unsubscripted array */
	
	ii = extract_keyword_cB(ws,NAMEL,FALSE,&term);
	if (ii <= 0)
		cerror(BADNAME,NEARNULL);
	ii = find_def_sym(wkSetH,ws,&fSetH,&fIndex);
	if (!ii) 
		cerror(SPECIFICERR,"Undefined array");
		
	/* get symbol definition and array descriptor */
	
	udP = (struct defset FAR *)GetPtr(fSetH);
	localSet = udP->local; /* get local define set flag */
	symP = (struct defvar FAR *)GetPtr(udP->defvarH);
	symP += fIndex; /* pointer to symbol definition */
	symDef = *symP; /* copy symbol definition */
	ReleasePtr(udP->defvarH); /* release symbol table */
	KillPtr(symP);
	ReleasePtr(fSetH); /* release define set */
	KillPtr(udP);
	if ((!symDef.dynamic) || (symDef.arrayinfo < 0))
		cerror(SPECIFICERR,"Must be dynamic array");
	uii = (localSet ? compunit: 0); /* get index in unit table */
	adsc = (struct array_desc FAR *)(descP+unittab[uii].descp+symDef.arrayinfo);
	
	/* add array description to p-codes */
	
	compile_long_value(symDef.kind); /* add int/float/txtype kind */
	compile_short_value(localSet); /* add global/local flag */
	compile_long_value(symDef.loc); /* relative addr on stack */
	compile_short_value(symDef.receive); /* add pass-by-address flag */
	
	/* compile index expressions */
	
	for(ii=0; ii<adsc->ndim; ii++) {
		term = compile_simple_numeric(0x80,0x00,TRUE); 
	} /* for */
	break;
	
case C_STYLE:
	term = compile_marker(TRUE,TRUE); /* storeable, semicolon */
	if (term != ';')
		cerror(NEEDSEMI,NEARNULL);
	compile_keyword_and_args(stylelist,&term);
	break;
	
case C_PICT:
	skip_white_cB(); /* skip over any white space */
	if (cB[cI] != NEWLINE) {
    	term = compile_marker(FALSE,FALSE); /* evaluate marker expr */
    	if (term != NEWLINE) {
    		term = compile_simple_numeric(0x80,0x00,TRUE); 
    	}
   	}
    break;
    
case C_DMA:
    break;
    
case C_SHOWZ:
case C_SHOWE:
    cmpbuf_word(wrapwrite ? C_BEGINTEXT : C_BEGINTEXT4);
    wkexa = defexp;
    wkexa.rtype = TFLOAT; /* want floating result */
    compile(&wkexa);
    compile_simple_numeric(0x180,0x00,FALSE);
    cmpbuf_word(newcmd);
    if (wkexa.exprtype != TMARK && !wrapwrite)
        addcmd = C_ENDTEXT1;
    else
        addcmd = C_ENDTEXT; /* marker show sets txt_doc to marker doc */
    break;

case C_FORGET:
	ii = compile_single_keyword(forgetlist,&term);
	compile_short_value(ii);
    compile_marker(FALSE,FALSE); 
    break;

case C_BLOCK:
	compile_numeric_array(); /* from buffer */
	term = compile_numeric_array(); /* to buffer */
	if (term != NEWLINE)
 		compile_simple_numeric(0x80,0x00,TRUE);  
	break;
	
case C_THICK:
    compile_simple_numeric(0x180,0x00,FALSE);
    break;

case C_SYSINFO:
	term = 0;
	compile_keyword_and_args(sysinfolist,&term);
	break;
	
case C_DIALOG:
	term = 0;
	compile_keyword_and_args(dialoglist,&term);
	break;
	
case C_STICKY:
    term = compile_marker(TRUE,FALSE); /* compile marker expr */
    if (term != NEWLINE)
        compile_simple_numeric(0x80,0x00,FALSE);
    else compile_short_value(-1);
	break;
	
case C_PRINT:
    compile_marker(FALSE,FALSE); /* evaluate marker expr */
    break;

case C_STEP:
	skip_white_cB();
	if (cB[cI] != NEWLINE)
		compile_simple_numeric(0x80,0x00,FALSE); /* TRUE or FALSE value */
	else compile_short_value(-1);
	break;
	
default:
    /* command not yet implemented */
    do cI--; /* position the caret */
    while (!CTisalnum(cB[cI]));
        cI++;
    cerror(NOTIMPLEMENTED,NEARNULL);

} /* switch */

} /* compile3 */

/* ******************************************************************* */

int compile_numeric_array() 

{   struct expra wkexa; /* expression analyzer params */
	int i;
	
    wkexa = defexp;
    wkexa.arrayok = TRUE; /* allow whole array */
    wkexa.reqstore = TRUE; /* get store-ability info */
    compile(&wkexa); /* compile from buffer expression */
    if (!wkexa.canstore) 
        cerror(NOTSTORABLE,NEARNULL); 
    i = wkexa.warray; /* non-zero if undimensioned */
    compile_short_value(i); /* add array flag */
	return(wkexa.lastchar);

} /* compile_numeric_buffer */

/* ******************************************************************* */

int compile_buffer_len(allow_mark) /* compile buffer or buffer,length */
int allow_mark; /* TRUE if marker expression allowed */

{	struct expra wkexa; /* scratch analyzer params */
	int markf; /* TRUE if marker expression */
	int i,j;
	int term; /* terminating character */
	
    wkexa = defexp; 
    wkexa.arrayok = TRUE; /* allow unindexed array */
    if (allow_mark) {
        wkexa.allowm = TRUE; /* allow marker expression */
        wkexa.mfunctst = FALSE; /* marker functions not store-able */
    }
    wkexa.reqstore = TRUE;
    compile(&wkexa); /* compile buffer expression */
    markf = (wkexa.exprtype == TMARK);
    i = wkexa.warray; /* TRUE if undimensioned */
    j = wkexa.lastchar != NEWLINE; /* length present flag */
	term = wkexa.lastchar;
    if (!wkexa.canstore) {
        if (j) cerror(SPECIFICERR, "Cannot specify count with an expression.");
    } /* not storeable if */

    if (i && (markf || wkexa.exprtype == MARRAY))
    	cerror(SPECIFICERR,"Can't use whole array of marker here");

    if  (j) {
        wkexa = defexp;
        wkexa.rtype =  TINT; /* get integer length */
        compile(&wkexa);
		term = wkexa.lastchar;
    } else if (!i && !markf) {
        compile_short_value(1); /* add length */    
        j = TRUE;
    }
    compile_short_value(i); /* add array flag */
    compile_short_value(j); /* add length flag */
	return(term);

} /* compile_buffer_len */

/* ******************************************************************* */

int compile_unit_and_arg() /* compile unit name and possible argument */

{   int term;
    int i;
    char ws[NAMEL+1];

    i = extract_unit(ws,&term,TRUE);
    if (i == -2) {
        if (strcmp(ws, "x") == 0)
            compile_short_value(UNITX);
        else
            cerror(MISSINGUNIT,NEARNULL);
    } else if (i == -1) /* indirect unit reference */
        cmpbuf_word(MUNIT);
    else /* normal unit ref */
        compile_short_value(i); /* add unit number */
    
    if (term == '(') {
        compile_short_value(TRUE); /* mark argument present */
        cI--; /* back up to balance parens */
	term = compile_simple_numeric(0x80,0x80,FALSE);
    } else {
        compile_short_value(FALSE); /* no arugment */
    } /* term else */

    return(term);

} /* compile_unit_and_arg */

/* ******************************************************************* */


#ifdef NosUch

int IncompleteBSE(type) /* compile incomplete button/edit/slider */
int type; /* 0 = absolute, 1 = relative, 2 = graphing */

{	int OrgcI; /* original position in cB */
	int tmpcI;
	int comaPos; /* position of first comma */
	int semiPos; /* position of first semicolon */
	int semi2Pos; /* position of second semicolon */
	int semi3Pos; /* position of third semicolon */
	int nextSep; /* next separator */
	int isBox; /* TRUE if should compile as -dot-/-box- */

	/* compile incomplete forms of button/edit/slider as dot or box */

	/* button  ; */
	/* button  ;x1,y1 */
	/* button  ;x1,y1;x2,y2 */
	/* button  button variable;x1,y1 */
	/* button  button variable;x1,y1;x2,y2 */
	
	isBox = FALSE;
	skip_white_cB(); /* skip over white space */
	OrgcI = cI;

	/* determine position of next comma, semicolon */
	
    comaPos = pbscan(cB,cI,","); /* position of comma */
    semiPos = pbscan(cB,cI,";"); /* position of semicolon */

	if ((semiPos < 0) || ((comaPos >= 0) && (comaPos < semiPos))) {
		cI = OrgcI; /* restore position */
		return(FALSE); /* treat as full command */
	}
	
    /* skip past button variable field */
    
	cI = semiPos+1; /* advance past button variable */
	skip_white_cB();
	if (cB[cI] == NEWLINE) {
		addcmd = -1; /* dummy command */
		return(TRUE);
	}
    
    /* check this isn't complete form of command */
    
    semi2Pos = pbscan(cB,semiPos+1,";"); /* check for 2nd semicolon */
    semi3Pos = nextSep = -1;
    if (semi2Pos >= 0) {
    	semi3Pos = pbscan(cB,semi2Pos+1,";"); /* check for 3rd semicolon */
    	tmpcI = cI;
    	cI = semi2Pos+1;
    	skip_white_cB();
    	nextSep = cB[cI]; /* NEWLINE if blank tag after semicolon */
    	cI = tmpcI;
    }
    	
    if (semi3Pos >= 0) {
		cI = OrgcI; /* restore position */
		return(FALSE); /* treat as full command */
    }

	if ((nextSep == NEWLINE) || (semi2Pos < 0)) { /* dot */
		isBox = TRUE;
		if (type == 0) {
    		compile_points(1,1,0,FALSE,FALSE,FALSE,1,TRUE,FALSE);
    		addcmd = C_DOT;
    	} else if (type == 1) {
    		compile_points(1,1,1,FALSE,FALSE,FALSE,1,FALSE,FALSE);
    		addcmd = C_RDOT;
    	} else if (type == 2) {
    		compile_points(1,1,2,FALSE,FALSE,FALSE,1,FALSE,FALSE);
    		addcmd = C_GDOT;
  		} else isBox = FALSE;
  	} else { /* box */
  		isBox = TRUE;
  		if (type == 0) {
    		compile_points(2,2,0,TRUE,FALSE,FALSE,0,TRUE,FALSE); 
   			addcmd = C_BOX;
		} else if (type == 1) {
    		compile_points(2,2,1,TRUE,FALSE,FALSE,0,FALSE,FALSE); 
 			addcmd = C_RBOX;
 		} else if (type == 2) {
    		compile_points(2,2,2,TRUE,FALSE,FALSE,0,FALSE,FALSE); 
    		addcmd = C_GBOX;
    	} else isBox = FALSE;
  	}
  	
  	if (isBox)
  		return(TRUE);
  		
	cI = OrgcI; /* restore position */
	return(FALSE);
	
} /* IncompleteBSE */

#endif

/* ******************************************************************* */
