
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University. */

/* ******************************************************************* */

/* code generation subroutines for Macintosh/SE and Macintosh-II */

#include "compile.h"
#include "ctutor.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "exprdefs.h"
#include "yacc.h"

#ifdef ctproto
extern int TUTORtrace(char *s);
int  cerror(int  errnumber,char  *execstr);
int  TUTORfree_handle(unsigned int  mm);
int  killptr(char  FAR * FAR *ptr);
extern char *TUTORrealloc(char *pp,long oldLen, long newLen, int abort);
int  cmpbuf_flt(double  d);
int  cmpbuf_word(int  n);
int  cmpbuf_plant_word(unsigned int  addr,int  n);
int  cmpbuf_long(long  nn);
int  cmpbuf_xref(int  kind,int  label);
int  tstaa(int  opc);
int  tstga(int  opc);
int  tstpa(int  opc);
extern int TUTORdump(char *s);
int  efunctna(int  cd);
extern int TUTORblock_move(char FAR *s1,char FAR *s2,long nn);
extern int TUTORset_hsize(Memh mm,long newSize, int abort);
extern int TUTORdealloc(char *ptr);
extern int ReleasePtr(Memh mm);
int  xref_close(void);
int sprintf(char *ss, char *form,...);
extern int TUTORlog(char *s);
extern int TUTORtrace_n(char *s,long nn);
int compile_command(short FAR *pcodeB, short FAR *pcodeP, short FAR *pcodeC);
extern int TUTORzero(char FAR *zp, long len);
int  xref_open(int  unitn);
long  TUTORget_hsize(unsigned int  mm);
extern char *TUTORalloc(long len, int abort, char *label);
extern int icgen(void);
int UnitCodegen(int unitn);
int  check_descriptors(void);
extern char *GetPtr(Memh mm);
unsigned short FAR *next_ptoken(unsigned short FAR *pcodeP);
int build_token_table(unsigned short FAR *pcodeB, unsigned short FAR *pcodeP);
int assign_registers(unsigned short FAR *pcodeB);
int pick_general(int opindx);
int gen_code_token(short FAR *pcodeB, short FAR *pcodeP, int tii, long cmpIB);
int gen_code_command(short FAR *pcodeB, short FAR *pcodeP, int tii, long cmpIB);
int must_interpret(int code);
int cvt_subr(int code);
struct toktab FAR *find_operand(struct toktab FAR *tokP, int opi);
int in_general_reg(struct toktab FAR *tokP, int rscr);
int reg_num(int rn);
int reg_src_mode(int rn);
int reg_dest_mode(int rn);
int gen_movl(int srn, int srm, int drn, int);
int gen_movw(int srn, int srm, int drn, int drm);
int gen_movb(int srn, int srm, int drn, int drm);
int gen_stackf(int arn);
int gen_roe(int cod, int rn, int om, int drn, int drm);
int gen_subrxx(int opc);
int gen_storinf(int type);
int init_volatile(void);
int gen_begin(void);
int gen_end(void);
int gen_xerr(void);
int gen_ra3_none(void);
int gen_ra3_update(void);
int gen_ra3_int(void);
int gen_ra3_float(void);
int gen_ra2_globals(void);
int gen_ra2_locals(void);
int gen_ra1_ra2_gvar(long addr);
int gen_ra1_ra2_lvar(long addr);
int gen_var(long addr, int rn, int size);
int gen_ra0_table(int index);
#endif /* ctproto */

#ifdef macproto

#endif

#ifdef MAC

/* ******************************************************************* */

#define long_read(addr) (*(long SHUGE *)(addr))
#define flt_read(addr) (*(double SHUGE *)(addr))

unsigned short FAR *next_ptoken();
struct toktab FAR *find_operand();

/* ******************************************************************* */

/* register definitions/tables for 68000 */

#define r_d0 0 /* base of general registers */
#define r_a0 8 /* base of address registers */
#define r_68stack 15 /* a7 = stack used by C code */
#define r_result 16 /* psuedo register for result stack */
#define r_max 17 /* length of register table */

/* operator/routine types */

#define or_general 1	/* general operands, general result */
#define or_subrxx 2		/* subroutine, args on xstack, result on xstack */
#define or_ibarray 3	/* indexed int/byte array, args in gen reg or xstack */
#define or_ibassign 4	/* int/byte assign, args in gen reg or xstack */
#define or_operandx 5	/* operand, result on stack */

/* register types */

#define rt_general 1 	/* general purpose register */
#define rt_temp 2		/* scratch register */
#define rt_reserv 3		/* reserved or unuseable register */
#define rt_result 4		/* psuedo register type for result stack */

/* register type (general, reserved, etc) table */

char r_type[r_max] = { 
	rt_temp,    /* d0 */
	rt_temp,    /* d1 */
	rt_temp,    /* d2 */
	rt_general, /* d3 */
	rt_general, /* d4 */
	rt_general, /* d5 */
	rt_general, /* d6 */
	rt_general, /* d7 */
	rt_temp,    /* a0 = temp, frequently pointer in exs_addr */
	rt_temp,    /* a1 = temp, frequently pointer to variable */
	rt_reserv,  /* a2 = pointer to globals or locals */
	rt_reserv,  /* a3 = pointer to integer or floating results stack */
	rt_reserv,  /* a4 = pointer to mach_addr table of pointers */
	rt_reserv,  /* a5 = reserved by Think-C */
	rt_reserv,  /* a6 = reserved by Think-C */
	rt_reserv,  /* a7 = 68000 stack */
	rt_result   /* psudeo register = expression stack */
}; /* r_type */

static int ra4_table;   /* TRUE if a4 set to point to mach_addr */
static int ra3_int;     /* TRUE if a3 set to point to integer results */
static int ra3_float;   /* TRUE if a3 set to point to floating results */	
static int ra2_locals;  /* TRUE if a2 set to point to local variables */
static int ra2_globals; /* TRUE if a2 set to point to global variables */
static long ra1_gvars; /* -1 = a1 not pointer in global variables */
                       /* +n = a1 = global variable address */
static long ra1_lvars; /* -1 = a1 not pointer in local variables */
                       /* +n = a1 = local variable address */
static int ra0_table;  /* -1 = a0 not pointer in mach_addr */
                       /* +n = a0 = mach_addr address */

static short r_inuse[r_max]; /* register in-use table */
static char r_used[r_max]; /* register ever-used table */

struct toktab { 
	short code; 		/* operator/operand code */
	unsigned short rel;	/* relative position of token in p-code */
	short op;			/* position/id of operator on this token */
	short reg; 			/* register assigned to this token */
	short dreg;			/* register expected at branch destination */
	short deferi; 		/* index of op to make deferred reg assignment */
	short deferf;		/* TRUE if this op must satisfy deferred reg */
	unsigned short store;   /* position/id of storinf token */
}; /* toktab */

struct movem {
	short type;	/* 0 = movem.l registers,-(sp) */
	            /* 1 = movem.l (sp)+,registers */
	unsigned short addr; /* address of register mask */
}; /* movem */

static int toktabN; /* number tokens in token table */
static struct toktab FAR *toktabP = NULL; /* pointer to token table */
static unsigned short FAR *tokstakP = NULL; /* pointer to token stack */
static int toktab_store; /* -4 = address of store item in store_addr */
                         /* -3 = address of store item in a1 */
                         /* -2 = address of store item on 68000 stack */
                         /* -1 = no store/type info yet */
                         /* +n = index of store item in token table */
static int toktab_xerr; /* TRUE if any token in table can exec err */
static int xrefri;  /* index of next reference in xref table */   
static int xrefli;	/* index of next label in xref table */
static int xreflen; /* lenght of xref table */
static unsigned short FAR *newdestP = NULL; /* branch destinations */  
static int srbiN; /* number entries in map */
static int srbii; /* index in source <-> binary map */
static int movemN; /* number of movem.l instructions to plant */
static int movemL; /* size of movemaskP table */
static struct movem FAR *movemP = NULL; /* movem.l instructions */
static int loopstkN; /* depth in loop stack */
static unsigned short loopstk[MAXINDENTS]; /* loop head stack */
static unsigned short looptyp[MAXINDENTS]; /* loop type stack */
static int ibranchf; /* TRUE if BRANCHT/BRANCHF should produce code */  
                     /* FALSE if already handled by IEQ, etc. */
static int loopbegf; /* TRUE if at begin of loop */
static int loopendf; /* TRUE if at end of loop */
static int casestkN; /* depth in case stack */
static unsigned short casestk[MAXINDENTS]; /* case type stack */
static int incode; /* TRUE if currently in a block of compiled code */ 
static long storinf_kind; /* kind of last storinf */
static long gdescp; /* base of descriptors for globals */
static long udescp; /* base of descriptors for this unit */

extern int PowerPC;

extern int breakpt(void);

/* ******************************************************************* */

UnitCodegen(unitn) /* compile machine code for unit */
int unitn;

{	unsigned short FAR *pcodeP; /* pointer to pcode */
	unsigned short FAR *pcodeC; /* base of command in pcode */
	unsigned short FAR *pcodeB; /* base of pcode */
	unsigned char FAR *pc; /* pointer to pcode */
	unsigned char FAR *machP; /* pointer to machine-code binary of unit */
	int code; /* next command/expr code */
	int siz; /* size of next expr code */
	int token; /* current command/expression code */ 
	long len; /* length of xrefs or xdests table */
	struct locref swap;
	int sortf; /* continue sort flag */
	struct locref FAR *tpt; /* pointer in value/address table */
	long asrc; /* branch source */
	long adest; /* branch destination */
	int dlabel; /* destination label */
	int low,high,dii; /* indexes for binary chop search */
	int ndesti; /* index in new destinations table */
	long relbra; /* relative branch value */
	int errabt; /* TRUE if error aborted compile */
	int ii; /* index in value/address table */

	if (unittab[unitn].pcodeOrgH == HNULL) return; /* no binary */	
	if ((3*unittab[unitn].pcodeOrgL) > CMPBUFC)
		return; /* don't compile - too big */
	errabt = FALSE; /* no error yet */

if (unitn == 88)
breakpt();	
	/* set up token table, token stack and movem.l table */
	
	if (toktabP == NULL) {
		toktabP = (struct toktab FAR *)TUTORalloc(
		          (long)(EX_STACKL*sizeof(struct toktab)),TRUE,"toktab");
		tokstakP = (unsigned short FAR *)TUTORalloc((long)(EX_STACKL*sizeof(short)),
		            TRUE,"tokstk");
		movemL = 10; /* initialize table length */
		movemP = (struct movem FAR *)TUTORalloc((long)(movemL*sizeof(struct movem)),
		          TRUE,"movem");
	} /* toktab if */	 
	if ((!toktabP) || (!tokstakP) || (!movemP))
		return;
			
	/* aquire pointer to expression compiler table */

	if (!xtP)
		xtP = (struct exprt FAR *) GetPtr(xtH);

	/* get pointer to array descriptors */
	
	if (descP == NULL) /* get pointer to descriptors pool */
		descP = GetPtr(descH);
	gdescp = unittab[0].descp; /* base of descriptors for globals */
	udescp = unittab[unitn].descp; /* base of descriptors for unit */

	/* set up cmpbuf for machine-code form of unit binary */
	
	if (!cmpLocked) {
		cmpbuf = (unsigned char FAR *)GetPtr(cmpH);
		cmpLocked = TRUE;
	} /* cmplocked */
	cmpl = 0; /* no code yet */

	/* get pointer on source <-> binary table */
	
	if (srbimapH) {
		ReleasePtr(srbimapH);
		KillPtr(srbimapP);
	}
	srbiN = 0;
	srbimapH = unittab[unitn].srcbinmap;
	if (srbimapH) {
		srbimapP = (struct srbimap FAR *)GetPtr(srbimapH);
		srbiN = TUTORget_hsize(srbimapH)/sizeof(struct srbimap);
	}
	srbii = 0; /* initialize index in source <-> binary map */

	/* initialize reloc/kind fields in refs */
	
	xref_open(unitn); /* get ptrs to tables */
	xreflen = unittab[unitn].nrefs; /* length of jump src/dest table */
	for(ii=0; ii<xreflen; ii++) {
		xrefP[ii].reloc = 0; /* unit relative */
		xrefP[ii].kind &= 0x7f; /* clear upper (satisfied) bit */
	}
	
	/* sort cross-reference table by source address */
	/* (should be mostly in order already) */
	
	do {
		sortf = FALSE; /* pre-set to terminate bubble sort */
		for(ii=1; ii<xreflen; ii++) {
			tpt = &xrefP[ii];
			if ((tpt-1)->aref > tpt->aref) {
				swap = *(tpt-1);
				*(tpt-1) = *tpt;
				*tpt = swap;
				sortf = TRUE; /* continue sort */
			} /* values if */
		} /* for */
	} while (sortf);

	/* set up table for new destinations */
	
	len = xreflen*sizeof(short);
	newdestP = (unsigned short FAR *)TUTORalloc(len,TRUE,"ndest");
	TUTORzero((char FAR *)newdestP,len); /* pre-zero table */
	xrefri = xrefli = 0; /* indexes in cross-reference tables */
	
	/* initialize registers-used */
	
	for(ii=0; ii<r_max; ii++) {
		r_used[ii] = FALSE;
	}
	movemN = 0; /* number movem.l instructions to plant */
	loopstkN = 0; /* no -loop- stack yet */
	incode = FALSE; /* not in compiled code */
	ibranchf = TRUE; /* assume will compile next branch */
	loopbegf = loopendf = FALSE; /* not in loop */
	casestkN = 0; /* no -case- stack yet */
	
	/* loop thru commands in this unit */
	
	pcodeB = (unsigned short FAR *)GetPtr(unittab[unitn].pcodeOrgH);
	pcodeP = pcodeC = pcodeB;
	do {
		token = *pcodeP;
		if (token >= C_MIN) {
			
			/* process next command */
				
			compile_command((short FAR *) pcodeB,(short FAR *) pcodeC,(short FAR *) pcodeP);
			pcodeC = pcodeP+1; /* set base for next command */
			
			/* check for compile buffer overflow */
			
			if (cmpl > CMPBUFC) { /* must abort - unit too big */
				errabt = 1; /* 1 = unit too big */
				break; /* exit while */
			}
				
		}
		pcodeP = next_ptoken(pcodeP);
	} while (token != C_ENDUNIT); 
	
	if (!errabt) {
	
		/* satisfy branch addresses within unit */
		
		for(ii = 0; ii < xreflen; ii++) {
		
			/* check if reference (not label) */
			
			if (xrefP[ii].aref && (xrefP[ii].kind < RD_MIN)) {
			
				/* find destination of this reference */
				
				adest = xrefP[ii].adest;
				dlabel = xrefP[ii].label;
				for(ndesti = 0; ndesti < xreflen; ndesti++) {
					if ((xrefP[ndesti].kind >= RD_MIN) &&
					    (xrefP[ndesti].aref == adest) &&
					    (xrefP[ndesti].label == dlabel)) {
						asrc = xrefP[ii].aref;
#ifdef NoSuch
 sprintf(msg,"reference to %x at %x\n",(int)newdestP[ndesti],(int)asrc);
	TUTORlog(msg); 
#endif
						if (xrefP[ii].reloc)
							relbra = newdestP[ndesti]-asrc; /* pc relative */
						else 
							relbra = newdestP[ndesti]; /* unit relative */
						cmpbuf[asrc] = (relbra >> 8) & 0xff;
						cmpbuf[asrc+1] = relbra & 0xff;
						break; /* exit ndesti for */
					} /* kind/ref if */
				} /* ndesti for */
#ifdef Nosuch
	if (ndesti >= xreflen) {
		sprintf(msg,"want label %d ref type %d\n",dlabel,xrefP[ii].kind);
		TUTORlog(msg);
		sprintf(msg,"didn't find dest %lx at %lx\n",(long)adest,(long)asrc);
		TUTORlog(msg);
	}
#endif
			} /* xrefP if */
		} /* ii for */

#ifdef Nosuch
for(ii=0; ii<xreflen; ii++) {
	sprintf(msg,"%d ref %x dest %x kind %d nd %x label %d\n",ii,xrefP[ii].aref,
	        xrefP[ii].adest,xrefP[ii].kind,newdestP[ii],xrefP[ii].label);
	TUTORlog(msg); 
} /* for */
#endif


	} /* errabt if */

	/* release handles, set up new unit handle for machine code */
	
	xref_close(); /* release handles */
	if (srbimapH) {
		ReleasePtr(srbimapH); /* release source <-> binary map */
		KillPtr(srbimapP);
		srbimapH = HNULL;
	}
	TUTORdealloc((char FAR *) newdestP); /* release branch destination table */
	ReleasePtr(descH); /* release descriptors table */
	KillPtr(descP);
	descP = NULL;
	ReleasePtr(unittab[unitn].pcodeOrgH); /* release pcode */
	KillPtr(pcodeB);
	ReleasePtr(cmpH); /* release cmpbuf */
	KillPtr(cmpbuf);
	cmpLocked = FALSE;
	if (!errabt) {
		if (unittab[unitn].pcodeExecH)
			TUTORfree_handle(unittab[unitn].pcodeExecH);
		unittab[unitn].pcodeExecH = TUTORhandle("pcode c ",(long)cmpl,TRUE);
		if (!unittab[unitn].pcodeExecH)
			errabt = TRUE; /* out of memory */
	}
	if (errabt) { /* something went wrong with compile */
		unittab[unitn].haserrors = TRUE;
		TUTORfree_handle(unittab[unitn].pcodeOrgH); /* release pcode handle */
		unittab[unitn].pcodeOrgH = HNULL;
		cerror(SPECIFICERR,"Out of memory or unit too big.");
	} else {
		pc = (unsigned char FAR *)GetPtr(unittab[unitn].pcodeExecH);
		cmpbuf = (unsigned char FAR *)GetPtr(cmpH);
		TUTORblock_move((char FAR *) cmpbuf,(char FAR *) pc,(long)cmpl);
		ReleasePtr(cmpH); /* release cmpbuf */
		KillPtr(cmpbuf);
		ReleasePtr(unittab[unitn].pcodeExecH); /* release unit pcode */
		KillPtr(pc);
		unittab[unitn].pcodeExecL = cmpl; /* set length of unit code  */
	} /* errabt else */
	
} /* UnitCodegen */

/* ******************************************************************* */

static compile_command(pcodeB,pcodeP,pcodeC) /* compile code for next command */
short FAR *pcodeB; /* ptr to base of pcode */
short FAR *pcodeP; /* ptr to start of command tokens in pcodes */
short FAR *pcodeC; /* ptr to command code */

{	long cmplB; /* base of compiled code for command */
	int ii;
	char msg[80];
	struct toktab FAR *tP; 

	/* set up token table for next command */
	
	build_token_table((unsigned short FAR *) pcodeB, (unsigned short FAR *) pcodeP); /* build token table for expressions */
	assign_registers((unsigned short FAR *) pcodeB);

#ifdef NoSuch
tP = toktabP;
for(ii=0; ii<toktabN; ii++) {
	sprintf(msg,"%d code %d rel %d op %d st %d reg %d dreg %d defri %d defrf %d\n",ii,tP->code,tP->rel,
	        tP->op,tP->store,tP->reg,tP->dreg,tP->deferi,tP->deferf);
	TUTORlog(msg); 
	tP++;
} /* for */
#endif


	/* generate code for expression(s) */
	
	toktab_store = -1;
	cmplB = cmpl; /* base of compiled code for command */
	for(ii=0; ii<toktabN; ii++) 
		gen_code_token(pcodeB,pcodeP,ii,cmplB);
	
} /* compile_command */	                     		
	
/* ******************************************************************* */

static build_token_table(pcodeB,pcodeP) /* build token table for next command */
unsigned short FAR *pcodeB; /* base of unit in pcodes */
unsigned short FAR *pcodeP; /* start of command tokens in pcodes */

{	unsigned char FAR *ppc; /* char pointer in pcode */
	struct toktab FAR *tP; /* pointer in token table */
	unsigned short FAR *tsP; /* pointer in working stack */
	struct array_desc FAR *pda; /* pointer to array descriptor */
	long adescp; /* bias to this array in descriptors */
	int opc; /* current operator/operand code */
	short asgopr; /* id/loc of assigned operand */
	unsigned short operand; /* id/loc of operand */
	int nargs; /* number arguments of operator */
	int tii; /* index in token table */
	int ii;
	
	toktabN = 0; /* initialize index in token table */
	tP = toktabP; /* initialize pointer in token table */
	tsP = tokstakP; /* initialize pointer in token stack */
	toktab_store = -1; /* haven't found store-able yet */
	toktab_xerr = FALSE; /* TRUE if this command can exec err */
	tii = 0; /* initialize index in token table */
	
	while (*pcodeP < C_MIN) { /* continue till hit next command */
		ppc = (unsigned char FAR *)pcodeP;
		tP->code = opc = *pcodeP; /* operator/operand code */
		tP->rel = pcodeP-pcodeB; /* relative position of op/arg */
		tP->op = -1; /* no operator on this token yet */
		tP->reg = tP->dreg = -1; /* no register assigned yet */
		tP->deferi = -1; /* no deferred reg assignment yet */
		tP->deferf = FALSE;
		tP->store = 0; /* no store-ability info yet */
		if (cmd_err_tab[opc]) 
			toktab_xerr = TRUE; /* command can exec err */
			
		if (xtP[opc].op) {
		
			/* process operator */
			
			if (xtP[opc].unary) nargs = 1; /* unary operator */
			else if (xtP[opc].trinary) { 
				if (opc == EFUNCT) /* EFUNCT may be unary, binary, trinary */
					nargs = efunctna(*(pcodeP+1)); 
				else nargs = 3; /* trinary operator */
			} else nargs = 2; /* binary operator */
			
			/* pop operands and identify as operands of this operator */
			
			for(ii=0; ii<nargs; ii++) {
				operand = *(--tsP); 
if (tsP < tokstakP) {
	TUTORdump("underflow working stack 1");
}
				toktabP[operand].op = tii;
			} /* for */	
			*tsP++ = tii; /* push result */
		} else {
		
			/* process operand */
			
			if ((xtP[opc].local >= 0) || (opc == MSYSVAR)) {
				toktab_store = tii; /* index of possible store-able */
			} 
			
			if (xtP[opc].array == 1) { /* process indexed array */
				
				/* pick up array dimensions */

				adescp = (tstga(opc) ? gdescp: udescp);
				pda = (struct array_desc FAR *)(descP+adescp+*(pcodeP+3));
				if (tstaa(opc)) /* check for assignment to array */
					asgopr = *(--tsP);
				else asgopr = -1;			

				/* set operated-on field for indexes */

				for (ii=1; ii<=pda->ndim; ii++){
					operand = *(--tsP); 
					toktabP[operand].op = tii; 
if (tsP < tokstakP) {
	TUTORdump("underflow working stack 2");
}
				} /* for */

				if (asgopr >= 0) /* push assigned operand back on stack */
					*tsP++ = asgopr; 
			} else if (opc == STORINF) { /* process store-ability info */
				if (*(pcodeP+5)) { /* if store-able */
					if (toktab_store >= 0) {
						/* this operand must produce store-able info */
						toktabP[toktab_store].store = tii;
					}
				} /* pcodeP if */
				toktab_store = -1; /* re-set for next storinf */
			} /* storinf else */
			*tsP++ = tii; /* push result on working stack */
		} /* operand else */
		
		tP++; /* advance pointer in token table */
		tii++; /* advance index in token table */
		toktabN++; /* increment number table entries */	
		pcodeP = (unsigned short FAR *)next_ptoken(pcodeP); /* advance to next token */

	} /* while */
	
	/* add command to token table */
	
	tP->code = opc = *pcodeP; /* operator/operand code */
	tP->rel = pcodeP-pcodeB; /* relative position of cmd */
	tP->op = -2; /* no operator on command token */
	tP->reg = tP->dreg = -1; /* no register assigned */
	tP->deferi = -1; /* no deferred reg assignment */
	tP->deferf = FALSE;
	tP->store = 0; /* no store-ability info */
	if (cmd_err_tab[opc]) 
			toktab_xerr = TRUE; /* command can exec err */
	toktabN++; /* increment number table entries */
	
} /* build_token_table */

/* ******************************************************************* */

static unsigned short FAR *next_ptoken(pcodeP) /* find next token in p-code */
unsigned short FAR *pcodeP; /* pointer to pcode */

{	unsigned char FAR *pc; /* pointer to pcode */
	int code; /* next command/expr code */
	int siz; /* size of next expr code */
	int len; /* length of text */
	int min,max; /* limits of -case- table */

	code = *pcodeP; /* get current token */

	if (code >= C_MIN) {
	
		/* process command code */
		
		return(pcodeP+1);
	} else {

		/* process expression token */

		siz = xtP[code].sgenv; /* additional bytes of pcode */
		pc = (unsigned char FAR *)pcodeP;
		pc += 2; /* advance past code */

		switch (siz) {

		case -1: /* array */
			pc += sizeof(long)+sizeof(short); /* addr */
			break;

		case -2: /* whole (unsubscripted) array */
			pc += 3*sizeof(long); /* type, address, length */
			break;

		case -3: /* floating value */
			pc += sizeof(double);
			break;

		case -4: /* table of unit locations */
			pc += (*(pcodeP+1)*sizeof(short))+sizeof(short);
			break;
				
		case -5: /* complex text */
			pc += 2*sizeof(long); /* address, length */
			break;

		case -6: /* in-line text */
			len = *(pcodeP+1); /* length of text */
			if (len & 1) len++;
			pc += len+2; /* advance past following text */
			break;
			
		case -7: /* -case- command table */
			min = *(short *)(pcodeP+1); /* minimum value of table */
			max = *(short *)(pcodeP+2); /* maximum value of table */
			len = 2*sizeof(short)+((1+max-min)*sizeof(short));
			pc += len; /* advance past table */
			break;

		default:
			pc += siz; /* increment for following bytes */
			break;

		} /* switch */
		return((unsigned short FAR *)pc); /* return new pcode pointer */

	} /* expression else */

} /* next_ptoken */

/* ******************************************************************* */

static assign_registers(pcodeB) /* register assignments for tokens */
unsigned short FAR *pcodeB; /* start of tokens in pcodes */

{	struct toktab FAR *tP; /* pointer in token table */
	short operator; /* id/loc of operator, -1 if no operator */
	struct array_desc FAR *pda; /* pointer to array descriptor */
	unsigned short FAR *brelp; /* pointer to relative branch address */
	long brel; /* relative branch address */
	struct toktab FAR *dtP; /* ptr to branch destination table entry */
	long adescp; /* index of this array in descriptors */
	int opc; /* operator code */
	int lastx; /* index of last expression code */
	int tii; /* index in token table */
	int rii; /* index in register table */
	int drii; /* index in register table */
	int aopc; /* op code of assign operand */
	int amdim; /* TRUE if assign to multi-dimensional array */
	int ii;

	/* initialize register used and in-use tables */
	
	for(ii=0; ii<r_max; ii++) {
		r_inuse[ii] = -1;
	} /* for */
	r_used[r_a0+4] = TRUE; /* a4 = pointer to mach_addr table */	
	r_used[r_a0+3] = TRUE; /* a3 = pointer to results table */
	
	tP = toktabP; /* pointer in token table */
	lastx = toktabN-1; /* end test for last code before command */
	toktabP[lastx].reg = r_result; /* pre-assign last result to stack */
	for(tii=0; tii<lastx; tii++) {
		operator = tP->op; /* operator on this token */
		if (operator < 0) {
		
			/* operator on this token is command */
			
			tP->op = lastx; 
			rii = r_result; /* assume final result on stack */
			opc = toktabP[lastx].code; /* get command code */
			
			/* assign registers for conditional branch */
			
			if ((opc == C_BRANCHT) || (opc == C_BRANCHF)) {
				if (toktabP[tii].code == ULOCADDR) 
					rii = r_d0; /* branch address to d0 */
				else rii = pick_general(lastx); /* find general reg */
			} 
			
			/* assign register for integer calc */
			
			else if (opc == C_ICALC) {
			
				/* find register assigned value is in */
				
				rii = -1; /* no register yet */
				for(ii=lastx; ii>=0; ii--) {
					if (toktabP[ii].op == tii) {
						dtP = toktabP+ii;
						if (!xtP[dtP->code].isaddr) {
							if (r_type[dtP->reg] == rt_general)
								rii = dtP->reg; /* use value reg */
						} /* isaddr if */
					} /* op if */
				} /* for */
					
				/* pick register if didnt find value */
				
				if (rii < 0) 
					rii = pick_general(lastx);
			} 
			
			/* assign register for integer iterative loop */
			
			else if ((opc == C_ICLOOPINIT) || (opc == C_ICLOOPINC)) {
				if (tP->store || (tP->code == ULOCADDR) || 
				   (tP->code == STORINF)) 
					rii = r_result;
				else 
					rii = pick_general(lastx);
			}
		} else {
			
			/* flag a2 used for global/local variable */
			
			if (xtP[tP->code].local >= 0) 
				r_used[r_a0+2] = TRUE;
			
			/* assign result register for operand/operator */
			
			opc = toktabP[operator].code;
			switch (xtP[opc].cgen) {

			case or_general: 
				rii = pick_general(operator);
				break;
				
			case or_subrxx:
				rii = r_result;
				break;
	
			case or_ibarray:
			
				/* single dimensional array in register, else */
				/* indexes on stack for subroutine */
				
				adescp = (tstga(opc) ? gdescp: udescp);
				pda = (struct array_desc FAR *)
				      (descP+adescp+*(pcodeB+toktabP[operator].rel+3));
				if (pda->ndim == 1) {
					rii = pick_general(operator);
				} else rii = r_result; 
				break;

			case or_ibassign:
			
				/* integer/byte assign wants value in gen reg, */
				/* address in a1 */
				
				if (xtP[tP->code].isaddr) rii = r_a0+1;
				else rii = pick_general(operator);
				break;
				
			case or_operandx:
				rii = r_result; /* result on stack */
				break;
				
			default: /* not implemented */
				break;
			} /* cgen switch */
		} /* operator else */
		tP->reg = rii; /* assign register to token */
		
		/* handle internal branch: if branch is taken source must */
		/* set up registers as expected at destination */
		
		if (tP->deferf) {
			for(ii=0; ii<tii; ii++)
				if (toktabP[ii].deferi == tii)
					toktabP[ii].dreg = rii;
		} /* deferf if */
		
		if ((tP->code == IBRANCHT) || (tP->code == IBRANCHF)) {
			brelp = pcodeB+tP->rel+1; /* ptr to relative branch addr */
			brel = (*brelp)/sizeof(short); 
			
			/* locate token at branch destination */
			
			dtP = toktabP; /* pointer in token table */
			while (dtP->rel != brel) dtP++;
			dtP--; /* back up to $and$/$or$/=/etc */
			dtP->deferf = TRUE; /* assign register later */	
			tP->deferi = dtP-toktabP; /* index of op to assign register */
			if (r_type[rii] == rt_general) {
			
				/* mark register in use by later token */
				
				r_inuse[rii] = dtP-toktabP;
			}
		} /* tP->code if */
			
		/* release registers used by previous operators */
		
		for(rii=(r_d0+3); rii<(r_d0+8); rii++) {
			if (r_inuse[rii] < tii) 
				r_inuse[rii] = -1; /* release register */
		}
		
		tP++; /* advance to next table entry */
	} /* tii for */
	
} /* assign_registers */

/* ******************************************************************* */

static int pick_general(opindx) /* find general register */
int opindx; /* index of operator requiring this register */

{	int ri; /* index in register table */

	for(ri=(r_d0+3); ri<(r_d0+8); ri++) {
		if ((r_type[ri] == rt_general) && (r_inuse[ri] == -1)) {
			r_inuse[ri] = opindx; /* mark this register in use */
			r_used[ri] = TRUE; /* mark this register used */
			return(ri); /* return index of this register */
		} /* opindex if */	
	} /* for */
	return(r_result); /* store on expression stack */
	
} /* pick_general */

/* ******************************************************************* */

gen_code_token(pcodeB,pcodeP,tii,cmplB) /* generate machine code for token */
short FAR *pcodeB; /* base of pcodes for unit */
short FAR *pcodeP; /* start of tokens in pcodes */
int tii; /* index of token in toktab */
long cmplB; /* base of compiled code for this command */

{	struct toktab FAR *tP; /* pointer in token table */
	struct exprt FAR *xtPTR; /* pointer in definitions (xtP[]) table */
	struct toktab FAR *op1; /* pointer to 1st operand in token table */
	struct toktab FAR *op2; /* pointer to 2nd operand in token table */
	int rn1; /* register number of 1st operand */
	int rn2; /* register number of 2nd operand */
	int tdrn; /* temporary destination register number */
	int drn; /* final destination register number */
	int irn; /* register number of array index */
	int code; /* operator/operand code */
	int ncode; /* next operator/operand code */
	long urel; /* position of token relative to unit */
	long ivalue; /* integer value associated with operand */
	double fvalue; /* floating value associated with operand */
	short FAR *oaddr; /* address associated with operand */
	unsigned char FAR *pcP; /* char pointer in pcode, descriptors */
	struct array_desc FAR *pda; /* pointer to array descriptor */
	struct dim_desc FAR *pdd; /* pointer to dimension description info */
	long adescp; /* index of this array in descriptors */
	short FAR *stP; /* pointer to storinf token in pcode */
	long FAR *ltP; /* pointer to storinf data */
	unsigned short word; /* machine word */
	int subrii; /* index of subroutine to call */
	int min,max; /* minimum/maximum for -case- table */
	int aii; /* index of value assigned to array */
	int aopc; /* op code of value being assigned */
	int ii;
	long FAR *lwP;
	char msg[80];

	tP = toktabP+tii; /* address of table entry */
	code = tP->code;

	/* check if have advanced to next source line */
		
	urel = tP->rel*sizeof(short); /* byte location relative to unit */
	while ((srbii < srbiN) && (urel >= srbimapP[srbii].binr)) {
		srbimapP[srbii].binr = cmpl; /* new address in binary */
		srbii++;
	}
	
	/* advance to next internal label */
	
	while ((xrefli < xreflen) && (xrefP[xrefli].kind < RD_MIN)) 
		xrefli++;
		
	/* advance to next reference to internal label */
	
	while ((xrefri < xreflen) && (xrefP[xrefri].kind >= RD_MIN))
		xrefri++;
			
	/* check if label at this point in binary */
	
if ((xrefli < xreflen) && (urel > xrefP[xrefli].aref)) {
	sprintf(msg,"missed xref: %d kind %d ref %x dest %x label %d urel %x",
		xrefli,xrefP[xrefli].kind,xrefP[xrefli].aref,xrefP[xrefli].adest,
		xrefP[xrefli].label,(int)urel);
	TUTORdump(msg);
}
	while ((xrefli < xreflen) && (xrefP[xrefli].kind >= RD_MIN) && 
	    (urel == xrefP[xrefli].aref)) {

		switch(xrefP[xrefli].kind) {
		
		case RD_ELSE:
		case RD_ELSEIF:
		case RD_ENDIF:
		case RD_COND1: /* conditional command end */
		case RD_COND3: /* conditional command clause */
		case RD_CLAUSE: /* -case- command clause */
		case RD_CLAUSEB: /* -case- command clause body */
		case RD_CASEELSE:
		case RD_ENDCASE:
		case RD_LOOP1: /* body of loop */
		case RD_LOOP2: /* end of loop */
		case RD_EXPRES:
			if (incode) gen_ra3_update(); /* bring stack ptr up to date */
			gen_begin(); /* must be in compiled code */
			init_volatile(); /* volatile registers uncertain */
			newdestP[xrefli++] = cmpl; /* addr is in compiled code */	
			gen_xerr(); 
			break;
			
		case RD_LOOP3: /* top of loop */
			if (incode) gen_ra3_update(); /* bring stack ptr up to date */
			gen_begin(); /* must be in compiled code */
			init_volatile(); /* volatile registers uncertain */
			newdestP[xrefli++] = cmpl; /* addr is in compiled code */
			gen_xerr(); 
									
			/* generate code to handle interrupt */
			
			gen_subrxx(LOOPCHK);
			cmpbuf_word(0x4a40); /* tst.w d0 */
			cmpbuf_word(0x671e); /* beq *+1e */
			gen_end(); /* end this block of compiled code */
			/* generate interpreted command to handle interrupt */
			cmpbuf_word(C_SLICE); 
			gen_begin(); /* begin a new block of compiled code */
			gen_xerr(); 
			break;
			
		case RD_COND2: /* conditional command table */
		case RD_CASET: /* -case- command table */
			if (!incode) gen_begin(); /* insure state before label */
			gen_xerr();
			newdestP[xrefli++] = cmpl; /* addr of table */
			break; 
		
		case RD_PREANS: /* -answer- command begin */
		case RD_ENDANS: /* -answer- command end */
		case RD_IFMATCH:
		case RD_ENDARROW:
		case RD_ARROW:
			gen_end(); /* must be in interpreted code */
			newdestP[xrefli++] = cmpl; /* addr is in interpreted code */
			break;
				
		} /* switch */
		
		/* advance to next internal label */
	
		while ((xrefli < xreflen) && (xrefP[xrefli].kind < RD_MIN)) 
			xrefli++;	
	} /* while */
			
	/* process command token */
	
	if (code >= C_MIN) {
		/* generate machine code for command */
		gen_code_command(pcodeB,pcodeP,tii,cmplB);
		return;
	}
	
	/* generate initial setup code if needed */

	if (!incode) {
		gen_begin(); /* generate initial setup code */
	} /* incode if */
	
	/* generate code to update interpreter's pointer if */
	/* execution error possible */
	
	gen_xerr();
	
	/* determine source and destination registers for next op/ad */

	xtPTR = xtP+code; /* address of xtP[] entry */	
	rn1 = rn2 = -1; /* no registers yet */
	drn = tdrn = tP->reg; /* destination register */
	
	switch(xtPTR->cgen) {
	
	case or_general:
		if (xtPTR->op) {
		
			/* insure operands in register - use d0,d1 if neccessary */
			
			if (xtPTR->unary) {
				if ((!ibranchf) && ((code == IBRANCHT) || (code == IBRANCHF))) {
				
					/* special handling for non-compiled branch */
					/* don't load operand to register */
					;
				} else {
	
					/* process unary operator */
			
					op1 = find_operand(tP,tii); 
					rn1 = in_general_reg(op1,r_d0); /* load to d0 if not in reg */
				}
			} else if (!xtPTR->trinary) {
		
				/* process binary operator */
			
				op2 = find_operand(tP,tii);
				rn2 = in_general_reg(op2,r_d0+1); 
				op1 = find_operand(op2,tii);
				rn1 = in_general_reg(op1,r_d0); 
			} /* binary else */
		} /* operator if */
		break;
	
	case or_subrxx:
		if (xtPTR->op) {
		
			/* insure operands on stack */
			
			if (xtPTR->unary) {
		
				/* process unary operator */
			
				op1 = find_operand(tP,tii); 
				rn1 = op1->reg; 
				if (rn1 != r_result) /* move.l rn,(a3)+ */
					gen_movl(reg_num(rn1),reg_src_mode(rn1),3,3);
			} else if (!xtPTR->trinary) {
		
				/* process binary operator */
			
				op2 = find_operand(tP,tii);
				rn2 = op2->reg;
				op1 = find_operand(op2,tii); 
				rn1 = op2->reg;
				if (rn1 != r_result) {
					gen_ra3_int(); /* a3 = pointer in int stack */
					/* move.l r1,(a3)+ */
					gen_movl(reg_num(rn1),reg_src_mode(rn1),3,3);
				}
				if (rn2 != r_result) {
					gen_ra3_int(); /* a3 = pointer in int stack */
					/* move.l r2,(a3)+ */
					gen_movl(reg_num(rn2),reg_src_mode(rn2),3,3);
				}
			} /* binary else */
		} /* operator if */
		rn1 = rn2 = r_result;		
		break;
	
	case or_ibassign:
		op2 = find_operand(tP,tii);
		rn2 = op2->reg; /* address */
		op1 = find_operand(op2,tii);
		rn1 = op1->reg; /* value */
		break;
			
	case or_operandx:
		rn1 = rn2 = r_result; 
		break;
		
	} /* switch */
	
	switch (code) {

	case ILITERAL:
		oaddr = pcodeB+tP->rel+1;
		ivalue = long_read(oaddr); /* read integer value from pcode */
		/* copy to destination register or stack */
		if (drn == r_result) gen_ra3_int(); /* a3 = int results ptr */
		/* move.l #k,rn */
		gen_movl(4,7,reg_num(drn),reg_dest_mode(drn)); 
		cmpbuf_long(ivalue); 	
		break;
		
	case FLITERAL:
		gen_ra3_float(); /* a3 = pointer in floating stack */
		oaddr = pcodeB+tP->rel+1;
		fvalue = flt_read(oaddr); /* read floating value from pcode */
		oaddr = (short FAR *)(&fvalue);
		gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
		cmpbuf_long(*(long FAR *)oaddr); 
		oaddr += 2;
		gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
		cmpbuf_long(*(long FAR *)oaddr); 
		break;
	
	case GLOBALADDR:
	case IGLOBALADDR:
	case BGLOBALADDR:
	case MGLOBALADDR:
		oaddr = pcodeB+tP->rel+1;
		ivalue = long_read(oaddr); /* read rel address from pcode */
		gen_ra1_ra2_gvar(ivalue); /* a1 = address of variable */
		tdrn = r_a0+1;
		break;

	case GLOBALVAL:
	case LOCALVAL:
	case PASSVAL:
		gen_ra3_float(); /* a3 = pointer in floating stack */
		oaddr = pcodeB+tP->rel+1;
		ivalue = long_read(oaddr);
		if (code == GLOBALVAL)
			gen_ra1_ra2_gvar(ivalue);  /* a1 = addr of global var */
		else if (code == LOCALVAL)
			gen_ra1_ra2_lvar(ivalue); /* a1 = addr of local var */
		else if (code == PASSVAL) {
			gen_ra1_ra2_lvar(ivalue); /* a1 = addr of pointer */
			/* get a1 = addr of passed variable */
			gen_movl(1,2,1,1); /* move.l (a1),a1 */
			ra1_gvars = ra1_lvars = -2; /* a1 destroyed */
			gen_ra2_globals(); /* a2 = address of global variables */
			cmpbuf_word(0xd3ca); /* add.l a2,a1 */
		}
		/* check if this token generates store address */
		if (tP->store) {
			if (tP->store != (tii+1)) {
				/* if another token before storinf token */
				/* (itof, ftoi, etc.) save address currently */
				/* in a1 on 68000 stack */
				gen_movl(1,1,7,4); /* move.l a1,-(sp) */
				toktab_store = -2; /* address on stack */
				gen_stackf(1); /* copy float (a1) to result */
			} else {
				gen_movl(1,1,0,1); /* move.l a1,a0 */
				gen_stackf(0); /* copy float (a0) to result */
				toktab_store = -3; /* address in a1 */
			}
		} else gen_stackf(1); /* copy float (a1) to result */	
		break;
		
	case IGLOBALVAL:			
	case ILOCALVAL:
	case IPASSVAL:
		if (drn == r_result) 
			gen_ra3_int(); /* a3 = int results ptr */
		if (code == IGLOBALVAL) 
			gen_ra2_globals(); /* a2 = address of global variables */
		else gen_ra2_locals(); /* a2 = address of local variables */
		oaddr = pcodeB+tP->rel+1;
		ivalue = long_read(oaddr); /* read rel addr from pcode */
		/* check if this token generates store address */
		if (tP->store) {
			if (code == IGLOBALVAL) /* global */
				gen_ra1_ra2_gvar(ivalue); /* a1 = addr of global var */
			else if (code == ILOCALVAL) /* local */
				gen_ra1_ra2_lvar(ivalue); /* a1 = addr of local var */
			else { /* pass-by-address */
				gen_ra1_ra2_lvar(ivalue); /* a1 = addr of pointer */
				/* get a1 = address of passed variable */
				gen_movl(1,2,1,1); /* move.l (a1),a1 */
				ra1_gvars = ra1_lvars = -2; /* a1 destroyed */
				gen_ra2_globals(); /* a2 = address of global variables */
				cmpbuf_word(0xd3ca); /* add.l a2,a1 */
			}
			/* move.l (a1),rn or move.l (a1),(a3)+ */
			gen_movl(1,2,reg_num(drn),reg_dest_mode(drn));	
			toktab_store = -3; /* address in a1 */
			if (tP->store != (tii+1)) {
				gen_movl(1,1,7,4); /* move.l a1,-(sp) */
				toktab_store = -2; /* address on stack */
			}		
		} else if (code == IPASSVAL) {
			gen_ra1_ra2_lvar(ivalue); /* a1 = addr of pointer */
			/* get a1 = address of passed variable */
			gen_movl(1,2,1,1); /* move.l (a1),a1 */
			ra1_gvars = ra1_lvars = -2; /* a1 destroyed */
			gen_ra2_globals(); /* a2 = address of global variables */
			cmpbuf_word(0xd3ca); /* add.l a2,a1 */
			/* move.l (a1),rn or move.l (a1),(a3)+ */
			gen_movl(1,2,reg_num(drn),reg_dest_mode(drn));	
		} else gen_var(ivalue,drn,4); /* load value */
		break;

	case BGLOBALVAL:		
	case BLOCALVAL:
	case BPASSVAL:
		if (code == BGLOBALVAL)
			gen_ra2_globals(); /* a2 = address of global variables */
		else gen_ra2_locals(); /* a2 = address of local variables */
		oaddr = pcodeB+tP->rel+1;
		ivalue = long_read(oaddr); /* read rel address from pcode */
		if (drn == r_result) 
			tdrn = r_d0; /* use d0 if result on stack */
		cmpbuf_word(0x4280+reg_num(tdrn)); /* clr.l  r */
		/* check if this token generates store address */
		if (tP->store) {
			if (code == BGLOBALVAL) /* global */
				gen_ra1_ra2_gvar(ivalue); /* a1 = addr of global var */
			else if (code == BLOCALVAL) /* local */
				gen_ra1_ra2_lvar(ivalue); /* a1 = addr of local var */
			else { /* pass-by-address */
				gen_ra1_ra2_lvar(ivalue); /* a1 = addr of pointer */
				/* get a1 = address of passed variable */
				gen_movl(1,2,1,1); /* move.l (a1),a1 */
				ra1_gvars = ra1_lvars = -2; /* a1 destroyed */
				gen_ra2_globals(); /* a2 = address of global variables */
				cmpbuf_word(0xd3ca); /* add.l a2,a1 */
			}
			/* move.b (a1),rn */
			gen_movb(1,2,tdrn,0);	
			toktab_store = -3; /* address in a1 */
			if (tP->store != (tii+1)) {
				gen_movl(1,1,7,4); /* move.l a1,-(sp) */
				toktab_store = -2; /* address on stack */
			}		
		} else if (code == BPASSVAL) {
			gen_ra1_ra2_lvar(ivalue); /* a1 = addr of pointer */
			/* get a1 = address of passed variable */
			gen_movl(1,2,1,1); /* move.l (a1),a1 */
			ra1_gvars = ra1_lvars = -2; /* a1 destroyed */
			gen_ra2_globals(); /* a2 = address of global variables */
			cmpbuf_word(0xd3ca); /* add.l a2,a1 */
			/* move.b (a1),rn */
			gen_movb(1,2,tdrn,0);	
		} else gen_var(ivalue,tdrn,1); /* load value */		
		break;
		
	case LOCALADDR:
	case ILOCALADDR:
	case BLOCALADDR:
	case MLOCALADDR:
		oaddr = pcodeB+tP->rel+1;
		ivalue = long_read(oaddr); /* read rel address from pcode */
		gen_ra1_ra2_lvar(ivalue); /* a1 = address of variable */
		tdrn = r_a0+1; /* result in a1 */
		break;	
		
	case PASSADDR:
	case IPASSADDR:
	case BPASSADDR:
		oaddr = pcodeB+tP->rel+1;
		ivalue = long_read(oaddr); /* read rel address from pcode */
		gen_ra1_ra2_lvar(ivalue); /* a1 = address of pointer */
		/* get a1 = address of passed variable */
		gen_movl(1,2,1,1); /* move.l (a1),a1 */
		ra1_lvars = ra1_gvars = -2; /* a1 destroyed */
		gen_ra2_globals(); /* a2 = address of global variables */
		cmpbuf_word(0xd3ca); /* add.l a2,a1 */
		tdrn = r_a0+1; /* result in a1 */
		break;		
	
	case IGARRAYVAL:
	case IGARRAYADDR:
	case BGARRAYVAL:
	case BGARRAYADDR:
	case ILARRAYVAL:
	case ILARRAYADDR:
	case BLARRAYVAL:
	case BLARRAYADDR:
	case XGARRAYVAL:
	case XLARRAYVAL:
		gen_ra3_int(); /* a3 = pointer in int stack */
	
		/* pick up array description */
		
		adescp = (tstga(code) ? gdescp: udescp);
		pda = (struct array_desc FAR *)(descP+adescp+*(pcodeB+tP->rel+3));
		pdd = (struct dim_desc FAR *)(pda+1);
		
		/* if multi-dimensional array, call subroutine */
	
		if (pda->ndim != 1) {
		
			/* for array address, insure value assigned is on stack */
			
			rn1 = -1; /* no action taken for assigned value yet */
			if (xtP[code].isaddr) {
				aii = -1;
				for(ii=0; ii<tii; ii++) {
					/* search for value to be assigned */
					if (toktabP[ii].op == tP->op) {
						aii = ii; /* save index of value */
						break; /* exit for */
					} 
				} /* for */
				if (aii < 0)
					TUTORdump("failed to find assigned value ");
				if (toktabP[aii].reg != r_result) {
					rn1 = toktabP[aii].reg; /* get result register */
					gen_ra3_int(); /* must be int if not on stack */
					/* move.l rn,(a3)+ */
					gen_movl(reg_num(rn1),reg_src_mode(rn1),3,3);
					toktabP[aii].reg = r_result; /* value is on stack */
				} /* reg if */
			} /* isaddr if */
			
			/* look up appropriate subroutine */
			
			subrii = cvt_subr(code);
			
			/* generate code to put rel addr on stack */
			
			oaddr = pcodeB+tP->rel+1;
			ivalue = long_read(oaddr); /* read addr field from pcode */
			gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
			cmpbuf_long(ivalue); 
			gen_subrxx(subrii);	
			toktab_store = -4; /* store info in store_addr, etc */
			tdrn = r_result;
			break;
		}	
		
		/* locate index operand */
		
		op1 = find_operand(tP,tii); /* locate index */	
		rn1 = op1->reg;
			
		/* generate in-line code (single dimension, index in reg) */
		
		if ((rn1 == r_d0) || (rn1 == (r_d0+1)))
			TUTORdump("gen_code confused: array index in d0 or d1");
		if (rn1 == r_result) {
			gen_movl(3,4,2,0); /* move.l -(a3),d2 */
			rn1 = r_d0+2; /* index in d2 */
		}	
		oaddr = pcodeB+tP->rel+1;
		ivalue = long_read(oaddr); /* read rel address from pcode */
					
		/* generate code to ajust index */
			
		if (pdd->lower == 1) {
			cmpbuf_word(0x5380+rn1); /* subq.l #1,rn1 */
		} else {
			cmpbuf_word(0x0480+rn1); /* subi.l #k,rn1 */
			cmpbuf_long(pdd->lower);
		} /* alower else */
		
		/* duplicate adjusted index (in d0) if need to compute */
		/* number array items later */
		
		if (tP->store) 
			gen_movl(rn1,0,0,0); /* move.l rn1,d0 */
			
		/* generate code for bounds test */
				
		cmpbuf_word(0x6b08); /* bmi  *+8 */
		cmpbuf_word(0x0c80+rn1); /* cmpi  #k,dj */
		cmpbuf_long(pdd->length);
		cmpbuf_word(0x6b06); /* bmi  *+6 */
	
		/* generate call to ex_arrayerr subroutine */
		/* generate call by hand - a0 is not destroyed */
		/* except on error exit */
		
		gen_movl(4,5,0,1); /* move.l  k(a4),a0 */
		cmpbuf_word((unsigned int)(EXS_ARRAYERR*sizeof(long))); 
		cmpbuf_word(0x4e90); /* jsr (a0) */				
		
		/* generate multiply by size of element */
		
		if (pda->size == 1) { 
			/* nothing to do if byte array */
		} else if (pda->size == 4) {
			cmpbuf_word(0xe588+rn1); /* lsl.l rn1,#2 */
		} else if (pda->size == 8) {
			cmpbuf_word(0xe788+rn1); /* lsl.l rn1,#3 */
		} else if (pda->size == 10) {
			gen_movl(rn1,0,1,0); /* move.l rn1,d1 */
			cmpbuf_word(0xe788+rn1); /* lsl.l rn1,#3 */
			cmpbuf_word(0xe388+1); /* lsl.l d1,#1 */
			/* add.l d1,rn1 */
			gen_roe(13,reg_num(rn1),2,1,0);
		} else if (pda->size == 12) {
			gen_movl(rn1,0,1,0); /* move.l rn1,d1 */
			cmpbuf_word(0xe788+rn1); /* lsl.l rn1,#3 */
			cmpbuf_word(0xe388+2); /* lsl.l d1,#2 */
			/* add.l d1,rn1 */
			gen_roe(13,reg_num(rn1),2,1,0);
		} 
		
		/* generate code to compute address of array element */
	
		/* get a1 = base address of array */
		ivalue += ARRAYHDR; /* bias past array header */
		if (xtP[code].local == 0) /* global */
			gen_ra1_ra2_gvar(ivalue); 
		else  /* local */
			gen_ra1_ra2_lvar(ivalue);
		ra1_lvars = ra1_gvars = -2; /* a1 destroyed */
		gen_roe(13,1,7,rn1,0); /* add.l rn1,a1 */	
		if (xtP[code].isaddr) {
			tdrn = r_a0+1; /* address result is in a1 */
			break; /* done if address */
		} 
		
		/* generate code to load value */
			
		if (pda->size == 1) { /* byte */
			if (tdrn == r_result) 
				tdrn = r_d0+1; /* use d1 if result on stack */	
			gen_ra3_int(); /* a3 = ptr in integer stack */
			/* clr.l rn */
			cmpbuf_word(0x4280+reg_num(tdrn)); 
			/* move.b (a1),rn */
			gen_movb(1,2,reg_num(tdrn),reg_dest_mode(tdrn));
		} else if (pda->size == 4) { /* long */
			gen_ra3_int(); /* a3 = ptr in integer stack */
			/* move.l (a1),rn */
			gen_movl(1,2,reg_num(tdrn),reg_dest_mode(tdrn));
		} else { /* float */
			gen_ra3_float(); /* a3 = ptr in floating stack */
			if (tP->store) {
				/* need address in a1, destroy a0 */
				gen_movl(1,1,0,1); /* move.l a1,a0 */
				gen_stackf(0); /* copy float (a0) to result */
				gen_ra3_int(); /* a3 = ptr in integer stack */
				gen_movl(1,1,3,3); /* stack dummy result */
			} else {	
				gen_stackf(1); /* copy float (a1) to result */
			} /* tP->store else */
			tdrn = r_result; /* result is on stack */
		} /* float else */
		
		/* generate code to return address, type, #items */
		
		if (tP->store) {
			if (drn != r_result)
				TUTORdump("storeable must be on stack!");
			gen_ra3_int(); /* a3 = ptr in integer stack */
			if (tdrn != r_result) 
				gen_movl(tdrn,0,3,3); /* move.l rn,(a3)+ */
			/* get pointer to storinf kind field in pcode */
			stP = pcodeB+toktabP[tP->store].rel+2;
			gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
			cmpbuf_long(*(long FAR *)(stP));
			gen_movl(1,1,3,3); /* move.l a1,(a3)+ */
			gen_movl(4,7,1,0); /* move.l #k,d1 */
			cmpbuf_long(pda->length);
			gen_roe(9,1,2,0,0); /* sub.l d0,d1 */
			gen_movl(1,0,3,3); /* move.l d1,(a3)+ */
			toktab_store = tii; /* info already generated */
			tdrn = r_result; /* result is on stack */
		} /* store if */
		break;

	case GARRAY:
	case IGARRAY:
	case BGARRAY:
	case MGARRAY:
	case LARRAY:
	case ILARRAY:
	case BLARRAY:
	case MLARRAY:
	case XGARRAY:
	case XLARRAY:

		/* generate code to put dummy result on int stack */

		gen_ra3_int(); /* a3 = pointer in integer stack */
		gen_movl(0,0,3,3); /* move.l d0,(a3)+ */

		/* generate code to return array float/int/mark type */

		stP = pcodeB+tP->rel; /* pointer to token in pcode */
		if (xtP[code].trel == TFLOAT)
			ivalue = FARRAY;
		else if (xtP[code].trel == TINT)
			ivalue = IARRAY;
		else if (xtP[code].trel == TBYTE)
			ivalue = BARRAY;
		else if (xtP[code].trel == TMARK)
			ivalue = MARRAY;
		else ivalue = long_read(stP+1); /* read TXTYPE kind field */
		gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
		cmpbuf_long(ivalue);
	
		/* generate code to return address of array */

		stP += 2; /* increment for kind field */
		ivalue = long_read(stP+1);
		if (xtP[code].local == 0)
			gen_ra1_ra2_gvar(ivalue);
		else gen_ra1_ra2_lvar(ivalue);
		gen_movl(1,1,3,3); /* move.l a1,(a3)+ */
		
		/* generate code to return array length */

		ivalue = long_read(stP+3);
		gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
		cmpbuf_long(ivalue);
		break;

	case PARRAY:
	case IPARRAY:
	case BPARRAY:
	case MPARRAY:
	case XPARRAY:
	case GDYARRAY:
	case LDYARRAY:
	case PDYARRAY:
	case IGDYARRAY:
	case ILDYARRAY:
	case IPDYARRAY:
	case BGDYARRAY:
	case BLDYARRAY:
	case BPDYARRAY:
		gen_ra3_int(); /* a3 = pointer in integer stack */

		/* generate code to return array float/int/mark type */

		stP = pcodeB+tP->rel; /* pointer to token in pcode */
		if (xtP[code].trel == TFLOAT) ivalue = FARRAY;
		else if (xtP[code].trel == TINT) ivalue = IARRAY;
		else if (xtP[code].trel == TBYTE) ivalue = BARRAY;
		else if (xtP[code].trel == TMARK) ivalue = MARRAY;
		else ivalue = long_read(stP+1); /* read TXTYPE kind field */
		gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
		cmpbuf_long(ivalue);

		/* generate code to return relative address of array */

		stP += 2; /* increment for kind field */
		ivalue = long_read(stP+1);
		gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
		cmpbuf_long(ivalue);

		/* generate call to subroutine to look up array */
		/* descriptor */
		
		if (tstpa(code))
			gen_subrxx(EXS_PARRAY);
		else {
			if (tstga(code))
				gen_subrxx(EXS_GDYARRAY);
			else 
				gen_subrxx(EXS_LDYARRAY);
		}
		break;

	case PARRAYVAL:
	case IPARRAYVAL:
	case BPARRAYVAL:
	case MPARRAYVAL:
	case PARRAYADDR:
	case IPARRAYADDR:
	case BPARRAYADDR:
	case MPARRAYADDR:		
	case GARRAYVAL:
	case GARRAYADDR:
	case LARRAYVAL:
	case LARRAYADDR:			
	case MLITERAL:
	case MGLOBALVAL:
	case MGARRAYVAL:
	case MGARRAYADDR:
	case MLOCALVAL:
	case MLARRAYVAL:
	case MLARRAYADDR:
	case MPASSVAL:
	case MPASSADDR:
	case XGLOBALVAL:
	case XLOCALVAL:
	case XPASSVAL:
	case XPARRAYVAL:
	case GDYARRAYVAL:
	case IGDYARRAYVAL:
	case BGDYARRAYVAL:
	case GDYARRAYADDR:
	case IGDYARRAYADDR:
	case BGDYARRAYADDR:
	case LDYARRAYVAL:
	case ILDYARRAYVAL:
	case BLDYARRAYVAL:
	case LDYARRAYADDR:
	case ILDYARRAYADDR:
	case BLDYARRAYADDR:
	case PDYARRAYVAL:
	case IPDYARRAYVAL:
	case BPDYARRAYVAL:
	case PDYARRAYADDR:
	case IPDYARRAYADDR:
	case BPDYARRAYADDR:
	
		/* for array address, insure value assigned is on stack */
			
		rn1 = -1; /* no action taken for assigned value yet */
		if (xtP[code].array && xtP[code].isaddr) {
			aii = -1;
			for(ii=0; ii<tii; ii++) {
				/* search for value to be assigned */
				if (toktabP[ii].op == tP->op) {
					aii = ii; /* save index of value */
					break; /* exit for */
				} 
			} /* for */
			if (aii < 0)
				TUTORdump("failed to find assigned value ");
			if (toktabP[aii].reg != r_result) {
				rn1 = toktabP[aii].reg; /* get result register */
				gen_ra3_int(); /* must be int if not on stack */
				/* move.l rn,(a3)+ */
				gen_movl(reg_num(rn1),reg_src_mode(rn1),3,3);
				toktabP[aii].reg = r_result; /* value is on stack */
			} /* reg if */
		} /* isaddr if */
		
		gen_ra3_int(); /* a3 = pointer in int stack */
		subrii = cvt_subr(code); /* look up subroutine */
		oaddr = pcodeB+tP->rel+1;
		ivalue = long_read(oaddr); /* read addr field from pcode */
		gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
		cmpbuf_long(ivalue); 
		gen_subrxx(subrii);	
		toktab_store = -4; /* store info in store_addr, etc */
		tdrn = r_result; /* result is on stack */
		break;
		
	case IASSIGN:
	case BASSIGN:
		/* if address set up in a1, generate code for assign, */
		/* else call subroutine */
		if (rn2 == (r_a0+1)) {
			rn1 = in_general_reg(op1,r_d0); 
			if (code == BASSIGN) /* move.b rn,(a1) */
				gen_movb(reg_num(rn1),reg_src_mode(rn1),1,2);
			else /* move.l rn,(a1) */
				gen_movl(reg_num(rn1),reg_src_mode(rn1),1,2);
			tdrn = rn1; /* result in arg 1 register */
		} else {
			gen_ra3_int(); /* a3 = pointer in int stack */
			/* insure both operands on stack */
			if (rn1 != r_result) /* move.l r1,(a3)+ */
				gen_movl(reg_num(rn1),reg_src_mode(rn1),3,3);
			if (rn2 != r_result) /* move.l r2,(a3)+ */
				gen_movl(reg_num(rn2),reg_src_mode(rn2),3,3);
			/* call assign subroutine */
			subrii = cvt_subr(code); /* look up subroutine */
			gen_subrxx(subrii);
			tdrn = r_result; /* result is on stack */
		}
		break;

	case IPLUS:
		if (drn == rn2) { 
			/* reverse registers to leave result in dest */
			rn2 = rn1;
			rn1 = drn;
		}
		/* add.l rn2,rn1 */
		gen_roe(13,reg_num(rn1),2,reg_num(rn2),reg_src_mode(rn2));
		tdrn = rn1; /* result is in 1st argument register */
		break;
		
	case IMINUS:
		/* sub.l rn2,rn1 */
		gen_roe(9,reg_num(rn1),2,reg_num(rn2),reg_src_mode(rn2));
		tdrn = rn1; /* result in arg 1 register */
		break;
		
	case IINC:
		/* addq.l #1,r */
		cmpbuf_word(0x5280+reg_num(rn1)+(reg_dest_mode(rn1) << 3));
		tdrn = rn1; /* result is in 1st argument register */
		break;
		
	case IDEC:
		/* subq.l #1,r */
		cmpbuf_word(0x5380+reg_num(rn1)+(reg_dest_mode(rn1) << 3));
		tdrn = rn1; /* result is in 1st argument register */
		break;
	
	case IUMINUS:
		/* neg.l rn1 */
		cmpbuf_word(0x4480+rn1);
		tdrn = rn1; /* result in arg 1 register */
		break;
		
	case COMP:
		/* not.l rn1 */
		cmpbuf_word(0x4680+rn1);
		tdrn = rn1; 
		break;
		
	case LSHIFT:
		/* lsl.l rn1,rn2 */
		cmpbuf_word(0xe1a8+(rn2 << 9)+rn1);
		tdrn = rn1; 
		break;
		
	case RSHIFT:
		/* lsl.l rn1,rn2 */
		cmpbuf_word(0xe0a8+(rn2 << 9)+rn1);
		tdrn = rn1; 
		break;
		
	case LMASK:
		/* and.l rn2,rn1 */
		gen_roe(0xc,rn1,2,rn2,0);
		tdrn = rn1; 
		break;
		
	case LUNION:
		/* or.l rn2,rn1 */
		gen_roe(0x8,rn1,2,rn2,0);
		tdrn = rn1; 
		break;
		
	case LDIFF:
		/* eor.l rn2,rn1 */
		gen_roe(0xb,rn2,6,rn1,0);
		tdrn = rn1;
		break;	
		
	case AND:
		/* and.l rn2,rn1 */
		gen_roe(0xc,rn1,2,rn2,0);
		tdrn = rn1;
		break;
		
	case OR:
		/* or.l rn2,rn1 */
		gen_roe(0x8,rn1,2,rn2,0);
		tdrn = rn1;
		break;

	case IEQ:
	case INE:
	case IGT:
	case ILT:
	case IGE:
	case ILE:
		/* sub.l  br,ar */
		gen_roe(9,rn1,2,rn2,0);
		if (code == IEQ) 
			word = 0x6704; /* beq  *+4 */
		else if (code == INE) 
			word = 0x6604; /* bne  *+4 */
		else if (code == IGT) 
			word = 0x6e04; /* bgt  *+4 */
		else if (code == ILT) 
			word = 0x6d04; /* blt  *+4 */
		else if (code == IGE) 
			word = 0x6c04; /* blt  *+4 */
		else if (code == ILE) 
			word = 0x6f04; /* ble  *+4 */
		cmpbuf_word(word); /* add fwd branch */
		cmpbuf_word(0x4280+rn1); /* clr.l  rn1 */
		cmpbuf_word(0x6006); /* bra  *+6 */
		gen_movl(4,7,rn1,0); /* move.l  #-1,rn1 */
		cmpbuf_long(-1L);
		tdrn = rn1; 
		break;

	case ISPEQ:
	case ISPNE:
	case ISPGT:
	case ISPLT:
	case ISPGE:
	case ISPLE:	
	case SPEQ:
	case SPNE:
	case SPGT:
	case SPLT:
	case SPGE:
	case SPLE:	
	case MSPEQ:
	case MSPNE:
	case MSPGT:
	case MSPLT:
	case MSPGE:
	case MSPLE:	
		gen_ra3_none(); /* insure stack pointer updated */
		/* generate subroutine call to do compare and adjust stack */
		subrii = cvt_subr(code);
		gen_subrxx(subrii);
				
		/* set up registers as required at branch destination */

		tdrn = r_result; /* result is on stack at present */
		drn = toktabP[tii+1].reg; /* get desired dest reg from branch */
		if (toktabP[tii+1].dreg != r_result) { /* next token is branch */
			tdrn = toktabP[tii+1].dreg;
			gen_ra3_int(); /* a3 = ptr in int stack */
			/* move.l -(a3),dn */
			gen_movl(3,4,reg_num(tdrn),reg_dest_mode(tdrn));
		} /* rn1 if */
		
		/* generate branch */
		
		gen_ra3_update(); /* insure stack pointer up to date */
		cmpbuf_word(0x4a40); /* tst.w d0 */
		cmpbuf_word(0x6700); /* beq * */
		xrefP[xrefri].reloc = 1; /* pc relative branch */
		xrefP[xrefri++].aref = cmpl; /* set address of reference */
		cmpbuf_word(0); /* address planted later */
		ibranchf = FALSE; /* ignore following branch */
		break;
		
	case IBRANCHT:
	case IBRANCHF:
		if (!ibranchf) {
			ibranchf = TRUE; /* don't ignore next */
			break; /* ignore - already handled by ISPEQ */
		}
		
		/* set up registers as required at branch destination */
		
		tdrn = rn1; /* result is in argument register at present */
		if (rn1 != tP->dreg) {
			tdrn = tP->dreg;
			if (tdrn == r_result)
				gen_ra3_int(); /* a3 = ptr in int stack */
			gen_movl(rn1,0,reg_num(tdrn),reg_dest_mode(tdrn));
		} /* rn1 if */
		
		/* generate branch */
		
		gen_ra3_update(); /* insure stack ptr up to date */
		cmpbuf_word(0x4a80+rn1); /* tst.l rn */
		if (code == IBRANCHT)
			word = 0x6b00; /* bmi */
		else word = 0x6a00; /* bpl */
		cmpbuf_word(word); 
		xrefP[xrefri].reloc = 1; /* pc relative branch */
		xrefP[xrefri++].aref = cmpl; /* set address of reference */
		cmpbuf_word(0); /* address planted later */
		break;
		
	case EXPONIC:
	case SYSVAR:
	case ISYSVAR:
	case TSYSVAR:
	case MSYSVAR:
	case MSYSVARA:
	case EFUNCT:
		if (code == MSYSVAR) 
			toktab_store = -4; /* info in store_addr, etc */
		gen_ra3_int(); /* a3 = int results pointer */
		stP = pcodeB+tP->rel; /* pointer to token in pcode */
		ivalue = *(stP+1);
		gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
		cmpbuf_long(ivalue);
		subrii = cvt_subr(code); /* look up subroutine */
		gen_subrxx(subrii);
		tdrn = r_result; /* result is on stack */
		break;
						
	case STORINF: /* return store-ability info */
	
		/* exit if storinf already handled by array */
		
		if (toktab_store >= 0) {
			toktab_store = -1; /* re-set for next storinf */
			break; /* info already generated */
		}
		
		/* get pointer to storinf token in pcode */
		
		stP = pcodeB+tP->rel;
		ltP = (long FAR *)(stP+2);
		storinf_kind = *(ltP);
		
		/* exit if (constant) loop - let loop handle storinf */
		
		if (loopbegf && (looptyp[loopstkN-1] == C_ICLOOPINIT)) 
			break; /* let C_ICLOOPINIT handle storinf */
			
		/* put dummy result on int stack if not int result */
		
		gen_ra3_int(); /* a3 = pointer in integer stack */	
		if (!(*(stP+4))) {
			/* marker/float result - put dummy result on int stack */
			gen_movl(0,0,3,3); /* move.l d0,(a3)+ */
		}
		
		/* put kind field on stack */
		
		gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
		cmpbuf_long(storinf_kind);
		
		/* put address field on stack */
		
		if (toktab_store == -2) {
			/* move address from 68000 stack to result stack */
			gen_movl(7,3,3,3); /* move.l (sp)+,(a3)+ */
		} else if (toktab_store == -3) {
			/* put address (a1) on stack */
if ((ra1_gvars == -1) && (ra1_lvars == -1))
	TUTORdump("address in a1?");
			gen_movl(1,1,3,3); /* move.l a1,(a3)+ */
		} else {
			/* put -1 on stack if no address */
			gen_movl(4,7,3,3); /* move.l #-1,(a3)+ */
			cmpbuf_long(-1L);
		}
		
		/* put #items field on stack */
		
		ivalue = long_read((stP+8)); /* read items from pcode */
		gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
		cmpbuf_long(ivalue);
		if (toktab_store == -4) {
			/* put global/local flag on stack */
			gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
			cmpbuf_long((long)(*(stP+1)));
			/* put store-able flag on stack */
			gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
			cmpbuf_long((long)(*(stP+5)));
			/* generate call to subroutine to pick */
			/* up store_addr, etc */
			gen_subrxx(EXS_STORINF); 
		}
		toktab_store = -1; /* ready for next storinf */
		break;
		
	case ITOC:
		cmpbuf_word(0xe188+rn1); /* lsl.l dn,#8 */
		cmpbuf_word(0xe188+rn1); /* lsl.l dn,#8 */
		tdrn = rn1; /* result is in argument register */
		break;	
		
	case ULOCADDR:
		ncode = *(pcodeB+tP->rel+2); /* get next expression/cmd code */
		if ((ncode == C_BRANCHT) || (ncode == C_BRANCHF) ||
		    (ncode == C_BRANCH)) 
			break; /* let branch compile ulocaddr */
		if (loopbegf)
			break; /* let loop compile ulocaddr */
		/* copy to destination register or stack */
		if (drn == r_result)
			gen_ra3_int(); /* a3 = int results ptr */
		gen_movl(4,7,reg_num(drn),reg_dest_mode(drn)); 
		cmpbuf_word(0); /* upper part of long is zero */
		xrefP[xrefri++].aref = cmpl; /* address of reference */
		cmpbuf_word(0); /* planted later */
		break;
		
	case ULOCTABL:
		/* add table header+length so compiled and interpreted */
		/* versions have same 4-byte displacement to actual table */
		cmpbuf_word(ULOCTABL); 
		stP = pcodeB+tP->rel+1;
		max = *stP++; /* maximum value in table */
		cmpbuf_word(max);
		for(ii=0; ii<max; ii++) {
			xrefP[xrefri++].aref = cmpl; /* address of reference */
			cmpbuf_word(*stP++); /* re-planted later */
		} /* for */
		break;
			
	case TKEYWORD:
		if (drn == r_result) gen_ra3_int(); /* a3 = int results ptr */
		ivalue = *(pcodeB+tP->rel+1);
		/* copy to destination register or stack */
		gen_movl(4,7,reg_num(drn),reg_dest_mode(drn)); 
		cmpbuf_long(ivalue); 
		break;
					
	case SKIP:
	case TDOT:
	case TPOINT:
		gen_ra3_int(); /* a3 = pointer in integer stack */
		gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
		cmpbuf_long((long)code); /* add pcode value */
		break;
	
	case MLITC: /* in-line string literal */
		stP = pcodeB+tP->rel+1;
		max = *stP++; /* get length of text */
		gen_ra3_int(); /* a3 = int results pointer */
		ra0_table = -1; /* forget a0 so fwd dispacement constant */
		cmpbuf_word(0x43fa); /* lea pc+24,a1 */
		cmpbuf_word(24); 
		gen_movl(1,1,3,3); /* move.l a1,(a3)+ */
		gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
		cmpbuf_long((long)max); /* add length of string */
		gen_subrxx(EXS_MLITC);
		if (max & 1) max++;
		cmpbuf_word(0x6000+max); /* bra  *+(length of string) */
		max = max >> 1;
		for(ii=0; ii<max; ii++)
			cmpbuf_word(*stP++); /* copy next 2 bytes of text */
		break;
	
	case TEXTARG:
		stP = pcodeB+tP->rel+1;
		gen_ra3_int(); /* a3 = pointer in integer stack */
		gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
		lwP = (long FAR *)stP;
		cmpbuf_long(*lwP); /* position of text */
		stP += 2;
		lwP = (long FAR *)stP;
		gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
		cmpbuf_long(*lwP); /* length of text */
		break;
		
	case TEXTARG1:
		gen_end(); /* switch to interpreted code */
		stP = pcodeB+tP->rel+1;
		cmpbuf_word(TEXTARG1);
		max = *stP++; /* get length of text */
		cmpbuf_word(max);
		max = (max+1) >> 1;
		for(ii=0; ii<max; ii++)
			cmpbuf_word(*stP++); /* copy next 2 bytes of text */
		break;
		
	case CASETAB:
		stP = pcodeB+tP->rel;
		cmpbuf_word(*stP++); /* add p-code */
		min = *stP++; /* minimum value in table */
		cmpbuf_word(min); /* add minimum */
		max = *stP++; /* maximum value in table */
		cmpbuf_word(max); /* add maximum */
		for(ii=min; ii<=max; ii++) {
			if (*stP == 0) {
				cmpbuf_word(0); /* 0 means branch to default */
			} else {
				if (xrefri >= xreflen) {
					TUTORdump("CASETAB xrefP overflow");
				} else {
					xrefP[xrefri++].aref = cmpl; /* address of reference */
				}
				cmpbuf_word(0); /* re-planted later */
			}
			stP++;
		} /* for */
		break;
		
	default:
		gen_subrxx(code);
		tdrn = r_result; /* result is on stack */
		break;
		
	} /* switch */
	
	if (!incode && (tdrn != drn))
		TUTORdump("can't move register in interpreted code");
	
	/* move result to correct register if neccessary */
	
	if (tdrn != drn) {
		if ((drn == r_result) || (tdrn == r_result)) {
		
			/* set up stack pointer if result on stack */
			
			gen_ra3_int(); /* a3 = pointer in integer stack */
		}
		gen_movl(reg_num(tdrn),reg_src_mode(tdrn),
		         reg_num(drn),reg_dest_mode(drn));
	} 
	
	/* insure last token of expression in correct register */
	/* for command */
	
	if (tP->op == -1) { /* token operated on by command */
		if (drn != r_result) {
			gen_ra3_int(); /* a3 = ptr in int stack */
			/* move.l dn,(a3)+ or move.l an,(a3)+ */
			gen_movl(reg_num(drn),reg_src_mode(drn),3,3);
		}
	} /* tP->op if */
	
} /* gen_code_token */

/* ******************************************************************* */

gen_code_command(pcodeB,pcodeP,tii,cmplB) 
/* generate machine code for command */
short FAR *pcodeB; /* base of input pcodes for unit */
short FAR *pcodeP; /* start of input tokens in pcodes */
int tii; /* index of command token in toktab */
long cmplB; /* base of compiled code for this command */

{	struct toktab FAR *tP; /* pointer to table entry */
	short FAR *paddr; /* address associated with operand in pcodes */
	int code; /* command code */
	unsigned short FAR *nextP; /* pointer to next pcode */
	int dcode; /* command code at branch destination */
	short uaddr; /* relative address within unit */
	int clauseri; /* index of clause entry in xrefP */
	struct toktab FAR *op1; /* pointer to 1st operand in token table */
	struct toktab FAR *op2; /* pointer to 2nd operand in token table */
	struct toktab FAR *op3; /* pointer to 3rd operand in token table */
	int rn1; /* register number of 1st operand */
	int rn2; /* register number of 2nd operand */
	int rn3; /* register number of 3rd operand */
	int nfind; /* number operands found */
	long loopinc; /* loop increment value */
	int word; 
	int ii;

	tP = toktabP+tii; /* address of table entry */
	code = tP->code;
	
	/* check if must switch from compiled to interpreted */
	
	if (must_interpret(code)) { /* if now generating compiled code */
	
		/* terminate block of compiled code */
		
		gen_end(); /* generate end of compiled code */
		cmpbuf_word(code); /* add command code to binary */
		return;
		
	} /* must_interpret if */
	
	if (incode) gen_xerr(); /* update interpreter for exec err */
	
	switch (code) {
	
	case C_LBEGIN:
		if (incode) gen_ra3_update(); /* insure stack pointer current */
		gen_begin(); /* loop is always compiled */
		loopstk[loopstkN++] = cmpl; /* address of head of loop */
		init_volatile(); /* mark volatile registers invalid */
		gen_xerr();
		loopbegf = TRUE; /* flag at begin of loop */
		
		/* look forwards to determine type of loop */
		
		nextP = (unsigned short FAR *)pcodeP;
		do {
			nextP = next_ptoken(nextP);
			dcode = *nextP;
			if ((dcode == C_ILOOPINIT) || (dcode == C_ILOOP1INIT) ||
			     (dcode == C_FLOOPINIT) || (dcode == C_ICLOOPINIT) ||
			     (dcode == C_BRANCHF)) {
				looptyp[loopstkN-1] = dcode;
				break; 
			} /* if */
		} while (TRUE);
		break;
		
	case C_LEND:
		loopendf = TRUE; /* flag at end of loop */
		gen_ra3_update(); /* insure stack pointer up to date */
		init_volatile() ;/* mark volatile registers invalid */
		break;
		
	case C_BRANCH:	
		if (loopendf) {
			
			/* unconditional backwards branch at endloop */
			
			loopendf = FALSE;	
			gen_begin(); /* must be in compiled code */	
			gen_xerr();		
				
			/* generate unconditional backwards branch */
			
			xrefP[xrefri++].aref = 0; /* void this reference */
			cmpbuf_word(0x6000); /* bra */
			cmpbuf_word(loopstk[loopstkN-1]-cmpl);
			loopstkN--; /* pop loop stack */
			break;
		} /* loopend if */
	
		/* generate compiled branch */
			
		gen_begin(); /* must be in compiled code */	
		gen_ra3_none(); /* insure result stack ptr up to date */
		init_volatile(); /* forget volatile registers */
		gen_xerr();
		cmpbuf_word(0x6000); /* bra */
		xrefP[xrefri].reloc = 1; /* pc relative branch */
		xrefP[xrefri++].aref = cmpl; /* set address of reference */
		cmpbuf_word(0); /* address planted later */
		break;
		
	case C_BRANCHT:
	case C_BRANCHF:
			
		/* find address and condition operands */
		
		op2 = find_operand(tP,tii);
		op1 = find_operand(op2,tii);
		rn1 = in_general_reg(op1,r_d0); /* get condition to reg */
		
		/* generate compiled branch */
	
		gen_ra3_none(); /* update stack pointer */
		init_volatile(); /* forget volatile registers */
		cmpbuf_word(0x4a80+rn1); /* tst.l rn1 */
		word = ((code == C_BRANCHT) ? 0x6b00: 0x6a00);
		cmpbuf_word(word); /* bmi or bpl */
		xrefP[xrefri].reloc = 1; /* pc relative branch */
		xrefP[xrefri++].aref = cmpl; /* set address of reference */
		cmpbuf_word(0); /* address planted later */
		loopbegf = FALSE; /* not begin of loop */
		break;
		
	case C_ILOOP1INIT:
		/* pop end, index off stack */
		gen_ra3_int(); /* a3 = pointer in integer results stack */
		cmpbuf_word(0x47eb); /* lea -8(a3),a3 */
		cmpbuf_word(-8);
		/* get end to d0 */
		gen_movl(3,5,0,0); /* move.l 4(a3),d0 */
		cmpbuf_word(4);
		gen_ra3_none(); /* update stack pointer */
		/* check if index >= end */
		gen_roe(0x0b,0,2,3,2); /* cmp.l (a3),d0 */
		/* jump to end loop */
		cmpbuf_word(0x6b00); /* bmi *+K */
		xrefP[xrefri+1].reloc = 1; /* pc relative branch */
		xrefP[xrefri+1].aref = cmpl; /* set address of reference */	
		cmpbuf_word(0); /* planted */
		/* jump to begin loop */
		cmpbuf_word(0x6000); /* bra */
		xrefP[xrefri].reloc = 1; /* pc relative branch */
		xrefP[xrefri].aref = cmpl; /* set address of reference */	
		cmpbuf_word(0); /* planted */	
		xrefri += 2;
		loopstk[loopstkN-1] = cmpl; /* address of head of loop */
		break;	
		
	case C_ILOOPINIT:
		/* pop increment, end, index off stack */
		gen_ra3_int(); /* a3 = pointer in integer results stack */
		cmpbuf_word(0x47eb); /* lea -12(a3),a3 */
		cmpbuf_word(-12);
		gen_ra3_none(); /* update stack pointer */
		/* get end to d0 */
		gen_movl(3,5,0,0); /* move.l 4(a3),d0 */
		cmpbuf_word(4);
		/* check if negative increment */
		cmpbuf_word(0x4aab); /* tst.l 8(a3) */
		cmpbuf_word(8);
		cmpbuf_word(0x6b08); /* bmi *+a */
		/* positive increment, check end-index */
		gen_roe(0x0b,0,2,3,2); /* cmp.l (a3),d0 */
		/* jump to jump to end loop */
		cmpbuf_word(0x6b08); /* bmi *+a */
		/* jump to begin loop */
		cmpbuf_word(0x6000); /* bra */
		xrefP[xrefri].reloc = 1; /* pc relative branch */
		xrefP[xrefri++].aref = cmpl; /* set address of reference */	
		cmpbuf_word(0); /* planted */	
		/* negative increment, check end-index */
		gen_roe(0x0b,0,2,3,2); /* cmp.l (a3),d0 */
		/* jump to jump to begin loop */
		cmpbuf_word(0x6ff8); /* bmi *-6 */
		/* jump to end loop */
		cmpbuf_word(0x6000); /* bra */
		xrefP[xrefri].reloc = 1; /* pc relative branch */
		xrefP[xrefri++].aref = cmpl; /* set address of reference */	
		cmpbuf_word(0); /* planted */	
		loopstk[loopstkN-1] = cmpl; /* address of head of loop */
		break;
		
	case C_ICLOOPINIT:	
	
		/* find index value */
		
		op1 = find_operand(tP,tii); /* skip address */
		op1 = find_operand(op1,tii); /* skip address */
		op1 = find_operand(op1,tii);
		rn1 = op1->reg;
		
		/* generate code to void stack */
		
		word = 0; /* number bytes to pop off stack */
		if (rn1 == r_result) word -= sizeof(long);
		if (word) {
			gen_ra3_int(); /* a3 = ptr in int results stack */
			cmpbuf_word(0x47eb); /* lea -k(a3),a3 */
			cmpbuf_word(word);
		} /* word if */
		
		/* jump to begin loop */
					
		gen_ra3_none(); /* insure stack pointer up to date */
		cmpbuf_word(0x6000); /* bra */
		xrefP[xrefri].reloc = 1; /* pc relative branch */
		xrefP[xrefri++].aref = cmpl; /* set address of reference */	
		cmpbuf_word(0); /* planted */	
		
		/* fake reference to end, set head of loop */
		
		cmpbuf_word(0x6000); /* bra */
		xrefP[xrefri].reloc = 1; /* pc relative branch */
		xrefP[xrefri++].aref = cmpl; /* fake reference to end of loop */
		cmpbuf_word(0);
		
		loopstk[loopstkN-1] = cmpl; /* address of head of loop */
		break;
		
	case C_ILOOP1:
	case C_ILOOPINC:
		loopbegf = FALSE; /* past begin of loop */
		gen_begin(); /* must be in compiled code */
		gen_xerr();
		gen_ra3_int(); /* a3 = pointer in integer results stack */
		
		/* stack = increment (ILOOPINC only) */
		/*         end value */
		/*         items (unused) */
		/*         address of index */
		/*         kind (int/byte) of index (unused) */
		/*         index */
				
		/* get end, index, address off stack */
		
		cmpbuf_word(0x47eb); /* lea -20/24(a3),a3 */
		if (code == C_ILOOP1) cmpbuf_word(-20);
		else cmpbuf_word(-24);
		/* get index to d0 */
		gen_movl(3,2,0,0); /* move.l (a3),d0 */
		/* get end to d1 */
		gen_movl(3,5,1,0); /* move.l 16(a3),d1 */
		cmpbuf_word(16);
		/* get address to a1 */
		gen_movl(3,5,1,1); /* move.l 8(a3),a1 */
		cmpbuf_word(8);

		gen_ra3_none(); /* update stack pointer */
		
		/* generate code to increment index and assign */
		
		if (code == C_ILOOP1)
			cmpbuf_word(0x5280); /* addq.l #1,d0 */
		else {
			gen_roe(13,0,2,3,5); /* add.l 20(a3),d0 */
			cmpbuf_word(20);
		}
		if (storinf_kind == TBYTE) {
			gen_movb(0,0,1,2); /* move.b d0,(a1) */
		} else {
			gen_movl(0,0,1,2); /* move.l d0,(a1) */
		} /* storinf else */
		
		/* generate end-test and exit branch */
		
		if (code == C_ILOOP1) {
			cmpbuf_word(0xb280); /* cmp.l d0,d1 */
			cmpbuf_word(0x6b00); /* bmi *+ */
			xrefP[xrefri].reloc = 1; /* pc relative branch */
			xrefP[xrefri++].aref = cmpl; /* set address of reference */
			cmpbuf_word(0); /* planted - loop exit */
		} else {
			cmpbuf_word(0x4aab); /* tst.l 20(a3) */
			cmpbuf_word(20);
			cmpbuf_word(0x6b08); /* bmi *+ */
			cmpbuf_word(0xb280); /* cmp.l d0,d1 */
			cmpbuf_word(0x6b00); /* bmi *+ */
			xrefP[xrefri].reloc = 1; /* pc relative branch */
			xrefP[xrefri++].aref = cmpl; /* set address of reference */
			cmpbuf_word(0); /* planted - loop exit */
			cmpbuf_word(0x6004); /* bra *+ */
			cmpbuf_word(0xb081); /* cmp.l d1,d0 */
			cmpbuf_word(0x6bf6); /* bmi *- */
		}
		break;
	
	case C_ICLOOPINC:
		loopbegf = FALSE;
		gen_begin(); /* must be in compiled code */
		gen_xerr();	
		
		/* locate increment literal value */
		
		nfind = 0; /* havent found any operands yet */
		for(ii = tii; ii >= 0; ii--) {
			if (toktabP[ii].op == tii) {
				nfind++; /* inc number operands found */
				if (nfind == 2)
					break; /* found increment operand */
			} /* toktabP if */
		} /* for */
		if (nfind != 2)
			TUTORdump("C_ICLOOPINC didn't find increment ");
		paddr = pcodeB+toktabP[ii].rel;
		if (*paddr == ILITERAL) {
			paddr++; 
			loopinc = long_read(paddr); /* read integer lit from pcode */
		} else if (*paddr = TKEYWORD)
			loopinc = *(paddr+1); /* read short lit from pcode */
		else 
			TUTORdump("C_ICLOOPINC found unexpected token");
		
		/* get ending value and increment to register */
		
		op3 = find_operand(tP,tii); /* skip address */
		op3 = find_operand(op3,tii); /* increment */
		rn3 = in_general_reg(op3,r_d0+2); 			
		op2 = find_operand(op3,tii); /* ending value */
		rn2 = in_general_reg(op2,r_d0+1);	
		
		/* get address of index variable to a1 */
		
		if (toktab_store >= 0) { /* storinf info on stack */
			gen_ra3_int(); /* a3 = ptr in int stack */
			cmpbuf_word(0x47eb); /* lea -12(a3),a3 */
			cmpbuf_word(-12);
			gen_movl(3,5,1,1); /* move.l 4(a3),a1 */
			cmpbuf_word(4);
		} else if (toktab_store == -2) { /* address on 68000 stack */
			gen_movl(7,3,1,1); /* move.l (sp)+,a1 */
		} else if (toktab_store == -3) { /* address in a1 */
			/* nothing to do - address in a1 */
if ((ra1_gvars == -1) && (ra1_lvars == -1))
	TUTORdump("address in a1?");
		} else { /* address in store_addr */
		
			/* save end, increment if neccessary */
			
			if (rn3 == r_d0+2) 
				gen_movl(2,0,7,4); /* move.l d2,-(a7) */
			if (rn2 == r_d0+1)
				gen_movl(1,0,7,4); /* move.l d1,-(a7) */
				
			/* generate subroutine call to put addr on int stack */
			
			gen_subrxx(EXS_STOREADDR);
			
			/* restore increment, end if neccessary */
			
			if (rn2 == r_d0+1)
				gen_movl(7,3,1,0); /* move.l (a7)+,d1 */
			if (rn3 == r_d0+2)
				gen_movl(7,3,2,0); /* move.l (a7)+,d2 */
				
			/* get address to a1 */
			
			gen_ra3_int(); /* a3 = ptr in integer results stack */
			/* move.l -(a3),a1 */
			gen_movl(3,4,1,1);
		} /* toktab_store else */
		
		/* get index to register */
		
		op1 = find_operand(op2,tii); /* skip storinf */
		op1 = find_operand(op1,tii);
		rn1 = in_general_reg(op1,r_d0); 
		gen_ra3_none(); /* insure stack pointer up to date */
		
		/* increment index */
		
		gen_roe(0xd,rn1,2,rn3,0); /* add.l rn3,rn1 */
		if (storinf_kind == TBYTE) 
			gen_movb(rn1,0,1,2); /* move.b rn1,(a1) */
		else
			gen_movl(rn1,0,1,2); /* move.l rn1,(a1) */
		
		/* generate loop end-test */

		if (loopinc >= 0) 
			gen_roe(0xb,rn2,2,rn1,0); /* cmp.l rn1,rn2 */
		else 
			gen_roe(0xb,rn1,2,rn2,0); /* cmp.l rn2,rn1 */
		cmpbuf_word(0x6b00); /* bmi *+ */
		xrefP[xrefri].reloc = 1; /* pc relative branch */
		xrefP[xrefri++].aref = cmpl; /* set address of reference */
		cmpbuf_word(0); /* planted - loop exit */
		
		toktab_store = -1; /* ready for next storinf */
		break;
		
	case C_FLOOPINIT:
	case C_FLOOPINC:
		gen_ra3_int(); /* a3 = pointer in integer stack */
		if (code == C_FLOOPINIT) {
		
			/* compile ref to begin of loop */
			
			gen_movl(4,7,3,3); /* move.l k,(a3)+ */
			cmpbuf_word(0); /* upper part of long is zero */
			xrefP[xrefri++].aref = cmpl; /* address of reference */
			cmpbuf_word(0); /* planted later */
		} /* floopinit if */
		
		/* compile ref to end of loop */
		
		gen_movl(4,7,3,3); /* move.l k,(a3)+ */
		cmpbuf_word(0); /* upper part of long is zero */
		xrefP[xrefri++].aref = cmpl; /* address of reference */
		cmpbuf_word(0); /* planted later */
		gen_subrxx(code); /* subroutine to do init/inc */
		cmpbuf_word(0x48c0); /* ext.l d0 */
		if (code == C_FLOOPINC) {
			/* compile jump to body of loop */
			cmpbuf_word(0x670a); /* beq *+ */
		}
		gen_ra0_table(EXS_PCODEP); /* get a0 = addr of addr of unit */
		gen_movl(0,2,0,1); /* move.l (a0),a0 */
		ra0_table = -1; /* a0 destroyed */
		gen_roe(0x0d,0,7,0,0); /* add.l d0,a0 */
		cmpbuf_word(0x4ed0); /* jmp (a0) */	
		if (code == C_FLOOPINIT) 
			loopstk[loopstkN-1] = cmpl; /* address of head of loop */
		else loopbegf = FALSE; /* past begin of loop */
		break;
		
	case C_CASE:
	case C_CASEM:
		casestk[casestkN++] = code; /* push -case- command code */
		gen_begin(); /* must be in compiled code */
		gen_xerr();
		gen_subrxx(code); /* subroutine call to start -case- */
		break;
		
	case C_CASET:
		casestk[casestkN++] = code; /* push -case- command code */
		gen_begin(); /* must be in compiled code */
		gen_xerr();
		gen_subrxx(C_CASET); /* call case-table subroutine */
		gen_ra0_table(EXS_PCODEP); /* get a0 = addr of addr of unit */
		cmpbuf_word(0x48c0); /* ext.l d0 */
		gen_movl(0,2,0,1); /* move.l (a0),a0 */
		ra0_table = -1; /* a0 destroyed */
		gen_roe(0x0d,0,7,0,0); /* add.l d0,a0 */
		cmpbuf_word(0x4ed0); /* jmp (a0) */		
		break;
		
	case C_CLAUSE:
	
		/* if optimized -case- remove compiled code for */
		/* C_CLAUSE command arguments */

		if (casestk[casestkN-1] == C_CASET) {
			clauseri = xrefri;
			/* search backwards for clause fwd reference */
			while (xrefP[--clauseri].kind != R_CLAUSE);
if (clauseri < 0) 
	TUTORdump("cant find -case- clause");	
			cmpl = cmplB; /* purge compiled code */
			xrefP[clauseri].aref = 0; /* don't plant fwd reference */
			break; 	
		}
		
		/* generate code for non-optimized (linear search) */
		/* forms of -case- */
		
		gen_begin(); /* must be in compiled code */	
		gen_xerr();
		gen_subrxx(C_CLAUSE); /* subroutine to do compare */
		cmpbuf_word(0x48c0); /* ext.l d0 */
		cmpbuf_word(0x670a); /* beq *+ */
		gen_ra0_table(EXS_PCODEP); /* get a0 = addr of addr of unit */
		gen_movl(0,2,0,1); /* move.l (a0),a0 */
		ra0_table = -1; /* a0 destroyed */
		gen_roe(0x0d,0,7,0,0); /* add.l d0,a0 */
		cmpbuf_word(0x4ed0); /* jmp (a0) */	
		break;	
	
	case C_ENDCASE:
		casestkN--; /* pop -case- stack */
		gen_begin(); /* must be in compiled code */
		gen_xerr();
		gen_subrxx(code); /* subroutine call to end -case- */
		break;
		
	case C_COND:
	case C_CONDOUT:
		gen_begin(); /* must be in compiled code */
		gen_xerr();
		gen_subrxx(code); /* call cond cmd subroutine */
		gen_ra0_table(EXS_PCODEP); /* get a0 = addr of addr of unit */
		cmpbuf_word(0x48c0); /* ext.l d0 */
		gen_movl(0,2,0,1); /* move.l (a0),a0 */
		ra0_table = -1; /* a0 destroyed */
		gen_roe(0x0d,0,7,0,0); /* add.l d0,a0 */
		cmpbuf_word(0x4ed0); /* jmp (a0) */		
		break;
	
	case C_ICALC:
		op1 = find_operand(tP,tii);
		rn1 = in_general_reg(op1,r_d0); /* get result to reg */
		break;
						
	default:
		gen_begin(); /* must be in compiled code */
		gen_xerr();
		gen_subrxx(code);
		break;
		
	} /* switch */
	
} /* gen_code_command */

/* ******************************************************************* */

/* table of commands which must be interpreted */

/* a.  commands which (may) return to interact loop */
/* b.  commands which (may) reallocate user variables stack */
/* c.  commands which are recognized by a special purpose interpretation */
/*     loop (such as ENDTEXT commands) */
/* d.  commands which (may) branch to another point in the pcode */
/* e.  commands which require excessive compiled code (such as -palette-) */

#define interp_n 66

static short interp_tab[interp_n] = {
	C_XIN,
	C_XOUT,
	C_DATAOUT,
	C_DATAIN,
	C_NUMOUT,
	C_READLN,
	C_CLRKEY,
	C_GETKEY,
	C_PRESS,
	C_DO,
	C_JUMP,
	C_OUTUNIT,
	C_ENDUNIT,
	C_ARROW,
	C_ARROW1,
	C_ARROW2,
	C_ARROW3,
	C_ENDARROW,
	C_PREANS,
	C_ENDANS,
	C_IFMATCH,
	C_JUDGE,
	C_OKCMD,
	C_NOCMD,
	C_EXACT,
	C_EXACTW,
	C_ANSWER,
	C_WRONG,
	C_ANSV,
	C_WRONGV,
	C_MARKPT,
	C_PAUSE,
	C_CMDS,
	C_ENDTEXT,
	C_ENDTEXT1,
	C_ENDTEXT2,
	C_STRING,
	C_TEXT,
	C_RTEXT,
	C_GTEXT,
	C_JUMPOUT,
	C_ICONS,
	C_FONT,
	C_CURSOR,
	C_PATTERN,
	C_FOCUS,
	C_BEEP,
	C_OBJW,
	C_SOCKET,
	C_SERVER,
	C_SOCKWAIT,
	C_VWAIT,
	C_VSTEP,
	C_SETFILE,
	C_SETDIR,
	C_ADDFILE,
	C_DIALOG,
	C_PALETTE,
	C_NEWPAL,
	C_FPALETTE,
	C_PUT,
	C_RPUT,
	C_GPUT,
	C_GET,
	C_RGET,
	C_GGET
}; /* interp_tab */

static int must_interpret(code) 
/* returns TRUE if this command must be interpreted, not compiled */
int code;

{	int ii;

	for(ii=0; ii<interp_n; ii++) {
		if (code == interp_tab[ii]) return(TRUE);
	} /* for */
	return(FALSE); /* don't force interpretation */
	
} /* must_interpret */

/* ******************************************************************* */

/* conversion tables for pcodes with special compiled-code */
/* call-able subroutines */

#define subr_code_n 91

static short subr_code_from[subr_code_n] = {
	GARRAYVAL,
	GARRAYADDR,
	IGARRAYVAL,
	IGARRAYADDR,
	BGARRAYVAL,
	BGARRAYADDR,
	MGARRAYVAL,
	MGARRAYADDR,
	LARRAYVAL,
	LARRAYADDR,	
	ILARRAYVAL,
	ILARRAYADDR,
	BLARRAYVAL,
	BLARRAYADDR,	
	MLARRAYVAL,
	MLARRAYADDR,
	PARRAYVAL,
	IPARRAYVAL,
	BPARRAYVAL,
	MPARRAYVAL,
	PARRAYADDR,
	IPARRAYADDR,
	BPARRAYADDR,
	MPARRAYADDR,
	MPASSVAL,
	MPASSADDR,
	MLITERAL,
	MGLOBALVAL,
	MLOCALVAL,
	EXPONIC,
	SYSVAR,
	ISYSVAR,
	TSYSVAR,
	MSYSVAR,
	MSYSVARA,
	EFUNCT,
	SPLT,
	SPGT,		
	SPLE, 
	SPGE,
	SPEQ, 	
	SPNE,
	ISPLT,
	ISPGT,		
	ISPLE, 
	ISPGE,
	ISPEQ, 	
	ISPNE,
	MSPLT,	
	MSPGT, 	
	MSPLE, 	
	MSPGE, 		
	MSPEQ, 	
	MSPNE,
	XGARRAYVAL,
	XLARRAYVAL,
	XPARRAYVAL,
	XGLOBALVAL,
	XLOCALVAL,
	XPASSVAL,
	GDYARRAYVAL,
	GDYARRAYADDR,
	IGDYARRAYVAL,
	IGDYARRAYADDR,
	BGDYARRAYVAL,
	BGDYARRAYADDR,
	MGDYARRAYVAL,
	MGDYARRAYADDR,
	XGDYARRAYVAL, 
	XGDYARRAYADDR,
	LDYARRAYVAL,
	LDYARRAYADDR,
	ILDYARRAYVAL,
	ILDYARRAYADDR,
	BLDYARRAYVAL,
	BLDYARRAYADDR,
	MLDYARRAYVAL,
	MLDYARRAYADDR,
	XLDYARRAYVAL,
	XLDYARRAYADDR,
	PDYARRAYVAL,
	PDYARRAYADDR,
	IPDYARRAYVAL,
	IPDYARRAYADDR,
	BPDYARRAYVAL,
	BPDYARRAYADDR,
	MPDYARRAYVAL,
	MPDYARRAYADDR,
	XPDYARRAYVAL,
	XPDYARRAYADDR,
	0
}; /* code_from */	

static short subr_code_to[subr_code_n] = {
	EXS_GARRAYVAL,
	EXS_GARRAYADDR,
	EXS_IGARRAYVAL,
	EXS_IGARRAYADDR,
	EXS_BGARRAYVAL,
	EXS_BGARRAYADDR,
	EXS_MGARRAYVAL,
	EXS_MGARRAYADDR,
	EXS_LARRAYVAL,
	EXS_LARRAYADDR,	
	EXS_ILARRAYVAL,
	EXS_ILARRAYADDR,
	EXS_BLARRAYVAL,
	EXS_BLARRAYADDR,	
	EXS_MLARRAYVAL,
	EXS_MLARRAYADDR,
	EXS_PARRAYVAL,
	EXS_IPARRAYVAL,
	EXS_BPARRAYVAL,
	EXS_MPARRAYVAL,
	EXS_PARRAYADDR,
	EXS_IPARRAYADDR,
	EXS_BPARRAYADDR,
	EXS_MPARRAYADDR,
	EXS_MPASSVAL,
	EXS_MPASSADDR,
	EXS_MLITERAL,
	EXS_MGLOBALVAL,
	EXS_MLOCALVAL,
	EXS_EXPONIC,
	EXS_SYSVAR,
	EXS_ISYSVAR,
	EXS_TSYSVAR,
	EXS_MSYSVAR,
	EXS_MSYSVARA,
	EXS_EFUNCT,
	EXS_SPLT,	
	EXS_SPGT,		
	EXS_SPLE,	
	EXS_SPGE,	
	EXS_SPEQ, 	
	EXS_SPNE, 
	EXS_ISPLT,
	EXS_ISPGT,		
	EXS_ISPLE, 
	EXS_ISPGE,
	EXS_ISPEQ, 	
	EXS_ISPNE,
	EXS_MSPLT,		
	EXS_MSPGT, 		
	EXS_MSPLE,	
	EXS_MSPGE, 	
	EXS_MSPEQ, 	
	EXS_MSPNE,
	EXS_IGARRAYVAL,
	EXS_ILARRAYVAL,
	EXS_IPARRAYVAL,
	EXS_XGLOBALVAL,
	EXS_XLOCALVAL,
	EXS_XPASSVAL,
	EXS_GDYARRAYVAL,
	EXS_GDYARRAYADDR,
	EXS_IGDYARRAYVAL,
	EXS_IGDYARRAYADDR,
	EXS_BGDYARRAYVAL,
	EXS_BGDYARRAYADDR,
	EXS_MGDYARRAYVAL,
	EXS_MGDYARRAYADDR,
	EXS_XGDYARRAYVAL, 
	EXS_XGDYARRAYADDR,
	EXS_LDYARRAYVAL,
	EXS_LDYARRAYADDR,
	EXS_ILDYARRAYVAL,
	EXS_ILDYARRAYADDR,
	EXS_BLDYARRAYVAL,
	EXS_BLDYARRAYADDR,
	EXS_MLDYARRAYVAL,
	EXS_MLDYARRAYADDR,
	EXS_XLDYARRAYVAL,
	EXS_XLDYARRAYADDR,
	EXS_PDYARRAYVAL,
	EXS_PDYARRAYADDR,
	EXS_IPDYARRAYVAL,
	EXS_IPDYARRAYADDR,
	EXS_BPDYARRAYVAL,
	EXS_BPDYARRAYADDR,
	EXS_MPDYARRAYVAL,
	EXS_MPDYARRAYADDR,
	EXS_XPDYARRAYVAL,
	EXS_XPDYARRAYADDR,
	0
}; /* code_to */

static int cvt_subr(code) /* look up compiled-code call-able subroutine */
int code;
{	short *cvtP; /* pointer in conversion table */
	int subrii; /* index of subroutine */
	
	/* look up index of compiled code call-able function */

	cvtP = &(subr_code_from[0]);
	while (code != *cvtP) {
		if (!*cvtP++) 
			TUTORdump("ran off end of cvt table");
	}
	subrii = cvtP-&subr_code_from[0];
	subrii = subr_code_to[subrii];
	return(subrii);

} /* cvt_subr */

/* ******************************************************************* */

static struct toktab FAR *find_operand(tokP,opi) 
/* find toktab entry for operand of specified operator */
register struct toktab FAR *tokP; /* starting ptr for backwards search */
int opi; /* index of operator */

{	struct toktab FAR *svP;

	svP = tokP;
	do {
		if ((--tokP)->op == opi)
			return(tokP); /* return index of find */
	} while (tokP > toktabP);

	TUTORdump("find_operand failed");
	
} /* find_operand */

/* ******************************************************************* */

static int in_general_reg(tokP,rscr) /* insure operand in general register */
struct toktab FAR *tokP; /* pointer to token table entry */
int rscr; /* index of scratch general register */

{	int rn; /* current register number */
	int regtyp; /* current register type */

	rn = tokP->reg;
	regtyp = r_type[rn];
	if (regtyp == rt_general) return(rn); /* nothing to do */
	
	/* move operand to scratch register */
	
	if (rn == r_result) 
		gen_ra3_int(); /* a3 = ptr in int stack */
	gen_movl(reg_num(rn),reg_src_mode(rn),rscr,0);
	return(rscr); /* return register containing operand */
	
} /* in_general_register */

/* ******************************************************************* */

reg_num(rn) /* return physical register number for logical register */
int rn; /* logical register number */

{	
	if (rn == r_result) return(3); /* result stack ptr = a3 */
	if (rn < (r_d0+8)) return(rn); /* d0 - d7 */
	return(rn-r_a0); /* a0 - a7 */

} /* reg_num */

/* ******************************************************************* */

reg_src_mode(rn) /* return addressing mode for source logical register */
int rn; /* logical register number */

{
	if (rn == r_result) return(4); /* -(a3) */
	if (rn < (r_d0+8)) return(0); /* d0 - d7 */
	return(1); /* a0 - a7 */

} /* reg_src_mode */

/* ******************************************************************* */

reg_dest_mode(rn) /* return addressing mode for destination logical reg */
int rn; /* logical register number */

{
	if (rn == r_result) return(3); /* (a3)+ */
	if (rn < (r_d0+8)) return(0); /* d0 - d7 */
	return(1); /* a0 - a7 */

} /* reg_dest_mode */

/* ******************************************************************* */

gen_movl(srn, srm, drn, drm)	/* generate move.l instruction */
int srn; /* source register number */
int srm; /* source addressing mode */
int drn; /* destination register number */
int drm; /* destination addressing mode */

{	unsigned int word;

	word = 0x20 + (drn << 1)+((drm >> 2) & 1); /* 0010rrrm */
	word = word << 8;
	word |= ((drm & 3) << 6)+(srm << 3)+srn; /* mmnnnrrr */
	cmpbuf_word(word);

} /* gen_movl */

/* ******************************************************************* */

gen_movw(srn, srm, drn, drm)	/* generate move.w instruction */
int srn; /* source register number */
int srm; /* source addressing mode */
int drn; /* destination register number */
int drm; /* destination addressing mode */

{	unsigned int word;

	word = 0x30 + (drn << 1)+((drm >> 2) & 1); /* 0011rrrm */
	word = word << 8;
	word |= ((drm & 3) << 6)+(srm << 3)+srn; /* mmnnnrrr */
	cmpbuf_word(word);

} /* gen_movw */

/* ******************************************************************* */

gen_movb(srn, srm, drn, drm) /* generate move.b instruction */
int srn; /* source register number */
int srm; /* source addressing mode */
int drn; /* destination register number */
int drm; /* destination addressing mode */

{	unsigned int word;

	word = 0x10 + (drn << 1)+((drm >> 2) & 1); /* 0001rrrm */
	word = word << 8;
	word |= ((drm & 3) << 6)+(srm << 3)+srn; /* mmnnnrrr */
	cmpbuf_word(word);

} /* gen_movb */

/* ******************************************************************* */

gen_stackf(arn) /* copy floating value to result stack */
int arn; /* a-register pointing to floating value */

{
	gen_movl(arn,3,3,3); /* move.l (an)+,(a3)+ */
	gen_movl(arn,2,3,3); /* move.l (an),(a3)+ */

	/* mark appropriate register destroyed by (an)+ */
		
	switch (arn) {
	case 0:
		ra0_table = -1;
		break;
	case 1: 
		ra1_gvars = ra1_lvars = -1;
		break;
	case 2:
		ra2_locals = ra2_globals = -1;
		break;
	default:
		break;
	} /* switch */
	
} /* gen_stack */

/* ******************************************************************* */

gen_roe(cod,rn,om,drn,drm) /* generate reg/op-mode/ea form instruction */
int cod; /* instruction code */
int rn;  /* register number */
int om;  /* op-mode */
int drn; /* effective address register number */
int drm; /* effective address mode */

{	unsigned int word;

	word = (cod << 4)+(rn << 1)+((om >> 2) & 1); /* ccccrro */
	word = word << 8;
	word |= (((om & 3) << 6)+(drm << 3)+drn); /* oommmrrr */
	cmpbuf_word(word);
	
} /* gen_roe */

/* ******************************************************************* */

gen_subrxx(opc)
/* generate call to subroutine which takes arguments from result stack */
/* and returns result on result stack */
int opc; /* index of subroutine (0 - C_MAX) */

{	int disp;

	gen_ra3_none(); /* store result stack pointer */
	
	/* generate code to load a0 with address of routine */
	
	disp = opc*sizeof(long); /* displacement in table */
	gen_movl(4,5,0,1); /* move.l  k(a4),a0 */
	cmpbuf_word((unsigned int)disp); /* add displacement */

	/* generate subroutine call */

	cmpbuf_word(0x4e90); /* jsr (a0) */
	
	ra0_table = ra1_gvars = ra1_lvars = -1; /* a0, a1 destroyed */

} /* gen_subrxx */

/* ******************************************************************* */

gen_storinf(type) /* generate store-ability info */
/* assumes address of variable is in a1 */
int type; /* store-ability type */

{
	/* generate code to return address, type, #items */
		
	gen_ra3_int(); /* a3 = ptr in integer stack */
	gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
	cmpbuf_long((long)(type));
	gen_movl(1,1,3,3); /* move.l a1,(a3)+ */
	gen_movl(4,7,3,3); /* move.l #k,(a3)+ */
	cmpbuf_long(1L);
			
} /* gen_storinf */

/* ******************************************************************* */

init_volatile () /* assume volatile registers destroyed */

{
	ra0_table = ra1_gvars = ra1_lvars = -1;
	ra2_locals = ra2_globals = FALSE; 	
	ra3_int = ra3_float = FALSE;
	toktab_store = -1; /* no storinf info yet */
	
} /* init_volatile */

/* ******************************************************************* */

gen_begin() /* generate initial setup code */

{	
	if (incode) return; /* already in compiled code */
	incode = TRUE;
	cmpbuf_word(CCODE); /* flip from interpreted to compiled */

#ifdef NoSuch	
	{
		char msg[80]; 
		sprintf(msg,"machine code at: %lx\n",(long)(cmpbuf+cmpl)); 
		TUTORlog(msg);  
	}
#endif
	
	r_used[r_d0] = r_used[r_a0+4] = TRUE; /* d0, a4 used in setup code */
	init_volatile(); /* mark volatile registers destroyed */
	
	/* get address of exs_addr[] table from stack */

	gen_movl(7,5,0,0); /* movel 4(sp),d0) */
	cmpbuf_word(4); /* add displacement */

	/* generate movem.l instruction to save registers */

	cmpbuf_word(0x48e7);	/* movem.l  /.../,(sp)- */
	movemP[movemN].type = 0; /* register -> memory */
	movemP[movemN++].addr = cmpl;
	cmpbuf_word(0);

	/* copy address of exs_addr[] table to a4 */

	gen_movl(0,0,4,1); /* move.l d0,a4 */
	ra4_table = TRUE; /* flag table set up */

} /* gen_begin */

/* ******************************************************************* */

gen_end() /* generate return from compiled code */

{	int ri; /* index in r_used */
	int rm; /* register mask to save registers */
	int mr; /* register mask to restore registers */
	int mi; /* index in movemP */
	struct movem FAR *mP; /* pointer in movemP table */

	if (!incode) return; /* not in compiled code */

	gen_ra3_none(); /* update stack ptr if still in register */
	
	/* generate code to update interpreter execution pointer */
	
	gen_ra0_table(EXS_BINP);
	cmpbuf_word(0x43fa); /* lea pc+k,a1 */
	cmpbuf_word(10); 
	gen_movl(1,1,0,2); /* move.l a1,(a0) */
	ra1_gvars = ra1_lvars = -1;
		
	/* check if room in movem table for another entry */
	
	if (movemN >= (movemL-2)) { /* table will be full on next gen_begin */
		movemL += 10; /* increment table length */
		movemP = (struct movem FAR *)TUTORrealloc(
		           (char FAR *)movemP,
		           (long)((movemL-10)*sizeof(struct movem)),
		           (long)(movemL*sizeof(struct movem)),
	               TRUE);
	} 
	
	/* generate movem.l instruction to restore registers */
	
	cmpbuf_word(0x4cdf); /* movem.l  /.../,+(sp) */
	movemP[movemN].type = 1; /* memory -> register */
	movemP[movemN++].addr = cmpl;
	cmpbuf_word(0);
	
	/* generate mask for initial movem.l instruction(s) which */
	/* saved registers */
	
	rm = 0;	/* initialize register mask */
	for (ri=3; ri<8; ri++)	/* build D register part of mask */
		if (r_used[ri]) rm |= (1 << ((7-ri)+8)); /* d3-d7 */
	for (ri=2; ri<7; ri++)	/* build A register part of mask */
		if (r_used[ri+8]) rm |= (1 << (7-ri)); /* a2-a7 */
	
	/* generate mask for final movem.l instruction(s) which */
	/* restore registers */

	mr = 0;	/* initialize register mask */
	for (ri=3; ri<8; ri++)	/* build d register part of mask */
		if (r_used[ri]) mr = mr | (1 << ri); /* d3-d7 */
	for (ri=2; ri<7; ri++)	/* build a register part of mask */
		if (r_used[ri+8]) mr =  mr | (1 << (ri+8)); /* a2-a6 */

	/* plant masks in movem.l instructions */
	
	mP = movemP;
	for (mi=0; mi<movemN; mi++) {
		if (mP->type) 
			*(short FAR *)(cmpbuf+mP->addr) = mr; /* memory -> register */
		else
			*(short FAR *)(cmpbuf+mP->addr) = rm; /* register -> memory */
		mP++;
	}
	
	/* generate return from subroutine */

	cmpbuf_word(0x4e75); /* rts */
	incode = FALSE; /* no longer in compiled code block */
	
#ifdef NoSuch
{
		char msg[80]; 
		sprintf(msg,"interpreted code at: %lx\n",(long)(cmpbuf+cmpl)); 
	TUTORlog(msg); 
}	
#endif

} /* gen_end */

/* ******************************************************************* */

gen_xerr() /* generate code to update interpreters execution */
           /* pointer if this command may fail on an execution error */
{
	if (toktab_xerr) {	
		gen_ra0_table(EXS_BINP);
		cmpbuf_word(0x43fa); /* lea pc+k,a1 */
		cmpbuf_word(2);
		gen_movl(1,1,0,2); /* move.l a1,(a0) */
		ra1_gvars = ra1_lvars = -1;
		toktab_xerr = FALSE;
	} /* toktab_xerr if */
	
} /* gen_xerr */

/* ******************************************************************* */

gen_ra3_none() /* update pointer currently in a3, free a3 */

{	
	gen_ra3_update(); /* bring pointer up to date */
	ra3_int = ra3_float = FALSE; /* a3 no longer valid */
	
} /* gen_ra3_none */

/* ******************************************************************* */

gen_ra3_update() /* update pointer currently in a3, free a3 */

{	int disp; /* displacement in table */

	if (ra3_int) disp = EXS_IRESP*sizeof(long);
	else if (ra3_float) disp = EXS_FRESP*sizeof(long);
	else return; /* a3 not in use */
	
	if (ra0_table != disp) {
		ra0_table = disp;
		gen_movl(4,5,0,1); /* move.l k(a4),a0 */
		cmpbuf_word(ra0_table);
	}
	gen_movl(3,1,0,2); /* move.l a3,(a0) */
	
} /* gen_ra3_update */

/* ******************************************************************* */

gen_ra3_int() /* setup a3 as pointer in integer results table */

{	
	if (ra3_int) return; /* already set up */
	
	gen_ra3_none(); /* update current pointer */
	gen_ra0_table(EXS_IRESP); /* a0 = addr of table entry */
	gen_movl(0,2,3,1); /* move.l (a0),a3 */
	ra3_int = TRUE; 
	ra3_float = FALSE;
			
} /* gen_ra3_int */

/* ******************************************************************* */

gen_ra3_float() /* setup a3 as pointer in floating results table */

{	
	if (ra3_float) return; /* already set up */
	
	gen_ra3_none(); /* update current pointer */
	gen_ra0_table(EXS_FRESP); /* a0 = addr of table entry */
	gen_movl(0,2,3,1); /* move.l (a0),a3 */	
	ra3_float = TRUE;
	ra3_int = FALSE; 
			
} /* gen_ra3_float */

/* ******************************************************************* */

gen_ra2_globals() /* setup a2 as pointer to global variables */

{
	if (ra2_globals) return; /* already set up */

	gen_movl(4,5,2,1); /* move.l k(a4),a2 */	
	cmpbuf_word((int)sizeof(long)*EXS_GLOBALP);
	ra2_globals = TRUE;
	ra2_locals = FALSE;
	
} /* gen_ra2_globals */

/* ******************************************************************* */

gen_ra2_locals() /* setup a2 as pointer to local variables */

{
	if (ra2_locals) return; /* already set up */
	
	gen_movl(4,5,2,1); /* move.l k(a4),a2 */	
	cmpbuf_word((int)sizeof(long)*EXS_LOCALP);
	ra2_locals = TRUE;
	ra2_globals = FALSE;
	
} /* gen_ra2_locals */

/* ******************************************************************* */

gen_ra1_ra2_gvar(addr) /* get a1 = address of global variable */
                       /*     a2 = base address of globals */
long addr; /* relative address of global variable */

{
	gen_ra2_globals(); /* a2 = address of globals */
	if (ra1_gvars == addr) return; /* a1 already correct */
	
	if (addr < 0x7fff) {
		cmpbuf_word(0x43ea); /* lea k(a2),a1 */
		cmpbuf_word((unsigned int)addr);
	} else {
		gen_movl(4,7,1,1); /* move.l #k,a1 */
		cmpbuf_long(addr);
		gen_roe(13,1,7,2,1); /* add.l a2,a1 */
	}
	ra1_lvars = -1; 
	ra1_gvars = addr;
	
} /* gen_ra1_ra2_gvar */

/* ******************************************************************* */

gen_ra1_ra2_lvar(addr) /* get a1 = address of local variable */
                       /*     a2 = base address of locals */
long addr; /* relative address of local variable */

{
	gen_ra2_locals(); /* a2 = address of local variables */
	if (ra1_lvars == addr) return; /* a1 already correct */
	
	if (addr < 0x7fff) {
		cmpbuf_word(0x43ea); /* lea k(a2),a1 */
		cmpbuf_word((unsigned int)addr);
	} else {
		gen_movl(4,7,1,1); /* move.l #k,a1 */
		cmpbuf_long(addr);
		gen_roe(13,1,7,2,1); /* add.l a2,a1 */
	}
	ra1_gvars = -1;
	ra1_lvars = addr; /* a1 = pointer in local variables */

} /* gen_ra1_ra2_lvar */

/* ******************************************************************* */

gen_var(addr,rn,size) /* load variable to specified register */
/* a2 must already point to globals or locals */
long addr; /* address of variable relative to a2 */
int rn; /* register/psuedo register number */
int size; /* size of variable in bytes */

{
	if (addr < 0x7fff) {
		if (size == 4) {
			/* move.l #k(a2),dn or move.l #k(a2),(a3)+ */
			gen_movl(2,5,reg_num(rn),reg_dest_mode(rn));
		} else {
			/* move.b #k(a2),dn or move.b #k(a2),(a3)+ */
			gen_movb(2,5,reg_num(rn),reg_dest_mode(rn));
		}
		cmpbuf_word((unsigned int)addr);	
	} else {
		gen_movl(4,7,1,1); /* move.l #k,a1 */
		cmpbuf_long(addr);
		gen_roe(13,1,7,2,1); /* add.l a2,a1 */
		if (size == 4) {
			/* move.l (a1),dn or move.l (a1),(a3)+ */
			gen_movl(1,2,reg_num(rn),reg_dest_mode(rn));
		} else {
			/* move.b (a1),dn or move.lb (a1),(a3)+ */
			gen_movb(1,2,reg_num(rn),reg_dest_mode(rn));		
		}
		if (ra2_globals) {
			ra1_gvars = addr; /* a1 = pointer in global vars */
			ra1_lvars = -1;
		} else {
			ra1_lvars = addr; /* a1 = pointer in local vars */
			ra1_gvars = -1;
		}
	} /* addr else */
	
} /* gen_var */

/* ******************************************************************* */

gen_ra0_table(index) /* get a0 = address of table entry */
int index; /* index in table */

{	int disp; /* displacement in table */

	disp = index*sizeof(long);
	if (ra0_table != disp) { /* check if a0 already correct */
		ra0_table = disp;
		gen_movl(4,5,0,1); /* move.l k(a4),a0 */
		cmpbuf_word(ra0_table);
	}
	
} /* gen_ra0_table */

/* ******************************************************************* */

icgen() /* one-time initializations for code generator */

{	int ii;

	for(ii=0; ii<XT_MAX; ii++)
		xtP[ii].cgen = or_subrxx; /* assume subroutine */
		
	xtP[ILITERAL].cgen = or_general;
	xtP[FLITERAL].cgen = or_operandx;
	xtP[MLITERAL].cgen = or_operandx;
	xtP[MLITC].cgen = or_operandx;
	xtP[GLOBALVAL].cgen = or_operandx;
	xtP[IGLOBALVAL].cgen = or_general;
	xtP[XGLOBALVAL].cgen = or_operandx;
	xtP[BGLOBALVAL].cgen = or_general;
	xtP[MGLOBALVAL].cgen = or_operandx;
	xtP[GLOBALADDR].cgen = or_operandx;
	xtP[IGLOBALADDR].cgen = or_general;
	xtP[BGLOBALADDR].cgen = or_general;
	xtP[MGLOBALADDR].cgen = or_operandx;
	xtP[GARRAYVAL].cgen = or_operandx;
	xtP[GARRAYADDR].cgen = or_operandx;
	xtP[IGARRAYVAL].cgen = or_ibarray;
	xtP[IGARRAYADDR].cgen = or_ibarray;
	xtP[BGARRAYVAL].cgen = or_ibarray;
	xtP[BGARRAYADDR].cgen = or_ibarray;
	xtP[MGARRAYVAL].cgen = or_operandx;
	xtP[MGARRAYADDR].cgen = or_operandx;
	xtP[XGARRAYVAL].cgen = or_operandx;
	xtP[LOCALVAL].cgen = or_operandx;
	xtP[ILOCALVAL].cgen = or_general;
	xtP[BLOCALVAL].cgen = or_general;
	xtP[MLOCALVAL].cgen = or_operandx;
	xtP[XLOCALVAL].cgen = or_operandx;
	xtP[LOCALADDR].cgen = or_general;
	xtP[ILOCALADDR].cgen = or_general;
	xtP[BLOCALADDR].cgen = or_general;	
	xtP[MLOCALADDR].cgen = or_operandx;
	xtP[LARRAYVAL].cgen = or_operandx;
	xtP[LARRAYADDR].cgen = or_operandx;
	xtP[ILARRAYVAL].cgen = or_ibarray;
	xtP[ILARRAYADDR].cgen = or_ibarray;
	xtP[BLARRAYVAL].cgen = or_ibarray;
	xtP[BLARRAYADDR].cgen = or_ibarray;
	xtP[MLARRAYVAL].cgen = or_operandx;
	xtP[MLARRAYADDR].cgen = or_operandx;
	xtP[XLARRAYVAL].cgen = or_operandx;
	xtP[PASSVAL].cgen = or_general;
	xtP[IPASSVAL].cgen = or_general;
	xtP[BPASSVAL].cgen = or_general;
	xtP[MPASSVAL].cgen = or_operandx;
	xtP[XPASSVAL].cgen = or_operandx;
	xtP[PASSADDR].cgen = or_general;
	xtP[IPASSADDR].cgen = or_general;
	xtP[BPASSADDR].cgen = or_general;
	xtP[MPASSADDR].cgen = or_operandx;
	xtP[PARRAYVAL].cgen = or_operandx;
	xtP[IPARRAYVAL].cgen = or_operandx;
	xtP[BPARRAYVAL].cgen = or_operandx;
	xtP[MPARRAYVAL].cgen = or_operandx;
	xtP[XPARRAYVAL].cgen = or_operandx;
	xtP[GARRAY].cgen = or_operandx;
	xtP[IGARRAY].cgen = or_operandx;
	xtP[BGARRAY].cgen = or_operandx;
	xtP[MGARRAY].cgen = or_operandx;
	xtP[XGARRAY].cgen = or_operandx;
	xtP[LARRAY].cgen = or_operandx;
	xtP[ILARRAY].cgen = or_operandx;
	xtP[BLARRAY].cgen = or_operandx;
	xtP[MLARRAY].cgen = or_operandx;
	xtP[XLARRAY].cgen = or_operandx;
	xtP[PARRAY].cgen = or_operandx;
	xtP[IPARRAY].cgen = or_operandx;
	xtP[BPARRAY].cgen = or_operandx;
	xtP[MPARRAY].cgen = or_operandx;
	xtP[XPARRAY].cgen = or_operandx;
	xtP[SYSVAR].cgen = or_operandx;
	xtP[MSYSVAR].cgen = or_operandx;
	xtP[MSYSVARA].cgen = or_operandx;
	xtP[IASSIGN].cgen = or_ibassign;
	xtP[BASSIGN].cgen = or_ibassign;
	xtP[IPLUS].cgen = or_general;
	xtP[IMINUS].cgen = or_general;
	xtP[IINC].cgen = or_general;
	xtP[IDEC].cgen = or_general;
	xtP[IUMINUS].cgen = or_general;
	xtP[COMP].cgen = or_general;
	xtP[LSHIFT].cgen = or_general;
	xtP[RSHIFT].cgen = or_general;
	xtP[LMASK].cgen = or_general;
	xtP[LUNION].cgen = or_general;
	xtP[LDIFF].cgen = or_general;
	xtP[AND].cgen = or_general;
	xtP[OR].cgen = or_general;
	xtP[IEQ].cgen = or_general;
	xtP[INE].cgen = or_general;
	xtP[IGT].cgen = or_general;
	xtP[ILT].cgen = or_general;
	xtP[IGE].cgen = or_general;
	xtP[ILE].cgen = or_general;
	xtP[ITOC].cgen = or_general;
	xtP[TKEYWORD].cgen = or_operandx;
	xtP[STORINF].cgen = or_general;
	xtP[IBRANCHF].cgen = or_general;
	xtP[IBRANCHT].cgen = or_general;
	xtP[SKIP].cgen = or_general;
	xtP[TDOT].cgen = or_general;
	xtP[TPOINT].cgen = or_general;
	xtP[TEXTARG].cgen = or_operandx;
		
} /* icgen */

/* ******************************************************************* */

#endif /* MAC */


