
/* (c) Copyright Carnegie-Mellon University, 1988. */
/* May be used and copied freely for educational purposes, */
/* but may not be sold without the written consent of Carnegie-Mellon University. */


#include "baseenv.h"
#include <stdio.h>
#include <bios.h>
#include <dos.h>
#include <signal.h>
#ifdef TURBOC
#include <alloc.h>
#endif
#include "baseenv.h"
#include "compute.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "memory.h"

#ifdef ctproto
extern int pc_recycle_handle_mem(Memh mm);
int LockMemoryTable(void);
int UnlockMemoryTable(void);
char  FAR *GetPtr(unsigned int  mm);
int  ReleasePtr(unsigned int  mm);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORdump_handle(unsigned int  mm);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
struct  htab FAR *TUTORget_entry_mem(int  handle);
int  DeleteFromHandle(unsigned int  mm,long  di,long  dl);
int  InsertIntoHandle(unsigned int  mm,char  FAR *is,long  ip,long  il);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
char  FAR *TUTORrealloc(char  FAR *ptr,long  oldsize,long  newsize,int  abort);
int  memchain(int  calli);
int  TUTORdealloc(char  FAR *ptr);
long  TUTORinq_mem_available(void);
extern int  nomem(char  *msg);
int  pc_drop_mem(void);
char  FAR *pc_get_mem(long  size,int  strategy,char  *label);
extern char  FAR *pc_alloc(long  size,int  strategy,char  *label);
int  pc_reduce_alloc(char  FAR *ptr,long  newsize);
int  pc_mem_purge(long  target);
int  pc_mem_compress(void);
int  pc_mem_tasks(void);
struct  htab FAR *pc_htab(int  handle);
int  pc_identify_handle(char  FAR *ptr,int  handle);
extern char FAR *pc_lp(long pp);
extern long pc_pl(char FAR *pp);
void  TUTORdelete_swap(long  pos);
int  TUTORdump(char  *s);
char  FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
int  TUTORrecover_handle(struct  htab FAR *hp,char  FAR *areap,int  handle);
extern TUTORblock_move(char FAR *sp, char FAR *dp, long lth);
extern struct memhdr FAR *pc_nxf(struct memhdr FAR *mm,long ss);
int  TUTORexpand_swap(void);
int  TUTORtrace_x(char  *s,long  nn);
int  TUTORinq_swap(void);
long  TUTORinq_msec_clock(void);
extern char FAR *pc_np(char FAR *pp);
long  TUTORwrite_swap(char  FAR *memp,long  size);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

extern long memtst();
extern long lastmsec;
extern char FAR *pc_alloc(long size,int strategy,char *label);
extern char FAR *pc_get_mem(long size,int strategy,char *label);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  TUTORclose(int  findx);
int  TUTORinq_file_info(struct    _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
long  TUTORinq_file_pos(int  findx);
int  TUTORinq_file_err(int  findx);
int  TUTORstat(struct  _fref FAR *fRef,struct  stat *buff);
int  TUTORseek(int  findx,long  pos);
long  TUTORwrite(char  FAR *ptr,int  pSize,long  count,int  findx);
long  TUTORread(char  FAR *ptr,int  pSize,long    count,int  findx);
int  TUTORreset_file(int  findx,int  option);
int  TUTORtemp_file_name(struct  _fref FAR *baseN,struct  _fref FAR *tempN);
int  TUTORopen_ems(long  FAR *size);
unsigned char  FAR *TUTORscan_bytes(unsigned char  FAR *bp,unsigned char  FAR *be,unsigned char  *tp,int  nTab);
int  TUTORcount_bytes(unsigned char  FAR *tp,unsigned char  FAR *te,int  cc);
unsigned int  TUTORcopy_handle(unsigned int  mm);
long  TUTORget_hsize(unsigned int  mm);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (*restoreproc)(),int  restorearg);
int  AllowHandlePurge(unsigned int  mm);
int  ChangedHandle(unsigned int  mm,int  stillPurge);
int  TUTORhandle_ispurged(unsigned int  mm);
int  TUTORrecover_handle(struct  htab FAR *hp,char  FAR *areap,int  handle);
int  TUTORinq_swap(void);
int  TUTORexpand_swap(void);
void  TUTORscan_swap(long  pos,long  length,char  FAR *memp);
void  TUTORdelete_swap(long  pos);
long  TUTORwrite_swap(char  FAR *memp,long  size);
int  assoc_name(struct    _fref FAR *fn,struct  _fref FAR *bfilen,char  *extnNew);

/* ******************************************************************* */

extern char FAR *TUTORalloc();
extern char FAR *TUTORrealloc();
extern struct htab FAR *TUTORget_entry_mem();
extern struct memhdr FAR *pc_nxf();
extern long pc_pl();
extern char FAR *pc_lp();
extern char FAR *pc_np();

/* ******************************************************************* */

char FAR *lastptr;
long lastsize;
char FAR *lastlabel;

long hmalloc = 0; /* number handles allocated */
struct htab FAR *htabp; /* pointer to table of handles */
short mLowest; /* index to start looking for empty slot */

long origmem = 0; /* original memory available */
struct memhdr FAR *basememp = 0; /* pointer to begin of working memory */
long membase[4] = { 0,0,0,0 };

/* ******************************************************************* */

char FAR *GetPtr(mm)
Memh mm;

{   struct htab FAR *pp;

    pp = TUTORget_entry_mem(mm);
    pp->lockcount++;
    return(pp->area);

} /* GetPtr */

/* ------------------------------------------------------------------- */

ReleasePtr(mm)
Memh mm;

{   struct htab FAR *pp;

    pp = TUTORget_entry_mem(mm);
    if (pp->lockcount == 0)
        TUTORdump("Handle unlocked too many times");
    pp->lockcount--;
    pp->lastref = lastmsec; /* save time of last reference */

} /* ReleasePtr */

/* ------------------------------------------------------------------- */

Memh TUTORhandle(name,size,purgewmrm) /* allocate new area of specified size */
char *name; /* descriptive label */
long size; /* size of area in bytes */
int purgewmrm; /* if TRUE, set up as purgeable WMRM */

{   int ii;        /* index in table */
    int handle;    /* actual handle value */
    struct htab FAR *hp;    /* pointer to next table entry */
    long tableSize; /* new table size */
    long oldsize;
    long nhmalloc; /* new num table entries */

    /* find an unused handle with enough memory */
    /* start looking at mLowest */

    for (ii=mLowest, hp=htabp+mLowest; ii<hmalloc;ii++, hp++)
    if (hp->area == (char FAR *) -1L) break;

    if (ii >= hmalloc) {
        /* allocate more handles since table full */
        oldsize = hmalloc * sizeof(struct htab);
        nhmalloc = hmalloc+NMEMADD; /* allocate more handles */
        tableSize = nhmalloc * sizeof(struct htab);
        htabp = (struct htab FAR *)
            TUTORrealloc((char FAR *)htabp,oldsize,tableSize,TRUE);
        if (!htabp)
            nomem("out of handles");

        /* initialize new entries */
        for (ii=0, hp=htabp+hmalloc; ii<NMEMADD; ii++, hp++){
            hp->area = (char FAR *) -1L;
            hp->size = 0;
            hp->lockcount = 0;
            hp->purge = hp->lastref = 0;
            hp->position = -1;
            hp->rarg = 0;
#ifdef MEMLABEL
            hp->label[0] = '\0';
#endif
        } /* for */
        ii = hmalloc; /* index of open entry */
        hp = htabp+ii;
        hmalloc = nhmalloc;
    } /* ii if */

    mLowest = ii+1; /* next time, start looking just past here */

    /* attempt to allocate memory */

    hp->area = pc_get_mem(size,1,"handle"); /* last-fit algorithim */
    if (!hp->area)
        nomem("out of memory");

    /* set up new handle */
    
#ifdef MEMVERIFY
    if (name)
        strncpyf(hp->label,(char FAR *)name,8);
    else
        hp->label[0] = 0;
#endif
    hp->size = size;
    hp->lockcount = 0;
    if (purgewmrm) hp->purge = M_WMRM | M_PURGEABLE;
    else hp->purge = M_NOPURGE;
    hp->position = -1;
    hp->rarg = 0;
    handle = ii | MEMMASK;
    pc_identify_handle(hp->area,handle);
    return(handle); /* Memh is index ored with mask */

} /* TUTORhandle */

/* ------------------------------------------------------------------- */

TUTORfree_handle(mm) /* recycle specified memory area */
Memh mm; /* handle on area */

{   struct htab FAR *hp;
    unsigned int maskTest;
    char FAR *optr; /* pointer to old area */
    struct memhdr FAR *memp;
    long lp;

    maskTest = mm & MEMMASK;
    if (!maskTest)
        TUTORdump("Handle without mem-mask");
    mm ^= MEMMASK;
    if (!mm)
        TUTORdump("NULL handle in TUTORfree_handle");
    if (mm >= hmalloc)
        TUTORdump("mm too large in TUTORfree_handle");

    hp = htabp + mm;
    optr = hp->area;

#ifdef MEMVERIFY
    if ((long)(optr) == -1L)
        TUTORdump("free_handle called on free handle");
#endif

    if (hp->lockcount > 0)
        TUTORdump("Attempt to free locked handle");

    /* If mem is in the swap file */
    if ((hp->purge & (M_WORM | M_WMRM)) && hp->position >= 0)
    TUTORdelete_swap(hp->position);
    
    if (mm <= mLowest)
        mLowest = mm; /* start search here */
    hp->area = (char FAR *) -1L; /* flags not in use */
    hp->size = 0;
#ifdef MEMLABEL
    hp->label[0] = 0;
#endif
    if (optr) {
        lp = pc_pl(optr)-sizeof(struct memhdr);
        memp = (struct memhdr FAR *)pc_lp(lp);
        memp->handle = 0; /* not associated with handle */
        TUTORdealloc(optr); /* release area */
    }

} /* TUTORfree_handle */

/* ------------------------------------------------------------------- */

TUTORdump_handle(mm) /* recycle specified memory area - always */
            /* (even if handle locked, etc.) */
Memh mm; /* handle on area */

{   struct htab FAR *hp;
    unsigned int maskTest;
    char FAR *optr;
    struct memhdr FAR *memp;
    long lp;
    
    maskTest = mm & MEMMASK;
    if (!maskTest)
    TUTORdump("Handle without mem-mask");
    
    mm ^= MEMMASK;
    if (!mm)
    TUTORdump("NULL handle in TUTORdump_handle");
    
    if (mm >= hmalloc)
    TUTORdump("mm too large in TUTORdump_handle");
    
    hp = htabp + mm;
    optr = hp->area;

#ifdef MEMVERIFY
    if ((long)(optr) == -1L)
    TUTORdump("dump_handle called on free handle");
#endif

    hp->lockcount = 0; /* handle is unlocked */

    
    /* If mem is in the swap file */
    if ((hp->purge & (M_WORM | M_WMRM)) && hp->position >= 0)
    TUTORdelete_swap(hp->position);
    
    if (mm <= mLowest)
        mLowest = mm; /* start search here */
    hp->area = (char FAR *) -1L; /* flags not in use */
    if (optr) {
        lp = pc_pl(optr)-sizeof(struct memhdr);
        memp = (struct memhdr FAR *)pc_lp(lp);
        memp->handle = 0; /* old area not handle */
        TUTORdealloc(optr);
    }

} /* TUTORdump_handle */

/* ------------------------------------------------------------------- */

int TUTORset_hsize(mm,newsize,abort) /* reset size of memory area */
Memh mm;
long newsize;    /* size to reset to */
int abort;  /* TRUE if should abort if no memory */
    
{   struct htab FAR *h; /* pointer to area */
    long oldsize;   /* previous size of area */
    char FAR *nptr; /* pointer to new area */
    char FAR *optr; /* pointer to old area */
    unsigned char oldpurge;
    struct memhdr FAR *memp; /* pointer to area header */
    long lp;

    h = TUTORget_entry_mem(mm);
    if ((h->lockcount > 0) && (newsize > h->size))
        TUTORdump("Attempt to increase size of locked handle");

    oldsize = h->size;
    if (newsize <= oldsize) {
    pc_reduce_alloc(h->area,newsize);
    } else {
        oldpurge = h->purge;
        h->purge = 0; /* so this handle doesn't get purged while we are allocating memory */
        nptr = pc_get_mem(newsize,1,"handle"); /* last fit algorithim */
        h->purge = oldpurge;    /* restore purge */
        if ((long)(nptr) == 0) {
            if (abort)
                nomem("no memory for size increase");
            return(FALSE);
        } /* nptr if */
        TUTORblock_move(h->area,nptr,oldsize);
        optr = h->area;  /* save addr of old area */
        lp = pc_pl(optr)-sizeof(struct memhdr);
        memp = (struct memhdr FAR *)pc_lp(lp);
        memp->handle = 0; /* old area not handle */
        h->area = nptr;  /* set to new area */
        pc_identify_handle(h->area,mm);
        TUTORdealloc(optr); /* release old space */
    } /* size else */
    h->size = newsize;

    /* If mem is in the swap file */
    if ((h->purge & M_WORM) && h->position >= 0) {
        TUTORdelete_swap(h->position);
        h->position = -1L;
    }

    return(TRUE);

} /* TUTORset_hsize */

/* ------------------------------------------------------------------- */

/* get pointer to handle table entry, retrieve item from disk  */

struct htab FAR *TUTORget_entry_mem(handle) /* get pointer to mmth entry */
int handle;

{   register struct htab FAR *hp;
    int mm; /* index into handle table */
    unsigned int maskTest;
    int ptype;    /* purge/restore type */

    maskTest = handle & MEMMASK;
    if (!maskTest)
    TUTORdump("Handle without mem-mask");

    mm = handle ^ MEMMASK; /* remove MEMMASK bit */
    if (!mm)
    TUTORdump("NULL handle in TUTORget_entry_mem");

    if (mm >= hmalloc)
    TUTORdump("mm too large in TUTORget_entry_mem");

    hp = htabp+mm;
    if (!hp->area) {

    if ((hp->purge & M_NOTINMEM) == 0)
        TUTORdump("Inactive handle in TUTORget_entry_mem");

    /* attempt to allocate memory */

    hp->area = pc_get_mem(hp->size,1,"handle"); /* last-fit algorithim */
    if (!hp->area)
        nomem("TUTORget_entry_mem - out of memory");

    pc_identify_handle(hp->area,handle);
    TUTORrecover_handle(hp,hp->area,handle);
    } /* area if */

    return(hp);

} /* TUTORget_entry_mem */

/* ------------------------------------------------------------------- */

DeleteFromHandle(mm,di,dl) /* remove bytes from specified area */
Memh mm;
long di; /* index of first byte to delete */
long dl; /* number of bytes to delete */

{   long hl;        /* size of area */
    long rmo;        /* offset to bytes after deleted area */
    long rmn;        /* number of remaining bytes after delete */
    register char FAR *rmp;    /* pointer to remaining bytes */
    register char FAR *sp;    /* pointer to area */
    register long i;
    struct htab FAR *h; /* handle on area */

    h = TUTORget_entry_mem(mm);
    hl = h->size;
    if ((dl <= 0) || (di < 0) || (di >= hl)) return(0);
    if ((di+dl) > hl) dl = hl-di; /* insure range legal */
    rmo = di+dl;
    rmn = hl-rmo;   /* number bytes after deleted area */
    rmp = h->area+rmo;        /* pointer to remaining bytes */
    sp = h->area+di;        /* pointer to bytes to delete */
    TUTORblock_move(rmp,sp,rmn);
    TUTORset_hsize(mm,(hl-dl),TRUE); /* shrink size of area */

} /* DeleteFromHandle */

/* ------------------------------------------------------------------- */

InsertIntoHandle(mm,is,ip,il) /* add bytes to specified area */
Memh mm;
char FAR *is;    /* pointer to bytes to insert */
long ip;    /* position at which to insert */
long il;    /* number of bytes to insert */

{   long hl;        /* size of area */
    struct htab FAR *h; /* handle on area */

    h = TUTORget_entry_mem(mm);
    if (h->lockcount > 0)
    TUTORdump("Attempt to add bytes to locked handle");
    hl = h->size;
    if ((ip < 0) || (il <= 0)) return(0);
    TUTORset_hsize(mm,(hl+il),TRUE);     /* expand area */
    TUTORblock_move(h->area+ip,h->area+ip+il,hl-ip); /* move down */
    TUTORblock_move(is,h->area+ip,il); /* insert new text */

} /* InsertIntoHandle */

/* ******************************************************************* */

char FAR *TUTORalloc(size,abort,label)    /* allocate block of memory */
long size; /* size requested */
int abort; /* TRUE if should abort if request fails */
char *label; /* descriptive label */

{   char FAR *pc;   /* pointer to actual area */
    char msg[80];

    /* attempt to allocate memory */

    pc = pc_get_mem(size,0,label); /* first-fit algorithim */
    if ((pc == FARNULL) && abort) {
        sprintf(msg,"Alloc failed: %ld\n",size);
        nomem(msg);
    }
    return pc;

} /* TUTORalloc */

/* ******************************************************************* */

char FAR *TUTORrealloc(ptr,oldsize,newsize,abort)
char FAR *ptr;    /* pointer to previous memory block */
long oldsize;
long newsize;
int abort;

{   char FAR *nptr;
    struct memhdr FAR *memp;
    long lp;
    char label[10];

    lp = pc_pl(ptr)-sizeof(struct memhdr);
    memp = (struct memhdr FAR *)pc_lp(lp);
#ifdef MEMLABEL
    strncpyf((char FAR *)label,memp->label,8);
#endif
    lastptr = (char FAR *)memp; /* save information for mem map */
    lastsize = newsize;
    lastlabel = memp->label;

    if (newsize <= oldsize) {
    pc_reduce_alloc(ptr,newsize);
    return(ptr); /* shorten original block */
    }
    nptr = pc_get_mem(newsize,0,label); /* first fit algorithim */
    if ((long)nptr == 0) {
    if (abort)
        nomem("realloc failed - not enough memory");
    return(FARNULL);
    }
    TUTORblock_move(ptr,nptr,oldsize);
    TUTORdealloc(ptr);
    return(nptr);

} /* TUTORrealloc */

/* ******************************************************************* */

memchain(calli)  /* check memory and handle tables */
int calli; /* identifying index of call */

{   struct memhdr FAR *memp;    /* pointer to area header */
    long tmem;    /* total memory found */
    struct htab FAR *hp;
    long lp;    /* long for pointer arithmetic */
    long lw1,lw2;
    int ii;

#ifdef Nosuchz
    tmem = 0;    /* total memory found */
    memp = basememp; /* begin at start of memory */
    while (memp->length) {
    tmem += memp->length;
    lp = pc_pl((char FAR *)memp)+memp->length;
    if (lp != (pc_pl((char FAR *)basememp)+tmem)) {
        TUTORtrace_n("memchain lost memory",(long)calli);
        TUTORdump(" ");
    } /* lp if */
    if (memp->handle) {
        lw1 = pc_pl((char FAR *)memp)+sizeof(struct memhdr);
        hp = htabp+(memp->handle ^ MEMMASK);
        lw2 = pc_pl(hp->area);
        if (lw1 != lw2) {
        TUTORtrace_n("memchain handle ptr bad",(long)calli);
        TUTORdump(" ");
        }
    } /* handle if */
    memp = (struct memhdr FAR *)pc_lp(lp);
    } /* while */
    tmem += sizeof (struct memhdr);
    if (tmem != origmem) {
    TUTORtrace_n("memchain memory total incorrect",(long)calli);
    TUTORdump(" ");
    } /* tmem if */

    if (htabp) for (ii=1; ii<hmalloc; ii++) {
    hp = htabp+ii;
    if (hp->area && hp->area != (char FAR *)-1L) {
        if (hp->label[0] == '\0') {
        TUTORtrace_n("memchain handle without label",(long)calli);
        TUTORdump(" ");
        }
        lw1 = pc_pl(hp->area)-sizeof(struct memhdr);
        memp = (struct memhdr FAR *)pc_lp(lw1);
        if (!memp->used) {
        TUTORtrace_n("memchain handle on unused block",(long)calli);
        TUTORdump(" ");
        } /* used if */
        if ((memp->handle ^ MEMMASK) != ii) {
        TUTORtrace_n_n("memchain handle index bad",(long)calli,(long)ii);
        TUTORdump(" ");
        } /* handle if */
        if (hp->size > (memp->length-sizeof(struct memhdr))) {
        TUTORtrace_n("memchain handle size wrong",(long)calli);
        TUTORdump(" ");
        }
    } /* label if */
    } /* for */
#endif

} /* memchain */

/* ******************************************************************* */

TUTORdealloc(ptr)    /* deallocate a block of memory */
char FAR *ptr;

{   struct memhdr FAR *memp;    /* pointer to area header */
    struct memhdr FAR *prev;    /* pointer to previous header */
    struct memhdr FAR *next;    /* pointer to next header */
    long tp,lp; /* longs for pointer arithmetic */

    /* search forwards to find this block */
    /* get pointer to previous block */

    memp = basememp; /* begin at start of memory */
    prev = FARNULL;
    tp = pc_pl(ptr); /* convert pointer to long */
    while (memp->length) {
        lp = pc_pl((char FAR *)memp);
        if (tp == (lp+sizeof(struct memhdr)))
            break;  /* found this pointer */
        prev = memp;
        lp += memp->length;
        memp = (struct memhdr FAR *)pc_lp(lp);
    } /* while */
    if (memp->length == 0) {
        TUTORtrace_x("dealloc bad pointer ",pc_pl(ptr));
        TUTORdump("TUTORdealloc bad pointer");
    }

    /* get pointer to next block */

    lp = pc_pl((char FAR *)memp)+memp->length;
    next = (struct memhdr FAR *)pc_lp(lp);

    /* check if can collapse this block into previous */

    if (prev && (!prev->used)) {
        prev->length += memp->length; /* add this block to previous */
        memp = prev;
    } /* prev if */

    /* check if can collapse next block into this */

    if (!next->used)
    memp->length += next->length;

    /* mark this block unused */

    memp->used = 0;
    memp->handle = 0;
#ifdef MEMLABEL
    memp->label[0] = '\0';
#endif

} /* TUTORdealloc */

/* ******************************************************************* */

long TUTORinq_mem_available()    /* return size of largest free memory block */

{   struct memhdr FAR *memp;    /* pointer to area header */
    long maxmem;  /* maximum found */
    long lp;    /* long for pointer arithmetic */

    maxmem = 0; /* nothing so far */
    memp = basememp; /* begin at start of memory */
    while (memp->length) {
        if ((!memp->used) && (memp->length > maxmem))
            maxmem = memp->length; /* set new maximum */
        lp = pc_pl((char FAR *)memp)+memp->length;
        memp = (struct memhdr FAR *)pc_lp(lp);
    } /* while */
    return(maxmem - sizeof(struct memhdr));

} /* TUTORinq_mem_avail */

/* ******************************************************************* */

static nomem(msg)   /* process out-of-memory situation */
char *msg;

{
    TUTORdump(msg);

} /* nomem */

/* ******************************************************************* */

pc_recycle_handle_mem(mh) 
/* prepare for immediate re-use of handle memory */
Memh mh;

{   struct htab FAR *pp;

    pp = TUTORget_entry_mem(mh);
    pp->lastref = 0; /* make this oldest handle */
    if (TUTORinq_fast_swap())
        pc_mem_purge(pp->size);
    
} /* pc_recycle_handle */

/* ******************************************************************* */

pc_drop_mem()    /* drop all memory assigned to ct on exit */

{   union REGS iregs;    /* intdos input  registers */
    union REGS oregs;    /* intdos output registers */
    struct SREGS sregs; /* intdosx segment registers */
    int ii;
    char FAR *temp;

#ifdef MSC
    for (ii = 0; ii < 4 && membase[ii]; ii++) {
        temp = pc_lp(membase[ii]);
        iregs.h.ah = 0x49;    /* deallocate memory */
        segread(&sregs);
        sregs.es = FP_SEG(temp);
        intdosx(&iregs,&oregs,&sregs);
        if (oregs.x.cflag) {
            printf("memory deallocate failed");
        }
    }
#endif

} /* pc_drop_mem */

/* ******************************************************************* */

char FAR *pc_get_mem(size,strategy,label) /* allocate+manage memory */
long size; /* size in bytes */
int strategy; /* allocation strategy (0=first-fit,1=last-fit) */
char label[8]; /* descriptive label */

{   char FAR *ptr;  /* pointer to space found */
    int i;

    /* attempt to insure space in swap table */

    TUTORexpand_swap();

    /* attempt to allocate memory */

    ptr = pc_alloc(size,strategy,label);
    if (ptr) return(ptr);

    /* try compacting memory if allocate failed */

    if (pc_mem_compress()) {
        ptr = pc_alloc(size,strategy,label);
        if (ptr)  {
            return(ptr);
        } /* ptr if */
    } /* compress if */

    /* try purging re-allocatable, re-loadable handles */

    while (pc_mem_purge(size)) {
        pc_mem_compress();
        ptr = pc_alloc(size,strategy,label);
        if (ptr) return(ptr);
    } /* purge while */

    return(FARNULL);

} /* pc_get_mem */

/* ******************************************************************* */

static char FAR *pc_alloc(size,strategy,label) /* allocate block of memory */
long size;    /* size in bytes */
int strategy;    /* allocation strategy */
        /* 0 = first-fit */
        /* 1 = last-fit */
char *label;    /* descriptive label */

{   struct memhdr FAR *memp;  /* pointer to current area header */
    struct memhdr FAR *foundp;    /* pointer to found area header */
    struct memhdr FAR *newp;    /* pointer to new area header */
    long tsize; /* amount of memory required */
    long freesp;    /* size of free space */
    long lp,np;    /* longs for pointer arithmetic */
    char FAR *pc;   /* pointer to actual area */

    lastptr = NULL; /* save information for mem map */
    lastsize = size;
    lastlabel = label;

    memp = basememp;    /* start at begin of memory */
    foundp = FARNULL;  /* nothing found yet */
    tsize = size+sizeof(struct memhdr);
    if (tsize & 3) {
        tsize += 4-(tsize & 3); /* round to 4-byte boundary */
    }
    do {
        memp = pc_nxf(memp,tsize); /* look for next free space */
        if (memp->length) {
            foundp = memp;  /* save pointer to find */
            if (strategy == 0)
                break;    /* done if first-fit algorithim */
            lp = pc_pl((char FAR *)memp)+memp->length;
            memp = (struct memhdr FAR *)pc_lp(lp);
        } /* length if */
    } while (memp->length);

    if (!foundp)
        return(FARNULL); /* not enough memory */

    /* build header for new block if found area too large */

    lp = pc_pl((char FAR *)foundp);
    if ((foundp->length-tsize) > 32) {
        freesp = foundp->length-tsize; /* size of free space */
        if (strategy == 0) { /* first-fit */
            np = lp+tsize;
            newp = (struct memhdr FAR *)(pc_lp(np));
        } else {
            newp = foundp;  /* pointer to free space */
            np = lp+freesp;
            foundp = (struct memhdr FAR *)(pc_lp(np));
        } /* strategy else */
        newp->length = freesp;
        foundp->length = tsize;
        newp->used = FALSE;
        newp->handle = 0;
#ifdef MEMLABEL
        newp->label[0] = '\0';
#endif
    } /* length-tsize if */

    /* initialize found memory block */

    foundp->handle = 0;
    foundp->used = TRUE;
#ifdef MEMLABEL
    strncpyf(foundp->label,(char FAR *)label,8);
#endif
    pc = pc_np((char FAR *)foundp);
    pc += sizeof(struct memhdr);
    if (size)
        *(pc) = 0;
    return(pc);

} /* pc_alloc */

/* ******************************************************************* */

pc_reduce_alloc(ptr,newsize)
char FAR *ptr; /* pointer to memory block */
long newsize; /* new size for block */

{   struct memhdr FAR *memp;    /* pointer to area header */
    struct memhdr FAR *nextp;    /* pointer to next area header */
    long oldsize; /* current size of area */
    long mlth; /* length of memory area */
    long ln; /* long for pointer arithmetic */

    if (newsize & 3) {
    newsize += 4-(newsize & 3); /* round to 4-byte boundary */
    }
    ln = pc_pl(ptr)-sizeof(struct memhdr);
    memp = (struct memhdr FAR *)pc_lp(ln);
    oldsize = memp->length-sizeof(struct memhdr);

    if (!memp->used)
    TUTORdump("pc_reduce_alloc block not in use");
    if (oldsize < newsize)
    TUTORdump("pc_reduce_alloc old < new");

    /* append next block if next block free */

    ln += memp->length;  /* address of next block hdr */
    nextp = (struct memhdr FAR *)pc_lp(ln);
    if (!nextp->used)
    memp->length += nextp->length;    /* absorb next block */

    /* create new block after this to absorb free space */

    if ((memp->length-newsize) > (sizeof(struct memhdr)+16)) {
    mlth = memp->length;    /* total memory involved */
    memp->length = newsize+sizeof(struct memhdr); /* reset length */
    ln = pc_pl((char FAR *)memp)+memp->length;
    nextp = (struct memhdr FAR *)pc_lp(ln);
    nextp->length = mlth-memp->length; /* length of new block */
    nextp->used = FALSE;
#ifdef MEMLABEL
    nextp->label[0] = '\0';
#endif
    nextp->handle = 0;
    } /* free if */

} /* pc_reduce_alloc */

/* ******************************************************************* */

int pc_mem_purge(target) /* purge unneeded items from memory */
/* returns TRUE if any item purged */
long target; /* amount of memory desired */

{   struct memhdr FAR *memp; /* pointer to area header */
    struct memhdr FAR *prev; /* pointer to previous area header */
    struct memhdr FAR *next; /* pointer to next area header */
    struct htab FAR *hp; /* pointer to handle table entry */
    long oldtim[NOLDFIND]; /* times of oldest purgeable items */
    Memh oldh[NOLDFIND]; /* oldest purgeable handles */
    int nfind; /* number purgeable handles found */
    long tsize; /* size required */
    int purge; /* handle purge info */
    long lp, np; /* longs for pointer arithmetic */
    int retv; /* TRUE if anything purged */
    int ii,jj; /* indexes in oldh/oldtim */
    int freecount;
    long wsize; /* size to write to swap */

    TUTORinq_msec_clock(); /* update lastmsec for ReleasePtr */
    retv = FALSE;
    tsize = target+sizeof(struct memhdr);   /* allow for memory header */

    /* locate the oldest purgeable items */

    freecount = TUTORinq_swap();
    if (freecount > NOLDFIND) freecount = NOLDFIND;
    memp = basememp; /* start at beginning of memory */
    prev = FARNULL;
    nfind = 0; /* nothing found yet */
    for (ii=0; ii<NOLDFIND; ii++) { /* nothing found yet */
    oldtim[ii] = lastmsec+1;
    oldh[ii] = HNULL;
    } /* for */
    while (memp->length) {
    if (memp->handle) {

        /* check if handle can be purged */

        hp = pc_htab(memp->handle);
        if (hp->area && (!hp->lockcount) && (hp->purge & M_PURGEABLE)) {
        purge = hp->purge & M_TYPEMASK;
        if (purge != M_NOPURGE) {

        /* check if should add to list of oldest items */

        if (!nfind) {
          nfind++; /* number found and kept */
          oldtim[0] = hp->lastref; /* remember this item */
          oldh[0] = memp->handle;
        } else {

          /* determine position in list for this item */

          if (hp->lastref <= oldtim[nfind-1]) {
            for(ii=0; ii<nfind; ii++) {
            if (hp->lastref <= oldtim[ii]) {

            /* shove rest of list down */

            for(jj=nfind-1; jj>ii; jj--) {
                oldtim[jj] = oldtim[jj-1];
                oldh[jj] = oldh[jj-1];
            } /* for */

            /* add to list of oldest handles */

            if (nfind < NOLDFIND)
                nfind++; /* number found and kept */
            oldtim[ii] = hp->lastref; /* remember this item */
            oldh[ii] = memp->handle;
            break; /* exit for */
            } /* lastref if */
            } /* for */
          } /* lastref if */
        } /* nfind else */
        } /* purgeable if */
        } /* lockcount if */
    } /* handle if */
    prev = memp;
    lp = pc_pl((char FAR *)memp)+memp->length;
    memp = (struct memhdr FAR *)pc_lp(lp); /* advance to next area */
    } /* while */

    memp = basememp;
    prev = FARNULL;
    while (memp->length) {
    if (memp->handle) {

        /* check if handle can be purged */

        hp = pc_htab(memp->handle);
        if (hp->area && (!hp->lockcount) && (hp->purge & M_PURGEABLE)) {
        purge = hp->purge & M_TYPEMASK;
        jj = -1;
        if (purge != M_NOPURGE) {

            /* check if handle in list of those to purge */

            for(ii=0; ii<freecount; ii++) {
            if (oldh[ii] == memp->handle) {
                jj = ii;
                break;
            } /* oldh if */
            } /* for */
        } /* purge if */

        if (jj >= 0) { /* delete if in list */

            /* free memory assigned to this handle */


            switch (purge) {
            case M_WORM:
                if (hp->position != -1) break;
        case M_WMRM:
        wsize = hp->size;
        if (wsize & 1) /* insure length even */
            wsize++; /* safe as block is 4-byte multiple */
#ifdef MEMVERIFY
        /* remember checksum of written memory */
        /* hp->swapSum = TUTORchecksum(hp->area,wsize); */
#endif
        hp->position = TUTORwrite_swap(hp->area, wsize);
                if (hp->position == -1) TUTORdump("Couldn't write to swap file");
                break;
            default:
                break;
            }

            hp->area = FARNULL;    /* mark no memory assigned */
            hp->purge |= M_NOTINMEM;    /* mark purged */
            memp->used = FALSE;
            memp->handle = 0;
#ifdef MEMLABEL
            memp->label[0] = '\0';
#endif
            retv = TRUE;

            /* check if this block can combine with next */

            np = pc_pl((char FAR *)memp)+memp->length;
            next = (struct memhdr FAR *)pc_lp(np);
            if (next->used == FALSE)
            memp->length += next->length;

            /* check if this block can combine with previous */

            if (prev && (prev->used == FALSE)) {
                prev->length += memp->length;
                memp = prev;
            }

            /* check if found enough space */

            if (memp->length >= tsize) {
            return(TRUE);
            }
        } /* in-purge-list if */
        } /* lockcount if */
    } /* handle if */
    prev = memp;
    lp = pc_pl((char FAR *)memp)+memp->length;
    memp = (struct memhdr FAR *)pc_lp(lp); /* advance to next area */
    } /* while */
    return(retv);

} /* pc_mem_purge */

/* ******************************************************************* */

static long pc_last_compress = 0; /* time of last memory compress */

int pc_mem_compress() /* compress memory - combine free spaces */
/* returns TRUE if any free space combined */

{   struct memhdr FAR *memp; /* pointer to area header */
    struct memhdr FAR *nextp; /* pointer to next area header */
    struct memhdr FAR *fprev; /* pointer to previous (free) header */
    struct memhdr FAR *fnext; /* pointer to next (free) header */
    struct htab FAR *hp; /* pointer to handle table entry */
    char FAR *fp; /* from address for move */
    char FAR *tp; /* to address for move */
    long movel; /* length of memory area to move */
    long nfree; /* size of 2nd free area */
    long mp,lp,np; /* longs for pointer arithmetic */
    int retv; /* return value, TRUE if combined some space */

    /* search for free area, followed by unlocked handles, followed */
    /* by another free area */

    pc_last_compress = TUTORinq_msec_clock();
    memp = basememp; /* begin at start of memory */
    fprev = FARNULL;
    retv = FALSE; /* haven't combined anything yet */
    while (memp->length) {
    lp = pc_pl((char FAR *)memp)+memp->length;
    nextp = (struct memhdr FAR *)pc_lp(lp); /* pointer to next area */

    if (!memp->used) {
        fprev = memp; /* save pointer to free area */

        /* search fwd thru unlocked handles for 2nd free area */

        fnext = FARNULL; /* no following area yet */
        do {
        lp = pc_pl((char FAR *)memp)+memp->length;
        memp = (struct memhdr FAR *)pc_lp(lp);
        if (memp->length) {
            if (!memp->used) {
            fnext = memp; /* found following free space */
            } else if (memp->handle) {
            hp = pc_htab(memp->handle);
            if (hp->lockcount)
                fprev = FARNULL; /* cant continue past locked area */
            } else fprev = FARNULL; /* not handle, not moveable */
        } else fprev = FARNULL; /* hit end of memory */
        } while (fprev && (fnext == FARNULL));

        /* found two free spaces, relocate everything in between */

        if (fnext) {

        /* loop thru handles addusting addresses */

        nfree = fnext->length; /* size of 2nd free space */
        mp = pc_pl((char FAR *)fprev); /* addr of 1st free */
        np = pc_pl((char FAR *)fnext); /* addr of 2nd free */
        mp += fprev->length; /* advance past first free area */
        fp = (char FAR *)pc_lp(mp); /* from address for move */
        movel = 0; /* nothing to move yet */
        while (mp < np) {
            memp = (struct memhdr FAR *)pc_lp(mp); /* ptr to area */
            hp = pc_htab(memp->handle);
            lp = pc_pl(hp->area)+nfree;
            hp->area = (char FAR *)pc_lp(lp);
            mp += memp->length; /* advance to next block */
            movel += memp->length; /* accumulated amount to move */
        } /* mp < np while */

        /* move all intervening handles to higher address */

        if (movel) {
            lp = pc_pl(fp)+nfree;
            tp = (char FAR *)pc_lp(lp); /* to address for move */
            TUTORblock_move(fp,tp,movel);
        } /* movel if */
        retv = TRUE; /* did something usefull */
        fprev->length += nfree; /* combine free spaces */
        nextp = fprev; /* start with this free space */
        } /* fnext if */
    } /* used if */

    /* advance to next memory area */

    memp = nextp;
    } /* while */
    return(retv);

} /* pc_mem_compress */

/* ******************************************************************* */

static long pc_last_optz = 0; /* time of last memory optimize */

pc_mem_tasks() /* background memory-management tasks */

{   long curmsec; /* current millisecond clock */
    long size; /* size of handle table memory area */
    long lp1,lp2; /* pointer values for compare */
    char FAR *newp; /* pointer to new area if any */

    if (nevents) return; /* exit if have something else to do */
    if (htabp == FARNULL) return; /* exit if no handle table */

    curmsec = TUTORinq_msec_clock();
    if ((curmsec-pc_last_optz) > 5000L) {
        pc_last_optz = curmsec; /* time of last attempt */

        /* try to move handle table down in memory */

        size = hmalloc*sizeof(struct htab);
        newp = pc_alloc(size,0,"htab");
        if (newp) {
            lp1 = pc_pl(newp);
            lp2 = pc_pl((char FAR *)htabp);
        if (lp1 < lp2) { /* found new area in lower mem */
                TUTORblock_move((char FAR *)htabp,newp,size);
                TUTORdealloc((char FAR *)htabp);
                htabp = (struct htab FAR *)newp;
                pc_mem_compress(); /* run memory compress */
            } else TUTORdealloc(newp);
        } /* newp if */
    } /* elapsed time if */

    if ((curmsec-pc_last_compress) > 6000L)
       pc_mem_compress(); /* run a memory-compress pass */

} /* pc_mem_tasks */

/* ******************************************************************* */

struct htab FAR *pc_htab(handle) /* get ptr to htab entry */
int handle;

{   register struct htab FAR *hp;
    int mm; /* index into handle table */
    unsigned int maskTest;

    maskTest = handle & MEMMASK;
    if (!maskTest)
        TUTORdump("pc_htab handle without mem-mask");

    mm = handle ^ MEMMASK; /* remove MEMMASK bit */
    if (!mm)
        TUTORdump("pc_htab NULL handle");

    if (mm >= hmalloc)
        TUTORdump("pc_htab handle too large");
    hp = htabp+mm;
    return(hp);

} /* pc_htab */

/* ******************************************************************* */

pc_identify_handle(ptr,handle)      /* flag area of memory as handle */
char FAR *ptr;    /* pointer to area */
int handle;    /* handle on area */

{   struct memhdr FAR *memp;    /* pointer to area header */
    long lw;

    lw = pc_pl(ptr)-sizeof(struct memhdr);
    memp = (struct memhdr FAR *)pc_lp(lw);
    memp->handle = handle;

} /* pc_identify_handle */

/* ******************************************************************* */

int LockMemoryTable(void) { return(0); } /* dummy on pc */
int UnlockMemoryTable(void) { return(0); } /* dummy on pc */

/* ******************************************************************* */
