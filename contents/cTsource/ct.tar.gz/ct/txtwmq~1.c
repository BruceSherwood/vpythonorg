
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* #define SELECTION_PASTE */

#include <stdio.h>

#include "baseenv.h"
#include "txt.h"
#include "tglobals.h"
#include "chardef.h"

#ifdef WINPC
#include <windows.h>
#endif

#ifndef IBMPC

#ifdef SYSV
#define sys_typesh
#include "wmx11.h"
#else
#include <sys/wait.h>
#include <sys/time.h>
#ifdef WM
#include "wmclient.h"
#endif
#endif

#include <X11/Xatom.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <X11/cursorfont.h>
#include <X11/keysym.h>

#endif /* IBMPC */

#ifdef WINPC
extern HWND CurrentWinH; /* handle on current window */
extern HDC CurrentDC; /* current window's device context */
#endif

#ifdef ctproto
static long TUTORfrom_internal_clip_doc(Memh doc,long pos,long len,long mpos,long mlen,
long *extraPos,int saveDo);
static int TUTORto_internal_clip_doc(Memh doc,long pos,long len,long *extraPos);
extern long TUTORload_region(FileRef FAR *fr);
extern int strlenf(char FAR *cc);
int  TUTORfread_graphic_doc(unsigned int  doc,int  type,int  find);
extern unsigned int  MakeGraphicChar(struct  pcfont FAR *fontp,int  charN);
unsigned int  ReadPCX(int  find);
int  TUTORto_clip_doc(unsigned int  doc,long  pos,long  len,int  doCut,long  *extraPos);
long  TUTORfrom_clip_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,long  *extraPos,int  saveDo);
int  AllowHandlePurge(unsigned int  mm);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
extern TUTORblock_move(char FAR *sp, char FAR *dp, long lth);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORadd_inset_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,int  kind,unsigned int  dat,long  *extraPos);
unsigned int  wmg_load_font(struct  _fref FAR *fontPath,int  index);
int  TUTORinq_fref(int  findx,struct  _fref FAR *fref);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
long  TUTORget_len_doc(unsigned int  doc);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int  TUTORget_char(int  findx,int  tryHard);
extern int TUTORzero(char FAR *ptr,long lth);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
int  TUTORsave_do_doc(unsigned int  doc,long  pos,long  len,int  op,long  newLen);
int  TUTORchange_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,unsigned char  FAR *cp,long  cLen,long  fromOff,unsigned int  styles,unsigned int  specialT,long  *extraPos,int  eupFlag);
#endif /* ctproto */

extern char FAR *GetPtr();
long TUTORget_len_doc();
Memh TUTORnew_doc();
extern char FAR *TUTORalloc();
long n_editorpaste();
extern unsigned int  wmg_load_font();
Memh MakeGraphicChar();
Memh ReadPCX();
long TUTORread();

static Memh clipboardDoc=0;
#ifdef IBMPC
#define PC_PASTE
#else
static char selectionOwner = FALSE;
extern Display *display;
#define PC_PASTE
#endif

TUTORfread_graphic_doc(doc,type,find)
Memh doc;   /* empty doc to be filled with a graphic */
int type;   /* 0: text, 1: native graphic, 2: cT font, 3: fdb, 4: color */
int find;   /* cT file index */
/* returns success flag */
    {
    FileRef fRef;
    struct pcfont FAR *fontp;
    long nChars;    /* # of chars we've added so far */
    long extraPos;  /* dummy arg */
    Memh font;  /* the font that comes from the file */
    int ii;
    Memh newChar;   /* new character taken from the font */
    int needFont;   /* TRUE if we want to keep the font handle */
    long dummy;

	font = HNULL; 
#ifdef IBMPC
    if (type != 2 && type != 1 && type != 4)
        return(FALSE);
#else
    if (type == 0 || type == 1)
        return(FALSE); /* not supported yet */
#endif
    
    /* get the name of the file so that we can call wmg_load_font */
    TUTORinq_fref(find,(FileRef FAR *) &fRef);

#ifdef WINPC
    newChar = TUTORload_region((FileRef FAR *)&fRef);
    if ((int)(newChar) > 0) {
    	TUTORadd_inset_doc(doc,0L,0L,0L,0L,PIXMAPSPECIAL,newChar,&dummy);
    	return(TRUE);
	}
#endif

    /* load font */
#ifdef IBMPC
    if (type == 1)
        font = ReadPCX(find);
    else
        font = wmg_load_font((FileRef FAR *) &fRef,-1);
#endif

#ifdef X11
	if (type != 4) {
        font = wmg_load_font((FileRef FAR *) &fRef,-1);
	} else {
    	newChar = TUTORload_region((FileRef FAR *)&fRef);
    	if ((int)(newChar) > 0) {
    		TUTORadd_inset_doc(doc,0L,0L,0L,0L,PIXMAPSPECIAL,newChar,&dummy);
    		return(TRUE);
		}	
		return(FALSE);
	}
#endif  

    if (!font)
        return(FALSE); /* couldn't load it */
    
    fontp = (struct pcfont FAR *) GetPtr(font);
    
    /* add the characters to the document */
    needFont = FALSE;
    nChars = 0;
    for (ii=0; ii<fontp->nchars8; ii++)
        {
        if (fontp->nchars8 > 1 || (fontp->format & 1) == 0)
            { /* break up or convert font */
            newChar = MakeGraphicChar(fontp,ii);
            }
        else
            { /* we can use the read-in font as the character */
            newChar = font;
            needFont = TRUE;
            }
        
	if ((int)(newChar) > 0)
            { /* we have another character to add */
            TUTORadd_inset_doc(doc,nChars,0L,0L,nChars,BITMAPSPECIAL,newChar,&extraPos);
            nChars++;
            }
        }
    
    ReleasePtr(font);
    KillPtr(fontp);
    
    if (!needFont)
        { /* we've extracted each char from the font, so we don't need
            the font handle itself */
        TUTORfree_handle(font);
        }
    
    return(TRUE);
    }

static Memh MakeGraphicChar(fontp,charN) /* create a "character" for document from font */
struct pcfont FAR *fontp;   /* pointer to font we are looking at */
int charN;  /* which character to convert */
    {
    long tempL;
    struct pccharl FAR *lcharp;
    struct pcchars FAR *scharp;
    int sizeFlag;   /* 0: small format, 1: large format */
    Memh charH; /* the character we are constructing */
    char FAR *cp;   /* pointer to contents of charH */
    struct pcfont FAR *newfontp;    /* pointer to pcfont of new char */
    struct pccharl FAR *newcharp;   /* pointer to new character info */
    long mapSize;   /* size of bitmap for character */
    char FAR *mapP; /* pointer to character map */
    
    /* allocate a handle to contain character */
    tempL = sizeof(struct pcfont) + sizeof(struct pccharl);
    if ((fontp->format & 1) == 0)
        { /* small format font */
        sizeFlag = 0;
        scharp = (struct pcchars FAR *) ((char FAR *) fontp + fontp->ddef);
        scharp += charN;
        mapSize = scharp->maph * ((scharp->mapw+15)/16)*2;
        }
    else
        { /* large character format */
        sizeFlag = 1;
        lcharp = (struct pccharl FAR *) ((char FAR *) fontp + fontp->ddef);
        lcharp += charN;
        mapSize = (long) lcharp->maph * ((lcharp->mapw+15)/16)*2;
        }
    if (mapSize == 0)
        return(HNULL); /* nonexistent character */
    
    tempL += mapSize;
    
    charH = TUTORhandle("grphchar",tempL,FALSE);
    if (!charH)
        return(HNULL);
    TUTORpurge_info(charH,M_WORM,FARNULL,0); /* make handle purgable */
    
    cp = GetPtr(charH);
    
    /* copy the font info */
    TUTORblock_move((char FAR *) fontp,cp,(long) sizeof(struct pcfont));
    /* modify the font info for this one character font */
    newfontp = (struct pcfont FAR *) cp;
    newfontp->format = (fontp->format & 2) | 1; /* always large char */
    newfontp->first8 = 0;
    newfontp->nchars8 = 1;
    newfontp->ddef = sizeof(struct pcfont);
    newfontp->dmap = sizeof(struct pcfont) + sizeof(struct pccharl);
    
    /* copy the character info */
    /* the only changes that we make are that y pen displacements are forced to 0
        and x pen displacements are forced to >= 0.  This is so that the text formatting
        doesn't go crazy */
    
    newcharp = (struct pccharl FAR *) (cp + sizeof(struct pcfont));
    if (sizeFlag == 0)
        { /* copy small format to large */
        newcharp->map = 0; /* because there is only 1 char */
        newcharp->pdx = scharp->pdx;
        newcharp->pdy = 0;
        newcharp->bndx = scharp->bndx;
        newcharp->bndy = scharp->bndy;
        newcharp->bnw = scharp->bnw;
        newcharp->bnh = scharp->bnh;
        newcharp->mapdx = scharp->mapdx;
        newcharp->mapdy = scharp->mapdy;
        newcharp->mapw = scharp->mapw;
        newcharp->maph = scharp->maph;
        }
    else
        { /* we can just block move the large format info */
        TUTORblock_move((char FAR *) lcharp,(char FAR *) newcharp,(long) sizeof(struct pccharl));
        newcharp->map = 0;
        newcharp->pdy = 0;
        }
    
    if (newcharp->pdx < 0)
        newcharp->pdx = 0;
    
    /* copy the bitmap */
    mapP = ((char FAR *) fontp) + fontp->dmap + ((sizeFlag == 0) ? scharp->map : lcharp->map);
#ifndef IBMPC
    if (!isx11) /* wm needs bytes in opposite order */
        TUTORswap_bits_char((unsigned char FAR *) mapP,mapSize);
#endif

    TUTORblock_move(mapP,cp + newfontp->dmap,mapSize);
    
    /* all done */
    ReleasePtr(charH);
    KillPtr(cp);
    
    AllowHandlePurge(charH);
    return(charH);
    }

/* ******************************************************************* */

#ifdef IBMPC

struct pcxhdr {
    char manuf; /* ? manufacturors code? */
    char tcode; /* version code 5 = version 3.0+palette */
    char encode; /* compression method = 1 = rle */
    char bpix; /* bits/pixel */
    int x1; /* coordinates of upper left of image */
    int y1;
    int x2; /* coordinates of lower right of image */
    int y2;
    char hdr2[4];
    char hdr4[48];
    char hdr5;
    char nplanes; /* number planes in image */
    int scanl; /* bytes per line in image */
    char hdr6[12];
    char hdr7[48];
}; /* pcxhdr */

/* ******************************************************************* */

Memh ReadPCX(find) /* convert pcx format to fct format */
int find; /* TUTOR file index */
/* returns font handle (with 1 char in it) */
    
{   struct pcxhdr pcxh; /* pcx file header */
    long tempL;
    int dx,dy; /* size of image */
    Memh fh;  /* the font handle to be returned */
    char FAR *bitmap;
    long bi; /* index in ct image bitmap */
    int pcxsi; /* index in pcx scan line */
    int ctscanl; /* bytes per ct scan line */
    int lastm; /* mask for last byte in scan line */    
    struct pcfont FAR *fonth; /* fpc file header */
    struct pccharl FAR *chart; /* character description */
    int cc;
    int rl; /* length of run-length-encoded data */
    int ii;
    long bitmapL; /* size of bitmap */

    /* read input file header */

    tempL = TUTORread((char FAR *) &pcxh,sizeof(struct pcxhdr),1L,find);
    if (tempL != sizeof(struct pcxhdr))
        return(HNULL);

    dx = pcxh.x2-pcxh.x1+1;
    dy = pcxh.y2-pcxh.y1+1;
    ctscanl = (dx+7) >> 3; /* bytes/scan-line in ct image */
    ii = dx & 7; /* compute bits in last byte */
    if (ii == 0) ii = 8;
    lastm = 0x0ff00L >> ii; /* mask for last byte */

    /* allocate font handle */
    ii = (dx >> 3)+1; /* bytes/row */
    bitmapL = bi = (long)(ii)*(long)(dy+1); /* total bytes for bitmap */
    tempL = (long)(sizeof(struct pcfont)+sizeof(struct pccharl))+bi;
    tempL += 80; /* allow one full scan line overrun */
    fh = TUTORhandle("pcx",tempL,FALSE);
    if (!fh)
        return(HNULL);

    fonth = (struct pcfont FAR *) GetPtr(fh);
    TUTORzero((char FAR *)fonth,(long)sizeof(struct pcfont));
    chart = (struct pccharl FAR *)(((char FAR *)fonth)+sizeof(struct pcfont));
    
    /* read and unpack bit-map */

    bi = 0; /* initialize index in bitmap */
    pcxsi = 0; /* init index in scan lines */
    bitmap = ((char FAR *) chart)+sizeof(struct pccharl);
    while ((cc = TUTORget_char(find,FALSE)) != EOF) {
        if ((cc & 0xc0) == 0xc0) { /* unpack run-length encoding */
            rl = cc & 0x3f;
            cc = TUTORget_char(find,FALSE); /* get repeated data byte */
            cc = ~cc; /* invert data */
        for(ii = 0; ii<rl && bi < bitmapL; ii++) {
                pcxsi++; /* increment scan line index */
                if (pcxsi < ctscanl) {
                    *bitmap++ = cc;
                    bi++;
                } else if (pcxsi == ctscanl) {
                    *bitmap++ = cc & lastm; /* mask last byte */
                    bi++;
                } /* pcxsi else */
            } /* for */
        } else { /* add next byte to bitmap */
            cc = ~cc; /* invert data */
            pcxsi++; /* increment scan line index */
            if (pcxsi < ctscanl) {
                *bitmap++ = cc;
                bi++;
            } else if (pcxsi == ctscanl) {
                *bitmap++ = cc & lastm; /* mask last byte */
                bi++;
            } /* pcxsi else */
        } /* run-length encoding else */

        /* check if at end of scan line */

        if (pcxsi >= pcxh.scanl)
            pcxsi = 0; /* reset index */

        /* check if bit map too large */

    if (bi >= bitmapL) { /* image is too large, give up */
            ReleasePtr(fh);
            KillPtr(fonth);
            TUTORfree_handle(fh);
            return(HNULL);
        }
    } /* while */

    /* set up font header */

    strcpyf(&fonth->ident[0],(char FAR *)"ct");
    fonth->first8 = 1;
    fonth->nchars8 = 1;
    fonth->newline = dy;
    fonth->ascent = 0;
    fonth->descent = 0;
    fonth->maxwidth = dx;
    fonth->size = 0;
    fonth->dstyle = 0; /* plain */
    fonth->astyle = 0; /* can't generate bold, italic, underline */
    fonth->format = 3; /* icons, large format */
    fonth->rdef = fonth->rmap = FARNULL;
    fonth->ddef = sizeof(struct pcfont);
    fonth->dmap = sizeof(struct pcfont)+sizeof(struct pccharl);

    /* set up character description */

    chart->pdx = dx;
    chart->pdy = dy;
    chart->bndx = 0;
    chart->bndy = -dy;  /* makes character all ascender */
    chart->bnw = dx; /* width  of bounding box */
    chart->bnh = dy; /* height of bounding box */
    chart->mapdx = 0;
    chart->mapdy = 0;
    chart->mapw = dx; /* width  of character bit map */
    chart->maph = dy; /* height of character bit map */
    chart->map = 0; /* bias to bitmap for character */

    /* clean up */
    ReleasePtr(fh);
    KillPtr(fonth);
    
    /* size handle properly & make it purgeable */
    tempL = sizeof(struct pcfont)+sizeof(struct pccharl)+(long)bi;
    TUTORset_hsize(fh,tempL,TRUE);
    TUTORpurge_info(fh,M_WORM,FARNULL,0); /* make handle purgable */
    AllowHandlePurge(fh);
    
    return(fh); 

} /* ReadPCX */

#endif /* IBMPC */

/* ******************************************************************* */

