


/* ******************************************************************* */
/* based on gif2ras.c, Marcel Mol */
/* The Graphics Interchange Format(c) is the Copyright property of */
/* CompuServe Incorporated.  GIF(sm) is a Service Mark property of */
/* CompuServe Incorporated. */
/* ******************************************************************* */

/*********************************************
 *             GIF to SUN rasterfile         *
 *                                           *
 *      March 23 1989 By Marcel J.E. Mol     *
 *                                           *
 * I hereby place this program               *
 * in the public domain, i.e. there are no   *
 * copying restrictions of any kind.         *
 *********************************************/

/* ******************************************************************* */

#include <stdio.h>
#include "baseenv.h"
#include "gifres.h"

#ifdef MAC
#include <string.h>
#define READCOD "rb"
#else
#include <sys/types.h>
#include <sys/stat.h>
#endif

#ifdef IBMPC
#define READCOD "rb"
#else
#define huge
#define far
#endif

#ifndef READCOD
#define READCOD "r"
#endif

#pragma check_stack(on)

#define COLSIZE 256

/* LZW definitions */

struct LZWinf {
	unsigned char far *stackp;
	unsigned char huge *fill; /* current fill pointer */
	unsigned long prefix[4096];
	unsigned char suffix[4096];
	unsigned char stack[4096];
	long datasize,codesize,codemask;     /* Decoder working variables */
	long clear,eoi;                      /* Special code values */
	long avail;
	long oldcode;
}; /* LZWinf */

struct LZWinf far *LZWp = NULL; /* pointer to Lempel-Zim info */

/* GIF definitions */

struct GIFinf {
	FILE *infile; /* pointer to GIF file */
	unsigned char huge *inMem;	/* pointer to GIF file in memory */
	long memSize; /* size of GIF file in memory */
	long memPos; /* current position within file */
	unsigned int screenwidth;           /* The dimensions of the screen */
	unsigned int screenheight;          /*   (not those of the image)   */
	unsigned int rscreenwidth;          /* The dimensions of the raster */
	int global;                        /* Is there a global color map? */
	int globalbits;                     /* Number of bits of global colors */
	unsigned char globalmap[COLSIZE*3]; /* RGB values for global color map */
	char bgcolor;                       /* background color */
	unsigned char huge *raster;	    /* Decoded image data */
	unsigned left,top,width,height,rwidth;
	unsigned char redC[COLSIZE];
	unsigned char greenC[COLSIZE];
	unsigned char blueC[COLSIZE];
}; /* GIFinf */

struct GIFinf far *GIFp = NULL; /* pointer to GIF info */

struct GIFresult far *GIFresp = NULL; /* pointer to GIF result return */

#ifdef ctproto
extern int TUTORdump(char *str);
extern struct GIFresult far *read_gif(char *filename,unsigned char huge *inMem,long memSize);
extern long my_l_read(char far *ptr,int pSize,long count,FILE *fp);
extern long my_l_write(char far *ptr,int pSize,long count,FILE *fp);
extern int TUTORblock_move(char far *p1,char far *p2,long len);
extern int TUTORzero(char far *pp,long len);
extern void initcolors(unsigned char far mp[COLSIZE*3],int nc,int bg);
extern char  FAR *TUTORalloc(long  size,int  abort,char  *label);
extern int  TUTORdealloc(char  FAR *ptr);
extern void convert(void);
extern int checksignature(void);
extern int process(long code);
extern void readscreen(void);
extern int readimage(void);
extern int my_getc(void);
extern void readextension(void);
extern int readraster(void);
extern int rasterize(int intz);
static long flrdwr(char far *rwptr,int pSize,long count,FILE *fp,int rwFlag);
#endif

extern char far *TUTORalloc();
extern int TUTORdealloc();
extern int strncmp();
extern void convert();
extern int  checksignature();
extern void readscreen();
extern int  readimage();
extern void readextension();
extern int  readraster();
extern int  process();
extern void outcode();
extern void initcolors();
extern int  rasterize();
extern long l_write();
extern long my_l_read();
extern long my_l_write();

static int my_getc();
static long flrdwr();

/* ******************************************************************* */

struct GIFresult far *read_gif(filename,inMem,memSize) /* top level driver for gif input */
char *filename; /* pointer to file name or NULL */
unsigned char huge *inMem; /* pointer to file in memory or NULL */
long memSize; /* size of file in memory */

{	int cii; /* index in colors */
	struct GIFresult far *retP; /* return pointer */

	if (!LZWp) 
		LZWp = (struct LZWinf huge *)TUTORalloc((long)sizeof(struct LZWinf),FALSE,"gif");
	if (!LZWp)
		return(NULL);
	TUTORzero((char far *)LZWp,(long)sizeof(struct LZWinf));
	if (!GIFp) {
		GIFp = (struct GIFinf huge *)TUTORalloc((long)sizeof(struct GIFinf),FALSE,"gif");
		if (!GIFp)
			return(NULL);
		TUTORzero((char far *)GIFp,(long)sizeof(struct GIFinf));
	} else {
		if (GIFp->raster)
			TUTORdealloc((char far *)GIFp->raster);
		GIFp->raster = NULL;
	}
	if (!GIFresp) {
		GIFresp = (struct GIFresult huge *)TUTORalloc((long)sizeof(struct GIFresult),FALSE,"gif");
	}
	if (!GIFresp)
		return(NULL);
	TUTORzero((char far *)GIFresp,(long)sizeof(struct GIFresult));
		
	if (GIFresp->raster)
		TUTORdealloc((char far *)GIFresp->raster); /* free old copy */
	GIFresp->raster = NULL;
	
	if (filename) { /* reading from file */
		if ((GIFp->infile = fopen(filename,READCOD)) == NULL) {
			return(NULL);
    	}
	} else if (inMem) {
		GIFp->inMem = inMem;
		GIFp->memSize = memSize;
		GIFp->memPos = 0L;
	}
    convert();
	if (filename)
    	fclose(GIFp->infile);
	if (!GIFp->raster) 
		return(NULL); /* didn't work */

	/* return GIF information */
	
	GIFresp->width = GIFp->width;
	GIFresp->height = GIFp->height;
	GIFresp->bytesRow = GIFp->rwidth;
	GIFresp->raster = GIFp->raster;
	GIFp->raster = NULL; /* doesn't belong to us any more */
	for(cii=0; cii<256; cii++) {
		GIFresp->redC[cii] = GIFp->redC[cii];
		GIFresp->greenC[cii] = GIFp->greenC[cii];
		GIFresp->blueC[cii] = GIFp->blueC[cii];
	}
	TUTORdealloc((char far *)GIFp); /* clean up intermediate storage */
	GIFp = NULL;
	TUTORdealloc((char far *)LZWp);
	LZWp = NULL;
	retP = GIFresp;
	GIFresp = NULL; /* we don't own this anymore */
	return(retP);

} /* read_gif */

/* ******************************************************************* */

void convert() /* parse gif file, convert to colors and raster */

{	char ch;

    if (checksignature())
        return;
    readscreen();
    while ((ch = my_getc()) != ';' && ch != EOF) {
        switch (ch) {
            case '\0':  break;  /* this kludge for non-standard files */
            case ',':   if (!readimage())
                           return;
                        break;
            case '!':   readextension();
                        break;
            default:    
                        return;
                        break;
        }
    }

} /* convert */

/* ******************************************************************* */

int checksignature() /* recognize GIF 87a */
{
    char buf[6];

    my_l_read(buf,1,6,GIFp->infile);
    if (strncmp(&buf[0],"GIF",3) != 0) {
        return 1;
    }
/*    if (strncmp(&buf[3],"87a",3)) {
        fprintf(stderr, "unknown GIF version number\n");
        return 1;
    } */
    return 0;

} /* checksignature */

/* ******************************************************************* */

void readscreen() /* get image size and global colors */

{	unsigned char buf[7];

    my_l_read((char far *)buf,1,7,GIFp->infile);
    GIFp->screenwidth = buf[0] + (buf[1] << 8);
    GIFp->rscreenwidth = GIFp->screenwidth + GIFp->screenwidth%2; /* compensate odd widths */
    GIFp->screenheight = buf[2] + (buf[3] << 8);
    GIFp->global = buf[4] & 0x80;
    if (GIFp->global) {
        GIFp->globalbits = (buf[4] & 0x07) + 1;
	my_l_read((char far *)GIFp->globalmap,3,1<<GIFp->globalbits,GIFp->infile);
    }
    GIFp->bgcolor = buf[5];

} /* readscreen */

/* ******************************************************************* */

int readimage() /* read colormap and raster */

{	unsigned char buf[9];
    int local, interleaved;
    char localmap[256*3];
    int localbits;
    long size;

    if (my_l_read((char far *)buf, 1, 9, GIFp->infile) == 0) {
        return(FALSE);
    }
    GIFp->left = buf[0] + (buf[1] << 8);
    GIFp->top = buf[2] + (buf[3] << 8);
    GIFp->width = buf[4] + (buf[5] << 8);
    GIFp->rwidth = GIFp->width + GIFp->width%2; /* compensate odd widths */
    GIFp->height = buf[6] + (buf[7] << 8);
    local = buf[8] & 0x80;
    interleaved = buf[8] & 0x40;

    if (local == 0 && GIFp->global == 0) {
        return(FALSE);
    }
    size = (long)(GIFp->rwidth)*(long)(GIFp->height);
    if ((GIFp->raster = (unsigned char huge *) TUTORalloc(size,FALSE,"gif")) == NULL) {
        return(FALSE);
    }
    TUTORzero((char FAR *)GIFp->raster,size);
    if (!readraster()) {
		TUTORdealloc((char far *)GIFp->raster); /* discard pixels, didn't work */
		GIFp->raster = NULL;
        return(FALSE);
	}

    if (local) {
        localbits = (buf[8] & 0x7) + 1;
	my_l_read(localmap, 3, 1<<localbits, GIFp->infile);
        initcolors((unsigned char *)localmap, 1<<localbits, GIFp->bgcolor);
    } else if (GIFp->global) {
        initcolors(GIFp->globalmap, 1<<GIFp->globalbits, GIFp->bgcolor);
    }

    rasterize(interleaved);

    return(TRUE);

} /* readimage */

/* ******************************************************************* */

void readextension() /* read and skip over GIF extension block */

{	unsigned char code;
    long count;
    char buf[255];

    code = my_getc();
    while (count = my_getc())
	my_l_read(buf, 1, count, GIFp->infile);

} /* readextension */

/* ******************************************************************* */

readraster() /* read image pixels */

{		unsigned width,height;
        unsigned char buf[255];
        register bits=0;
        register unsigned long datum=0;
        register unsigned char *ch;
		long count;
		long code;

		width = GIFp->width;
		height = GIFp->height;
		LZWp->fill = GIFp->raster;
        LZWp->datasize = my_getc();
        LZWp->clear = 1L << LZWp->datasize;
        LZWp->eoi = LZWp->clear + 1;
        LZWp->avail = LZWp->clear + 2;
        LZWp->oldcode = -1;
        LZWp->codesize = LZWp->datasize + 1;
        LZWp->codemask = (1L << LZWp->codesize) - 1;
        for (code = 0; code < LZWp->clear; code++) {
            LZWp->prefix[code] = 0;
            LZWp->suffix[code] = code;
        }
        LZWp->stackp = LZWp->stack;
        for (count = my_getc(); count > 0; count = my_getc()) {
	    my_l_read((char far *)buf,1,count,GIFp->infile);
            for (ch=buf; count-- > 0; ch++) {
                datum += (unsigned long)(*ch) << bits;
                bits += 8;
                while (bits >= LZWp->codesize) {
                    code = datum & LZWp->codemask;
                    datum >>= LZWp->codesize;
                    bits -= LZWp->codesize;
                    if (code == LZWp->eoi) {               /* This kludge put in */
                        goto exitloop;               /* because some GIF files*/
                    }                                /* aren't standard */
                    if (process(code)) {
                        goto exitloop;
                    }
                }
            }
            if (LZWp->fill >= GIFp->raster+(long)(width)*(long)(height)) {
                goto exitloop;
            }
        }
exitloop:
	if ((LZWp->fill-GIFp->raster) != (long)(width)*(long)(height))	{
   TUTORdump("wrong raster size");
          /*  printf("warning: wrong rastersize: %ld bytes\n",
                      (long) (fill-GIFp->raster));
            printf( "         instead of %ld bytes\n",
                      (long) width*height); */
        }

        return(TRUE);

} /* readraster */


/*
 * Process a compression code.  "clear" resets the code table.  Otherwise
 * make a new code table entry, and output the bytes associated with the
 * code.
 */

process(code)
register long code;
{
        long incode;
        static unsigned char firstchar;

        if (code == LZWp->clear) {
            LZWp->codesize = LZWp->datasize + 1;
            LZWp->codemask = (1L << LZWp->codesize) - 1;
            LZWp->avail = LZWp->clear + 2;
            LZWp->oldcode = -1;
            return 0;
        }

        if (LZWp->oldcode == -1) {
            *LZWp->fill++ = LZWp->suffix[code];
            firstchar = LZWp->oldcode = code;
            return 0;
        }

        if (code > LZWp->avail) {
            return 1; 
        }

        incode = code;
        if (code == LZWp->avail) {      /* the first code is always < avail */
            *LZWp->stackp++ = firstchar;
            code = LZWp->oldcode;
        }
        while (code > LZWp->clear) {
            *LZWp->stackp++ = LZWp->suffix[code];
            code = LZWp->prefix[code];
        }

        *LZWp->stackp++ = firstchar = LZWp->suffix[code];
        LZWp->prefix[LZWp->avail] = LZWp->oldcode;
        LZWp->suffix[LZWp->avail] = firstchar;
        LZWp->avail++;

        if (((LZWp->avail & LZWp->codemask) == 0) && (LZWp->avail < 4096)) {
            LZWp->codesize++;
            LZWp->codemask += LZWp->avail;
        }

        LZWp->oldcode = incode;
        do {
            *LZWp->fill++ = *--(LZWp->stackp);
        } while (LZWp->stackp > LZWp->stack);

        return 0;

} /* process */

/*
 * Convert a color map (local or global) to arrays with R, G and B
 * values. Pass colors to SUNVIEW and set the background color.
 */

void initcolors(colormap, ncolors, bgcolor)
unsigned char far colormap[COLSIZE*3];
int ncolors;
int bgcolor;
{
    register i;

    for (i = 0; i < ncolors; i++) {
        GIFp->redC[i]   = colormap[i*3];
        GIFp->greenC[i] = colormap[(i*3)+1];
        GIFp->blueC[i]  = colormap[(i*3)+2];
    }

} /* initcolors */



/*
 * Read a row out of the raster image and write it to the screen
 */

rasterize(interleaved)
int interleaved;

{
    long row, col;
	register unsigned char huge *raster;
    register unsigned char huge *rr;
    unsigned char huge *newras;
    
   
    
#define DRAWSEGMENT(offset, step)                       \
        for (row = offset; row < GIFp->height; row += step) { \
            rr = newras + (long)(row)*(long)(GIFp->rwidth);                   \
            TUTORblock_move((char far *)raster, (char far *)rr,(long)GIFp->width);                   \
            raster += GIFp->width;                            \
        }

	raster = GIFp->raster;
    if ((newras = (unsigned char huge *) TUTORalloc((long)GIFp->rwidth*(long)GIFp->height,FALSE,"gif")) == NULL) {
        return 1;
    }
    rr = newras;
    if (interleaved) {
        DRAWSEGMENT(0, 8);
        DRAWSEGMENT(4, 8);
        DRAWSEGMENT(2, 4);
        DRAWSEGMENT(1, 2);
    }
    else 
        DRAWSEGMENT(0, 1);

    TUTORdealloc((char far *)GIFp->raster);
	GIFp->raster = newras; /* set to point at new image */
	return(0);

} /* rasterize */

/* ******************************************************************* */

long my_l_write(ptr,pSize,count,fp) /* long write */
char far *ptr; /* buffer to write out */
int pSize; /* size of item */
long count; /* # of items to write out */
FILE *fp;
/* returns # of bytes written */
    
{
    return(flrdwr(ptr,pSize,count,fp,FALSE));

} /* my_l_write */

/* ******************************************************************* */

static int my_getc() /* read character from file or memory */

{	unsigned char cc[2]; /* character to read into */

	if (my_l_read((char far *)&cc[0],1,1L,GIFp->infile) != 1)
		return(EOF);
	return(cc[0]);
	
} /* my_getc */

/* ******************************************************************* */

static long my_l_read(ptr,pSize,count,fp) /* long read from file or memory */
char far *ptr; /* buffer to fill */
int pSize; /* size of item */
long count; /* # of items to write out */
FILE *fp;
/* returns # of bytes read */
    
{
	if (GIFp->inMem) {
		count = count*pSize; /* convert to bytes */
		if (GIFp->memPos >= GIFp->memSize) 
			return(EOF); /* at end of file */
		if ((GIFp->memPos+count) > GIFp->memSize)
			count = GIFp->memSize-GIFp->memPos;
		TUTORblock_move((char far *)(GIFp->inMem+GIFp->memPos),(char far *)ptr,count);
		GIFp->memPos += count;
		return(count);
	}
    return(flrdwr(ptr,pSize,count,fp,TRUE));

} /* my_l_read */

/* ******************************************************************* */

#define CHUNKSZE 1024

static long flrdwr(rwptr,pSize,count,fp,rwFlag) /* long read or write */
char far *rwptr; /* where the read is going */
int pSize; /* size of object */
long count; /* # of objects */
FILE *fp; /* file to read/write */
int rwFlag; /* TRUE: read, FALSE: write */
    
{   int nReads,ii, nNew, toRead;
    long nIn;
    char far *fbuf; /* long pointer to local buffer */
    char buf[CHUNKSZE]; /* local buffer for read/write */
    char huge *ptr; /* pointer to data read/written */

    nIn = 0;
    ptr = rwptr; /* use huge ptr so arithmetic works */
    count *= pSize; /* now just working in bytes */

    if (!count)
		return(nIn);
    
    nReads = (int)((count-1)/CHUNKSZE);
    for (ii=0; ii<=nReads; ii++) {
    	if (ii == nReads) {
    		toRead = count-(long)(nReads)*(long)(CHUNKSZE);
    	} else toRead = CHUNKSZE;
		if (rwFlag) {
	    	nNew = fread(buf,1,toRead,fp);
	    	fbuf = buf; /* far pointer to local buffer */
	    	TUTORblock_move(fbuf,ptr,(long)toRead);
		} else {
	    	fbuf = buf; /* far pointer to local buffer */
	    	TUTORblock_move(ptr,fbuf,(long)toRead);
	    	nNew = fwrite(buf,1,toRead,fp);
		} /* else */
		if (nNew == 0) {
	    	if (feof(fp))
				return(nIn); /* read to end of file */
	    	return(0L); /* error */
		} /* nNew if */
		nIn += nNew;
		ptr += toRead;
		if (nNew < toRead)
	    	break;
    } /* for */

    if (!rwFlag)
		fflush(fp);

    return(nIn);

} /* flrdwr */

/* ******************************************************************* */
