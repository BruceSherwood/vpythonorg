

/* -vset- tokens */

#define VID_DISK 200
#define VID_PICTURE 201
#define VID_AUDIO1 202
#define VID_AUDIO2 203
#define VID_FRAME 204
#define VID_RECTANGLE 205
#define VID_COLOR 206
#define VID_VONLY 207

extern int vid_kind; /* type of video system */
extern int vid_color; /* current transparent color */


/* ******************************************************************* */

struct controlDat { /* data required for video/audio controller */
	int window; /* window scroll bar is in */
	struct tutorview FAR *ownerView; /* view of controller's owner, or "container" */
	struct tutorview FAR *view; /* scroll bar's view */
	TRect cRect; /* rectangle enclosing controller */
	struct tutorColor cGrey; /* light grey - background color */
	struct tutorColor cDkGrey; /* dark grey - highlight color */
	int playStop; /* TRUE = play button (stopped) */
	              /* FALSE = stop button (playing) */
	TRect playB; /* play button */
	TRect fwdB; /* forward button */
	TRect backB; /* backward button */
	TRect clipR; /* clip region */
	int playVis,fwdVis,backVis; /* TRUE if button visible */
	int playLit; /* TRUE if play button highlighted */
	int fwdLit; /* TRUE if forward button hilighted */
	int backLit; /* TRUE if backward button hilighted */
	int drawTrack; /* TRUE if need to redraw track */
	TRect trackBack; /* track background region */
	TRect trackFore; /* track foreground region */
	int trackWidth; /* length of thumb track */
	long trackRegion; /* saved region for track background */
	int thumbXAdj; /* adjustment to to center of thumb */
	TRect thumbRect; /* current thumb rectangle */
	double thumbPos; /* position (time) of controller slider */
	double prevThumb; /* previous position of controller slider */
	double startTime; /* start position in media (seconds) */
	double endTime; /* end position in media (seconds) */
	double duration; /* length of media (seconds) */
	int numMouseDown; /* number mouse-down events */
	int mouseAction; /* 0 = no down-click yet */
	                 /* 1 = dragging the thumb */
	                 /* 2 = play/stop button pressed */
	                 /* 3 = backwards button pressed */
	                 /* 4 = forwards button pressed */
	long timerCount; /* number time events rcvd while button down */
#ifdef MAC
	int (*playProc)(Memh c1H); /* routine to handle play button */
	int (*stopProc)(Memh c2H); /* routine to handle stop button */
	int (*thumbProc)(Memh c3H); /* routine to handle thumb position change */
	int (*backProc)(Memh c4H); /* routine to handle backwards button */
	int (*fwdProc)(Memh c5H); /* routine to handle forwards button */
#endif
#ifdef X11
	int (*playProc)(); /* routine to handle play button */
	int (*stopProc)(); /* routine to handle stop button */
	int (*thumbProc)(); /* routine to handle thumb position change */
	int (*backProc)(); /* routine to handle backwards button */
	int (*fwdProc)(); /* routine to handle forwards button */
#endif
#ifdef WINPC
	int (*playProc)(); /* routine to handle play button */
	int (*stopProc)(); /* routine to handle stop button */
	int (*thumbProc)(); /* routine to handle thumb position change */
	int (*backProc)(); /* routine to handle backwards button */
	int (*fwdProc)(); /* routine to handle forwards button */
#endif

}; /* controlDat */

/* ******************************************************************* */
