
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#ifndef _execdefsh
#define _execdefsh

/*
Header file for cT execution.
*/

#ifndef _baseenvh
#include "baseenv.h"
#endif
#ifndef _computeh
#include "compute.h"
#endif
/* ifndef _commandsh
 include "commands.h"
 endif */
#ifndef _tutorh
#include "tutor.h"
#endif

#ifndef setjmp_d
#include "setjmp.h"
#define setjmp_d
#endif

/* defines for run-time stack */

#define STACK_MAIN_UNIT 1
#define STACK_UNIT 2
#define STACK_DO 3
#define STACK_ARROW 4
#define STACK_ARROW_NEST 5

#define checkbit(qq,nn) ((qq & (1L << nn)) != 0)
#define round(qq) (lcftoi(qq))

#define OUTGO if (exS.outcnt > 10) flush()
#define IFEVENT (exS.readevent != exS.writeevent)
#define LOOPCOUNT 10
#define DOCOUNT 10

/* read floating value */
#define readflt(laddr) *(double SHUGE *)(laddr)

/* store floating value */
#define storeflt(laddr, fvalue) *(double SHUGE *)(laddr )= fvalue

/* store 32-bit integer value */
#define storeint(laddr, ivalue) *(long SHUGE *)(laddr) = ivalue

/* store 4 bytes */
#define store4(laddr, value) *(long SHUGE *)(laddr) = value

#define RDN (pi/180.0)

#define BUTTONSIGNAL 3001
#define BUTTONSIGNALA 3002

/* indexes in touch region info */

#define TR_LDOWN   0    /* left down */
#define TR_LUP     1    /* left up */
#define TR_LMOVE   2    /* left down move */
#define TR_LDOUBLE 3    /* left double-click */
#define TR_RDOWN   4    /* right down */
#define TR_RUP     5    /* right up */
#define TR_RMOVE   6    /* right down move */
#define TR_RDOUBLE 7    /* right double-click */
#define TR_UPMOVE  8    /* buttons-up move */

/* length of executor -write- temp buffer */

#define WRT_TXT_LTH 1000

#endif /* _execdefsh */
