/*
A component of the cT (TM) programming environment.
(c) Copyright 1994 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/
#include "baseenv.h"
#include <stdio.h>
#include "prefs.h"
#ifdef ANDREW
#ifndef sys_typesh
#include <sys/types.h>
#define sys_typesh
#endif
#ifdef SYSV
#include <dirent.h>
#else
#include "dir.h"
#endif
#endif /* andrew */
#include "kglobals.h"
#include "ecglobal.h"
#include "tglobals.h"
#include "tfiledef.h"
#include "compute.h"
#include "commands.h"
#ifdef ctproto
extern int TUTORzero(char SHUGE *ptr,long length);
extern int TUTORget_AE_win(void);
extern int UpdateWinPrefs(void);
extern int MacSysFolder(FileRef *fR,int type);
extern int PrefColorN(char *str);
extern int PrefFaceN(char *str);
long  TUTORwrite(char  FAR *ptr,int  pSize,long  count,int  findx);
extern char *PrefFaceStr(int index);
extern char *PrefColorStr(int index);
struct PrefRec FAR *ReadPrefs(void);
int WritePrefs(struct PrefRec FAR *prefPtr); 
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int  strlenf(char  FAR *aa);
int  TUTORdealloc(char  FAR *ptr);
extern int strcmpf(char FAR *aa,char FAR *bb);
extern int OpenPrefs(int ww);
extern char *skip_white(char *sptr);
extern int uplow(char FAR *str);
extern int ParseTF(char *str);
int  InitPrefs(void);
int  TUTORget_zfont(char  *famS,int  size);
int  TUTORtrace(char  *s);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  assoc_name(struct  _fref FAR *fn,struct  _fref FAR *bfilen,char  *extnNew);
int  TUTORget_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  TUTORdump(char  *s);
int  TUTORinq_font_descr(int  fontN,long *fam,int  *siz,int  *fac);
int  TUTORget_font2(long  fam,int  size,unsigned int  face,int cid);
int  TUTORround_font_size(int  size);
int  TUTORclose(int  findx);
int  TUTORread_string(unsigned char  *str,int  length,int  findx);
int  SetHiliteColor(int  hc);
long TUTORadd_ffamily(struct  _fref *famName,int  isSys,int  isSwitch);
int  TUTORsymbolic_fileref(struct  _fref FAR *fRef,char  FAR *syms);
long  TUTORinq_symbolic_font_id(char  *fontName);
int  TUTORcopy_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  TUTORcopy_fileref_dir(struct  _fref FAR *dirname,struct  _fref FAR *fullname);
extern char FAR *strncpyf(char FAR *aa,char FAR *bb,int len);
extern int PrefFont(void);
#ifdef IBMPROTO
int _CDECL sscanf(const char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */
#ifdef macproto
#ifndef THINKC5
#ifndef WERKS
extern int sprintf(char *ss, char *form,...);
extern int sscanf(char *ss, char *form,...);
#endif
#endif
#endif
extern char *skip_white();
extern long TUTORget_len_doc();
extern char *TUTORgetenv();
extern  int procexecstub();
long TUTORwrite(), TUTORread();
char *strf2n();
extern Memh TUTORnew_doc();
extern long TUTORinq_msec_clock();
extern char *machinename();
extern long lowcore();  /* low-memory routines */
extern long lcftoi();   
extern double lcitof();
extern char  FAR *strcpyf();
/* ******************************************************************* */
#ifndef MAC
#ifndef IBMPC
#define WORKSTATION
#endif
#endif
char *kPrefID = "cT 2.6 01";
/* ******************************************************************* */
static int OpenPrefs(ww) /* open preferences file */
int ww; /* TRUE if open for write */
{	FileRef prefRef;
	char tempS[FILEL+1];
    int prefFile;
    int haveRef;
    int openType;
    /* open preferences file */
	haveRef = FALSE;
#ifndef WORKSTATION /* ---------------------------- */
#ifdef MAC
	if (ww) openType = 2;
	else openType = 1;
	if (prefFile = MacSysFolder(&prefRef,openType)) /* open sys-defined preference */
		haveRef = TRUE;
#endif
	if (!haveRef) {
	TUTORcopy_fileref_dir((FileRef FAR *) &prefRef, ctDirP);
#ifdef MAC
#ifdef WERKS
#ifdef __MC68K__
    	TUTORcopy_fileref_name((FileRef FAR *) &prefRef,(char FAR *)"cT_Preferences_68k");
#else
    	TUTORcopy_fileref_name((FileRef FAR *) &prefRef,(char FAR *)"cT_Preferences_ppc");
#endif
#else
    	TUTORcopy_fileref_name((FileRef FAR *) &prefRef,(char FAR *)"cT.Preferences");
#endif
#else
#ifdef CTEDIT
    	TUTORcopy_fileref_name((FileRef FAR *) &prefRef, (char FAR *)"ctedit.prf");
#else
    	TUTORcopy_fileref_name((FileRef FAR *) &prefRef,(char FAR *)"ct.prf");
#endif
#endif /* MAC else */ 
		prefFile = TUTORopen((FileRef FAR *) &prefRef,!ww,ww,FALSE);
	}
    
#else /* WORKSTATION ------------------------------ */
#ifdef CTEDIT
    strcpy(tempS,"~/.cTEdit.prf.");
    strcat(tempS,machinename());
    TUTORcvt_path(tempS, (FileRef FAR *)&prefRef, FARNULL,TRUE);
#else
    strcpy(tempS,"~/.cT.prf.");
    strcat(tempS,machinename());
    TUTORcvt_path(tempS, (FileRef FAR *)&prefRef, FARNULL,TRUE);
#endif /* CTEDIT */
    prefFile = TUTORopen((FileRef FAR *) &prefRef,!ww,ww,FALSE);
#endif /* WORKSTATION */   
    return(prefFile);
    
} /* OpenPrefs */
/* ******************************************************************* */
static struct PrefRec FAR *ReadPrefs() /* read preferences file */
{	int prefFile; /* cT file index */
	struct PrefRec FAR *prefPtr; /* pointer to preferences data */
	long lRead; /* amount of data read */
	long lPrefs; /* size of prefs record */
	int errF; /* TRUE if error */
    
    prefFile = OpenPrefs(FALSE);
	if (!prefFile)
		return(FARNULL);
		
	/* allocate memory for preferences data */
	
	errF = FALSE;
	lPrefs = (long)sizeof(struct PrefRec);
	prefPtr = (struct PrefRec FAR *)TUTORalloc(lPrefs,FALSE,"pref");
	if (!prefPtr) errF = TRUE;
	else {
	
		/* read preference data */
		
		lRead = TUTORread((char  FAR *)prefPtr,1,(long)sizeof(struct PrefRec),prefFile);	
		if (lRead != lPrefs) 
			errF = TRUE;
		else {
			if (strcmpf(prefPtr->prefID,(char FAR *)kPrefID)) /* check identifying label */
				errF = TRUE;  
			if (prefPtr->recLen != sizeof(struct PrefRec))
				errF = TRUE;
		}
	}	
	TUTORclose(prefFile); /* close file after reading */
	
	/* exit if error */
	
	if (errF) {
		TUTORdealloc((char FAR *)prefPtr);
		return(FARNULL);
	}
	return(prefPtr);
		
} /* ReadPrefs */
/* ******************************************************************* */
InitPrefs() /* initialize preferences settings */
    
{	int havePrefs; /* TRUE if preferences set up */
	/* attempt to read preferences file */
	havePrefs = FALSE;
	if (!prfP) {
		prfP = ReadPrefs();
		if (prfP)
			havePrefs = TRUE; /* successfully obtained preferences */
	}
		
	/* quick check that preferences make sense */
	
	if (havePrefs) {
		if (prfP->fcolor == prfP->bcolor) {
			prfP->fcolor = color_black;
			prfP->bcolor = color_white;
		}
	}
	
	/* allocate memory for preferences if needed */
	
	if (!prfP) {
		prfP = (struct PrefRec FAR *)TUTORalloc((long)sizeof(struct PrefRec),FALSE,"pref");
		if (!prfP) 
			return(0); /* no memory */
		TUTORzero((char FAR *)prfP,(long)sizeof(struct PrefRec));
		havePrefs = FALSE; /* need to set defaults */
	}
	
	if (!havePrefs) {
	
   		/* set up default preferences */
    	prfP->fcolor = color_black;
    	prfP->bcolor = color_white;
#ifdef MAC
		prfP->fontSize = 12;
#else
		prfP->fontSize = 16;
#endif
		strcpyf(prfP->fontFamily,"zsans"); /* preferred font name */
	
#ifdef DOSPC
    	strcpy(pprntr,"prn"); /* default printer on IBM-PC */
    	psbint = psbport = 0;
#endif
#ifdef X11
		strcpy(pprntr,"lpr ");
#endif
#ifdef CTEDIT
    	prfP->nTabs = 4;
#else
    	prfP->nTabs = 8;
#endif
        prfP->recLen = sizeof(struct PrefRec);
		strcpy(prfP->prefID,kPrefID);
    	prfP->swapSize = 2*1000L*1000L;
    	useEMS = FALSE; /* dont use EMS on PC by default */
    	useXMS = FALSE; /* dont use xms by default */
    	prfP->snapShot = FALSE; /* dont snapshot exec window */
    	prfP->checkTime = 600; /* checkpoint file every 10 minutes */
    	prfP->winSaveOnExit = TRUE; /* save window settings */
		if (prfP->editWp.left >= prfP->editWp.right) {
			TUTORzero((char FAR *)&prfP->editWp,(long)sizeof(TRect));
			TUTORzero((char FAR *)&prfP->execWp,(long)sizeof(TRect));
			TUTORzero((char FAR *)&prfP->debugWp,(long)sizeof(TRect));
			TUTORzero((char FAR *)&prfP->stackWp,(long)sizeof(TRect));
			TUTORzero((char FAR *)&prfP->msgWp,(long)sizeof(TRect));
			prfP->editWp.right = 610;
			prfP->editWp.bottom = 400;
			prfP->execWp.right = 500;
			prfP->execWp.bottom = 400;
			prfP->msgWp.top = prfP->editWp.top+40;
			prfP->msgWp.right = prfP->editWp.right;
			prfP->msgWp.bottom = prfP->msgWp.top+150;
			prfP->debugWp.right = 320;
			prfP->debugWp.bottom = 150;
			prfP->stackWp.right = 300;
			prfP->stackWp.bottom = 150;
		}
	} /* havePrefs if */
	    
	PrefFont(); /* set up font */
	
    return(0);
    
} /* InitPrefs */
/* ******************************************************************* */
	
int PrefFont() /* set editor default font from preferences */
{	FileRef fontName;
    char FAR *tempNameP; /* pointer to font name */
    int tempSize; /* font size */
    int tempFace; /* font face */
    long tempFam; /* font family index */
    int fii; /* font index */
    unsigned char tempS[FILEL+1];
    
	if (!prfP->fontFamily[0]) {
		strcpyf(prfP->fontFamily,"zsans"); /* set default face */
#ifdef MAC
		prfP->fontSize = 13;
#else
		prfP->fontSize = 16;
#endif		
		prfP->fontFace = 0;
	}
	strcpyf((char FAR *)tempS,prfP->fontFamily);
	tempFam = TUTORinq_symbolic_font_id((char *)tempS);
	if (tempFam < 0) { /* need to add font family */
		TUTORsymbolic_fileref((FileRef FAR *) &fontName,(char FAR *)tempS);
        tempFam = TUTORadd_ffamily(&fontName,TRUE,FALSE);
	} /* tempFam if */
	pffamilynP = prfP->fontFamily; /* pointer to font family name */
 	tempSize = prfP->fontSize;
 	tempFace = prfP->fontFace;
    tempSize = TUTORround_font_size(tempSize); /* make tempSize a good size */
    fii = TUTORget_font2(tempFam,tempSize,tempFace,113);
    TUTORinq_font_descr(fii,&pffamily,&pfsize,&pfface);
    return(0);
    
} /* PrefFont */
/* ******************************************************************* */
#ifndef EXECUTE
int WritePrefs(prefPtr) /* write preferences file */
struct PrefRec FAR *prefPtr; /* pointer to preferences data */
{	int prefFile; /* cT file index */
	long lWrote; /* amount of data written */
	int errF; /* TRUE if error */
    
    prefFile = OpenPrefs(TRUE);
	if (!prefFile)
		return(FALSE);
	
	/* write preference data */
		
	errF = FALSE;
	lWrote = TUTORwrite((char  FAR *)prefPtr,1,(long)sizeof(struct PrefRec),prefFile);	
	if (lWrote != sizeof(struct PrefRec)) 
		errF = TRUE;
	TUTORclose(prefFile); /* close file after reading */
	
	return(!errF);
		
} /* WritePrefs */
/* ******************************************************************* */
int UpdateWinPrefs() /* update author/execute window locations/sizes */
{	
	if (!prfP->winSaveOnExit) return(0); /* nothing to do */
	if ((ExecWn < 0) || (EditWn[0] < 0)) return(0);
	
	TUTORget_AE_win(); /* get window location info */
	WritePrefs(prfP); /* update preferences file */
		
	return(0);
	
} /* UpdateWinPrefs */
/* ******************************************************************* */
char *PrefColorStr(index) /* return preference color name string */
int index;
{	
	switch (index) {
	case 0: return("black");
	case 1: return("white");
	case 2: return("red");
	case 3: return("green");
	case 4: return("blue");
	case 5: return("yellow");
	case 6: return("cyan");
	case 7: return("magenta");
	default: return("black");
	} /* switch */
	
} /* PrefColorStr */
/* ******************************************************************* */
int PrefColorN(str) /* return preference color value */
char *str; /* color name string */
{	if (!strcmp(str,"black")) return(0);
	if (!strcmp(str,"white")) return(1);
	if (!strcmp(str,"red")) return(2);
	if (!strcmp(str,"green")) return(3);
	if (!strcmp(str,"blue")) return(4);
	if (!strcmp(str,"yellow")) return(5);
	if (!strcmp(str,"cyan")) return(6);
	if (!strcmp(str,"magenta")) return(7);
	return(0);
	
} /* PrefColorN */
/* ******************************************************************* */
char *PrefFaceStr(index) /* return preference font face name string */
int index; /* style index */
{
	if (index == style_bold) return("bold");
	else if (index == style_italic) return("italic");
	else return("normal");
	
} /* PrefFaceStr */
/* ******************************************************************* */
int PrefFaceN(str) /* return preference font face value */
char *str;
{	if (!strcmp(str,"normal")) return(0);
	if (!strcmp(str,"bold")) return(style_bold);
	if (!strcmp(str,"italic")) return(style_italic);
	return(0);
	
} /* PrefFaceN */
#endif /* EXECUTE */
/* ******************************************************************* */
