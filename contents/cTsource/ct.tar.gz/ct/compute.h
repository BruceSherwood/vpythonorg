
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#ifndef _computeh
#define _computeh

#ifndef _baseenvh
#include "baseenv.h"
#endif

#ifdef MAC
#include "math.h"
#else
#include <math.h>
#endif

#ifndef MAC
#ifndef sys_typesh
#include <sys/types.h>
#define sys_typesh
#endif
#include <sys/stat.h>
#endif

#ifndef NULL
#define NULL 0L	/* also defined in /usr/include/stdio.h */
#endif

extern compile();
extern double evaluate();
extern long evali();

#define CURRENTV 21 /* current cmututor version (to convert up to) */
#define LEGALV 21 /* legal version, may not yet be converting up to this */

#define EX_STACKL 130 /* size of run-time int/float expression stacks */
#define EX_MSTACKL 50 /* size of run-time marker expression stack */

#define HASFILES 1 /* unit has local files to close */
#define HASMARKERS 2  /* unit has local markers to close */

#define DEFNAMEL 36   /* must be at least 2 greater than NAMEL */
#define MENUSLEN 81 /* menu item string length is 80 */

#define MAXINDENTS 31 /* max indent level */
#define NUMMENUS 60 /* number of active menus */
#define ARROWLIMIT 200 /* max input chars at arrow */
#define MAXPASSVAL 20  /* allow 20 pass-by-value args */
#define MAXPASSADDR 20  /* allow 20 pass-by-address args */
#define FILLPOINTS 50  /* allow 50 points in -fill- */

#define CHARERR 1	/* illegal character */
#define DECERR 2	/* too many decimal points */
#define LPARENERR 3	/* missing left parenthesis */
#define RPARENERR 4	/* missing right parenthesis */
#define FORMERR 5	/* bad form, e.g. 3+ */
#define BLANKERR 6  /* blank input */
#define NAMEERR 7	/* unrecognized name */
#define DEFERR 8 /* -define- error */
#define USERERR 9 /* bad funct arg, as in arcsin(2) */
#define VARCNTERR 10 /* varcnt != 0 with specs novars */
#define NOTOKASSIGN 11 /* := without specs okassign */
#define NOMEM 12 /* not enough memory */


/* MicroTutor zreturn values for file operations */

#define FILENAMEERR 1 /* illegal name */
#define FILEPOINTER 2 /* illegal file pointer */
#define FILENOTOPEN 3 /* file not open */
#define FILEMISSING 4 /* file not found */
#define FILEIMPROPERTYPE 5
#define FILECODE 6 /* code-word error */
#define FILEDUP 7 /* duplicate file */
#define FILEQUOTA 8 /* assume over quota */
#define FILEPARAMETER 9 /* catch-all error */
#define FILEDIRFULL 10 /* directory full */
#define FILEPERMIT 11 /* permission not granted */
#define FILEINUSE 12 /* cannot delete this file */
#define FILEDIRNOTEMPTY 13 /* cannot delete this directory */
#define FILERANGE 14 /* read or write out of range */
#define FILERESERVED 15 /* file is currently reserved */
#define FILECHAR 16 /* illegal character */
#define FILECANCEL 17 /* dialog box cancled */
#define FILEREGION 18 /* screen region too small for dialog */
#define FILEMEM 19 /* not enough memory */
#define FILENOTSUP 20 /* file operation not supported */
#define FILEBAKWIN 21 /* background window */

/* Arithmetic expression parameters */
#define SEMICOLON 1
#define BACKSLASH 2
#define PERCENT 3
#define RIGHTEMBED 4
#define COLON 5

/* avoid enumeration types, for wider C compatibility */

#define writemode 1
#define rewritemode 2
#define erasemode 3
#define inversemode 4
#define xormode 5

#define judgeok 1
#define judgewrong 2
#define judgeno 3
#define judgeunjudge 4
#define judgeexit 5
#define judgeignore 6
#define judgequit 7
#define judgeokquit 8
#define judgenoquit 9
#define judgeexdent 10
#define judgerejudge 11

#define runall 1
#define runone 2
#define halt 3
#define compileit 4
#define atpause 5
#define atendunit 6
#define atarrow 7
#define atinterrupt 8
#define atgetkey 9
#define atdebug 10

#define ARROWOFFSET 10  /* offset from arrowhead to start of text */

struct sourcefile {
	long mtime;		/* time file last modified */
	FileRef fRef;	/* source file reference */
	short doc;		/* pointer to document */
	short writeable;	/* document writeable flag */
	short valid;		/* file contents valid flag */
	short programpart;	/* part of program (main or used) */
	short ctutv;			/* cmututor version */
	short outeruse;		/* position of outer -use- in base source */
	short ieu;			/* unit number of IEU for this file */
	short firstunit;		/* unit number of first unit in this file */
	short lastunit;		/* unit number of last unit in this file */
	short globaldefsetH;	/* handle on global define set */
	short userdefsetH;	/* handle on user define set */
	short editI; 		/* index of editor on this source file */
}; 

struct caseoptv { /* -case- command optimization data for single value */
	long value; /* constant value */
	unsigned short address; /* address of -case- clause */
	int label; /* internal label of -case- clause */
}; /* caseoptv */

struct caseopt { /* -case- command optimization data */
	int nitems; /* number (constant) items in -case- */
	int nalloc; /* allocated size of value table */
	unsigned short head; /* address of -case- command */
	struct caseoptv FAR *cv; /* value+address */
}; /* caseopt */

struct dim_desc { /* data for single dimension */
	long lower; /* lower bound of this dimension */
	long length; /* length of this dimension */
	long multiplier; /* multiplier for this dimension */
}; /* dim_desc */

struct array_desc { /* data for array+dimensions */
	unsigned char dtype; /* 1 = array descriptor, 6 = dynamic array */
	unsigned char ndim; /* number dimensions */
	unsigned char passa; /* TRUE if pass-by-address */
	unsigned char ddddy; /* unused */
	long ltype; /* logical type */
	long size; /* size of individual element */
	long addr; /* relative address in stack */
	long length; /* total number of elements in array */
	/* struct dim_desc[ndim] follows */
}; /* array_desc */

struct arg_desc {
	unsigned char dtype; /* 2 = pass-by-value, 3 = pass-by-addr */
	unsigned char global; /* local/global flag */
	unsigned char dddd[2]; /* unused */
	long ltype; /* logical type */
	long addr; /* relative address in stack */
}; /* arg_desc */

struct mark_desc {
	unsigned char dtype; /* 4 = single marker variable */
	unsigned char unused[3];
	long addr; /* relative address in stack */
}; /* mark_desc */

struct txtype_desc {
	unsigned char dtype; /* 5 = file/bitmap/etc */
	unsigned char unused[3];
	long ltype; /* logical type */
	long addr; /* relative address in stack */
}; /* txtype_desc */

struct srbimap { /* source/binary map entry */
	unsigned short srcr; /* relative pos of command in source */
	unsigned short binr; /* relative pos of command in binary */
}; /* srbimap */

struct unitinfo {
	char compiled;	/* TRUE if already compiled */
	char haserrors;	/* TRUE if compilation errors */
	char hasglobals;	/* TRUE if refers to global vars */
	char hasfile; /* TRUE if has local file variables */
	char nvargs; /* number value arguments */
	char naargs; /* number address arguments */
	char dddu,dddv; 
	short beginfile;	/* index of source file (0 = base source, non-0 = -use-) */
	short marki;	/* index to an internal marker */
	short pcodeAlphaH; /* original interpreted pcode for each unit */
	short pcodeBetaH; /* possibly compiled pcode */
	short argdesc; /* index of argument descriptors */
	short baseuse;	/* position of outermost -use- for error message */
	short nrefs; /* number branch cross-reference entries */
	short xrefs; /* local branch cross-reference table */
	short nmap; /* number entries in source/binary map */
	short srcmapAlphaH; /* source/binary mapping */
	short srcmapBetaH; /* possibly compiled version of map */
	short debugSetH; /* defines for this unit when debugging */
	long pcodeBetaL; /* length of pcode (pcodeExec) */
	long pcodeAlphaL; /* length of original pcode (pcodeOrg) */
	long textp;	/* starting index of text */
	long textl;	/* length of text */
	long pdskadr; /* address of unit p-code in binary file */
	long bdskadr; /* address of unit compiled code in binary file */
	long rdskadr; /* address of unit branch/reference table in binary file */
	long descp;	/* starting index of array/argument descriptors */
	long descl;	/* length of descriptors */
	long nlvars; /* local variable space required */
}; /* unitinfo */

struct exprt { /* operator/operand description for compile */
	char op; 	/* TRUE if operator */
	char unary; /* TRUE if  unary operator */
	char trinary; /* TRUE if trinary (or greater) operator */
	char array; /* 0 = not array, 1 = indexed array, 2 = whole array */
	char local; /* -1 = not global/local */
	            /* 0 = global */
	            /* 1 = local */
	            /* 2 = pass */
	            /* 3 = global dynamic array */
	            /* 4 = local dynamic array */
                    /* 5 = pass dynamic array */
	char isaddr; /* TRUE = address, FALSE = value */
	unsigned char targ;	/* integer/float/string type of argument(s) */
	unsigned char trel;	/* integer/float/string type of result */
	unsigned char eop;	/* equivalent floating or integer operator */
	unsigned char seop;	/* equivalent string operator */
	unsigned char xeop;	/* equivalent TXTYPE operator */
	unsigned char iad;	/* equivalent integer operand */
	unsigned char bad;	/* equivalent byte operand */
	unsigned char sad;	/* equivalent string operand */
	unsigned char xad;	/* equivalent TXTYPE operand for file, bitmap */
	unsigned char endop;	/* TRUE if end operator (ENDI, ENDF, etc) */
	unsigned char cgen68K;  /* 68000 register/subroutine/not compiled flag */
	unsigned char cgenPPC;  /* PPC   register/subroutine/not compiled flag */
	unsigned char txop;     /* TRUE if legal on one or more TXTYPE */
	char dduu;
	short sgenv;	/* size of value field to generate */
};

struct expra { /* expression analyzer input/output */

    /* input arguments */

    char teol;          /* TRUE if end-of-line is legal terminator */
    char tcomma;        /* TRUE if comma is legal terminator */
    char tsemic;        /* TRUE if semicolon is legal terminator */
    char tassign;       /* TRUE if assign operator is legal terminator */
    char tcolon;        /* TRUE if colon is legal terminator */
    char tparen;        /* TRUE if right paren is legal terminator */
    char tembed;        /* TRUE if embed is legal terminator */
    char tcond;         /* TRUE if backslash is legal terminator */
    char tpercent;      /* TRUE if percent is legal terminator */
    char userc;         /* TRUE if run-time -compute- expression */
    char userd;         /* TRUE if run-time evaulation for debugger */
    char reqstore;      /* TRUE if expression must set store-ablity info */
    char arrayok;       /* TRUE if whole (index-less) array legal */
    char allowsk;       /* TRUE if SKIP allowed */
    char allowf;        /* TRUE if file descriptor allowed */
    char allowm;        /* TRUE if marker variable allowed */
    char allowscrn;     /* TRUE if screen variable allowed */
    char allowbutn;     /* TRUE if button variable allowed */
    char allowslid;     /* TRUE if slider variable allowed */
    char allowedit;     /* TRUE if edit variable allowed */
    char allowtouch;	/* TRUE if touch variable allowed */
    char allowdde;	/* TRUE if DDE variable allowed */
    char mfunctst;	/* TRUE if marker functions store-able */
    char calc;          /* TRUE if compiling -calc- command */
    char docmd; 	/* TRUE if compiling -do- command */
    char nogen; 	/* TRUE if should suppress p-code generation */

    long rtype;         /* type (TINT, TFLOAT, TMARK) of result required */
			/* 0 if should accept any numeric type */

    /* source input */

    Memh srcH; /* handle on source document */
    long *srcbase; /* base position of input C string in source doc */
    unsigned char FAR *src; /* pointer to input C string */
    int *srcpos; /* position in input C string */

    /* pocde generation */

    unsigned char FAR *pcode;    /* buffer for pcodes */
    unsigned int *pcodepos;      /* position in pcode buffer */

    /* string literal generation */

    Memh text;      /* document for (styled) string literals */
    long textbase;  /* base position in string document */

    /* error return */

    char *errmess;      /* returned address of error message */
    int errnum;         /* error number */

    /* expression description return fields */

    char assigned;      /* TRUE if assignment occurred */
    char canstore;      /* TRUE if can store into this expression */
    char isconst;        /* TRUE if expression is constant */
    char warray;        /* = 0 scalar, = 1 whole array, = 2 whole dynamic array */		
    long exprtype;      /* byte/int/float/array type of expression */
    int opcnt;          /* operator count */
    int varcnt;         /* variable count */
    int lastchar;       /* character expression terminated on */
    long iconst;        /* integer constant result */
    double fconst;      /* floating constant result */
}; /* expra */

struct xtoken {
  long type; /* operator/operand type: int,float,etc. */
  unsigned char constf; /* TRUE if constant */
  unsigned char global; /* TRUE if global variable */
  short result; /* result register */
  int code;     /* operator/operand code */
  int loc;      /* address of token within expression */
  unsigned char nextt; /* index of next token */
  unsigned char prevt; /* index of previous token */
  unsigned char nextr; /* index of next linked relational operator */
  unsigned char nextb; /* forwards    link for branch true/false */
  unsigned char nextw; /* index of next token in working chain */
  unsigned char prevw; /* index of previous token in working chain */
  double fvalue; /* floating literal value */
  long ivalue; /* integer literal value */
  long defloc;    /* 16/set, 16/index of symbol */
};  /* xtoken */

struct defset {
	char name[DEFNAMEL]; /* defined set name */
	short srcfile; /* index in sourcetable of source file */
	short global; /* TRUE if global define set */
	short user; /* TRUE if user define set */
	short local; /* TRUE if local define set */
	short defvarH; /* handle on defined variables */
	short defvarN; /* number of defined variables */
	short defvarA; /* number of defined variable slots allocated */
	short mergeH; /* handle on table of merged sets */
	short mergeN; /* number of merged sets */
	short mergeA; /* number merged set slots allocated */
	short nextSet; /* handle on next define set */
}; /* defset */

struct defvar {
	char name[DEFNAMEL]; /* defined name */
	double dvalue; /* value of floating literal */
	long kind; /* 32/TBYTE,TINT,TFLOAT,etc. or 16/type,16/TXTYPE */
	long loc; /* location in stack */
	short arrayinfo; /* -1 scalar, else array descriptor location */
	short arraysum; /* checksum of array descriptor */
	char receive; /* TRUE if receive-by-address local variable */
	char dynamic; /* TRUE if dynamically allocated array */
	char literal; /* TRUE if a literal */
	char dddd; /* unused */
}; /* defvar */

struct argdef { /* unit argument */
	char name[DEFNAMEL]; /* argument name */
	short defined; /* TRUE if argument defined */
	short defsetH; /* handle on define set of argument */
	long defIndex; /* index within define set */
	long startOfLine; /* where arguments line started */
	long cI; /* index at end of name */
}; /* argdef */

struct arrows { /* keep all arrow status in one struct */
  Coord arrowx, arrowy; /* (author) display arrow here */
  int arrowendx, arrowbottom; /* bottom right of drawn text (including ok/no) */
  TRect arrowR; /* absolute arrow rectangle */
  short arrowFont; /* font arrow is writing in */
  TRect arrowLastR; /* for erasing last answer-contingent text */
  double arrowsizex, arrowsizey; /* -size- parameters */
  double RAngle; /* rotation angle */
  short arrowunit; /* unit in which active -arrow- resides */
  long arrowstack; /* relative stack position of arrow unit */
  unsigned short endarrowuloci, ifmatchuloci; /* initial settings of endarrow/ifmatch ulocs */
  unsigned short arrtopuloc, arrowuloc, ifmatchuloc; /* uloc of -arrow- and -ifmatch- */
  unsigned short endarrowuloc; /* uloc of -endarrow- */
  short iarrowunit, ijudgeunit; /* -iarrow- and -ijudge- units */
  short eraseuunit; /* -eraseu- unit */
  struct markvar SHUGE *jbuffer;	/* pointer to judge buffer marker */
  unsigned char Abuffer[ARROWLIMIT+1]; /* student/author judge buffers */
  short exdentunit; /* unit in which -answer- was found */
  unsigned short exdentuloc; /* end of -answer- indented code */
  long exdentstack;		/* relative stack position of exdent unit */
  short bestscore;  /* the score of the best match so far */
  struct sline *bestmatch; /* the best match so far */
/* save unit, string address, string length of best match */
  short bestunit, bestlength;
  unsigned char beststring[ARROWLIMIT]; /* best-match -answer- string */
  int bestspecsbits; /* specs at time of best match */

  int specsbits; /* set by -specs- */

  short zjudged; /* -1 ok, 0 wrong, 1 no, 2 unjudged */
  short judged; /* internal version of zjudged */
  short zanscnt; /* count of response-matching judging commands passed thru */
  short zcaps; /* -1 if no capitalization errors */
  short zentire; /* -1 if all required words present in response */
  short zextra; /* -1 if no extra words in response */
  short zntries; /* number of attempts at current arrow */
  short zopcnt; /* no. of math operators in response */
  short zvarcnt; /* no. of variables referenced in response */
  short zorder; /* -1 if word order correct */
  short zspell; /* -1 if spelling correct */
  short zwcount; /* no. of words in response, set by -answer- etc. */  

  Memh keyDoc;	/* document of user's typing */

  Memh aPanel;	/* text panel running arrow editing (on keyDoc) */
  struct tutorview FAR *aView;	/* view of aPanel */
  char arrowState; /* 0: not started, 1: normal input, 2: judging, 3: ok/no */
  char doNormalInput; /* special flag for handling enabled click outside arrow view */
  char resizing; /* flag indicating that we are resizing view for 1-point arrow */
  char ddzunused;
  int charH;	/* height of arrowFont (for resizing) */
  int charW;	/* maximum width of arrowFont (for resizing) */
  Memh lthand;	/* answer judging */
    
  long dummy; /* make sure stacking and unstacking aligned */
}; /* arrows */

/* structures for words and phrases in answer judging */
struct sword {
	unsigned char FAR *word ,FAR *goodspell;
	char gslen;
	int order,extra,spell,cap,res;
	int len;
	};
struct sline {
	int zcaps,zentire,zextra,zorder,zspell,zwcount,result,alen,authornum,manfound;
	struct sword FAR *wordarray;
	unsigned char *output_text;
	double score;
	};

struct anslist {
	unsigned char FAR *word;
	int len,type;
};

struct menutype {
  short card, item; /* menu card and menu item identifiers */
  short active; /* TRUE if item currently enabled */
  unsigned char string[MENUSLEN+1]; /* actual menu characters */
  char jump; /* TRUE if -jump- rather than -do- */
/* menu  string1~p1, string2~p2:unit */
/* p1 and p2 are optional priorities prefixed by tilde */
/* If no comma, 0--len1 is item title */
/* If comma, 0--len1 is card title, start2--len2 is item title */
/* p1start--p1len is ~p1, p2start--p2len is ~p2 */
/* len is total length including priorities and embedded spaces */
  short len, len1, p1start, p1len, p2start, p2len, start2, len2;
  short unit; /* number of unit to do */
  double param; /* parameter to pass to unit */
  };


/* handling indented structures in compiler */

#define nonekind 0
#define loopkind 1
#define ifkind 2
#define arrowkind 3
#define arrow0kind 4
#define anskind 5
#define casekind 6 
#define caseexprkind 7

struct indenter { /* keep track of loop, if, arrow, answer, case */
	char stype; /* one of the kinds above */
	char constf; /* all-constants flag for -case-  */
	short exprtype; /* TINT/TFLOAT/TMARK type for -case- */
	long headsource; /* location in source of /loop/if/arrow/.. */
	unsigned short headloc; /* location in binary of /loop/if/arrow/.. */
	short headref; /* index in reference table of loop/if/arrow */
	short lastif; /* cmd code of previous if/else/elseif */
	int nextlabel; /* internal label of next structure element */
	int endlabel; /* internal label of ending structure element */
	long machb; /* extra address for compiled code forms */
};

struct tevents {
  int key; /* CMU Tutor key value */
  int x, y; /* mouse x,y */
};

#endif /* _computeh */
