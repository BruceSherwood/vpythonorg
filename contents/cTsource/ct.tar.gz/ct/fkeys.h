
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* definitions for special keys.  Note that for the
	move insertion point keys and the function keys
	1 may be added to the value to indicate "extend selection" */

/* simple keys */
#define KTIMEUP 256
#define KNEXT 257
#define KBACK 258
#define KERASE 8
#define KCR NEWLINE
#define KALL 2048
#define KTOUCH 4096
#define KEXT 8192

/* extra keys */
#define KDEL 8
#define KFWDDEL 261
#define KTAB 9
#define KBACKTAB 262
#define KESCAPE 263
#define KHELP 264

/* function keys (assummed by newlex to be sequential) */
#define KFA 265
#define KFB 266
#define KFC 267
#define KFD 268

/* special editing keys */
#define KTRANSPOSE 269

/* move insertion point, or general move */
#define KLEFT 270
#define KRIGHT 272
#define KUP 274
#define KDOWN 276
#define KBEGLINE 278
#define KENDLINE 280
#define KBEGPAGE 282
#define KENDPAGE 284
#define KBEGFILE 286
#define KENDFILE 288
#define KPAGEUP 290
#define KPAGEDOWN 292

/* scrolling keys (don't move insertion point) */
#define KSBEGFILE 294
#define KSENDFILE 295
#define KSPAGEUP 296
#define KSPAGEDOWN 297

/* cut & paste keys */
#define KCUT 298
#define KCOPY 299
#define KPASTE 300
#define KUNDO 301

