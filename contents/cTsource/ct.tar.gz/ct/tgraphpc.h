
/* ******************************************************************* */

struct pccharl { /* large-format character definition */
    unsigned int map;   /* displacement to bit map for this char */
    int pdx,pdy;    /* pen x,y increment */
    int bndx,bndy;  /* displacement from pen to top,left of char bounding box */
    int bnw;        /* width  of char bounding box */
    int bnh;        /* height of char bounding box */
    int mapdx,mapdy;    /* displacement from top,left of bounding box */
            /* to top,left of character bit map */
    int mapw;       /* width  of character bit map */
    int maph;       /* height of character bit map */
}; /* pccharl */

struct pcchars { /* small-format character definition */
    unsigned int map;   /* displacement to bit map for this char */
    char pdx,pdy;   /* pen x,y increment */
    char bndx,bndy; /* displacement from pen to top,left of char bounding box */
    unsigned char bnw;  /* width  of char bounding box */
    unsigned char bnh;  /* height of char bounding box */
    char mapdx,mapdy;   /* displacement from top,left of bounding box */
            /* to top,left of character bit map */
    unsigned char mapw; /* width  of character bit map */
    unsigned char maph; /* height of character bit map */
}; /* pcchars */

struct pcfont { /* font definition */
    char family[20];        /* family name */
    unsigned char size;     /* font size */
    unsigned char dstyle;   /* font design styles */
                /* least sig bit = bold */
                     /* next = italic */
                     /* next = underline */
    unsigned char astyle;   /* algorithmically generated styles */
                /* least sig bit = bold */
                     /* next = italic */
                     /* next = underline */
    unsigned char format;   /* least sig bit = char definition type */
                        /* 0 = small-format char defs */
                        /* 1 = large-format char defs */
                     /* next = font type */
                        /* 0 = characters */
                        /* 1 = icons */
    int newline;    /* newline height */
    int maxwidth;   /* maximum character width */
    int ascent;     /* ascent  for all characters in font */
    int descent;    /* descent for all characters in font */
    unsigned char first;    /* first character in font */
    unsigned char nchars;   /* number characters in font */
    unsigned int ddef;      /* displacement to char definitions within font */
    unsigned int dmap;      /* displacement to bit-maps within font */
    unsigned char far *rdef;    /* pointer to char defs in memory */
    unsigned char far *rmap;    /* pointer to bit-maps in memory */
}; /* pcfont */

/* ******************************************************************* */

struct videoid {
    unsigned char subsystem0;
    unsigned char display0;
    unsigned char subsystem1;
    unsigned char display1;
}; /* videoid */

/* ******************************************************************* */

#define SR_MAXP 22 /* maximum number pieces */

struct saved_region { /* saved region info */
    int width; /* width of region */
    int height; /* height of region */
    int offsetX, offsetY; /* the offset from get origin to image */
    int yinc; /* y increment within chunk */
    Memh ids[SR_MAXP]; /* handles on saved chunks */
}; /* saved_region */

/* ******************************************************************* */

extern char pc2ct[]; /* pc->ct keyboard/file conversion table */
extern char ct2pc[]; /* ct->pc file conversion table */

/* ******************************************************************* */
