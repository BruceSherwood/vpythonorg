
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University. */

#include "execdefs.h"
#include "eglobals.h"
#include "tglobals.h"
#include "txt.h" 
#include "exprdefs.h"
#include "yacc.h"
#include "fkeys.h" 
#include "editor.h"
#include "txtv.h" 
#include "ct_ctype.h"
#include "tfiledef.h"
#include "kglobals.h"
#include "commands.h"

/* ******************************************************************* */

#ifdef ctproto
double combinatorial(long av,long bv);
double factorial(int aa);
extern int ex_zcomb(void);
extern int ex_zfactorial(void);
extern int zsearch_icons(struct markvar SHUGE *target,struct markvar SHUGE *region);
static int compare_icons(Memh doc1,long pos1,Memh doc2,long pos2);
int  lclocy(long  q);
int  lclocx(long  q);
extern int  _TUTORwhere_pos_tview(struct  _viewp FAR *tvp,struct  _tpoint where,struct  _ps FAR *post,struct  _ps *wordE,int  byWord,int  *inHot,int *onChar);
static icon_lookup(struct markvar SHUGE *mx,long iconIndex,long *nret,
                   long *ixret,char *fxret); 
int  TUTORfind_stext(struct  _spt2 FAR *stp,long  pos);
long TUTORinq_symbolic_font_id(char  *fontName);
int  TUTORget_default_styles_doc(unsigned int  doc,short  FAR *defStyles);
int ex_znicons(void);
int ex_zhasstyle(void);
int ex_ziconcode(void);
int ex_ziconfile(void);
int  tdoc_getstyles(unsigned int  theD,long  pos,short  *styles);
int  GraphScale(long  fnx,long  fny,double  *cx,double  *cy);
int  RelativeScale(long  fnx,long  fny,double  *cx,double  *cy);
int  ex_cotofn(void);
int  ex_tsysvar(void);
int  exs_tsysvar(void);
int get_edit_ref(Memh eH);
int get_button_ref(Memh bH);
int get_slider_ref(Memh sH);
extern int uplow(char FAR *str);
int ex_zfilepath(void);
int xfilenm(int type);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
int ex_zlengthf(void);
int  mvar_zero(struct  markvar SHUGE *mp);
int  GetUnitName(int  unitn,unsigned char  *name);
long  lcbitcnt(long  av);
int  ex_gamma(void);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int ex_zfilename(void);
int  ex_znextword(void);
int ex_znextline(void);
int mvar_next_item(int type);
extern long TUTORsearch_doc();
long  _TUTORsearch_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sGood,long  sLen,unsigned int  strSpecial,long  strSOff,long  pos,long  posEnd,unsigned char  FAR *cTable);
int  ex_zsearch(void);
extern int dynerr(void);
extern long dyn_array_index(long idescp);
extern long dyn_array_lth(long FAR *ptr);
extern int gdy_array_inf(void);
extern int ldy_array_inf(void);
extern int pdy_array_inf(void);
extern int exs_gdyarray(void);
extern int exs_ldyarray(void);
int  set_exec_pt(unsigned int  uloc);
long  get_exec_pt(void);
int  ex_arrayerr(void);
long  l_bin(void);
double  f_bin(void);
long  l_read(char  FAR *addr);
double  f_read(char  FAR *addr);
int  n_follow(int  branchtype);
extern int  mvar_stack(long  addr);
int  mvar_init(struct  markvar SHUGE *mp);
int  mvar_assign(struct markvar SHUGE  *vaddr,struct  markvar SHUGE *mx);
int  mvar_compare(struct  markvar SHUGE *ma,struct  markvar SHUGE *mb,int  exact);
int  ex_nofun(void);
double  lcfexpon(double  y,double  x);
long  lcbitcnt(long  av);
long  IntToCoord(int  xx);
int  RoundCoord(long  xx);
int  GraphScale(long  fnx,long  fny,double  *cx,double  *cy);
int  RelativeScale(long  fnx,long  fny,double  *cx,double  *cy);
int  TUTORdump(char  *s);
int  TUTORtrace(char  *s);
int  flush(void);
int  TUTORforce_redraw(int  wix);
int  TUTORflush(void);
int  ReleaseStack(void);
int  mvar_temp_cleanup(void);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  InsureUnit(int  unitn);
unsigned char  SHUGE *LockStack(void);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
long  FloatToCoord(double  zz);
int  execerr(char  *msgstr);
int  matherror(int  errnum,char  *s);
int  MatchUnitName(unsigned char  *name);
long  lcftoi(double  dv);
double  lcitof(long  iv);
extern double floor(double x);
extern double atan2(double x, double y);
extern double atan(double x);
extern double log10(double x);
extern double sqrt(double x);
int  fuzzyeq(double  x,double  y);
extern double acos(double x);
extern double fabs(double x);
extern double asin(double x);
extern double cos(double x);
extern double sin(double x);
extern double tan(double x);
extern double tanh(double x);
extern double cosh(double x);
extern double sinh(double x);
extern double pow(double x,double y);
extern double exp(double x);
extern double log(double x);
int  mvar_get_inf(unsigned int  docH,long  *len,long *users,long  *head);
int  TUTORinsert_string_doc(unsigned int  doc,long  pos,unsigned char  FAR *ss,long  sLen);
int  scoderr(void);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
unsigned int  mvar_new(int  ref);
long  _TUTORsearch_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sGood,long  sLen,unsigned int  strSpecial,long  strSOff,long  pos,long  posEnd,unsigned char  FAR *cTable);
int  _TUTORload_buffer_doc(struct  _ktd FAR *dp,long  pos);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
char  FAR *GetPtr(unsigned int  mm);
int  _TUTORinfo_vbar_tview(struct  _viewp FAR *tvp,struct  _sbarinf *vb);
int  TUTORinq_select_tview(unsigned int  theV,long  *pos,long  *len);
int  TUTORdealloc(char  FAR *ptr);
int  strlenf(char  FAR *aa);
char  FAR *CTzks(int  code,char  *tempS);
double  TUTORinq_slider_value(unsigned int  sbi);
unsigned char  FAR *GetHotstringTStyle(unsigned int  pd,int  id,long  *len,long  *spos,long  *slen,int  getS);
int  TUTORtrace_n(char  *s,long  nn);
double  CoordToFloat(long  xx);
long  TUTORinq_msec_clock(void);
int  GetUnitName(int  unitn,unsigned char  *name);
extern char *TUTORgetenv(char *varname);
double  MovieGetTime(void);
int  TUTORget_colors(struct tutorColor *fcx,struct tutorColor *bcx,struct tutorColor *wcx);
int  CTcount_colors(int  oldF);
int  TUTORshowt(double  value,int  nBefore,int  nAfter,int  showperiod,char  *s);
int  TUTORshow(int type,double  value,int  sigfig,char  *ss);
int  mvar_attach_doc(struct  markvar SHUGE *mvarP,unsigned int  docH,unsigned char  SHUGE *stackP);
int  mvar_detach_doc(struct  markvar SHUGE *mvarP,unsigned int  docH,unsigned char  SHUGE *stackP);
extern int TUTORzero(char SHUGE *ptr,long lth);
int  TUTORfree_handle(unsigned int  mm);
int  _TUTORcmp_doc(struct  _ktd FAR *dp,long  pos0,long  dLen0,long  *docUsed,unsigned char  FAR *ss,long  ssGood,long  *cLen0,unsigned int  strSpecial,long  strSOff,unsigned char  FAR *cTable,int  exactF);
extern int ex_ztextat(void);
extern int ex_zeditbase(void);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
#ifndef THINKC5
#ifndef WERKS
extern int sprintf(char *ss, char *form,...);
extern int printf(char *form,...);
#endif
#endif
extern int MacFilePath(FileRef *fRef,char *str,int len);
extern long Mac_Zncolors(void);
#endif

#ifndef __MC68K__
double  gamma(double  a);
#endif

#ifndef WERKS
extern double atan2();
extern double sin(), cos(), tan(), asin(), acos(), atan();
extern double fabs(), sqrt(), exp(), pow(), log10(), log();
extern double alog(), sinh(), cosh(), tanh();
#endif

double combinatorial();
double factorial();
extern  long lcbitcnt();
extern long l_bin();
extern long l_read();
extern double f_bin();
extern double f_read();
extern long array_index();
extern long pass_addr();
extern Coord IntToCoord();
extern Coord FloatToCoord();
extern long array_index();
extern long lcftoi();
extern double lcitof();
extern double floor();
extern  double lcfexpon();
extern double atan();
extern double fabs();
extern Memh mvar_new();
extern unsigned char FAR *GetHotstringTStyle();
extern char FAR *TUTORalloc();
extern double CoordToFloat();
extern int TUTORcharat_doc();
extern double TUTORinq_slider_value();
extern double MovieGetTime();


/* ******************************************************************* */

#ifndef long_align
#define long_bin (*((long FAR *)(ex_binP)))
#define long_read(addr) (*(long SHUGE *)(addr))
#define flt_bin (*((double FAR *)(ex_binP)))
#define flt_read(addr) (*(double SHUGE *)(addr))
#else
#define long_bin (l_bin())
#define long_read(addr) (l_read(addr))
#define flt_bin (f_bin())
#define flt_read(addr) (f_read(addr))
#endif

#define IHUGE 0x7fffffff
#define abstolerance 0.000000001
#define reltolerance 0.00000000001
#define onep 1.0

extern int logcmd;

/* ------------------------------------------------------------------- */

ex_zhasstyle() /* check if marker has specified style */

{   struct markvar SHUGE *mx;
    long styleType; /* type of style to ask about */
    int retv; /* cT TRUE/FALSE return */
    int ccode; /* current character code */
    int isStyled; /* TRUE if document has styles */
    short styles[NSTYLES]; 
    short defStyles[NSTYLES]; /* default styles for document */
    int allmatch; /* TRUE if all styles match default */
    int plainF; /* TRUE if looking for plain text */
    long fontV; /* font we're checking for */
    int ii,si;

    retv = 0; /* pre-set cT FALSE */
    mx = --markP;
    styleType = *(--iresP);
    if (styleType == KW_ICON) {
        for(ii=0; ii<markP->len; ii++) {
            ccode = TUTORcharat_doc(markP->doc,markP->pos+ii);
            if (ccode == ICONSPECIAL) { 
                retv = -1; /* found an icon */
                break; /* no need to search further */
            } /* ccode if */
        } /* for */
    } else {
        if ((styleType == KW_PLAIN) || (styleType == KW_PLAINEST)) {
            plainF = TRUE;
            TUTORget_default_styles_doc(markP->doc,(short  FAR *)&defStyles[0]);
        } else plainF = FALSE;
        
        for(ii=0; ii<markP->len; ii++) {
        	for(si=0; si<NSTYLES; si++) styles[si] = 0;
            isStyled = tdoc_getstyles(markP->doc,markP->pos+ii,&styles[0]);
            if (!isStyled) {
                if (plainF) 
                    retv = -1; /* found plain text */
            }
            
            switch (styleType) {
            case KW_PLAIN: 
            case KW_PLAINEST:
                allmatch = TRUE; /* pre-set all styles match */
                for(si=0; si<NSTYLES; si++) {
                    if (!((styleType == KW_PLAIN) && 
                         ((si == FONTSTYLE) || (si == SIZESTYLE)))) {
                        if (styles[si] != defStyles[si])
                            allmatch = FALSE; /* something differs */
                    }
                } /* si for */
                if (allmatch) 
                    retv = -1; /* found plain text */
                break; 
            case KW_BOLD:
                if (styles[FACESTYLE] & style_bold)
                    retv = -1;
                break;  
            case KW_ITALIC:
                if (styles[FACESTYLE] & style_italic)
                    retv = -1;
                break;
            case KW_HOTSTYLE:
                if (styles[HOTSTYLE] && (styles[HOTSTYLE] != DEFSTYLE))
                    retv = -1;
                break;
            case KW_SUPSCRIPT:
                if (styles[FACESTYLE] & SUPERSTYLE)
                    retv = -1;
                break;
            case KW_SUBSCRIPT:
                if (styles[FACESTYLE] & SUBSTYLE)
                    retv = -1;
                break;
            case KW_FULLJUST:
                if (styles[PARASTYLE] & FULLJUST)
                    retv = -1;
                break;
            case KW_LEFTJUST:
                if (styles[PARASTYLE] & RIGHTJUST)
                    retv = -1;
                break;
            case KW_CENTER:
                if (styles[PARASTYLE] & CENTERJUST)
                    retv = -1;
                break;
            case KW_BLACK:
                if ((styles[COLORSTYLE] == 0) || (styles[COLORSTYLE] == DEFSTYLE))
                    retv = -1;
                break;
            case KW_WHITE:
            case KW_RED:
            case KW_GREEN:
            case KW_BLUE:
            case KW_YELLOW:
            case KW_CYAN:
            case KW_MAGENTA:
                if (styles[COLORSTYLE] == (styleType-KW_BLACK))
                    retv = -1;      
                break;
            case KW_BIGGER:
                if (styles[SIZESTYLE] > 0)
                    retv = -1;
                break;
            case KW_SMALLER:
                if (styles[SIZESTYLE] < 0)
                    retv = -1;
                break;
            case KW_SERIF:
                fontV = TUTORinq_symbolic_font_id("zserif");
                if (styles[FONTSTYLE] == fontV)
                    retv = -1;
                break;
            case KW_SANS:
                fontV = TUTORinq_symbolic_font_id("zsans");
                if (styles[FONTSTYLE] == fontV)
                    retv = -1;
                break;
            case KW_TYPEWRITER:
                fontV = TUTORinq_symbolic_font_id("zfixed");
                if (styles[FONTSTYLE] == fontV)
                    retv = -1;
                break;
            case KW_SYMBOL:
                fontV = TUTORinq_symbolic_font_id("zsymbol");
                if (styles[FONTSTYLE] == (int)fontV)
                    retv = -1;
                break;
            } /* switch */
        
            if (retv)
                break; /* exit for, found a match */
                
        } /* for */
    
    } /* else */
    *iresP++ = retv;
    
} /* ex_zhasstyle */

/* ------------------------------------------------------------------- */

ex_znicons() /* return number icons in marker */

{   struct markvar SHUGE *mx;
    long nIcons;

    mx = --markP;
    icon_lookup(mx,-1,&nIcons,NEARNULL,NEARNULL);
    *iresP++ = nIcons;
    
} /* ex_znicons */

/* ------------------------------------------------------------------- */

ex_ziconcode() /* return icon numbers from marker */

{   struct markvar SHUGE *mx;
    long iconIndex; /* index of icon to look up */
    long iconN; /* icon code */

    mx = --markP;
    iconIndex = *(--iresP);
    icon_lookup(mx,iconIndex,NEARNULL,&iconN,NEARNULL);
    if (iconN < 0)
        execerr("icon index out of range");
    *iresP++ = iconN;
    
} /* ex_ziconcode */

/* ------------------------------------------------------------------- */

ex_ziconfile()

{   struct markvar SHUGE *mx;
    long iconIndex; /* index of icon to look up */
    long iconN; /* icon code */
    int slen; /* length of file name string */
    char fname[CTPATHLEN]; /* file name string */

    mx = --markP;
    iconIndex = *(--iresP);
    icon_lookup(mx,iconIndex,NEARNULL,&iconN,fname);
    if (iconN < 0)
        execerr("icon index out of range");
    
    /* build marker containing icon file name */
    
    mvar_init(markP); /* initialize new temp marker */
    slen = strlen(fname);
#ifdef IBMPC
    uplow((char FAR *)&fname[0]); /* convert to lower case */
#endif
    InsertString(markP->doc,0L,(char FAR *)&fname[0],(long)slen);
    markP->pos = 0; /* wrap marker around string */
    markP->len = markP->doclen = slen;
    markP++; /* advance marker stack */
    
} /* ex_ziconfile */

/* ------------------------------------------------------------------- */

int zsearch_icons(target,region)
struct markvar SHUGE *target; /* target marker */
struct markvar SHUGE *region; /* region marker */

{	struct markvar result; /* resulting marker */
	long rii; /* index in region */
	long tii; /* index in target */
	int firstC; /* first character to look for */
	int curCode,curTarget; /* current characters */
	
    result = *region;
    result.pos = result.len = 0; /* set up empty marker */
    firstC = TUTORcharat_doc(target->doc,target->pos); /* first target char */
    
    for(rii=0; rii<region->len; rii++) {
       	curCode = TUTORcharat_doc(region->doc,region->pos+rii);
       	if (curCode == firstC) {
       		for(tii=0; tii<target->len; tii++) {
       			if ((rii+tii) >= region->len)
       				break; /* beyond end of region */
       			curCode = TUTORcharat_doc(region->doc,region->pos+rii+tii);
       			curTarget = TUTORcharat_doc(target->doc,target->pos+tii);
       			if (curCode != curTarget)
       				break; /* failed, exit tii for */
       			if (curCode == ICONSPECIAL) {
       			
       				/* compare icon strings */
       				
       				if (!compare_icons(region->doc,rii+tii,target->doc,tii))
       					break; /* failed, exit tii for */
       			}
       			if (tii == (target->len-1)) { /* last char ok */
       				result.pos = rii;
       				result.len = target->len;
       				*markP++ = result;
       				return(0); /* exit happy */
       			}
       		} /* tii for */
       	} /* curCode if */
    } /* rii for */
    
    *(markP++) = result; /* return zero-lth marker for failure */
    return(0);
    
} /* zsearch_icons */

/* ------------------------------------------------------------------- */

static int compare_icons(doc1,pos1,doc2,pos2) 
Memh doc1; /* handle on first document */
long pos1; /* position in first document */
Memh doc2; /* handle on second document */
long pos2; /* position in second document */

{	DocP dp1; /* pointer to 1st document */
	DocP dp2; /* pointer to 2nd document */
	SpecialTP stp1; /* pointer to 1st special text table */
	SpecialTP stp2; /* pointer to 2nd special text table */
	int stextN1; /* index in 1st special text table */
	int stextN2; /* index in 2nd special text table */
	Memh iconH1; /* handle on 1st icon data block */
	Memh iconH2; /* handle on 2nd icon data block */
	int FAR *iconP1; /* pointer to 1st icon block */
	int FAR *iconP2; /* pointer to 2nd icon block */
	int numIcons; /* number icons in icon block */
	int iconI; /* index in icons */
	int match;
	
	match = FALSE; /* no match yet */
	iconH1 = HNULL;
	
    dp1 = (DocP)GetPtr(doc1);
    dp2 = (DocP)GetPtr(doc2);
    if ((!dp1->specialT) || (!dp2->specialT)) {
    	ReleasePtr(doc1);
    	ReleasePtr(doc2);
    	return(FALSE);
    }
  
    stp1 = (SpecialTP)GetPtr(dp1->specialT); /* pointer to stext table */
    stextN1 = TUTORfind_stext(stp1,pos1); /* index in stext table */
    stp2 = (SpecialTP)GetPtr(dp2->specialT);
    stextN2 = TUTORfind_stext(stp2,pos2);
	if ((stextN1 < 0) || (stextN2 < 0))
		goto exit;
		
	iconH1 = stp1->text[stextN1].dat;
	iconP1 = (int FAR *)GetPtr(iconH1);
	iconH2 = stp2->text[stextN2].dat;
	iconP2 = (int FAR *)GetPtr(iconH2);
	if (*iconP1 != *iconP2)
		goto exit; /* not same number of icons */
	numIcons = (*iconP1)+1; /* compare icons + font id */
	for(iconI=0; iconI<numIcons; iconI++) {
		if (*iconP1 != *iconP2)
			goto exit; /* didn't match */
		iconP1++;
		iconP2++;
	}
	match = TRUE;
	
exit:
	ReleasePtr(dp1->specialT);
	ReleasePtr(dp2->specialT);
	ReleasePtr(doc1);
	ReleasePtr(doc2);
	if (iconH1) {
		ReleasePtr(iconH1);
		ReleasePtr(iconH2);
	}
	return(match);

} /* compare_icons */	
   
/* ------------------------------------------------------------------- */

static icon_lookup(mx,iconIndex,nret,ixret,fxret) /* look up icon information */
struct markvar SHUGE *mx; /* marker in which to look for icons */
long iconIndex; /* index of icon to look up */
long *nret; /* returned with number icons in marker */
long *ixret; /* returned with icon number */
char *fxret; /* returned with font name */

{   long numIcons; /* number of icons in this bunch */
    long indexBase; /* starting ordinal for current bunch of icons */
    long iconN; /* icon number */
    long iconCount; /* count of icons found */
    long fontIndex; /* index of font */
    int ccode; /* current character code */
    DocP dp; /* pointer to document */
    SpecialTP stp; /* pointer to special text table */
    int stextN; /* index in special text table */
    Memh iconH; /* handle on icons info */
    int FAR *iconDatP; /* pointer to icon data */
    char FAR *fnameP; /* pointer to icon file name */
    int ii;

    iconN = fontIndex = -1; /* haven't looked up icon yet */
    iconCount = 0; /* haven't found any icons yet */
    indexBase = 1;
    for(ii=0; ii<markP->len; ii++) {
        ccode = TUTORcharat_doc(markP->doc,markP->pos+ii);
        if (ccode == ICONSPECIAL) { 
            dp = (DocP)GetPtr(markP->doc);
            if (dp->specialT) {
                stp = (SpecialTP)GetPtr(dp->specialT);
                stextN = TUTORfind_stext(stp,markP->pos+ii);
                if (stextN >= 0) {
                    iconH = stp->text[stextN].dat;
                    iconDatP = (int FAR *)GetPtr(iconH); /* point to icon data */
                    numIcons = *(unsigned int FAR *)iconDatP; /* get number entries */
                    iconCount += numIcons; /* keep count of total found */
                    if ((iconIndex >= indexBase) && (iconIndex < (indexBase+numIcons))) {
                        iconN = *(unsigned int FAR *)(iconDatP+(iconIndex-indexBase)+1);
                        fnameP = (char FAR *)(iconDatP+numIcons+2);
                        if (fxret)
                            strcpyf((char FAR *)fxret,fnameP);
                    }
                    indexBase += numIcons; /* advance for icons in this set */
                    ReleasePtr(iconH);
                    KillPtr(iconDatP);
                } /* stextN if */
                ReleasePtr(dp->specialT);
                KillPtr(stp);
            }
            ReleasePtr(markP->doc);
            KillPtr(dp);
        } /* ccode if */
        if ((iconN >= 0) && (nret == NEARNULL))
            break; /* exit if found our icon */
    } /* for */
    
    if (nret)
        *nret = iconCount;
    if (ixret)
        *ixret = iconN;
        
} /* icon_lookup */

/* ------------------------------------------------------------------- */

ex_ztextat() /* return marker corresponding to x,y position */

{   int ix,iy,xx,yy; /* x,y position */
    Memh hdrH; /* handle on object header */
    struct ebshdr FAR *hdrP; /* pointer to object header */
    Memh tpanel; /* handle on text panel */
    TextVDat FAR *tpp; /* pointer to text panel */
    TViewP tvp; /* pointer to TextView */
    struct markvar result; /* result marker */
    DocP dp; /* pointer to document */
    TPoint where; /* x,y position, in local coordinates */
    Position txtLoc; /* location in text */
    int onChar;
    
    /* pick up x,y location */
    
    iy = *(--iresP);
    ix = *(--iresP);
    xx = lclocx(IntToCoord(ix));
    yy = lclocy(IntToCoord(iy));
    
    /* find position in text panel */
    
    tpanel = 0; /* no handle on panel yet */
    hdrH = *(--iresP); /* get handle on object header */
    if (hdrH) {
        hdrP = (struct ebshdr FAR *)GetPtr(hdrH);
        tpanel = hdrP->objectH; /* get handle on text panel */
        ReleasePtr(hdrH);
        KillPtr(hdrP);
    } /* hdrH if */
    
    mvar_zero((struct markvar SHUGE *) &result); /* clear result */
    
    if (tpanel == 0) {
        /* no text panel, result is zempty */
        ;
    } else {
        /* construct marker on edit document */
        tpp = (TextVDat FAR *) GetPtr(tpanel);
        tvp = (TViewP) GetPtr(tpp->textv);
        result.doc = tvp->doc;
        result.doclen = tvp->bounds.doclen;
        if (xx < tpp->view->rr.left) xx = tpp->view->rr.left;
        if (xx > tpp->view->rr.right) xx = tpp->view->rr.right;
        if (yy < tpp->view->rr.top) yy = tpp->view->rr.top;
        if (yy > tpp->view->rr.bottom) yy = tpp->view->rr.bottom;
        where.hh = xx;
        where.vv = yy;
        _TUTORwhere_pos_tview(tvp,where,(Position FAR *) &txtLoc,NEARNULL,FALSE,NEARNULL,&onChar);
         result.pos = txtLoc.pos;
         result.len = 1; 
         if ((onChar == -2) || (onChar == 2))
         	result.len = 0; /* before or after entire line */
         if (onChar == -1) { /* click before position returned */
 			result.pos -= 1; /* back up to character */
 			if (result.pos < 0) result.pos = 0;
 		}
        
        dp = (DocP)GetPtr(tpp->textd); /* get document */
        if (result.pos+result.len > dp->totLen) {
            /* check if beyond document bounds (selection deleted) */
            result.pos = dp->totLen; /* zero length, at end */
            result.len = 0;
        }
        ReleasePtr(tpp->textd);
        ReleasePtr(tpp->textv);
        ReleasePtr(tpanel);
    } /* tpanel else */

    if (result.doc == HNULL) /* no result */
        mvar_init((struct markvar SHUGE *)&result);
        
    *(markP++) = result;
    return(0);
    
} /* ex_ztextat */

/* ------------------------------------------------------------------- */

ex_zcomb() /* combinatorial */

{	long aa,bb;

	bb = *(--iresP);
	aa = *(--iresP);
	if (aa < 0 | bb < 0) 
		matherror(USERERR,"Combinatorial arguments must be positive.");

	*fresP++ = combinatorial(aa,bb);
	
} /* ex_zcomb */

/* ------------------------------------------------------------------- */

ex_zfactorial() /* factorial */

{   long aa;

	aa = *(--iresP);
	if (aa < 0) 
		matherror(USERERR,"Factorial argument must be positive.");
	if (aa > 1755) {
		*fresP++ = Infinite;
		return;
	}
	*fresP++ = factorial((int)aa);
	
} /* ex_zfactorial */

/* ******************************************************************* */

double combinatorial(av,bv)          /* floating combinatorial */
long av,bv;

{
	long cv,t2,t3,nn;
	double num,den,onum,oden;
	/* (av bv): number of ways of arranging av things taken bv at a time; av!/[bv!(av-bv)!] */

	cv = av-bv;
	den = num = 1.0;
	t2 = bv;
	t3 = cv;
	if (bv >= cv) {
		t2 = cv;
		t3 = bv;
	}
	for (nn = t3+1; nn <= av; nn++) {
		onum = num;
		num = num*(double)nn; 
		if ((num == Infinite) || (num < onum))
			return(Infinite);
	}
	for (nn = 2; nn <= t2; nn++) {
		oden = den;
		den = den*(double)nn; 
		if ((den == Infinite) || (den < oden))
			return(Infinite);
	}
    return(num/den);

} /* combinatorial */

/* ******************************************************************* */

double factorial(av)                /* floating factorial */
int av;

{
	int nn;
	double fact;
		
	fact = 1.0;
	for (nn = 2; nn <= av; nn++) fact = fact*(double)nn; 
    return(fact);

} /* factorial */

/* ******************************************************************* */
