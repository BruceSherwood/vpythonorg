
/* definitions for cT help and dictionary */

#define SINGLECLICK

typedef struct _ed
    {
    long textStart, textLen;
    int type; /* node or leaf (0: index, 1: body) */
    } Entry;

#ifdef MAC
#define HELPSIZE 13
#else
#define HELPSIZE 16 
#endif

/* defines for page layout */
/* LISTV and LISTH are height and width (without scroll bar) of list view */
#define LISTH 150
/* BANNERV is the height of the banner over the index view */
#define BANNERV 20

#define ENCODE

#define HELPNAME "cthelp"
#define HELPNAMES "cthelp.sml"

#define MAXENTRIES 400 /* was 350 until 97/05/22 */
#define MAXCOMMANDS 900 /* 750 until 97/05/22 */
#define MAXSUBS 30

#define TITLELEN 59

typedef struct _hinf
    {
    int wid; /* window index */
    long wp; /* pointer to window */
    struct tutorview FAR *helpV; /* help window background view */
    Memh indexh;    /* text panel for index */
    Memh listH;     /* text panel for keyword list */
    Memh bodyh;     /* text panel for body */
    struct tutorview FAR *indexV, FAR *listV, FAR *bodyV; /* views */
    Memh indexSh, listSh, bodySh;   /* handles of scroll bars */
    Memh listDocH; /* handle on keyword list document */
    Memh indexDocH; /* handle on index document */
    Memh bodyDocH; /* handle on main-body document */
    struct tutorview FAR *curActive; /* currently active text view */
    int listVSize; /* vertical size of list */
    short indexMid, listMid;
    char indexT[TITLELEN+1];
    int nEntries, nCommands;
    Entry entries[MAXENTRIES];
    int commands[MAXCOMMANDS];
    int indexNums[MAXSUBS];     /* entry # for children (& parent) of current node */
    int nCurEntries;
    long cStart, cLen; /* bounds of commands (list) text */
    FileRef helpFile;
    short curBody, curIndex;
    long boldIndexS, boldIndexL; /* bounds of index bolding */
    long boldListS, boldListL; /* bounds of list bolding */
    short titleF; /* font for index title */
    Memh searchKeyTxtH; /* handle on list body */
    long searchKeyTime; /* time of last key for list-panel search */
    long searchKeyPos; /* position of last find for list-panel search */
    int nSearchKeys; /* number of codes in search target */
    int nSearchFind; /* number of chars matched in search target */
    char searchKeys[5]; /* search target */
    } HelpDat;

#define DICTITEML 32    /* max length of dictionary item */
#define NDICTMENU 20    /* max number dictionary menu items */

typedef struct _dictdat
    {
    int wid; /* window index */
    Memh tPanel;
    Memh textd;
    Memh textv;
    struct tutorview FAR *view;
    } DictData;

