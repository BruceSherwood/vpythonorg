
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* header file for the use of the tgraph modules */
/* variables which are used only in the tgraph modules are all defined in ctgraph.c */

#ifndef _tgraphh
#define _tgraphh

#include "baseenv.h"

/* ******************************************************************* */


/* ******************************************************************* */


#endif
