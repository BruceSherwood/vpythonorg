
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Routines associated with authoring.
*/

/* ******************************************************************* */

#include <stdio.h>
#include "baseenv.h"
#include "tutor.h"
#ifdef ANDREW
/* #include <sys/file.h> */
#endif
#include "tglobals.h"
#include "edglobal.h"
#include "ecglobal.h"

#include "editor.h"
#include "txt.h"
#include "txtv.h"
#include "compute.h"
#include "commands.h"

/* ******************************************************************* */

#ifdef ctproto
extern int procDebug(Memh selectH, struct tutorevent *cev);
int  TUTORchange_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,unsigned char  FAR *cp,long  cLen,long  fromOff,unsigned int  styles,unsigned int  specialT,long  *extraPos,int  eupFlag);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,
 unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
int  TUTORclose_view(struct  tutorview FAR *vp);
extern Memh mvar_new(int ref);
int  CommentOut(struct  _tvdat FAR *vp,long  pos,long  len);
int  IndentOn(struct  _tvdat FAR *vp,long  pos,long  len);
int  IndentOff(struct  _tvdat FAR *vp,long  pos,long  len,int  charOut);
int  HideUnits(struct  _tvdat FAR *vp,long  pos,long  len, int all);
int  ShowAllUnits(struct  _tvdat FAR *vp);
int  ShowUnits(struct  _tvdat FAR *vp,long  pos,long  len);
int  LocateUnit(Memh docH,long  pos);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORsave_do_doc(unsigned int  doc,long  pos,long  len,int  op,long  newLen);
int  RefreshPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  cpos,long  clen,long  newC,long  selStart,long  selLen,int  scroll,int force);
int  getrealcommand(void);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
int  SkipLine(void);
int  TUTORinsert_string_doc(unsigned int  doc,long  pos,unsigned char  FAR *ss,long  sLen);
long  TUTORsearch_string_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sLen,long  pos,long  posEnd);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORstyle_doc(unsigned int  doc,long  pos,long  len,int  type,int  dat,int  canCombine,long  *extraPos);
int  Seek(char  *ss,unsigned int  dd,long  start,long  *found);
int  _TUTORinq_state_internal_marker(int  ind,long  *pos,long  *len,int  *altered);
int  TUTORnormal_cursor(void);
int  FindUnits(void);
int  TUTORwait_cursor(void);
int  TUTORdelete_doc(unsigned int  doc,long  pos,long  len,long  *extraPos);
int  SetSelectPanel(struct  _tvdat FAR *vp,long  pos,long  len);
#endif /* ctproto */

#ifdef macproto
#ifndef THINKC5
#ifndef WERKS
extern  int sprintf(char *, char *, ...);
#endif
#endif
#endif

extern char FAR *GetPtr();
extern char *machinename();
extern char FAR *ReadFileKView();
long TUTORwrite(), TUTORread();
long TUTORinq_file_pos();
char *strf2n();
long TUTORget_len_doc();
extern long TUTORsearch_string_doc();

#ifdef ANDREW
extern long getpid();
#endif

char *nxtkword();	

/* ******************************************************************* */

#ifdef NOSUCH 

static Memh SelectDocH = HNULL; /* handle on run-select display doc */
static Memh SelectPanelH = HNULL; /* run-select display text panel */

/* ******************************************************************* */

int RunSelectDisplay() /* generate display to select program to execute  */

{   int eii; /* index in editors */
    Memh editH; /* handle on edit data */
    struct  _edat FAR *ep; /* pointer to edit data */
    struct  _tvdat FAR *vp; /* pointer to textpanel data */
	int nLines; /* number lines in select display */
	int nChars; /* number characters in select display */
    
	nLines = nChars = 0;
    for(eii=0; eii<EDITWINDOWLIMIT; eii++) {
        if (EditWn[eii]) { /* found an editor window */
            editH = windowsP[EditWn[eii]].wH;
            if (editH) {
                ep = (EditDat FAR *) GetPtr(editH);
				nLines++;
				nChars += strlenf(ep->filename);   
                ReleasePtr(editH);
            } /* editH if */
        }
    } /* for */

	return(0);
    
} /* RunSelectDisplay */

/* ******************************************************************* */

static int RunSelectOpenWindow()

{	struct tutorview FAR *cv; /* current view */
	int info; /* edit panel setup */
	TextVDat FAR *vp; /* text panel info */
		
	cv = TUTORinq_view(); /* remember current view */
	if (SelectVp)
		TUTORclose_view(SelectVp); /* close select window if already open */

	/* create select window */
	
	TUTORset_view(FARNULL); /* save current view */
	SelectWn = TUTORcreate_window(-1,-1,0,0,SELECTW);
	if (SelectWn < 0) 
    	goto rview;
	windowsP[SelectWn].wproc = (int(*)())(procSelect); 	
    
    /* initialize run-select window event mask */
    
    TUTORset_event_mask(EVENT_LEFTDOWN,TRUE);
    TUTORset_event_mask(EVENT_LEFTUP,TRUE);
    TUTORset_event_mask(EVENT_RIGHTDOWN,TRUE);
    TUTORset_event_mask(EVENT_RIGHTUP,TRUE);
    TUTORset_event_mask(EVENT_DOWNMOVE,TRUE);
    TUTORset_event_mask(EVENT_HOT,TRUE);
    TUTORset_event_mask(EVENT_MENU,TRUE);
    TUTORset_event_mask(EVENT_MSG,TRUE);
    TUTORset_event_mask(EVENT_FWD,TRUE);
    TUTORset_event_mask(EVENT_VFOCUS,TRUE);
    TUTORset_event_mask(EVENT_WFOCUS,TRUE);
    TUTORset_event_mask(EVENT_SCROLL,TRUE);
    TUTORset_event_mask(EVENT_KEY,TRUE);

	/* create run-select view */
	
    SelectVp = TUTORinit_view(SelectWn,0,procSelect);
    TUTORset_view(SelectVp); 
    
  	/* initialize text panel */
  	
    info = LEFTSTICK | RIGHTSTICK | TOPSTICK | BOTTOMSTICK;
    SelectPanelH = MakeTextPanel(SelectWn,(long)SelectDocH,0,0,(TRect *)NEARNULL,info,
            100,TRUE,SelectDocH,0L, -1L,TRUE,TRUE,FARNULL,FALSE,FALSE,FALSE,TRUE,
            -1,-1,-1,FALSE,7);
    if (!SelectPanelH) { /* out of memory */
    	TUTORclose_view(SelectVp);
    	goto rview;
    }		    
	vp = (TextVDat FAR *)GetPtr(SelectPanelH);
	RestartPanel(vp,0L,0L /* len */,0L,0L);
	ReleasePtr(SelectPanelH);

	/* initialize menu */

    TUTORset_menubar(debugMenu,AuxVp);
	
rview:
	TUTORset_view(cv); /* restore original view */
	return(0);

} /* RunSelectOpenWindow */

/* ******************************************************************* */

static int procSelect(Memh dbgH, struct tutorevent *event)

{	int wix; /* index of window */
	TRect clipR; /* saved clip rectangle */
	TRect eRect; /* rectangle to erase */
	struct tutorview FAR *viewP; /* pointer to view */
	struct tutorevent gevent; /* event for editor */
	int hotUnit; /* unit number from hot event */
	long hotLvars; /* relative base of lvars in stack */
	long hotUloc; /* location in unit */
	long hotRel; /* relative position in stack */
	int doFwd; /* window to bring forward */
	
	wix = event->window;
	doFwd = -1;
	
	switch (event->type) {
	        
	case EVENT_LEFTUP:
		break;
		
    case EVENT_REDRAW:
    	TUTORset_view(SelectVp);
        TUTORinq_abs_clip_rect(&clipR); /* save clip */
		TUTORclip_window(wix); /* clip to entire window */
		eRect.top = eRect.left = 0;
		eRect.bottom = windowsP[wix].wysize;
		eRect.right = windowsP[wix].wxsize;
        TUTORdraw_abs_solid_rect((TRect FAR *)&eRect,PAT_BACKGROUND);  
        TUTORset_abs_clip_rect((TRect FAR *) &clipR); /* restore clip */
        viewP = windowsP[wix].lastView;
        while (viewP) {
        	if (viewP != SelectVp) {
            	TUTORset_view(viewP);
           		(*viewP->vproc) (viewP->vh,event);
           	}
            viewP = viewP->prevView;
        }
        event->type = -1; /* we handled it already */
        break;

    case EVENT_FWD:
        viewP = windowsP[wix].firstView;
        while (viewP) {
        	if (viewP != SelectVp) {
            	TUTORset_view(viewP);
            	(*viewP->vproc) (viewP->vh,event);
            }
            viewP = viewP->nextView;
        }
        event->type = -1;
        break;

    case EVENT_VFOCUS:
        event->type = -1;
        break;
    	
    case EVENT_WMKILL: /* window closed by window manager */  
    	event->type = -1;
    	if (SelectVp)
    		TUTORclose_view(SelectVp);
    	break;
    	
    case EVENT_DESTROY: /* view closed */
    	if ((wix >= 0) && (wix == SelectWn) && SelectVp) { 
    		AuxWn = -1; /* no reccursion */
    		dDatP = (DebugData FAR *)GetPtr(debugDatH);
    		dDatP->auxDisplay = 0; /* neither stack nor marker */
    		if (dDatP->auxPanelH)
				TUTORclose_panel(dDatP->auxPanelH); 
			/* auxDocH closed when main debug window closes */
    		ReleasePtr(debugDatH);
    		AuxVp = FARNULL;
    		TUTORclose_window(wix);
    	} /* wix if */
    	event->type = -1;
        break;
		
	case EVENT_HOT:
		if (runflag == halt)
			break;
		sscanf(strf2n(event->eDataP),"%d %ld %ld %ld",&hotUnit,&hotLvars,&hotUloc,&hotRel);
		TUTORdealloc(event->eDataP);
		event->eDataP = FARNULL;
		event->type = -1;
		DebugHiliteLine(hotUnit,hotUloc);
		dDatP = (DebugData FAR *)GetPtr(debugDatH);
		dDatP->swContext = TRUE; /* we have set a context */
		dDatP->swStackRel = hotRel;
		dDatP->swUnit = hotUnit;
		dDatP->swLvars = hotLvars;
		ReleasePtr(debugDatH);
		DebugClearExpr(); /* expression no longer valid */
		break;
		        
	default:
		break;
	
	} /* switch */
	
	/* pass on events we didn't handle */
	
    if (event->type > 0 && event->view) {
    	if (event->view != AuxVp) {
        	TUTORset_view(event->view);
        	(*event->view->vproc)(event->view->vh,event);
        }
    }
    
 	/* switch focus to another window if needed */
    
    if (doFwd >= 0) {
    	if (doFwd == EditWn[0])
    		EditForward(); /* bring correct editor forward */
    	else
    		TUTORforward_window(doFwd);
    }
    	        	
    event->type = -1; /* no window proc to fall back on */
	return(0);
	
} /* procSelect */

#endif

/* ******************************************************************* */

CommentOut(vp,pos,len) /* put asterisks at front of lines */
TextVDat FAR *vp;
long pos,len;
	{
	long curPos, newEnd;
	long viewStart, viewEnd;
	long extraDumm;
	long srclen;
	unsigned char cc[2];
	TViewP tvp;
	DocP dp;
	
	TUTORwait_cursor();
	curPos = pos;
	newEnd = pos + len;
	tvp = (TViewP) GetPtr(vp->textv);
	viewStart = tvp->bounds.pos;
	viewEnd = tvp->bounds.pos + tvp->bounds.len;
	ReleasePtr(vp->textv);
	KillPtr(tvp);
	cc[0] = '*';
	if (pos == viewStart || TUTORcharat_doc(vp->textd,pos-1) == NEWLINE)
		{
	/*	InsertString(vp->textd,pos,(char FAR *)cc,1L); */
		TUTORchange_doc(vp->textd,pos,0L,0L,TUTORget_len_doc(vp->textd),(unsigned char FAR *)cc,
		   1L,0L,-1,HNULL,&extraDumm,FALSE);
		newEnd++;
		viewEnd++;
		}
	
	while (TRUE)
		{
		dp = (DocP) GetPtr(vp->textd);
		curPos = TUTORsearch_string_doc(dp,(unsigned char FAR *) NEWLINES,1L,curPos,viewEnd);
		ReleasePtr(vp->textd);
		KillPtr(dp);
		if (curPos < 0 || curPos >= newEnd-1)
			break; /* we're done */
		curPos++; /* get past newline */
	/*	InsertString(vp->textd,curPos,(char FAR *)cc,1L); 	*/	
		TUTORchange_doc(vp->textd,curPos,0L,0L,TUTORget_len_doc(vp->textd),(unsigned char FAR *)cc,
		   1L,0L,-1,HNULL,&extraDumm,FALSE);
	    newEnd++;
	    viewEnd++;
		}

	RefreshPanel(vp,pos,newEnd-pos,pos,0L,newEnd - (pos+len),pos,newEnd - pos,TRUE,FALSE);

	TUTORsave_do_doc(HNULL,0L,0L,0,0L); /* can't undo */
	
	TUTORnormal_cursor();

	return(0);
	}

/* ******************************************************************* */

IndentOn(vp,pos,len) /* indent lines */
TextVDat FAR *vp;
long pos,len;
	{
	int intext, cmd;
	long myEnd,loc;
	long docLen;
	long extraDumm;
	Memh docH;

	TUTORwait_cursor();
	
	intext = FALSE;  /* not in the body of a -text- statement */
	srcPos = pos;
	myEnd = pos+len;
	docH = vp->textd;

	/* loop to indent lines within region */
	while (TRUE) {
 		if (!(srcPos && (TUTORcharat_doc(docH,srcPos-1) == NEWLINE) )) { 
    		while ( TUTORcharat_doc(docH,srcPos) != NEWLINE )
        		srcPos++;
    		srcPos++; /* move past the newline */
    	}
		if (srcPos >= myEnd) 
			break; /* terminate while */
		if (!intext)
			{ 
			/* InsertString(vp->textd,srcPos,(char FAR *) "\t",1L); */
			TUTORchange_doc(vp->textd,srcPos,0L,0L,TUTORget_len_doc(vp->textd),(unsigned char FAR *)"\t",
			    1L,0L,-1,HNULL,&extraDumm,FALSE);
			myEnd++;
			}
		if (intext && TUTORcharat_doc(vp->textd, srcPos) == '\\') 
			intext = FALSE;
		while ((cmd = getrealcommand()) == INDENT)
			; /* loop thru indents */
		if (cmd == C_TEXT || cmd == C_RTEXT || cmd == C_GTEXT || cmd == C_STRING)
			intext = TRUE; 
		}

	RefreshPanel(vp,pos,len,pos,0L,myEnd - (pos+len),pos,myEnd-pos,TRUE,FALSE);
	TUTORsave_do_doc(HNULL,0L,0L,0,0L); /* can't undo */

	TUTORnormal_cursor();
	
	return(0);

	}								/* IndentOn */

/*********************************************/

IndentOff(vp,pos,len,charOut)  /* remove indenting or comments from lines */
TextVDat FAR *vp;
long pos,len;
int charOut;	/* either tab (to remove indents) or * (to remove comments) */
	{
	long loc, myEnd;
	long docLen;
	long viewStart;
	unsigned char cc[2];
	TViewP tvp;

	loc = pos;
	myEnd = pos + len;
	
	TUTORwait_cursor();
	
	tvp = (TViewP) GetPtr(vp->textv);
	viewStart = tvp->bounds.pos;
	ReleasePtr(vp->textv);
	KillPtr(tvp);

	if (loc == viewStart || TUTORcharat_doc(vp->textd,loc-1) == NEWLINE)
		{ /* selection begin at start of view or line */
		if (TUTORcharat_doc(vp->textd,loc) == charOut)
			{
			TUTORdelete_doc(vp->textd, loc,1L,NEARNULL);
			myEnd--;
			}
		else if (charOut == '\t' && TUTORcharat_doc(vp->textd,loc)=='.' && 
				TUTORcharat_doc(vp->textd,loc+1L)=='\t' )
			{
			TUTORdelete_doc(vp->textd, loc,2L,NEARNULL);
			myEnd-=2;
			}
		}
	while (Seek(NEWLINES, vp->textd, loc,&loc) && loc < myEnd-1 )
		{ /* scan thru the selection */
	    loc++;
	    if (TUTORcharat_doc(vp->textd,loc) == charOut)
	    	{
	    	TUTORdelete_doc(vp->textd, loc,1L,NEARNULL);
	    	myEnd--;
	    	}
	    else if (charOut == '\t' && TUTORcharat_doc(vp->textd,loc)=='.' &&
				TUTORcharat_doc(vp->textd,loc+1)=='\t')
			{
			TUTORdelete_doc(vp->textd, loc,2L,NEARNULL);
			myEnd-=2;
			}
		}
	
	RefreshPanel(vp,pos,len,pos,pos+len-myEnd,0L,pos,myEnd-pos,TRUE,FALSE);
	TUTORsave_do_doc(HNULL,0L,0L,0,0L); /* can't undo */
	
	TUTORnormal_cursor();
	
	}

/* ******************************************************************* */

HideUnits(vp,selpos,sellen, all)  /* make units invisible, except for first line */
TextVDat FAR *vp;
long selpos,sellen;	/* selection position */
int all;
	
{	int firstUnit,lastUnit,ii;
	long endSel;
	long unitStart, unitEnd;
	long tempPos, tempLen;
	long docLen, addNewline;
	long pos,len;
	int srcI; /* index of source file in sourcetable */
	Memh docH; /* handle on source document */
	
	TUTORwait_cursor();
	FindUnits(); /* to make sure unit markers are correct */
	
	docH = vp->textd;
	srcI = -1; /* look up file in source table */
	for (ii=0; ii<sourcemalloc; ii++)
		if (sourcetable[ii].doc == docH)
			srcI = ii;
	
	if ((nunits < 0) || (srcI < 0)) { /* not main source or use */
		TUTORnormal_cursor();
		return(-1);
	}
	
	if (all) { /* hiding all units */
		pos = 0;
		len = TUTORget_len_doc(docH);
	} else { /* just hiding selection */
		pos = selpos;
		len = sellen;
	}
	
	endSel = pos+len;
	
	firstUnit = LocateUnit(docH,pos);
	if (firstUnit <= 0) 
		firstUnit = 1; /* can't hide IEU */
	if (sourcetable[srcI].ieu == firstUnit)
		firstUnit++; /* skip over IEU */
	lastUnit = LocateUnit(vp->textd,endSel);
	if (lastUnit < firstUnit) {
		TUTORnormal_cursor();
		return(0);
	}
	
	pos = -1; /* not reset yet */
	for (ii=firstUnit; ii<=lastUnit; ii++) {
		_TUTORinq_state_internal_marker(unittab[ii].marki,&tempPos,&tempLen,NEARNULL);
		unitStart = tempPos;
		unitEnd = unitStart+tempLen; /* end of this unit */
		Seek(NEWLINES,docH,unitStart,&unitStart); /* move unitStart up to newline of 1st line */
		unitStart++; /* move past newline */
		if (unitStart < unitEnd) { /* non-empty unit */
			TUTORstyle_doc(docH,unitStart,unitEnd-unitStart,PARASTYLE,1,VISMASK,NEARNULL);
			if (pos == -1)
				pos = unitStart; /* position at first change */
			endSel = unitEnd; /* position at end of last change */
		}
	} /* for */
	
	docLen = TUTORget_len_doc(docH);
	addNewline = 0L;
	if (endSel >= docLen) {
		/* last change went to doc end, make sure document ends with newline */
		if (TUTORcharat_doc(docH,docLen-1L) != NEWLINE) {
			TUTORinsert_string_doc(docH,docLen,
									(unsigned char FAR *) NEWLINES,1L);
			addNewline = 1L;
		}
	}
	
	if (pos > -1) {
		len = endSel - pos;
		if (addNewline)
			len++; /* to include new newline */
		RefreshPanel(vp,pos,len,pos,0L,addNewline,selpos,sellen,TRUE,FALSE);
	}

	TUTORsave_do_doc(HNULL,0L,0L,0,0L); /* can't undo */
	
	TUTORnormal_cursor();
	return(0);
	
} /* HideUnits */

/* ******************************************************************* */

ShowAllUnits(vp) /* make all units in text panel visible again */
TextVDat FAR *vp;
	
{	TViewP tvp;
	long startSel, endSel, beginShow, showLen;
	long tempL;

	TUTORwait_cursor();
	tvp = (TViewP) GetPtr(vp->textv);
	startSel = tvp->anchor.pos;
	endSel = tvp->selA.pos;
	if (startSel > endSel) { /* swap startSel & endSel */
		tempL = startSel;
		startSel = endSel;
		endSel = tempL;
	}
	endSel -= startSel; /* turn into length */
	
	beginShow = tvp->bounds.pos;
	showLen = tvp->bounds.len;
	ReleasePtr(vp->textv);
	KillPtr(tvp);
	
	TUTORstyle_doc(vp->textd,beginShow,showLen,PARASTYLE,0,VISMASK,NEARNULL);
	RefreshPanel(vp,beginShow,showLen,beginShow,0L,0L,startSel,endSel,TRUE,FALSE);
	SetSelectPanel(vp,startSel,endSel);
	TUTORnormal_cursor();

	TUTORsave_do_doc(HNULL,0L,0L,0,0L); /* can't undo */

} /* ShowAllUnits */

/*********************************************/

ShowUnits(vp,pos,len) /* make units visible again */
TextVDat FAR *vp;
long pos,len;
	
{	long startSel, endSel, beginShow, showLen, endShow, endShowL;
	int firstUnit, lastUnit;
	Memh docH; /* handle on source document */
	int ii,srcI;
	
	TUTORwait_cursor();
	FindUnits(); /* make sure unit markers are correct */
	
	docH = vp->textd;
	srcI = -1; /* look up file in source table */
	for (ii=0; ii<sourcemalloc; ii++)
		if (sourcetable[ii].doc == docH)
			srcI = ii;
	
	if ((nunits<=0) || (srcI < 0)) {
		TUTORnormal_cursor();
		return(-1);
	}
	startSel = pos;
	endSel = pos+len;
	
	firstUnit = LocateUnit(docH,startSel);
	lastUnit = LocateUnit(docH,endSel);
	
	_TUTORinq_state_internal_marker(unittab[firstUnit].marki,&beginShow,NEARNULL,NEARNULL);
	_TUTORinq_state_internal_marker(unittab[lastUnit].marki,&endShow,&endShowL,NEARNULL);
	showLen = endShow+endShowL - beginShow;
	TUTORstyle_doc(docH,beginShow,showLen,PARASTYLE,0,VISMASK,NEARNULL);
	RefreshPanel(vp,beginShow,showLen,beginShow,0L,0L,-1L,0L,TRUE,FALSE);

	TUTORsave_do_doc(HNULL,0L,0L,0,0L); /* can't undo */

	TUTORnormal_cursor();
	return(0);
	
} /* ShowUnits */

/* ******************************************************************* */

LocateUnit(docH,pos) /* return unit number of unit at position pos */
Memh docH; /* handle on source document */
long pos; /* position in source document */

{	int ii;
	int sii; /* index in sourcetable */
	int lastun;
	long tempPos, tempL;

	if (nunits <= 0)
		return(0); /* no unit setup */
	for(sii=0; sii<sourcemalloc; sii++)
		if (sourcetable[sii].doc == docH)
			break; /* found sourcetable index */
	if (sii >= sourcemalloc) 
		return(0); /* didn't find in source table */
	lastun = sourcetable[sii].lastunit;
	if (pos >= TUTORget_len_doc(sourcetable[sii].doc))
		return(lastun);

	for (ii=0; ii<nunits; ii++) {
		_TUTORinq_state_internal_marker(unittab[ii].marki,&tempPos,&tempL,NEARNULL);
		if  ((unittab[ii].beginfile == sii) && (tempPos <=  pos) &&
		     (pos < (tempPos + tempL)))
			break;
	} /* for */
	if (ii>lastun) ii = lastun; /* insure not beyond last unit in base source */
	return(ii);

} /* LocateUnit */

/* ******************************************************************* */
