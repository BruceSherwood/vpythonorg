
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* #define SELECTION_PASTE */

#include <stdio.h>

#include "baseenv.h"
#include "txt.h"
#include "tglobals.h"
#include "chardef.h"

#ifdef WINPC
#include <windows.h>
#endif

#ifndef IBMPC

#ifdef SYSV
#define sys_typesh
#include "wmx11.h"
#else
#include "wait.h"
#include <sys/time.h>
#ifdef WM
#include "wmclient.h"
#endif
#endif

#include "x11i.h"

#endif /* IBMPC */

#ifdef WINPC
extern HWND CurrentWinH; /* handle on current window */
extern HDC CurrentDC; /* current window's device context */
#endif

#ifdef ctproto
static long TUTORfrom_internal_clip_doc(Memh doc,long pos,long len,long mpos,long mlen,
long *extraPos,int saveDo);
static int TUTORto_internal_clip_doc(Memh doc,long pos,long len,long *extraPos);
extern long TUTORload_region(FileRef FAR *fr);
extern int strlenf(char FAR *cc);
int  TUTORfread_graphic_doc(unsigned int  doc,int  type,int  find);
extern unsigned int  MakeGraphicChar(struct  pcfont FAR *fontp,int  charN);
unsigned int  ReadPCX(int  find);
int  TUTORto_clip_doc(unsigned int  doc,long  pos,long  len,int  doCut,long  *extraPos);
long  TUTORfrom_clip_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,long  *extraPos,int  saveDo);
int  AllowHandlePurge(unsigned int  mm);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
extern TUTORblock_move(char FAR *sp, char FAR *dp, long lth);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORpurge_info(unsigned int  mm,int  ptype,char FAR *restoreproc,int  restorearg);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORadd_inset_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,int  kind,unsigned int  dat,long  *extraPos);
unsigned int  wmg_load_font(struct  _fref FAR *fontPath,int  index);
int  TUTORinq_fref(int  findx,struct  _fref FAR *fref);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
long  TUTORget_len_doc(unsigned int  doc);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int  TUTORget_char(int  findx,int  tryHard);
extern int TUTORzero(char FAR *ptr,long lth);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
int  TUTORsave_do_doc(unsigned int  doc,long  pos,long  len,int  op,long  newLen);
int  TUTORchange_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,unsigned char  FAR *cp,long  cLen,long  fromOff,unsigned int  styles,unsigned int  specialT,long  *extraPos,int  eupFlag);
#endif /* ctproto */

extern char FAR *GetPtr();
long TUTORget_len_doc();
Memh TUTORnew_doc();
extern char FAR *TUTORalloc();
long n_editorpaste();
extern unsigned int  wmg_load_font();
Memh MakeGraphicChar();
Memh ReadPCX();
long TUTORread();

static Memh clipboardDoc=0;
#ifdef IBMPC
#define PC_PASTE
#else
static char selectionOwner = FALSE;
extern Display *display;
#define PC_PASTE
#endif

/* ******************************************************************* */

TUTORto_clip_doc(doc,pos,len,doCut,extraPos) /* do copy/cut */
Memh doc;
long pos,len;
int doCut; /* TRUE if we are cutting */
long *extraPos; /* to be set to position where real end of change is
                    (due to paragraph styles) - in terms of doc AFTER change */
/* returns success flag */

{   long clipLen;
    long mLen; /* length of datastream in memory */
    char FAR *memBuff; /* pointer to datastream */
	int openF; /* TRUE if aquired clipboard */
	HGLOBAL clipData; /* handle on data to send to clipboard */
	char SHUGE *lpData; /* pointer to clip data */
    
    if (!len)
        return(FALSE); /* nothing to copy */

    if (!clipboardDoc) { /* create document for handling cut/copy/paste */
		clipboardDoc = TUTORnew_doc(TRUE,FALSE);
		if (!clipboardDoc)
			return(FALSE);
    }

    /* copy to internal clip document */

    TUTORto_internal_clip_doc(doc,pos,len,extraPos);

    /* cut from original doc if neccessary */

    if (doCut) {
        TUTORchange_doc(doc,pos,len,pos,len,FARNULL,0L,0L,HNULL,HNULL,extraPos,FALSE);
    }
    
    /* create a memory copy (ascii) of doc */
	
    mLen = len;
    memBuff = TUTORalloc(mLen+2L,FALSE,"cutbuff");
    if (!memBuff)
        return (FALSE);
	clipLen = len;

    TUTORget_string_doc(clipboardDoc,0L,(long) mLen,(unsigned char FAR *)memBuff);

	/* put contents on system clipboard */
	
	clipLen = mLen; /* length of datastream */
	clipData = GlobalAlloc(GHND,clipLen+1L);
	if (!clipData) {
		TUTORdealloc(memBuff);
		return(FALSE);
	}
    
	/* transfer data to global handle */
		
	lpData = GlobalLock(clipData);
	TUTORblock_move(memBuff,lpData,clipLen);
	GlobalUnlock(clipData);
		
	/* pass global handle to clipboard */
		
	openF = OpenClipboard(CurrentWinH); /* grab clipboard for our window */
	if (openF) {
		EmptyClipboard(); /* clear whatever is there */
		SetClipboardData(CF_TEXT,clipData); /* hand clipboard our data */
		CloseClipboard();
	} else {
		GlobalFree(clipData); /* release global handle */
	}
	TUTORdealloc(memBuff); /* release memory */
    return(openF);

} /* TUTORto_clip_doc */

/* ******************************************************************* */

static int TUTORto_internal_clip_doc(doc,pos,len,extraPos) 
Memh doc;
long pos,len;
long *extraPos; /* to be set to position where real end of change is
                    (due to paragraph styles) - in terms of doc AFTER change */
/* returns success flag */
    
{   long clipLen;
    
    if (!len)
        return(FALSE); /* we don't copy nothing */

    /* copy to internal clip document */
    
    if (!clipboardDoc) { /* create document for handling cut/copy/paste */
		clipboardDoc = TUTORnew_doc(TRUE,FALSE);
		if (!clipboardDoc)
			return(FALSE);
    }

	clipLen = TUTORget_len_doc(clipboardDoc);
    TUTORchange_doc_doc(clipboardDoc,0L,clipLen,0L,clipLen,
            doc,pos,len,extraPos,FALSE);
    return(TRUE);
    
} /* TUTORto_internal_clip_doc */

/* ******************************************************************* */

long TUTORfrom_clip_doc(doc,pos,len,mpos, mlen,extraPos, saveDo) /* paste */
Memh doc;
long pos,len;
long mpos, mlen; /* bounds of "marker" that we are changing */
long *extraPos; /* to be set to position where real end of change is
                    (due to paragraph styles) - in terms of doc AFTER change */
int saveDo; /* TRUE if should save action (for later undo) */
/* returns # of chars added */
    
{   long clipLen;
    int aFlag; /* TRUE if this looks like append */
    long nn;
    int openF; /* TRUE if clipboard aquired */
    HGLOBAL clipData; /* handle on data to send to clipboard */
    char SHUGE *lpData; /* pointer to clip data */
    HWND clipOwner; /* window handle of clipboard owner */
    
    if (!clipboardDoc) { /* create document for handling cut/copy/paste */
        clipboardDoc = TUTORnew_doc(TRUE,FALSE);
    }

    /* get data from internal clip if we own clip */

    clipOwner = GetClipboardOwner();
    if (clipOwner) {
	for(nn=0; nn<WINDOWLIMIT; nn++) {
	    if ((HWND)windowsP[nn].wp == clipOwner)
		return(TUTORfrom_internal_clip_doc(doc,pos,len,mpos,mlen,extraPos,saveDo));
	} /* for */
    } /* clipOwner */

    /* get data from system clipboard */
	
    if (IsClipboardFormatAvailable(CF_TEXT)) {
	openF = OpenClipboard(CurrentWinH);
	if (openF) {
	    clipLen = TUTORget_len_doc(clipboardDoc);
	    TUTORdelete_doc(clipboardDoc,0L,clipLen,NEARNULL);
	    clipData = GetClipboardData(CF_TEXT); /* handle on clipboard data */
	    lpData = GlobalLock(clipData); /* pointer to clip data */
	    clipLen = strlenf(lpData);
	    TUTORread_be2_doc(0,clipboardDoc,(unsigned char FAR *)lpData,clipLen);
	    GlobalUnlock(clipData);
	    CloseClipboard();
	} /* openF if */
    } /* data available if */
	
    clipLen = TUTORget_len_doc(clipboardDoc);
    if (saveDo)
        TUTORsave_do_doc(doc,pos,len,1,clipLen);
    
    aFlag = (len == 0);
    TUTORchange_doc_doc(doc,pos,len,mpos,mlen,
            clipboardDoc,0L,clipLen,extraPos,FALSE);
    
    return(clipLen);

} /* TUTORfrom_clip_doc */

/* ******************************************************************* */

static long TUTORfrom_internal_clip_doc(doc,pos,len,mpos, mlen,extraPos, saveDo) 
Memh doc;
long pos,len;
long mpos, mlen; /* bounds of "marker" that we are changing */
long *extraPos; /* to be set to position where real end of change is
                    (due to paragraph styles) - in terms of doc AFTER change */
int saveDo; /* TRUE if should save action (for later undo) */
/* returns # of chars added */
    
{	long clipLen;
    int aFlag; /* TRUE if this looks like append */
    
    if (!clipboardDoc) { /* nothing cut/copied yet */
        *extraPos = pos+len;
        return(0L);
    }
    
    clipLen = TUTORget_len_doc(clipboardDoc);
    if (saveDo)
        TUTORsave_do_doc(doc,pos,len,1,clipLen);
    
    aFlag = (len == 0);
    TUTORchange_doc_doc(doc,pos,len,mpos,mlen,
            clipboardDoc,0L,clipLen,extraPos,FALSE);
    
    return(clipLen);
    
} /* TUTORfrom_internal_clip_doc */

/* ******************************************************************* */
