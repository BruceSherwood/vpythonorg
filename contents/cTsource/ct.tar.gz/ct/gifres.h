

struct GIFresult {
	long width; /* width of image */
	long height; /* height of image */
	long bytesRow; /* bytes/row in raster */
	unsigned char SHUGE *raster; /* pointer to pixels */
	unsigned char redC[256];  /* color table */
	unsigned char greenC[256];
	unsigned char blueC[256];
}; /* GIF result */
