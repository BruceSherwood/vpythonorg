
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Part of the command compiler.
 */

#include "ctutor.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "exprdefs.h"
#include "yacc.h"
#include "txt.h"

#ifndef setjmp_d
#include "setjmp.h"
#define setjmp_d
#endif

#ifdef ctproto
int release_define_chain(Memh startH);
extern int set_wk_defset(Memh setH);
int  eError(char  *errstr,int sourceI,long pos,long len,int type);
extern int TUTORlog(char *str);
int  AllowHandlePurge(unsigned int  mm);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
extern int TUTORdump(char *msg);
extern int init_unit_defines(void);
extern int check_descriptors(void);
extern int init_all_defines(void);
extern int end_global_defines(void);
int  CountNeedsCompiled(void);
int  CompileProgram(int  wix,int  binf,int  mFlag);
extern int  CompileUnit(int  unitn);
extern int  StartCompunit(void);
extern int  DoneCompunit(void);
extern int  GlomIEU(void);
int  UserDefinesSetup(int  sourcen);
int  dumpunit(int  uii);
extern int  dmp_uinfo(int  uii);
int  Parse1Line(void);
int  cerror(int  errnumber,char  *execstr);
int  InitParse(void);
long  TUTORinq_msec_clock(void);
int  GetUnitName(int  unitn,unsigned char  *name);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
int  StopCompile(void);
int  writebinary(void);
int  TUTORstyle_doc(unsigned int  doc,long  pos,long  len,int  type,int  dat,int  canCombine,long  *extraPos);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORfree_handle(unsigned int  mm);
int  EditCompileMsg(int  wn,char  *ms);
int  _TUTORinq_state_internal_marker(int  ind,long  *pos,long  *len,int  *altered);
char  *parse_env(void);
int  FindUnits(void);
long  TUTORget_hsize(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  xref_open(int  unitn);
int  TUTORdelete_doc(unsigned int  doc,long  pos,long  len,long  *extraPos);
int  Halt(void);
int  MidCompile(int  cmdN);
int  xref_close(void);
int  MatchUnitName(unsigned char  *name);
int  getcommand(void);
int  cmpbuf_word(int  n);
int  compile_short_value(int  vv);
int  _TUTORset_state_internal_marker(int  ind,long  pos,long  len,int  altered);
int  TUTORtrace(char  *s);
int  TUTORtrace_n(char  *s,long  nn);
int  TUTORdealloc(char  FAR *ptr);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
extern int setjmp(jmp_buf env);
extern int sprintf(char *ss, char *form,...);
int  UnitCodegen68K(int  unitn);
int  UnitCodegenPPC(int  unitn);
#endif

extern long TUTORget_len_doc();
extern int RestoreBinaryStub();
extern long TUTORget_hsize();
extern char *parse_env();
extern long TUTORinq_msec_clock();

/* ******************************************************************* */

int CountNeedsCompiled() /* find out how many units need compiling */
/* returns # of units that need compiling (which may be 0),
   or -1 when everything needs to be recompiled */
{   int ii;
    int tempMod;    /* marker mod flag */
    int nNeedsC;    /* cumulative counter of units that need compilation */

    if (binaryOnly) return(0);

    FindUnits();
    if (nunits<=0)
        return(-1); /* unit setup failed */

    nNeedsC = 0;
    for (ii=0; ii<nunits; ii++) {
        /* check every unit to see if it needs to be compiled */
        _TUTORinq_state_internal_marker(unittab[ii].marki,NEARNULL,NEARNULL,&tempMod);
        if (!unittab[ii].compiled || unittab[ii].haserrors || tempMod) {
            if (ii == 0)
                return(-1); /* ieu changed, maybe everything needs recompilation */
            nNeedsC++;
        } /* compiled if */
    } /* for */
    
    return(nNeedsC);

} /* CountNeedsCompiled */
                
/* ******************************************************************* */

int CompileProgram(wix,binf, mFlag) /* compile all units */
/* returns TRUE for succesful compile */
int wix;    /* index of edit window for messages */
int binf;   /* TRUE if should produce binary */
int mFlag;  /* TRUE if should display message */
/* returns success flag */

{   int cmpi,pcmpi; /* compile unit table index */
    int errf;   /* checkpoint/compile error flag */
    int binw;   /* binary written flag */
    char *pmsg; /* parse_env error message */
    unsigned char unitname[NAMEL+1];
	char msg[200];
    int ii;
    int tempMod;
    jmp_buf saveBuff;   /* to save old longjump */

    TUTORblock_move((char SHUGE *) errjmpbuff,(char SHUGE *) saveBuff,(long) sizeof(jmp_buf));
    if (setjmp(errjmpbuff)) { /* some error */
        TUTORblock_move((char SHUGE *) saveBuff, (char SHUGE *) errjmpbuff,(long) sizeof(jmp_buf));
        return(FALSE);
    }
    
    errf = FALSE;
    
    /* Note: it is assummed that FindUnits was done in an immediately preceeding
        call to CountNeedsCompiled */

    /* check if should re-compile IEU(s) */

    _TUTORinq_state_internal_marker(unittab[0].marki,NEARNULL,NEARNULL,&tempMod);
    if ((!unittab[0].compiled) || tempMod) {
        cmpl = 0;   /* initialize length of *cmpbuf* */
        compunit = 0;
        init_all_defines(); /* initialize all defines/sets */
        unittab[0].compiled = FALSE;
        ctutv = 0; /* don't know version yet */
        pmsg = parse_env();
        if (pmsg) 
        	cerror(SPECIFICERR,pmsg);
            
        /* check legal $syntaxlevel version */

        if (ctutv != CURRENTV) {
            startofline = srcPos = cI = ciStart = 0;
			strcpy(msg,"Missing or illegal $syntaxlevel.");
			strcat(msg,NEWLINES);
			strcat(msg,"Enter $syntaxlevel 2 as the 1st line of the program?");
            cerror(SPECIFICERR,msg);
        }
        
        allowcoarse = FALSE; /* coarse grid not allowed till hit -coarse- */    
    } /* compiled if */

    /* loop to compile units */

    cmpi = 0; /* set unit */
    pcmpi = -1; /* display 1st unit name */
    while ((cmpi < nunits) && (!errf)) {

        /* display message for next unit */

        _TUTORinq_state_internal_marker(unittab[cmpi].marki,NEARNULL,NEARNULL,&tempMod);
        if ((!unittab[cmpi].compiled) || tempMod) {
            if (cmpi != pcmpi) {
                if (mFlag) {
                    GetUnitName(cmpi,unitname);
                    EditCompileMsg(wix,(char *) unitname);
                }
                pcmpi = cmpi;
            } /* cmpi if */

            /* compile next unit */

            errf = !CompileUnit(cmpi); /* compile next unit */

            /* 2nd pass to generate compiled code for unit */

#ifdef MAC
            UnitCodegen68K(cmpi); /* generate 68000 code */ 
            UnitCodegenPPC(cmpi); /* generate PowerPC code */
#endif

            /* release cross-reference table */
            
            if (unittab[cmpi].xrefs) {
                TUTORfree_handle(unittab[cmpi].xrefs);
                unittab[cmpi].xrefs = HNULL;
                unittab[cmpi].nrefs = 0;
            } /* xref if */
        } /* compiled if */

        /* process compile error */

        if (errf)
            break;

        cmpi++; /* advance to next unit */
    } /* while */
    compunit = 0;

    if (!errf) { /* finish up */
        /* make text in textpool visible (invisibility is irrelevant in textpool) */
        TUTORstyle_doc((Memh) textpool,0L,TUTORget_len_doc((Memh) textpool),
                    PARASTYLE,0,VISMASK,NEARNULL);
        if (binf) 
            errf = !writebinary(); /* complete binary file */
    }
    
    StopCompile();
    TUTORblock_move((char SHUGE *) saveBuff, (char SHUGE *) errjmpbuff,
                    (long) sizeof(jmp_buf));
    
    check_descriptors(); /* check array descriptors make sense */

    return(!errf);

} /* CompileProgram */

/* ******************************************************************* */

static int CompileUnit(unitn) /* compile specified unit */
int unitn;
{   char unitname[NAMEL+1];

    /* check if unit already compiled */

    compunit = unitn;
    if (unittab[compunit].compiled) return(TRUE);

    /* pretend -use-d IEUs already compiled */
    
    GetUnitName(compunit,(unsigned char *) unitname);

    if (compunit && (!unittab[compunit].compiled) && 
       (strcmp(unitname,"*ieu") == 0)) {
        unittab[compunit].compiled = TRUE;
        unittab[compunit].haserrors = FALSE;
        return(TRUE);
    }

    TUTORinq_msec_clock(); /* update clock for memory manager */
    
    /* initialize variables for unit compile */

    StartCompunit();
    InitParse();
    
    /* compile body of unit */

    if (compunit == 0) { /* special for IEU: loop thru IEUs of all files */
        do { 
            init_unit_defines(); /* initialize define set */
            while (Parse1Line()) 
                if (cmpl > CMPBUFC) 
                    cerror(SPECIFICERR,"Unit too Big");
            GlomIEU(); /* advance to next IEU */
        } while(csourcen);
    }  else { /* compile ordinary unit */
        while(Parse1Line())
            if (cmpl > CMPBUFC) 
                cerror(SPECIFICERR,"Unit too Big");
    } /* compunit else */

    /* finish up unit */

    continFlag = FALSE; /* last command doesn't continue */
    MidCompile(UNITEND); /* done with unit */
    DoneCompunit();
        
    return(unittab[compunit].compiled);

} /* CompileUnit */

/* ******************************************************************* */

static StartCompunit() /* initializations for compiling a unit */
    
{   register struct unitinfo FAR *unitP;
    short ii;
    long loc;
    long hlth; /* length of handle */
    long lth; /* length for move */
    char FAR *from; /* from address for move */
    char FAR *to; /* to address for move */
    long tempPos, tempLen;

    /* delete previous pcode for this unit */
    
    unitP = unittab+compunit;
    if (unitP->pcodeAlphaH) {
        /* must halt execution if the pcode for the */
        /* currently executing unit is destroyed */
        if (pcodeh == unitP->pcodeAlphaH)
            Halt();
        TUTORfree_handle(unitP->pcodeAlphaH);
    }
	if (unitP->pcodeBetaH)
		TUTORfree_handle(unitP->pcodeBetaH);
    unitP->pcodeAlphaH = unitP->pcodeBetaH = HNULL;
    unitP->pcodeBetaL = unitP->pcodeAlphaL = 0;
    unitP->pdskadr = unitP->bdskadr = unitP->rdskadr = -1;

    /* delete previous text/strings for this unit */
    /* adjust following units */

    if (unitP->textl) {
        TUTORdelete_doc(textpool,unitP->textp,unitP->textl,NEARNULL);
        loc = unitP->textp;
        for (ii=0; ii<unitmalloc; ii++)
            if (unittab[ii].textp > loc)
                unittab[ii].textp -= unitP->textl;
    } /* textl if */

	if (unitP->debugSetH) 
		release_define_chain(unitP->debugSetH); /* only 1 set in chain */
	unitP->debugSetH = HNULL;
	
    unitP->textp = TUTORget_len_doc(textpool);
    unitP->textl = 0;
    defexp.text = textpool; /* document for string literals */
    defexp.textbase = unitP->textp; /* set base for string literals */
    defexp.srcH = source; /* default source input document */

    /* set up cross-reference tables */

    labelID = 1; /* initialize internal label id */
    unittab[compunit].nrefs = 0;
    xref_open(compunit);

    /* set up source/binary map */

    if (srbimapH) {
        ReleasePtr(srbimapH); /* release previous table */
        KillPtr(srbimapP);
    }
    srbimapH = srbimapL = 0; /* no handle, no length */
    srbimapP = NULL; /* no pointer */
    if (unitP->srcmapAlphaH == HNULL) /* init map handle */
        unitP->srcmapAlphaH = TUTORhandle("srbimap ",50L,TRUE); 
    srbimapH = unitP->srcmapAlphaH; /* get handle on units src/bin map */
    TUTORpurge_info(srbimapH,M_WMRM,FARNULL,0);
    AllowHandlePurge(srbimapH);
    srbimapL = TUTORget_hsize(srbimapH); /* current lth of table (bytes) */
    srbimapL = srbimapL/sizeof(struct srbimap); /* lth as number entries */
    srbimapP = (struct srbimap FAR *)GetPtr(srbimapH);
    unitP->nmap = 0; /* init num entries in source/binary map */

    /* set up compile buffer */

    cmpbuf = (unsigned char FAR *) GetPtr(cmpH);
    cmpLocked = TRUE;
    defexp.pcode = cmpbuf; /* pcode output to cmpbuf, cmpl */
    cmpl = 0; /* reset pointer in cmpbuf */

    /* delete previous array/argument descriptors for this unit */
    /* adjust following units */

    if (descP == NULL)/* get pointer to descriptors pool */
        descP = GetPtr(descH);
    if (unitP->descl) { /* delete previous descriptors */

        /* shove following info down */

        loc = unitP->descp+unitP->descl;
        hlth = TUTORget_hsize(descH); /* current size of handle */
        lth = hlth-loc; /* lth to move */
        to = descP+unitP->descp; /* to address for move */
        from = to+unitP->descl; /* from address for move */
        TUTORblock_move(from,to,lth);
        ReleasePtr(descH); /* allow handle to move */
        KillPtr(descP);
        TUTORset_hsize(descH,hlth-unitP->descl,TRUE); /* down-size handle */
        descP = GetPtr(descH); /* re-aquire pointer */

        /* adjust pointers to following info */

        lth = unitP->descl;
        for(ii=0; ii<unitmalloc; ii++) {
            if (unittab[ii].descp >= loc)
                unittab[ii].descp -= lth;
        } /* for */
    } /* unitP->descl if */

    unitP->descp = TUTORget_hsize(descH); /* new info at end */
    unitP->descl = 0; /* no info for this unit */
    
    unitP->nvargs = unitP->naargs = 0; /* no arguments yet */
    unitP->compiled = FALSE;
    unitP->haserrors = FALSE;
    unitP->hasglobals = FALSE;
    unitP->hasfile = FALSE;
    
    npass_by_addr = npass_by_value = 0;
    csourcen = unitP->beginfile;
    source = sourcetable[csourcen].doc;
        defexp.srcH = source; /* source input doc for expressions */
    ctutv = sourcetable[csourcen].ctutv; /* current level */
    _TUTORinq_state_internal_marker(unitP->marki,&tempPos,&tempLen,NEARNULL);
    srcEnd = tempPos + tempLen;
    _TUTORset_state_internal_marker(unitP->marki,-1L,-1L,FALSE);
    lvaraddr = 0;
    currentkind = NOTDEFINED;
    appendok = FALSE; /* not continued -calc- */
    srcPos = tempPos;
    oldcmd = lastcmd = 0;

    /* aquire pointer to expression compiler table */

    if (!xtP)
        xtP = (struct exprt FAR *) GetPtr(xtH);

    /* set up commands at begin of IEU */

    if ((compunit==0) && (csourcen==0)){

        /* add set-version command */
        compile_short_value(ctutv); 
        compile_short_value(!nocliptext);
        compile_short_value(!oldfontsize);
        compile_short_value(wrapwrite);
        compile_short_value(oldcolor);
        compile_short_value(pcoldcolor);
        compile_short_value(ExecWinX);
        compile_short_value(ExecWinY);
        cmpbuf_word(C_SVERS);
    } /* compunit if */

	if ((DebugWn >= 0) && compunit)
		cmpbuf_word(C_BEGINUNIT); /* mark begin of unit for debugger */
		
    return 0;

} /* StartCompunit */

/* ******************************************************************* */

static DoneCompunit() /* done compiling, finish up */
    
{   int ii;
    char unitname[NAMEL+1];
    struct caseopt *casep; /* -case- optimization table */

    cmpbuf_word(C_ENDUNIT);
    oldcmd = 0;

    /* set local variable requirement for this unit */
    unittab[compunit].nlvars = (compunit ? lvaraddr: 0);

    /* look at next command and make sure it is UNIT, or end */
    
    if (srcPos < TUTORget_len_doc(source) && (getcommand() != C_UNIT)) {
    	nunits = -1;
        cerror(SPECIFICERR,"Badly formed -unit- command.");
    }

    if (compunit == 0) {
        /* special work for ieu */

        end_global_defines(); /* done compiling globals */

        /* pretend -use-d IEUs already compiled */
        for (ii=1; ii<sourcemalloc; ii++) {
            if (sourcetable[ii].programpart && sourcetable[ii].valid){
                unittab[sourcetable[ii].ieu].compiled = TRUE;
            }
        } /* for */
    } /* compunit if */

    /* set size of unit text */

    unittab[compunit].textl = TUTORget_len_doc(textpool)-unittab[compunit].textp;

    /* check if should display unit binary for debug */

    ii = MatchUnitName((unsigned char *) "BruceS");
    if (ii == compunit || ii == 1) {
        /* dump specially named unit */
        dumpunit(compunit); 
    }

    /* release expression compiler table */

    if (xtP) {
        ReleasePtr(xtH);
        xtP = NULL;
    }

    /* transfer unit from compile buffer to unit document */
    if (unittab[compunit].pcodeAlphaH) {
        /* must halt execution if the pcode for the */
        /* currently executing unit is destroyed */
        if (pcodeh == unittab[compunit].pcodeAlphaH)
            Halt();
        TUTORfree_handle(unittab[compunit].pcodeAlphaH);
    }
    unittab[compunit].pcodeAlphaH = (TUTORhandle("pcode  ",(long) cmpl,TRUE));
    if (!unittab[compunit].pcodeAlphaH) {
    	nunits = -1;
        cerror(SPECIFICERR,"Not enough memory for unit.");
    }
    unittab[compunit].pcodeAlphaL = cmpl; /* length of pcode */
     /* copy unit binary */
    TUTORblock_move((char SHUGE *) cmpbuf,GetPtr(unittab[compunit].pcodeAlphaH),(long) cmpl);
    ReleasePtr(unittab[compunit].pcodeAlphaH);
    
    /* clean up branch cross-reference tables */

    xref_close(); /* release handles */
    TUTORset_hsize(unittab[compunit].xrefs,(long)
                   (unittab[compunit].nrefs*sizeof(struct locref)),TRUE);

    /* re-size source/binary map table */

    if (srbimapH) {
        ReleasePtr(srbimapH);
        TUTORset_hsize(srbimapH,(long)(unittab[compunit].nmap*sizeof(struct srbimap)),TRUE);
    }
    srbimapH = srbimapL = 0; /* no handle, no length */
    srbimapP = NULL; /* no pointer */

    /* clean up -case- optimization table */

    for(ii=0; ii<MAXINDENTS; ii++) {
        casep = &caseod[ii];
        if (casep->cv) {
            TUTORdealloc((char FAR *)casep->cv);
            casep->cv = NULL;
        } /* values if */
        casep->nitems = casep->nalloc = 0;
    } /* for */

    if (cmpLocked){ /* free compile buffer */
        ReleasePtr(cmpH);
        KillPtr(cmpbuf);
        cmpLocked = FALSE;
    } /* cmpLocked if */

	/* save local defines if debugging */
	
	if ((DebugWn >= 0) && compunit) {
		unittab[compunit].debugSetH = localSetH;
		localSetH = HNULL;
		set_wk_defset(HNULL); /* no define set in effect */
	}
	
    unittab[compunit].compiled = TRUE;
    compunit = 0;

    return 0;

} /* DoneCompunit */

/* ******************************************************************* */

static GlomIEU() /* agglomerate -use-d ieu's into main file ieu */

{   int ii;
    long tempPos, tempLen;

    do {
        csourcen++;
    } while ((csourcen < sourcemalloc) && ((!sourcetable[csourcen].valid) ||
                    (!sourcetable[csourcen].programpart)));

    if (csourcen < sourcemalloc) {
        srcPos = 0;
        ii = sourcetable[csourcen].ieu;
        _TUTORinq_state_internal_marker(unittab[ii].marki,&tempPos,&tempLen,NEARNULL);
        srcEnd = tempPos + tempLen;
        unittab[ii].compiled = TRUE;
        unittab[ii].haserrors = FALSE;
        source = sourcetable[csourcen].doc;
        defexp.srcH = source; /* source input doc for expressions */
    } else {
        csourcen = 0; /* set back to base if all IEUs compiled */
        _TUTORinq_state_internal_marker(unittab[0].marki,NEARNULL,&tempLen,NEARNULL);
        srcPos = srcEnd = tempLen;
    }

    source = sourcetable[csourcen].doc;
        defexp.srcH = source; /* source input doc for expressions */
    ctutv = sourcetable[csourcen].ctutv; /* current level */
    return 0;

} /* GlomIEU */

/* ******************************************************************* */

#ifdef MAC
#define TRACE_LINE 5
#else
#define TRACE_LINE 10
#endif

dumpunit(uii) 
int uii; /* unit number to dump */

{   long j;
    int nl,cc;
    char unitname[NAMEL+1];
    char nstr[10];
    char msgb[120];

    TUTORtrace(" "); /* start with blank line */
    GetUnitName(uii,(unsigned char *) unitname);
    sprintf(msgb,"unit: %s #%d",unitname,uii);
    TUTORtrace(msgb);

    /* make sure that compunit (which is in cmpbuf) is the unit to be dumped */
    if (uii != compunit) {
        TUTORtrace_n("Unit currently compiling is",(long) compunit);
        return 0;
    }

    msgb[0] = 0;
    for (j=0; j<cmpl; j++){
        if ( (j% TRACE_LINE) == 0) {
            TUTORtrace(msgb); /* output line */
            msgb[0] = 0;
        }
        sprintf(nstr,"%d ",cmpbuf[j]);
        strcat(msgb,nstr);
    } /* for */
    TUTORtrace(msgb);
    dmp_uinfo(uii);  /* display additional info */

} /* dumpunit */

/* ******************************************************************* */

static dmp_uinfo(uii) /* display unit info for specified unit */
int uii; /* index of unit */

{   struct locref FAR *rp;
    int ii,lth,linc,cc,msgi;
    char msgb[120];

    if (descP == NULL)/* get pointer to descriptors pool */
        descP = GetPtr(descH);

    /* dump descriptors for this unit */

    lth = unittab[uii].descl;
    if (lth) {
        sprintf(msgb,"descriptors: %d %d\n",unittab[uii].descp,unittab[uii].descl);
        TUTORtrace(msgb);
        linc = msgi = 0;
        for(ii=0; ii<lth; ii++) {
            if (linc == 0) {
                sprintf(&msgb[msgi],"%d: ",ii);
                msgi = strlen(msgb);
            }
            sprintf(&msgb[msgi],"%d ",(unsigned char)(descP[unittab[uii].descp+ii]));
            msgi = strlen(msgb);
            linc++;
            if (linc == 16) {
                linc = 0;
                TUTORtrace(msgb);
                msgi = 0; /* reset index in output line */
            }
        } /* descriptors for */
        if (linc && msgi) {
            TUTORtrace(msgb);
            msgi = 0; /* reset index in output line */
        } /* linc if */
    } /* lth if */

    /* dump text pool for this unit */

    lth = unittab[uii].textl;
    if (lth) {
        sprintf(msgb,"textpool: %ld %ld",(long)unittab[uii].textp,(long)lth);
        TUTORtrace(msgb);
        linc = msgi = 0;
        for(ii=0; ii<lth; ii++) {
            cc = TUTORcharat_doc(textpool,(long)(unittab[uii].textp+ii));
            if (linc == 0) {
                sprintf(&msgb[msgi],"%d: ",ii);
                msgi = strlen(msgb);
            }
            if ((cc > 32) && (cc < 127))
                sprintf(&msgb[msgi],"%c ",cc);
            else sprintf(&msgb[msgi],"%d ",cc);
            msgi = strlen(msgb);
            linc++;
            if (linc == 32) {
                linc = msgi = 0;
                TUTORtrace(msgb);
            }
        } /* text for */
        if (linc && msgi) 
            TUTORtrace(msgb);
    } /* lth if */

    /* dump cross-reference tables for this unit */

    xref_open(uii); /* get pointers to tables */
    lth = unittab[uii].nrefs;
    if (lth) {
        sprintf(msgb,"refs: %d ",unittab[uii].nrefs);
        TUTORtrace(msgb);
        for(ii=0; ii<lth; ii++) {
            rp = &xrefP[ii];
            sprintf(msgb,"aref %d adest %d kind %d label %d satis %d",
               rp->aref,rp->adest,rp->kind & 0x3f,rp->label,
               (rp->kind >> 7) & 1);
            TUTORtrace(msgb);
        } /* refs for */
    } /* lth if */

    xref_close(); /* release handles */

} /* dmp_uinfo */

/* ******************************************************************* */

check_descriptors() /* check array descriptors intact */

{   long lth; /* length of descriptors */
    long loc; /* current position in descriptors */
    struct array_desc FAR *pdarray;
    struct arg_desc FAR *pdarg;
    struct mark_desc FAR *pdmark;
    struct dim_desc FAR *pddim;
    
    if (descP == NULL)/* get pointer to descriptors pool */
        descP = GetPtr(descH);
    
    lth = TUTORget_hsize(descH); /* current size of handle */
    loc = 0;
    
    /* loop thru descriptors checking reasonableness */
    
    while (loc < lth) {
        pdarray = (struct array_desc FAR *)(descP+loc);
    
        switch (pdarray->dtype) {
        
        case 1: /* array descriptor */
        case 6: /* dynamic array descriptor */
            loc += sizeof(struct array_desc);
            loc += pdarray->ndim*sizeof(struct dim_desc);
            break;
            
        case 2: /* pass-by-value argument */
        case 3: /* pass-by-address argument */
            loc += sizeof(struct arg_desc);
            break;
            
        case 4: /* marker variable */
            loc += sizeof(struct mark_desc);
            break;

        case 5: /* file, bitmap, etc */
            loc += sizeof(struct txtype_desc);
            break;
            
        default:
            TUTORdump("unrecognized item in descriptors ");
        
        } /* switch */
    } /* while */
    
} /* check_descriptors */

/* ******************************************************************* */
