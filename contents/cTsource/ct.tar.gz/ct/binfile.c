
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Routines associated with authoring.
*/

#include <stdio.h>
#include "baseenv.h"
#include "tutor.h"
#ifdef ANDREW
/* #include <sys/file.h> */
#endif
#include "tglobals.h"
#include "edglobal.h"
#include "ecglobal.h"

#include "editor.h"
#include "txt.h"
#include "compute.h"
#include "commands.h"

#ifdef ctproto
extern int TUTORlog(char *str);
extern int structures_check(void);
extern int set_wk_defset(Memh setH);
int  EditorDefaultStyles(unsigned int  doc);
int CheckEditOnFile(FileRef FAR *fRef,Memh *docHP,int Exclude);
int release_define_chain(Memh startH);
extern int release_old_defines(void);
extern int release_local_defines(void);
extern Memh read_handle(int index,int *errf);
extern int TUTORzero(char SHUGE *ptr,long length);
extern int readdefs(int index);
static int release_all_defines(void);
extern int write_handle(int bfile,Memh handm,int *errf);
char  FAR *TUTORrealloc(char  FAR *ptr,long  oldsize,long  newsize,int  abort);
int writedefs(int bfile);
char *getbinid(void);
extern int TUTORget_fileref_name(FileRef FAR *fRef, char FAR *name);
int  startbinary(void);
int  writebinary(void);
long  bin_write(char  FAR *ptr,int  size,long  count,int  findx,int  *errc);
long  bin_read(char  FAR *ptr,int  size,long  count,int  findx,int  *errc);
extern int  writepcodes(int  unitN,int  bfile);
extern int  finishbinary(int  bfile);
int  readbinary(struct  _fref FAR *fn, int sourceName);
int  AllocUnits(int  unl);
int  _TUTORinq_state_internal_marker(int  ind,long  *pos,long  *len,int  *altered);
int  GetUnitName(int  unitn,unsigned char  *name);
int  TUTORwrite_short(short ii,int  findx);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
long  TUTORwrite(char  FAR *ptr,int  pSize,long  count,int  findx);
int  TUTORdelete_file(struct  _fref FAR *fRef);
int  AllowHandlePurge(unsigned int  mm);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
int  RestoreBinaryStub(unsigned int  unitH,char  FAR *up,long  uLen,int  unitn);
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
int  TUTORclose(int  findx);
char  *machinename(void);
char  *strf2n(char  FAR *strp);
int  TUTORset_file_type(struct  _fref FAR *fRef,int  findx,int  type,int  xx,int  yy);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
int  assoc_name(struct  _fref FAR *fn,struct  _fref FAR *bfilen,char  *extnNew);
int  TUTORfree_handle(unsigned int  mm);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORfwrite_doc(unsigned int  doc,long  pos,long  len,int  fInd,int  nativeF);
long  TUTORget_len_doc(unsigned int  doc);
int  killptr(char  FAR * FAR *ptr);
long  TUTORget_hsize(unsigned int  mm);
int  TUTORinq_file_err(int  findx);
long  TUTORinq_file_pos(int  findx);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  AddUnitName(unsigned char  *name,int  unitNum);
int  TUTORread_short(short  *ii,int  findx);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  clearsrc(int  domkall);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
int  TUTORdealloc(char  FAR *ptr);
int  TUTORread_char(unsigned char  *cc,int  findx);
int  _TUTORinternal_marker(struct  markvar FAR *mp,unsigned int  stackH,long  rloc);
int  readdoc(unsigned int  doc,struct  _fref FAR *fRef,int  *iswrite);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  TUTORfread_doc(unsigned int  doc,long  len,int  docKind,int  fInd);
int  TUTORdump(char  *s);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
int  StopProgram(char  *s);
int  UserDefinesSetup(int  sourcen);
#endif /* ctproto */

#ifdef macproto
#ifndef WERKS
extern  int sprintf(char *, char *, ...);
#endif
#endif

char *getbinid();
extern Memh TUTORnew_doc();
extern long TUTORget_len_doc();
extern char *machinename();
extern char FAR *ReadFileKView();
extern long TUTORwrite();
extern long TUTORread();
extern long bin_write();
extern long bin_read();
extern long TUTORinq_file_pos();
extern char *strf2n();
extern int RestoreBinaryStub();
extern Memh read_handle();

#ifdef ANDREW
extern long getpid();
#endif

char *nxtkword();	

static char *binid = "ct061098 b";

/* ******************************************************************* */

startbinary() /* set up for creation of binary */
	
{	register struct unitinfo FAR *unp;
	int ii;
	
	/* make sure all already compiled units are in memory or swap file */
	/* get rid of all the other pcodes */
	
	unp = (struct unitinfo FAR *) unittab;
	for (ii=0; ii < nunits; ii++, unp++) {
		if (!unp->compiled || unp->haserrors) { /* destroy handle for uncompiled units */
			if (unp->pcodeAlphaH)
				TUTORfree_handle(unp->pcodeAlphaH);
			unp->pcodeAlphaH = HNULL;
			if (unp->pcodeBetaH)
				TUTORfree_handle(unp->pcodeBetaH);
			unp->pcodeBetaH = HNULL;
			unp->pcodeAlphaL = unp->pcodeBetaL = 0;
			unp->compiled = FALSE;
		}
	} /* for */
	
	/* destroy binary file reference */
	binaryFile.path[0] = '\0';	/* now we can't restore unit from binary file */

	return(0);
	
} /* startbinary */

/* ******************************************************************* */

char *getbinid()
	
{
	return(binid);
}

/* ******************************************************************* */

int structures_check()

{	int checksum;

	checksum = sizeof(struct sourcefile);
	checksum += sizeof(struct unitinfo);
	checksum += sizeof(double);
	checksum += sizeof(size_t);
	checksum += sizeof(struct unitinfo);
	checksum += sizeof(FileRef);
	checksum += sizeof(struct defvar);
	checksum += sizeof(struct defset);
	checksum += sizeof(struct sourcefile);
	checksum += sizeof(struct srbimap);
	checksum += sizeof(struct array_desc);
	checksum += sizeof(struct arg_desc);
	checksum += sizeof(struct mark_desc);
	checksum += sizeof(struct txtype_desc);
	checksum += sizeof(struct dim_desc);
	checksum += sizeof(struct argdef);
	checksum += sizeof(struct markvar);
	return(checksum);
	
} /* structures_check */

/* ******************************************************************* */

int writebinary()  /* write binary file */
/* returns TRUE if binary written, else FALSE */
	
{	char machn[16]; /* machine name */
	long mpos, mlen; /* unit marker position, length */
	int checksum; /* table-size check value */
	int errw, errf; /* error flags */
	int i; /* work variable */
	FileRef bn; /* binary file */
	struct unitinfo FAR *unp; /* pointer to unit info for unitN */
	int fileX, fileY; /* file location (for shell) */
	int bFile;	/* binary file index */
	
	errf = FALSE; /* no error yet */

    /* generate binary file name */
	assoc_name(&sourcetable[0].fRef,(FileRef FAR *) &bn, ".ctb");
	
	/* get binary file location (if any) */
	TUTORinq_file_info((FileRef FAR *) &bn,NEARNULL,NEARNULL,NEARNULL,&fileX,&fileY);

	/* initialize binary file */

	bFile = TUTORopen((FileRef FAR *) &bn,FALSE,TRUE,FALSE); /* open binary file */
	if (bFile == 0)
		return(FALSE);
	TUTORset_file_type((FileRef FAR *) &bn,bFile,2,fileX,fileY); /* set file type for binary */
  
	/* generate binary file header */

	TUTORwrite((char FAR *)binid,(int)sizeof(char),10L,bFile);
	for(i=strlen(strf2n(sourcetable[0].fRef.path)); i<FILEL; i++)
		sourcetable[0].fRef.path[i] = '\0'; /* clean file name */
	bin_write(sourcetable[0].fRef.path,(int)sizeof(char),(long) FILEL,bFile,&errf);
	for (i=0; i<16; i++)
		machn[i] = '\0';
	strcpy(machn,machinename()); /* machine name, zero filled */
	bin_write((char FAR *)machn,(int)sizeof(char),16L,bFile,&errf);
	TUTORwrite_short(ctutv,bFile); /* ct version */
	TUTORwrite_short(ExecWinX,bFile); /* executor window X size */
	TUTORwrite_short(ExecWinY,bFile); /* executor window Y size */
	TUTORwrite_short(usesColor,bFile); /* TRUE if program uses color */
	TUTORwrite_short((DebugWn >= 0),bFile); /* TRUE if compiled in debug mode */
	checksum = structures_check();
	TUTORwrite_short(checksum,bFile);
	TUTORwrite_short(1,bFile); /* start of section 1 (unit info) */
	TUTORwrite_short(nunits,bFile); /* # of units */

	if (!errf) { /* write all the unit pcodes */
		for(i=0; i<nunits && !errf; i++)
			errf = !writepcodes(i,bFile);
	}

	if (!errf)
		errf = !finishbinary(bFile);
		
	/* finish up */

	TUTORclose(bFile);

	if (!errf) { /* re-start unit paging */
		TUTORcopy_fileref((FileRef FAR *) &binaryFile,(FileRef FAR *) &bn);
	} else { /* delete faulty binary */
		TUTORdelete_file((FileRef FAR *) &bn);
	}

	if (!errf)
		binaryFileCurrent = TRUE;

	return(!errf);

} /* writebinary */

/* ******************************************************************* */

long bin_write(ptr,size,count,findx,errc) /* write, set error flag */
char FAR *ptr; /* pointer to item to write */
int size; /* size of element */
long count; /* number elements */
int findx; /* file index */
int *errc; /* error return - set TRUE if error, unaltered otherwise */

{	long nw; /* number actually written */

	nw = TUTORwrite(ptr,size,count,findx);
	if (nw == 0) *errc = TRUE;

} /* bin_write */

/* ******************************************************************* */

long bin_read(ptr,size,count,findx,errc) /* read, set error flag */
char FAR *ptr; /* pointer to item to write */
int size; /* size of element */
long count; /* number elements */
int findx; /* file index */
int *errc; /* error return - set TRUE if error, unaltered otherwise */

{	long nr;

	nr = TUTORread(ptr,size,count,findx);
	if (nr == 0) *errc = TRUE;

} /* bin_read */

/* ******************************************************************* */

static int writepcodes(unitN,bfile)	/* write unit info to file */
int unitN; /* unit # */
int bfile;	/* binary file index */
/* returns TRUE if binary written, else FALSE */
	
{	long mpos, mlen; /* unit marker position, length */
	int errf; /* error flag */
	int i; /* work variable */
	struct unitinfo FAR *unp; /* pointer to unit info for unitN */
	char FAR *pcptr; /* pointer to p-code */
	char unitname[NAMEL+1];

	errf = FALSE; /* no error yet */
	unp = unittab+unitN;
	
	/* now write unit info */

	TUTORwrite_short(unitN,bfile); /* this unit number */
	
	/* unittab entry */
	
	bin_write((char FAR *) unp,(int)sizeof(struct unitinfo),1L,bfile,&errf);
	
	/* unit name table entry */
	GetUnitName(unitN,(unsigned char *) unitname);
	bin_write((char FAR *) unitname,(int)sizeof(char),(long) (NAMEL+1),bfile,&errf);
	
	/* marker on unit */
	
	_TUTORinq_state_internal_marker(unp->marki,&mpos,&mlen,NEARNULL);
	*tempFarL = mpos;
	bin_write((char FAR *)tempFarL,(int)sizeof(long),1L,bfile,&errf);
	*tempFarL = mlen;
	bin_write((char FAR *)tempFarL,(int)sizeof(long),1L,bfile,&errf);
	
	/* source<->binary map */
	
	if (unp->nmap)  {
		pcptr = GetPtr(unp->srcmapAlphaH);
		bin_write((char FAR *)pcptr,(int)sizeof(char),
		          (long)TUTORget_hsize(unp->srcmapAlphaH),
		          bfile,&errf);
		ReleasePtr(unp->srcmapAlphaH);
		KillPtr(pcptr);
		if (unp->srcmapBetaH) {
			pcptr = GetPtr(unp->srcmapBetaH);
			bin_write((char FAR *)pcptr,(int)sizeof(char),
		          (long)TUTORget_hsize(unp->srcmapBetaH),
		          bfile,&errf);
			ReleasePtr(unp->srcmapBetaH);
			KillPtr(pcptr);	
		}
	} /* nmap if */
	
	if (unp->pcodeAlphaH) {
	
		/* write (interpreted) unit to binary file */
		
		pcptr = GetPtr(unp->pcodeAlphaH);
		unp->pdskadr = TUTORinq_file_pos(bfile); /* location of unit in file */
		bin_write(pcptr,(int)sizeof(char),(long) unp->pcodeAlphaL,bfile,&errf);
		ReleasePtr(unp->pcodeAlphaH);
		if (unp->pcodeBetaH) {
		
			/* write (partly compiled) unit to binary file */
		
			pcptr = GetPtr(unp->pcodeBetaH);
			unp->bdskadr = TUTORinq_file_pos(bfile); /* location of unit in file */
			bin_write(pcptr,(int)sizeof(char),(long) unp->pcodeBetaL,bfile,&errf);
			ReleasePtr(unp->pcodeBetaH);
		}
		KillPtr(pcptr);
	} else
		unp->pdskadr = unp->rdskadr = -1; /* not in file (because doesn't exist) */

	if (errf || TUTORinq_file_err(bfile))
		return(FALSE);

	return(TRUE); /* success */

} /* writepcodes */

/* ******************************************************************* */	

int writedefs(bfile) /* write defines */
int bfile; /* index of binary file */

{	int errf; /* TRUE if error occurred */
	Memh nextH;  /* handle on next define set */
	struct defset FAR *nextP;  /* pointer to next define set */
	int ndefsets; /* number define sets */
	int mii,mjj; /* indexes in merged set table */
	int	tranN; /* number entries in translation table */
	long tranS; /* size of translation table */
	long FAR *tranP;  /* pointer to translation table */
	int mrgN; /* number entries in merge table */
	long mrgS; /* size of merge table */
	long FAR *mrgP; /* pointer to merge table */
	Memh findH; /* handle to find+convert */
	long prevsz; /* previous size of table */
	Memh wH; 
	char FAR *wP;
	long wL;

	errf = 0; /* no error yet */
	
	/* write number bytes global storage */
	
	bin_write((char FAR *)&gvaraddr,(int)sizeof(char),(long)sizeof(long),bfile,&errf);
	
	/* count define sets, build table to translate define set handles */
	/* to binary-file-order indexes */
	
	tranN = 50; /* number entries in translation table (start big) */
	tranS = tranN*sizeof(long); /* size of table in bytes */
	tranP = (long FAR *)TUTORalloc(tranS,TRUE,"mrgtr1");
	ndefsets = 0; 
	nextH = firstSetH;
	while (nextH) { /* loop thru global define set chain */
		tranP[ndefsets++] = nextH; /* add next handle to table */
		if (ndefsets >= tranN) { /* check if need to extend table */
			prevsz = tranS;
			tranN += 10; /* lengthen table */
			tranS = tranN*sizeof(long);
			tranP = (long FAR *)TUTORrealloc((char FAR *)tranP,prevsz,tranS,TRUE);
		} /* ndefsets if */
		nextP = (struct defset FAR *)GetPtr(nextH);
		wH = nextP->nextSet; /* get next handle in chain */
		ReleasePtr(nextH);
		KillPtr(nextP);
		nextH = wH;
	} /* while */
	
	/* write number of define sets*/
	
	TUTORwrite_short(ndefsets,bfile);
	
	/* allocate (scratch) merged-sets table */
	
	mrgN = ndefsets; /* maximum number entries required */
	mrgS = mrgN*sizeof(long);
	mrgP = (long FAR *)TUTORalloc(mrgS,TRUE,"mrgtr2");
	
	/* write define sets to binary file */
	
	nextH = firstSetH; /* loop thru global define set chain */
	while (nextH) {
	
		/* write next define set header */

		nextP = (struct defset FAR *)GetPtr(nextH);
		wH = nextP->nextSet; /* get next handle in chain */
		write_handle(bfile,nextH,&errf);
		
		/* write symbol table to binary file */
		
		write_handle(bfile,nextP->defvarH,&errf);

		/* convert and write merge table */
		
		if (nextP->mergeN) {
		
			/* copy merge table to scratch table */
			
			wP = GetPtr(nextP->mergeH); /* pointer to merge table */
			wL = nextP->mergeN*sizeof(long);
			TUTORblock_move(wP,(char SHUGE *)mrgP,wL);
			ReleasePtr(nextP->mergeH); /* release merge table */
			KillPtr(wP);
			
			/* convert handles to indexes */
			
			for(mii=0; mii<nextP->mergeN; mii++) {
				findH = mrgP[mii]; /* next handle to convert */
				for(mjj=0; mjj<tranN; mjj++) {
					if (findH == tranP[mjj]) {
						mrgP[mii] = mjj; /* convert handle */
						break; /* exit mjj for */
					} /* findH if */
				} /* mjj for */
			} /* mii for */
			
			/* write translated merge table to binary file */
		
			bin_write((char FAR *)mrgP,(int)sizeof(char),wL,bfile,&errf);
		} /* mergeN if */
		
		ReleasePtr(nextH);
		KillPtr(nextP);
		nextH = wH; /* chain to next handle */
	} /* while */
	if (errf) return(FALSE); /* return failure if error occurred */
	return(TRUE); /* all ok */
	
} /* writedefs */

/* ******************************************************************* */

static int write_handle(bfile,handm,errf) /* write contents of handle */
int bfile; /* index of binary file */
Memh handm; /* handle to write */
int *errf; /* address for error return */

{	int errl; /* local error status */
	long writeL; /* size to write */
	char FAR *wP; /* pointer to data to write */

	errl = 0; /* no error yet */
	
	/* write out size of handle */
	
	if (handm) 
		writeL = TUTORget_hsize(handm);
	else 
		writeL = 0;
	bin_write((char FAR *)&writeL,(int)sizeof(long),1L,bfile,&errl);
	
	/* write contents of handle */
	
	if (handm) {
		wP = (char FAR *)GetPtr(handm);
		bin_write(wP,(int)sizeof(char),writeL,bfile,&errl);
		ReleasePtr(handm);	
		KillPtr(wP);
	} /* handm if */
	
	if (errl) *errf = TRUE; /* error return */
	
} /* write_handle */
	
/* ******************************************************************* */

static finishbinary(bfile) /* finish binary file */
int bfile;	/* binary file index */

{	int errw, errf; /* error flags */
	struct defvar FAR *gvarp;
	long FAR *gvarorderp;
	int ii;
	struct unitinfo FAR *unp;
	long tempL[2];

	errf = FALSE; /* no error yet */

	/* write source files table */

	TUTORwrite_short(2,bfile);  /* section 2 - sourcetable */
	*tempFarS = sourcemalloc; /* so TUTORwrite gets far */
    bin_write((char FAR *)tempFarS,(int)sizeof(short),1L,bfile,&errf);
	bin_write((char FAR *)sourcetable,(int)sizeof(struct sourcefile),
               (long)sourcemalloc,bfile,&errf);

	/* write defines */

	TUTORwrite_short(3,bfile);  /* section 3 - defines */
	errw = writedefs(bfile); /* write global define tree */
	if (errw == 0) errf = TRUE; 

	/* write argument/array descriptors */

	TUTORwrite_short(4,bfile); /* section 4 - descriptors */
	if (descP == NULL) descP = GetPtr(descH); /* ptr to info */
	*tempFarL = TUTORget_hsize(descH);
	bin_write((char FAR *)tempFarL,(int)sizeof(long),1L,bfile,&errf);
	if (*tempFarL) {
		bin_write(descP,1,*tempFarL,bfile,&errf);
	} /* len if */
	ReleasePtr(descH); /* allow handle to move */
	KillPtr(descP);
	descP = NULL; /* no pointer */

	/* write styled text */

	TUTORwrite_short(5,bfile);  /* section 5 - text pool */
	for (ii=0; ii<nunits; ii++)  { /* write out unit's textpool pointer */
		tempL[0] = unittab[ii].textp;
		tempL[1] = unittab[ii].textl;
		bin_write((char FAR *)tempL,(int)sizeof(long),2L,bfile,&errf);
	} /* for */
	
	/* write out text */
	errw = TUTORfwrite_doc((Memh) textpool,0L,TUTORget_len_doc((Memh) textpool),bfile,FALSE);
	if (errw == 0) errf = TRUE;

	return(!errf);

} /* finishbinary */

/* ******************************************************************* */

extern int CheckUnitMarkers(void);

int readbinary(fn, sourceName)	/* read binary file and initialize tables */
			/* returns TRUE if binary read, else FALSE */
FileRef FAR *fn; /* source or binary file name */
int sourceName;	/* TRUE if fn is the name of the source file */


{	int findx; /* index of binary file in file table */
	FileRef filen; /* binary file name */
	char FAR *vfilen; /* file name for verify */
	char machn[16]; /* machine name */
	long mpos,mlen; /* unit marker position and length */
	int errr, errf; /* error flags */
	int rctutv; /* ct version number read from binary */
	int rcsum; /* table size check-sum read from binary */
	int checksum; /* expected value of check-sum */
	struct sourcefile FAR *rsourcet=FARNULL; /* pointer to temporary sourcetable */
	int rsourcem; /* size of temporary sourcetable */
	long modtim; /* time file last modified */
	int wrtf; /* document writeable flag */
	char FAR *c; /* pointer to BE-II text string */
	char cw;
	struct defvar FAR *gvarp;
	long FAR *gvarorderp;
	int editI; /* index of editor on file */
	int ui; /* unit index */
	int i, jj; /* work variables */
	int unitN; /* number of unit we are currently reading */
	long FAR *tempPos, FAR *tempLen;	/* temporary places to hold unit marker info */
	struct markvar tempM;
	unsigned char unitname[NAMEL+1];
	int nunitsfile;	/* # of units in file */
	Memh srcDoc; /* handle on source document */
	short shortWk;
	char fileName[FILEL+1];

	allcompiled = FALSE;
	binaryFileCurrent = FALSE;

	if (DebugWn >= 0) /* don't bother if debugging - need to recompile */
		return(FALSE);
		
	tempPos = FARNULL;
	tempLen = FARNULL;
	
	/* get binary file name */

	if (sourceName)	/* get associated binary file name */
		assoc_name(fn, (FileRef FAR *) &filen, ".ctb");
	else
		{ /* executor, use file name unless it is *.t, in which case replace .t with .ctb */
		TUTORget_fileref_name(fn,fileName);
		jj = strlen(fileName);
		if (jj > 1 && 0 == strcmp(fileName+jj-2,".t")) /* name ends in .t */
			assoc_name(fn, (FileRef FAR *) &filen, ".ctb"); /* change to .ctb */
		else
			TUTORcopy_fileref((FileRef FAR *) &filen,fn);	/* just copy file ref */
		}

	/* open binary file for read */

	findx = TUTORopen((FileRef FAR *) &filen,TRUE,FALSE,FALSE);
	if (!findx) {
		if (!sourceName) { /* also try .ctb ending */
			assoc_name(fn, (FileRef FAR *) &filen, ".ctb"); /* change to .ctb */
			findx = TUTORopen((FileRef FAR *) &filen,TRUE,FALSE,FALSE);
		}
		if (!findx)
			return(FALSE);
	}

	/* read and verify binary file header */

	c = &machn[0];
	for (i=0; i<10; i++) {
		TUTORread_char((unsigned char *) &cw,findx); /* read identifying label */
		*c++ = cw;
	}
	if (strncmp(machn,binid,10) != 0) {
		TUTORclose(findx); /* binary not valid */
		return(FALSE);
	} /* strncmp if */

	/* read (skip over) binary name */

	errf = FALSE; /* no error yet */
	vfilen = TUTORalloc((long) (FILEL+20),TRUE,"vfile");
	bin_read(vfilen,(int)sizeof(char),(long) FILEL,findx,&errf);
	TUTORdealloc(vfilen);

	/* read and verify machine name */

	bin_read(tempFarS,(int)sizeof(char),16L,findx,&errf);
	TUTORblock_move(tempFarS,Farp(machn),16L);
	if (strncmp(machn,machinename(),16) != 0) {
		errf = TRUE;
	}

	/* read and verify CT version */

	TUTORread_short(&shortWk,findx); /* get ct version */
	rctutv = shortWk;
	if (rctutv != CURRENTV) {
		errf = TRUE;
	}
	
	/* read executor window size */
	
	TUTORread_short(&shortWk,findx); /* get x size */
	ExecWinX = shortWk;
	TUTORread_short(&shortWk,findx); /* get y size */
	ExecWinY = shortWk;

	/* get color and debug flags */
	
	TUTORread_short(&shortWk,findx); /* get color flag */
	usesColor = shortWk;
	TUTORread_short(&shortWk,findx); /* get debugEnabled flag */
	/* debugEnabled = shortWk; */
	
	/* read and verify table-size check-sum */

	checksum = structures_check();
	TUTORread_short(&shortWk,findx); /* get table check-sum */
	rcsum = shortWk;
	if (rcsum != checksum) {
		errf = TRUE;
	}

	/* start reading unit pcodes */

	TUTORread_short(&shortWk,findx);
	if (shortWk != 1) errf = TRUE;
	if (errf) { /* exit if error at this point */
		TUTORclose(findx);
		return(FALSE); /* bad binary */
	}

	clearsrc(TRUE);

	/* read number units and allocate unit table */

	TUTORread_short(&shortWk,findx);
	nunitsfile = shortWk;
	AllocUnits(nunitsfile); /* allocate unit table */
	
	tempPos = (long FAR *) TUTORalloc((long) (nunitsfile*sizeof(long)),TRUE,"tempPos ");
	tempLen = (long FAR *) TUTORalloc((long) (nunitsfile*sizeof(long)),TRUE,"tempLen ");

	nunits = 0;
	for(ui=0; (ui<nunitsfile) && !errf; ui++) {
		TUTORread_short(&shortWk,findx); /* read unit number */
		unitN = shortWk;
		if (unitN < 0 || unitN >= nunitsfile){ /* bad unit number */
			errf = TRUE;
			break;
		}
		bin_read((char FAR *)&unittab[unitN],(int)sizeof(struct unitinfo),1L,findx,&errf);
		bin_read((char FAR *) unitname,(int)sizeof(char),(long) (NAMEL+1),findx,&errf);
		unitname[NAMEL] = '\0'; /* guarantee null termination */
		AddUnitName(unitname,unitN);
		/* we should not have any unit markers at this point */
		bin_read((char FAR *) (tempPos+unitN),(int)sizeof(long),1L,findx,&errf);
		bin_read((char FAR *) (tempLen+unitN),(int)sizeof(long),1L,findx,&errf);
		if (errf) {
			break; /* stop working with error before do allocations */
		}
		unittab[unitN].debugSetH = HNULL; /* handle isn't valid */
		i = unittab[unitN].nmap;
		if (i) {
			i *= sizeof(struct srbimap);
			unittab[unitN].srcmapAlphaH = TUTORhandle("srbimap ",(long)i,TRUE);
			bin_read(GetPtr(unittab[unitN].srcmapAlphaH),(int)sizeof(char),(long)i,findx,&errf);
			ReleasePtr(unittab[unitN].srcmapAlphaH);
			TUTORpurge_info(unittab[unitN].srcmapAlphaH,M_WMRM,FARNULL,0);
    		AllowHandlePurge(unittab[unitN].srcmapAlphaH);
    		if (unittab[unitN].srcmapBetaH) {
    			unittab[unitN].srcmapBetaH = TUTORhandle("srbimap ",(long)i,TRUE);
    			bin_read(GetPtr(unittab[unitN].srcmapBetaH),(int)sizeof(char),(long)i,findx,&errf);
				ReleasePtr(unittab[unitN].srcmapBetaH);
				TUTORpurge_info(unittab[unitN].srcmapBetaH,M_WMRM,FARNULL,0);
    			AllowHandlePurge(unittab[unitN].srcmapBetaH);
    		}
		} else {
			unittab[unitN].srcmapAlphaH = HNULL; /* insure no handle */
			unittab[unitN].srcmapBetaH = HNULL;
		}
		if (unittab[unitN].pcodeAlphaL) {
			jj = TRUE;
#ifdef EXECUTE
			jj = FALSE;
#endif
			unittab[unitN].pcodeAlphaH = TUTORhandle("pcode r ",(long)unittab[unitN].pcodeAlphaL,jj);
			unittab[unitN].pdskadr = TUTORinq_file_pos(findx);
			bin_read(GetPtr(unittab[unitN].pcodeAlphaH),(int)sizeof(char),
			                (long) unittab[unitN].pcodeAlphaL,findx,&errf);
			ReleasePtr(unittab[unitN].pcodeAlphaH);
			if (!jj) { /* execute */
				TUTORpurge_info(unittab[unitN].pcodeAlphaH,M_RPROC,RestoreBinaryStub,unitN);
				AllowHandlePurge(unittab[unitN].pcodeAlphaH);		
			}
			if (unittab[unitN].pcodeBetaL) {
				unittab[unitN].pcodeBetaH = TUTORhandle("pcode r ",(long)unittab[unitN].pcodeBetaL,jj);
				unittab[unitN].bdskadr = TUTORinq_file_pos(findx);
				bin_read(GetPtr(unittab[unitN].pcodeBetaH),(int)sizeof(char),
			                (long) unittab[unitN].pcodeBetaL,findx,&errf);
				ReleasePtr(unittab[unitN].pcodeBetaH);
				if (!jj) { /* execute */
					TUTORpurge_info(unittab[unitN].pcodeBetaH,M_RPROC,RestoreBinaryStub,unitN);
					AllowHandlePurge(unittab[unitN].pcodeBetaH);		
				}
			}
		} /* pcode if */
		nunits++;
	} /* units for */

	/* NOTE! we have severe problems if the binary is partial!  If we read in the unitinfo
		table & then stop, we have expectations about text in textpool (which we
		will then attempt to delete in StartCompunit - crash) and we will leak memory
		due to too many marker allocations... */
	
	if (errf || nunits < 1 || nunits != nunitsfile) {
		goto readberr;
	}

	/* read source files table */

	TUTORread_short(&shortWk,findx); /* get section number */
	if (shortWk != 2) errf = TRUE;

	if (errf) {
		goto readberr;
	}

	bin_read((char FAR *) tempFarS,(int)sizeof(short),1L,findx,&errf);
	rsourcem = *tempFarS;
	rsourcet = (struct sourcefile FAR *)
	               TUTORalloc((long)(rsourcem*sizeof(struct sourcefile)),TRUE,"srctable");
	if (rsourcet == NULL) errf = TRUE;

	if (errf) {
		goto readberr;
	}

	bin_read((char FAR *)rsourcet,(int)sizeof(struct sourcefile),(long)rsourcem,findx,&errf);
	rsourcet[0].doc = source;
	rsourcet[0].editI = -1; /* no editor (known) on this file */
	if (EditWn[0] >= 0)
		rsourcet[0].editI = 0; /* main editor on this file */
	for(i=1; i<rsourcem; i++) {
		rsourcet[i].doc = HNULL;
		rsourcet[i].editI = -1; /* no editor (known) on this file yet */
	} /* for */

	if ((ctedit || ctcomp)) {

		/* read -use- source files */

		for(i=1; i<rsourcem; i++) {
			editI = CheckEditOnFile(&rsourcet[i].fRef,&srcDoc,-1);
			rsourcet[i].doc = srcDoc;
			if (editI >= 0) {
				rsourcet[i].editI = editI; /* found editor on file */
				rsourcet[i].valid = TRUE; /* must be valid */
			} else {
				rsourcet[i].doc = TUTORnew_doc(FALSE,TRUE); /* set up document */
				if (rsourcet[i].doc == FALSE) {
					errf = TRUE;
					rsourcet[i].valid = FALSE;
					break;
				} /* doc if */
				EditorDefaultStyles((Memh)rsourcet[i].doc);
				errr = readdoc((Memh )rsourcet[i].doc,&rsourcet[i].fRef,
			    &wrtf);
#ifdef MAC
		        if (!errr) {
		        	rsourcet[i].fRef.volNum = filen.volNum;
		        	rsourcet[i].fRef.dirID = filen.dirID;
					errr = readdoc((Memh )rsourcet[i].doc,&rsourcet[i].fRef,
		            	&wrtf);		        
			}
#endif
				rsourcet[i].writeable = wrtf;
				if ((!errr) && (EditWn[0] >= 0)) {
					errf = TRUE;
					rsourcet[i].valid = FALSE;
					break;
				} /* err if */
			} /* editI else */
		} /* for */

		/* check if source or used file altered */

		for(i=0; i<rsourcem; i++) { 
			if (rsourcet[i].valid && rsourcet[i].doc) {
				TUTORinq_file_info(&rsourcet[i].fRef,NEARNULL,NEARNULL,&modtim,NEARNULL,NEARNULL);
				if (!modtim && (i == 0)) { /* try sourcetable fRef, file may have moved */
					TUTORinq_file_info(&sourcetable[0].fRef,NEARNULL,NEARNULL,&modtim,NEARNULL,NEARNULL);
				}
				if (modtim) { /* 0 if file no longer exists */
					if ((modtim > rsourcet[i].mtime) && (EditWn[0] >= 0)){
						nunits = -1; /* force new setup */
						errf = TRUE;
					} /* time compare if */
				} /* modtim if */
				/* attach unit markers for this file to correct document */
				for (jj=rsourcet[i].firstunit; jj<=rsourcet[i].lastunit; jj++) {
					tempM.doc = rsourcet[i].doc;
					tempM.alteredF = FALSE;
					tempM.pos = tempPos[jj];
					tempM.len = tempLen[jj];
					unittab[jj].marki = _TUTORinternal_marker((struct markvar SHUGE *) &tempM,HNULL,0L);
				} /* for */
			} /* valid if */
		} /* for */

		for(i=0; i<rsourcem; i++) { /* special fix for ieu */
			if (rsourcet[i].valid && rsourcet[i].doc){
				tempM.doc = rsourcet[i].doc;
				tempM.alteredF = FALSE;
				jj = rsourcet[i].ieu;
				tempM.pos = tempPos[jj];
				tempM.len = tempLen[jj];
				unittab[jj].marki = _TUTORinternal_marker((struct markvar SHUGE *) &tempM, HNULL,0L);

			}
		} /* for */
	} /* ctedit if */

	TUTORdealloc((char FAR *) tempPos);
	tempPos = FARNULL;
	TUTORdealloc((char FAR *) tempLen);
	tempLen = FARNULL;
	
	/* exit if error has occurred */

	if (errf) {
		goto readberr;
	}

	/* dump current source/unit/define tables */
	/* an error after this point is fatal */

	ctutv = rctutv; /* set version */
	TUTORcopy_fileref(&rsourcet[0].fRef,&sourcetable[0].fRef);
	if (sourcetable != NULL) 
		TUTORdealloc((char FAR *)sourcetable);
	sourcemalloc = rsourcem; /* size of new sourcetable */
	sourcetable = rsourcet; /* point to new table */
	release_all_defines(); /* release all define sets */

	/* read and allocate define tables */

	TUTORread_short(&shortWk,findx); /* get section number */
	if (shortWk != 3) TUTORdump("binfile 1");
	errr = readdefs(findx); /* read defines */
	if (errr == 0) errf = TRUE;

	if (errf) TUTORdump("binfile 2");

	/* read array/argument descriptors */

	TUTORread_short(&shortWk,findx); /* get section number */
	if (shortWk != 4) TUTORdump("binfile 3");
	bin_read((char FAR *) tempFarL,(int)sizeof(long),1L,findx,&errf);
	if (descP) {
		ReleasePtr(descH); /* allow re-size of handle */
		KillPtr(descP);
	}
	TUTORset_hsize(descH,*tempFarL,TRUE); /* re-size handle */
	descP = GetPtr(descH); 
	if (*tempFarL) { /* read descriptors */
		bin_read(descP,1,*tempFarL,findx,&errf);
	} /* tempFarL if */
	ReleasePtr(descH);
	KillPtr(descP);
	descP = FARNULL;

	/* read length of styled text pool */

	TUTORread_short(&shortWk,findx); /* get section number */
	if (shortWk != 5) TUTORdump("binfile 4");

	/* read unit's textpool pointers */

	for (i=0; i<nunits;i++) {
		bin_read((char FAR *) &unittab[i].textp,(int)sizeof(long),1L,findx,&errf);
		bin_read((char FAR *) &unittab[i].textl,(int)sizeof(long),1L,findx,&errf);
	}

	/* read styled text */
	/* it is assummed that all the rest of the file is styled text */

	errr = TUTORfread_doc((Memh) textpool,-1L,1,findx);
	if (errr == FALSE) errf = TRUE;

	if (errf) TUTORdump("binfile 5");

	TUTORclose(findx);
	allcompiled = TRUE;

	/* save binary file name */
	TUTORcopy_fileref((FileRef FAR *) &binaryFile,(FileRef FAR *) &filen);

	binaryFileCurrent = TRUE;
CheckUnitMarkers();
	return(TRUE);

readberr: /* error reading binary, after having started reading */
	if (rsourcet != FARNULL)
		TUTORdealloc((char FAR *)rsourcet);
	if (tempPos)
		TUTORdealloc((char FAR *)tempPos);
	if (tempLen)
		TUTORdealloc((char FAR *)tempLen);
	TUTORclose(findx);
	clearsrc(TRUE); /* re-initialize source table (& force re-init of unit info) */
	return(FALSE); /* binary not valid */

} /* readbinary */

/* ******************************************************************* */

extern Memh internalMarkers;

int CheckUnitMarkers()

{	int uii;
	int mii;
	struct markvar SHUGE *stackP;
	struct markvar SHUGE *markP;
	
	if ((nunits < 0) || (!sourcetable) || (!sourcetable[0].doc) || (!sourcetable[0].valid))
		return(0);
		
	stackP = (struct markvar SHUGE *)GetPtr(internalMarkers);
	for(uii=0; uii<=sourcetable[0].lastunit; uii++) {
		if (unittab[uii].beginfile == 0) {
			mii = unittab[uii].marki;
			markP = stackP+mii;
			if (markP->doc != sourcetable[0].doc) {
				char msg[80];
				sprintf(msg,"binfile %d %d\n",(int)markP->doc,(int)sourcetable[0].doc);
				TUTORlog(msg);
				TUTORdump("binfile 6");
			}
		}
	}
	ReleasePtr(internalMarkers);
	
}

/* ******************************************************************* */

int readdefs(bfile) /* read define tables from binary file */
int bfile; /* index of binary file */

{	int errf; /* TRUE if error occurred */
	int ndefsets; /* number define sets */
	int sii; /* index in define sets */
	int tii; /* index in translation table */
	int tranN; /* number entries in translation table */
	long tranS; /* size of translation table */
	long FAR *tranP; /* pointer to translation table */
	Memh setH; /* handle on next define set */
	struct defset FAR *setP; /* pointer to next define set */
	int mii; /* index in merge table */
	Memh mergeH; /* handle on merge table */
	long FAR *mergeP; /* pointer to merge table */
	long mergeS; /* size of merge table */
	Memh nextH; /* handle on next set in chain */
	struct defset FAR *nextP;  /* pointer to next set in chain */
	Memh prevH; /* handle on previous set in chain */
	struct defset FAR *prevP; /* pointer to previous set in chain */
	short shortWk;
	Memh wH;

	errf = FALSE; /* no error yet */
	
	/* read number bytes of global variables */
	
	bin_read((char FAR *)&gvaraddr,(int)sizeof(long),1L,bfile,&errf);
	
	/* read number of define sets */
	
	TUTORread_short(&shortWk,bfile); 
	ndefsets = shortWk;
	
	/* allocate translation table to convert indexes in binary */
	/* file to handles */
	
	tranN = ndefsets; /* number entries in table */
	tranS = tranN*sizeof(long); /* size of table */
	tranP = (long FAR *)TUTORalloc(tranS,TRUE,"mrgtr1");
	TUTORzero((char SHUGE *)tranP,tranS);
	
	/* read define sets from binary file */
	
	prevH = HNULL; /* no previous set yet */
	for(sii=0; sii<ndefsets; sii++) {
	
		/* read define set header */
		
		setH = read_handle(bfile,&errf); /* read define set header */
		if (setH == HNULL) return(FALSE); /* failed */
		tranP[sii] = setH; /* add to translation table */
		
		/* fix up global handles */
		
		setP = (struct defset FAR *)GetPtr(setH);
		setP->defvarH = HNULL; /* use defvarN, mergeN */
		setP->mergeH = HNULL;
		setP->mergeA = 0; /* don't know allocated size yet */
		setP->nextSet = HNULL; /* no next set yet */
		if (firstSetH == HNULL)
			firstSetH = setH; /* first set in chain */
		if (sii == (ndefsets-1))
			lastSetH = setH; /* last set in chain */
		if (setP->global)
			sourcetable[setP->srcfile].globaldefsetH = setH;
		if (setP->user)
			sourcetable[setP->srcfile].userdefsetH = setH;
		if (prevH) { /* link previous set to this */
			prevP = (struct defset FAR *)GetPtr(prevH);
			prevP->nextSet = setH;
			ReleasePtr(prevH);
			KillPtr(prevP);
		} /* prevH if */
		
		/* read symbol table */
		
		setP->defvarH = read_handle(bfile,&errf); /* read symbols */
		
		/* read merge table for this set */
		
		if (setP->mergeN) {
			mergeS = setP->mergeN*sizeof(long);
			mergeH = TUTORhandle("mrg",mergeS,TRUE); 
			mergeP = (long FAR *)GetPtr(mergeH);
			bin_read((char FAR *)mergeP,(int)sizeof(char),mergeS,bfile,&errf);
			ReleasePtr(mergeH); 
			setP->mergeH = mergeH; /* handle on merge table */
			setP->mergeA = setP->mergeN; /* allocated = used */
		} /* mergeN if */
		ReleasePtr(setH);
		KillPtr(setP);
		
		prevH = setH; /* make this set previous */
	} /* sii for */
	
	/* convert indexes in binary file to handles */

	nextH = firstSetH; /* loop thru define set chain */
	while (nextH) {
		nextP = (struct defset FAR *)GetPtr(nextH);
		wH = nextP->nextSet; /* get handle on next in chain */
		if (nextP->mergeN) {
			mergeH = nextP->mergeH;
			mergeP = (long FAR *)GetPtr(mergeH);
			for(mii=0; mii<nextP->mergeN; mii++) {
				mergeP[mii] = tranP[mergeP[mii]];
			} /* mii for */
			ReleasePtr(mergeH);
			KillPtr(mergeP);
		} /* mergeN if */
		ReleasePtr(nextH);
		KillPtr(nextP);
		nextH = wH; /* move to next in chain */
	} /* while */
	
	TUTORdealloc((char FAR *)tranP); /* release index->handle translation table */
	
	if (errf) return(FALSE); /* something went wrong */
	return(TRUE);
	
} /* readdefs */

/* ******************************************************************* */

static Memh read_handle(bfile,errf) /* read contents of handle */
int bfile; /* index of binary file */
int *errf; /* address for error return */

{	int errl; /* local error status */
	long readL; /* size to write */
	Memh rH; /* new handle to read into */
	char FAR *rP; /* pointer to handle to read into */

	errl = 0; /* no error yet */
	rH = HNULL; /* no handle yet */
	
	/* read size of handle */
	
	bin_read((char FAR *)&readL,(int)sizeof(long),1L,bfile,&errl);
	
	if (readL) {
	
		/* create handle to read into */
	
		rH = TUTORhandle("rdh",readL,TRUE); 
	
		/* read contents of handle */
	
		rP = (char FAR *)GetPtr(rH);
		bin_read(rP,(int)sizeof(char),readL,bfile,&errl);
		ReleasePtr(rH);	
		KillPtr(rP);
	}
	
	if (errl) {
		*errf = TRUE; /* error return */
		if (rH)
			TUTORfree_handle(rH);
		return(HNULL); /* failed - no handle */
	}
	return(rH); /* return new handle */
	
} /* read_handle */

/* ******************************************************************* */

AllocUnits(unl)	/* allocate unit table entries */
int unl; /* desired length of unit table */

{	int i; /* index in unit table */
	int pmalloc; /* previous size of table */
	struct unitinfo FAR *up;
	struct unitnames FAR *np;

	if (unl+1 < unitmalloc)
		return(0);
	pmalloc = unitmalloc;

	if (!unittabH) { /* initial allocation */
		unittabH = TUTORhandle("unittab",
                                       (long)(unl+10)*sizeof(struct unitinfo),
                                       TRUE);
		unittab = (struct unitinfo FAR *) GetPtr(unittabH);
		unitNames = TUTORhandle("unitname",(long) sizeof(struct unitdat)*(unl+10L),TRUE);
	} else { /* add more space */
		if (unittab) {
			ReleasePtr(unittabH);
			KillPtr(unittab);
		}
		TUTORset_hsize(unittabH,(long)(unl+10)*sizeof(struct unitinfo),TRUE);
		unittab = (struct unitinfo FAR *) GetPtr(unittabH);
		if (!TUTORset_hsize(unitNames,(long) sizeof(struct unitdat)*(unl+10L),FALSE))
			StopProgram(NEARNULL);
	} /* unit else */
	unitmalloc = unl+10; /* always ask for extra */

	if (!unittab) 
		StopProgram(NEARNULL);

	np = (struct unitnames FAR *) GetPtr(unitNames);
	for (i=pmalloc; i<unitmalloc; i++) {
		np->udata[i].name[0] = 0; /* empty name */
		np->udata[i].unitnum = -1; /* bad unit number */
		up = &unittab[i];
		up->compiled = FALSE;
		up->haserrors = FALSE;
		up->hasglobals = FALSE;
		up->debugSetH = HNULL;
		up->beginfile = 0;
		up->pcodeAlphaH = HNULL;
		up->pcodeAlphaL = 0;
		up->pcodeBetaL = 0;
		up->pcodeBetaH = HNULL;
		up->pdskadr = up->bdskadr = up->rdskadr = -1;
		up->descp = 0;
		up->descl = 0;
		up->marki = -1; 
		up->textp = 0; /* base in textpool */
		up->textl = 0; /* length in textpool */
		up->nrefs = 0; /* length of relocation table */
		up->xrefs = HNULL;
		up->nmap = 0; /* number entries in map table */
		up->srcmapAlphaH = up->srcmapBetaH = HNULL;
		up->nlvars = 0; /* local variable storage size */
		up->baseuse = 0;
	} /* for */
	ReleasePtr(unitNames);
	KillPtr(np);

} /* AllocUnits */

/* ******************************************************************* */

static int release_all_defines() /* destroy saved/current define sets */

{
	set_wk_defset(HNULL);
#ifndef EXECUTE
	release_old_defines(); /* release saved defines */
	release_local_defines(); /* release local define set */
#endif
	release_define_chain(firstSetH); /* release current global sets */
	globalSetH = userSetH = firstSetH = lastSetH = HNULL;
	
} /* release_all_defines */

/* ******************************************************************* */

int release_define_chain(startH) /* destroy -define- set tree */
Memh startH; /* handle on first set in chain */

{	Memh nextH; /* handle on next set in chain */
	Memh dumpH; /* handle set to dump */
	struct defset FAR *dsetP; /* pointer on next define set */
	
	if (!startH) 
		return(0); /* nothing to do */
	
	/* destroy all sets in chain */
	
	nextH = startH; /* handle on next set to dump */
	do {
		dumpH = nextH;
		dsetP = (struct defset FAR *)GetPtr(dumpH);
		nextH = dsetP->nextSet; /* handle on next set */
		if (dsetP->defvarH)
			TUTORfree_handle(dsetP->defvarH); /* release defines */
		if (dsetP->mergeH)
			TUTORfree_handle(dsetP->mergeH); /* release merge table */
		ReleasePtr(dumpH); 
		KillPtr(dsetP);
		TUTORfree_handle(dumpH); /* destroy set */
	} while(nextH); /* loop thru all following sets */
		
	return(0);
		
} /* release_define_chain */

/* ******************************************************************* */
