#define EOS	'\0'

#define CONTROL(x)	((x)-0x40)
#define ESC_KEY		CONTROL('[')

#define COM_PARAMS (_COM_CHR8 | _COM_STOP1 | _COM_NOPARITY | _COM_1200)

/* Define receive and transmit buffer sizes */
#define RXQSIZE	512
#define TXQSIZE	512

/* Definitions for the 8259A Programmable Interrupt Controller */
#define P8259_0		0x20	/* int control register */
#define P8259_1		0x21	/* int. mask register */
#define END_OF_INT	0x20	/* Non-specific EOI */

/* Define XON and XOFF ASCII codes */
#define XON_ASCII	(0x11)
#define XOFF_ASCII	(0x13)

/* Address of BIOS data area at 400h */
#define BIOS_DATA	((int FAR *)(0x400000L))
#define COMPORT(x)		(*(BIOS_DATA + (x))

#define IER(x) (COMPORT(x) + 1) /* interrupt enable register */
#define IIR(x) (COMPORT(x) + 2) /* interrupt identification */
#define LCR(x) (COMPORT(x) + 3) /* line control register */
#define MCR(x) (COMPORT(x) + 4) /* modem control register */
#define LSR(x) (COMPORT(x) + 5) /* line status register */
#define MSR(x) (COMPORT(x) + 6) /* modem status register */

/* Codes to enable inidividual interrupts */
#define RDAINT	1
#define THREINT	2
#define RLSINT	4
#define MSINT	8

/* Modem Control Register value */
#define MCRALL	15 /* (DTR, RTS, OUT1 and OUT2 = 1) */
#define MCROFF	0  /* everything off */

/* Interrupt Enable Register value to turn on/off int */
#define IERALL	(RDAINT+THREINT+RLSINT+MSINT)
#define IEROFF	0

/* Some masks for turning interrupts off */
#define THREOFF	0xfd

/* Interrupt identification numbers */
#define MDMSTATUS	0
#define TXREGEMPTY	2
#define RXDATAREADY	4
#define RLINESTATUS	6

/* Flags for XON/XOFF flow control */
#define XON_RCVD	1
#define XOFF_RCVD	0
#define XON_SENT	1
#define XOFF_SENT	0

/* Hi and low percentages for xon-xoff trigger */
#define HI_TRIGGER(x)	(3*(x)/4)
#define LO_TRIGGER(x)	((x)/4)

#define PORTS		2

/* Function to get bit 0 of an integer */
#define bit0(i)		((i) & 0x0001)

#define turnon_int(port, i,j)	\
	if ((((j) = inp(IER(port))) & (i)) == 0) outp(IER(port),((j)|(i)))
	
typedef struct QTYPE {
	int count;
	int front;
	int rear;
	int maxsize;
	char *data;
} QTYPE;

static char rxbuf[PORTS][RXQSIZE];
static char txbuf[PORTS][TXQSIZE];

static QTYPE rcvq[PORTS] = {{0, -1, -1, RXQSIZE, rxbuf[0]},
		    	    {0, -1, -1, RXQSIZE, rxbuf[1]}};
static QTYPE trmq[PORTS] = {{0, -1, -1, TXQSIZE, txbuf[0]},
			    {0, -1, -1, TXQSIZE, txbuf[1]}};
			
static QTYPE *txq[PORTS] = {&trmq[0], &trmq[1]};
static QTYPE *rxq[PORTS] = {&rcvq[0], &rcvq[1]};

static void (interrupt FAR old_handler[PORTS])();

static int s_linestatus[PORTS];
static int s_modemstatus[PORTS];

static short enable_xonxoff[PORTS] = {1, 1};
static short rcvd_xonxoff[PORTS] = {XON_RCVD, XON_RCVD};
static short sent_xonxoff[PORTS] = {XON_SENT, XON_SENT};
static short send_xon[PORTS] = {FALSE, FALSE};
static short send_xoff[PORTS] = {FALSE, FALSE};
static short int_number[PORTS] = {12, 11};
static short int_enable_mask[PORTS] = {0xef, 0xf7};
static short int_disable_mask[PORTS] = {0x10, 8};

#ifdef ctproto
void interrupt FAR pc_com1hndlr();
void interrupt FAR pc_com2hndlr();
static void s_trmty();
static void s_rda();
int s_setup();
int s_cleanup();
static int s_sendchar();
static int s_rcvchar();
static int q_puton();
static char *q_getfrom();
pc_rdwr_serial();
#endif /* ctproto */

pc_rdwr_serial(port, ptr, count, rwFlag)
int port;
char FAR *ptr;
long count;
int rwFlag;
{
	register char FAR *c;
	register int ii = 0, jj;
	
	if (rwFlag == TRUE) {
		for (c = ptr; ii < count; c++, i++) {
			jj = s_rcvchar(port);
			if (jj == -1) {
				return (ii - 1);
			}
			*c = (char)jj;
		}
		return ii;
	}
	else {
		for (c = ptr; ii < count; c++, ii++) {
			if (s_sendchar((int)*c, port) == 0) {
				return (ii - 1);
			}
		}
		return ii;
	}
		
}

void interrupt FAR pc_com1hndlr()
{
	int c;
	register int int_ud, intmask;
	
	_enable();
	for (;;) {
		int_id = inp(IIR(0));
		if (bit0(int_id) == 1) {
			outp(P8259_0, END_OF_INT);
			return;
		}
		if (int_id >= RXDATAREADY)
			turnon_int(0, THREINT, intmask);
		
	/* Process interrupt according to ID.  The following
	 * list is in increasing order of priority.
	 */
		switch (int_id) {
		case MDMSTATUS:	/*read modem status */
			s_modemstatus[0] = inp(MSR(0));
			break;
		case TXREGEMPTY:
			s_trmty(0);
			break;
		case RXDATAREADY:
			s_rda(0);
			break;
		case RLINESTATUS: /* read line status */
			s_linestatus[0] = inp(LSR(0));
			break;
		default:
			break;
		}
	}
}

void interrupt FAR pc_com2hdnlr()
{
	int c;
	register int int_ud, intmask;
	
	_enable();
	for (;;) {
		int_id = inp(IIR(1));
		if (bit0(int_id) == 1) {
			outp(P8259_0, END_OF_INT);
			return;
		}
		if (int_id >= RXDATAREADY)
			turnon_int(1, THREINT, intmask);
		
	/* Process interrupt according to ID.  The following
	 * list is in increasing order of priority.
	 */
		switch (int_id) {
		case MDMSTATUS:	/*read modem status */
			s_modemstatus[1] = inp(MSR(1));
			break;
		case TXREGEMPTY:
			s_trmty(1);
			break;
		case RXDATAREADY:
			s_rda(1);
			break;
		case RLINESTATUS: /* read line status */
			s_linestatus[1] = inp(LSR(1));
			break;
		default:
			break;
		}
	}
}

static void s_trmty(port)
int port;
{
	char c;
	register int ierval;
	
	if (send_xoff1 == TRUE) {
		outp(COMPORT(port), XOFF_ASCII);
		send_xoff = FALSE;
		sent_xonxoff = XOFF_SENT;
		return;
	}
	if (send_xon == TRUE) {
		outp(COMPORT(port), XON_ASCII);
		send_xon = FALSE;
		sent_xonxoff = XON_SENT;
		return;
	}
	
/* Put a character into the transmit holing register */
	if (q_getfrom(txq[port], &c) != NULL) {
		outp(COMPORT(port), c);
		return;
	}
/* Nothing to send -- turn off THRE interrupts */
	ierval = inp(IER(port));
	if (ierval & THREINT)
		outp(IER(port), ierval & THREOFF);
}

static void s_rda(port)
int port;
{
	register int intmask;
	char c;
	
	/* Read from comport */
	c = inp(COMPORT(port));
	if (enable_xonxoff[port]) {
		if (c == XON_ASCII) {
			rcvd_xonxoff[port] = XON_RCVD;
			/* Turn on the THRE if it's off */
			turnon_int(port, THREINT, intmask);
			return;
		}
		if (c == XOFF_ASCII) {
			rcvd_xonxoff[port] = XOFF_RCVD;
			/* Turn off THRE interrupts */
			intmask = inp(IER(port));
			if (intmask & THREINT)
				outp(IER(port), intmask & THREOFF);
			return;
		}
	}
	q_puton(rxq[port], &c);
	/* Check if queue is almost (75%) full */
	if (enable_xonxoff[port]) {
		if (rxq[port]->count >= HITRIGGER(RXQSIZE)
		    && sent_xonxoff[port] != XOFF_SENT) {
			/* Set flag to send XOFF */
			send_xoff[port] = TRUE;
			/* Turn on THRE interrupts so we can send the XOFF */
			turnon_int(port, THREINT, intmask);
		}
	}
}

int s_setup(port, commparams)
short port;
unsigned int commparams;
{
	int intmask;
	
	if (port < 0 || port > 1)
		return 0;
	
	if (COMPORT(port) == 0)
		return 0;
	
	switch (port) {
	case 0:
		old_handler[0] = _dos_getvect(int_number[0]);
		_disable();
		_dos_setvect(int_number[0], pc_com1hndlr);
		_enable()
		break;
	case 1:
		old_handler[1] = _dos_getvect(int_number[1]);
		_disable();
		_dos_setvect(int_number[1], pc_com2hndlr);
		_enable()
		break;
	default:
		return 0;
		break;
	}
	
	_bios_serialcom(_COM_INIT, port, commparams);
	
	rcvd_xonxoff[port] = XON_RCVD;
	if (sent_xonxoff[port] == XOFF_SENT)
		send_xonport] = TRUE;
	else
		send_xon = FALSE;
	send_xoff = FALSE;
	
	_disable();
	outp(MCR(port), MCRALL);
	outp(IER(port), IERALL);
	
	intmask = inp(P8259_1) & int_enable_mask[port];
	outp(P8259_1, intmask);
	
	_enable();

	return 1;
}

int s_cleanup(port)
int port;
{
	int intmask;

	_disable();
	outp(IER(port), IEROFF);
	outp(MCR(port), MCROFF);
	intmask = inp(P8259_1) | int_disable_mask[port];
	_dos_setvect(int_number[port], old_handler[port];
	_enable();
}

static int s_sendchar(ch, port)
int ch, port;
{
	int retval, intmask;
	
	_disable();
	retval = q_puton(txq[port], (char *)&ch);
	_enable();
	
	if (rcvd_xonxoff[port] != XOFF_RCVD)
		turnon_int(port, THREINT, intmask);
	
	return retval;
}

static int s_rcvchar(port)
int port;
{
	int ch, intmask;
	
	if (enable_xonxoff[port]) {
		if (rxq[port]->count <= LO_TRIGGER(RXQSIZE)
		    && sent_xonxoff[port] != XON_SENT) {
			send_xon[port] = TRUE;
			turnon_int(port, THREINT, intmask);
		}
	}
	_disable();
	if (q_getfrom(rxq[port], (char *)&ch) == NULL) {
		_enable();
		return -1;
	}
	else {
		_enable();
		return ch;
	}
}

static char *q_getfrom(queue, data)
QTYPE *queue;
char *data;
{
	char *current;
	
	current = NULL;
	if (queue->front == -1)
		return current;
	
	current = &(queue->data[queue->front]);
	*data = *current;
	queue->count--;
	if (queue->count == 0) {
		queue->front = queue->rear = -1;
		return current;
	}
	if (queue->front == queue->maxsize - 1)
		queue->front = 0;
	else
		queue->front++;
	}
	return current;
}

static int q_puton(queue, data)
QTYPE *queue;
char *data;
{
	if (queue->count == queue->maxsize)
		return 0;
	
	if (queue->rear == queue->maxsize - 1)
		queue->rear = 0;
	else
		queue->rear++;
	
	queue->data[queue->rear] = *data;
	queue->count++;
	if (queue->front == -1)
		queue->front = 0;
	
	return 1;
}
