
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/


#ifndef _kdefsh
#define _kdefsh

/* scroll bar defs */
/* type defs */
#define SBHORIZ 1
#define SBVERT 2
#define sbToTop 24
#define sbToBot 25
#define sbVUp 26
#define sbVDown 27
#define sbToPos 28
#define sbToPosB 29
#define sbPageUp 30
#define sbPageDown 31
#define sbLineUp 32
#define sbLineDown 33
#define sbSetMax 51
#define sbSetSelect 52
#define sbSetView 53

/* message defs */
#define SBNEWD 11
#define SBNEWM 12
#define SBNEWMR 13
#define SBNEWB 14
#define EVWIND 23
#define EVSTOP 24
#define EVLAUNCH 25
#define MNDESKA 31
#define MNWSPAC 32


/* item info defs */
#define LEFTSTICK 1
#define TOPSTICK 2
#define RIGHTSTICK 4
#define BOTTOMSTICK 8

/*window type defs */
#define WTRACE 11
#define WUNUSED 91

#endif  /* _kdefsh */
