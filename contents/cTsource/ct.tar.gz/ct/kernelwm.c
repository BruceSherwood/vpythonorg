/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>
#include <signal.h> 
#include <sys/types.h>
#include "baseenv.h"
#include "tglobals.h"
#ifdef SYSV
#ifdef LINUX
#include <time.h>
#endif
#include <string.h>
#include <sys/times.h>
#else
#ifdef IBMPC
#include <string.h>
#include <sys\timeb.h>
#include "time.h"
#else
#include <strings.h>
#include <sys/time.h>
#endif
#endif


#ifdef ctproto
int  breakpt(void);
int  breakpt1(void);
int  breakpt2(void);
int  cmdbreakpt(void);
long  TUTORinq_msec_clock(void);
int  TUTORcvt_path(char  *ssx,struct  _fref FAR *fRef,struct  _fref FAR *baseRef,int isFile);
int  FileExists(struct  _fref FAR *fRef);
int  vfclose(struct  _iobuf *fp);
int  fork(void);
double  gamma(double  a);
long  TUTOR_random(void);
int  TUTORovl_log(int  overlay,int  callret);
int  TUTORlog(char  *str);
int  setfptr(int  FAR *aptr,unsigned int  seg,unsigned int  adr);
char  *strf2n(char  FAR *strp);
char  *strnf2n(char  FAR *strp,int  nn);
int  strlenf(char  FAR *aa);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
char  FAR *strcatf(char  FAR *aa,char  FAR *bb);
int  strcmpf(char  FAR *aa,char  FAR *bb);
char  FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
char  FAR *strncatf(char  FAR *aa,char  FAR *bb,int  nn);
int  strncmpf(char  FAR *aa,char  FAR *bb,int  nn);
int  matherr(struct  exception *x);
extern   char *FullName(char *path,char FAR *basefile);
extern void exit(int status);
extern int getpid(void);
/* gettimeofday() */
extern int kill(int pid, int signaln);
/* random(); */
extern sleep(int time);
#ifdef macproto
extern char *strcat(char *aa, char *bb);
extern int strcmp(char *aa, char *bb);
extern char *strcpy(char *aa, char *bb);
extern int strlen(char *str);
extern char *strncat(char *aa, char *bb, int nn);
extern int strncmp(char *aa, char *bb, int nn);
extern char *strncpy(char *aa, char *bb, int nn);
#endif
#ifdef IBMPROTO
int _CDECL fflush(FILE *);
int _CDECL printf(const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

extern char *malloc();
extern char *realloc();
extern char *getenv();
extern  char *FullName();
extern char *strcat();
extern int strcmp();
extern char *strcpy();
extern int strlen();
extern char *strncat();
extern int strncmp();
extern char *strncpy();

long lastmsec = 0;

/* ******************************************************************* */

char *strf2n(aa) /* copy far string to near string */
char FAR *aa;

{
	return(aa);

} /* strf2n */

/* ------------------------------------------------------------------- */

int strlenf(aa) /* length of far string */
char FAR *aa;
{
	return(strlen(aa)); /* no far nonsense on wm */

} /* strlenf */

/* ------------------------------------------------------------------- */

char FAR *strcpyf(aa,bb) /* copy to a far pointer */
char FAR *aa;
char FAR *bb;

{
	return(strcpy(aa,bb)); /* no far nonsense on wm */

} /* strcpyf */

/* ------------------------------------------------------------------- */

char FAR *strncpyf(aa,bb,nn)
char FAR *aa;
char FAR *bb;
int nn;

{
	return(strncpy(aa,bb,nn));

} /* strncpyf */

/* ------------------------------------------------------------------- */

char FAR *strncatf(aa,bb,nn)
char FAR *aa;
char FAR *bb;
int nn;

{
	return(strncat(aa,bb,nn));

} /* strncatf */

/* ------------------------------------------------------------------- */

char FAR *strcatf(aa,bb)
char FAR *aa;
char FAR *bb;

{
	return(strcat(aa,bb));

} /* strcatf */

/* ------------------------------------------------------------------- */

char FAR *strnf2n(ss,nn)
char FAR *ss;
int nn;
	
{
	return(ss);

} /* strnf2n */

/* ------------------------------------------------------------------- */

int strncmpf(s1,s2,nn)
char FAR *s1;
char FAR *s2;
int nn;
	
{
	return(strncmp(s1,s2,nn));

} /* strncmpf */

/* ------------------------------------------------------------------- */

int strcmpf(aa,bb)
char FAR *aa;
char FAR *bb;
	
{ 
	return(strcmp(aa,bb)); 

} /* strcmpf */

/* ******************************************************************* */

long TUTOR_random()

{
	return(random());

} /* TUTOR_random */

/* ******************************************************************* */

#ifdef hp700
char *TUTORdate() { return("--/--/--"); }
char *TUTORtime() { return("--:--:--"); }
double TUTORjdate() { return(0.0); }
#else
/* ******************************************************************* */

char dateStr[10];

static int DD0099(val,str)
int val; /* value to convert */
char *str; /* result string */

{
	if (val < 10)
		*str++ = '0';
	sprintf(str,"%d",val);
	return(val);
	
} /* DD0099 */

/* ******************************************************************* */

char *TUTORdate() 

{ 	unsigned long clock;
	struct tm *timeRec;
	
	time(&clock);
	timeRec = localtime(&clock);
	DD0099(timeRec->tm_mon+1,dateStr);
	dateStr[2] = '/';
	DD0099(timeRec->tm_mday,&dateStr[3]);
	dateStr[5] = '/';
	if (timeRec->tm_year >= 100)
		timeRec->tm_year -= 100;
	DD0099(timeRec->tm_year,&dateStr[6]);
	dateStr[8] = 0;
	return(dateStr); 
	
} /* TUTORdate */

/* ******************************************************************* */


char *TUTORtime() 

{	unsigned long clock;
	struct tm *timeRec;
	
	time(&clock);
	timeRec = localtime(&clock);
	DD0099(timeRec->tm_hour,dateStr);
	dateStr[2] = ':';
	DD0099(timeRec->tm_min,&dateStr[3]);
	dateStr[5] = ':';
	DD0099(timeRec->tm_sec,&dateStr[6]);
	dateStr[8] = 0;
	return(dateStr); 
	
} /* TUTORtime */

/* ******************************************************************* */


double TUTORjdate()

{	long timV;

	time(&timV);
	return((double)timV);
	
} /* TUTORjdate */

#endif

/* ******************************************************************* */

#ifdef SYSV
#ifdef SOLARIS
static long timebase = 0; /* initial seconds, gmt since 1/1/1970 */

long TUTORinq_msec_clock() /* return millisecond clock */

{   struct timeval tv; /* seconds+microseconds */
    struct timezone tz;

    if (!timebase) { /* set initial base time */
	gettimeofday(&tv, &tz);
	timebase = tv.tv_sec;
    } /* timebase if */
    gettimeofday(&tv, &tz); /* get seconds+microseconds */
    tv.tv_sec = tv.tv_sec - timebase;
	lastmsec = (tv.tv_sec * 1000) + (tv.tv_usec / 1000);
	return lastmsec;

} /* TUTORinq_msec_clock */
 
#else /* non-SOLARIS SYSV */
static long timebase = 0; /* initial clock value */

long TUTORinq_msec_clock() /* return millisecond clock */

{   struct tms timev;
    long ctim; 

    ctim = times(&timev); /* get clock in 1/100s second */
    ctim = 10L*ctim;
    if (timebase == 0) timebase = ctim;
	lastmsec = ctim;
    return(ctim);

} /* TUTORinq_msec_clock */
#endif

/* ------------------------------------------------------------------- */

#else

static long timebase = 0; /* initial seconds, gmt since 1/1/1970 */

long TUTORinq_msec_clock() /* return millisecond clock */

{   struct timeval tv; /* seconds+microseconds */
    struct timezone tz;

    if (!timebase) { /* set initial base time */
	gettimeofday(&tv, &tz);
	timebase = tv.tv_sec;
    } /* timebase if */
    gettimeofday(&tv, &tz); /* get seconds+microseconds */
    tv.tv_sec = tv.tv_sec - timebase;
	lastmsec = (tv.tv_sec * 1000) + (tv.tv_usec / 1000);
	return lastmsec;

} /* TUTORinq_msec_clock */
 
#endif

/* ******************************************************************* */

TUTORcvt_path(ssIn,fRef,baseRef,isFile) /* convert ss to full path name */
char *ssIn; /* string containing file name, possibly partial */
FileRef FAR *fRef; /* complete file reference, to be created */
FileRef FAR *baseRef;	/* "current" directory to work from */
int isFile; /* TRUE if includes file name, FALSE if just path */
/* returns TRUE if ss is full path, FALSE otherwise */
	
{	int mlen;
	char tempS[FILEL+2]; /* temporary space */
	char *cp;

	/* we don't want leading spaces */
	while (*ssIn == ' ')
		ssIn++;

	strcpy(tempS,ssIn); /* copy, so that we won't modify input */

	/* strip trailing spaces */
	mlen = strlen(tempS);
	/* strip trailing spaces */
	while (mlen > 0 && tempS[--mlen] == ' ') tempS[mlen] = '\0';

	if (!tempS[0])
		return(FALSE); /* no file name */
	if (tempS[0] != '/') {
		/* not yet a full path, make it one */
		cp = FullName(tempS,baseRef->path);
	} else
		cp = tempS; /* already a full path */

	strcpyf(fRef->path,cp);
	cp = fRef->path + strlen(fRef->path) -1;
	while (*cp != '/')
		cp--;
	fRef->nameInd = (cp-fRef->path) + 1;

	return(TRUE); /* always a full path */

} /* TUTORcvt_path */
/* ******************************************************************* */

double gamma(a)
double a;

{
    return(a);

} /* gamma */

/* ******************************************************************* */

TUTORexit()  /* final exit - terminate job */

{		
	TUTORclose_swap(); /* close/delete swap file */
    exit(0);

} /* TUTORexit */

/* ******************************************************************* */

TUTORtrace(s)			/* print out the string s.  It doesn't need
				 * to be terminated with newline */
char *s;

{
    printf("%s\n", s);
    fflush(stdout);

} /* TUTORtrace */

/* ******************************************************************* */

TUTORtrace_n(s, nn)		/* print out string s & number.  It doesn't
				 * need to be terminated with newline */
char *s;
long nn;

{
    printf("%s %ld\n", s, nn);
    fflush(stdout);

} /* TUTORtrace_n */

/* ******************************************************************* */

TUTORtrace_x(s, nn)		/* print out string s & number.  It doesn't
				 * need to be terminated with newline */
char *s;
long nn;

{
    printf("%s %lx\n", s, nn);
    fflush(stdout);

} /* TUTORtrace_x */


/* ******************************************************************* */

TUTORtrace_n_n(s, nn, mm)	/* print out string s & number.  It doesn't
				 * need to be terminated with newline */
char *s;
long nn;
long mm;

{
    printf("%s %ld %ld\n", s, nn, mm);
    fflush(stdout);

} /* TUTORtrace_n_n */

/* ******************************************************************* */

TUTORtrace_dd(nn)		/* print out a number without return
				 * (followed by space) */
long nn;

{
    printf("%ld ", nn);
    /* fflush assumed done with call to another trace routine */

} /* TUTORtrace_dd */

/* ******************************************************************* */

static int rwf = 0;

TUTORlog(str)   /* write to log file */
char *str;      /* pointer to string to write */

{   FILE *logfp;

    if (rwf == 0) {
    	logfp = fopen("ct.log","w");
        rwf = 1;
    } else {
    	logfp = fopen("ct.log","a");
    } /* else */

    if (logfp == NULL) return(0);
    fprintf(logfp,"%s",str);
    if (str[strlen(str)-1] != '\n')
        fprintf(logfp,"\n");
    fclose(logfp);

} /* TUTORlog */

/* ******************************************************************* */

static int isDumping = FALSE;
TUTORdump(s)
char *s;

{
    int pid;

    if (isDumping) return;
    isDumping = TRUE;

    printf("%s\n", s);
    fflush(stdout);

    /* kill */
    pid = getpid();
    kill(pid, SIGILL);		/* send illegal signal to self */
    sleep(5);

} /* TUTORdump */


/* ******************************************************************* */
