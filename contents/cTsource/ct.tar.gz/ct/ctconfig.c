
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>
#include "baseenv.h"
#include "tutor.h"
#include "compute.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "kglobals.h"

#ifdef ANDREW
#endif /* ANDREW */

/* dummy routines - no point in getting prototypes right */
#undef ctproto

#ifdef ctproto
int  TUTORinq_abs_string_width16(unsigned char  FAR *s,int  lth,int *dx);
int  ctconfig(void);
extern int TMessage(char FAR *s);
extern void longjmp(jmp_buf env, int value);
int  dmpexpr(void);
int  exprmsg(char  *pstr);
int  UnitCodegen(int  unitn);
int icgen68K(void);
int icgenPPC(void);
int FindUnits(void);
int CheckEditOnFile(void);
char *parse_env(void);
extern int DebugAfterStep(int token);
int initsourcet(int i);
int ictcomp(void);
int insertversion(void);
int add_dest(int type, int label, unsigned int pos);
int clearsrc(int domkall);
int add_xref(int kind, int label, Memh aref, Memh adest);
int UserDefinesSetup(int sourcen);
int initedit0(void);
int initeditviews(int ii, FileRef FAR *fref, int *jj);
int initedit(int ww, Memh mm, Memh doc);
int CompileProgram(int wix, int binf, int mflag);
int EditConvert(void);
int CountNeedsCompiled(void);
int procedit(Memh editH, struct tutorevent *cev);
int procdict(Memh editH, struct tutorevent *cev);
int prochelp(Memh editH, struct tutorevent *cev);
int prochelpv(Memh editH, struct tutorevent *cev);
int grafedit(struct tutorevent *evp);
int ChangeEditMenus(int ii);
int editormsg(char *ss, int aFlag);
int LocateUnit(Memh docH,long pos);
int readdoc(Memh doc, FileRef FAR *fRef, int *iswrite);
int  TUTORclear_doc(unsigned int  doc);
extern  int TUTORopen(FileRef FAR *fRef,int rf,int wf,int af);
extern  int TUTORinq_file_info(FileRef FAR *fname,int *waccess,long *length,long *modtim,int *posx,int *posy);
extern  int TUTORclose(int findx);
int  TUTORfread_doc(unsigned int  doc,long  len,int  docKind,int  fInd);
extern int TUTORget_fileref_name(FileRef FAR *fRef, char FAR *name);
extern int TUTORdump(char *s);
int cerror(int errnumber, char *execstr);
extern int TraceMsg(void);
int DebugHalt(void);
#endif /* ctproto */

ctconfig() 
/* establish presence of editor, executor, compiler, mouse */
/* may be called very early - must depend on conditional compile only */

{

#ifndef IBMPC
    ctmouse = TRUE; /* always assume a mouse present */
#endif

#ifdef AUTHOR
    ctedit = TRUE; /* full environment, everything present */
    ctcomp = TRUE; /* -x option will suppress edit window */
    ctexec = TRUE;
#endif

#ifdef EDCOMP
    ctedit = TRUE;  /* editor+compiler */
    ctcomp = TRUE;
    ctexec = FALSE;
#endif

#ifdef CTEDIT
    ctedit = TRUE;  /* editor */
    ctcomp = FALSE;
    ctexec = FALSE;
#endif

#ifdef CTCOMP
    ctedit = FALSE; /* compiler */
    ctcomp = TRUE;
    ctexec = FALSE;
#endif

#ifdef EXECUTE
    ctedit = FALSE; /* executor only */
    ctcomp = FALSE;
    ctexec = TRUE;
#endif

} /* ctconfig */

/* ******************************************************************* */

/* dummy routines for executor */

#ifdef EXECUTE

#include "execdefs.h"

char binaryFileCurrent = 0; /* normally in edglobal */
Memh helpmenus = 0;
Memh dictmenus = 0;
int AuxWn = -1;
struct tutorview FAR *AuxVp = FARNULL;  
int TraceMsg() { return(0); }
struct tutorview FAR *TraceVp = FARNULL;

/* ------------------------------------------------------------------- */

int icgen68K() { return; }
int icgenPPC() { return; }
FindUnits() { return; }
CheckEditOnFile() { return(-1); }
char *parse_env() { return(""); }
initsourcet(i) int i; {return;}
ictcomp() { return; }
insertversion() { return; }
add_dest(type,label,pos) int type,label; unsigned int pos; { return; }
clearsrc(domkall) int domkall; { return; }
add_xref(kind,label,aref,adest) int kind, label; Memh aref,adest; { return; }
UserDefinesSetup(sourcen) int sourcen; { return; }
initedit0() { return; }
initeditviews(ii,fref,jj) int ii; FileRef FAR *fref; int *jj; { return; }
initedit(ww,mm,doc) int ww; Memh mm; Memh doc; { return; }
CompileProgram(wix,binf,mflag) int wix; int binf; int mflag; { return; }
EditConvert() { return; }
int CountNeedsCompiled() { return(0); }
int DebugAfterStep(tt,ntt) int tt; int ntt; { return(0); }
DebugHalt() { return; }

procedit(editH, cev)
Memh editH;
struct tutorevent *cev;
    { return; }

procdict(editH, cev)
Memh editH;
struct tutorevent *cev;
    { return; }

prochelp(editH, cev)
Memh editH;
struct tutorevent *cev;
    { return; }

prochelpv(editH, cev)
Memh editH;
struct tutorevent *cev;
    { return; }

grafedit(evp) struct tutorevent *evp; { return; }
ChangeEditMenus(ii) int ii; {return;}
editormsg(ss,aFlag) char *ss; int aFlag; { return; }
LocateUnit(doc,pos) Memh doc; long pos; { return(0); }

int readdoc(doc,fRef,iswrite) /* read styled document */
Memh doc;   /* document to read into */
FileRef FAR *fRef;
int *iswrite;   /* returned TRUE if document writeable */

{   int findx; /* index in file table for source file */
    FileRef tempRef;
    char cs[CTPATHLEN+40];  /* message buffer */
    int wrtf; /* TRUE if writeable file */
    long smtime; /* time source file last modified */
    int i;  /* work variables */
    long FileL; /* length of file */
    char cvtf; /* CR/LF conversion flag */
    int errf; /* error flag */
    char ctavers[10]; /* .cta file version */
    char *c;

    wrtf = FALSE; /* assume read-only */
    TUTORclear_doc(doc);

    /* attempt to open source file */
    findx = TUTORopen(fRef,TRUE,FALSE,FALSE);
    if (findx) 
        TUTORinq_file_info(fRef,&wrtf,&FileL,&smtime,NEARNULL,NEARNULL);
    *iswrite = wrtf;
    if ((findx == 0) || (FileL <= 0)) {
        if (findx) TUTORclose(findx); /* close source file */
        *iswrite = TRUE; /* new file can be written */
        return(FALSE);
    } /* findx if */

    /* set up styled text document */

    i = TUTORfread_doc(doc,-1L,-1,findx);
    TUTORclose(findx); /* close source file */
    if (i == FALSE) {
        strcpy(cs,"can't read styled document ");
        TUTORget_fileref_name(fRef,(char FAR *) (cs + strlen(cs)));
        TUTORdump(cs);
    }

    return(TRUE);
    
} /* readdoc */

/* ------------------------------------------------------------------- */

cerror(errnumber, execstr) /* compile or execute error */
int errnumber; /* error number */
char *execstr; /* error message string */

{
    runflag = halt; /* insure execution stopped */
    TMessage((char FAR *)execstr); /* display message */
    longjmp(errjmpbuff,1);

} /* cerror */

#endif

/* ******************************************************************* */

/* dummy routines for editor */

#ifdef CTEDIT

/* ------------------------------------------------------------------- */

#ifdef WINPC
int fMoviePlaying = 0;
struct tutorview FAR *TraceVp = FARNULL;
struct tutorview FAR *AuxVp = FARNULL;
int movieInhibitF = 0;

int TraceMsg() { return(0); }
int MovieSupport() { return(0); }
int vControlProc() { return(0); }
#else
int post_toedit() { return(0); }
#endif

int pgen;
int mControllerHasPalette = FALSE;
int AuxWn = -1;

long ControlWndProc() { return(0L); }
int procmsg() { return(0); }
int DebugClearStep() { return(0); }
int TMessage() { return(0); }
VerifyFindUnits() { return; }
write_abs_text() { return; }
openhelp() { return; }
procexecw() { return; }
lclocx() { return; }
lclocy() { return; }
WriteGif() { return; }
read_gif() { return; }
setedittouch() { return; }
EditConvert() { return; }
findmf() { return; }
ClearAuthorFile() { return; }
initexec0() { return; }
initexecw() { return; }
exec_switch_fixup() { return; }
initexec() { return; }
flush() { return; }
Run() { return; }
RunFromUnit() { return; }
Halt() { return; }
FullHalt() { return; }
InitExecution() { return; }
tempmk() { TUTORdump("tempmk called"); }
preexec() { return; }
RunUnitOvl() { return; }
procexec() { return; }
TimedPauseOvl() { return; }
UserDefinesSetup() { return; }
cerror() { return; }
initlex() { return; }
FindUnits() { return; }
SkipLine() { return; }
getrealcommand() { return; }
Seek() { return; }
icompile() { return; }
ictcomp() { return; }
TUTORline_thick() { return; }
dde_proc_unit() { return; }
TellExecInt() { return; }

int qtMovieOpenF = 0;
int fMovieOpen = 0;
int qtControllerHasPalette = 0;
long hwndMovie = 0;

qtProc() { return(0); }
MoviePalette() { return(0); }

#ifndef WINPC
TUTORabs_fill_polygon() { return; }
#endif

/* ------------------------------------------------------------------- */

#endif

/* ******************************************************************* */

/* dummy routines for compiler */

#ifdef CTCOMP


/* ------------------------------------------------------------------- */

TUTORshowt() { return; } 
findmf() { return; } 
TUTORshow() { return; } 
TUTORget_colors() { return; } 
TUTORcount_colors() { return; } 
tempmk() { return; } 
FullHalt() { return; } 
interact() { return; } 
StopProgram() { return; } 
TriggerEventTime() { return; } 
TriggerEvent() { return; } 
SlowCompile() { return(FALSE); }
Halt() { return; } 
CancelTrigger() { return; } 
TUTORpost_event() { return; } 
TellUser() { return; } 
TUTORput_scrap() { return; } 
DecodeText() { return; } 
TUTORmove_abs_rect() { return; } 
TUTORinq_abs_clip_rect() { return; } 
TUTORset_abs_clip_rect() { return; } 
TUTORinq_abs_string_width() { return; } 
TUTORdraw_abs_solid_rect() { return; } 
TUTORdone_startup() { return; }
TUTORset_window() { return; }
settitles() { return; }
initexec0() { return; }
setexectitle() { return; }
TUTORset_view() { return; }
log_init() { return; }
TUTORinit_graf() { return; }
initeditviews() { return; }
ClearAuthorFile() { return; } 
TimedPauseOvl() { return; } 
procdict() { return; } 
prochelp() { return; } 
RunUnitOvl() { return; } 
procexec() { return; } 
RestoreUnit() { return; } 

/* ------------------------------------------------------------------- */

#endif

/* ******************************************************************* */

/* dummy routines for all configurations */

dmpexpr() {return(0);}  /* dummy routine for expression analyzer debug */
exprmsg(pstr) char *pstr; {return(0);}

#ifdef DOSPC
MovieOpen() { return; }
MovieRectangle() { return; }
MoviePlay() { return; }
MovieSupport() { return; }
MovieClose() { return; }
double MovieGetTime() { return(0.0); }
MovieSound() { return; }
#endif

#ifndef MAC
UnitCodegen(unitn) int unitn; { return(0); }
#endif

#ifdef MAC
int  TUTORinq_abs_string_width16(s,lth,dx)
unsigned char  FAR *s;
int  lth;
int *dx;

{
    return(0);
}
#endif

#ifdef ANDREW
#ifndef GENERICSYS
MovieOpen() { return; }
MovieRectangle() { return; }
MoviePlay() { return; }
MovieSupport() { return; }
MovieClose() { return; }
double MovieGetTime() { return(0.0); }
MovieInfo() { return; }
MovieSound() { return; }
MovieStep() { return; }
MovieShow() { return; }
#endif
#endif

#ifdef GENERICSYS
MovieOpen() { return; }
MovieRectangle() { return; }
MoviePlay() { return; }
MovieInfo() { return; }
MovieClose() { return; }
double MovieGetTime() { return(0.0); }
MovieSound() { return; }
CloseMMotionVideo() { return; }
MMotionSet() { return; }
DetermineVideo() { return(0); }
InitMMotionVideo() { return; }
MMotionPlay() { return; }
InitExternalVideo() { return; }
Pi6000Play() { return; }
Pi6000Step() { return; }
Pi6000Set() { return; }
CloseExternalVideo() { return; }
/* versstats() { return; } */
#endif /* GENERICSYS */

#ifdef SYSV
int TUTORopen_serial() { return(0); }
int TUTORinit_swap() { return(0); }
int srandom() { return(0); }
long random() { return(rand()); }
#endif

#ifdef NOSUCHz
/* ? MSC complains of premature end of file if this isn't here ? */
#endif
