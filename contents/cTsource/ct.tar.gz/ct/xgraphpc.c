
/* A component of the cT (TM) programming environment.  */
/* (c) Copyright 1989 Carnegie Mellon University. */
/* cT is a trademark of Carnegie Mellon University. */
/* All rights reserved. */
/* May not be copied without the written consent */
/* of Carnegie Mellon University.  */

/* TUTORgraphics package */

#include "baseenv.h"
#include <stdio.h>  /* C 5.0 library */
#include <float.h>
#include <signal.h>
#include <bios.h>
#include <dos.h>
#ifdef TURBOC
#include <alloc.h>
#else
#include <malloc.h>
#endif
#include <setjmp.h>
#include <process.h>
#include <stdlib.h>
#include <string.h>
#include <sys\types.h>
#include <sys\timeb.h>
#include <sys\stat.h>

#include "time.h"

#include "execdefs.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "eglobals.h"
#include "edglobal.h"
#include "editor.h"
#include "tgraphpc.h"
#include "tfiledef.h"
#include "kglobals.h"

#ifdef ctproto
extern int  FillTrapezoid(int  x1,int  y1,int  dx1,int  x2,int  y2,int  dx2,int  lastF);
int  TUTORabs_fill_polygon(int  npoints,long  *fx,long  *fy);
extern void  PCfill_polygon(int  npoints,long  *xa,long  *ya);
extern struct  poly_edge *merge_sort(struct  poly_edge *list);
extern struct  poly_edge *merge_lists(struct  poly_edge *list1,struct  poly_edge *list2);
int  TUTORabs_fill_disk(int type,long xc,long yc,struct  _trect *rp,int  pFont,int  pChar);
int  displayffv(int  x,int  y,int  op,int  format,double  value);
long  IntToCoord(int  xx);
long  FloatToCoord(double  zz);
int  pc_trapezoid(int  x1,int  y1,int  w1,int  x2,int  y2,int  w2,long  fh,int  c,int  lastF);
long  TUTORinq_font_ptr(int  fontN);
int  RoundCoord(long  xx);
int  TUTORdraw_text(unsigned char  FAR *buf,int  count);
int  TUTORabs_move_to(int  x,int  y);
int  TUTORinq_abs_string_width(unsigned char  FAR *s,int  lth,int  *dx);
/* extern int strlen(char *str);    */
long  lcftoi(double  dv);
extern double sin(double x);
extern double cos(double x);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

/* ******************************************************************* */

extern long TUTORinq_mem_available();
extern  int TUTORpurge_info(unsigned int mm,int ptype,int (*restoreproc)(),int restorearg);
extern  int Be2WriteKDoc(unsigned int theD,long sPos,long ePos,int rFlag,FILE *fOut,char FAR * FAR *mp, long *mLen);
extern  long TUTORinq_font_ptr(int nn);
extern  long lcftoi(double dv);
extern  int ctmain(int argc,char * *argv);
extern  char far *GetPtr(unsigned int mm);
extern  int ReleasePtr(unsigned int mm);
extern  char *FullName(char *file,char FAR *path);
extern  int TUTORset_window(int wid);
extern  char *strf2n(char far *strp);
extern  char far *strcpyf(char far *aa,char far *bb);
extern  char far *strcatf(char far *aa,char far *bb);
extern  char far *strncpyf(char far *aa,char far *bb,int nn);
extern  int strncmpf(char far *aa,char far *bb,int nn);
extern  int strlenf(char far *aa);
extern  char far *strncatf(char far *aa,char far *bb,int nn);
extern  int pd_init(void );
extern  int pd_flush(void );
extern  int pd_menumouse(struct tutorevent *event);
extern  int pd_selectcard(int ww,int card);
extern  int pd_display_bar(int ww);
extern  int pd_enter(int wix);
extern  int pd_restore(void );
extern  int pd_menu_change(int ww);
extern  int pd_item_change(int ww,int cardi);
extern  int pd_find_high_menu(int ww,int type,int card,int position,int priority);
extern  int pd_find_itemdn(int ww,int type,int cardi,int n);
extern  int pd_bar_hit(int ww,int mx);
extern  int pd_card_hit(int ww,int card,int my);
extern double lcfdiv(double aa, double bb);

/* ------------------------------------------------------------------- */

extern  int main(int argc,char * *argv);
extern  int wmg_restore_font(unsigned int unitH,char FAR *up,long uLen,int unitn);
extern int TUTORinit_palette(void );
extern  int TUTORsystem_tasks(void );
extern  int TUTORpoll_events(int block);
extern  int TUTORforward_window(int wix);
extern  int TUTORclose_copyright(void );
extern  int TUTORdone_startup(void );
extern  int TUTORset_program_name(char *pname);
extern  int TUTORhide_window(int wInd);
extern  int TUTORshow_window(int wix);
extern  int TUTORwindow_init(void );
extern  int TUTORsync(void );
extern  int TUTORflush(void );
extern  int machineflush(void );
extern  int TUTORset_event_mask(int eventc,int value);
extern  int TUTORabs_move_to(int x,int y);
extern  int TUTORabs_move(int x,int y);
extern  int TUTORdraw_dot(Coord x1,Coord y1);
extern  int TUTORdraw_line(Coord x1,Coord y1,Coord x2,Coord y2);
extern  int TUTORabs_line_to(int x,int y);
extern  int TUTORline_to(Coord x,Coord y);
extern  int TUTORend_line(Coord x,Coord y);
extern  int TUTORdraw_polyline(int num_pts,Coord *x,Coord *y);
extern  int TUTORdraw_rectangle(Coord x1,Coord y1,Coord x2,Coord y2);
extern  int TUTORdraw_arc(int calledby,Coord xc,Coord yc,Coord x1,Coord y1,Coord x2,Coord y2,double startAngle,double arcAngle,int unbroken);
extern  int TUTORfill_rectangle(Coord x1,Coord y1,Coord x2,Coord y2);
static  int FillTrapezoid(int x1,int y1,int dx1,int x2,int y2,int dx2, int lastF);
extern  int TUTORabs_fill_polygon(int npoints,long *fx,long *fy);
extern  int fill_general(int npoints,int top,Coord *fx,Coord *fy);
extern  int find_fill_extremes(Coord *small,Coord *large,Coord *left,Coord *right,int *top,int npoints,Coord *fx,Coord *fy);
extern  int fill_horizontal(Coord left,Coord right,Coord small);
extern  int fill_vertical(Coord left,Coord small,Coord large);
extern  int horizontal_top(Coord *p_toplength,int *p_itemp,int *p_count,int top,int npoints,Coord *fx,Coord *fy);
extern  int TUTORabs_fill_disk(int type,long xc,long yc,TRect *dr,int pFont, int pChar);
int pc_trapezoid(int x1,int y1,int w1,int x2,int y2,int w2,long fh,int c, int lastF);
static  struct pcfont FAR *pc_fix_font(long fh);
extern  int TUTORinvert_abs_rect(int x1,int y1,int x2,int y2);
extern  int TUTORmove_abs_rect(int x1,int y1,int x2,int y2,int newx,int newy);
extern  int TUTORclear_screen(void );
extern  int TUTORabs_restore_region(long id,int x1,int y1,int x2,int y2);
extern  long TUTORabs_save_region(long id,int x1,int y1,int x2,int y2);
extern  int TUTORbeep(int *ff,int *dur,int *volume,int nbeep);
extern  int TUTORstop_sound(void );
extern  int TUTORset_comb_rule(int rule);
extern  int TUTORpalette(int index,double red,double green,double blue,int defaultindex);
extern  int TUTORinq_palette(int paletteN,int *realN,double *redV,double *greenV,double *blueV);
extern  int TUTORinq_closest_palette(double redv,double greenv,double bluev);
extern  int TUTORrestore_palette(int color);
extern  int TUTORset_foreground_color(int color);
extern  int TUTORset_background_color(int color);
extern  int TUTORset_window_color(int color);
extern  int TUTORcount_colors(void );
extern  long TUTORinq_msec_clock(void );
extern  int TUTORinq_abs_pen_pos(int *x,int *y);
extern  int TUTORput_scrap(unsigned int theDoc,long scrapStart,long scrapEnd);
extern  int TUTORstart_menubar(unsigned int barh);
extern  char far *TUTORzfont(char far *fName);
extern  int ConvertSystemName(char *fName);
extern  int TUTORset_textfont(int jj);
extern  int TUTORmouse_off(void );
extern  int TUTORmouse_on(void );
extern  int TUTORset_cursor(int cInd,int cChar);
static  char far *fontchrmap(struct pcfont far *f,int cc,int *bytesx,int *bytesy,int *hotx,int *hoty);
extern  int TUTORarrow_cursor(int isTemp);
extern  int TUTORset_abs_space_shim(long shim);
extern  int TUTORhilite(int x1,int y1,int x2,int y2);
extern  int TUTORdraw_text(unsigned char far *buf,int count);
extern  int TUTORshim_move(int nMove);
extern  int TUTORtext_flush(void );
extern  int displayffv(int x,int y,int op,int format,double value);
extern  int TUTORnormal_cursor(void );
extern  int TUTORwait_cursor(void );
extern  int TUTORresume_cursor(void );
extern  int TUTORdraw_graphic_icons(char *s);
extern  int TUTORdraw_alpha_icons(char *s);
extern  int TUTORinq_font_info(int *ascent,int *descent,int *maxwidth,int *leading);
extern  int TUTORinq_abs_string_width(unsigned char far *s,int lth,int *dx);
extern  int FSize2Index(int fSize,int defIndex);
extern  int FIndex2Size(int fIndex,int defIndex);
extern  int TUTORexit_machine(void );
extern  int wmg_on(void );
extern  int wmg_off(void );
extern  int wmg_font(long fonth);
extern  int wmg_layout(void );
extern  int wmg_fwd(int wix);
extern  int wmg_arrange(int focus);
extern  int wmg_frame(int wix);
extern  int wmg_outline(int x1,int y1,int x2,int y2,int md);
extern  int wmg_focus(int fwix);
extern  int wmg_hide(int wix);
extern  int wmg_window_pt(int x,int y);
extern  int wmg_wipe(void );
extern  int wmg_xlate_color(int color);
extern  int wmg_color(int fc,int bc);
extern  int TUTORtrace(char *s);
extern  int TUTORtrace_d(char *s,double nn);
extern  int TUTORtrace_n(char *s,long nn);
extern  int TUTORtrace_n_n(char *s,long nn,long mm);
extern  int TUTORtrace_x(char *s,long nn);
extern  int windmp(void );
extern  int TUTORdump(char *s);

extern unsigned char far *sysfont_chrad();
extern char *FullName();
extern char far *pc_np(char far *ptr);
extern long pc_pl(char far *ptr);
extern char far *pc_lp(long addr);
extern int pc_float();
extern int pc_mouse_drv();
extern char FAR *fontchrmap();

extern int lforkf;  /* layout fork flag (-d option) */
extern int twf;     /* dma debug option */
extern int spyf;    /* profiling flag */
extern int codegen; /* compiled code flag */
extern struct sourcefile far *sourcetable;  /* source file names/pointers */

extern int pcv_mouseqi;     /* index in mouse queue */
extern int pcv_mouseq[];    /* mouse queue */
extern int pc_isoff;
extern int pc_wmode;
extern int pc_foregnd,pc_backgnd;

/* ******************************************************************* */

extern int wmg_xo[WINDOWLIMIT];    /* window x origin */
extern int wmg_yo[WINDOWLIMIT];    /* window y origin */
extern int wmg_xs[WINDOWLIMIT];    /* window x size */
extern int wmg_ys[WINDOWLIMIT];    /* window y size */
extern int wmg_next[WINDOWLIMIT];  /* index of next (upper, forwards) window */
extern int wmg_prev[WINDOWLIMIT];  /* index of previous (lower, behind) window */
extern int wmg_obscured[WINDOWLIMIT];   /* TRUE if window obscured */
extern int wmg_hidden[WINDOWLIMIT]; /* TRUE if window hidden */
extern int wmg_select; /* window selected for move/resize operation */
extern int wmg_top;    /* index of topmost window */
extern int wmg_bottom; /* index of bottommost window */
extern int wmg_px;     /* physical x screen size */
extern int wmg_py;     /* physical y screen size */

extern int pd_menualt[WINDOWLIMIT]; /* menus altered table */

extern int pd_mw; /* current window for menu operations */
extern int pd_barheight; /* pull-down menu bar height */
extern int pd_wmctrlw; /* control button width */

struct poly_edge {
    short       y;
    Coord       x, rslope;
    char localMax;  /* TRUE if this edge's ymax is local maximum */
    char unused;
    struct poly_edge *next;
};

struct trap_edge {
    short       x, length;
};

/* ******************************************************************* */

extern Memh wmFonth; /* handle on currently selected text font */
extern struct pcfont far *wmFont; /* currently selected text font */

/* ******************************************************************* */

static FillTrapezoid(x1, y1, dx1, x2, y2, dx2, lastF)   /* fill trapezoid with current pattern */
     /* expects integers, screen coordinates */
int x1, y1, dx1, x2, y2, dx2;
int lastF;  /* if TRUE (the usual case), draw the last line */

{   int sm; /* saved mode */

    sm = CurrentMode;
#ifdef NOSUCHz
    if (sm == SRC_COPY) { /* erase, then write black */
        pc_mode(1); /* mode rewrite */
        pc_trapezoid(x1,y1,dx1,x2,y2,dx2,TUTORinq_font_ptr(patternFont0),patternChar0,lastF);
    } /* mode if */
    else if (sm == NOT_SRC_COPY) { /* fill black, then write white */
        pc_mode(3); /* mode inverse */
        pc_trapezoid(x1,y1,dx1,x2,y2,dx2,TUTORinq_font_ptr(patternFont0),patternChar0,lastF);
    } /* else if mode */
    TUTORset_comb_rule(sm); /* restore mode */
#endif
    pc_trapezoid(x1,y1,dx1,x2,y2,dx2,TUTORinq_font_ptr(patternFont),patternChar,lastF);

} /* FillTrapezoid */

/* ******************************************************** */

TUTORabs_fill_polygon(npoints, fx, fy)

/*   Fills a polygon described by an array of points (fx[i], fy[i]).
fx[i] & fy[i] are already converted to actual screen locations. */

/* fx and fy are actually int (not Coord) on entry */

  int npoints ;
  long fx[] ;  /* arrays for -fill- */
  long fy[] ;
{
    PCfill_polygon(npoints, fx, fy);
} /* TUTORfill_polygon */

static void PCfill_polygon(npoints, xa, ya)
/*
 * Fills a polygon described by an array of points (fx[i], fy[i]) by
 * decomposing it into a series of horizontal trapezoids (working from bottom
 * to top) and filling them with FillTrapezoid fx[i] & fy[i] are already
 * converted to actual screen locations.  This is based on the algorithm in
 * "Fundamentals of Interactive Computer Graphics" by Foley and Van Dam. The
 * major difference is breaking this down by trapezoids instead of
 * scan-lines.
 */
int npoints;
long *xa, *ya;

{   short ii, jj, kk, mm, nedges, ntraps, last_y;
    struct poly_edge edges[FILLPOINTS],*et[FILLPOINTS],*aet,temp_edge,*prev,*curr;
    short y_list[FILLPOINTS];
    struct trap_edge traps[FILLPOINTS / 2];
    int lastF;  /* flag set to TRUE (which is usual) if we should draw bottom of trapezoid */

    xa++;
    ya++; /* this is bogus.  change TUTOR{abs,}fill_polygon */

    /* set up the edges */
    nedges = npoints;
    kk = 0;
    for (ii = 0; ii < npoints; ii++) {
        jj = (ii == npoints - 1) ? 0 : ii + 1;
        if (ya[ii] == ya[jj]) { /* Horizontal edges are ignored */
            nedges--;
        } else {
            if (xa[ii] == xa[jj])
                edges[kk].rslope = coordZero;
            else
                edges[kk].rslope = FloatToCoord((float) (xa[ii] - xa[jj]) / (float) (ya[ii] - ya[jj]));

            if (ya[ii] > ya[jj]) {
                edges[kk].y = ya[ii];
                edges[kk].x = IntToCoord((int)xa[jj]);
                
                /* is this edge's ymax a local maximum? */
                mm = (ii == 0) ? npoints - 1 : ii-1; /* previous point */
                edges[kk].localMax = (ya[mm] <= ya[ii]);
                
                /* find the next point with a different y */
                mm = (jj == npoints - 1) ? 0 : jj + 1;
                while (ya[jj] == ya[mm]) {
                    mm = (mm == npoints - 1) ? 0 : mm + 1;
                }
                if (ya[jj] > ya[mm]) {
                    edges[kk].x += edges[kk].rslope;
                    y_list[kk] = ya[jj] + 1;
                }
                else {
                        y_list[kk] = ya[jj];
                }
            } else {
                edges[kk].y = ya[jj];
                edges[kk].x = IntToCoord((int)xa[ii]);
                
                /* is this edge's ymax a local maximum? */
                mm = (jj == npoints - 1) ? 0 : jj+1; /* point after jj */
                edges[kk].localMax = (ya[mm] <= ya[jj]);
                
                mm = (ii == 0) ? npoints - 1 : ii - 1;
                while (ya[ii] == ya[mm]) {
                    mm = (mm == 0) ? npoints - 1: mm - 1;
                }
                if (ya[ii] > ya[mm]) {
                    edges[kk].x += edges[kk].rslope;
                    y_list[kk] = ya[ii] + 1;
                }
                else {
                        y_list[kk] = ya[ii];
                }       
            }
            edges[kk].next = NULL;
            kk++;
        }
    }

    if (nedges <= 0)
        return; /* all horizontal.  We don't draw because we don't
                    draw the bottom line (which is the only line) */

    /* sort y_list and edges */
    for (ii = 0; ii < nedges - 1; ii++)
        for (jj = ii + 1; jj < nedges; jj++) {
            if (y_list[ii] > y_list[jj]) {
                kk = y_list[ii];
                y_list[ii] = y_list[jj];
                y_list[jj] = kk;
                temp_edge.y = edges[ii].y;
                temp_edge.x = edges[ii].x;
                temp_edge.rslope = edges[ii].rslope;
                temp_edge.localMax = edges[ii].localMax;
                edges[ii].localMax = edges[jj].localMax;
                edges[ii].y = edges[jj].y;
                edges[ii].x = edges[jj].x;
                edges[ii].rslope = edges[jj].rslope;
                edges[jj].y = temp_edge.y;
                edges[jj].x = temp_edge.x;
                edges[jj].rslope = temp_edge.rslope;
                edges[jj].localMax = temp_edge.localMax;
            }
        }

    for (ii = 0; ii < nedges; ii++) {
        et[ii] = NULL;
    }

    /* compact y_list and construct edge table */
    /* nedges will now represent the number of rows in the edge table */
    kk = nedges;
    ii = jj = 0;
    while (jj < kk) {
        if ((ii != jj) && (y_list[ii] != y_list[jj])) {
            ii++;
            y_list[ii] = y_list[jj];
        }
        if (et[ii] == NULL)
            et[ii] = edges + jj;
        else if (et[ii]->x > edges[jj].x) {
            edges[jj].next = et[ii];
            et[ii] = edges + jj;
            nedges--;
        } else {
            prev = et[ii];
            curr = prev->next;
            while (curr && (curr->x < edges[jj].x)) {
                prev = curr;
                curr = curr->next;
            }
            if (curr)
                edges[jj].next = curr;
            prev->next = edges + jj;
            nedges--;
        }
        jj++;
    }

    /* start drawing, working our way up the edge table (et) */
    ii = 1;
    jj = last_y = y_list[0];
    aet = curr = et[0];
    for (ntraps = 0; curr; ntraps++) {
        traps[ntraps].x = RoundCoord(curr->x);
        traps[ntraps].length = RoundCoord(curr->next->x - curr->x);
        curr = curr->next->next;
    }
    for (curr = aet; curr; curr = curr->next) {
        curr->x += curr->rslope;
    }
    jj++;
    
    do {
        kk = 0;

        /* Step 1 */
        /* add new edges */
        if (ii < nedges && jj == y_list[ii]) {
            if (jj != last_y) {
                curr = aet;
                for (ntraps = 0; curr; ntraps++) {
                    if (jj == curr->y && curr->localMax) {
                         /* the bottom of this trapezoid is a maximum, we
                            don't want the last line. */
                        lastF = FALSE;
                    }
                    else
                        lastF = TRUE;
                    FillTrapezoid(traps[ntraps].x, last_y, traps[ntraps].length,
                        RoundCoord(curr->x), jj, RoundCoord(curr->next->x - curr->x),lastF);
                    curr = curr->next->next;
                    }
                last_y = jj + 1;
            }
            aet = merge_lists(aet, et[ii]);
            ii++;
        }
        if (last_y >= jj) {
            curr = aet;
            for (ntraps = 0; curr; ntraps++) {
                traps[ntraps].x = RoundCoord(curr->x);
                traps[ntraps].length = RoundCoord(curr->next->x - curr->x);
                curr = curr->next->next;
            }
        }

        /* Step 2 */
        /* draw */
        
        for (curr = aet; curr; curr = curr->next) {
            if (curr->y == jj) {
                kk++;
                break;
            }
        }
        
        if (kk) {
            curr = aet;
            for (ntraps = 0; curr; ntraps++) {
                if (jj == curr->y && curr->localMax) {
                     /* the bottom of this trapezoid is a maximum, we
                        don't want the last line. */
                    lastF = FALSE;
                }
                else
                    lastF = TRUE;
                FillTrapezoid(traps[ntraps].x, last_y, traps[ntraps].length,
                    RoundCoord(curr->x), jj, RoundCoord(curr->next->x - curr->x),lastF);
                curr = curr->next->next;
                }
            last_y = jj + 1;
        }

        /* Step 3 & Step 4 */
        /* remove old entries & add 1/m to x */
    
        curr = aet->next;
        prev = aet;
        while (curr) {
            if (curr->y == jj)
                prev->next = curr->next;
            else {
                curr->x += curr->rslope;
                prev = prev->next;
            }
            curr = curr->next;
        }

        if (aet->y == jj)
            aet = aet->next;
        else
            aet->x += aet->rslope;
        
        /* Step 5 */
        /* re-sort */
        aet = merge_sort(aet);
        
        /* Step 6 */
        /* increment jj */
        jj++;

    } while (aet || ii < nedges);
}

static struct poly_edge *
merge_sort(list)
    struct poly_edge *list;
{
    struct poly_edge *temp1, *temp2, *prev;

    if (!list || !list->next)
        return (list);

    temp1 = temp2 = list;
    prev = temp1;
    while (temp2 && temp2->next) {
        temp2 = temp2->next->next;
        prev = temp1;
        temp1 = temp1->next;
    }
    prev->next = NULL;
    return (merge_lists(merge_sort(list), merge_sort(temp1)));
}


/* merge two pre-sorted lists. */
static struct poly_edge *
merge_lists(list1, list2)
    struct poly_edge *list1, *list2;
{
    struct poly_edge *head, *curr;

    if (!list1)
        return (list2);
    if (!list2)
        return (list1);

    if (list1->x < list2->x) {
        head = list1;
        list1 = list1->next;
    } else {
        head = list2;
        list2 = list2->next;
    }
    curr = head;
    for (curr = head; list1 && list2; curr = curr->next) {
        if (list1->x < list2->x) {
            curr->next = list1;
            list1 = list1->next;
        } else {
            curr->next = list2;
            list2 = list2->next;
        }
    }
    curr->next = list1 ? list1 : list2;
    return (head);
}


/* ********************************************************** */

TUTORabs_fill_disk(type,xc,yc,rp,pFont,pChar) /* filled disk */
/* partial disks not allowed at present */
int type;
long xc,yc; /* center */
TRect *rp;
int pFont, pChar;

{   long xcenter,ycenter; /* absolute co-ordinates of center */
    long xradius,yradius;
    long cx,cy; /* current x,y */
    long ox,oy; /* previous x,y */
    int angle; /* current angle of rotation */
    double radians; /* angle in radians */
    double degcvt = 3.1415926535897932/180.0;
    int ux1,uy1,ux2,uy2,uw1,uw2; /* upper trapezoid */
    int bx1,by1,bx2,by2,bw1,bw2; /* lower trapezoid */
    int drawf; /* TRUE if will draw trapezoid */
    int maxr; /* max radius */
    int ainc; /* angle increment */

    xradius = (rp->right-rp->left)/2;
    yradius = (rp->bottom-rp->top)/2;
    xcenter = rp->left+xradius;
    ycenter = rp->top+yradius;
    if (yradius == 0) 
    return(0);

    if (xradius > yradius) maxr = xradius;
    else maxr = yradius;

    ainc = 1; /* pre-set increment */
    if (maxr < 45) ainc = 2;
    if (maxr < 30) ainc = 5;

    ox = xradius; /* initial co-ordinates */
    oy = 0;

    /* fill center line of circle */

    ux1 = xcenter-ox;
    ux2 = ux1;
    uy1 = ycenter-oy;
    uy2 = uy1;
    uw1 = 2*ox;
    uw2 = uw1;
    pc_trapezoid(ux1,uy1,uw1,ux2,uy2,uw2,TUTORinq_font_ptr(pFont),pChar,TRUE);

    for (angle=ainc; angle<=90; angle += ainc) {
    radians = degcvt*(double)angle;
    cx = round((double)xradius*cos(radians));
    cy = round((double)yradius*sin(radians));
    ux1 = xcenter-cx;
        ux2 = xcenter-ox;
        uy1 = ycenter-cy;
        uy2 = ycenter-oy;
        uw1 = 2*cx;
    uw2 = 2*ox;
    drawf = (cy != oy);
    if (drawf) {
        uy2 -= 1; /* avoid overlap in mode xor */
        if (cy == (oy+1)) { /* 1 pixel high, use smaller dimension */
        ux2 = ux1;
        uw2 = uw1;
        }
        pc_trapezoid(ux1,uy1,uw1,ux2,uy2,uw2,TUTORinq_font_ptr(pFont),pChar,TRUE);
    }
        bx1 = ux2;
        by1 = ycenter+oy;
        bw1 = uw2;
        bx2 = ux1;
    by2 = ycenter+cy;
    bw2 = uw1;
    if (drawf) {
        by1 += 1; /* avoid overlap in mode xor */
        pc_trapezoid(bx1,by1,bw1,bx2,by2,bw2,TUTORinq_font_ptr(pFont),pChar,TRUE);
        ox = cx;
        oy = cy;
    }
    } /* angle for */

} /* TUTORabs_fill_disk */

#ifdef Nosuchz
/* int  pc_trapezoid(int  x1,int  y1,int  w1,int  x2,int  y2,int  w2,long  fh,int  c, int lastF); */



Coord xcenter, ycenter, radiusx, radius;
  double rotate;
  int nchords, n;
  Coord x, y, newx, newy;
  Coord cosphi, sinphi;
  double phi;
  int lastx, lasty, ix, iy ;
  Coord scalex, scale2;

  /* convert to screen coordinates */
  /* get center-radius description so can use algorithm below */
  xcenter = IntToCoord((rp->left+rp->right)/2);
  ycenter = IntToCoord((rp->top+rp->bottom)/2) ;
  radiusx = IntToCoord((rp->right - rp->left)/2);
  radius = IntToCoord((rp->bottom - rp->top)/2);
  scalex = DivCoord(radiusx,radius);
  /* number of trapezoid slices should depend on radius of y */
  if (radius == coordZero) return(0);


  phi =  1.0/sqrt(CoordToFloat(AbsCoord(radius)));
  nchords = floor(pi/phi);
  phi = pi/nchords;
  cosphi = FloatToCoord(cos(phi));
  sinphi = FloatToCoord(sin(phi));
  x = coordZero;
  y = -radius;

  /* starting point for FillTrapezoid */
  lastx = RoundCoord(xcenter);
  lasty = RoundCoord(ycenter-radius);
  scale2 = 2*scalex;

  for (n=1; n<=nchords; ++n)
   {
    newx = MulCoord(x,cosphi) - MulCoord(y,sinphi);
    newy = MulCoord(y,cosphi) + MulCoord(x,sinphi);

    ix = RoundCoord(xcenter - MulCoord(scalex,newx));
    iy = RoundCoord(ycenter + newy) ;

    FillTrapezoid( lastx, lasty, RoundCoord(MulCoord(scale2,x)),
                         ix, iy, RoundCoord(MulCoord(scale2,newx)),TRUE); 

    x = newx; y = newy;
    lastx = ix ;
    lasty = iy+1;
   }
} /* WMfill_disk */
#endif

/* ******************************************************************* */

displayffv(x,y,op,format,value) /* display formatted floating value */
/* used for putting labels on graphs */
int x;      /* x co-ordinate */
int y;      /* y co-ordinate */
int op;     /* 0 = top, between left and right */
        /* 1 = bottom, between left and right */
        /* 2 = left, between top and bottom */
        /* 3 = right, between top and bottom */
int format;   /* 1 = G, 2 = E */
double value;   /* floating value to display */

{   char s[60];
    int slen, ascent, descent, dx;

    sprintf(s, "%G", value);
    slen = strlen(s);
    TUTORinq_abs_string_width((unsigned char far *) s,slen,&dx);
    ascent = wmFont->ascent;
    descent = wmFont->descent;

    switch (op) {
    case 0:
        x -= (dx >> 1);
        y += ascent;
        break;
    case 1:
        x -= (dx >> 1);
        y -= descent;
        break;
    case 2:
        y += (ascent >> 1);
        break;
    case 3:
        x -= dx;
        y += (ascent >> 1);
        break;
    } /* switch */

    TUTORabs_move_to(x,y);
    TUTORdraw_text((unsigned char far *)s,slen);

} /* displayffv */

/* ************************************************************* */
