
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/


#ifndef _editorh
#define _editorh

#ifndef _baseenvh
#include "baseenv.h"
#endif

#define MSGTEXTL 80 /* message line text length */

typedef struct _tvdat { /* data required for scrollable, editable text */
    Memh self;  /* so the handle can refer to itself */
    struct tutorview FAR *view; /* view on text */
    Memh ebshdrH; /* handle on cT object header (if any) */
    int ebsref; /* reference count on cT object */
    Memh scrollh;   /* horizontal scroll bar */
    Memh scrollv;   /* vertical scroll bar */
    
    long ownerDat; /* some kind of data representing higher level (used by filters) */
#ifdef MAC
#ifdef THINKC5
    int (*KeyFilter)(...); /* key filter */
    int (*ClickFilter)(...);   /* click filter */
#else
    int (*KeyFilter)(); /* key filter */
    int (*ClickFilter)();   /* click filter */
#endif
#else /* MAC */
    int (*KeyFilter)(); /* key filter */
    int (*ClickFilter)();   /* click filter */
#endif
    
    Memh textv; /* handle on ktext view */
    Memh textd; /* handle on text object */
    
    Memh searchPanel;   /* text panel for search */
    Memh searchDoc;     /* doc for searchPanel */
    Memh replacePanel;  /* text panel for replace */
    Memh replaceDoc;    /* doc for replacePanel */
    Memh searchButtons[4];  /* buttons used by search */
    
    Memh nextPanel;     /* next panel in chain of text panels (starts at doc editPanel) */
    
    Memh curActive; /* currently active panel (self, search or replace) */
    TRect absRect; /* absolute (entire panel) rectangle */
    TRect relRect; /* window relative rectangle (for text view) */
    unsigned short minDest; /* minimum destination width */
    char    sizeInfo; /* info to generate relRect (used with relRect) */
    
    short defStyles[NSTYLES];   /* default styles for this view */
    char dduu;
    
    char caretSet;  /* TRUE if next key should be styled */
    short caretStyle[NSTYLES];  /* style of caret (to be used on next key) */

    int alteredc; /* counter incremented on every change */
    int blinkid; /* id of blink timing event */
    char searchState; /* 0: not searchable, 1: normal edit, 2: search string entry, 3: search buttons */
    char readOnly;        /* TRUE if read-only */
    unsigned char eActive;   /* TRUE if view is active */
    unsigned char keySelect; /* TRUE if we are currently doing selection via keys */
    char focusClick;    /* TRUE if current click is focus-change click */
    char doErase; /* TRUE if we should erase panel when it is closed */
    char doFrame; /* TRUE if need a frame around text panel */
    char inhibitState; /* 0 = no inhibit editdraw */
                       /* 1 = inhibit editdraw in effect */
                       /* 2 = draw was inhibited, need to update on allow */                     
	long ihPos,ihLen;		/* editdraw total range of change (in terms of BEFORE change) */
	long ihCpos,ihClen; 	/* editdraw where text was replaced */
	long ihNewC;  			/* editdraw # of new characters that were added */
	long ihSelStart;		/* editdraw where selection should end up */
	long ihSelLen; 
	char ihScroll; 			/* editdraw TRUE if should update scroll bar */
	char ihForce; 			/* editdraw TRUE if should force complete update */                 
                       
    struct tutorColor ecolor; /* color to erase with */
    int newlineH; /* newline height (or zero) */
    int dispMode; /* mode (xor/write/etc) to display, or -1 */
    short selectH; /* the current desired horizontal position of a key select */
    
    int nunits; /* number units in source file */
    Memh unitH; /* handle on unit table */
    
#ifdef MAC
    Memh styleMenu; /* menu bar where styles menus are found */
    short menuStyles[6];    /* current styles shown by menus */
    char haveMStyles[6];    /* TRUE if have style shown by menu */
#endif

    char drawGrow;  /* TRUE if want to draw grow icon */
    char searchDir; /* search direction - TRUE if forward */
    char searchExact; /* TRUE if search should match case */
    char absorbFClick; /* TRUE if absorb focus click */
    char highSel; /* TRUE if will highlight selection region */
    char singleSel; /* TRUE if will select on single click */
    char upHot; /* TRUE if will process hot text on up move */
    /* event units flags */
    /* 0 = no associated unit */
    /* 1 = unit, no argument */
    /* 2 = unit with single pass-by-value argument */
    char hotunitF; /* hot text unit */
	char eventunitF[12]; /*  0 = before event key */
	                     /*  1 = after event key */
	                     /*  2 = before event left-down */
	                     /*  3 = after event left-down */
	                     /*  4 = before event left-up */
	                     /*  5 = after event left-up */
	                     /*  6 = before event right-down */
	                     /*  7 = after event right-down */
	                     /*  8 = before event right-up */
	                     /*  9 = after event right-up */
	                     /* 10 = before event down-move */
	                     /* 11 = after event down-move */  
    int hotunitN; /* unit number for hot text events */
	int eventunitN[12]; /* unit numbers for event units */
    double hotunitA; /* hot unit pass-by-value argument */
	double eventunitA[12]; /* arguments for event units */
} TextVDat;

typedef struct _edat { /* data required for file editor */
    int wid;        /* window index */
    FileRef filename; /* file we are editing */
    Memh textPanel; /* text panel data */
    struct tutorview FAR *view; /* main edit view */
    long checkTime; /* time for next checkpoint */
    unsigned char chkpf;    /* TRUE if checkpoint file created */
    char needCursor; /* TRUE if need to reestablish cursor */
    int compilc;    /* counter value at last compile */
    int savedc, checkptc; /* counters at last save & checkpoint */
    int didall; /* all compiled at some point */
} EditDat;

/* info for scroll bars */
typedef struct _sbarinf {
    long maxPos; /* maximum of scroll bar */
    long curPos; /* current position of scroll bar */
    long rangePos, rangeLen; /* current region of text displayed */
    long selPos, selLen; /* current region of text selected */
} SBarInfo;


#endif  /* _editorh */
