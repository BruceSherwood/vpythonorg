
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>
#include "baseenv.h"
#include "tutor.h"
#include "tglobals.h"
#include "ecglobal.h"

#ifndef setjmp_d
#include "setjmp.h"
#define setjmp_d
#endif

#ifdef ctproto
int  TUTORtrace(char  *s);
extern int TUTORexit(void);
extern char *TUTORalloc(long mm, int abort,char *label);
extern int TUTORzero(char SHUGE *ptr,long length);
extern int myexit(void);
extern int main(int argc, char **argv);
extern int ctmain1(int argc, char **argv);
extern int ctmain2(void);
extern int TUTORunlock_code(void);
extern int interact(int block);
extern int FullHalt(void);
extern int TUTORpost_event(struct tutorevent *event);
extern int start_executor(void);
extern int start_editor(void);
int  TUTORpoll_events(int  block);
extern int TUTORblock_move(char FAR *p1,char FAR *p2,long len);
#endif /* ctproto */

extern jmp_buf errjmpbuff; /* general compile/execution error longjmp */
extern unsigned char interactDepth; /* # of times interact is called recursively */

#ifdef X11
extern int pd_barheight;
#endif

#ifdef MAC
extern int setjmp(jmp_buf env); 
extern int MacFetchBinary(FileRef *fName);
#endif

/* stub main program - call ctmain immediately */

/* ************************************************************************************* */


main(argc,argv)
int argc;
char **argv; 

{	struct tutorevent event;
	
	ctmain1(argc,argv);
		
	TUTORunlock_code(); /* free some memory before allocating compile buffer */
	ctmain2();			/* finish initializations */
	TUTORunlock_code();	/* done with initializations, free up some memory */

#ifndef CTEDIT
	if (setjmp(errjmpbuff)) { /* handle compile/execution error */
		FullHalt();
		if (!ctedit)
			myexit(); /* nothing more to do if executor only */
	} /* setjmp if */
#endif

	TUTORpoll_events(FALSE); /* allow any initial redraws into que */
	if (nosourcelayout)
		start_executor();
	else
		start_editor();
	
	interactDepth = 0; /* top of everything */
	while (1) {	/* main interaction loop */
  		interact(TRUE);  /* blocking input */
	}

} /* main */

/* ************************************************************************************* */

static int start_executor() /* post event to begin execution */

{	struct tutorevent event;
	FileRef fRefTmp;
	FileRef FAR *fRefP; /* alloced cT file ref for jumpout */

	TUTORzero((char FAR *)&event,(long)sizeof(struct tutorevent));
	if (fileSpecified == 1) { /* already know what to do */
		event.type = EVENT_MSG;
		event.window = ExecWn;
		event.value = event.id = event.timestamp = 0;
		event.view = ExecVp;
		event.a1 = exec_run;
		event.eDataP = FARNULL;
		TUTORpost_event(&event);
	} else if (fileSpecified == 0) { 
		TUTORpoll_events(FALSE); /* allow AppleEvent processing */
		if (fileSpecified) return; /* now know file name */
#ifdef EXECUTE
#ifdef MAC
  		if (MacFetchBinary(&fRefTmp)) { /* run dialog to get file name */
			fRefP = (FileRef FAR *)TUTORalloc((long)sizeof(FileRef),FALSE,"fref");
			if (!fRefP) TUTORexit();
			*fRefP = fRefTmp;
		
			/* post jumpout event */

			TUTORzero((char FAR *)&event,(long)sizeof(struct tutorevent));
			event.type = EVENT_MENU;
			event.eDataP = (char FAR *)fRefP;
			event.a1 = exec_jumpout;
			event.window = ExecWn;
			event.view = ExecVp;
    		TUTORpost_event(&event);
  		} else TUTORexit();
#endif
#endif
	}
	return(0);
	
} /* start executor */

/* ************************************************************************************* */

static int start_editor() /* post event to start editor */

{	struct tutorevent event;
	int wix;
	
	TUTORzero((char FAR *)&event,(long)sizeof(struct tutorevent));
	event.type = EVENT_REDRAW;
	event.origin = 3;
	event.window = wix = EditWn[0];
	event.view = EditVp[0];
	event.x = windowsP[wix].wxsize;
	event.y = windowsP[wix].wysize;
#ifdef X11
	event.y -= pd_barheight;
#endif
	TUTORpost_event(&event);

	return(0);
	
} /* start_editor */

/* ************************************************************************************* */