
/* editor menu definitions */

#ifndef edit_quit

#define edit_quit -1            /* quit editor */
#define edit_save edit_quit-1       /* save source file */
#define edit_saveas edit_save-1     /* save source file as another file */
#define edit_search edit_saveas-1   /* start search dialog */
#define edit_searchd edit_search-1  /* search from dialog */
#define edit_searchu edit_searchd-1 /* search for unit */
#define edit_linen edit_searchu-1   /* get/use line number */
#define edit_style edit_linen-1 /* text style*/
#define edit_plain edit_style-1     /* plainest style */
#define edit_undo edit_plain-1      /* undo last operation */
#define edit_cut edit_undo-1        /* cut selected region */
#define edit_copy edit_cut-1        /* copy selected region */
#define edit_clear edit_copy-1      /* erase slected region */
#define edit_region edit_clear-1    /* region selection (cut, copy) */
#define edit_paste edit_region-1    /* paste */
#define edit_replace edit_paste-1   /* replace selected region with paste */
#define edit_comment edit_replace-1 /* comment lines */
#define edit_uncomment edit_comment-1   /* un-comment lines */
#define edit_indent edit_uncomment-1    /* right-indent source code */
#define edit_unindent edit_indent-1 /* un-indent source code */
#define edit_hideunits edit_unindent-1  /* hide selected units in source */
#define edit_showunits edit_hideunits-1 /* show selected units in source */
#define edit_showall edit_showunits-1   /* show all units in source */
#define edit_help edit_showall-1    /* bring up help window */
#define edit_previndex edit_help-1  /* help previous index */
#define edit_print edit_previndex-1 /* print file */
#define edit_compile edit_print-1   /* compile program */
#define edit_switch edit_compile-1  /* switch to another source file */
#define edit_sewind edit_switch-1   /* Mac SE window */
#define edit_command edit_sewind-1  /* to control commands window */
#define edit_inset edit_command-1   /* for adding insets */
#define edit_fcolor edit_inset-1    /* editor foreground color */
#define edit_bcolor edit_fcolor-1   /* editor background color */
#define edit_evlog edit_bcolor-1    /* log events to file */
#define edit_playlog edit_evlog-1   /* replay logged events from file */
#define edit_toexec edit_playlog-1  /* editor->executor transition */
#define edit_run edit_toexec-1      /* run from beginning */
#define edit_runfrom edit_run-1     /* run from selected unit */
#define edit_rununit edit_runfrom-1 /* execute selected unit */
#define edit_selunit edit_rununit-1 /* select unit */
#define edit_execcur edit_selunit-1 /* execute current unit */
#define edit_insertf edit_execcur-1 /* insert a file */
#define edit_execfwd edit_insertf-1 /* bring execute window forward */
#define edit_icon edit_execfwd-1    /* insert icon */
#define edit_open edit_icon-1		/* open new edit window */
#define edit_close edit_open-1		/* close edit window */
#define edit_window edit_close-1	/* select window */
#define edit_prefer edit_window-1	/* preferences */
#define edit_message edit_prefer-1  /* message window */
#define edit_debug edit_message-1	/* enable / disable debugging */
#define edit_about edit_debug-1     /* display "About cT" */

#endif

