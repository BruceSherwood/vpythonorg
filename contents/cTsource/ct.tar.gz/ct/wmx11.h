/* Used as a place holder for X11 versions of cT */


#ifndef FONTMAGIC
/* FONTMAGIC satisfied by fontwmx11.h */

#ifndef FILE
#include <stdio.h>
#endif


enum GraphicsOperations {
	GR_MOVE,
	GR_LINE,
	GR_GETDIMS,
	GR_GETDIMSR,
	GR_SETFUNC,
	GR_SETTTL,
	GR_SETDIMS,
	GR_MOUSECHANGE,
	GR_SETRAWIN,
	GR_DISABLEINPUT,
	GR_ENABLEINPUT,
	GR_SETMOUSEINTEREST,
	GR_RASTEROP,
	GR_RASTERSMASH,
	GR_DELETEWINDOW,
	GR_DEFINEFONT,
	GR_DEFINEFONTR,
	GR_SELECTFONT,
	GR_SETMOUSEPREFIX,
	GR_MYPGRPIS,
	GR_ADDMENU,
	GR_DISABLENEWLINES,
	GR_BITSTOREGION,
	GR_SENDFONT,
	GR_HEREISFONT,
	GR_SETCURSOR,
	GR_SETSPACESHIM,
	GR_SETCHARSHIM,
	GR_DEFINECOLOR,
	GR_HEREISCOLOR,
	GR_SELECTCOLOR,
	GR_HIDEME,
	GR_EXPOSEME,
	GR_SETPROGRAMNAME,
	GR_SETMOUSEGRID,
	GR_DEFINEREGION,
	GR_SELECTREGION,
	GR_ZAPREGIONS,
	GR_SETCLIPRECTANGLE,
	GR_ACQUIREINPUTFOCUS,
	GR_GIVEUPINPUTFOCUS,
	GR_IHANDLEACQUISITION,
	GR_WRITETOCUTBUFFER,
	GR_READFROMCUTBUFFER,
	GR_HEREISCUTBUFFER,
	GR_ROTATECUTRING,
	GR_SAVEREGION,
	GR_RESTOREREGION,
	GR_FORGETREGION,
	GR_HEREISREGION,
	GR_FILLTRAPEZOID,
	GR_ZOOMFROM,
	GR_SETMENUPREFIX,
	GR_LINKREGION,
	GR_NAMEREGION,
	GR_IAMDONZ,
	GR_STUFFCUTBUFFER,
	GR_ZAPFONT,
	GR_USER,			
	GR_CONSTRAINMOUSE,
	GR_SETHELPCALL,
	GR_SWAPCUTBUFFERS,
	GR_IAMRINGMASTER,
	GR_APPENDCUTBUFFERS,
	GR_GETNUMWINS,
	GR_GETNUMWINSR,
	GR_NEWREGION,
	GR_NEWREGIONR,
	GR_DESTROYREGION,
	GR_NEWBITMAP,
	GR_NEWBITMAPR,
	GR_SELECTBITMAP,
	GR_DESTROYBITMAP,
	GR_COPYREGION,
	GR_WRITEREGION,
	GR_READREGION,
	GR_FUNCKEY,		
	GR_ARC, 
    GR_GETMOUSE, 
    GR_GETMOUSER, 
	GR_REGIONTOBITS,	
	GR_REGIONTOBITSR,
	GR_FNSAVEREGION		
};

#define wm_UserOp (0)		
#define wm_MoveTo(x,y) wmx11_dummy()
#define wm_DrawTo(x,y) wmx11_dummy()
#define wm_ArcTo(xend, yend, ccw, a, b, xoff, yoff) wmx11_dummy()
#define wm_SetFunction(f)  wmx11_dummy()


#define		f_black		0
#define		f_white		0
#define		f_invert	0
#define		f_copy		0
#define		f_BlackOnWhite	0
#define		f_WhiteOnBlack	0

int wm_CurrentFunction;

#define wm_SetTitle(s)  wmx11_dummy()
#define wm_SetProgramName(s)  wmx11_dummy()
#define wm_SetHelp(s)  wmx11_dummy()
#define wm_GetDimensions(width,height)   wmx11_dummy()
#define wm_SetDimensions(minx, maxx, miny, maxy) wmx11_dummy()
#define wm_MouseInputToken (0)
#define wm_SawMouse(action,x,y) wmx11_dummy()
#define wm_SetRawInput() wmx11_dummy()
#define wm_DisableInput() wmx11_dummy()
#define wm_EnableInput() wmx11_dummy()
#define wm_RasterOp(sx,sy,dx,dy,w,h) wmx11_dummy()
#define wm_RasterSmash(dx,dy,w,h) wmx11_dummy()
#define wm_ClearWindow() wmx11_dummy()
#define wm_SetMouseInterest(mask) wmx11_dummy()
#define wm_AddMenu(s) wmx11_dummy()
#define wm_StdioWindow() wm_SelectWindow (0)
#define wm_SelectFont(n) wmx11_dummy()
#define wm_SetMousePrefix(p) wmx11_dummy()
#define wm_DisableNewlines() wmx11_dummy()
#define wm_BitsToRegion(id,w,h) wmx11_dummy()
#define wm_RegionToBits(id,w,h) wmx11_dummy()
#define wm_SetCursor(f,c) wmx11_dummy()
#define wm_SetStandardCursor(c) wmx11_dummy()
#define wm_SetSpaceShim(s)  wmx11_dummy()
#define wm_SetCharShim(s)  wmx11_dummy()
#define wm_DefineColor(s,c) wm_DoDefineColor(s,c)
#define wm_SelectColor(c)  wmx11_dummy()
#define wm_SelectColorElement(c,e)  wmx11_dummy()
#define wm_HideMe()  wmx11_dummy()
#define wm_ExposeMe()  wmx11_dummy()
#define wm_SetMouseGrid(n)  wmx11_dummy()
#define wm_DefineRegion(id,x,y,w,h)  wmx11_dummy()
#define wm_SelectRegion(id)  wmx11_dummy()
#define wm_ZapRegions()  wmx11_dummy()
#define wm_SetClipRectangle(x,y,w,h)  wmx11_dummy()
#define wm_AcquireInputFocus()  wmx11_dummy()
#define wm_GiveupInputFocus()  wmx11_dummy()
#define wm_IHandleAcquisition()  wmx11_dummy()
#define wm_WriteToCutBuffer()  wmx11_dummy()
#define wm_ReadFromCutBuffer(n)  wmx11_dummy()
#define wm_RotateCutRing(n)  wmx11_dummy()
#define wm_StuffCutBuffer()  wmx11_dummy()
#define wm_IAmRingMaster(nbuf,nch)  wmx11_dummy()
#define wm_AppendCutBuffers()  wmx11_dummy()
#define wm_SwapCutBuffers()  wmx11_dummy()
#define wm_SaveRegion(id,x,y,w,h)  wmx11_dummy()
#define wm_FnSaveRegion(id,x,y,w,h)  wmx11_dummy()
#define wm_RestoreRegion(id,x,y)  wmx11_dummy()
#define wm_ForgetRegion(id)  wmx11_dummy()
#define wm_HereIsRegion(id,w,h)  wmx11_dummy()
#define wm_FillTrapezoid(x1,y1,w1,x2,y2,w2,f,c)  wmx11_dummy()
#define wm_ZoomFrom(x,y,w,h)  wmx11_dummy()
#define wm_SetMenuPrefix(s)  wmx11_dummy()
#define wm_LinkRegion(newid,oldid)  wmx11_dummy()
#define wm_NameRegion(id,name)  wmx11_dummy()
#define wm_IAmDonZ(name)  wmx11_dummy()
#define wm_RefreshFont(n)  wmx11_dummy()
#define wm_ConstrainMouse()  wmx11_dummy()
#define wm_NumWindows(count,max)   wmx11_dummy()
#define wm_NewRegion()    wmx11_dummy()
#define wm_DestroyRegion(id)  wmx11_dummy()
#define wm_NewBitmap(width, height)	 wmx11_dummy()
#define wm_SelectBitmap(id)	 wmx11_dummy()
#define wm_DestroyBitmap(id)  wmx11_dummy()
#define wm_CopyRegion(from_id,from_left,from_top,to_id,to_left,to_top,w,h)  wmx11_dummy()
#define wm_WriteRegion(id, left, top, w, h, s) wmx11_dummy()
#define wm_ReadRegion(id, left, top, s) wmx11_dummy()
#define wm_GetMousePos(x, y)    wmx11_dummy()

short uarg[6];

struct wm_window_aux {
    struct font *CurFont;
    short   nFonts;
    short   nSlots;
    struct font **font;
    unsigned long hostaddress;
};

struct wm_window {
#ifndef SYSV
#ifndef GENERICSYS
#ifndef LINUX
    struct _iobuf   outs,
                    ins;
#endif
#endif
#endif
    char    inb[200],
            outb[2048];
    struct wm_window_aux a;
};

struct font *CurFont;
struct wm_window *wm_NewWindow(/* host */);
struct wm_window *CurrentUserWindow;
struct wm_window_aux *CurrentUserWindowParameters;
/*   XXX - infile() and outfile() go away */
#ifdef GENERICSYS
#define outfile(w) (0)
#define wm_outfile(w) (0)
#define infile(w) (0)
#define wm_infile(w) (0)
#else
#define outfile(w) (&(w)->outs)
#define wm_outfile(w) (&(w)->outs)
#define infile(w) (&(w)->ins)
#define wm_infile(w) (&(w)->ins)
#endif
FILE *winout;
FILE *winin;
#define WMPORT 0


#define UpMovement	0
#define DownTransition	1
#define UpTransition	2
#define DownMovement	3

#define LeftButton	2
#define MiddleButton	1
#define RightButton	0


struct font *wm_FontStruct ();
struct font *wm_DefineFont ();

#define wm_AtLeft		    1
#define wm_AtRight		    2
#define wm_BetweenLeftAndRight	    4
#define wm_AtTop		  010
#define wm_AtBottom		  020
#define wm_AtBaseline		  040
#define wm_BetweenTopAndBottom	 0100
#define wm_BetweenTopAndBaseline 0200


char *getprofile(/* char *var */);

#define wm_ArrowCursor			'a'
#define wm_GunsightCursor		'g'
#define wm_CrossCursor			'x'
#define wm_HourglassCursor		'H'
#define wm_RightFingerCursor		'f'
#define wm_HorizontalBarsCursor		'h'
#define wm_LowerRightCornerCursor	'l'
#define wm_PaintbrushCursor		'p'
#define wm_UpperLeftCornerCursor	'u'
#define wm_VerticalBarsCursor		'v'
#define wm_DangerousBendCursor		'w'
#define wm_CaretCursor			'|'
#define wm_GrayCaretCursor		'}'
#define wm_WindShieldCursor		'm'

#define wm_FlagRedraw	'R'
#define wm_FlagExpose	'E'
#define wm_FlagKill	'K'
#define wm_FlagHide	'H'
#define wm_FlagColor	'C'
#define wm_FlagIndex	'I'
#define wm_FlagFont	'F'


struct color {
    short index;
    short setsize;
};
struct color *wm_DoDefineColor();


/* High C lies about being an ANSI standard C compiler. */
#if defined(__STDC__) && !defined(__HIGHC__)
#define program(n) char ProgramName[100] = #n ;
#else
#define program(n) char ProgramName[100] = "n";
#endif

#define _flsbuf(c, fp) wm_flsbuf(c, fp)
#define fflush(fp) wm_fflush(fp)

#include "fontwmx11.h" /* font definitions */

#endif
