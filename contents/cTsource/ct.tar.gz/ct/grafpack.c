
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Execute cT pcode -- procedures for graphing commands

Judith N. Sherwood, CMU June 1985
*/

#include "execdefs.h"
#include "eglobals.h"
#include "tglobals.h"

#ifdef ctproto
extern int EqFloat(double v1,double v2);
int  axes(void);
int  gscale(int  plus,int  neg,double  offset,double  max,double  *scale);
extern int  get_maxmin(int  plus,int  neg,double  scale,double  offset,double  *gmax,double  *gmin);
extern int  gadjust_stepsize(double  max,double  min,int  plus,int  neg,double  *stepsize);
extern int  gset_start_end(int  negaxis,int  precise,double  offset,double  max,double  min,double  stepsize,double  *start,double  *end);
int  glabelx(double  majormk,double  minormk,int  ticks,int  precise,int  Ldigits,int  Rdigits,int  labelflag);
int  gmarkx(double  majormk,double  minormk,int  ticks,int  precise,int  Ldigits,int  Rdigits,int  labelflag);
int  glabely(double  majormk,double  minormk,int  ticks,int  precise,int  Ldigits,int  Rdigits,int  labelflag);
int  gmarky(double  majormk,double  minormk,int  ticks,int  precise,int  Ldigits,int  Rdigits,int  labelflag);
int  glscale(int  plus,int  neg,double  *offset,double  max,double  *scale);
int  getlog_maxmin(int  plus,int  neg,double  scale,double  offset,int  *maxlog,int  *minlog);
int  logmarkx(double  majormk,double  minormk,int  ticks,int  precise,int  Ldigits,int  Rdigits,int  labelflag);
int  logmarky(double  majormk,double  minormk,int  ticks,int  precise,int  Ldigits,int  Rdigits,int  labelflag);
int  vbar(long  tx,long  ty,long  width);
int  hbar(long  tx,long  ty,long  width);
int  gset_delta(int  axis,int  logflag,int  decades,double  tminor,double  scale,double  delta,double  *width);
int  gbox(int  tgiven,double  x1,double  y1,double  x2,double  y2,double  thick,int  scaleFirst);
int  garc(int  type,long  xcenter,long  ycenter,double  radius,double  angle1,double  angle2,int  unbroken);
int  gfunct(void);
int  badscale(void);
int  badlabel(void);
extern double fabs(double x);
int  TUTORset_textfont(int  jj);
extern double ceil(double x);
extern double floor(double x);
int  flush(void);
int  TUTORdraw_line(long  x1,long  y1,long  x2,long  y2);
long  IntToCoord(int  xx);
int  setmode(int  m);
int  displayffv(int  x,int  y,int  op,int  format,double  value);
int  lclocx(long  q);
long  FloatToCoord(double  zz);
int  lclocy(long  q);
extern double log10(double x);
long  lcftoi(double  dv);
extern double pow(double x,double y);
int  TUTORfill_rectangle(long  x1,long  y1,long  x2,long  y2);
long  HalveCoord(long  xx);
int  TUTORdraw_rectangle(long  x1,long  y1,long  x2,long  y2);
int  TUTORthick_box(long  x1,long  y1,long  x2,long  y2,long  thick,long  thickx,long  thicky);
int  graph_to_fine(double  gx,double  gy,long  *cx,long  *cy);
int  GraphScale(long  fnx,long  fny,double  *cx,double  *cy);
int  execerr(char  *msgstr);
int  TUTORdraw_arc(int  calledby,long xc,long yc,double radius,long  x1,long  y1,long  x2,long  y2,
 double  startAngle,double  stopAngle,int  unbroken);
int  TUTORfill_disk(int type,long xc,long yc,long  x1,long  y1,long  x2,long  y2);
extern double sin(double x);
extern double cos(double x);
#endif /* ctproto */

#ifdef macproto
extern int sprintf(char *,char *,...);
#endif

/*************************************************/

/***definitions for graphing commands***/

/* The "G" prefix is used for graphing values in general.
    A lower-case "g" is used for graphing values which are local variables.
    The "D" prefix is used for dot (pixel) values.

    DXplus, DYplus lengths of positive axes.  Must be >= 0.
    DXneg and DYneg are the "negative" axes.  Must be <= 0.
        DXplus, DYplus, DXneg, and DYneg are set by -axes-. 

    gXmax & gXmin are the right & left ends of the axis.
    GXoffset is the graph value at the origin (where y-axis crosses).
    GXscale is the number of "dots" for each graphing unit.

            If DXplus=0, gXmax value is interpreted as the left end 
            (becomes gXmin), gXmax is set equal to GXoffset.

    When log scales are used, the right end is forced to a power of 10.
     gXmax, gXmin, and GXoffset are expressed as the power of 10 at
     those positions (i.e., -2, -1, 0, 1, 2 instead of .001, .1, 1, 10, 100).
     GXscale is the number of "dots" for each decade.

        User gives gXmax & GXoffset in -scalex-, and GXscale is set.
        After that, gXmax & gXmin are recalculated when needed.

        If values increase left-to-right, GXscale is positive.
        If values increase from bottom-to-top GYscale is positive.

           ** Same definitions are true for Y values. **
*/


#define lp2 (double)(0.301030)      /* base 10 logs */
#define lp3 (double)(0.477121)      /* used for log labels */
#define lp4 (double)(0.602060)
#define lp5 (double)(0.698970)
#define lp6 (double)(0.778151)
#define lp7 (double)(0.845098)
#define lp8 (double)(0.903090)
#define lp9 (double)(0.954243)

#define epsilon 0.0000001

/************ graphpack commands ************/

/******************   axes   *****************************/

axes()
	{
	TUTORdraw_line(exS.GXorigin+IntToCoord(exS.DXneg), exS.GYorigin, exS.GXorigin+IntToCoord(exS.DXplus), exS.GYorigin);
	TUTORdraw_line(exS.GXorigin, exS.GYorigin-IntToCoord(exS.DYneg), exS.GXorigin, exS.GYorigin-IntToCoord(exS.DYplus));
	exS.outcnt += 4;
	OUTGO; 
	}

 /****************** scaling & labeling ******************/

gscale( plus, neg, offset, max, scale )
   int  plus, neg ;
   double   offset, max, *scale ;
{
  if( (plus - neg) == 0 )    /* no axis at all */
   {*scale = 1 ;  return(0) ; }

  if (max == offset) badscale() ;

  if (plus > 0)    *scale = (double)(plus) / ( max - offset) ; 
  else               *scale = (double)(neg) / ( max - offset) ;
}

static get_maxmin( plus, neg, scale, offset, gmax, gmin)
int  plus, neg ;
double scale, offset ;
double *gmax, *gmin ;  /* values ends of axis */
	{
	/* calculate ends of axes for labeling; these values are not saved */

	/* if there is no positive axis (plus=0), then max is at the origin,
      and min is at the left end */
	/* if there is no negative axis (neg=0), then min is at the origin,
       i.e., min = offset  */

	if (plus > 0 )
		{
		*gmax = (plus/scale) + offset ;
		*gmin = (neg/scale) + offset ;
		}
	else
		{
		*gmin = (neg/scale) + offset ;
		*gmax = offset ;
		}
	
	return(0);
	}

static gadjust_stepsize( max, min, plus, neg, stepsize)
  double   max, min, *stepsize ;
  int  neg, plus ;
    /* if requested stepsize results in intervals of less than 2 dots, */
    /* make stepsize 10 times greater */ 
{double  nsteps;
  while( 1 )
    {nsteps = fabs(max - min) / (*stepsize) ;    /* # intervals requested */
        if( ((plus - neg)/(nsteps) ) <2 )   *stepsize = 10*(*stepsize) ; 
        else     break ; 
       }
}


static gset_start_end(negaxis, precise, offset, max, min, stepsize, start, end) 
int   negaxis, precise ;
double   offset, max, min, stepsize, *start, *end ;
	{
	double  tempX, localepsilon;
	
	/* end is most-positive value, start is most-negative; usually this means */
	/* plotted values go left to right.  Normally the values shown are multiples */ 
	/* of the major mark size.   "precise" forces the axis crossing (origin) to be */
	/* labeled, even if that point is not a multiple of "majormk" */

	localepsilon = stepsize/1000 ;    
	*end = max ;
	if (precise)
		{ /* force a label at the origin */
		if (max > min)
			{ /* make sure label is not beyond end of axis */
 			if (negaxis == 0)
 				*start = offset  ;
			else
				{
				tempX = floor((offset - min+localepsilon) / stepsize) ;
				*start = offset - stepsize*tempX ;
 				}
			}
		else
			{ /* max < min */
			tempX = floor((offset - max+localepsilon) / stepsize) ;
			*start = offset - stepsize*tempX ;
			*end = min ;
			} 
		}
	else if (max > min)
		*start = stepsize*ceil((min-localepsilon)/stepsize) ;
	else
		{
		*start = stepsize*ceil((max-localepsilon)/stepsize) ;
		*end = min ; 
		}
	
	return(0);
	}

glabelx(majormk, minormk, ticks, precise, Ldigits, Rdigits, labelflag)
double majormk, minormk ;         /* major & minor mark intervals */
int ticks ;                   /* type of tick marks */ 
int Ldigits, Rdigits ;    /* digits left & right of decimal */
int precise ;              /* TRUE means start at origin */
int labelflag;   /* not used yet */
	{
	Coord y ;
	int ix, iy ;
	register int displayformat, format ;
	double currentx, start, end, stepsize, localepsilon;
	double value ;
	double gXmax, gXmin ;  /* value at right, left ends of axis */

	/* display labels along the x-axis at majormark intervals */
	/* this routine sends integer, absolute screen coordinates to displayffv */

	if (( (exS.DXplus - exS.DXneg) == 0 ) || (exS.GXscale <= 0))
		{ /* 0-length axis */
		badlabel() ;
		return (0);
		}

#ifdef DOPSCRIPT
	if (pscript ) {sprintf( PSbuff, "\n%% labelx \n") ;  PostScriptOutput( PSbuff ) ;}
#endif

	TUTORset_textfont(exS.baseFont);

	get_maxmin( exS.DXplus, exS.DXneg, exS.GXscale, exS.GXoffset, &gXmax, &gXmin) ;
	stepsize = majormk ;  /* majormk is always positive */
	if ((stepsize == 0.0) || (stepsize == Infinite) || (EqFloat(stepsize,Indefinite)))
	    return(0);	/* no step */
	while (fabs(stepsize * exS.GXscale) < 2 )
		stepsize = stepsize*10.0;

	gset_start_end(exS.DXneg, precise, exS.GXoffset, gXmax, gXmin, stepsize, &start, &end) ;

	localepsilon = stepsize/1000 ;   /* magnitude just needs to be well below stepsize */
	end = end + localepsilon ;        /* leeway for roundoff errors */

	if (exS.DYplus > 0 )
		{     /* labels below X-axis */
		y = exS.GYorigin + IntToCoord(6);
		displayformat = 0;
		}
	else
		{ /* labels above X-axis */
		y = exS.GYorigin - IntToCoord(6);
		displayformat = 1;
		}
	format = ( stepsize < .0001 ) ? 2: 1 ;      /* E-style or G-style */
	iy = lclocy(y) ;
	if (fabs((end-start)/stepsize) > 1000) return(0); /* too many labels */
	for (currentx = start ; currentx<= end ;  currentx += stepsize )
   		{ /* draw all the labels */
   		ix = lclocx(FloatToCoord(exS.GXscale*(currentx-exS.GXoffset)) + exS.GXorigin);

		/* value = (fuzzyeq(currentx, 0.0)) ? 0.0 : currentx ; */
		value = (fabs(currentx) < localepsilon) ? 0.0 : currentx ;
		if (exS.GPolar)
			value = fabs(value);

		displayffv(ix+exS.OffsetX, iy+exS.OffsetY, displayformat, format, value); 

#ifdef DOPSCRIPT
		if(  pscript )     
			{
			sprintf( PSbuff, "(%g) %d %d %d CenterString  \n", value, displayformat, ix, iy ) ;
			PostScriptOutput( PSbuff ) ;
			}
#endif
		}
	gmarkx(majormk, minormk, ticks, precise, 0, 0, 0) ;
	
	return(0);
	}

 
gmarkx(majormk, minormk, ticks, precise, Ldigits, Rdigits, labelflag)
double majormk, minormk ;	/* major & minor mark intervals */
int ticks ;			/* type of tick marks */
int precise ;		/* default (FALSE) means round off labels */
int Ldigits, Rdigits ;		/* (passed on to loglabelx) */ 
int labelflag ;		/* 1 = make labels, 0=marks only */
	{
	int pass ;
	double currentx, start, end, stepsize, localepsilon;
	Coord x, topY, bottomY;
	double gXmax, gXmin ;
	int savemode;

	if ((exS.DXplus - exS.DXneg) == 0)
		return(0) ;    /* 0-length axis   */
	if (majormk == 0)
		return(0);  /* no marks at all */

	savemode = exS.mode;
	if (exS.mode == xormode)
		{ /* don't want to draw in xor, change to write */
		setmode(writemode);
		}

#ifdef DOPSCRIPT
	if (pscript)  {sprintf( PSbuff, "\n%% markx \n") ; PostScriptOutput( PSbuff ) ; }
#endif

	get_maxmin( exS.DXplus, exS.DXneg, exS.GXscale, exS.GXoffset, &gXmax, &gXmin) ;

	for ( pass = 1;  pass <=2; ++ pass )
		{
		if ((pass == 2) && (minormk == 0))
			return (0); /* no minor tickmarks, we're done */

		stepsize = (pass == 1) ? majormk : minormk ;

		gadjust_stepsize(gXmax, gXmin, exS.DXplus, exS.DXneg, &stepsize) ;
		/*  end = gXmax ;    --set in next line */

		gset_start_end(exS.DXneg, precise, exS.GXoffset, gXmax, gXmin, stepsize, &start, &end) ;
		localepsilon = stepsize / 1000 ;
		end = end + localepsilon ;  /* need a bit of leeway for roundoff errors */

		/* ticks=0: little tick marks only                      */
		/* ticks=1: extend major marks to boundaries  */
		/* ticks=2: extend major & minor marks to boundaries */
		/* length of little tick marks is not scaled with graph */

		if ( pass <= ticks )
			{ /* ticks reach side-to-side */
			topY = exS.GYorigin - IntToCoord(exS.DYplus) ;  
			bottomY = exS.GYorigin - IntToCoord(exS.DYneg) ;
			}
		else if (pass == 1)
			{ /* short major tick marks */
			topY = exS.GYorigin - IntToCoord(4);           /* major ticks cross axis */
			bottomY = exS.GYorigin + IntToCoord(4); 
			}
		else if (pass == 2)
			{ /* short minor tick marks */
			topY = exS.GYorigin ;      /* top/bottom orientation doesn't matter*/
			bottomY = (exS.DYplus != 0) ? exS.GYorigin + IntToCoord(4) : exS.GYorigin - IntToCoord(4);  
			}
 
		for (currentx = start ; currentx <= end ; currentx+=stepsize )
			{ /* draw all the tick marks for this pass */
			if ((exS.GPolar) && (ticks >= pass) && (currentx != 0))
				{ /* "extend ticks" for polar draws a broken circle */
				garc(1, exS.GXorigin,exS.GYorigin,currentx, 0.0, 360.0, FALSE) ; 
				}
			else 
				{
				x = exS.GXorigin + FloatToCoord((currentx -exS.GXoffset)*exS.GXscale);
				TUTORdraw_line( x, topY, x, bottomY) ; 
				}
			} 
		} /* end of pass loop */
		
	if (exS.mode != savemode)
		{ /* we changed the mode, restore it */
		setmode(savemode);
		}

	exS.ScreenX = exS.GXorigin;
	exS.ScreenY = exS.GYorigin;
	flush();  /* make sure the marks and labels appear */
	}

glabely(majormk, minormk, ticks, precise, Ldigits, Rdigits, labelflag)
 double majormk, minormk ;  /* major & minor mark intervals */
 int ticks ;            /* type of tick marks */ 
 int Ldigits, Rdigits ;
 int precise ;
 int labelflag ;    /* not used yet */
{Coord x;
  int ix, iy;
  register int displayformat, format ;
 double currenty, start, end, stepsize, localepsilon;
 double value ;
 Coord basepoint ;
 double gYmax, gYmin ;

if( (exS.DYplus - exS.DYneg) == 0  )    /* 0-length axis */
    {badlabel() ;  return(0) ;  }

#ifdef DOPSCRIPT
if( pscript )     
	{sprintf( PSbuff, "\n%% labely \n") ;
	 PostScriptOutput( PSbuff ) ;
	}
#endif

TUTORset_textfont(exS.baseFont);

 get_maxmin( exS.DYplus, exS.DYneg, exS.GYscale, exS.GYoffset, &gYmax, &gYmin) ;

stepsize = majormk ;
#ifndef WINPC
/* something wrong here - this always exits on Windows */
if ((stepsize == 0.0) || (stepsize == Infinite) || EqFloat(stepsize,Indefinite))
	return(0);  /* no step */
#endif
while (fabs(stepsize * exS.GYscale) < 2 )  {stepsize = stepsize*10.0 ;}
localepsilon = stepsize / 1000 ;

 gset_start_end(exS.DYneg, precise, exS.GYoffset, gYmax, gYmin, stepsize, &start, &end) ;
 basepoint = exS.GYorigin + FloatToCoord(exS.GYoffset*exS.GYscale);   /* fine grid point */
 end = end + localepsilon ;     /* leeway for roundoff errors */

 if ( exS.DXplus > 0)   
           { x = exS.GXorigin-IntToCoord(6) ;  displayformat = 3 ; }     /* labels left of Y-axis */
 else     {x = exS.GXorigin+IntToCoord(7) ;  displayformat = 2 ; }    /* labels right of Y-axis */
format = ( stepsize < .0001 ) ? 2: 1 ;      /* E-style or G-style */
 ix = lclocx(x) ;

if (fabs((end-start)/stepsize) > 1000) return(0); /* too many labels */
for (currenty=start ; currenty<=end ;  currenty += stepsize)
   {iy = lclocy(exS.GYorigin-FloatToCoord(exS.GYscale * (currenty-exS.GYoffset))) ;

     /* value = (fuzzyeq(currenty, 0.0)) ? 0.0 : currenty ; */
     value = (fabs(currenty) < localepsilon) ? 0.0 : currenty ;

     if (exS.GPolar)  value = fabs(value) ;

     displayffv(ix+exS.OffsetX,  iy+exS.OffsetY, displayformat, format, value);
 
#ifdef DOPSCRIPT
     if( pscript )     
	{sprintf( PSbuff, "(%G) %d %d %d LabelYAxis \n", value, displayformat, ix, iy ) ;
	 PostScriptOutput( PSbuff ) ;
	}
#endif
    }

 gmarky(majormk, minormk, ticks, precise, 0, 0, 0) ;
}
  
gmarky(majormk, minormk, ticks, precise, Ldigits, Rdigits, labelflag)
 double majormk, minormk ;  /* major & minor mark intervals */
 int ticks ;            /* type of tick marks */
 int precise ;          /*FALSE means round off labels */ 
 int Ldigits, Rdigits ;     /* (passed on to loglabelx) */ 
 int labelflag ;       /* 1 = make labels, 0=marks only; not used yet */
{int pass ;
 double currenty, start, end, stepsize, localepsilon;
 Coord y, leftX, rightX ;
 double gYmax, gYmin ;
 int savemode ;

 if( (exS.DYplus - exS.DYneg) == 0 )   return (0);       /* 0-length axis */
 if (majormk == 0)    return(0);                     /* no marks at all */

 savemode = exS.mode;
 if (exS.mode == xormode) setmode(writemode); 

#ifdef DOPSCRIPT
 if( pscript )   
	{sprintf( PSbuff, "\n%% marky \n") ;
		 PostScriptOutput( PSbuff ) ;
	}
#endif

 get_maxmin( exS.DYplus, exS.DYneg, exS.GYscale, exS.GYoffset, &gYmax, &gYmin) ;

 for ( pass = 1;  pass <=2; ++ pass )
   {if ((pass==2) && (minormk==0))  return(0) ;

     stepsize = (pass == 1) ? majormk : minormk ;
     while( fabs(stepsize*exS.GYscale) < 2 )  {stepsize = stepsize*10.0 ; }
     localepsilon = stepsize / 1000 ;

     gset_start_end(exS.DYneg, precise, exS.GYoffset, gYmax, gYmin, stepsize, &start, &end) ;
     end = end + localepsilon ;     /* leeway for roundoff errors */

    /* ticks=0: short ticks */
    /* ticks=1: extend major marks to boundaries  */
    /* ticks=2: extend major & minor marks to boundaries */

    if (pass <= ticks)       /* ticks reach side-to-side */
        {leftX = exS.GXorigin + IntToCoord(exS.DXplus);  
          rightX = exS.GXorigin + IntToCoord(exS.DXneg);
        }

    else if (pass == 1) 	/* short major tick marks */
        {leftX = exS.GXorigin - IntToCoord(4) ;           /* major ticks cross axis */
          rightX = exS.GXorigin + IntToCoord(4); 
        }

    else if (pass == 2)       /* short minor tick marks */
        {rightX = exS.GXorigin ;      /* left/right orientation doesn't matter*/
          leftX = (exS.DXplus != 0) ? exS.GXorigin - IntToCoord(4) : exS.GXorigin + IntToCoord(4) ;  
        }

    for (currenty = start ; currenty <= end ;   currenty +=stepsize )
       {  /* gcircle for "extend ticks" should be drawn by markx.*/
           /*  If marky is to do something, I suppose it should draw radians. */
         if ((exS.GPolar) && (ticks >= pass))  { /* do nothing */ }

         else
           {y = exS.GYorigin - FloatToCoord((currenty -exS.GYoffset)*exS.GYscale);
             TUTORdraw_line( leftX,  y, rightX, y ) ; 
           }
        }
    } 
  if (exS.mode != savemode)
  	setmode(savemode) ;
  exS.ScreenX = exS.GXorigin ; 
  exS.ScreenY = exS.GYorigin ;
 flush();  /* make sure the marks and labels appear */
}



/**** log base 10 scales & labeling ***/

glscale( plus, neg, offset, max, scale )
    int  plus, neg ;              /* axis length */
    double  *offset;     /* power of 10 of origin */ 
    double max ;         /* values at end of axis */
    double *scale ;     /* scale = # of pixels per decade */
{ double   temp ;      /* power of 10 of right end  */

   if ( plus > 0 )      /* normally have positive axis, max is end */
        {temp = ceil(log10(max) - epsilon) ;       /* "maxlog" */
          *offset = ceil(log10(*offset) - epsilon ) ;
          *scale =  (double)(plus) / (temp - *offset) ;
         }
  else
        {temp = floor(log10(max) + epsilon) ;  /* left/lower end */
          *offset = ceil(log10(*offset)) ;
          *scale = (double)(neg) / (temp - *offset) ;
         }
}


getlog_maxmin( plus, neg, scale, offset, maxlog, minlog)
  int  plus, neg ;
  double scale, offset ;
  int *maxlog, *minlog ;

{if (plus > 0 )  *maxlog = round((plus/scale) + offset) ;
  else             *maxlog = offset ;

  if (neg == 0 ) *minlog = offset ;
  else               *minlog = ceil(neg/scale) + offset ;
}


logmarkx(majormk, minormk, ticks, precise, Ldigits, Rdigits, labelflag)
 double majormk, minormk ;  /* major & minor mark intervals */
 int ticks ;            /* type of tick marks */
 int precise ;          /* (not used for log labels) */
 int Ldigits, Rdigits ;     /* (passed on to loglabelx) */
 int labelflag ;       /* 1 = make labels, 0=marks only */
{double temp;
 Coord upperY, lowerY ;
 int i, j, start, end;
 Coord itemp, basepoint ;
 int savemode ;
 Coord x, y, ytop, ybottom ;
 int ix, iy ;
 int gXmaxlog, gXminlog ;
 double value ;
 int displayformat ;

#ifdef DOPSCRIPT
 if( pscript )   
	{sprintf( PSbuff, "\n%% log markx \n") ;
	 PostScriptOutput( PSbuff ) ;	
	}
#endif

 savemode = exS.mode;
 if (exS.mode == xormode) setmode(writemode); 

 /* Find powers at right and left ends of axes. */
 /* (If DXneg not 0, gXminlog is not necessarily at the end.) */
 getlog_maxmin( exS.DXplus, exS.DXneg, exS.GXscale, exS.GXoffset, &gXmaxlog, &gXminlog) ;

 /* if some marks extend to edges, find upper & lower Y */
 if ( ticks > 0 )  {upperY =exS.GYorigin -IntToCoord(exS.DYplus);  lowerY =exS.GYorigin -IntToCoord(exS.DYneg);}

 /* ticks for major marks */
 if (ticks == 0)    {ytop = exS.GYorigin -IntToCoord(4) ;  ybottom = exS.GYorigin+IntToCoord(4) ;}
 else                  {ytop = upperY ;      ybottom = lowerY ; }

 /* set start & end so that end > start */
 if ( gXmaxlog > gXminlog )  {start = gXminlog ;  end = gXmaxlog ; }
 else                                    {start = gXmaxlog ;  end =  gXminlog ;  }

 /* all points relative to point where "1" would be plotted */
 basepoint = exS.GXorigin - FloatToCoord(exS.GXoffset*exS.GXscale);
 itemp = exS.GXorigin + IntToCoord(exS.DXneg) ;    /* left end of axis */

 /** display major marks **/
 for (i=start ;  i <= end;  ++i) 
     {x = basepoint + FloatToCoord(i*exS.GXscale) ;
       if (x >= itemp) 
              TUTORdraw_line(x, ytop, x, ybottom ) ; 
      } 

 /* if DXneg != 0, allow minor ticks to continue past leftmost label */
 if (exS.DXneg != 0 )
      {if ( gXmaxlog > gXminlog )  start = gXminlog - 1 ;
        else                                    end =  gXminlog ;
      }

 /** display minor marks **/
 if ( minormk > 0 )          /* no ticks if minormk = 0 */
      /* ticks for minor marks */
   {if (ticks <= 1)    
         {ytop = exS.GYorigin; 
           ybottom = (exS.DYplus >0) ? exS.GYorigin+IntToCoord(4) : exS.GYorigin-IntToCoord(4) ; 
         }
     else                  {ytop = upperY ;  ybottom = lowerY ; }

     for (i=start;  i <end;  ++i)    /* loop through each decade */
        {for (j=2;  j<=9;  ++j) 
                {temp = 0;
                 switch ( j )  
                        {case 2:  temp = lp2;  break;
                          case 3:  if (minormk>3) temp = lp3; break;
                          case 4:  if (minormk>5) temp = lp4; break;
                          case 5:  temp = lp5;  break;
                          case 6:  if (minormk>5) temp = lp6; break;
                          case 7:  if (minormk>3) temp = lp7; break;
                          case 8:  if (minormk>5) temp = lp8; break;
                          case 9:  if (minormk>5) temp = lp9; break;  
                         }
                 if (temp != 0) 
                       {x =  basepoint + FloatToCoord(exS.GXscale*(i+temp));
                         if (x >= itemp )    /* point might be left of axis end */
                            TUTORdraw_line(x, ytop, x, ybottom) ; 
                       } 
                } 
          }
     }

/** display labels -- log scales are labeled only at the decades **/

if( labelflag==1) 
   {
#ifdef DOPSCRIPT
   if( pscript )   
	{sprintf( PSbuff, "\n%% log labelx: \n") ;
	 PostScriptOutput( PSbuff ) ;
	}
#endif

     TUTORset_textfont(exS.baseFont); 

     if (exS.DXneg != 0 )   /* reset to original start, end */
          if ( gXmaxlog > gXminlog )  start = gXminlog ;

     y = exS.GYorigin ;
     if ( exS.DYplus > 0)
               {y += 5 ; displayformat = 0 ; }    /* labels below X-axis */
     else    {y -= 3 ; displayformat = 1 ; }     /* labels above X-axis */
     iy = lclocy( y ) ;

     value = pow(10.0, (double)(start) ) ;

   /** display labels at each decade  (labelx) **/

     for (i=start;  i <= end;  ++i)
        {x = basepoint + FloatToCoord(i*exS.GXscale);
          if (x >= itemp) 
            {ix = lclocx(x) ;
             displayffv( ix+exS.OffsetX, iy+exS.OffsetY, displayformat, 1, value);

#ifdef DOPSCRIPT
             if( pscript )   
		{sprintf( PSbuff, "(%g) %d %d %d CenterString \n", value, displayformat, ix, iy ) ;
		 PostScriptOutput( PSbuff ) ;
		}
#endif
            }

         value = 10*value ; 
        }
    }

 if (exS.mode != savemode)  setmode(savemode); 
 exS.ScreenX = exS.GXorigin ;
 exS.ScreenY = exS.GYorigin ;
}
 

logmarky(majormk, minormk, ticks, precise, Ldigits, Rdigits, labelflag)
 double majormk, minormk ;  /* major & minor mark intervals */
  int ticks ;		/* type of tick marks */
 int precise ; 		/* (not used for log labels) */
 int Ldigits, Rdigits ; 	/* not used yet */
 int labelflag ;		/* 1 = make labels, 0=marks only */
{Coord leftX, rightX ;
 double temp;
 int i, j, start, end ;
 int savemode;
 Coord x, y, xleft, xright ;
 int  gYmaxlog, gYminlog ;
 Coord basepoint, itemp;
 int  ix, iy, displayformat;
 double  value ;

#ifdef DOPSCRIPT
 if( pscript )   
	{sprintf( PSbuff, "%% log marky: \n") ;
	 PostScriptOutput( PSbuff ) ;
	}
#endif

 savemode = exS.mode;
 if (exS.mode == xormode) setmode(writemode);

 getlog_maxmin( exS.DYplus, exS.DYneg, exS.GYscale, exS.GYoffset, &gYmaxlog, &gYminlog) ;

 /* if some marks extend to edges, find rightX, leftX */
 if ( ticks > 0 )  {rightX = exS.GXorigin + IntToCoord(exS.DXplus);    leftX = exS.GXorigin + IntToCoord(exS.DXneg) ; }

 /* ticks for major marks */
 if (ticks == 0)   {xleft = exS.GXorigin - IntToCoord(4) ; xright = exS.GXorigin + IntToCoord(4) ;}
 else                 {xleft = leftX ;   xright = rightX ; }

 /* set start & end so that end > start */
 if (gYmaxlog > gYminlog )   {start = gYminlog ;  end = gYmaxlog ; }
 else                                   {start = gYmaxlog;  end = gYminlog ; }

 /* all points are calculated relative to the point where "1" (i.e., 10^0) 
     would be plotted */
 basepoint = exS.GYorigin + FloatToCoord(exS.GYoffset*exS.GYscale);
 itemp = exS.GYorigin - IntToCoord(exS.DYneg) ;           /* bottom of axis */

 /* display major marks */
 for (i=start;  i <= end;  ++i)
     {y = basepoint - FloatToCoord(i*exS.GYscale);
       if ( y <= itemp )  TUTORdraw_line( xleft, y, xright, y ) ;
     }

 /* if DYneg != 0, allow minor ticks to continue past bottom label */
 if (exS.DYneg != 0 )
      {if ( gYmaxlog > gYminlog )   start = gYminlog - 1 ;
        else                                    end = gYminlog ;
      }

 /* display minor marks */
 if ( minormk >= 0 ) 
 {if  ( ticks <= 1 )    
      { xright = exS.GXorigin ;
         xleft = (exS.DXplus>0) ? exS.GXorigin-IntToCoord(4) : exS.GXorigin+IntToCoord(4) ; 
      }
   else     {xleft = leftX ;   xright = rightX ; }

  for (i = start;  i < end;  ++i)
   {for (j=2;  j<=9;  ++j) 
      {temp = 0;
        switch ( j )  
          {case 2:  temp = lp2;  break;
            case 3:  if (minormk>3.0) temp = lp3; break;
            case 4:  if (minormk>5.0) temp = lp4; break;
            case 5:  temp = lp5;  break;
            case 6:  if (minormk>5.0) temp = lp6; break;
            case 7:  if (minormk>3.0) temp = lp7; break;
            case 8:  if (minormk>5.0) temp = lp8; break;
            case 9:  if (minormk>5.0) temp = lp9; break;  
           }

       if (temp != 0)
            {y = basepoint - FloatToCoord(exS.GYscale*(i+temp));
              if (y <= itemp)   TUTORdraw_line( xleft, y, xright, y ) ;
             }
       } 
   } 
}

/** display labels at each decade  (labely) **/

if ( labelflag == 1)
   {
#ifdef DOPSCRIPT
   if( pscript )   
	{sprintf( PSbuff, "%% log label y\n") ;
	 PostScriptOutput( PSbuff ) ;
	}
#endif

    TUTORset_textfont(exS.baseFont);

     /* reset to original start, end */
     if ((exS.DYneg != 0) & (gYmaxlog > gYminlog))   start = gYminlog ;

     x = exS.GXorigin ;
     if ( exS.DXplus > 0)
               {x -= 6 ; displayformat = 3 ; }           /* left of Y-axis */
     else    {x += 4 ; displayformat = 2 ; }          /* right of Y-axis */
     ix = lclocx( x ) ;

     value = pow(10.0, (double)(start) ) ;

     for (i=start;  i <= end;  ++i)
        {y = basepoint - FloatToCoord(i*exS.GYscale);
          if ( y <= itemp )
             {iy = lclocy( y ) ;
               displayffv(ix+exS.OffsetX, iy+exS.OffsetY, displayformat, 1, value);

#ifdef DOPSCRIPT
              if( pscript )   
		{sprintf( PSbuff, "(%g) %d %d %d LabelYAxis \n", value, displayformat, ix, iy ) ;
	 	PostScriptOutput( PSbuff ) ;
		}
#endif
             }

         value = value*10 ;
        }
    }
 
 if (exS.mode != savemode) setmode(savemode); 
 exS.ScreenX = exS.GXorigin ;
 exS.ScreenY = exS.GYorigin ;
}

/**************** end of scaling & labeling *******************/


vbar(tx, ty, width)	/* expects fine grid coordinates */
 Coord tx, ty, width ;

/* vertical bar from x-axis to point tx,ty;  
    bar width is centered on tx; width is set by -delta-. 
    bar is filled with the current pattern ;  */ 

{Coord  x  ;

 x = tx  - HalveCoord(width);
 
 TUTORfill_rectangle(x, exS.GYorigin, x+width, ty) ; 

/* current x,y updated in execute1.c only after final point */ 
/*   ScreenX = tx ;   ScreenY = ty ;  */
 }


hbar(tx, ty, width)               /* expects fine grid coordinates */
 Coord  tx, ty, width ;       /* I think maybe hbar is one dot too short?  */

{Coord  y ;

 y = ty - HalveCoord(width);

 TUTORfill_rectangle(exS.GXorigin, y, tx, y+width) ; 

/* current x,y updated in execute1.c only after final point */ 
/*   ScreenX = tx ;   ScreenY = ty ;  */
}

gset_delta( axis, logflag, decades, tminor, scale, delta, width )
   int  axis, logflag, decades ;
   double  tminor, scale, delta, *width ;
{
   /* This routine sets the "thickness" of the horizontal or vertical bar.
       -delta- defaults to 0; can be set by program.
       For non-log scales:
  	If delta is not 0, width = delta. 
   	If delta = 0, then width = minor mark interval. 
 	If minor mark = 0, then width = 5% of axis length.
        For log scales:
	If delta is not 0, delta(= width) is interpreted as % of 1 decade.
	If delta = 0, width is 10% of 1 decade 
   */

 if(logflag)              /* log scales */
   {if ( delta != 0 )       *width = 0.01*delta*axis/decades ; 
     else                      *width = 0.1 * axis/decades ;
   }
 else  		/* x,y coordinates; no accommodation for polar */
   {if  ( delta !=0 )       *width = fabs(delta*scale) ;     
    else
        {if ( tminor == 0)  *width = 0.05*axis ;
          else                   *width = fabs(tminor*scale) ;
         }
    }

 *width = (*width < 1) ? 1 : *width ;     /* let it shrink to nothing ? */
}

gbox(tgiven, x1,y1,x2,y2,thick,scaleFirst)
/* expects graph coords */
/* ScreenX, ScreenY on completion are first point mentioned */
double x1,y1, x2,y2, thick ;
int tgiven;  /* TRUE if thickness given specifically */
int scaleFirst; /* TRUE if first point needs scaling */
	{
	Coord thickx, thicky ;
	Coord c1, c2, c3, c4;
	
	if (scaleFirst)
		graph_to_fine(x1, y1, &c1, &c2);
	else
		{
		c1 = x1;
		c2 = y1;
		GraphScale(FloatToCoord(x1),FloatToCoord(y1),&x1,&y1);
		}
	graph_to_fine(x2, y2, &c3, &c4);
	
	exS.ScreenX = c1;
	exS.ScreenY = c2;

	if (thick==0)
		return(0);
  
	/* is thick large enough to fill entire box? */
	if (thick < 0) 
		{
		if ( ( fabs(thick) > (fabs(x1-x2)+1)/2)  ||  ( fabs(thick) > (fabs(y1-y2)+1)/2) )
			{
			TUTORfill_rectangle(c1,c2,c3,c4);
			return(0) ; 					 /* exit */
			}
		}

	/** special exit conditions finished **/


	if (tgiven)
		{
		thickx = FloatToCoord(fabs(exS.GXscale) * thick);
		thicky = FloatToCoord(fabs(exS.GYscale) * thick);
		TUTORthick_box(c1,c2,c3,c4, FloatToCoord(thick), thickx, thicky) ;
		}
	else
		TUTORdraw_rectangle(c1, c2, c3, c4) ;
	
	return(0);
	}

/***************  gcircle  &  gdisk  ************/

garc(type, xcenter, ycenter, radius, angle1, angle2, unbroken)
  int type ;  		/* 1 if circle, 2 if arc, 3 if disk */
         /* circle/arc distinction useful for postscript */
Coord xcenter, ycenter;
  double radius ;
  double angle1, angle2 ;	 /* angle1 and angle2 are in degrees */
  int unbroken ;		 /* true if -rcircle-, false if -rcircleb- */
 {Coord x1, y1, x2, y2;

	if (radius == 0.0) {
		TUTORdraw_dot(xcenter,ycenter);
		return(0);
	}
  if (angle1 == angle2) return(0);

  if ( exS.GYscale > 0)  {angle1 = 360.0 - angle1;   angle2 = 360.0 - angle2; }
  /* graph scales are in the opposite sense from absolute & relative */
  
  /* after circle, position at center; after arc, position at end of arc */
  if ( type == 2 )
      {exS.ScreenX = xcenter + FloatToCoord(exS.GXscale*radius*cos(angle2*RDN));
        exS.ScreenY = ycenter + FloatToCoord(exS.GYscale*radius*sin(angle2*RDN));
      }
  else
      {exS.ScreenX = xcenter ;
        exS.ScreenY = ycenter ;
       }

  x1 = xcenter-FloatToCoord(exS.GXscale*radius);
  y1 = ycenter-FloatToCoord(exS.GYscale*radius);
  x2 = xcenter+FloatToCoord(exS.GXscale*radius);
  y2 = ycenter+FloatToCoord(exS.GYscale*radius);

  if (type == 3 )
   TUTORfill_disk(0,xcenter,ycenter,x1, y1, x2, y2);
 else
  TUTORdraw_arc(2,xcenter, ycenter, radius,x1, y1, x2, y2, angle1, angle2, unbroken);
}

/* dummy function */
gfunct()
 { }

/********** specific graphing error messages ************/

badscale()
  {execerr( "Axis maximum cannot equal value at origin");  }

badlabel()
  {execerr( "Bad axes or label value.") ;  }
