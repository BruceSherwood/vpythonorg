
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/


/* Part of the TUTORgraphics package for cT */

#include "baseenv.h"
#ifdef MAC
#include <stdio.h>
#endif
#ifdef ANDREW
#include <stdio.h>
#endif
#include "tglobals.h"
#include "ecglobal.h"
#include "kglobals.h"
#include "fkeys.h"
#include "eglobals.h"
#include "commands.h"

#ifdef ctproto
int  TUTORalert(int  wn,char  *msg);
extern int cTOrderPalette(struct CTcolorentry FAR *cTPaletteP); 
static int PaletteOrder(struct CTcolorentry FAR *cTPaletteP,int nEntries,int newPos,
	unsigned int red,unsigned int green,unsigned int blue);
extern int PaletteMatch(struct CTcolorentry FAR *paletteP,int nColors,
           unsigned int redC,unsigned int greenC,unsigned int blueC);
extern int TUTORfree_palette(Memh palH);
extern Memh TUTORalloc_palette(int pSlots);
extern int TUTORmem_alert(void);
int  strcmpf(char  FAR *aa,char  FAR *bb);
extern int TUTORinq_region_info(long regionID,int *width,int *height);
extern void TUTORset_color(int select,struct tutorColor FAR *newColor);
static unsigned char FAR *next_str(unsigned char SHUGE *cP,int *retV);
long  TUTORwrite(char  FAR *ptr,int  pSize,long  count,int  findx);
extern int TUTORfile_region_ppm(FileRef FAR *fRef,long regionID);
extern Memh TUTORget_rgb_region(long regionID);
extern long TUTORmem_to_region(int type,int width,int height,Memh palH,unsigned char SHUGE *bP);
int  TUTORfree_handle(unsigned int  mm);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
int  AllowHandlePurge(unsigned int  mm);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
long TUTORload_region_ppm(FileRef FAR *fRef);
int  TUTORdealloc(char  FAR *ptr);
extern int DumpPalette(char *idstr,Memh palH);
unsigned int  TUTORcopy_handle(unsigned int  mm);
int TUTORset_color_rgb(int select,int SysOrPal,double red,double green,double blue);
extern int TUTORinq_foreground_color(struct tutorColor *fc);
int  TUTORinq_background_color(struct tutorColor *fc);
int  TUTORinit_graf(void);
int uplow(char FAR *str);
int  CTinit_default_palette(void);
int  CTinit_old_default_palette(void);
extern int  CTset_color_entry(struct  CTcolorentry FAR *cep,unsigned int  rr,unsigned int  gg,unsigned int  bb,int  ff,int  bf,int  res);
int  TUTORcreate_window(int  top,int  left,int  xSize,int  ySize,int  type);
int  TUTORpoll_event_log(void);
extern int  ParseEventLog(char  *lstr,struct  tutorevent *pev,int  topCall);
struct  keywdinf *GetComposeFKey(void);
int  TUTORcompose_fkey(unsigned char  *cCompose);
unsigned int  TUTORinit_menubar(int  nItems);
int  TUTORadd_menu(unsigned int  barh,char  *card,int  cp,char  *item,int  ip,int  keyBind,int  type,int  unit,double  unitArg,int  eType);
int  TUTORdelete_menu(unsigned int  barh,char  *card,char  *item);
int  TUTORmodify_menu(unsigned int  barh,char  *card,char  *item,int  enableFlag,int  checkFlag,int  style);
int  TUTORinq_author_menus(unsigned int  barh);
int  TUTORdelete_author_menus(unsigned int  barh);
int  TUTORset_menubar(unsigned int  barh,struct  tutorview FAR *newMenuView);
int  TutorCountMenuItems(void);
extern int  FindFree(unsigned int  barh);
long TUTORinq_ffamily_id(struct  _fref *famName,int known);
long TUTORinq_symbolic_font_id(char  *fontName);
int  TUTORget_zfont(char  *famS,int  size);
int  TUTORcvt_font_size(long ffid,int  crsize,int  *realSize);
int  TUTORinq_font_name(int  nn,char  *name,int  maxLen);
int  extend_font_table(int  nnew);
int  TUTORstart_fonts(void);
long  TUTORadd_ffamily(struct  _fref *famName,int  isSys,int  isSwitch);
int  CTpalette(int  wn,unsigned int  newPal,int  newFlag,unsigned int  defPal);
int  CTinq_closest_color(int  wn,double  redF,double  greenF,double  blueF,int  hsvf);
extern long  ColorDistance(unsigned int  r1,unsigned int  g1,unsigned int  b1,unsigned int  r2,unsigned int  g2,unsigned int  b2);
extern long  ColorDistanceHSV(double  h1,double  s1,double  v1,double  h2,double  s2,double  v2);
int  TUTORinq_rgb_slot(int  wn,int  slotn,double  *red,double  *green,double  *blue);
int  TUTORhsv_to_rgb(double  hue,double  saturation,double  value,double  *red,double  *green,double  *blue);
int  TUTORrgb_to_hsv(double  red,double  green,double  blue,double  *hue,double  *saturation,double  *value);
char  FAR *GetPtr(unsigned int  mm);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  CTcount_colors(int  oldF);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
extern int TUTORzero(char SHUGE *ptr,long lth);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
long  IntToCoord(int  xx);
int  FindWindowByType(int  type);
long  TUTORinq_msec_clock(void);
int  TUTORclose(int  findx);
int  TUTORread_string(unsigned char  *str,int  length,int  findx);
int  TUTORseed_random(int  value);
int  log_event(struct  tutorevent *ev);
int  TUTORset_textfont(int  jj);
int  TUTORset_window(int  wid);
int  TUTORforward_window(int  wix);
int  TUTORflush(void);
int  TUTORset_cursor(int  cInd,int  cChar);
int  TUTORset_fill(int  fInd,int  fChar);
int  TUTORset_comb_rule(int  rule);
int  TUTORabs_move_to(int  x,int  y);
int  TUTORwindow_init(int  wix);
int  TUTORnew_window(int  wid);
int  TUTORset_view(struct  tutorview FAR *vp);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
int  TutorNewItem(unsigned int  barh,int  cardI,char  *item,int  ip,int  keyBind,int  itemI);
int  TutorNewCard(unsigned int  barh,char  *card,int  cp,short  *cardNN,int  cardInd);
int  TutorFindCard(unsigned int  barh,char  *card);
int  TUTORstart_menubar(unsigned int  barh);
int  TutorModifyItem(unsigned int  barh,int  cardI,int  itemI,int  enableFlag,int  checkFlag,int  style);
int  TutorFindItem(unsigned int  barh,char  *item,int  cardI);
int  TutorDeleteItem(unsigned int  barh,int  cardI,int  itemI);
int  TutorDeleteCard(unsigned int  barh,int  cardI);
int  FontFamilyIndex(long  id);
int  TUTORget_font2(long  fam,int  size,unsigned int  face,int cid);
int  TUTORsymbolic_fileref(struct  _fref FAR *fRef,char  FAR *syms);
int  TUTORcmp_fileref(struct  _fref FAR *f1,struct  _fref FAR *f2);
int  TutorChangeMenuBar(unsigned int  oldBarh,unsigned int  newBarh);
long  TUTORget_hsize(unsigned int  mm);
int  TUTORfont_sizes(long id,int  fontN);
long  MyFontID(struct  _fref *famName,int  isSys,int  *iso,int *cTknown);
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
int  TUTORdump(char  *s);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
int  TUTORget_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  CTset_background_color(int  color);
int  CTchange_palette(int  wn,unsigned int  newPal,int  sizeWanted,int  *pSet,int  allNew);
int  CTinq_rgb_system(int  cn,double  *red,double  *green,double  *blue);
#ifdef IBMPROTO
int _CDECL sscanf(const char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
extern int mac_get_rgb_region(long id);
#endif

extern long lcftoi();
extern double lcitof();
extern long TUTORget_hsize();
extern long TUTORwrite();
extern long TUTORread();
static unsigned char FAR *next_str();
long  TUTORadd_ffamily();

#ifdef ANDREW
extern FILE *wf[WINDOWLIMIT];   /* wm input files */
#endif

struct keywdinf *GetComposeFKey();
extern struct tutorview FAR *TUTORinq_view();
extern  struct tutorview FAR *TUTORinit_view();
extern long ColorDistance();
extern long ColorDistanceHSV();
extern unsigned int  TUTORinit_menubar();
double  lcfcoord();
long  TUTORinq_msec_clock();

extern int MillionsColor,ReadOnlyColor;
static int eventid; /* unique (incrementing) id */
static long repbase = 0; /* base time for event replay option */
static long repstart;  /* time replay began */
static struct tutorevent playev; /* event currently waiting to replay */

/* ********************************************************* */

TUTORinit_graf()    /* initializations for graphics package */

{   int i;
    register struct tutorview *vp;
    struct tutorwindow FAR *wp;
    
    /* set up Coord constants */
    coordZero = IntToCoord(0);
    coordOne = IntToCoord(1);
    
    /* initialize event/timing queues */

    nevents = 0;
    eventid = 1;
    ntiming = 0;
    evlogfi = evplayfi = 0; /* no event log/play file yet */
    modalW = -1; /* we are not in a modal state */

    /* initialize fonts table */

    nfonts = 0; /* no font table yet */
    nFamilies = 0;
    extend_font_table(4);
    fontFamilies = TUTORhandle("family ",(long)sizeof(FontFamily)*MAXFAMILIES,TRUE);

    NewFontSize = TRUE; /* the default */
    TUTORstart_fonts();
#ifdef MAC
    TUTORget_zfont("system",12); /* insure system font defined */
#endif
#ifdef IBMPC /* DOS or Windows */
    TUTORget_zfont("system",10); /* insure system font defined */
#endif
    textFont0 = TUTORget_zfont("zserif",15);
    textFont = -1; /* not set yet */

    cursorFont = patternFont = -1; /* not set yet */
    cursorChar = 'a'; /* some reasonable value */
    patternChar = 0;
    
        /* initialize event queue */

    eventque = (struct tutorevent FAR *)
        TUTORalloc((long)(EVENTLIMIT*sizeof(struct tutorevent)),TRUE,"tutorevent");
    timeque = TUTORhandle("time q ",(long)(TIMINGLIMIT*sizeof(struct tutorevent)),TRUE);

    /* initialize windows table */

    if (windowsP == FARNULL)
    windowsP = (struct tutorwindow FAR *)TUTORalloc(
              (long)(WINDOWLIMIT*sizeof(struct tutorwindow)),TRUE,"win t");
    for (i=0, wp=windowsP; i<WINDOWLIMIT; i++, wp++) {
        TUTORzero((char FAR *)wp,(long)sizeof(struct tutorwindow));
        wp->paletteSize = 8;
    }; /* for */

    CurrentWindow = -1; /* no window selected yet */
    CurrentView = FARNULL;  /* no view selected yet */
    RealX = RealY = -1; /* position unknown */
    tgclipw = tgcliph = -1; /* no clip rectangle yet */
    CurrentMode = -1;   /* mode unknown */
    SpaceShim = 0;      /* no shim yet */

    flushMenu = TRUE; /* menu flushing on */
    
    bgndColor.palette = winColor.palette = color_defaultb;
    fgndColor.palette = color_defaultf;
    CurrentPaletteSize = 8;
    
} /* TUTORinit_graf */

/* ******************************************************************* */

CTinit_default_palette()
    {
    struct CTcolorentry FAR *cep;

    /* initialize color */

    if (defaultPalette) 
    	return(defaultPalette);

    defaultPalette = TUTORalloc_palette(256);
    cep = (struct CTcolorentry FAR *) GetPtr(defaultPalette);
   
    CTset_color_entry(cep,0,0,0,0,0,FALSE);         /* black */
    CTset_color_entry(cep+1,0xffff,0xffff,0xffff,0,0,FALSE);    /* white */
#ifdef DOSPC
    CTset_color_entry(cep+2,0xffff,0,0,1,1,FALSE);  /* red */
    CTset_color_entry(cep+3,0,0xffff,0,1,1,FALSE);  /* green */
#else
    CTset_color_entry(cep+2,0xffff,0,0,0,0,FALSE);  /* red */
    CTset_color_entry(cep+3,0,0xffff,0,0,0,FALSE);  /* green */
#endif
    CTset_color_entry(cep+4,0,0,0xffff,3,3,FALSE);  /* blue */
    CTset_color_entry(cep+5,0xffff,0xffff,0,2,2,FALSE); /* yellow */
    CTset_color_entry(cep+6,0,0xffff,0xffff,3,3,FALSE); /* cyan */
    CTset_color_entry(cep+7,0xffff,0,0xffff,2,2,FALSE); /* magenta */
    ReleasePtr(defaultPalette);
    KillPtr(cep);
    }

/* ******************************************************************* */

CTinit_old_default_palette() /* create old style executor palette */
    {
    struct CTcolorentry FAR *cep, FAR *cepDef;
    int nColors, ii;
    int fColor, fall;
 
 	if (oldDefaultPalette)
 		return(oldDefaultPalette);
 		
    /* so we always have valid default palette even if user changes screen depth */
    nColors = 256;

    oldDefaultPalette = TUTORalloc_palette(nColors);
    cep = (struct CTcolorentry FAR *) GetPtr(oldDefaultPalette);
    
    /* first 8 slots are copies of default (but reserved) */
    cepDef = (struct CTcolorentry FAR *) GetPtr(defaultPalette);
    for (ii=0; ii<8; ii++)
        CTset_color_entry(cep+ii,cepDef[ii].red,cepDef[ii].green,
            cepDef[ii].blue,cepDef[ii].foreFall,cepDef[ii].backFall,TRUE);
    ReleasePtr(defaultPalette);
    KillPtr(cepDef);
    
    /* the rest of the slots are grey, fallback to zdefaultf */
#ifdef DOSPC
    fall = 1;
#else
    fall = 0;
#endif
    fColor = 0x3fff;
    for (ii=8; ii<nColors; ii++)
        CTset_color_entry(cep+ii,fColor,fColor,fColor,fall,fall,TRUE);
    ReleasePtr(oldDefaultPalette);
    KillPtr(cep);
    
    }

/* ******************************************************************* */

CTset_color_entry(cep,rr,gg,bb,ff,bf,res)
register struct CTcolorentry FAR *cep;
unsigned int rr,gg,bb;
int ff,bf;  /* fallbacks */
int res;
    
{	double hue,saturation,value;
	double redD,greenD,blueD;
	
    cep->red = rr;
    cep->green = gg;
    cep->blue = bb;
    cep->foreFall = ff;
    cep->backFall = bf;
    cep->reserved = res;
    cep->isSet = TRUE;
    redD = (((double) cep->red)/(double) 0xffff) * 100.0;
    greenD = (((double) cep->green)/(double) 0xffff) * 100.0;
    blueD = (((double) cep->blue)/(double) 0xffff) * 100.0;
    TUTORrgb_to_hsv(redD,greenD,blueD,&hue,&saturation,&value);
    cep->cHue = hue*4.0;
    cep->cSaturation = saturation*4.0;
    cep->cValue = value*4.0;
     
} /* CTset_color_entry */

/* ****************************************************** */

int TUTORcreate_window(top,left,xSize,ySize,type)
int top,left; /* position of desired top & left (if -1, let lower level code set it) */
int xSize, ySize; /* desired window size */
int type; /* desired window type */
/* returns window index, or -1 for failure */
/* window is left set to new window */
    {
    int wid, ii;
    register struct tutorwindow FAR *wp;
    struct tutorevent cev;

    /* find free window slot  */
    for (wid=0; wid<WINDOWLIMIT;wid++)
        if (!windowsP[wid].wp) break;
    if (wid >= WINDOWLIMIT)
        return(-1); /* no space */
    
    TUTORset_view(FARNULL); /* save current view */
    wp = &windowsP[wid];
    wp->wxsize = xSize;
    wp->wysize = ySize;
    wp->type = type;

    TUTORnew_window(wid);
#ifndef MAC
    wp->winRedraw = TRUE;  /* start with redraw event (WM only) */
#endif
    windowsP[wid].menuf = FALSE; /* no menu selection (pulldown/windows only) */
    wp->KeyFocus = FARNULL; /* no focus yet */
    wp->MouseFocus = FARNULL;
    wp->MenuFocus = FARNULL;
    wp->luptime = 0;    /* no double click */
    wp->ruptime = 0;
    wp->menus = HNULL;
    wp->normalCursorFont = cursorFont0;
    wp->normalCursorChar = cursorChar0;
	wp->iconified = FALSE;

    for (ii=0; ii<EVENT_N; ii++)
        wp->eventMask[ii] = FALSE;
    wp->eventMask[EVENT_REDRAW] = TRUE;
    wp->eventMask[EVENT_BEGINLAY] = TRUE;
    wp->eventMask[EVENT_ENDLAY] = TRUE;
    wp->eventMask[EVENT_TIME] = TRUE;
    wp->eventMask[EVENT_PROC] = TRUE;
    wp->eventMask[EVENT_WMKILL] = TRUE;
    wp->eventMask[EVENT_RESIZE] = TRUE;
    wp->eventMask[EVENT_SIGNAL] = TRUE;

    wp->firstView = FARNULL;
    TUTORwindow_init(wid);
    TUTORabs_move_to(0,0);
    TUTORset_comb_rule(SRC_OR);
    TUTORset_fill(patternFont0,patternChar0);
    TUTORset_cursor(cursorFont0,cursorChar0);
    TUTORflush();

    TUTORforward_window(wid); /* make sure new window is frontmost */
    TUTORset_window(wid); /* set to new window */

    textFont = -1; /* not actually set yet */
    TUTORset_textfont(textFont0);  /* properly set the font */
    wp->FontIndex = textFont0;
    
    if (evlogfi)
        { /* if we are logging events, put in a resize event so that on playback
            we get the correct window size */
        cev.window = wid;
        cev.type = EVENT_RESIZE;
        cev.x = windowsP[wid].wxsize;
        cev.y = windowsP[wid].wysize;
        log_event(&cev);
        }

    return(wid);
    }

/* ********************************************** */

TUTORpoll_event_log() /* process re-play of events */

{   char lstr[202]; /* event replay string */
    long reptime; /* time of replay event */
    int mousef; /* TRUE if mouse-type event */
    float mxx,myy; /* mouse co-ordinates */
    char wstr[20]; /* scratch string */
    int i, j;
    long tempL;
    struct tutorview FAR *viewp;

    /* check if re-playing events */

    if (evplayfi) { /* read next logged event */
    if (repbase == 0) {

            /* get starting time and random number seed */

        TUTORread_string((unsigned char *) lstr,100,evplayfi);
        sscanf(lstr,"%ld %d",&repbase,&seedrand);
        repstart = TUTORinq_msec_clock();
            TUTORseed_random(seedrand);
        playev.type = -1; /* startup by reading event */
    } /* repbase if */

    if (playev.type < 0) {

        /* read next event from log file */

        i = TUTORread_string((unsigned char *) lstr,100,evplayfi);
        if (i == 0) { /* check if at end of log file */
        TUTORclose(evplayfi);
        evplayfi = 0;
        } else {

        /* parse event log entry */

        ParseEventLog(lstr,&playev,TRUE);
        } /* end-of-file else */
    } else {

        /* check if current event ready to replay */

       if (playev.timestamp < TUTORinq_msec_clock()) {
        eventque[nevents++] = playev;
        playev.type = -1;
        } /* timestamp if */
    } /* playev.type else */
    } /* evplayfi if */

} /* TUTORpoll_event_log */

/* ********************************************** */

static ParseEventLog(lstr,pev,topCall)
char *lstr;
struct tutorevent *pev;
int topCall; /* TRUE if we were called directly from TUTORpoll_event_log */

{  long reptime; /* time of replay event */
    int mousef; /* TRUE if mouse-type event */
    float mxx,myy; /* mouse co-ordinates */
    char wstr[20]; /* scratch string */
    int i, j;
    long tempL;
    struct tutorview FAR *viewp;
    struct tutorevent tempEv;
    double tempD;

    /* parse event log entry */
    
    mousef = FALSE; /* not a mouse event yet */
    sscanf(lstr,"%ld %s",&reptime,wstr); /* get time and window */
    pev->timestamp = (reptime-repbase)+repstart; /* convert time */
    if (strcmp(wstr,"edit") == 0)
        pev->window = FindWindowByType(EDITW);
    else if (strcmp(wstr,"exec") == 0)
        pev->window = FindWindowByType(EXECW);
    else if (strcmp(wstr,"cmds") == 0)
        pev->window = FindWindowByType(DICTW);
    else if (strcmp(wstr,"help") == 0)
        pev->window = FindWindowByType(HELPW);
    else if (strcmp(wstr,"search") == 0)
        pev->window = FindWindowByType(SEARCHW);
    else if (strcmp(wstr,"xxxx") == 0)
        pev->window = 1001; /* ridiculous number */
    sscanf(lstr+14,"%s",wstr); /* get event type */
    if (strcmp(wstr,"ldwn") == 0) {
        pev->type = EVENT_LEFTDOWN;
        mousef = TRUE;
    } else if (strcmp(wstr,"lup") == 0) {
        pev->type = EVENT_LEFTUP;
        mousef = TRUE;
    } else if (strcmp(wstr,"rdwn") == 0) {
        pev->type = EVENT_RIGHTDOWN;
        mousef = TRUE;
    } else if (strcmp(wstr,"rup") == 0) {
        pev->type = EVENT_RIGHTUP;
        mousef = TRUE;
    } else if (strcmp(wstr,"move") == 0) {
        pev->type = EVENT_DOWNMOVE;
        mousef = TRUE;
    } else if (strcmp(wstr,"wfocus") == 0) {
        pev->type = EVENT_WFOCUS;
       if (pev->window == ExecWn)
        pev->view = ExecVp;
       else if (pev->window == EditWn[0])
        pev->view = EditVp[0];
       else if (pev->window == DictWn)
    pev->view = DictVp;
       else if (pev->window == HelpWn)
        pev->view = HelpVp;
       else
        pev->window = -1; /* kills event in interact */
    } else if (strcmp(wstr,"wmkill") == 0) {
        /* window manager kills window */
        pev->type = EVENT_WMKILL;
        pev->view = 0L;
    } else if (strcmp(wstr,"scroll") == 0) {
        pev->type = EVENT_SCROLL;
       sscanf(lstr+21,"%g %d",&tempD,&j); /* get new scroll value & which scroll bar*/
       pev->a3 = tempD;
       viewp = windowsP[pev->window].firstView;
       /* set view according to view "index" in j */
       while (viewp && j > 0) {
        j--;
        viewp = viewp->nextView;
       }
       if (viewp)
         pev->view = viewp;
       else
        pev->window = -1; /* some problem - kill the event */
    } else if (strcmp(wstr,"key") == 0) {
        pev->type = EVENT_KEY;
        pev->view = windowsP[pev->window].KeyFocus;
        pev->nkeys = 1;
        sscanf(lstr+18,"%d",&i); /* get key code */
        pev->keys[0] = i;
#ifdef MAC_old_fkey
        /* special keys need to be in 3 key sequence
            so make call to ParseEventLog to get next 2 keys */
        if (pev->keys[0] == 1 && topCall)
            {
            for (j = 1; j <= 2; j++)
                {
                TUTORread_string((unsigned char *) lstr,100,evplayfi);
                ParseEventLog(lstr,&tempEv,FALSE);
                pev->keys[j] = tempEv.keys[0];
                }
            pev->nkeys = 3;
            }
#endif
    } else if (strcmp(wstr,"fkey") == 0) {
        pev->type = EVENT_FKEY;
        sscanf(lstr+19,"%d",&pev->value);
        pev->nkeys = 1;
    } else if (strcmp(wstr,"menu") == 0) {
        pev->type = EVENT_MENU;
        sscanf(lstr+18,"%d %d %f",&pev->a1,&pev->a2,&mxx);
                            pev->a3 = mxx;
    } else if (strcmp(wstr,"resize") == 0) {
        pev->type = EVENT_RESIZE;
        sscanf(lstr+21,"%d %d",&i,&j);
        pev->x = i;
        pev->y = j;
    }
    if (mousef && (pev->window >= 0)) {
        sscanf(lstr+18,"%f %f",&mxx,&myy);
        if (pev->window < 100) { /* non xxxx window */
            pev->x = (float)windowsP[pev->window].wxsize*mxx + 0.4;
            pev->y = (float)windowsP[pev->window].wysize*myy + 0.4;
        } else {
            pev->x = mxx;
            pev->y = myy;
        }
    } /* mousef if */
    
    
} /* ParseEventLog */


/* function key composition table */
static struct keywdinf fkey_compose[] =
    {
    "fd\b",KFWDDEL,
    "bk\t",KBACKTAB,
    "esc",KESCAPE,
    "???",KHELP,
    "fna",KFA, "fnb",KFB, "fnc",KFC, "fnd",KFD,
    "trn",KTRANSPOSE,
    "lf-",KLEFT, "lfe", KLEFT+1,
    "rt-",KRIGHT, "rte",KRIGHT+1,
    "up-",KUP, "upe",KUP+1,
    "dn-",KDOWN,"dne",KDOWN+1,
    "bl-",KBEGLINE, "ble",KBEGLINE+1,
    "el-",KENDLINE, "ele",KENDLINE+1,
    "bp-",KBEGPAGE, "bpe",KBEGPAGE+1,
    "ep-",KENDPAGE, "epe",KENDPAGE+1,
    "bf-",KBEGFILE, "bfe",KBEGFILE+1, "bfs",KSBEGFILE,
    "ef-",KENDFILE, "efe",KENDFILE+1, "efs",KSENDFILE,
    "pu-",KPAGEUP, "pue",KPAGEUP+1, "pus",KSPAGEUP,
    "pd-",KPAGEDOWN, "pde",KPAGEDOWN+1, "pds",KSPAGEDOWN,
    "cut",KCUT, "cpy",KCOPY, "pst", KPASTE, "und", KUNDO,
    "bck", KBACK, "nxt", KNEXT,
    "",0
    };

struct keywdinf *GetComposeFKey()
    {
    return (&fkey_compose[0]);
    }

TUTORcompose_fkey(cCompose)
unsigned char *cCompose;
/* returns the fkey value, or 0 if none */
    {
    int ii;
    
    if (*cCompose != ';')
        return(0); /* sequence starts incorrectly */
    
    ii = 0;
    while (fkey_compose[ii].value != 0)
        {
        if (0 == strncmp((char *) (cCompose+1),fkey_compose[ii].name,3))
            return(fkey_compose[ii].value);
        ii++;
        }
    
    /* didn't find a match */
    return(0);
    }


/* ******************************************************************* */

int cTOrderPalette(cTPaletteP)
struct CTcolorentry FAR *cTPaletteP; /* pointer to palette */

{
	/* find best aproximation to our basic colors */
	
    PaletteOrder(cTPaletteP,256,2,0xffff,0x0000,0x0000); /* red */
    PaletteOrder(cTPaletteP,256,3,0x0000,0xffff,0x0000); /* green */
    PaletteOrder(cTPaletteP,256,4,0x0000,0x0000,0xffff); /* blue */
    PaletteOrder(cTPaletteP,256,5,0xffff,0xffff,0x0000); /* yellow */
    PaletteOrder(cTPaletteP,256,6,0x0000,0xffff,0xffff); /* cyan */
    PaletteOrder(cTPaletteP,256,7,0xffff,0x0000,0xffff); /* magenta */
    PaletteOrder(cTPaletteP,256,0,0x0000,0x0000,0x0000); /* black */
    PaletteOrder(cTPaletteP,256,1,0xffff,0xffff,0xffff); /* white */
    cTPaletteP->red = 0; /* black really is black */
    cTPaletteP->green = 0;
    cTPaletteP->blue = 0;
    cTPaletteP->cHue = 180*4;
    cTPaletteP->cSaturation = cTPaletteP->cValue = 0;
    (cTPaletteP+1)->red = 0xffff; /* white really is white */
    (cTPaletteP+1)->green = 0xffff;
    (cTPaletteP+1)->blue = 0xffff;
    (cTPaletteP+1)->cHue = 180*4;
    (cTPaletteP+1)->cSaturation = 0;
    (cTPaletteP+1)->cValue = 100;
    return(0);
    
} /* cTOrderPalette */

/* ******************************************************************* */

static int PaletteOrder(cTPaletteP,nEntries,newPos,red,green,blue)
struct CTcolorentry FAR *cTPaletteP;
int nEntries; /* number colors in palette */
int newPos; /* new position for color */
unsigned int red;
unsigned int green;
unsigned int blue;

{	int curPos;
	struct CTcolorentry swapColor;
	
	curPos = PaletteMatch(cTPaletteP,nEntries,red,green,blue);
	if (curPos != newPos) {
		swapColor = *(cTPaletteP+curPos);
		*(cTPaletteP+curPos) = *(cTPaletteP+newPos);
		*(cTPaletteP+newPos) = swapColor;
	}
	return(0);
	
} /* PaletteOrder */

/* ******************************************************************* */

Memh TUTORinit_menubar(nItems) /* initialize menu bar */
int nItems; /* # of items (including one item per card for header) */
    
{   int ii;
    TutorMenuBar FAR *bar;
    TutorMenuItem FAR *mp;
    Memh barh;
    long size; /* size of memory allocated for bar */

    size = (long)(sizeof(TutorMenuBar)+(nItems-1)*sizeof(TutorMenuItem));
    barh = TUTORhandle("menubar",size,TRUE);
    if (!barh) return(0);
    bar = (TutorMenuBar FAR *) GetPtr(barh);
    TUTORzero((char SHUGE *)bar,size);
    TUTORstart_menubar(barh);
    bar->nItems = nItems;
    for (ii=0, mp=bar->items; ii<nItems; ii++, mp++) {
        mp->itemKind = UNUSED;
        mp->state = ITEMDISABLED;
    } /* for */

    ReleasePtr(barh);
    KillPtr(bar);
    return(barh);

} /* TUTORinit_menubar */

/* ****************************************************** */

static char *NILCard = "Option";

/* ********************************************************** */

TUTORadd_menu(barh,card,cp,item,ip,keyBind,type,unit,unitArg, eType) /* create a menu item */
Memh barh;
char *card, *item;
int cp,ip,unit,type;
int keyBind; /* if non-zero, the Mac keyBinding character */
double unitArg;
int eType;
/* returns card id of new item, or -1 for failure */
    
{   TutorMenuBar FAR *bar;
    int cardI,itemI,tempI;
    short newID,tempsi;
    register TutorMenuItem FAR *itemP;
    
    if (barh == 0) return(-1); /* menu bar doesn't really exist */

    if (card == NEARNULL)
#ifdef WM
        card = isx11 ? NILCard : "\0";
#else
        card = NILCard;
#endif

    TUTORdelete_menu(barh,card,item); /* delete card if exists -- needed because of possible priority changes */
    
    itemI = FindFree(barh); /* make sure there is space for item */
    if (itemI < 0) return 0; /* no space */
    
    bar = (TutorMenuBar FAR *) GetPtr(barh);
    itemP = bar->items + itemI;
    itemP->itemKind = MENUITEM; /* so space isn't used for card */
    itemP->cardI = -1; /* but make sure it doesn't belong to any card yet */
    ReleasePtr(barh); /* to make code load (of TutorFindCard) easy */
    KillPtr(bar);

    /* make sure card exists */
    cardI = TutorFindCard(barh,card); /* find index of card */
    if (cardI < 0) { /* didn't find card */ 
        cardI = FindFree(barh); /* space for card */
        if (cardI < 0) {
            bar = (TutorMenuBar FAR *) GetPtr(barh);
            bar->items[itemI].itemKind = UNUSED; /* free item space that never was actually used */
            bar->items[itemI].state = ITEMDISABLED;
            ReleasePtr(barh);
            KillPtr(bar);
            return 0;
        } /* cardI < 0 */
        newID = TutorNewCard(barh,card,cp,&tempsi,cardI); /* create menu */

        /* create tutor info */
        bar = (TutorMenuBar FAR *) GetPtr(barh);
        itemP = bar->items + cardI;
        TUTORblock_move(Farp(card),itemP->name,(long) MENUNAMEL);
        itemP->state = ITEMVISIBLE;
        itemP->itemKind = MENUCARD;
        itemP->isAuthor = (type == exec_unit || type == exec_unita) ? 1 : 0;
        itemP->cardI = newID;
        itemP->priority = cp;
    /*  itemP->nnth = tempI;  set by TutorNewCard */
    } else { /* maintain card isAuthor field */
        bar = (TutorMenuBar FAR *) GetPtr(barh);
        bar->items[cardI].isAuthor &= ((type == exec_unit || type == exec_unita) ? 1 : 0);
    } /* cardI < 0 else */
    ReleasePtr(barh);
    KillPtr(bar);
    
    /* make item */

    tempI = TutorNewItem(barh,cardI,item,ip,keyBind,itemI);
        
    /* create tutor info */
    bar =  (TutorMenuBar FAR *) GetPtr(barh);
    itemP = bar->items + itemI;
    TUTORblock_move(Farp(item),itemP->name, (long) MENUNAMEL);
    itemP->state = ITEMVISIBLE;
    itemP->type = type;
    itemP->isAuthor = (type == exec_unit || type == exec_unita) ? 1 : 0;
    itemP->cardI = cardI;
    itemP->priority = ip;
    itemP->nnth = tempI;
    itemP->unit = unit;
    itemP->unitArg = unitArg;
    itemP->eventType = eType;

    cardI = bar->items[cardI].cardI;
    ReleasePtr(barh);
    KillPtr(bar);
    if (flushMenu) TUTORflush();
    return(cardI); /* success */

} /* TUTORadd_menu */

/* ******************************************************** */

TUTORdelete_menu(barh,card,item) /* delete a menu item */
Memh barh;
char *card; /* may be NIL.  Which could mean delete from options menu, or
                it could mean delete the whole card whose name is in item */
char *item;
    {
    TutorMenuBar FAR *bar;
    int cardI, itemI, nItems, nullI;
    register short ii;
    register TutorMenuItem FAR *mp;
    char *tempC;
    int hadNoCard;

    if (barh == 0)
        return(0); /* menu bar doesn't really exist */
	itemI = -1;
    if (card)
        {
        cardI = TutorFindCard(barh,card);
        if (cardI < 0)
            return(0);
		if (item)
        	itemI = TutorFindItem(barh,item,cardI);
        }
    else /* card is empty */
        { /* try to delete whole card (whose name is in item) */
        cardI = TutorFindCard(barh,item);
        if (cardI >= 0)
            { /* we found card, we will be deleting it */
            card = item;
            item = NEARNULL; /* indicates card deletion */
            }
        else
            { /* look for the item on default card */
            bar = (TutorMenuBar FAR *) GetPtr(barh);
            nullI = TutorFindCard(barh,NILCard);
            itemI = -1;
            if ((nullI >= 0) && ((itemI = TutorFindItem(barh,item,nullI)) >= 0)) {
                cardI = nullI;
                }
            ReleasePtr(barh);
            KillPtr(bar);
            }
        }
    
    if (itemI < 0 && item)
        return(0); /* couldn't find item, and couldn't find a card */
    
    /* at this point we have either:
        1: cardI and itemI (item != NEARNULL) - delete an item
        2: item == NEARNULL - delete cardI
     */
    
    if (item)
        { /* deleting an item.  Count items on this card.  If the item we are
                deleting is the only one, we want to delete the whole card */
        nItems = 0;
        bar = (TutorMenuBar FAR *) GetPtr(barh);
        for (ii=0, mp=bar->items; ii<bar->nItems; ii++, mp++)
            {
            if (mp->cardI == cardI && mp->itemKind == MENUITEM)
                {
                nItems++;
                if (nItems > 1)
                    break; /* don't have to look any further */
                }
            }
        ReleasePtr(barh);
        KillPtr(bar);
        }
    
    if (nItems <= 1 || !item)
        { /* delete card (either because there is only 1 item, or because
                we matched card name above) */
        TutorDeleteCard(barh,cardI);
        bar = (TutorMenuBar FAR *) GetPtr(barh);
        bar->items[cardI].itemKind = UNUSED; /* mark card entry empty */
        bar->items[cardI].state = ITEMDISABLED;
        for (ii=0, mp=bar->items; ii<bar->nItems; ii++, mp++)
            if (mp->cardI == cardI && mp->itemKind == MENUITEM) {
                mp->itemKind = UNUSED; /* mark all items unused */
                mp->state = ITEMDISABLED;
            }
        ReleasePtr(barh);
        KillPtr(bar);
        }
    else
        { /* delete item, card will still be around */
        TutorDeleteItem(barh,cardI,itemI);
        bar = (TutorMenuBar FAR *) GetPtr(barh);
        bar->items[itemI].itemKind = UNUSED;
        bar->items[itemI].state = ITEMDISABLED;
        ReleasePtr(barh);
        KillPtr(bar);
        }

    if (flushMenu)
        TUTORflush();
        
    return(0);

    }                   /* TUTORdelete_menu */

/* ****************************************************** */

TUTORmodify_menu(barh,card,item,enableFlag,checkFlag,style) /* change the style of menu item */
Memh barh;
char *card;
char *item; /* item chars, if NIL, apply change to card */
int enableFlag; /* 1: enable, 0: disable, -1: do nothing */
int checkFlag; /* 1: check, 0: uncheck, -1: do nothing */
int style; /* 0 and up: face style for item, -1: do nothing */
    
{   int cardI, itemI;
    TutorMenuBar FAR *bar;

    if (barh == 0) return 0; /* menu bar doesn't really exist */

    if (card == NIL)
#ifdef WM
        card = isx11 ? NILCard : "\0";
#else
        card = NILCard;
#endif
    cardI = TutorFindCard(barh,card);
    if (cardI < 0) return 0; /* couldn't find card */
    
    if (item == NIL) {
        if (enableFlag != -1) { /* only valid operation on card is enable */
            TutorModifyItem(barh,cardI,-1,enableFlag,-1,-1);
            bar = (TutorMenuBar FAR *) GetPtr(barh);
            bar->items[cardI].state = enableFlag ? ITEMVISIBLE : ITEMDISABLED;
            ReleasePtr(barh);
            KillPtr(bar);
        } /* enableFlag */
        return 0;
    } /* item */
    itemI = TutorFindItem(barh,item,cardI);
    if (itemI < 0) return 0; /* couldn't find item */
    
    TutorModifyItem(barh,cardI,itemI,enableFlag,checkFlag,style);
    if (enableFlag >= 0) {
        bar = (TutorMenuBar FAR *) GetPtr(barh);
        bar->items[itemI].state = enableFlag ? ITEMVISIBLE : ITEMDISABLED;
        ReleasePtr(barh);
        KillPtr(bar);
    } /* enableFlag */
    if (flushMenu) TUTORflush();
    return 0;

} /* TUTORmodify_menu */

/* ******************************************************** */

TUTORinq_author_menus(barh) /* return TRUE if there are any author menus in bar */
Memh barh;

{   register short ii;
    register TutorMenuItem FAR *mp;
    TutorMenuBar FAR *bar;
    int rVal; /* value to return; */

    if (barh == 0) return(0); /* menu bar doesn't really exist */

    bar = (TutorMenuBar FAR *) GetPtr(barh);
    rVal = FALSE; /* preset for no author menus found */
    for (ii=0, mp=bar->items; ii<bar->nItems; ii++, mp++)
        if (mp->itemKind == MENUITEM && mp->state == ITEMVISIBLE && mp->isAuthor) {
            rVal = TRUE; /* found an author menu */
            break;
        } /* itemKind */

    ReleasePtr(barh);
    KillPtr(bar);
    return(rVal);

} /* TUTORinq_author_menus */

/* ******************************************************* */

TUTORdelete_author_menus(barh) /* delete all author menus from bar */
Memh barh;
    
{   register short ii, jj;
    register TutorMenuItem FAR *mp, FAR *m2p;
    TutorMenuBar FAR *bar;
    
    if (barh == 0) return 0; /* menu bar doesn't really exist */

    flushMenu = FALSE; /* turn off forced flushing */

    /* note that barh left locked over calls to TutorDeleteCard & TutorDeleteItem */

    /* delete all author cards, by card */
    bar = (TutorMenuBar FAR *) GetPtr(barh);
    for (ii=0, mp=bar->items; ii<bar->nItems; ii++, mp++) {
        if (mp->itemKind == MENUCARD && mp->isAuthor){
            TutorDeleteCard(barh,ii); /* get rid of menu */
            for (jj=0, m2p=bar->items; jj<bar->nItems; jj++, m2p++)
                if (m2p->itemKind == MENUITEM && m2p->cardI == ii) {
                     /* mark all items on card as unused */
                    m2p->itemKind = UNUSED;
                    m2p->state = ITEMDISABLED;
                }
            mp->itemKind = UNUSED; /* mark card as unused */
        } /* itemKind if */
    } /* for */
    
    /* delete all remaining items by item */
    for (ii=0, mp=bar->items; ii<bar->nItems; ii++, mp++)
        if (mp->itemKind == MENUITEM && mp->isAuthor){
            TutorDeleteItem(barh,mp->cardI,ii);
            mp->itemKind = UNUSED;
            mp->state = ITEMDISABLED;
        } /* itemKind if */

    /* flush to window manager */
    TUTORflush();
    flushMenu = TRUE;

    ReleasePtr(barh);
    KillPtr(bar);
    return 0;

} /* TUTORdelete_author_menus */

/* ********************************************************** */

TUTORset_menubar(barh,newMenuView)   /* change the menu bar of the current window */
Memh barh;
struct tutorview FAR *newMenuView;  /* new MenuFocus for current window */
    
{   Memh oldBar;
    register struct tutorwindow FAR *wp;

    wp = windowsP + CurrentWindow;
    if (wp->menus == barh) return 0; /* menu already set */

    flushMenu = FALSE; /* stop forced flushing to wm */
    oldBar = wp->menus;
    wp->menus = barh;
    TutorChangeMenuBar(oldBar,barh);
    wp->MenuFocus = newMenuView;
    
    /* flush to wm */
    TUTORflush();
    flushMenu = TRUE;

    return 0;

} /* TUTORset_menubar */

/* ******************************************************************* */

int TutorCountMenuItems() /* return number menu items */

{   TutorMenuBar FAR *bar; /* pointer to menu bar structure */
    Memh barh;
    int ii;
    int count;

    barh = windowsP[CurrentWindow].menus;
    bar = (TutorMenuBar FAR *) GetPtr(barh);
    count = 0;
    for (ii=0; ii<bar->nItems; ii++)
        if ((bar->items[ii].itemKind != UNUSED) &&
            (bar->items[ii].state == ITEMVISIBLE))
            count++;
    ReleasePtr(barh);
    return(count);

} /* TutorCountMenuItems */

/* ******************************************************* */

static FindFree(barh) /* find free space in menubar */
Memh barh;
    
{   register short ii;
    register TutorMenuItem FAR *mp;
    TutorMenuBar FAR *bar;
    int rVal; /* returned value */
    
    rVal = -1; /* preset for no space found */
    bar = (TutorMenuBar FAR *) GetPtr(barh);
    for (ii=0, mp=bar->items; ii<bar->nItems; ii++, mp++)
        if (mp->itemKind == UNUSED){
            rVal = ii;
            break;
        } /* itemKind if */ 
    ReleasePtr(barh);
    KillPtr(bar);
    return(rVal);

} /* FindFree */

/* ********************************************************** */

long TUTORinq_ffamily_id(famName,known)
FileRef *famName;
int known; /* TRUE if want font with known sizes (zsans,zserif) */
    {
    int ii;
    FontFamily FAR *ffp;
    long id;

    /* look thru font family table & see if we know this family */
    ffp = (FontFamily FAR *) GetPtr(fontFamilies);
    for (ii=0; ii<nFamilies; ii++,ffp++)
        if (TUTORcmp_fileref((FileRef FAR *) famName,&ffp->familyRef) == 0) {
	    if ((!known) && ffp->knownFont) {
		if (strcmpf((char FAR *)famName->path,(char FAR *)"system") == 0)
		    break; /* system doesn't have size table */
                ; /* don't want known sizes */
	    } else
                break;
        }
    if (ii >= nFamilies)
        id = -1; /* we didn't find font */
    else
        id = ffp->fID;
    ReleasePtr(fontFamilies);
    KillPtr(ffp);

    return(id);
    }

/* ********************************************************** */

long TUTORinq_symbolic_font_id(fontName)
char *fontName;
    {
    FileRef fRef;
    
    TUTORsymbolic_fileref((FileRef FAR *) &fRef, (char FAR *) fontName);
    return(TUTORinq_ffamily_id(&fRef,TRUE));
    }

/* ********************************************************** */

TUTORget_zfont(famS,size) /* get one of z* fonts */
char *famS;
int size; /* physical (pixel) size, or -1 (indicating no size wanted - cursors, patterns or maybe icons) */
    {
    int  realSize;
    long id;

    id = TUTORinq_symbolic_font_id(famS);
    if (size >= 0)
        { /* transform physical size into system size */
        size = TUTORcvt_font_size(id,size,&realSize);
        }
    return(TUTORget_font2(id,size,0,100));
    }

/* ********************************************************** */

int TUTORcvt_font_size(ffid,crsize,realSize) /* get system size based on cr size */
long ffid; /* font family id */
int crsize; /* desired cr size */
int *realSize; /* to be set to actual pixel height of font to be used */
/* returns appropriate system size to use */
    {
    FontFamily FAR *fFam;
    short ii, sizeInd;
    int family;
    int sysSize,foundSize;
    int systemFont; /* TRUE if default system font */

    systemFont = FALSE;
    family = FontFamilyIndex(ffid);
    fFam = family + (FontFamily FAR *) GetPtr(fontFamilies);
    if (strcmpf(fFam->familyRef.path,(char FAR *)"system") == 0)
	systemFont = TRUE;

    if (!systemFont && fFam->knownFont) {
    
        /* search size table */
        
        ii = 0;
        if (CurrentView == ExecVp)
            sizeInd = NewFontSize ? 2 : 1; /* to select which size data to use */
        else sizeInd = 2;
        while (ii<NFSIZES && fFam->famSizes[sizeInd][ii] <= crsize && fFam->famSizes[sizeInd][ii] != -1)
            ii++; /* keep going thru table till find something too large */
        
        if (ii > 0) ii--; /* since went too far */
        
        foundSize = fFam->famSizes[sizeInd][ii];
        if (foundSize == -1) {
            *realSize = crsize; /* don't know sizes */
            sysSize = crsize;
        } else {
            *realSize = foundSize;
            sysSize = fFam->famSizes[0][ii];
        }
    } else { 
        
        /* don't know sizes for this font */
        
        *realSize = sysSize = crsize;
    }
    ReleasePtr(fontFamilies);
    KillPtr(fFam);
    return(sysSize);
    }

/* ********************************************************** */

TUTORinq_font_name(nn,name,maxLen) /* return family name of nnth family */
int nn;
char *name; /* note that just the name of the font, not the rest of the font file ref, gets copied! */
int maxLen;
/* returns success flag (can fail if there isn't enough space for the font name) */
    {
    FontFamily FAR *ffp;
    int nameLen;
    char fontName[FILEL+1];

	*name = 0; /* in case doesn't work */
	if (nn < 0)
		return(FALSE);
	if (nn > nFamilies)
		TUTORdump("inq_font_name failed");
    ffp = nn + (FontFamily FAR *) GetPtr(fontFamilies);
    TUTORget_fileref_name(&ffp->familyRef,(char FAR *) fontName);
    nameLen = strlen(fontName);
    if (nameLen+1 > maxLen)
        return(FALSE);
    strcpy(name,fontName);
    ReleasePtr(fontFamilies);
    KillPtr(ffp);

    return(TRUE);
    }

/* ********************************************************** */

extend_font_table(nnew) /* expand fonts table */ /* machine independent */
int nnew;   /* number table entries to add */
    
{   int ii; /* index in font table */
    struct tutorfont FAR *tf;
    char FAR *chp; 

    /* allocate new font table entries */
    if (nfonts == 0) {
        fontsH = TUTORhandle("fonttab",(long)(sizeof(struct tutorfont)*nnew),TRUE);
    } else { /* resize font table */
        TUTORset_hsize(fontsH,(long)((nfonts+nnew)*sizeof(struct tutorfont)),TRUE);
    }
    
    /* initialize new fonts table entries */
    tf = nfonts + (struct tutorfont FAR *) GetPtr(fontsH);
    for (ii=nfonts; ii<(nfonts+nnew); ii++, tf++) {
        chp = (char FAR *)tf;
        TUTORzero(chp,(long)sizeof(struct tutorfont)); /* pre-zero */
        tf->fID = -1;
    } /* for */
    ReleasePtr(fontsH);
    KillPtr(tf);
    nfonts += nnew;
    
} /* extend_font_table */

TUTORstart_fonts() /* initialize font table with z* families */
    {
    FileRef fRef;

#ifdef WM
    if (!isx11)
        { /* create a temporary window to connect to wm (ARGHHH!) */
        wm_NewWindow(0L);
        /* wm_DeleteWindow(); /* and delete it because we don't want it */
        }
#endif
    TUTORsymbolic_fileref((FileRef FAR *) &fRef, (char FAR *) "zserif");
    TUTORadd_ffamily(&fRef,TRUE,FALSE);
    TUTORsymbolic_fileref((FileRef FAR *) &fRef, (char FAR *) "zsans");
    TUTORadd_ffamily(&fRef,TRUE,FALSE);
    TUTORsymbolic_fileref((FileRef FAR *) &fRef, (char FAR *) "zsymbol");
    TUTORadd_ffamily(&fRef,TRUE,FALSE);
    TUTORsymbolic_fileref((FileRef FAR *) &fRef, (char FAR *) "zfixed");
    TUTORadd_ffamily(&fRef,TRUE,FALSE);
    TUTORsymbolic_fileref((FileRef FAR *) &fRef, (char FAR *) "zpatterns");
    TUTORadd_ffamily(&fRef,TRUE,FALSE);
    TUTORsymbolic_fileref((FileRef FAR *) &fRef, (char FAR *) "zcursors");
    TUTORadd_ffamily(&fRef,TRUE,FALSE);
    TUTORsymbolic_fileref((FileRef FAR *) &fRef, (char FAR *) "zicons");
    TUTORadd_ffamily(&fRef,TRUE,FALSE);
#ifdef MAC
    TUTORsymbolic_fileref((FileRef FAR *) &fRef, (char FAR *) "system");
    TUTORadd_ffamily(&fRef,TRUE,FALSE);
#endif
#ifdef WINPC
    TUTORsymbolic_fileref((FileRef FAR *) &fRef, (char FAR *) "system");
    TUTORadd_ffamily(&fRef,TRUE,FALSE);
#endif
#ifdef IBMPC
    TUTORsymbolic_fileref((FileRef FAR *) &fRef, (char FAR *) "system");
    TUTORadd_ffamily(&fRef,TRUE,FALSE);
#endif
    }

long TUTORadd_ffamily(famName,isSys,isSwitch) /* load up info for entire font family */
FileRef *famName; /* either a complete path (file reference), or reference to system font */
int isSys; /* only used on Mac */
int isSwitch; /* TRUE if this family should be purged on a switch file */
/* returns new family id */
    {
    REGISTER FontFamily FAR *ffp;
    long fontID;
    int iso, cTknown;
	
    if (nFamilies >= MAXFAMILIES)
        TUTORdump("No space for new family in TUTORadd_ffamily");
    
    ffp = nFamilies + (FontFamily FAR *) GetPtr(fontFamilies);
    nFamilies++;
    TUTORcopy_fileref(&ffp->familyRef,(FileRef FAR *) famName);
    ffp->switchable = isSwitch;
    ffp->knownFont = TRUE; /* assume we know about font sizes */
    ffp->TrueType = FALSE; /* not a scalable font */
    fontID = ffp->fID = MyFontID(famName,isSys, &iso,&cTknown);
    ffp->knownFont = cTknown;
    ffp->isoFont = iso;
    ReleasePtr(fontFamilies);
    KillPtr(ffp);

    TUTORfont_sizes(fontID,nFamilies-1);

    return(fontID);
    }

/* ********************************************************* */

CTpalette(wn,newPal,newFlag,defPal)
int wn;         /* window index */
Memh newPal;    /* the new palette entries (if HNULL, restore system palette) */
int newFlag;    /* non-zero if this palette should replace old entirely */
                /* =  0 = merge with old palette */
                /* = +1 = create entirely new palette */
                /* = +2 = create entirely new executor (disposeable) palette */
Memh defPal;    /* palette to use as default (only used when newFlag is FALSE) */
/* returns -1 for success or # of colors actually set otherwise (same as zreturn) */
    {
    REGISTER struct CTcolorentry FAR *cep, FAR *copyp;
    struct CTcolorentry FAR *cep0;
    struct CTcolorentry FAR *oldP;
    struct CTcolorentry FAR *defP;
    Memh oldPalette;
    register int ii;
    int pSize;  /* the size of the requested palette */
    int pFail; /* TRUE if failed to get a color */
    struct tutorColor saveF, saveB;   /* used to reset current colors */
    int pSet;   /* TRUE if palette was set */
    long tempL;
    int oldPaletteSize; /* # of entries in the old palette */
    int newPSize;   /* # of entries in the old palette */
    int nPaletteGot; /* # palette slots we got */  
    int doSet; /* TRUE if program has no palette, all colors are set */
    
    oldPalette = windowsP[wn].paletteH;
    if (!oldPalette)
    	oldPalette = defaultPalette;
        
    if (newPal) { /* calculate # of new entries */
        tempL = TUTORget_hsize(newPal);
        newPSize = tempL / sizeof(struct CTcolorentry);
    } else
        newPSize = 8; /* size of default palette */
    
    if (newPal && !newFlag)
        { /* modify existing palette */
        /* we will take newPal and copy entries into it from the window's palette,
            making a new complete palette */
        
        /* at this point the isSet field in newPal entries can have 3 values:
            1: a new entry
            0: an entry that we don't change
            -1: an entry we want to restore from defaultPalette
        
        After the loop below isSet (in all palettes installed in windows) can have
            2 values:
            1: entry has been set by program
            0: entry hasn't been set
        */
        
        tempL = TUTORget_hsize(oldPalette);
        oldPaletteSize = tempL / sizeof(struct CTcolorentry);
        oldP = (struct CTcolorentry FAR *) GetPtr(oldPalette);
        cep = (struct CTcolorentry FAR *) GetPtr(newPal);
        cep0 = cep;
        defP = (struct CTcolorentry FAR *) GetPtr(defPal);
        /* the size of the requested palette is the index of the highest set entry */
        for (ii=0; ii<newPSize; ii++, cep++)
            {
            copyp = FARNULL;
            if (cep->isSet == 0)
                { /* -palette- didn't refer to this slot, use old entry, if it exists */
                if (ii < oldPaletteSize)
                    copyp = oldP+ii;
                }
            else if (cep->isSet == -1)
                { /* restoring an entry from the default palette */
                if (ii < 8)
                    copyp = defP+ii;
                else
                    cep->isSet = 0;
                }
            /* else this entry is set in new palette */
            if (copyp)
                *cep = *copyp;
            }
        ReleasePtr(oldPalette);
        ReleasePtr(defPal);
        KillPtr(oldP);
        KillPtr(defP);
        
        /* now calculate desired size of palette */
        cep = cep0;
        pSize = 0;
        for (ii=0; ii<newPSize; ii++, cep++)
            if (cep->isSet)
                pSize++;
        
        ReleasePtr(newPal);
        KillPtr(cep);
        }
    else if (!newPal)
        { /* we are installing the default palette */
        pSize = 8;
        }
    else
        { /* we are installing some new palette */
        cep = (struct CTcolorentry FAR *) GetPtr(newPal);
        pSize = 0;
        for (ii=0; ii<newPSize; ii++,cep++) {
            if (cep->isSet)
                pSize++;
        } /* for */
        ReleasePtr(newPal);
        KillPtr(cep);
        }
    
    /* tell the underlying system that the palette has changed */
    nPaletteGot = CTchange_palette(wn,newPal,pSize,&pSet, newFlag);
    pFail = FALSE;    
#ifdef NOSUCH
    if ((wn == ExecWn) && ((usesColor & 2) == 0) && windowsP[wn].paletteH) {
    	/* if program has no -palette- commands, mark all */
    	/* colors as if they were set by the program */ 
    	cep = (struct CTcolorentry FAR *) GetPtr(windowsP[wn].paletteH); 
    	pSize = windowsP[wn].paletteSize;
    	for(ii=0; ii<pSize; ii++,cep++) { 
    		cep->isSet = TRUE;
    	} 
    	ReleasePtr(windowsP[wn].paletteH);
    }   
#endif
    if (newPal) {
    	cep = (struct CTcolorentry FAR *) GetPtr(newPal);
    	for (ii=0; ii<pSize; ii++,cep++) {
    		if ((cep->isSet) && (cep->realV < 0))
        		pFail = TRUE; /* some color failed */
    	}
    	ReleasePtr(newPal);
    	KillPtr(cep);
    }
    
    if (wn == CurrentWindow)
        {
        /* reset colors, so that we will use new palette */
        CurrentPaletteSize = windowsP[wn].paletteSize;
        TUTORinq_foreground_color(&saveF);
        TUTORinq_background_color(&saveB);
        fgndColor.palette = -4; /* not set */
        bgndColor.palette = -4;
        TUTORset_color(0,&saveF);
        TUTORset_color(1,&saveB);
        }
    
    if ((pFail) || (!pSet) || (nPaletteGot < pSize))
    	return(nPaletteGot);
    else return(-1);
   
    }

/* ********************************************************* */

CTinq_closest_color(wn, redF, greenF, blueF, hsvf)
int wn;
double redF, greenF, blueF;
int hsvf; /* if TRUE, values are really hue, sat, value.  Match in that space */
    {
    Memh palette;
    REGISTER struct CTcolorentry FAR *cep;
    int ii;
    unsigned int red, green, blue;
    long dist, bestD;
    int bestSlot;
    double hue, saturation, value;
    double red2, green2, blue2; /* red, green, blue of each slot as float */
    int PalSize;
    
    if (!hsvf)
        { /* convert floating values to ints */
        green = (greenF*((double) 0xffff))/100.0;
        blue = (blueF*((double) 0xffff))/100.0;
        red = (redF*((double) 0xffff))/100.0;
        }
    
    palette = windowsP[wn].paletteH;
    if (!palette)
        palette = defaultPalette;
    
  	PalSize = TUTORget_hsize(palette)/sizeof(struct CTcolorentry);
    cep = (struct CTcolorentry FAR *) GetPtr(palette);
    
    bestD = 0xffff; /* best distance */
    bestSlot = -1; /* slot of best distance */
    for (ii=0; ii<PalSize; ii++, cep++)
        {
        if (!hsvf)
            dist = ColorDistance(red,green,blue,cep->red,cep->green,cep->blue);
        else
            {
            red2 = (((double) cep->red)/(double) 0xffff) * 100.0;
            green2 = (((double) cep->green)/(double) 0xffff) * 100.0;
            blue2 = (((double) cep->blue)/(double) 0xffff) * 100.0;
            TUTORrgb_to_hsv(red2,green2,blue2, &hue, &saturation, &value);
            dist = ColorDistanceHSV(redF,greenF,blueF,hue,saturation,value);
            }
        if (dist < bestD || bestSlot == -1)
            {
            bestD = dist;
            bestSlot = ii;
            }
        }
    
    ReleasePtr(palette);
    KillPtr(cep);
    
    /* we always return a non-animating slot if we can */
    return(bestSlot);
    }

static long ColorDistance(r1,g1,b1,r2,g2,b2)
unsigned int r1,g1,b1,r2,g2,b2;
    {
    register long dist, del;
    
    dist = (long) r1 - (long) r2;
    if (dist < 0) dist = -dist;
    del = (long) g1 - (long) g2;
    if (del < 0) del = -del;
    dist += del;
    del = (long) b1 - (long) b2;
    if (del < 0) del = -del;
    dist += del;
    return(dist);
    }

static long ColorDistanceHSV(h1,s1,v1,h2,s2,v2)
double h1,s1,v1,h2,s2,v2;

{   double dist, del;
    double maxDist;

    dist = h1 - h2;
    if (dist < 0)
        dist = -dist;
    if (dist > 180)
        dist = 360 - dist; /* because hue wraps around */

    del = s1 - s2;
    if (del < 0)
        del = -del;
    dist += del;
    
    del = v1 - v2;
    if (del < 0)
        del = -del;
    dist += del;

    dist = (dist/560.0)*0xffffL; /* scale distance */

    return(dist);
}

/* ********************************************************* */

TUTORinq_rgb_slot(wn,slotn,red,green,blue)
int wn;     /* window index */
int slotn;  /* cT slot number */
double *red, *green, *blue; /* to be set to rgb 0-100 */
    {
    Memh palette;
    struct CTcolorentry FAR *cep;   /* pointer at cT's color table */
    int ii;
    
    palette = windowsP[wn].paletteH;
    if (!palette)
        palette = defaultPalette;
    cep = (struct CTcolorentry FAR *) GetPtr(palette);
    cep += slotn;
    
    ii = FALSE;
    if (cep->reserved)
        { /* animating color, may have changed.  We need to ask system */
        ii = CTinq_rgb_system(slotn,red,green,blue);
        /* if ii is false, it indicates system doesn't know about color.  In
            which case it hasn't been animated & we can use cT's palette */
        }
    
    if (!ii)
        { /* use cT's palette to determine the color */
        *red = (double) cep->red * 100.0 / (double) 0xffff;
        *green = (double) cep->green * 100.0 / (double) 0xffff;
        *blue = (double) cep->blue * 100.0 / (double) 0xffff;
        }
    ReleasePtr(palette);
    KillPtr(cep);
    
    return(TRUE);
    }

/* **************************************************** */

TUTORhsv_to_rgb(hue, saturation, value, red, green, blue)
double hue, saturation, value, *red, *green, *blue;
/* Convert hue-saturation-value to red-green-blue. */
/* All values in range 0-100 except hue, which is 0-360 */
/* Algorithm adapted from Foley and van Dam, */
/* "Fundamentals of Interactive Computer Graphics" */
{
    int ii;
    double ff, pp, qq, tt;

    if (saturation <= 0.0) {
        *red = *green = *blue = value;
        return 0;
        }
    if (hue < 0.0 || hue >= 360.0) hue = 0.0;
    hue = hue/60.0;
    ii = hue; /* integer part */
    ff = hue - ii;
    pp = value*(1.0-saturation/100.0);
    qq = value*(1.0-(saturation*ff/100.0));
    tt = value*(1.0-(saturation*(1.0-ff)/100.0));
    switch (ii) {
        case 0:
            *red = value;
            *green = tt;
            *blue = pp;
            return 0;
        case 1:
            *red = qq;
            *green = value;
            *blue = pp;
            return 0;
        case 2:
            *red = pp;
            *green = value;
            *blue = tt;
            return 0;
        case 3:
            *red = pp;
            *green = qq;
            *blue = value;
            return 0;
        case 4:
            *red = tt;
            *green = pp;
            *blue = value;
            return 0;
        case 5:
            *red = value;
            *green = pp;
            *blue = qq;
            return 0;
        } /* switch (ii) */

} /* hsb_to_rgb */

/* **************************************************** */

TUTORrgb_to_hsv(red, green, blue, hue, saturation, value)
double red, green, blue, *hue, *saturation, *value;

/* Convert hue-saturation-value to red-green-blue. */
/* All values in range 0-100 except hue, which is 0-360 */
/* Algorithm adapted from Foley and van Dam, */
/* "Fundamentals of Interactive Computer Graphics" */

{   double max, min, dred, dgreen, dblue;

    if (red >= green && red >= blue) {
        max = red;
        min = (green < blue) ? green: blue;
    } else if (green >= red && green >= blue) {
        max = green;
        min = (red < blue) ? red : blue;
    } else {
        max = blue;
        min = (green < red) ? green : red;
    }
    *value = max;
    *saturation = (max == 0.0) ? 0.0 : 100.0*(max-min)/max;
    if (*saturation == 0.0) {
        *hue = 180.0;
        return 0;
    }
    dred = 60.0*(max-red)/(max-min);
    dgreen = 60.0*(max-green)/(max-min);
    dblue = 60.0*(max-blue)/(max-min);
    if (red == max) *hue = dblue-dgreen;
    else if (green == max) *hue = 120.0+dred-dblue;
    else *hue = 240.0+dgreen-dred;
    if (*hue < 0.0) *hue = *hue+360.0;

} /* TUTORrgb_to_hsv */

/* ******************************************************************* */

long TUTORload_region_ppm(fRef) /* load image from file */
FileRef FAR *fRef;
/* returns +n = region id */
/*         -1 = no file */
/*         -2 = no memory */
/*         -3 = no data */

{   int fIndx; /* cT file index */
    long fileSize; /* total size of file */
    Memh headerH; /* handle on region header */
    Memh filBuffH; /* handle on file contents */
    unsigned char SHUGE *filBuffP; /* pointer to file contents */
    long nRead; /* number bytes actually read */
    unsigned char SHUGE *inP; /* working input pointer */
    unsigned char SHUGE *outP; /* working output pointer */
    int width,height; /* width, height of image */
    int maxV; /* maximum value of pixel component */
    int rowI,colI,cii;
    int pixelV;
    int errF;

    TUTORinq_file_info(fRef,NEARNULL,&fileSize,NEARNULL,NEARNULL,NEARNULL);
    if (fileSize < 6) {
	return(-3); /* must have at least minimum header */
    }

    fIndx = TUTORopen(fRef,TRUE,FALSE,FALSE);
    if (fIndx == 0)
	return(-1); /* -1 = can't open file */
		
    /* set up storage for file */
    
    filBuffH = TUTORhandle("pixmap",fileSize,TRUE);
    if (!filBuffH) {
        return(-2); /* couldn't get enough memory */
    }
    TUTORpurge_info(filBuffH,M_WORM,FARNULL,0);
    AllowHandlePurge(filBuffH);

    errF = FALSE;
    filBuffP = (unsigned char FAR *)GetPtr(filBuffH);
    nRead = TUTORread((char FAR *)filBuffP,1,fileSize,fIndx);    
    TUTORclose(fIndx);
    if (nRead != fileSize)
		errF = TRUE;

    if (*filBuffP != 'P')
	errF = TRUE;
    if ((*(filBuffP+1) != '3') && (*(filBuffP+1) != '6'))
	errF = TRUE;
		
    if (errF) {
	ReleasePtr(filBuffH);
	TUTORfree_handle(filBuffH);
	return(-3);
    }
	
    /* convert P3 (ascii) format to P6 (binary) */
	
    if (*(filBuffP+1) == '3') {
	inP = next_str(filBuffP+2,&width);
	inP = next_str(inP,&height);
	inP = next_str(inP,&maxV);
	if (((long)width*(long)height*3L) > fileSize) { /* sanity check */
	    ReleasePtr(filBuffH);
	    TUTORfree_handle(filBuffH);
	    return(-3);
	}
	*inP++ = NEWLINE; /* insure terminated with newline */
	outP = inP; /* put binary bytes right after ascii header */
	for(rowI=0; rowI<height; rowI++) {
	    for(colI=0; colI<width; colI++) {
		for(cii=0; cii<3; cii++) {
		    if ((inP-filBuffP) > fileSize)
			break; /* sanity check */
		    inP = next_str(inP,&pixelV);
		    *outP++ = pixelV;
		} /* cii for */
	    } /* colI for */
	} /* rowI for */
    } /* P3 if */
	
    /* parse width, height */

    inP = next_str(filBuffP+2,&width);
    inP = next_str(inP,&height);
    inP = next_str(inP,&maxV);
    inP++; /* advance past newline */
    headerH = TUTORmem_to_region(2,width,height,HNULL,inP); /* build image from data */
    if (!headerH) {
	return(-2); /* no memory? */
    }
	return(headerH);
	
} /* TUTORload_region_ppm */

/* ------------------------------------------------------------------- */

static unsigned char FAR *next_str(cP,retV)
unsigned char SHUGE *cP; /* pointer to next byte in input */
int *retV; /* pointer to return value */

{	int altNL; /* alternate NEWLINE value */
	int nStr;
	char vStr[8];

	if (NEWLINE == 0x0d) altNL = 0x0a;
	else altNL = 0x0d;
	
	do {	
		while ((*cP == ' ') || (*cP == '\t') || (*cP == NEWLINE) || (*cP == altNL))
			cP++;
		if (*cP == '#') 
			while ((*cP != NEWLINE) && (*cP != altNL)) 
				cP++; /* advance past comment */
		while ((*cP == ' ') || (*cP == '\t') || (*cP == NEWLINE) || (*cP == altNL))
			cP++;
	} while (*cP == '#'); /* skip thru comments */
	nStr = 0; /* no numeric chars yet */
	while ((*cP >= '0') && (*cP <= '9')) {
		if (nStr < 7) vStr[nStr++] = *cP;
		cP++;
	}
	vStr[nStr] = 0; /* terminate string */
	sscanf(vStr,"%d",retV);
	
	return(cP);
	
} /* next_str */

/* ******************************************************************* */

int TUTORfile_region_ppm(fRef,regionID) /* save region to file */
FileRef FAR *fRef; /* pointer to file description */
long regionID; /* handle on saved region */

{   Memh headerH; /* handle on region header */
    struct saved_region FAR *headerP; /* pointer to region header */
    Memh outPixelsH; /* handle on output pixels */
    unsigned char FAR *outPixelsP; /* pointer to output pixel data */
    int width; /* width of bitmap containing screen region */
    int height; /* height of bitmap containing screen region */
    int fIndx; /* index of file */
    long pixelsSize; /* size of PPM file pixel data */
    long nWrote; /* number bytes written to file */
    char dimenStr[12]; /* width/height string */

	/* convert pixel data if neccessary */
	
	headerH = regionID;
	outPixelsH = TUTORget_rgb_region(headerH);
	if (!outPixelsH) return(0);
	
	/* get image size */
	
	headerP = (struct saved_region FAR *)GetPtr(headerH);
	width = headerP->width;
	height = headerP->height;
	pixelsSize = 3L*width*height;
	ReleasePtr(headerH);
	KillPtr(headerP);
	
    /* open and write file */

    fIndx = TUTORopen(fRef,FALSE,TRUE,FALSE);
    if (!fIndx)
		return(FALSE);
		
	TUTORwrite("P6\012",1,3L,fIndx);
	sprintf(dimenStr,"%d %d\012",width,height);
	TUTORwrite(dimenStr,1,(long)strlen(dimenStr),fIndx);
	TUTORwrite("255\012",1,4L,fIndx);
	outPixelsP = (unsigned char FAR *)GetPtr(outPixelsH);
	nWrote = TUTORwrite((char FAR *)outPixelsP,(int)sizeof(char),pixelsSize,fIndx); 
	TUTORclose(fIndx);
	
	ReleasePtr(outPixelsH);
	
	return(nWrote == pixelsSize);
	
} /* TUTORfile_region_ppm */

/* ******************************************************************* */

int TUTORinq_region_info(regionID,width,height) /* get width, height of region */
long regionID;
int *width;
int *height;

{   Memh headerH; /* handle on region header */
    struct saved_region FAR *headerP; /* pointer to region header */

    headerH = (Memh)regionID;
    if (!headerH) {
    	*width = *height = 0;
    	return(0);
    }
    headerP = (struct saved_region FAR *)GetPtr(headerH);
    *width = headerP->width;
    *height = headerP->height;
    ReleasePtr(headerH);
    return(0);
    
} /* TUTORinq_region_info */

/* ******************************************************************* */

Memh TUTORalloc_palette(nSlots) /* allocate cT palette */
int nSlots; /* size of palette */

{   long bSize; /* size of palette in bytes */
    Memh retH;
    struct CTcolorentry FAR *palP;
    int pii;
	
    if (nSlots > 256)
	nSlots = 256;
    if (nSlots < 2)
	nSlots = 2;
    bSize = nSlots*sizeof(struct CTcolorentry);
    retH = TUTORhandle("palette",bSize,TRUE);
    if (!retH)
	return(HNULL);
	
    palP = (struct CTcolorentry FAR *)GetPtr(retH);
    TUTORzero((char FAR *)palP,bSize);
    for(pii=0; pii<nSlots; pii++)
	(palP+pii)->realV = -1;
    ReleasePtr(retH);

    TUTORpurge_info(retH,M_WORM,FARNULL,0);
    AllowHandlePurge(retH);


    return(retH);
	
} /* TUTORalloc_palette */

/* ******************************************************************* */

int TUTORfree_palette(palH) /* release cT palette */
Memh palH;

{	int wix;

	if (palH && (palH != defaultPalette) && (palH != oldDefaultPalette))
		TUTORfree_handle(palH);
		
	for(wix=0; wix<WINDOWLIMIT; wix++) {
		if (windowsP[wix].paletteH == palH)
			windowsP[wix].paletteH = HNULL;
	} /* for */
	
	return(0);
	
} /* TUTORfree_palette */

/* ******************************************************************* */

int PaletteMatch(paletteP,nColors,redC,greenC,blueC)
struct CTcolorentry FAR *paletteP; /* pointer to cT palette */
int nColors; /* number colors in palette */
unsigned int redC,greenC,blueC; /* 16-bit color values */

{   int pii; /* index in palette */
    int bestSlot; /* best slot found so far */
    long dist;
    long bestDist; /* distance of best slot */
    long curDist; /* distance of current slot */
    double redD,greenD,blueD;
    double h1,s1,v1;
    double h2,s2,v2;
    struct CTcolorentry FAR *searchP; /* pointer for search */
    int searchHSV; /* TRUE if should use HSV search */

    redD = (((double)redC)/(double) 0xffff) * 100.0;
    greenD = (((double)greenC)/(double) 0xffff) * 100.0;
    blueD = (((double)blueC)/(double) 0xffff) * 100.0;
    TUTORrgb_to_hsv(redD,greenD,blueD,&h1,&s1,&v1);

    searchHSV = TRUE;
    if ((s1 < 1.0) || (v1 < 1.0))
		searchHSV = FALSE; /* use RGB search */
	if ((redC >= 0xff00) || (greenC >= 0xff00) || (blueC >= 0xff00))
		searchHSV = FALSE; /* use rgb search if strong color */

    /* handle palette-based display */

    searchP = paletteP;
    bestSlot = 0;
    bestDist = 0x7fffffffL;
    for(pii=0; pii<nColors; pii++) {
	h2 = searchP->cHue/4.0;
	s2 = searchP->cSaturation/4.0;
	v2 = searchP->cValue/4.0;
	if (searchHSV) {
	    curDist = ColorDistanceHSV(h1,s1,v1,h2,s2,v2);
	} else {
	    curDist = ColorDistance(redC,greenC,blueC,
			   searchP->red,searchP->green,searchP->blue);
	}
	if (curDist < bestDist) {
	    bestDist = curDist; /* best match so far */
	    bestSlot = pii;
	    if (bestDist == 0)
		break; /* perfect match */
	} /* if */
	searchP++;
    } /* for */
    return(bestSlot); /* best match found */
	
} /* PaletteMatch */

/* ******************************************************************* */

uplow(str) /* convert upper case to lower case */
char FAR *str;

{   char FAR *cp;
    int cc;

    cp = str;
    while (*cp) {
        cc = *cp++;
        if ((cc >= 'A') && (cc <= 'Z'))
            *(cp-1) = (cc-'A')+'a'; /* convert to lower case */
    } /* while */
    
} /* uplow */

/* ******************************************************************* */

int TUTORmem_alert()

{	int wix;

	wix = -1;
	if (EditWn[0] >= 0) wix = EditWn[0];
	else if (ExecWn) wix = ExecWn;
	
	if (wix < 0)
		return(0); /* didn't make it up far enough to have a window */
		
	TUTORalert(wix,"Out of memory, please save your work.");
	return(0);
	
} /* TUTORmem_alert */

/* ******************************************************************* */
