/*
A component of the cT (TM) programming environment.
(c) Copyright 1997 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/
                     
#include <stdio.h>
#include "baseenv.h"
#include "kdefs.h"
#include "editmenu.h"
#include "tutor.h"
#include "editor.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "edglobal.h"
#include "txt.h"
#include "txtv.h"
#include "ct_ctype.h"
#include "execdefs.h"
#include "commands.h"
#include "eglobals.h"
#include "exprdefs.h"
#include "kglobals.h"

/* ******************************************************************* */

#ifdef ctproto
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,
 int ebsref,struct  _trect *theR,int  relInfo,int  mintw,int  wrap,
 unsigned int  doc,long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),
 int  ro,int  corner,int  erase,int  frame,int tabsz,int lm,int rm,int inhss,int type);
extern int DebugOpenWindow(void);
extern int DebugAfterStep(int token);
extern int DebugExpr(Memh idocH,long *iRet,double *fRet,Memh rdocH,char **msgRet);
extern int DebugExprDisplay(void);
extern int DebugStackDisplay(void);
extern int DebugHiliteLine(int unitn,long xloc);
extern int DebugClearExpr(void);
extern int DebugHalt(void);
extern int DebugClearStep(void);
extern int DebugDefaultStyles(Memh doc);
extern int TUTORforward_window(int wix);
int  CTset_foreground_color(int  cn);
int  CTset_background_color(int  cn);
int  CTset_window_color(int  cn);
extern int EditForward(void);
extern int procDebug(Memh debugH, struct tutorevent *cev);
extern int procAuxDebug(Memh dbgH, struct tutorevent *event);
unsigned int  TUTORnew_button(int  wn,unsigned int  owner,unsigned int  objH,int objR,
      struct  _trect *tr,int  kind,
      int  thick,int  bFont,char  *title,Memh titleD,unsigned int  destH,
      int  (*DestProc)(),int  destMsg,
      int  destMsg1,double  destMsg2,int erase);
int  TUTORalert(int  wn,char  *msg);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,int ebsref,
	struct  _trect *theR,int  relInfo,int  mintw,int  wrap,unsigned int  doc,long  pos,
	long  len,int  wantV,int  wantH,int  (*KeyF)(),int  ro,int  corner,int  erase,
	int  frame,int tabsz,int lm,int rm,int inhss,int type);
struct  tutorview FAR *TUTORinq_view(void);
int  TUTORabs_move_to(int  x,int  y);
int  TUTORdefault_styles_doc(unsigned int  doc,short  FAR *defStyles);
int  TUTORdraw_text(unsigned char  FAR *buf,int  count);
int  TUTORinq_abs_string_width(unsigned char  FAR *s,int  lth,int *dx);
int  AddParaLayout(struct  _paral *pl);
int  TUTORinq_font_descr(int  fontN,long *fam,int  *siz,int  *fac);
extern int TUTORset_textfont2(long family, int size, int face);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
int  TUTORset_view(struct  tutorview FAR *vp);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int  TUTORset_window_title(int  wid,char  *wt);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORstyle_hot_doc(unsigned int  doc,long  pos,long  len,unsigned char FAR *ss,long  sLen);
char  *strf2n(char  FAR *strp);
int  TUTORcreate_window(int  top,int  left,int  xSize,int  ySize,int  type);
long  get_exec_pt(void);
int  GetUnitName(int  unitn,unsigned char  *name);
int  TUTORset_program_name(char  *pname);
extern int TUTORmem_alert(void);
int  TUTORdelete_menu(unsigned int  barh,char  *card,char  *item);
int  TUTORadd_menu(unsigned int  barh,char  *card,int  cp,char  *item,int  ip,int  keyBind,int  type,int  unit,double  unitArg,int  eType);
extern long  FindSourceLine(int  unitn,long xloc);
int  _TUTORinq_state_internal_marker(int  ind,long  *pos,long  *len,int  *altered);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
extern  int TUTORpost_event(struct tutorevent *event);
int  TUTORinq_abs_clip_rect(struct  _trect *cr);
int  TUTORclip_window(int  wid);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
extern  struct tutorview FAR *TUTORinit_view(int sW,unsigned int vDat,int (*vProc)());
extern  int TUTORset_abs_clip_rect(TRect FAR *cr);
int  TUTORset_event_mask(int  eventc,int  value);
extern int TUTORzero(char SHUGE *ptr,long length);
int TUTORclose_button(Memh bH);
int  ReleasePtr(unsigned int  mm);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORclose_view(struct  tutorview FAR *vp);
extern int TUTORclose_window(int wid);
unsigned int  TUTORinit_menubar(int  nItems);
int  TUTORadd_menu(unsigned int  barh,char  *card,int  cp,char  *item,int  ip,int  keyBind,int  type,int  unit,double  unitArg,int  eType);
int  TUTORmodify_menu(unsigned int  barh,char  *card,char  *item,int  enableFlag,int  checkFlag,int  style);
int  TUTORset_menubar(unsigned int  barh,struct  tutorview FAR *newMenuView);
int  TUTORdelete_menu(unsigned int  barh,char  *card,char  *item);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  DebugDefaultStyles(unsigned int  doc);
int  TUTORclose_panel(unsigned int  theV);
int  TUTORclose_doc(unsigned int  doc);
int  RestartPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  selStart,long  selLen);
extern int  KFilterExpr(long  ownerDat,unsigned int  textv,struct  tutorevent *cev);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
extern int set_wk_defset(Memh setH);
int  TUTORdealloc(char  FAR *ptr);
int  exec_compute(short  FAR *codep);
int  TUTORshow(int type,double  value,int  sigfig,char  *ss);
int  TUTORclear_doc(unsigned int  doc);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
int release_define_chain(Memh startH);
extern int set_wk_defset(Memh setH);
unsigned char  SHUGE *LockStack(void);
int  ReleaseStack(void);
int  TUTORclear_doc(unsigned int  doc);
int  TUTORget_zfont(char  *famS,int  size);
int  TUTORset_textfont(int  jj); 
extern int chkDebExeOverlap(void);
#endif /* ctproto */

extern struct  tutorview FAR *TUTORinq_view(void);
extern long  get_exec_pt(void);
extern int KFilterExpr();
extern int DebugExpr();
extern int DebugExprDisplay();
extern int procDebug();
extern int procAuxDebug();

extern int execrun;

/* ******************************************************************* */

typedef struct _debugdat {
	int token; /* current (just executed) command */
	int into; /* TRUE if stepping into -do-ne unit */
	int valid; /* TRUE if have valid expression */
	int auxDisplay; /* 0 = unknown, 1 = stack, 2 = marker */
	Memh runBH; /* handle on run button */
	Memh stepBH; /* handle on step button */
	Memh intoBH; /* handle on into (subroutine) button */
	Memh stackBH; /* handle on stack button */
	Memh inPanelH; /* input panel */
	Memh inDocH; /* input document */
	Memh rPanelH; /* result panel */
	Memh rDocH; /* result document */
	Memh auxPanelH; /* auxiliary window panel */
	Memh auxDocH; /* document for auxiliary debug window */
	int rUnit; /* unit of expression */
	long rStackRel; /* stack depth of expression */
	int swContext; /* TRUE if context set by stack window */
	int swUnit; /* unit number set to */
	long swLvars; /* base of lvars set to */
	long swStackRel; /* stack level set to */
	int fontN; /* font used for display */
	long dbFamily; /* font family */
	int dbSize; /* font size */
	int dbFace; /* font face */  
	int warnOneShot; /* warning message issued flag */
	char auxTitleStr[22]; /* auxiliary window title */
} DebugData;

static Memh debugDatH = HNULL; /* handle on debug data */
static Memh debugMenu = HNULL; /* handle on menus */

#define RUNPUSH 1 /* run button pushed */
#define STEPPUSH 2 /* step button pushed */
#define INTOPUSH 3 /* into button pushed */
#define STACKPUSH 4 /* stack button pushed */
#define EXPRPUSH 5 /* RETURN key pressed to evaluate expression */
#define IDLEPUSH 6 /* mock push to keep window active */

#define DTEXTSIZE 16 

int AuxWn = -1;	/* auxiliary debug window */
struct tutorview FAR *AuxVp = 0;

/* ******************************************************************* */

int DebugOpenWindow()

{   struct tutorview FAR *cv; /* current view */
    int uii; /* index in units */
    DebugData FAR *dDatP; /* pointer to debug info */
    TRect buttonB; /* bounding box for button */
    TRect panelB; /* bounding box for text panel */
	int info; /* edit panel setup */
	TextVDat FAR *vp; /* text panel info */ 
	long fFam; /* font family */
	int fSize; /* font size */
	int fFace; /* font face */
	int bKind; /* button kind */

	if (DebugWn >= 0) return(0);
	
	/* quick check to see if memory available */
	
    debugDatH = TUTORhandle("debugdata",(long)5000L,TRUE);
    if (!debugDatH) {
    	TUTORmem_alert();
    	return(0);
    }
    TUTORfree_handle(debugDatH);
	
	/* create debug window */
	
    cv = TUTORinq_view(); /* remember current view */
    TUTORset_view(FARNULL); /* save current view */
    DebugWn = TUTORcreate_window(-1,-1,0,0,DEBUGW);
    if (DebugWn < 0) 
    	goto rview;
    windowsP[DebugWn].wproc = (int(*)())(procDebug); 	
    TUTORset_program_name("Debug");
    
    /* initialize debug window event mask */
    
    TUTORset_event_mask(EVENT_LEFTDOWN,TRUE);
    TUTORset_event_mask(EVENT_LEFTUP,TRUE);
    TUTORset_event_mask(EVENT_RIGHTDOWN,TRUE);
    TUTORset_event_mask(EVENT_RIGHTUP,TRUE);
    TUTORset_event_mask(EVENT_DOWNMOVE,TRUE);
    TUTORset_event_mask(EVENT_MENU,TRUE);
    TUTORset_event_mask(EVENT_MSG,TRUE);
    TUTORset_event_mask(EVENT_FWD,TRUE);
    TUTORset_event_mask(EVENT_VFOCUS,TRUE);
    TUTORset_event_mask(EVENT_WFOCUS,TRUE);
    TUTORset_event_mask(EVENT_SCROLL,TRUE);
    TUTORset_event_mask(EVENT_KEY,TRUE);

	/* create debug info + view */
	
    debugDatH = TUTORhandle("debugdata",(long) sizeof(DebugData),TRUE);
    if (!debugDatH) 
    	goto rview;
    dDatP = (DebugData FAR *)GetPtr(debugDatH);
    TUTORzero((char FAR *)dDatP,(long)sizeof(DebugData));
    DebugVp = TUTORinit_view(DebugWn,0,procDebug);
    TUTORset_view(DebugVp);
    fgndColor.palette = -4; /* not set */
    bgndColor.palette = -4;
    CTset_foreground_color(color_black);
    CTset_background_color(color_white);
    CTset_window_color(color_white);
    
    dDatP->fontN = TUTORget_zfont("zsans",DTEXTSIZE);
	TUTORset_textfont(dDatP->fontN);  
    TUTORinq_font_descr(dDatP->fontN,&fFam,&fSize,&fFace);	  
    dDatP->dbFamily = fFam;
    dDatP->dbSize = fSize;
    dDatP->dbFace = fFace;
    
    /* create run, step, into and stack buttons */
    
    buttonB.left = 8;
    buttonB.top = 4;
    buttonB.right = 72;
    buttonB.bottom = 28;
#ifdef MAC
    bKind = 0;
#else
	bKind = 3;
#endif
    dDatP->runBH = TUTORnew_button(DebugWn,HNULL,0,0,&buttonB,
			bKind,1,-1,"Run",HNULL,debugDatH,
            procDebug,BUTTONSIGNAL,RUNPUSH,0.0,FALSE);
    buttonB.left += 64+10;
    buttonB.right += 64+10;
	dDatP->stepBH = TUTORnew_button(DebugWn,HNULL,0,0,&buttonB,
			bKind,1,-1,"Step",HNULL,debugDatH,
            procDebug,BUTTONSIGNAL,STEPPUSH,0.0,FALSE); 
    buttonB.left += 64+10;
    buttonB.right += 64+10;
	dDatP->intoBH = TUTORnew_button(DebugWn,HNULL,0,0,&buttonB,
			bKind,1,-1,"Into",HNULL,debugDatH,
            procDebug,BUTTONSIGNAL,INTOPUSH,0.0,FALSE);   
    buttonB.left += 64+10;
    buttonB.right += 64+10;
	dDatP->stackBH = TUTORnew_button(DebugWn,HNULL,0,0,&buttonB,
			bKind,1,-1,"Stack",HNULL,debugDatH,
            procDebug,BUTTONSIGNAL,STACKPUSH,0.0,FALSE);  
  	
  	/* initialize auxiliary window document */
  	
    dDatP->auxDocH = TUTORnew_doc(TRUE,TRUE); /* set up document */
	DebugDefaultStyles(dDatP->auxDocH);	
  	
  	/* initialize input document + text panel */
  	
  	dDatP->inDocH = TUTORnew_doc(TRUE,TRUE); /* set up document */
	DebugDefaultStyles(dDatP->inDocH); 
	TUTORset_textfont(dDatP->fontN);
  	info = LEFTSTICK | TOPSTICK; /* | RIGHTSTICK  | BOTTOMSTICK;  */     
    panelB.left = 42;
    panelB.top = 36;
    panelB.right = windowsP[DebugWn].wxsize-8;
    panelB.bottom = panelB.top+24;         

    dDatP->inPanelH = MakeTextPanel(DebugWn,(long)dDatP->inDocH,0,0,(TRect *)&panelB,info,
            100,FALSE,dDatP->inDocH,0L, -1L,FALSE,FALSE,KFilterExpr,FALSE,FALSE,FALSE,TRUE,
            -1,-1,-1,FALSE,7);
	vp = (TextVDat FAR *)GetPtr(dDatP->inPanelH);  
	windowsP[DebugWn].MouseFocus = windowsP[DebugWn].KeyFocus = vp->view;
	RestartPanel(vp,0L,0L /* len */,0L,0L);
	ReleasePtr(dDatP->inPanelH);
	
	/* initialize output document + text panel */
  	
  	dDatP->rDocH = TUTORnew_doc(TRUE,TRUE); /* set up document */
	DebugDefaultStyles(dDatP->rDocH);
   /* info = LEFTSTICK | RIGHTSTICK | TOPSTICK | BOTTOMSTICK;      */
    info = LEFTSTICK | TOPSTICK;
    panelB.left = 8;
    panelB.top = 68;
    panelB.bottom = panelB.top+24;
    dDatP->rPanelH = MakeTextPanel(DebugWn,(long)dDatP->rDocH,0,0,(TRect *)&panelB,info,
            100,FALSE,dDatP->rDocH,0L, -1L,FALSE,FALSE,FARNULL,TRUE,FALSE,FALSE,TRUE,
            -1,-1,-1,FALSE,5);
	vp = (TextVDat FAR *)GetPtr(dDatP->rPanelH);
	RestartPanel(vp,0L,0L /* len */,0L,0L);
	ReleasePtr(dDatP->rPanelH);
  	ReleasePtr(debugDatH); 
		
	TUTORclip_window(DebugWn); /* clip to entire window */  	
    TUTORabs_move_to(8,52);
    TUTORdraw_text((unsigned char FAR *)"Expr:",5); 
    
	/* initialize menu */

	if (!debugMenu) 
    	debugMenu = TUTORinit_menubar(5);
    windowsP[DebugWn].menus = 0L; /* no menus yet */
    TUTORadd_menu(debugMenu,"Option",10,"Edit Program",60,0,edit_debug,1,0.0,EVENT_MENU); 
    TUTORadd_menu(debugMenu,"Option",10,"Debug",61,0,edit_debug,2,0.0,EVENT_MENU); 
    TUTORset_menubar(debugMenu,DebugVp);
                	
    /* initialize for debugging - set to recompile */
    
	for (uii = 0; uii < nunits; uii++) 
		unittab[uii].compiled = FALSE;	
		
	/* be sure focus is on debug window*/
	
	TUTORforward_window(DebugWn);
	
rview:
	TUTORset_view(cv);
	return(0);
	
} /* DebugOpenWindow */

/* ******************************************************************* */

static int AuxOpenWindow()

{	struct tutorview FAR *cv; /* current view */
	DebugData FAR *dDatP; /* pointer to debug info */
	int info; /* edit panel setup */
	TextVDat FAR *vp; /* text panel info */

	if ((DebugWn < 0) || (AuxWn >= 0))
		return(0); 
	
	/* create debug window */
	
    cv = TUTORinq_view(); /* remember current view */
    TUTORset_view(FARNULL); /* save current view */
    AuxWn = TUTORcreate_window(-1,-1,0,0,DEBUGAUXW);
    if (AuxWn < 0) 
    	goto rview;
    windowsP[AuxWn].wproc = (int(*)())(procAuxDebug); 	
    
    /* initialize auxiliary debug window event mask */
    
    TUTORset_event_mask(EVENT_LEFTDOWN,TRUE);
    TUTORset_event_mask(EVENT_LEFTUP,TRUE);
    TUTORset_event_mask(EVENT_RIGHTDOWN,TRUE);
    TUTORset_event_mask(EVENT_RIGHTUP,TRUE);
    TUTORset_event_mask(EVENT_DOWNMOVE,TRUE);
    TUTORset_event_mask(EVENT_HOT,TRUE);
    TUTORset_event_mask(EVENT_MENU,TRUE);
    TUTORset_event_mask(EVENT_MSG,TRUE);
    TUTORset_event_mask(EVENT_FWD,TRUE);
    TUTORset_event_mask(EVENT_VFOCUS,TRUE);
    TUTORset_event_mask(EVENT_WFOCUS,TRUE);
    TUTORset_event_mask(EVENT_SCROLL,TRUE);
    TUTORset_event_mask(EVENT_KEY,TRUE);

	/* create auxiliary debug view */
	
    AuxVp = TUTORinit_view(AuxWn,0,procAuxDebug);
    TUTORset_view(AuxVp); 
    
  	/* initialize text panel */
  	
  	dDatP = (DebugData FAR *)GetPtr(debugDatH);
    info = LEFTSTICK | RIGHTSTICK | TOPSTICK | BOTTOMSTICK;
    dDatP->auxPanelH = MakeTextPanel(AuxWn,(long)dDatP->auxDocH,0,0,(TRect *)NEARNULL,info,
            100,TRUE,dDatP->auxDocH,0L, -1L,TRUE,TRUE,FARNULL,FALSE,FALSE,FALSE,TRUE,
            -1,-1,-1,FALSE,7);
    if (!dDatP->auxPanelH) { /* out of memory */
    	ReleasePtr(debugDatH);
    	TUTORclose_view(AuxVp);
    	goto rview;
    }		    
	vp = (TextVDat FAR *)GetPtr(dDatP->auxPanelH);
	RestartPanel(vp,0L,0L /* len */,0L,0L);
	ReleasePtr(dDatP->auxPanelH);
  	ReleasePtr(debugDatH); 

	/* initialize menu */

    TUTORset_menubar(debugMenu,AuxVp);
	
rview:
	TUTORset_view(cv);
	return(0);

} /* AuxOpenWindow */

/* ******************************************************************* */

DebugAfterStep(token)
int token; /* current (just executed) command code */

{   long tempL;
    long posL,lenL; /* position/length of unit */
    int valid; /* TRUE if have valid expression */
    int doStack; /* TRUE if should update stack display */
	DebugData FAR *dDatP; /* pointer to debug info */
	struct tutorevent gevent;
	int exprUnit; /* unit of expression */
	long exprStackRel; /* stack depth of expression */
	TextVDat FAR *vdp; /* pointer to text panel info */
		    
    if (DebugWn < 0)
    	return; /* can't open window */
    	
    if (exS.stepMode == 2) { /* stepping over -do- */
    	tempL = exS.stackpntr-exS.stackP;
    	if (tempL > exS.stepStackTarget)
    		return; /* stepping over -do- */
		exS.stepMode = 1; /* done stepping over -do- */
		exS.stepStackTarget = 0; /* clear target */
	} /* stepMode if */
	        
   	dDatP = (DebugData FAR *)GetPtr(debugDatH); 
   	dDatP->token = token; /* save current command */ 
   	if (dDatP->swContext) {
   		dDatP->swContext = FALSE; /* no longer in context set by stack window */
   		dDatP->valid = FALSE;
   	}
   	valid = dDatP->valid; /* remember if expression valid */
   	exprStackRel = dDatP->rStackRel; /* remember stack depth */
   	exprUnit = dDatP->rUnit; /* remember unit number */
   	doStack = (dDatP->auxDisplay == 1); /* TRUE if should update stack display */
    ReleasePtr(debugDatH);   
    
    if ((token == C_LBEGIN) || (token == C_LEND) || (token == C_SLICE) ||
        (token == C_STRING) || (token == C_COND) || (token == C_CONDOUT))	
    	return; /* don't halt for these commands */
    	
    if (exS.inText || exS.inOver || (exS.execunit < 0))
     	return;	
     	        	
    if (execrun) {
		execrun = FALSE; /* return from executor */
		waitflag = atdebug;
    }  
    
    /* clear expression result if scope invalid */
    
    if (valid) {
        ReleaseStack(); /* be sure stack floating */
        if (exS.LockStackRel < exprStackRel) {
			DebugClearExpr();
			valid = FALSE;
		}
	} /* valid if */   
	 
    /* generate event to editor to highlight line */
    
    tempL = get_exec_pt()+1; /* just past current execution pos */
    DebugHiliteLine(exS.execunit,tempL); /* locate source line */
    
    /* generate event to update stack window */
    
    if (doStack) {
    	TUTORzero((char FAR *)&gevent,(long)sizeof(struct tutorevent));
        gevent.window = DebugWn;
        gevent.view = DebugVp;
        gevent.vproc = procDebug;
        gevent.type = EVENT_SIGNAL;
        gevent.value = STACKPUSH;
    	TUTORpost_event(&gevent); /* send event to debug window */
    }		
    
    /* generate event to update expression */	
    
    TUTORzero((char FAR *)&gevent,(long)sizeof(struct tutorevent));
    gevent.window = DebugWn;
    gevent.view = DebugVp;
    gevent.vproc = procDebug;
    gevent.type = EVENT_SIGNAL;
    if (valid)
    	gevent.value = EXPRPUSH;
    else
    	gevent.value = IDLEPUSH;
    TUTORpost_event(&gevent); /* send event to debug window */
    
    if (waitflag != atdebug) {
     	TUTORforward_window(ExecWn); /* switch to executor */
    	return;
    }
    	
    TUTORforward_window(DebugWn);

} /* DebugAfterStep */

/* ******************************************************************* */

int DebugClearStep() { exS.stepMode = 0; return(0); }

/* ******************************************************************* */

int DebugHalt() /* clean up debugger when executor halted */
/* doesn't clear exS.stepMode as can be called during -jumpout- */

{	DebugData FAR *dDatP; /* pointer to debug info */
	TextVDat FAR *vp; /* pointer to text panel info */
	struct tutorview FAR *cv; /* current view */
	
	if ((DebugWn < 0) || (!debugDatH))
		return;
		
	cv = TUTORinq_view();
	TUTORset_view(DebugVp); /* set to debug view */
	DebugClearExpr(); /* clear expression */
	dDatP = (DebugData FAR *)GetPtr(debugDatH);
	dDatP->valid = dDatP->swContext = FALSE;
	TUTORclear_doc(dDatP->auxDocH); /* clear auxiliary window content */
	if (AuxWn >= 0) {
		TUTORset_view(AuxVp);
		vp = (TextVDat FAR *)GetPtr(dDatP->auxPanelH);
		RestartPanel(vp,0L,0L /* len */,0L,0L);
		ReleasePtr(dDatP->auxPanelH);	
	}
	ReleasePtr(debugDatH);
	TUTORset_view(cv); /* restore view */
	return(0);
	
} /* DebugHalt */

/* ******************************************************************* */

static int procDebug(Memh dbgH, struct tutorevent *event)

{	int wix; /* index of window */
	TRect clipR; /* saved clip rectangle */
	TRect eRect; /* rectangle to erase */
	struct tutorview FAR *viewP; /* pointer to view */
	struct tutorevent gevent; /* event for editor */
	DebugData FAR *dDatP; /* pointer to debug info */
	int uii; /* index in units */
	int doRun; /* TRUE if need to generate run event for editor */
	int doFwd; /* window number if should bring window forward */
	
	wix = event->window;
	doRun = FALSE;
	doFwd = -1;

	switch (event->type) {
	
    case EVENT_REDRAW:
    	TUTORset_view(DebugVp);
        TUTORinq_abs_clip_rect(&clipR); /* save clip */
		TUTORclip_window(wix); /* clip to entire window */
		eRect.top = eRect.left = 0;
		eRect.bottom = windowsP[wix].wysize;
		eRect.right = windowsP[wix].wxsize;
        TUTORdraw_abs_solid_rect((TRect FAR *)&eRect,PAT_BACKGROUND); 
        dDatP = (DebugData FAR *)GetPtr(debugDatH);    
        TUTORset_textfont(dDatP->fontN);    
        ReleasePtr(debugDatH);
        TUTORabs_move_to(8,52);
        TUTORdraw_text((unsigned char FAR *)"Expr:",5); 
        TUTORset_abs_clip_rect((TRect FAR *) &clipR); /* restore clip */
        
        viewP = windowsP[wix].lastView;
 
        while (viewP) {
        	if (viewP != DebugVp) {
            	TUTORset_view(viewP);
           		(*viewP->vproc) (viewP->vh,event);
           	}
            viewP = viewP->prevView;
        }
        event->type = -1; /* we handled it already */
        break;

    case EVENT_FWD:
        viewP = windowsP[wix].firstView;
        while (viewP) {
        	if (viewP != DebugVp) {
            	TUTORset_view(viewP);
            	(*viewP->vproc) (viewP->vh,event);
            }
            viewP = viewP->nextView;
        }
        event->type = -1;
        break;

    case EVENT_VFOCUS:
        event->type = -1;
        break;
        
    case EVENT_MENU:
    case EVENT_MSG:
    	switch (event->a1) {
    	
    	case edit_debug:
    		if (event->a2 == 1) { /* switch to editor */
    			Halt(); /* stop executor */
    			doFwd = EditWn[0]; /* editor in control */
    		} else if (event->a2 == 2) { /* switch to debugger */
    			doFwd = DebugWn;
    		} else if (event->a2 == 3) { /* switch to auxiliary */
    			doFwd = AuxWn;
    		}
    		event->type = -1;
    		break;
    		
    	} /* switch */
    	break;
    	
    case EVENT_WMKILL: /* window closed by window manager */      
    	event->type = -1;       
    	if (DebugVp)
    		TUTORclose_view(DebugVp);    
    	break;
    	
    case EVENT_DESTROY: /* view closed */
    	if ((wix >= 0) && (wix == DebugWn) && DebugVp) { 
    		DebugWn = -1; /* no reccursion */
    		Halt(); /* stop executor */
    		if (AuxVp)
    			TUTORclose_view(AuxVp); /* close aux window */
    		dDatP = (DebugData FAR *)GetPtr(debugDatH);
    		if (dDatP->runBH)
				TUTORclose_button(dDatP->runBH);
			if (dDatP->stepBH)
				TUTORclose_button(dDatP->stepBH);
			if (dDatP->intoBH)
				TUTORclose_button(dDatP->intoBH);
			if (dDatP->stackBH)
				TUTORclose_button(dDatP->stackBH);
			if (dDatP->inPanelH)
				TUTORclose_panel(dDatP->inPanelH); 
			if (dDatP->rPanelH)
				TUTORclose_panel(dDatP->rPanelH);
			if (dDatP->inDocH)
				TUTORclose_doc(dDatP->inDocH);
			if (dDatP->rDocH)
				TUTORclose_doc(dDatP->rDocH);
			if (dDatP->auxDocH)
				TUTORclose_doc(dDatP->auxDocH);
    		ReleasePtr(debugDatH);
    		TUTORfree_handle(debugDatH);
    		debugDatH = HNULL;
    		DebugVp = FARNULL;
    		TUTORclose_window(wix);
    		
    		exS.stepMode = 0;
			for (uii = 0; uii < nunits; uii++) {
				unittab[uii].compiled = FALSE;	
				if (unittab[uii].debugSetH)
					release_define_chain(unittab[uii].debugSetH); /* only 1 set in chain */
				set_wk_defset(HNULL);
				unittab[uii].debugSetH = HNULL;
			} /* for */
    	} /* wix if */
    	event->type = -1;
        break;

	case EVENT_SIGNAL:
		dDatP = (DebugData FAR *)GetPtr(debugDatH);     
		if (chkDebExeOverlap() && (!dDatP->warnOneShot)) {    
			dDatP->warnOneShot = TRUE;
			TUTORalert(DebugWn,"Debug/Exec windows should not overlap.");    
		}
		switch (event->value) {
		
		case RUNPUSH:
			dDatP->swContext = FALSE; /* out of context set by stack window */
			exS.stepMode = 0;
			if (waitflag == halt) {
				doRun = TRUE; /* generate run event for editor */
			} else if (waitflag == atdebug) {
				waitflag = atinterrupt;
				doFwd = ExecWn; /* focus on executor */
			}
			break;
				
		case STEPPUSH:
		case INTOPUSH:
			dDatP->swContext = FALSE; /* out of context set by stack window */
			if (waitflag == atdebug) 
				waitflag = atinterrupt;
			else if (waitflag == halt)
				doRun = TRUE; /* generate run event for editor */
			exS.stepMode = 1;
			
			/* check if should step over unit */
			
			if (waitflag != halt) { /* must be running */
				ReleaseStack(); /* insure stack floating */
		    	dDatP->into = (event->value == INTOPUSH);
				if (!dDatP->into) {
					exS.stepStackTarget = exS.LockStackRel;
					exS.stepMode = 2; /* stepping over -do- */
				}
			} /* waitflag if */
			doFwd = ExecWn; /* focus on executor */
			break;
		
		case STACKPUSH:
			DebugStackDisplay();
			dDatP->swContext = FALSE; /* out of context set by stack window */
			break;
			
		case EXPRPUSH:
			TUTORset_view(DebugVp); /* may not be our view */
			DebugExprDisplay();
			doFwd = DebugWn; /* focus on debugger */
			break;
			
		case IDLEPUSH:
			doFwd = DebugWn; /* focus on debugger */
			break;
			
		} /* value switch */
		ReleasePtr(debugDatH);
		event->type = -1;
		break;
		      
	case EVENT_KEY: 
		break;
		  
	default:
		break;
	
	} /* switch */
	
	/* generate run event if needed */
	
	if (doRun) {
		TUTORzero((char FAR *)&gevent,(long)sizeof(struct tutorevent));
		gevent.type = EVENT_MENU;
		gevent.window = EditWn[0];
        gevent.a1 = edit_run; /* run from beginning */
        TUTORpost_event(&gevent);
	}
	
	/* pass on events we didn't handle */
	
    if (event->type > 0 && event->view) {
    	if (event->view != DebugVp) {
        	TUTORset_view(event->view);
        	(*event->view->vproc)(event->view->vh,event);
        }
    }
    
    /* switch focus to another window if needed */
    
    if (doFwd >= 0) {
    	if (doFwd == EditWn[0])
    		EditForward(); /* bring correct editor forward */
    	else
    		TUTORforward_window(doFwd);
    }
    	
    event->type = -1; /* no window proc to fall back on */
	return(0);
	
} /* procDebug */

/* ******************************************************************* */

int procAuxDebug(Memh dbgH, struct tutorevent *event)

{	int wix; /* index of window */
	TRect clipR; /* saved clip rectangle */
	TRect eRect; /* rectangle to erase */
	struct tutorview FAR *viewP; /* pointer to view */
	struct tutorevent gevent; /* event for editor */
	DebugData FAR *dDatP; /* pointer to debug info */
	int hotUnit; /* unit number from hot event */
	long hotLvars; /* relative base of lvars in stack */
	long hotUloc; /* location in unit */
	long hotRel; /* relative position in stack */
	int doFwd; /* window to bring forward */
	
	wix = event->window;
	doFwd = -1;
	
	switch (event->type) {
	        
	case EVENT_LEFTUP:
		break;
		
    case EVENT_REDRAW:
    	TUTORset_view(AuxVp);
        TUTORinq_abs_clip_rect(&clipR); /* save clip */
		TUTORclip_window(wix); /* clip to entire window */
		eRect.top = eRect.left = 0;
		eRect.bottom = windowsP[wix].wysize;
		eRect.right = windowsP[wix].wxsize;
        TUTORdraw_abs_solid_rect((TRect FAR *)&eRect,PAT_BACKGROUND);  
        TUTORset_abs_clip_rect((TRect FAR *) &clipR); /* restore clip */
        viewP = windowsP[wix].lastView;
        while (viewP) {
        	if (viewP != AuxVp) {
            	TUTORset_view(viewP);
           		(*viewP->vproc) (viewP->vh,event);
           	}
            viewP = viewP->prevView;
        }
        event->type = -1; /* we handled it already */
        break;

    case EVENT_FWD:
        viewP = windowsP[wix].firstView;
        while (viewP) {
        	if (viewP != AuxVp) {
            	TUTORset_view(viewP);
            	(*viewP->vproc) (viewP->vh,event);
            }
            viewP = viewP->nextView;
        }
        event->type = -1;
        break;

    case EVENT_VFOCUS:
        event->type = -1;
        break;
        
    case EVENT_MENU:
    case EVENT_MSG:
    	if (event->a1 == edit_debug) {
    		if (event->a2 == 1) { /* switch to editor */
    			Halt(); /* stop executor */
    			doFwd = EditWn[0]; /* editor in control */
    		} else if (event->a2 == 2) { /* switch to debugger */
    			doFwd = DebugWn;
    		} else if (event->a2 == 3) { /* switch to auxiliary */
    			doFwd = AuxWn;
    		}
    	} /* a1 if */
    	event->type = -1;
    	break;
    	
    case EVENT_WMKILL: /* window closed by window manager */  
    	event->type = -1;
    	if (AuxVp)
    		TUTORclose_view(AuxVp);
    	break;
    	
    case EVENT_DESTROY: /* view closed */
    	if ((wix >= 0) && (wix == AuxWn) && AuxVp) { 
    		AuxWn = -1; /* no reccursion */
    		dDatP = (DebugData FAR *)GetPtr(debugDatH);
    		dDatP->auxDisplay = 0; /* neither stack nor marker */
    		if (dDatP->auxPanelH)
				TUTORclose_panel(dDatP->auxPanelH); 
			/* auxDocH closed when main debug window closes */
    		ReleasePtr(debugDatH);
    		AuxVp = FARNULL;
    		TUTORclose_window(wix);
    	} /* wix if */
    	event->type = -1;
        break;
		
	case EVENT_HOT:
		if (runflag == halt)
			break;
		sscanf(strf2n(event->eDataP),"%d %ld %ld %ld",&hotUnit,&hotLvars,&hotUloc,&hotRel);
		TUTORdealloc(event->eDataP);
		event->eDataP = FARNULL;
		event->type = -1;
		DebugHiliteLine(hotUnit,hotUloc);
		dDatP = (DebugData FAR *)GetPtr(debugDatH);
		dDatP->swContext = TRUE; /* we have set a context */
		dDatP->swStackRel = hotRel;
		dDatP->swUnit = hotUnit;
		dDatP->swLvars = hotLvars;
		ReleasePtr(debugDatH);
		DebugClearExpr(); /* expression no longer valid */
		break;
		        
	default:
		break;
	
	} /* switch */
	
	/* pass on events we didn't handle */
	
    if (event->type > 0 && event->view) {
    	if (event->view != AuxVp) {
        	TUTORset_view(event->view);
        	(*event->view->vproc)(event->view->vh,event);
        }
    }
    
 	/* switch focus to another window if needed */
    
    if (doFwd >= 0) {
    	if (doFwd == EditWn[0])
    		EditForward(); /* bring correct editor forward */
    	else
    		TUTORforward_window(doFwd);
    }
    	        	
    event->type = -1; /* no window proc to fall back on */
	return(0);
	
} /* procAuxDebug */

/* ******************************************************************* */

static int KFilterExpr(ownerDat,textv,cev) /* key filter for expression panel */
long ownerDat; /* handle of search dialog owner's panel */
Memh textv; /* tview of text panel */
struct tutorevent *cev; /* the key event structure */
/* returns TRUE if we used key, FALSE otherwise */
    
{	struct tutorevent tempEv;   /* for posting end of search event */
    register int ii;
    int postEvent;  /* if TRUE we are done */
    
    /* look thru event for a newline */
    
    postEvent = FALSE; 
    for (ii=0; ii<cev->nkeys; ii++) {
        if (cev->keys[ii] == NEWLINE || cev->keys[ii] == RETURN) {
            cev->nkeys = ii; /* clip out newline */
            postEvent = TRUE;
            break;
        }
    } /* for */
    
    /* post a signal to cause expression to be evaluated */
    
    if (postEvent) {
        TUTORzero((char FAR *)&tempEv,(long)sizeof(struct tutorevent));
        tempEv.type = EVENT_SIGNAL;
        tempEv.value = EXPRPUSH;
		tempEv.window = DebugWn;
		tempEv.vproc = procDebug;
        tempEv.a1 = BUTTONSIGNAL;
        TUTORpost_event(&tempEv);
    } /* postEvent */
    
    return(!cev->nkeys); /* return TRUE if there are no keys left... */
    
} /* KFilterExpr */

/* ******************************************************************* */

static int AuxTitle(titleStr) /* set auxiliary window title + menu */
char *titleStr;

{	DebugData FAR *dDatP; /* pointer to debug info */

	if (AuxWn < 0) return(0); /* nothing to do */
	
	dDatP = (DebugData FAR *)GetPtr(debugDatH);
	if (dDatP->auxTitleStr[0]) { /* delete old menu */
		TUTORdelete_menu(debugMenu,"Option",strf2n(dDatP->auxTitleStr));
	}
	strcpyf(dDatP->auxTitleStr,(char FAR *)titleStr);
	ReleasePtr(debugDatH);
	TUTORset_window_title(AuxWn,titleStr);
    TUTORadd_menu(debugMenu,"Option",10,titleStr,62,0,edit_debug,3,0.0,EVENT_MENU); 
	
	return(0);
	
} /* AuxTitle */

/* ******************************************************************* */

static int DebugExprDisplay() /* evaulate expression and display result */

{	DebugData FAR *dDatP; /* pointer to debug info */
	Memh eDocH; /* handle on expression document */
	Memh tDocH; /* handle on text result document */
	int ret; /* error return for DebugExpr */
	long iRet; /* integer value */
	double fRet; /* floating value */
	TextVDat FAR *vdp; /* pointer to text view */
	long len; /* length of string */
	char *errMsg; /* pointer to error message */
	char msgStr[80];
							
	dDatP = (DebugData FAR *)GetPtr(debugDatH);
	eDocH = dDatP->inDocH;
	tDocH = dDatP->auxDocH;
	dDatP->valid = FALSE; /* pre-set for error */ 
	TUTORset_textfont(dDatP->fontN);
    ReleasePtr(debugDatH);
    
    TUTORclear_doc(tDocH); /* recycle document */
	DebugDefaultStyles(tDocH);
	
    ret = DebugExpr(eDocH,&iRet,&fRet,tDocH,&errMsg);
    msgStr[0] = 0;
    if (ret >= 0) {
    	if (errMsg)
    		strcpy(msgStr,errMsg); /* set error message */
    	else
    		strcpy(msgStr,"Could not evaluate"); /* generic */
    } else if (ret == -1) {
    	fRet = iRet; /* convert to float */
    	TUTORshow(0,fRet,10,msgStr);
    } else if (ret == -2) {
    	TUTORshow(0,fRet,10,msgStr);
    } else if (ret == -3) {
    	if (prfP->debugMarkWin) {
    	
	    	/* open window, set title */
	    	
	  		AuxOpenWindow(); /* get window if don't yet have it */  
	  		len = TUTORget_len_doc(eDocH);
	  		if (len > 20) len = 20; /* keep title short */
	  		TUTORget_string_doc(eDocH,0L,len,(unsigned char *)msgStr);
	  		AuxTitle(msgStr);

			/* display result of marker expression */
			
	  		dDatP = (DebugData FAR *)GetPtr(debugDatH);
	  		dDatP->auxDisplay = 2; /* expression */
	  		len = TUTORget_len_doc(tDocH);
	  		TUTORset_view(AuxVp);
	  		vdp = (TextVDat FAR *)GetPtr(dDatP->auxPanelH);
			RestartPanel(vdp,0L,len,0L,0L);   
			ReleasePtr(dDatP->auxPanelH);
			ReleasePtr(debugDatH); 
			TUTORset_view(DebugVp);
		} /* debugMarkWin if */
		
		/* display unstyled result in expression pane */
		
		msgStr[0] = 0;
		len = TUTORget_len_doc(tDocH);
		if (len > 30) len = 30; /* keep string short */
  		TUTORget_string_doc(tDocH,0L,len,(unsigned char *)msgStr);
    }
    TUTORset_view(DebugVp); /* make sure we have debug view */
    dDatP = (DebugData FAR *)GetPtr(debugDatH);
    if (ret < 0) 
    	dDatP->valid = TRUE;
	eDocH = dDatP->rDocH;
    TUTORclear_doc(eDocH);
	len = strlen(msgStr);
    InsertString(eDocH,0L,(char FAR *)msgStr,len);
    vdp = (TextVDat FAR *)GetPtr(dDatP->rPanelH);
	RestartPanel(vdp,0L,len,0L,0L);
	ReleasePtr(dDatP->rPanelH);
	TUTORclip_window(DebugWn);
	ReleasePtr(debugDatH);
	return(0);
	
} /* DebugExprDisplay */

/* ******************************************************************* */

static int DebugExpr(docH,iRet,fRet,docRet,errMsg) /* evaluate expression for debgger */
Memh docH; /* document containing expression */
long *iRet; /* integer return value */
double *fRet; /* floating return value */
Memh docRet; /* document for text return */
char **errMsg; /* error message return */
/* returns -1 = integer expression */
        /* -2 = floating expression */
        /* -3 = marker expression */
        /*  0 = not running or out of memory */
        /* +n = error code */

{	int ret; /* returned value */
	long srcl; /* length of input source */
	int srci; /* index in input source */
	unsigned char srcbuf[304]; /* buffer for expressions */
	unsigned int pcodei; /* index in pcodes */
	unsigned char FAR *pcptr; /* pointer to pcodes */
	struct expra uexp; /* expr analyzer params */
	int setr; /* setjmp return */
	struct defset FAR *SetP; /* pointer to define set */
	int fresI,iresI,markI; /* indexes in stacks */
	int saveUnit; /* current unit */
	long saveLvars; /* current base of local variables */
	long saveRel; /* current stack depth */
	long extraDumm;
	DebugData FAR *dDatP; /* pointer to debug info */
	
	userExp = -1;	/* flag compile phase of -compute- type operation */
	uexp.errnum = 0; /* no error yet */
	pcptr = NULL; /* no compiled code yet */
	*iRet = 0;
	*fRet = 0.0;
	*errMsg = NEARNULL;

	if ((runflag == halt) || (exS.execunit < 0)) {  
		*errMsg = "Not running";  
		return(0); 
	}
		
	/* set up source / pcode buffer */

	pcptr = (unsigned char FAR *)(TUTORalloc(2000L,TRUE,"comput"));
	if (!pcptr)
		return(0);
			
	/* get expression string from marker */
	
	srcl = TUTORget_len_doc(docH);
	if (srcl > 300)
		srcl = 300;
	TUTORget_string_doc(docH,0L,srcl,(unsigned char FAR *)srcbuf);
	srcbuf[srcl++] = NEWLINE;
	srcbuf[srcl++] = '\0';
	pcodei = srci = 0; /* initialize index in soruce, pcodes */
	
 	/* save current context */
 	
 	ReleaseStack(); /* be sure stack floating */
 	saveRel = exS.LockStackRel; /* save stack depth */
 	saveUnit = exS.execunit; /* save unit info */
 	saveLvars = exS.lvars; 
 	fresI = fresP-fstack; /* save result stack positions */
	iresI = iresP-istack;
	markI = markP-markstack;
	
	/* reset context if set by stack window */
	
    dDatP = (DebugData FAR *)GetPtr(debugDatH);	
    if (dDatP->swContext) { /* if we have set a different context */
    	exS.LockStackRel = dDatP->swStackRel;
    	exS.execunit = dDatP->swUnit;
    	exS.lvars = dDatP->swLvars;
    }
    ReleasePtr(debugDatH);
    
	/* set up -define- variables */

	compunit = exS.execunit;
	userSetH = unittab[exS.execunit].debugSetH; /* get local define set */
	if (userSetH) {
		SetP = (struct defset FAR *)GetPtr(userSetH);
		if ((!SetP->defvarN) && (!SetP->mergeN)) 
			userSetH = HNULL; /* empty set */
		ReleasePtr(unittab[exS.execunit].debugSetH);
	}
	if (!userSetH)
		userSetH = globalSetH; /* use globals if no locals */
	set_wk_defset(userSetH);

	/* set up expression analyzer params */

	uexp.teol = TRUE;      /* eol is legal terminator */
	uexp.tcomma = FALSE;   	
	uexp.tsemic = FALSE;
	uexp.tassign = FALSE;
	uexp.tcolon = FALSE;
	uexp.tparen = FALSE;
	uexp.tembed = FALSE;
	uexp.tcond = FALSE;
	uexp.tpercent = FALSE;
	uexp.userc = FALSE;     /* not -compute- */
	uexp.userd = TRUE;      /* debug expression */
	uexp.reqstore = FALSE;  /* storability info not required */
	uexp.arrayok = FALSE;   /* whole array not allowed */
	uexp.allowsk = FALSE;   /* SKIP not allowed */
	uexp.allowf = FALSE;    /* file variable not allowed */
	uexp.allowm = TRUE;     /* marker result allowed */
	uexp.mfunctst = FALSE;  /* marker functions are not store-able */
	uexp.calc = FALSE;      /* not -calc- command */
	uexp.nogen = FALSE;		/* do generate pcode */
	uexp.rtype = 0;         /* numeric (either int or float) allowed */
	uexp.text = HNULL;      /* no styled string literals */
	uexp.src = srcbuf;      /* source input */
	uexp.srcpos = &srci;
	uexp.pcode = pcptr; /* pcode output to buffer */
	uexp.pcodepos = &pcodei;

	/* set up to handle error and compile expression */

	if (setr = setjmp(uenv)) {
		uexp.errnum = setr;
	} else 
		compile(&uexp); /* compile expression */

	pcptr[pcodei++] = 0; /* insert zero code at end */
	pcptr[pcodei++] = 0;
	set_wk_defset(HNULL); /* no current defines */	
	
	if (xtP) { /* free expression analyzer table */
		ReleasePtr(xtH);
		xtP = NULL;
	}
		
	/* check if error in compile phase */

	if (uexp.errnum) {
	    exS.LockStackRel = saveRel; /* restore context */
    	exS.execunit = saveUnit;
    	exS.lvars = saveLvars;
		TUTORdealloc((char FAR *) pcptr); /* release p-code buffer */
		userExp = 0; /* clear user expression flag */
		*errMsg = uexp.errmess; /* return pointer to error message */
		return(uexp.errnum); /* return error code */
	} /* error if */
	
	/* set up before executing expression */
	    
	exS.loopcounter = exS.shouldint = exS.outcnt = 0;
    if (pcodeh) {
        ReleasePtr(pcodeh);
        pcodep = FARNULL;
    }
    pcodeh = 0;
    
    LockStack(); /* stack must be locked when expression evaluated */
    dDatP = (DebugData FAR *)GetPtr(debugDatH);
    dDatP->rUnit = exS.execunit; /* unit of expression */
 	dDatP->rStackRel = exS.stackpntr-exS.stackP; /* stack depth of expression */
	ReleasePtr(debugDatH);  
    
    execrun = TRUE;
    uexp.errmess = NEARNULL; /* no error message at present */
	 
	/* set up to handle error and execute expression */

	userExp = 1; /* execution phase */
	if (uexp.errnum = setjmp(uenv)) { 
		; /* nothing to do if error */
	} else {
		exec_compute((short FAR *)pcptr); /* execute expression */
		*fRet = fstack[0];
	} /* errnum else */
	userExp = 0; /* clear user expression flag */

	if (pcptr)
		TUTORdealloc((char FAR *)pcptr); /* release p-code buffer */
	
	ret = uexp.errnum; /* set for error */
	if (ret) {
		*errMsg = uexp.errmess; /* return pointer to error message */
	} else {
		if (uexp.exprtype == TMARK) {
			ret = -3; /* marker result */
			markP = &markstack[markI]; /* point to marker result */
 			TUTORchange_doc_doc(docRet,0L,0L,0L,0L,markP->doc,markP->pos,markP->len,&extraDumm,TRUE);
		} else if (uexp.exprtype == TFLOAT) {
			ret = -2; /* floating result */
			*fRet = fstack[fresI];
		} else if (uexp.exprtype == TINT) {
			ret = -1; /* integer result */
			*iRet = istack[iresI];
		}
	} /* ret if */
	
	ReleaseStack(); /* be sure stack floating */
	exS.LockStackRel = saveRel; /* restore context */
    exS.execunit = saveUnit;
    exS.lvars = saveLvars;
	fresP = fstack+fresI; /* restore stack positions */
	iresP = istack+iresI;
	markP = markstack+markI;

	return(ret);

} /* DebugExpr */

/* ******************************************************************* */

static int DebugClearExpr() /* clear current expression result */

{   DebugData FAR *dDatP;
    TextVDat FAR *vdp;
	
    if ((!DebugVp) || (!debugDatH))
	return(0); /* nothing to do */
	
    TUTORset_view(DebugVp); /* be sure using our view */
    dDatP = (DebugData FAR *)GetPtr(debugDatH);
    TUTORclear_doc(dDatP->rDocH);
    vdp = (TextVDat FAR *)GetPtr(dDatP->rPanelH);
    RestartPanel(vdp,0L,0L,0L,0L);
    ReleasePtr(dDatP->rPanelH);
    TUTORclip_window(DebugWn);
    dDatP->valid = FALSE;
    ReleasePtr(debugDatH);
    return(0);
	
} /* DebugClearExpr */

/* ******************************************************************* */

static int DebugStackDisplay() /* generate -do- stack display */

{   DebugData FAR *dDatP; /* pointer to debug info */
	Memh tDocH; /* handle on text document */
	int unitn; /* unit number */
    unsigned char SHUGE *sptr; /* pointer in exS.stackP */
    int stackc; /* current stack item type */
    int sunit; /* current unit number while unstacking */
    long suloc; /* position within unit */
    long slvars; /* current base of lvars while unstacking */
    long stackRel; /* relative location on stack */
    long tempL;
    TextVDat FAR *vdp; /* pointer to text info */
    TViewP vvp; /* pointer to text view */
    char unitname[NAMEL+1];

	AuxOpenWindow(); /* get window if don't have it yet */
	if (AuxWn < 0)
		return(0); /* can't do anything */
		
	if ((runflag == halt) || (exS.execunit < 0))
		return(0);
		
	dDatP = (DebugData FAR *)GetPtr(debugDatH);
	tDocH = dDatP->auxDocH;
	if (dDatP->auxDisplay != 1)
		AuxTitle("Stack"); /* update title */
	dDatP->auxDisplay = 1; /* displaying stack */
    ReleasePtr(debugDatH);
    TUTORclear_doc(tDocH); /* recycle document */
	DebugDefaultStyles(tDocH);	
    
    /* put current unit into text */

	LockStack(); /* be sure stack available */                   
	GetUnitName(exS.execunit,(unsigned char *) unitname);
    strcat(unitname,NEWLINES);
    tempL = strlen(unitname);
   	InsertString(tDocH,0L,(char FAR *)unitname,tempL);
   	suloc = exS.uloc+1;
    stackRel = exS.stackpntr-exS.stackP;
    sprintf(unitname,"%d %ld %ld %ld",(int)exS.execunit,exS.lvarP-exS.stackP,suloc,stackRel);
    TUTORstyle_hot_doc(tDocH,0L,tempL,
                  (unsigned char FAR *)unitname,(long)strlen(unitname));  	
                  
    /* trace backwards thru stack */

    if (exS.stackpntr > (exS.stackP+gvaraddr)) {
        sptr = exS.stackpntr;
        do {
            sptr -= sizeof(long);
            stackc = *(long SHUGE *)sptr; /* pop next item from stack */

            switch (stackc) {

            case STACK_MAIN_UNIT:
            case STACK_UNIT:
                sptr -= sizeof(long);
                sunit = *(long SHUGE *)sptr; /* pop next unit # */
                sptr -= sizeof(long);
                slvars = *(long SHUGE *)sptr; /* pop base of lvars */
                sptr = exS.stackP+slvars; /* pop local variables */
                break;

            case STACK_DO:
            	sptr -= sizeof(long);
            	slvars = *(long SHUGE *)sptr; /* base of local vars */
                sptr -= 2*sizeof(long); /* pop condt, uloc */
                suloc = *(long SHUGE *)sptr; /* location within unit */
                sptr -= sizeof(long); /* pop unit */
                sunit = *(long SHUGE *)sptr; 
#ifdef IBMPC
                sptr -= 44; /* -do- status is 64 bytes on PC */
#endif
                GetUnitName(sunit,(unsigned char *) unitname);
                strcat(unitname,NEWLINES);
                tempL = strlen(unitname);
    			InsertString(tDocH,0L,(char FAR *)unitname,tempL);
    			stackRel = exS.stackpntr-exS.stackP;
    			sprintf(unitname,"%d %ld %ld %ld",sunit,slvars,suloc,stackRel);
        		TUTORstyle_hot_doc(tDocH,0L,tempL,
                           (unsigned char FAR *)unitname,(long)strlen(unitname));
                break;  
            
            case STACK_ARROW:
#ifdef IBMPC
                sptr -= 60; /* -arrow- status is 64 bytes on PC */
#endif
                break;

            case STACK_ARROW_NEST:
                sptr -= (sizeof(struct arrows)+3*sizeof(long));
#ifdef IBMPC
                sptr -= exS.arrExtra; /* remove modulo 64 bytes filler */
#endif
                break;

            default:
                stackc = STACK_MAIN_UNIT; /* exit while */
                break;
                
            } /* switch */
        } while (stackc != STACK_MAIN_UNIT);
    } /* stackpntr if */

    TUTORset_view(AuxVp);  
    tempL = TUTORget_len_doc(tDocH);
	dDatP = (DebugData FAR *)GetPtr(debugDatH);    
    vdp = (TextVDat FAR *)GetPtr(dDatP->auxPanelH);
    vdp->singleSel = TRUE; /* select on single click */
    vvp = (TViewP) GetPtr(vdp->textv);
    vvp->singleSel = TRUE; /* select on single click */
    ReleasePtr(vdp->textv);
	RestartPanel(vdp,0L,tempL,0L,0L);
	ReleasePtr(dDatP->auxPanelH);
	ReleasePtr(debugDatH);
	
	TUTORforward_window(AuxWn); /* bring stack display to front */
	
	return(0);
	
} /* DebugStackDisplay */

/* ******************************************************************* */

static int DebugHiliteLine(exunit,exloc) /* highlight line in source window */
int exunit; /* execution unit */
long exloc; /* execution point */

{   long srcloc; /* starting location of line in source */
    int nchars; /* number chars in line */
    long eventid; /* id of editor event */
    struct tutorevent gevent; /* locally generated event */
    int fileI; /* index of file line is in */
    long tempL;
    long posL,lenL; /* position/length of unit */
   
    srcloc = FindSourceLine(exunit,exloc); /* locate source line */

    if (srcloc >= 0) {
        fileI = unittab[exunit].beginfile; /* index of file */
        if ((fileI < 0) || (fileI > sourcemalloc))
            fileI = 0;
        source = sourcetable[fileI].doc;

        /* find end of source line */

        _TUTORinq_state_internal_marker(unittab[exunit].marki,&posL,&lenL,NEARNULL);
        srcloc += posL;
        nchars = 0;
        while ((nchars < 128) && 
               (TUTORcharat_doc(source,(long)(srcloc+nchars)) != NEWLINE))
            nchars++;
        if (nchars <= 0) nchars = 1; /* always highlight something */
        if ((srcloc+nchars) > (posL+lenL)) {
        	srcloc = posL+lenL-1;
        	nchars = 1;
        }

        /* set up event for editor */

		TUTORzero((char FAR *)&gevent,(long)sizeof(struct tutorevent));
        gevent.window = EditWn[0];
        gevent.view = FARNULL; /* message sent to window */
        gevent.type = EVENT_TIME;
        gevent.value = time_source;
        gevent.timestamp = 0;
        gevent.a1 = FALSE; /* not a FindUnits error */
        gevent.a2 = fileI; /* index in sourcetable */
        gevent.a4 = srcloc; /* pass position+length */
        gevent.a5 = nchars;
    	eventid = TUTORpost_event(&gevent); /* send event to editor */
    } /* edit view if */
    
    return(0);
    
} /* DebugHiliteLine */

/* ******************************************************************* */

DebugDefaultStyles(doc) /* put debugger's default styles on doc */
Memh doc;   /* document to get default styles */
    
{   DebugData FAR *dDatP; /* pointer to debug info */
	ParagraphLayout pLay;   /* the proper paragraph layout */
    short defP; /* the default paragraph style */
    short defStyles[NSTYLES];   /* default styles we want */
    int digitWidth; /* width of a digit (a 5 is used) */

	if (!debugDatH)
		return(0); /* nothing to do */
		
    dDatP = (DebugData FAR *)GetPtr(debugDatH);
    TUTORset_textfont2(dDatP->dbFamily,dDatP->dbSize,dDatP->dbFace);
    TUTORinq_abs_string_width((unsigned char FAR *) "5",1,&digitWidth);
    pLay.tabSize = digitWidth * 8;
    pLay.leftMar = pLay.rightMar = 10;
    pLay.paraIndent = 0;
    defP = (AddParaLayout(&pLay) << 3);
    defP |= LEFTJUST;
    
    defStyles[FONTSTYLE] = dDatP->dbFamily;
    defStyles[SIZESTYLE] = dDatP->dbSize;
    defStyles[FACESTYLE] = dDatP->dbFace;
    defStyles[PARASTYLE] = defP;
    defStyles[COLORSTYLE] = color_black;
    defStyles[HOTSTYLE] = 0;
    TUTORdefault_styles_doc(doc,(short FAR *) defStyles);
    ReleasePtr(debugDatH);
        
    return(0);

} /* DebugDefaultStyles */

/* ******************************************************************* */

    	
