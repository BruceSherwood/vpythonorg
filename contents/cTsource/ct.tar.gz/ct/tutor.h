
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Definitions for TUTORgraphics package
*/

#ifndef _tutorh
#define _tutorh

#ifdef WINPC
#ifndef BYTE
typedef unsigned char BYTE;
#endif
#endif

#define EVENT_KEY 1     /* keyboard */
#define EVENT_LEFTDOWN 2    /* mouse left  button down-transition */
#define EVENT_RIGHTDOWN 3   /* mouse right button down-transition */
#define EVENT_LEFTUP 4      /* mouse left  button up-transition */
#define EVENT_RIGHTUP 5     /* mouse right button up-transition */
#define EVENT_DOWNMOVE 6    /* mouse movement with button down */
#define EVENT_UPMOVE 7      /* mouse movement with button up */
#define EVENT_MENU 8        /* menu selection (view menu) */
#define EVENT_TIME 9        /* timing completed */
#define EVENT_PASTE 10      /* paste */
#define EVENT_PROC 11       /* execute procedure */
#define EVENT_WMKILL 12     /* termination forced by window manager */
#define EVENT_FWD 13        /* window brought forward */
#define EVENT_BEGINLAY 14   /* begin window re-layout */
#define EVENT_ENDLAY 15     /* end window re-layout */
#define EVENT_REDRAW 16     /* redraw window */
#define EVENT_FKEY 17       /* function or special key */
#define EVENT_MSG 18        /* message between tasks (fake menu) */
#define EVENT_WFOCUS 19     /* window focus change */
#define EVENT_SCROLL 20     /* scroll bar */
#define EVENT_VFOCUS 21     /* view focus change */
#define EVENT_DESTROY   22  /* destroy view or window */
#define EVENT_RESIZE 23     /* resize window */
#define EVENT_SIGNAL 24 /* general message (internally generated) */
#define EVENT_HOT 25    /* hot text hit */
#define EVENT_PRINT 26  /* print file */

#define EVENT_N 27      /* number event codes */

/* dictionary menu definitions */

#define dict_select 1           /* select section of dictionary */

/* executor menu definitions */

#define exec_run 1                  /* run from beginning */
#define exec_runfrom exec_run+1     /* run from specified unit */
#define exec_rununit exec_runfrom+1 /* execute specified unit */
#define exec_quit exec_rununit+1    /* quit execution */
#define exec_unit exec_quit+1       /* execute unit (no arguments) */
#define exec_unita exec_unit+1      /* execute unit (with argument) */
#define exec_next exec_unita+1      /* execute next unit */
#define exec_back exec_next+1       /* execute previous unit */
#define exec_paste exec_back+1      /* paste (into arrow) */
#define exec_response exec_paste+1  /* finish response (at arrow) */
#define exec_cut exec_response+1    /* cut (from arrow) */
#define exec_copy exec_cut+1        /* copy (from arrow) */
#define exec_replace exec_copy+1    /* replace (arrow text) */
#define exec_toedit exec_replace+1  /* executor->editor transition */
#define exec_switch exec_toedit+1   /* switch file */
#define exec_runsel exec_switch+1   /* run from selected unit */
#define exec_execsel exec_runsel+1  /* execute specified unit */
#define exec_execcur exec_execsel+1 /* execute current unit */
#define exec_print exec_execcur+1   /* print execute window */
#define exec_jumpout exec_print+1	/* -jumpout- to another program */

/* editor internal event codes (presented as time events) */

#define time_checkpt 1  /* checkpoint edit file */
#define time_quit 2 /* quit edit file */
#define time_search 3   /* search edit file */
#define time_srt 4  /* target for search+replace */
#define time_srr 5  /* replacement string for search+replace */
#define time_sra 6  /* action for search+replace */
#define time_saveas 7   /* save file under another name */
#define time_switch 8   /* switch to another source file */
#define time_swa 9  /* query save before switch */
#define time_blink 10   /* blink cursor */
#define time_sru 11 /* search for unit */
#define time_err 12 /* highlight line containing error */
#define time_cmp1 13    /* compile edit file */
#define time_cvtend 14  /* end of conversion */
#define time_cvtend1 15 /* end of conversion - save file query */
#define time_cvtend2 16 /* end of conversion - save file action */
#define time_scr_lup 17     /* scroll up one line */
#define time_scr_ldown 18   /* scroll down one line */
#define time_scr_pup 19     /* scroll up one page */
#define time_scr_pdown 20   /* scroll down one page */
#define time_scr_pos 21     /* scroll to position */
#define time_convert 22     /* source conversion */
#define time_source 23		/* hilight source line */


/* structures for keywords */

struct keywdinf {
    char *name; /* keyword name */
    int value; /* associated value */
}; /* keywdinf */

typedef struct _fofa {
    FileRef familyRef;
    long fID; /* font id # */
    short famSizes[3][NFSIZES]; /* sizes[0] is system size, sizes[1] is crSize Yy, sizes[2] is crSize newline*/
    char switchable; /* if TRUE, this family must be purged on switch file */
    char isoFont;   /* which iso8859 alphabet this family contains (0 if not iso) */
    char knownFont; /* TRUE if we know font sizes */
    char TrueType; /* TRUE if scalable font */
} FontFamily;
/* system dependent # of font sizes */

struct tutorfont { /* font usage table */
    unsigned char family;   /* index in font family table */
    unsigned char textface; /* normal, italic, bold */
    long fID;       /* internal id number */
    short size; /* size (for system) */
    char basicType; /* one of the types defined below */
                /* or -1 if family stub */
    char alphaIcon; /* used only for icons.  -1: not set yet, 0: graphic, 1: alphabetic */
    char sysFlag; /* if TRUE, this is a "system" font */
    char codeSize; /* 0 = 8-bit character codes, 1 = 16-bit */
#ifdef X11
    long ptr;   /* pointer to font definition */
    FileRef fontfile; /* actual file name of font */
#endif
#ifdef DOSPC
    long ptr;   /* pointer to font definition */
    FileRef fontfile; /* actual file name of font */
#endif
#ifdef WINPC
    long fptr;	 /* pointer to font definition */
    FileRef fontfile; /* actual file name of font */
    int datType; /* 0 = windows native font, 1 = fpc format font */
    short nheight; /* character height */
    short nwidth; /* character width */
    short nweight; /* character weight 400=normal, 700=bold */
    BYTE citalic; /* TRUE if italic */
    BYTE cpitchandfamily; /* fixed, proportional, modern, roman, etc */
    char cfacename[34]; /* font face name */
#endif
#ifdef MAC
    char datType;   /* 0: native Mac, 1:cT default, 2: some file */
    char iconType;  /* 0: ICON, 1: FONT, 2: PICT, 3: CTIC 4: 16-bit icons */
    char isoAlphabet;   /* which iso8859 alphabet this font is */
    char dddunused; 
    short ptr;  /* resource # of font */
#endif
    char nusers; /* user count for this font */
    char badFont; /* TRUE if didn't actually find font */
}; /* tutorfont */

/* types for tutorfont type field */
#define FONTF 0
#define PATTERNF 1
#define ICONSF 2
#define CURSORF 3
#define ICONS16F 4

struct CTcolorentry
    {
    unsigned short red, green, blue; /* R,G,B color of this entry */
    unsigned short cHue, cSaturation, cValue; /* H,S,V color of this entry, fixed pt, << 2 */
    char foreFall, backFall;    /* fallbacks for this entry */
    char reserved;              /* TRUE if this entry can be animated */
    char isSet;                 /* used during -palette- & newpal commands */
    unsigned long realV;		/* underlying palette slot / color representation */
    };
    
struct tutorColor {
	int palette; /* palette slot number, or -1 = RGB color */
	unsigned long value; /* color value */
	double red,green,blue; /* 0.0-100.0 RGB color values */
};

struct tutorevent { /* mouse, keyboard, timing, etc event */
    short window;   /* window of event */
    struct tutorview FAR *view; /* view of event */
    short type; /* event type code */
    int value;  /* generic data */
    int id;     /* unique id for this event */
    char FAR *eDataP;   /* pointer to data associated with event */
    int (*vproc)(); /* pointer to routine associated with event */
    int nkeys;  /* number of keys for key event */
    unsigned char keys[16]; /* buffer for burst of keys */
    int x;      /* x position if relevant */
    int y;      /* y position if relevant */
    char rightdown; /* TRUE if right mouse button down */
    char leftdown;  /* TRUE if left mouse button down */
    char pressed;   /* TRUE if this event was pressed */
    char unused;
    long timestamp; /* time event received or to elapse */
    int a1;     /* menu 1st argument (type) */
    int a2;     /* menu 2nd argument (unit) */
    double a3;  /* menu 3rd argument (argument of unit) */
    long a4;    /* additional argument */
    long a5;    /* additional argument */
    int a6;		/* additional argument */
    int origin; /* for debugging */
}; /* tutorevent */

struct tutorview {  /* view (scroll-bar, text, message) definition */
    short window;   /* window view is contained in */
    struct tutorview FAR *nextView;
    struct tutorview FAR *prevView;
    Memh objectH; /* handle on edit/button/slider object */
    int objectT; /* TXBUTTON, TXSLIDER, etc */
    int refc; /* unique identifier */
    int priority; /* front/back priority of this view (touch areas only) */
    int inhibitF; /* TRUE if view inhibited from processing events */
    char caninput;  /* view can accept key & menu input (& grab focus on click) */
    char canclick;  /* view can accept mouse input */
    char dialogV;   /* TRUE if this is a dialog view */
    char unused1;
    Memh vh;    /* "handle" to view structure */
#ifdef WERKS
    int (*vproc)(unsigned int vh,struct tutorevent FAR *ev); /* routine to handle this view */
#else
    int (*vproc)(); /* routine to handle this view */
#endif
    TRect rr;   /* rectangle enclosing view */
    TRect clipr; /* clip rectangle for view */
    int RealX;  /* current x position */ 
    int RealY;  /* current y position */
    int CurrentMode;    /* write/rewrite etc. mode */
    struct tutorColor fgndColor; /* foreground color */
    struct tutorColor bgndColor; /* background color */
    struct tutorColor winColor; /* background erase color */
    long SpaceShim; /* current space shim value */
    int tabSize; /* current tab size (-1 for default) */
    int lineThick; /* current line thickness */
    int newlineH; /* current newline height */
    int SupSub; /* current superscript/subscript */
}; /* tutorview */

/* window types (for type field in struct tutorwindow) */

#define OTHERW 0
#define EDITW 1
#define EXECW 2
#define HELPW 3
#define DICTW 4
#define TRACEW 5
#define DEBUGW 6
#define DEBUGAUXW 7
#define SEARCHW 8
#define MESGW 9
#define ABOUTW 10

struct tutorwindow {    /* window definition */
    long wp;	/* pointer to wm structure */
#ifdef WERKS
    int (*wproc)(unsigned int vh,struct tutorevent FAR *ep); /* pointer to routine for window */
#else /* THINKC5 */
    int (*wproc) ();	/* pointer to routine for window */
#endif /* THINKC5 */
    short type; /* window type */
    Memh wH;    /* window's data */
    struct tutorview FAR *firstView;
    struct tutorview FAR *lastView;
    int winRedraw; /* TRUE if must redraw this window */
    int wxsize; /* window x size */
    int wysize; /* window y size */
    long ldowntime2; /* time of previous left-down event */
    long ldowntime1; /* time of last left-down event */
    long luptime;   /* time of last left-up event */
    long rdowntime2; /* time of previous right-down event */
    long rdowntime1; /* time of last right-down event */
    long ruptime;   /* time of last right-up event */
    int mousex; /* last mouse x position */
    int mousey; /* last mouse y position */
    int upx;    /* x position of last up event */
    int upy;    /* y position of last up event */
    int moveEvent;  /* id of window's move event */
    char forward;   /* 0 if window is obscured */
                    /* 1 if window is forward (unobscured) window */
                    /* 2 if window is forward and has focus */
    char iconified; /* TRUE if window is iconified */
	char moved;     /* TRUE if window resized or moved */
	char ddduu;
    struct tutorview FAR *KeyFocus; /* view which has key input focus */
    struct tutorview FAR *MouseFocus;   /* view which has mouse input focus */
    struct tutorview FAR *MenuFocus;    /* view which has mouse menu focus */
    Memh paletteH;   /* palette for this window (HNULL if system palette) */
    short paletteSize;  /* # of entries in palette */
    int menuf;  /* TRUE if menu selection in progress */
    Memh menus; /* handle to menu bar */
    int FontIndex;  /* index of current font in font table */
    short cursorFont; /* index of font current cursor is in */
    short cursorChar; /* character currently used as cursor */
    short normalCursorFont; /* font for default cursor of this window */
    short normalCursorChar; /* character for default cursor of this window */
#ifdef WINPC
    int wWidth; /* current width of window */
    int wHeight; /* current height of window */
    int wXpos; /* current x position */
    int wYpos; /* current y position */
    Memh vScroll;   /* handle on window's vertical scroll bar */
    Memh hScroll;   /* handle on window's horizontal scroll bar */
    long vScrollW;  /* (HWND) vertical scroll bar child window */
    long hScrollW;  /* (HWND) horizontal scroll bar child window */
    long winPalH; /* handle on windows palette */
#endif
    unsigned char eventMask[EVENT_N];
}; /* tutorwindow */


#endif /* _tutorh */
