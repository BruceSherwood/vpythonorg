
#define MAXTITLE 81
#define BSIGNAL 77
#define NSAVEKEYS 21

typedef struct _buttonD {
    Memh owner;
    struct tutorview FAR *view; /* view of button */
    Memh ebshdrH; /* handle on ct object header (if any) */
    int ebsref; /* reference count on ct object header */
    int thick; /* thickness of button */
    int bFont; /* font to draw label in */
    char state; /* button state (1 if normal, 0 if gray) */
    char eraseF; /* TRUE if we should erase on destroy */
    int ecolor; /* color to erase with */
    char value; /* button's value (0 or 1 usually) */
	char exValue; /* executor value for button */
    char title[MAXTITLE+2]; /* label on button */
	Memh titleDoc; /* styled label on button */
    short tx, ty; /* pen position (relative to button) for drawing title */
    Memh destH; /* data for "button pressed" signal */
    int (*DestProc)(); /* proc for "button pressed" signal */
    int destMsg; /* message for "button pressed" signal */
    int destMsg1;
    double destMsg2;
    int kind; /* button kind 0: normal, 1: check, 2: radio */
    int button_is_up; /* for eliminating flickering on mouse drags */
} ButtonDat;

typedef struct _DItem
    {
    TRect rr;
    struct tutorview FAR *view; /* view of this item, if it has one */
    int thick;
    char FAR *text;
    unsigned char key;  /* key, when typed which triggers this item (usually button) */
    int kind;
	int value;
    int (*ActionProc) ();   /* Take some action other than returning a value */
    Memh itemH;
    } DItem;

typedef struct _dialinf
    {
    TRect *bounds;
    int dialogKind;
    int partialResult, result;
    int nItems;
    int defaultB;
    DItem *items;
    struct tutorview FAR *view; /* pointer to main dialog view */
    struct tutorview FAR *keyView; /* restore key focus to here (when dialog is finished) */
    long savedRegion; /* reference to saved region of screen */
    short curItem;  /* currently active item */
    
    /* used especially for file dialog: */
	int willCreate; /* TRUE if should create file if doesn't exist */
    long lastKeyTime;   /* used in file dialog for key "closeness" */
    unsigned char savedKeys[NSAVEKEYS+1];  /* used in file dialog */
    } DialogDat;

/* dialog kinds */
#define FILEDIALOG 1
#define OTHERDIALOG 2

/* button kinds */
#define NORMALBUTTON 0
#define RADIOBUTTON 2
#define CHECKBOXBUTTON 1
#define THREEDBUTTON 3



