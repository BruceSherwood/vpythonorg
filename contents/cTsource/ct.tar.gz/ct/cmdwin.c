
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdlib.h>
#include <malloc.h>
#include <stdio.h>
#include <string.h>
#include <sys\types.h>
#include <sys\stat.h>

#include "ctutor.h"
#include "exprdefs.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "ct_ctype.h"
#include "ctstring.h"
#include "exprdefs.h"
#include "yacc.h"
#include "cmdtab.h"

/* ******************************************************************* */

extern char *loadFile(char *fileName,int *fileLength);
extern int dataRES(char *fileName,char *resName,char *dataP,int dataL);
extern int TUTORzero(char FAR *ptr,long len);

/* ******************************************************************* */

main()

{   int tableL; /* size of table */
    char *tableP; /* pointer to table */
	char *msgP; /* pointer to message string */
    int nStr; /* number of strings */
    int cii;

    /* figure out total length of error message strings */

    nStr = sizeof(comperr)/sizeof(char *);
    tableL = 0;
    for(cii=0; cii<nStr; cii++) {
		tableL += strlen(comperr[cii])+1;
    }

	/* assemble message strings */

	tableP = malloc((size_t)tableL);
	if (!tableP) {
		printf("Not enough memory\n");
		exit(1);
	}
	TUTORzero(tableP,tableL);

	msgP = tableP; /* pointer in message strings */
	for(cii=0; cii<nStr; cii++) {
		strcpy(msgP,comperr[cii]);
		msgP += strlen(comperr[cii])+1;
	}

    /* write out resource for error messages */

    dataRES("errmsg.h","messages",tableP,tableL);
	free(tableP);

    /* write out resource files containing command + function data */

    dataRES("cmdres.h","cmdres",(char *)cmdtable,sizeof(cmdtable));
    dataRES("funres.h","funres",(char *)zfcttab,sizeof(zfcttab));

    /* write out resource file for system palette */

    tableP = loadFile("system.pal",&tableL);
    dataRES("syspal.h","syspal",tableP,tableL);
    free(tableP);

    /* write out resource file for cursors, icons and patterns */

    tableP = loadFile("zcursors.fpc",&tableL);
    dataRES("zcursors.h","zcursors",tableP,tableL);
    free(tableP);
    tableP = loadFile("zicons.fpc",&tableL);
    dataRES("zicons.h","zicons",tableP,tableL);
    free(tableP);
    tableP = loadFile("zpattern.fpc",&tableL);
    dataRES("zpattern.h","zpatterns",tableP,tableL);
    free(tableP);

	exit(0);

    return(0);
 	
} /* main */

/* ******************************************************************* */

char *loadFile(fileName,fileLength) /* load file into memory */
char *fileName;
int *fileLength; /* returned with length of file */

{   struct _stat statBuf; /* file description */
    FILE *table;
    int tablel; /* file size */
    char *tableP; /* pointer to file contents */
    int osErr;

    *fileLength = 0;
    osErr = _stat(fileName,&statBuf);
    if (osErr) {
	printf("can't open %s\n",fileName);
	exit(1);
    }
    if (statBuf.st_size & 0xffff0000L) {
	printf("file too big %s\n",fileName);
	exit(1);
    }

    *fileLength = (int)statBuf.st_size;
    tablel = (int)statBuf.st_size;

    table = fopen(fileName,"rb");
    if (!table) {
	printf("can't open %s\n",fileName);
	exit(1);
    }

    tableP = malloc((size_t)tablel);
    if (!tableP) {
	printf("not enough memory\n");
	exit(1);
    }

    fread(tableP,1,tablel,table);
    fclose(table);

    return(tableP);

} /* loadFile */

/* ******************************************************************* */

dataRES(fileName,resName,dataP,dataL) /* write arbitrary data as resource file */
char *fileName; /* name of file to create */
char *resName; /* resource name */
char *dataP; /* pointer to data to write */
int dataL; /* length of data to write */

{   FILE *table;
    int dii;
    int dByte1,dByte2;
    int iWord;
    char item[12];
    char line[70];

    table = fopen(fileName,"wb");
    if (!table) {
	printf("can't create file %s\n",fileName);
	exit(1);
    }
    fprintf(table,"\n");
    fprintf(table,"%s RCDATA\n",resName);
    fprintf(table,"BEGIN\n");
    fprintf(table,"%dL,\n",(long)dataL);

    line[0] = 0;
    for(dii=0; dii<dataL >> 1; dii++) {
	dByte1 = *(dataP++) & 0xff;
	dByte2 = *(dataP++) & 0xff;
	iWord = (dByte2 << 8) | dByte1;
	sprintf(item,"0x%x, ",iWord);
	strcat(line,item);
	if (strlen(line) >= 60) {
	    strcat(line,"\n");
	    fprintf(table,line);
	    line[0] = 0;
	}
    }
    if (dataL & 1) { /* handle odd length */
	iWord = *dataP & 0xff;
	sprintf(item,"0x%x, ",iWord);
	strcat(line,item);
    }
    if (strlen(line)) {
	strcat(line,"\n");
	fprintf(table,line);
    }

    fprintf(table,"END\n");
    fprintf(table,"\n");
    fclose(table);

    return(0);

} /* dataRES */

/* ******************************************************************* */

TUTORzero(ptr,len) /* zero block of memory */
register char FAR *ptr; /* address of block */
register long len; /* length of block */

{   char SHUGE *ptrH; /* huge pointer so arithmetic correct */

    if (len <= 0)
        return(0); /* nothing to do */
    ptrH = ptr;
    while(len-- > 0)
	*ptrH++ = 0;
    return(0);
		
} /* TUTORzero */

/* ******************************************************************* */
