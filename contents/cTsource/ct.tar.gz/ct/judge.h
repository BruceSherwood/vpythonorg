/* *********************************************************************** */
/*           DATATYPES AND FUNCTION PROTOTYPES AND CONSTANTS               */
/* *********************************************************************** */
/* Module  : judge.h                                                       */
/* Author  : Peter Kornelisse                                              */
/* Place   : Delft University of Technology                                */
/*                                                                         */
/* Last update : March 23th 1989                                           */
/* *********************************************************************** */
/* (c) Copyright Carnegie Mellon University, 1989. May be used and copied  */
/* freely for educational purposes, but may not be sold without the        */
/* written consent of Carnegie Mellon University.                          */
/* *********************************************************************** */

#include "execdefs.h"
#include "ecglobal.h"
#include "eglobals.h"
#include "tglobals.h"


#define TEST1
#define TESTING
#define PROTO    /* No prototypes allowed */
#define DEBUG
#define UNIX

#define PRINT


#define TRANSPOSITION 0
#define ORDER_CHECK 1
#define SPELL_CHECK 2

#define ORDER_SUBST 30
#define ORDER_INDEL  1
#define ORDER_RED_T  0

#define SPELL_SUBST  2
#define SPELL_INDEL  5
#define SPELL_RED_T  3

#define MAX_SOUNDEXED   2       /*  number of letters that is coded
                                    except the first letter of the
                                    word                                */
#define MAX_SOUNDEX_LENGTH 943  /* 0-941 for words and 942 for garbage  */


#define SIMILAR_TRESHOLD 0.30

#define MAX_LENGTH 16  /* ATTENTION: only words with a length of 16 or less letters are allowed */

#define NOP 0
#define SUB 1
#define INS 2
#define DEL 3

typedef struct {
    int value,
        links;
} cell;

typedef cell cost_array[MAX_LENGTH][MAX_LENGTH];

#define MAXINT          16768
#define MAX_DELTA_LENGTH    3
#define MAX_DISTANCE        0.25

#define MAX_NR_TOKENS       40
#define MEAN_LENGTH_WORD    8

#define equality_level      1     /* deze dient nog globaal aan te worden gemaakt */


/* ***  Definition of the values that of a 'type_of_token'  *** */

#define START            0
#define SPACE            1
#define WORD             2
#define EXPRESSION       3
#define PUNCTUATION      4
#define LEFT_BRACKET     5
#define RIGHT_BRACKET    6
#define LEFT_SQUARE      7
#define RIGHT_SQUARE     8
#define FINISH           9
#define SYMBOL          10
#define GARBAGE         11
#define GROUP_IGNORABLE 12
#define GROUP_SYNONYM   13
#define SKIP1           14
#define GROUP           15

#define NOP_GROUP   18  /* nothing read concerning groups           */
#define OPEN_GROUP  16  /* '{' read, next word must be group        */
#define CLOSE_GROUP 17  /* '}' read, one word must be read already  */
#define GROUP_IN_SYN    19

/* Need of precence for a word in the response */
#define UNDEFINED   0
#define MANDATORY   1
#define IGNORABLE   2

#define SYNONYM     0
#define NO_SYNONYM  1

#define PLAIN_TEXT      0
#define ORIGINAL_TEXT   1

/* #define VOCAB  1
   #define ANSWER 2 */ /* ??????????? */

#define OWNER       1
#define NO_OWNER    2


#define PARSE_TAG   1
#define PARSE_USER  2
#define PARSE_VOCAB 3

/* status of reading groups */

/* defines what kind of words are searched for by search_bucket             */
#define ALL_WORDS   1   /* search all words (with and without instances)    */
#define INST_WORDS  2   /* search all words where there is an instance      */

typedef struct {
    unsigned char FAR   *letters;
    unsigned char FAR   *original_letters;
    int                  length;
} Tword;


typedef struct Twordlist_tmp FAR *Twordlist_ptr;

typedef struct Twordlist_tmp {
    int              type_of_token;
    Tword FAR       *word;
    Twordlist_ptr    next;
} Twordlist;


typedef struct Tinstance_tmp FAR    *Tinstance_ptr;

typedef struct Tinstance_tmp {
    int             index_tag_token;
    int             index_user_token;
    Tinstance_ptr   next_instance;
} Tinstance;

typedef struct Twords_tmp FAR *Twords_ptr;

typedef struct Tlist_of_info_tmp FAR *Tlist_of_info_ptr;

typedef struct {
    int         nr_groups; /* counter used for checking of wordorder */
    Tinstance   FAR *list_of_instances;  /* pointer to list of instances */
    Twords_ptr group;
    Tlist_of_info_ptr group_info;
} Tinfo_instances;




typedef struct Tlist_of_info_tmp {
    Tinfo_instances FAR *info_instances;
    Tlist_of_info_ptr next;
    int owner;
} Tlist_of_info;

typedef struct Twords_tmp {
    unsigned char FAR *original_letters;
    int length;
    Tlist_of_info FAR *list_of_info;  /* pointer to infoblock on instances */
    Twords_ptr next;
} Twords;


typedef struct {
     Twords FAR *bucket;
} Tstate;


typedef struct tmp_Ttag_token  Ttag_token;

typedef struct {
    int         type_of_token;
    Tword       FAR *word;
    int         distance;
    Ttag_token  FAR *twin;
    int         token_index;
    int         order_ok;
    int         printed;
    double      value;
} Tuser_token;

typedef struct {
    double dummy;
} Tinfo_word;

typedef struct {
    double  value;
} Tinfo_expression;

typedef struct {
    int dummy;
} Tinfo_punctuation;

typedef struct tmp_Ttag_token {
    int             type_of_token;
    Tuser_token     FAR *twin;
    int             need_of_presence;   /* ignorable or mandatory word */
    Twords          FAR *word;
    Tinfo_instances FAR *instances;
    union   {
          Tinfo_word        FAR *word;
          Tinfo_expression  FAR *expression;
          Tinfo_punctuation FAR *punctuation;
    } info;
};


typedef struct {
    Tinfo_instances FAR *info_instances;
} Tpunct_machine;


typedef struct tmp_expr_node FAR *expr_node_prt;

typedef struct tmp_expr_node {
    double          value;
    expr_node_prt   left;
    expr_node_prt   right;
    Tinfo_instances FAR *info_instances;
} Texpr_node;


typedef struct {
    Tinstance FAR *instance;
    Twords FAR *words;
} Tword_instance;


extern unsigned char dummy[64];
extern int  idummy;
extern unsigned char FAR *error_msg;
extern int stop_answer;
extern int nr_mandatory;

extern struct sline FAR *match;
extern int output_index;
extern unsigned char FAR *output_cT;

extern int machine_handle; /* wordbox */
extern Tstate FAR *machine;

extern int
    /* input parameters */
    nomark, nookno, noops, nospell, okcaps, okextra, okorder, okspell,
    punc, novars, okassign;

    /* output parameters */


#ifdef PROTOz


/* answer */
int wait_key(void);
void clear_tag(void);
void clear_index_tag(void);
void clear_index_user(void);
void clear_answer(void);
void_clear_tag(void);
void free_tag(void);
void free_user(void);
void free_answer(void);
void init_user(void);
void init_tag(void);
void init_answer(void);
void end_beta(void);


/* instance.c */
void show_instances(Tinstance FAR *list_of_instances);
void free_list_of_instances(Tinstance FAR *list_of_instances);
void free_info_instances(Tinfo_instances FAR *info_instance);
void init_info_blocks(void);
void add_to_list_of_instances(Tinstance FAR * FAR *instances, int tag_index);
void clear_index_list_of_instances(Tinstance FAR *list_of_instances);
void clear_index_info_instances(Tinfo_instances FAR *info_instance);
Tinfo_instances FAR *create_info_instances(Twords FAR *group);
Tlist_of_info FAR *append_to_list_of_info(Tlist_of_info FAR *list_of_info, Tinfo_instances FAR *info_instances, int owner);

/* word_box.c */
Twords FAR *search_bucket(Twords FAR *bucket, unsigned char FAR *keyword, int key_length, int FAR *distance, int kind_of_instance);
Twords FAR *append_bucket(Twords FAR *bucket, unsigned char FAR *letters, int length);
Twords FAR *create_bucket(unsigned char FAR *letters, int length);
void link_words_instances(Twords FAR *words, Tinfo_instances FAR *info_instances, int owner);
void show_machine(void);
void enter_synonym(Tword FAR *keyword, Tinfo_instances FAR *info_instances, int type_of_token);
void create_machine(void);
void free_bucket(Twords FAR *words);
void free_machine(void);
void enter_keyword (Tword FAR *keyword, int index_token, Tinfo_instances FAR * FAR *return_info_instances, Twords FAR **return_words, int kind_of_word, int type_of_token);
Twords FAR *search_word (Tword FAR *key, int FAR *distance);
void clear_index_machine(void);
void free_list_of_info(Tlist_of_info FAR *list_of_info);
void clear_index_bucket(Twords FAR *bucket);
void clear_index_list_of_info(Tlist_of_info FAR *list_of_info);
void clear_bucket(Twords FAR *bucket);
void clear_machine(void);
void clear_list_of_info(Tlist_of_info FAR * FAR *list_of_info);
Tinfo_instances FAR *find_info_group(Twords FAR *words);

/* expr_box.c */
void init_expr_machine(void);
void show_expr_node(Texpr_node FAR *node);
Texpr_node FAR *walk_nodes(Texpr_node FAR *node, double value);
Texpr_node FAR *top_expr_node(void);
Tinfo_instances FAR *enter_expr_machine(int tag_index, double value);
void free_expr_machine(Texpr_node FAR *node);
double abs_diff_double(double value1,double value2);
Texpr_node FAR *search_expr(Texpr_node FAR *node, double value);
void clear_index_expr_machine(Texpr_node FAR *node);

/* punc_box.c */
void show_punct_machine(void);
void init_punct_machine(void);
void free_punct_machine(void);
Tinfo_instances FAR *enter_punct_machine(int tag_index, unsigned char FAR *symbol);
void search_punct(Tword FAR *word, Tinstance FAR * FAR *list_of_instances);
Tinfo_instances FAR *create_punct_info_block(int punct_index, int tag_index);
void clear_index_punct_machine(void);

/* token.c */
void show_user_word(Tword FAR *word);
void show_tag_word(Twords FAR *word);
void output_taglist(void);
void output_userlist(void);
void unlink_word_tokens (Tuser_token FAR *user_token, Tinstance FAR *instance);
void link_word_tokens (Tuser_token FAR *, Ttag_token FAR *, int, Tinstance FAR *);
void update_word_token_links (Tuser_token FAR *, Ttag_token FAR *, int, Tinstance FAR *);
void create_tagtoken(int type_of_token, int need_of_presence, Ttag_token FAR **tag_token);
void check_word_token (Tuser_token FAR *user_token);
void judge_answer(void);
void check_punctuation_token(Tuser_token FAR *user_token);
void check_expression_token(Tuser_token FAR *user_token);
Tinstance FAR *worse_list_of_info(Tlist_of_info FAR *list_of_info);
void link_twins(void);
Tinstance FAR *worse_instance(Tinstance FAR *list_of_instances, int *kind_of_instance);
Tinstance FAR *worse_info_instances(Tinfo_instances FAR *info_instances, int *kind_of_instance);


/* parse.c */
void remove_space(unsigned char FAR *text, int FAR *length);
void read_word(unsigned char FAR *text, int FAR *length);
void read_expression(unsigned char FAR *text, int FAR *length);
void put_tag_expression(int tag_index, int FAR length);
void read_punctuation(unsigned char FAR *text, int FAR *length);
void change_need(int FAR *need, unsigned char FAR *text);
void handle_tag_error(int need_of_word);
int next_tag_state(unsigned char FAR *text, int current_state);
void parse_tag(void);
void put_user_expression(int user_index, int FAR length);
void put_user_punctuation(int user_index, int FAR length);
void put_user_word(int user_index, int length);
void handle_user_error(void);
void parse_user_input(void);
void read_garbage(unsigned char FAR *text, int FAR *length);
int next_user_state(unsigned char FAR *text);
void parse_vocab(void);
void parse_answer(void);

/* response.c */
unsigned char FAR *output_correct_letters (unsigned char FAR *word1, unsigned char FAR *word2, int length);
void concept_response (int index_source, int index_target);
void init_output_text();
void init_output_text(void);
void show_output(void);
int need_of_presence(Ttag_token FAR *tag_token);

/* twin.c */
void init_twin();
void put_tag(char FAR *answer_tag);
void put_user_input(char FAR *student_input);
Ttag_token FAR *get_tag_token(int nr_tag_token);
Tuser_token FAR *get_user_token(int nr_user_token);
int nr_tag_tokens(void);
int nr_user_tokens(void);
void inc_nr_tag_tokens (int nr_incs);
void inc_nr_user_tokens (int nr_incs);
Ttag_token FAR *twin_of_user_token(Tuser_token FAR *user_token);
Tuser_token FAR *twin_of_tag_token(Ttag_token FAR *tag_token);
unsigned char FAR *get_user_input(int type_of_text, int index);
unsigned char FAR * get_tag(int type_of_text, int index);
void free_twins_tag(void);
void free_twins_user_input(void);
void init_twin_user(void);
void init_twin_tag(void);
void clear_index_tag_tokens_twin(void);

/* spell.c */
void fill_cell (int v1, int v2, int v3, cell FAR *c);
int compare_letter(unsigned char letter1, unsigned char letter2);
int indel (unsigned char letter);
int subst (unsigned char letter1,unsigned char letter2);
void output_cost_array(int length_source, int length_target);
int min_int_3 (int i1, int i2, int i3);
void transposition (int index_source, int index_target, int FAR *distance);
int calc_edit_array (Tword FAR *word_1, Tword FAR *word_2, int calc_state);

/* normaliz.c */
void normal(unsigned char  FAR *word);

/* order.c */
void check_wordorder(void);

/* soundex.c */
int soundex(unsigned char FAR *, int);

/* ct_conv.c */
int fuzzyeq(double d1, double d2);
void printfFAR(unsigned char FAR *s);
unsigned char FAR *getsFAR(unsigned char FAR *s);
int strlenf(unsigned char FAR *aa);
void strcpyf(unsigned char FAR *aa, char FAR *bb);

/* vocab.c */

void read_vocab(void);


extern int InitHandles(void);
#ifndef ASMGETP
extern char *GetPtr(Memh mm);
#endif
extern char *FastGetPtr(Memh mm);
extern Handle TUTORget_handle(Memh mm);
extern int LockCount(Memh mm);
extern int CheckLock(Memh mm);
extern int ReleasePtr(Memh mm);
extern Memh TUTORhandle(char *name,long size);
extern int TUTORfree_handle(Memh mm);
extern int TUTORdump_handle(Memh mm);
extern Memh TUTORaffix_handle(Handle theH, char *name);
extern long TUTORget_hsize(Memh mm);
extern TUTORadjust_hsize(Memh mm, long newSize);
extern int TUTORset_hsize(Memh mm,long newSize);
extern int AllowHandlePurge(Memh mm);
extern int TUTORpurge_info(Memh mm,int,int (*restR)(),int);
extern int NoHandlePurge(Memh mm);
extern int TUTORhandle_ispurged(unsigned int mm);
extern pascal long zzMyGrowZone(long sizeW);
extern char *TUTORalloc(long len, int abort);
extern char *TUTORrealloc(char *pp,long oldLen, long newLen, int abort);
extern int TUTORdealloc(char *ptr);

#endif  /* Prototypes allowed */



/* answer */
int wait_key();
void clear_tag();
void clear_index_tag();
void clear_index_user();
void clear_answer();
void_clear_tag();
void free_tag();
void free_user();
void free_answer();
void init_user();
void init_tag();
void init_answer();

/* instance.c */
void show_instances();
void free_list_of_instances();
void free_info_instances();
void init_info_blocks();
void add_to_list_of_instances();
void clear_index_list_of_instances();
void clear_index_info_instances();
Tinfo_instances FAR *create_info_instances();
Tlist_of_info FAR *append_to_list_of_info();
void append_group_info();

/* word_box.c */
Twords FAR *search_bucket();
Twords FAR *append_bucket();
Twords FAR *create_bucket();
void link_words_instances();
void show_machine();
void show_words();
void enter_synonym();
void create_machine();
void free_bucket();
void free_machine();
void enter_keyword ();
Twords FAR *search_word ();
void clear_index_machine();
void free_list_of_info();
void clear_index_bucket();
void clear_index_list_of_info();
void clear_bucket();
void clear_machine();
void clear_list_of_info();

/* expr_box.c */
void init_expr_machine();
void show_expr_node();
Texpr_node FAR *walk_nodes();
Texpr_node FAR *top_expr_node();
Tinfo_instances FAR *enter_expr_machine();
void free_expr_machine();
double abs_diff_double();
Texpr_node FAR *search_expr();
void clear_index_expr_machine();

/* punc_box.c */
void show_punct_machine();
void init_punct_machine();
void free_punct_machine();
Tinfo_instances FAR *enter_punct_machine();
void search_punct();
Tinfo_instances FAR *create_punct_info_block();
void clear_index_punct_machine();

/* token.c */
void show_user_word();
void show_tag_word();
void unlink_word_tokens ();
void link_word_tokens ();
void update_word_token_links ();
void create_tagtoken();
Tinstance FAR *worse_link();
void check_word_token ();
void judge_answer();
void check_punctuation_token();
void check_expression_token();
Tinstance FAR *worse_list_of_info();
void link_twins();

/* parse.c */
void remove_space();
void read_word();
void read_expression();
void put_tag_expression();
void read_punctuation();
void change_need();
void handle_tag_error();
int next_tag_state();
void parse_tag();
void put_user_expression();
void put_user_punctuation();
void put_user_word();
void handle_user_error();
void parse_user_input();
void read_garbage();
int next_user_state();
void parse_vocab();
void parse_answer();

/* response.c */
int min_int_3 ();
unsigned char FAR *output_correct_letters ();
void concept_response ();
void init_output_text();
void show_output();
int need_of_presence();

/* twin.c */
void init_twin();
void put_tag();
void put_user_input();
Ttag_token FAR *get_tag_token();
Tuser_token FAR *get_user_token();
int nr_tag_tokens();
int nr_user_tokens();
void inc_nr_tag_tokens ();
void inc_nr_user_tokens ();
Ttag_token FAR *twin_of_user_token();
Tuser_token FAR *twin_of_tag_token();
unsigned char FAR *get_user_input();
unsigned char FAR * get_tag();
void free_twins_tag();
void free_twins_user_input();
void init_twin_user();
void init_twin_tag();
void clear_index_tag_tokens_twin();
void init_twin_tag();

/* spell.c */
void fill_cell ();
int compare_letter();
int indel ();
int subst ();
void output_cost_array();
int min_int_3 ();
void transposition ();
int calc_edit_array ();

/* normaliz.c */
void normal();

/* order.c */
void check_wordorder();


/* soundex.c */
int soundex();

/* ct_conv.c */
void gotoscr();
int fuzzyeq();

/* vocab.c */

void read_vocab();

