
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#ifndef _baseenvh
#define _baseenvh

#ifdef hp9000s800
/* hopefully temporary kludge so can use standard */
/* makefiles with HP700 */
#undef WM
#define GENERICSYS
#define SYSV
#define hp700
#endif

#ifdef LINUX
#define GENERICSYS
#ifndef SYSV
#define SYSV
#endif
#undef WM
#endif

#ifdef SOLARIS
#undef WM
#define GENERICSYS
#ifndef SYSV
#define SYSV
#endif
#endif

/* set machine token */

#ifdef BE1
#define ANDREW
#endif
#ifdef BE2
#define ANDREW
#endif
#ifdef WM
#define ANDREW
#endif
#ifdef X11
#ifndef SYSV
#ifndef LINUX
#define ANDREW
#endif
#endif
#endif

/* set for Windows if not something else */

#ifndef ANDREW
#ifndef X11
#ifndef IBMPC
/* #define IBMPC */
#endif
#endif
#endif

#define CTDEBUG

#ifdef hp700
#define long_align
#endif

#ifdef mips
#define long_align
#endif

#ifdef sparc
#define long_align
#endif

#ifdef THINK_C
#define MAC
#include "mac-project.h"
#endif

#ifdef BE1
#include "be1.h"
#endif

#ifdef BE2
#include "be2.h"
#endif

#ifdef WM
#include "andrew.h"
#endif

#ifdef X11
#include "x11.h"
#endif

#ifdef MAC
#include "mac.h"
#endif

#ifdef IBMPC
#include "winpc.h"
#endif

#include "basic.h"

#endif  /* baseenvh */
