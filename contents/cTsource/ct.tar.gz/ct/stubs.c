
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>
#include "baseenv.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "editmenu.h"
#include "editor.h"
#include "compute.h"

#ifdef ctproto
int  TUTORforward_window(int  wix);
extern int TUTORzero(char SHUGE *ptr,long length);
int  TUTORpost_event(struct  tutorevent *event);
extern int SetCurEditWi(void);
struct  tutorview FAR *TUTORinq_view(void);
int  procscrollstub(unsigned int  scrH,struct  tutorevent *event);
int  procdictstub(unsigned int  wh,struct  tutorevent *event);
int  prochelpstub(unsigned int  wh,struct  tutorevent *event);
int  proceditstub(unsigned int  editH,struct  tutorevent *event);
extern int  exec_to_edit(unsigned int  editH,struct  tutorevent *event);
int  procdialogwstub(unsigned int  dh,struct  tutorevent *event);
int  procexecwstub(unsigned int  wh,struct  tutorevent *event);
int  procexecstub(unsigned int  viewH,struct  tutorevent *event);
int  procmsgstub(unsigned int  viewH,struct  tutorevent *event);
int  prochelpvstub(unsigned int  hv,struct  tutorevent *event);
int  procdialogstub(unsigned int  hv,struct  tutorevent *event);
int  procbuttonstub(unsigned int  hv,struct  tutorevent *event);
int  proctouchstub(unsigned int  hv,struct  tutorevent *event);
double  SliderScrollstub(struct  tutorview FAR *tview,int  hv,double  nn,int  type);
double  PanelScrollstub(struct  tutorview FAR *tview,int  hv,double  nn,int  type);
int  PanelEventStub(unsigned int  panelH,struct  tutorevent *event);
int  TimedPauseStub(void);
int  RestoreBinaryStub(unsigned int  unitH,char  FAR *up,long  uLen,int  unitn);
int  RestoreRelocStub(unsigned int  unitH,char  FAR *up,long  uLen,int  unitn);
int  matherror(int  errnum,char  *s);
int  OpenFileDialogstub(unsigned int  dialog,int  itemN);
int  ESTextSelectstub(long  dialog,unsigned int  edH,struct  tutorevent *event);
int  ESTextSelect(unsigned int  dialog,unsigned int  edH,struct  tutorevent *event);
int  OpenFileDialog(unsigned int  dialog,int  itemN);
int  execerr(char  *msgstr);
int  cerror(int  errnumber,char  *execstr);
extern void longjmp(jmp_buf env, int value);
int  RestoreReloc(unsigned int  unitH,char  FAR *up,long  uLen,int  unitn);
int  RestoreUnit(unsigned int  unitH,char  FAR *up,long  uLen,int  unitn);
int  TimedPauseOvl(void);
int  PanelEvent(unsigned int  edH,struct  tutorevent *event);
double  PanelScroll(struct  tutorview FAR *tview,int  hv,double  fn,int  type);
double  SliderScroll(struct  tutorview FAR *tview,int  hv,double  fn,int  type);
int  procbutton(unsigned int  bH,struct  tutorevent *event);
int  proctouch(unsigned int  bH,struct  tutorevent *event);
int  procmsg(unsigned int  bH,struct  tutorevent *event);
int  procdialog(unsigned int  dialog,struct  tutorevent *cev);
int  prochelpv(unsigned int  viewH,struct  tutorevent *event);
int  procexec(unsigned int  viewH,struct  tutorevent *event);
int  procexecw(unsigned int  execH,struct  tutorevent *event);
int  TUTORpost_event(struct  tutorevent *event);
int  procdialogw(unsigned int  dialog,struct  tutorevent *event);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  TUTORmessage(struct  tutorview FAR *vp,int  eKind,int  eVal);
int  TUTORset_view(struct  tutorview FAR *vp);
char  FAR *GetPtr(unsigned int  mm);
int  FullHalt(void);
int  procedit(unsigned int  editH,struct  tutorevent *cev);
int  prochelp(unsigned int  helpH,struct  tutorevent *event);
int  procdict(unsigned int  dictH,struct  tutorevent *event);
int  procscroll(unsigned int  theSbar,struct  tutorevent *event);
#endif /* ctproto */

#ifdef AUTHOR
#define stubexec
#endif

#ifdef EXECUTE
#define stubexec
#endif

extern double PanelScroll();
extern double PanelScrollstub();
extern double SliderScroll();
extern double SliderScrollstub();
extern struct  tutorview FAR *TUTORinq_view();

/* ******************************************************************* */

/* stub routines for overlayed event processors called indirectly via */
/* view structure */

/* ------------------------------------------------------------------- */

int procscrollstub(scrH,event)  /* event processor for scroll bar */
Memh scrH;
struct tutorevent *event; /* event to process */

{
    return(procscroll(scrH,event));

} /* procscrollstub */

/* ------------------------------------------------------------------- */

int procdictstub(wh,event)  /* event processor for dictionary */
Memh wh;
struct tutorevent *event; /* event to process */

{
    return(procdict(wh,event));

} /* procdictstub */

/* ------------------------------------------------------------------- */

int procmsgstub(wh,event)  /* event processor for message window */
Memh wh;
struct tutorevent *event; /* event to process */

{
    return(procmsg(wh,event));

} /* procmsgstub */

/* ------------------------------------------------------------------- */

int prochelpstub(wh,event)  /* event processor for help */
Memh wh;
struct tutorevent *event; /* event to process */

{
    return(prochelp(wh,event));

} /* prochelpstub */

/* ------------------------------------------------------------------- */

int proceditstub(editH,event)   /* view event processor for editor */
Memh editH;
struct tutorevent *event; /* event to process */

{   EditDat FAR *ep;    /* pointer to editable text info */
    TextVDat FAR *vp;
    int typ;

    exec_to_edit(editH,event); /* handle exec->edit transition */
    return(procedit(editH,event));

} /* proceditstub */

/* ------------------------------------------------------------------- */

static int exec_to_edit(editH,event) /* executor->editor transition */
Memh editH;
struct tutorevent *event; /* event to process */

{   EditDat FAR *ep;    /* pointer to editable text info */
    TextVDat FAR *vp;
    struct tutorview FAR *cv; /* pointer to current view */
    int typ;

#ifndef CTEDIT
#ifndef EXECUTE
    typ = event->type;
    if ((typ != EVENT_REDRAW) && (typ != EVENT_TIME) && (typ != EVENT_FWD)) {
        cv = TUTORinq_view(); /* get current view */
        
        /* stop execution */

        if ((runflag != halt) || (cv == ExecVp)) {
            if (runflag != halt) {
                TUTORset_view(ExecVp); /* set to executor view */
                FullHalt(); /* stop execution */
            }
            ep = (EditDat FAR *) GetPtr(editH);
            vp = (TextVDat FAR *) GetPtr(ep->textPanel);

            if (CurEditWi < 0)
            	SetCurEditWi();
           	/* TUTORset_view(vp->view);  */ /* back to editor view */
           	TUTORset_view(EditVp[CurEditWi]);
			TUTORforward_window(EditWn[CurEditWi]);
            TUTORmessage(vp->view,EVENT_FWD,TRUE);  /* activate edit view */
            ReleasePtr(ep->textPanel);
            KillPtr(vp);
            ReleasePtr(editH);
            KillPtr(ep);
        } /* halt if */
    } /* event type if */
#endif /* ~EXECUTE */
#endif /* ~CTEDIT */

	return(0);
	
} /* exec_to_edit */

/* ------------------------------------------------------------------- */

int procdialogwstub(dh, event)
Memh dh;
struct tutorevent *event;
    {
    return(procdialogw(dh,event));
    }

/* ------------------------------------------------------------------- */

int procexecwstub(wh,event) /* window event processor for executor */
Memh wh;
struct tutorevent *event; /* event to process */

{   int newc;

    /* intercept executor "run" menu and re-route to editor */

#ifdef stubexec 
    if (event->type == EVENT_MENU) {
        newc = 0;
        if (event->a1 == exec_run)
            newc = edit_run;
        else if (event->a1 == exec_rununit)
            newc = edit_rununit;
        else if (event->a1 == exec_runfrom)
            newc = edit_runfrom;
        if (newc) {
        	if (CurEditWi < 0) CurEditWi = 0;
            event->type = EVENT_MSG;
            event->window = EditWn[CurEditWi];
            event->view = FARNULL;
            event->a1 = newc;
            event->timestamp = 0;
            event->eDataP = FARNULL;
            TUTORpost_event(event);
            return(0);
        }
    } /* type if */

    return(procexecw(wh,event));
#endif

} /* procexecwstub */

/* ------------------------------------------------------------------- */

procexecstub(viewH,event)   /* view event processor for executor */
Memh viewH; /* handle to view data */
struct tutorevent *event; /* event to process */

{
#ifdef stubexec
    return(procexec(viewH,event));
#endif

} /* procexecstub */

/* ------------------------------------------------------------------- */

int prochelpvstub(hv,event)
Memh hv;
struct tutorevent *event;

{
    return(prochelpv(hv,event));
}

/* ------------------------------------------------------------------- */

int procdialogstub(hv,event)
Memh hv;
struct tutorevent *event;
{
    return(procdialog(hv,event));
}

/* ------------------------------------------------------------------- */

int proctouchstub(hv,event)
Memh hv;
struct tutorevent *event;
{
    return(proctouch(hv,event));
}

/* ------------------------------------------------------------------- */

int procbuttonstub(hv,event)
Memh hv;
struct tutorevent *event;
{
    return(procbutton(hv,event));
}


/* ******************************************************************* */

double SliderScrollstub(tview,hv,nn,type)
struct  tutorview FAR *tview;
int  hv;
double  nn;
int  type;
    
{
    return(SliderScroll(tview,hv,nn,type));
}

/* ******************************************************************* */

double PanelScrollstub(tview,hv,nn,type)
struct  tutorview FAR *tview;
int  hv;
double  nn;
int  type;
    
{
    return(PanelScroll(tview,hv,nn,type));
}

/* ******************************************************************* */

PanelEventStub(panelH, event)
Memh panelH;
struct tutorevent *event;
    
{
    return(PanelEvent(panelH,event));
}

/* ******************************************************************* */

/* stubs for overlayed routines called indirectly via TriggerEvent */

TimedPauseStub()    /* process return from timed pause */

{
#ifdef stubexec
    TimedPauseOvl();
#endif
	return(0);
	
} /* TimedPauseStub */

/* ------------------------------------------------------------------- */

RestoreBinaryStub(unitH,up,uLen,unitn) /* restore unit's binary from disk */
Memh unitH; /* handle to unit being restored (not used) */
char FAR *up; /* pointer to place to restore unit binary */
long uLen; /* length of unit */
int unitn;
    
{
    RestoreUnit(unitH,up,uLen,unitn);
    return(0);
}

/* ------------------------------------------------------------------- */

RestoreRelocStub(unitH,up,uLen,unitn) /* restore unit's reloc table disk */
Memh unitH; /* handle to unit being restored (not used) */
char FAR *up; /* pointer to place to restore unit binary */
long uLen; /* length of unit */
int unitn;
    
{
    RestoreReloc(unitH,up,uLen,unitn);
    return(0);
}

/* ******************************************************************* */

matherror(errnum, s) 
int errnum; 
char *s;    /* error message string */

{
    if (userExp) {
        /* if (userExp<0) return(0); */ /* exit if in compile phase */
        longjmp(uenv,errnum);   /* return to usereval */
    }
    if ((waitflag != runflag) || (runflag == halt)) 
        cerror(SPECIFICERR,s);
    
    /* update execution pointer */
    /* uloc = (unsigned short)(bin - (unsigned char FAR *)cbody); -- not used? */
    execerr( s);
    return(0); 

} /* matherror */

/* ******************************************************************* */

#ifndef MAC
OpenFileDialogstub(dialog, itemN)
Memh dialog;
int itemN;
{
    return(OpenFileDialog(dialog, itemN));
}

ESTextSelectstub(dialog, edH, event)
long dialog;
Memh edH;
register struct tutorevent *event;
{
    return(ESTextSelect((Memh) dialog, edH, event));
}
#endif
