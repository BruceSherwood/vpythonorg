
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* ******************************************************************* */

#include <stdio.h>
#include "baseenv.h"
#include "compute.h"
#include "ecglobal.h"
#include "tfiledef.h"
#include "tglobals.h"

#ifdef SYSV
#include <dirent.h>
#endif

#ifdef ANDREW
#ifndef SYSV
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/errno.h>
#include <sys/file.h> 
#include <sys/dir.h>
#endif
#endif

#ifdef hp700
#include <sys/unistd.h>
#endif

#ifdef ctproto
extern int AppendSlash(char *str);
int TUTORinq_fref(int find, FileRef FAR *fref);
int TUTORinq_is_dir(FileRef FAR *path);
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
int  TUTORcmp_fileref(struct  _fref FAR *f1,struct  _fref FAR *f2);
int  TUTORcopy_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  TUTORcopy_fileref_dir(struct  _fref FAR *dirname,struct  _fref FAR *fullname);
int  TUTORsymbolic_fileref(struct  _fref FAR *fRef,char  FAR *syms);
int  TUTORget_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  file_slot(void);
int  TUTORclose(int  findx);
int  TUTORrename_file(struct  _fref FAR *fOld,struct  _fref FAR *fNew);
int  TUTORdelete_file(struct  _fref FAR *fRef);
int  TUTORfile_exists(struct  _fref FAR *fRef);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
long  TUTORinq_file_pos(int  findx);
int  TUTORinq_file_err(int  findx);
int  TUTORstat(struct  _fref FAR *fRef,struct  stat *buff);
int  TUTORseek(int  findx,long  pos);
int  TUTORset_file_type(struct  _fref FAR *fRef,int  findx,int  type,int  xx,int  yy);
long  TUTORwrite(char  FAR *ptr,int  pSize,long  count,int  findx);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
int  TUTORwrite_int(int  ii,int  findx);
int  TUTORread_int(int  *ii,int  findx);
int  TUTORwrite_short(short  ss,int  findx);
int  TUTORread_short(short  *ss,int  findx);
int  TUTORwrite_char(int cc,int  findx);
int  TUTORread_char(unsigned char  *cc,int  findx);
int  TUTORget_char(int  findx,int  tryHard);
int  TUTORread_string(unsigned char  *str,int  length,int  findx);
long  TUTORread_number(int  findx);
int  TUTORungetc(int  findx,int  cc);
extern long  flrdwr(char  FAR *ptr,int  pSize,long  count,int  findx,int  rwFlag);
int  TUTORreset_file(int  findx,int  option);
int  TUTORopen_serial(int  port,int  baud,int  datab,int  parity,double  stopb);
int  TUTORtemp_file_name(struct  _fref FAR *baseN,struct  _fref FAR *tempN);
int  TUTORopen_ems(long  FAR *size);
extern void  pc_close_ems(int  handle);
extern long  pc_rdwr_ems(long  length,char  FAR *memp,int  read);
extern void  pc_map_ems(int  handle,int  page);
int  TUTORopen_xms(long  FAR *size);
extern long  pc_rdwr_xms(long  length,char  FAR *memp,int  read);
extern void  pc_close_xms(int  handle);
extern FAR char *TUTORread_dir(FileRef FAR *fref);
int  ClearAuthorFile(long  vloc);
char  FAR *GetPtr(unsigned int  mm);
int  ReleasePtr(unsigned int  mm);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
extern int TUTORclose_socket(struct tutorfile *tfp);
int  TUTORdump(char  *s);
extern int TUTORgetchar_socket(struct tutorfile FAR *fp);
extern long TUTORread_socket(struct tutorfile FAR *tp,char FAR *cp,long nn);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
extern int TUTORungetc_socket(struct tutorfile FAR *tfp,int cc);
extern long TUTORwrite_socket(struct tutorfile FAR *tp,char FAR *cp,long nn);
extern int access(char *path,int mode);
extern int alphasort();
extern char *mktemp(char *path);
/* rindex() */
/* scandir(); */
/* select() */
extern char *strcat(char *aa, char *bb);
int  strcmpf(char  FAR *aa,char  FAR *bb);
extern char *strcpy(char *aa, char *bb);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
char  *strf2n(char  FAR *strp);
int  strlenf(char  FAR *aa);
int  strncmpf(char  FAR *aa,char  FAR *bb,int  nn);
char  FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
#ifdef IBMPROTO
int _CDECL fclose(FILE *);
int _CDECL fflush(FILE *);
int _CDECL fgetc(FILE *);
FILE * _CDECL fopen(const char *, const char *);
size_t _CDECL fread(void *, size_t, size_t, FILE *);
int _CDECL fscanf(FILE *, const char *, ...);
int _CDECL fseek(FILE *, long, int);
long _CDECL ftell(FILE *);
size_t _CDECL fwrite(const void *, size_t, size_t, FILE *);
int _CDECL rename(const char *, const char *);
int _CDECL ungetc(int, FILE *);
int _CDECL unlink(const char *);
#endif /* IBMPROTO */
#endif /* ctproto */

static long flrdwr();
long TUTORwrite_socket();
long TUTORread_socket();
extern char *strf2n();
extern char *mktemp();
extern char *rindex_z();
extern char *getenv();
extern char *getwd();

#ifdef ANDREW
#define RMODE "r"
#define RMODEB "r"
#define WMODE "w"
#define WMODEB "w"
#define WRMODE "w+"
#define RWMODE "r+"
#define AMODE "a"
#define AMODEB "a"
#endif


#ifdef LINUX
#define RMODE "r"
#define RMODEB "r"
#define WMODE "w"
#define WMODEB "w"
#define WRMODE "w+"
#define RWMODE "r+"
#define AMODE "a"
#define AMODEB "a"
#endif

#ifdef SYSV
#define RMODE "r"
#define RMODEB "r"
#define WMODE "w"
#define WMODEB "w"
#define WRMODE "w+"
#define RWMODE "r+"
#define AMODE "a"
#define AMODEB "a"
#endif

#ifdef IBMPC
#define RMODE "rb"
#define RMODEB "rb"
#define WMODE "wb"
#define WMODEB "wb"
#define WRMODE "wb+"
#define RWMODE "rb+"
#define AMODE "ab"
#define AMODEB "ab"
#endif

/* ******************************************************************* */
TUTORcopy_fileref(fDest,fSource)
FileRef FAR *fDest, FAR *fSource;
	{
#ifdef long_align
if (((long)(fDest->path) & 1) || ((long)(fSource->path) & 1))
	TUTORdump("unaligned TUTORcopy_fileref");
#endif
	strcpyf(fDest->path,fSource->path);
	fDest->nameInd = fSource->nameInd;
	}

/* ******************************************************************* */
TUTORcmp_fileref(f1,f2)
FileRef FAR *f1, FAR *f2;
/* returns 0 if filerefs match */
	{
	if (f1->nameInd == f2->nameInd)
		return(strcmpf(f1->path,f2->path));
	else
		return(1);
	}

/* ******************************************************************* */
TUTORcopy_fileref_name(fRef,name)
FileRef FAR *fRef; /* use directory reference from here */
char FAR *name; /* use this as file name */
	{
	strcpyf(fRef->path + fRef->nameInd,name);
	}

/* ******************************************************************* */

TUTORcopy_fileref_dir(dirname, fullname) /* copy directory path */
FileRef FAR *dirname;	/* path to have only directory set */
FileRef FAR *fullname;	/* full path */ 
	{
	strncpyf(dirname->path,fullname->path,fullname->nameInd);
	dirname->path[fullname->nameInd] = '\0'; /* no name */
	dirname->nameInd = fullname->nameInd;
	}		 /* TUTORcopy_fileref_dir */

/* ******************************************************************* */
TUTORsymbolic_fileref(fRef,syms)
FileRef FAR *fRef;	/* to be set up for symbolic fRef */
char FAR *syms;		/* symbolic string */
	{
	/* a symbolic name can be detected on unix by noticing that path[0] != '/' */

	strcpyf(fRef->path,syms);
	fRef->nameInd = 0;
	}

/* ******************************************************************* */
TUTORget_fileref_name(fRef,name) /* return the name of an fRef */
FileRef FAR *fRef;
char FAR *name;
	{
	int len, ii;

	ii = len = strlenf(fRef->path);
	while (ii > 0 && fRef->path[ii-1] != '/')
		ii--; /* back up to slash */
	strcpyf(name,fRef->path+ii);
	}

/* ******************************************************************* */
int  TUTORget_fileref_dir(fRef,name) /* get the directory of an fRef */
FileRef FAR *fRef;
char FAR *name;
{
	char FAR *cp;
	
	strcpyf(name,fRef->path);
	cp = rindex_z(name, '/');
	if (cp) {
		*cp = '\0';
	}
	else {
		name[0] = '\0';
	}
}
	
/* ******************************************************************* */
TUTORinq_fref(findx,fref)
int findx;	/* file index */
FileRef FAR *fref;	/* to be filled with fileref of file whose index is find */
	{
	struct tutorfile FAR *tfp;
	
    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to file table entry */

	TUTORblock_move((char FAR *) &(tfp->fRef),(char FAR *) fref,
					(long) sizeof(FileRef));
	ReleasePtr(filesopen);
	KillPtr(tfp);
	
	return(TRUE);
	}

/* ******************************************************************* */

int TUTORopen(fRef,rf,wf,af) /* open file */
FileRef FAR *fRef;
int rf; /* TRUE if read access */
int wf; /* TRUE if write access */
int af; /* TRUE if append */

{   struct tutorfile FAR *tfp; /* pointer to file table entry */
    int ii;
    char *fstr; /* pointer to r/w/a string */
    int wrtf; /* write allowed flag */
	char FAR *tempS, *tempNS;

    /* set up file table entry */

    tfilerr = -1; /* no error yet */
    ii = file_slot(); /* locate free file table slot */
    tfp = ii+(struct tutorfile FAR *) GetPtr(filesopen);
    tfp->inuse = TRUE; /* mark file table entry in use */
    tfp->lastop = fop_open; /* no operations yet */
    tfp->ro = ((!wf) && (!af)); /* set read-only flag */
    tfp->kind = 0; /* normal file */
    TUTORcopy_fileref(&tfp->fRef,fRef);

    /* open file */


#ifndef IBMPC
    if (af && rf) fstr = "a+"; /* build file access type */
    else if (af) fstr = "a";
    else if (wf && (!rf)) fstr = "w";
    else if (wf) fstr = "r+";
    else fstr = "r";
#endif

#ifdef IBMPC
    if (af && rf) fstr = "ab+"; /* build file access type */
    else if (af) fstr = "ab";
    else if (wf && (!rf)) fstr = "wb";
    else if (wf) fstr = "rb+";
    else fstr = "rb";
#endif

	tempS = fRef->path;
	tempNS = strf2n(tempS);
    tfp->fp = fopen(tempNS,fstr);
    if (tfp->fp == NULL) {
        tfp->inuse = FALSE;
        tfilerr = FILEPERMIT; /* permission not granted */
        ReleasePtr(filesopen);
        return(0);
    } /* fp if */
    ReleasePtr(filesopen);

    return(ii); /* return index in file table */

} /* TUTORopen */

/* ------------------------------------------------------------------- */

int file_slot() /* locate free file table slot */

{   struct tutorfile FAR *tfp;
    int ii;

    /* search for unused slot */

    tfp = ((struct tutorfile FAR *)GetPtr(filesopen))+1;
    for (ii = 1; ii < filesmalloc; ii++, tfp++) /* skip slot 0 */
        if (!tfp->inuse)
            break;

    /* allocate new slot */

    if (ii >= filesmalloc) {
        ReleasePtr(filesopen);
        filesmalloc++;
        TUTORset_hsize(filesopen,(long)(filesmalloc*sizeof(struct tutorfile)),TRUE);
	tfp = (struct tutorfile FAR *) GetPtr(filesopen);
	ii = filesmalloc-1; /* index of empty slot */
	tfp += ii; /* point to empty slot */
	tfp->inuse = FALSE;
    } /* ii if */
    tfp->vloc = -1;
    tfp->styles_allowed = FALSE;
    tfp->fp = 0L;
    tfp->stream = -1;
	tfp->crKind = -1;
    tfp->buffer = FARNULL;
    ReleasePtr(filesopen);
    return(ii); /* always slot 1 or above */

} /* file_slot */

/* ******************************************************************* */

TUTORclose(findx) /* close file */
int findx; /* index in file table (returned by TUTORopen) */

{   struct tutorfile FAR *tfp;	
    FILE *stream;
    char FAR *cp;

	if (findx <= 0)
		return;
		
    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    stream = tfp->fp;

    if (tfp->vloc >= 0)
	ClearAuthorFile(tfp->vloc); /* author file, clear variable */

    if (tfp->kind == 0) {
        if (stream) { /* normal file */
            fclose(stream); 
	}
    } else if (tfp->kind == 1) {
        if (stream)
            fclose(stream); /* serial port */
    } else if (tfp->kind == 2) 
	{ /* socket */
	TUTORclose_socket(tfp);
	}
    tfp->inuse = FALSE;
    tfp->fRef.path[0] = '\0';
    tfp->vloc = -1;
    tfp->fp = NULL;
    ReleasePtr(filesopen);

} /* TUTORclose */

/* ******************************************************************* */

int TUTORrename_file(fOld,fNew) /* rename file, return TRUE if worked */
FileRef FAR *fOld, FAR *fNew;

{   int rret;
    char tempS[CTPATHLEN+1];

    strcpy(tempS,strf2n(fNew->path));
    rret = rename(strf2n(fOld->path),tempS);
    return(rret == 0);

} /* TUTORrename_file */

/* ******************************************************************* */

int TUTORdelete_file(fRef) /* delete file, return TRUE if worked */
FileRef FAR *fRef;

{   int dret;

    dret = unlink(strf2n(fRef->path));
    return(dret == 0);

} /* TUTORdelete_file */

/* ******************************************************************* */

TUTORfile_exists(fRef) /* return TRUE if file "s" exists */
FileRef FAR *fRef;

{   long length;

    if (fRef->path[0] == 0) return(FALSE);
#ifndef MAC
#ifndef IBMPC
    if (strncmpf(fRef->path,(char FAR *) "/dev/ttys",9) == 0) 
		return(TRUE); /* serial ports exist */
#endif
#endif
    TUTORinq_file_info(fRef,NEARNULL,&length,NEARNULL,NEARNULL,NEARNULL);
    if (length >= 0) return(TRUE);
    else return(FALSE);

} /* TUTORfile_exists */

/* ******************************************************************* */

TUTORinq_file_info(fRef,waccess,length,modtim,posx,posy)
FileRef FAR *fRef;
int *waccess; /* TRUE if have write access to file */
long *length; /* length of file */
              /* -1 if file does not exist */
long *modtim; /* time of last modification */
int *posx; /* x position of file icon */
int *posy; /* y position of file icon */

{   struct stat fst; /* file status block */  
    int sr; /* stat return */ 

    /* get file status if neccessary */

    if (waccess || length || modtim) {
        sr = stat(strf2n(fRef->path),&fst); /* get file status info */
        if (sr) {
            fst.st_size = -1; /* clear fields if stat failed */
            fst.st_mode = 0;
            fst.st_mtime = 0;
        } /* sr if */
    } /* access if */

    /* return write permission status if requested */

    if (waccess) *waccess = TRUE;
#ifdef ANDREW
#ifndef SYSV
    if (waccess) { 
        *waccess = TRUE; /* assume write permission */
        if (access(fRef->path,W_OK) != 0) 
            *waccess = FALSE;
        else if ((fst.st_mode & S_IFMT) == S_IFDIR) 
            *waccess = FALSE;
    } /* waccess if */
#endif
#endif
#ifdef hp700
    if (waccess) { 
        *waccess = TRUE; /* assume write permission */
        if (access(fRef->path,W_OK))
			waccess = FALSE;
	}
#endif

    /* return file length if requested */

    if (length) *length = fst.st_size;

    /* return time of last modification if requested */

    if (modtim) *modtim = fst.st_mtime;

    /* return file icon position if requested */

    if (posx) *posx = -10000; /* no position for wm */
    if (posy) *posy = -10000;

} /* TUTORinq_file_info */

/* ******************************************************************* */

long TUTORinq_file_pos(findx) /* get current read/write position */
int findx; /* index of file */

{   struct tutorfile FAR *tfp; /* pointer to file table entry */
    long pos; /* file position */

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to file table entry */
    pos = ftell(tfp->fp);
    ReleasePtr(filesopen);
    return(pos);

} /* TUTORinq_file_pos */

/* ******************************************************************* */

int TUTORinq_file_err(findx) /* returns TRUE if error has occurred */
int findx;

{   struct tutorfile FAR *tfp; /* pointer to file table entry */
    int fret; /* error return */

    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    fret = ferror(tfp->fp);
    ReleasePtr(filesopen);
    return(fret ? TRUE: FALSE);

} /* TUTORinq_file_err */

/* ******************************************************************* */

TUTORstat(fRef,buff)
FileRef FAR *fRef;
struct stat *buff;
	{
	return(stat(strf2n(fRef->path), buff));
	}

/* ******************************************************************* */

TUTORseek(findx,pos) /* seek to specified position in file */
int findx; /* index of file in file table */
long pos; /* position */

{   struct tutorfile FAR *tfp; /* pointer to file table entry */

    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    fseek(tfp->fp,pos,0);
    ReleasePtr(filesopen);

} /* TUTORseek */

/* ******************************************************************* */

TUTORset_file_type(fRef,findx,type,xx,yy)  /* set file's operating system type */
FileRef FAR *fRef;
int findx; /* file index */
int type; /* 1: AUTHOR, 2: EXECUTOR */
int xx, yy; /* file icon location (-10000 if not to be used) */
	
{
    ; /* unix doesn't support file types... */

} /* TUTORset_file_type */

/* ******************************************************************* */

long TUTORwrite(ptr,pSize,count,findx)
char FAR *ptr; /* buffer to write out */
int pSize; /* size of item */
long count; /* # of items to write out */
int findx;
/* returns # of bytes written */
	
{
    return(flrdwr(ptr,pSize,count,findx,FALSE));

} /* TUTORwrite */

/* ******************************************************************* */

long TUTORread(ptr,pSize,count,findx)
char FAR *ptr; /* buffer to fill */
int pSize; /* size of item */
long count; /* # of items to write out */
int findx;
/* returns # of bytes read */
	
{
    return(flrdwr(ptr,pSize,count,findx,TRUE));

} /* TUTORread */

/* ******************************************************************* */

TUTORwrite_int(ii,findx)
int ii;
int findx;
	
{   FILE *stream;
    struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *) GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    stream = tfp->fp; /* get FILE pointer */
    tfp->lastop = fop_write;
    fwrite(&ii,sizeof(int),1,stream);
    if (tfp->kind == 1) fflush(stream); /* flush serial port */
    ReleasePtr(filesopen);

} /* TUTORwrite_int */

/* ******************************************************************* */

TUTORread_int(ii,findx)
int *ii;
int findx;
	
{   FILE *stream;
    struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *) GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    stream = tfp->fp; /* get FILE pointer */
    tfp->lastop = fop_read;
    fread(ii,sizeof(int),1,stream);	
    ReleasePtr(filesopen);

} /* TUTORread_int */

/* ******************************************************************* */

TUTORwrite_short(ss,findx)
short ss;
int findx;
	
{   FILE *stream;
    struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    stream = tfp->fp; /* get FILE pointer */
    tfp->lastop = fop_write;
    fwrite(&ss,sizeof(short),1,stream);
    if (tfp->kind == 1) fflush(stream); /* flush serial port */
    ReleasePtr(filesopen);

} /* TUTORwrite_short */

/* ******************************************************************* */

TUTORread_short(ss,findx)
short *ss;
int findx;
	
{   FILE *stream;
    struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    stream = tfp->fp; /* get FILE pointer */
    tfp->lastop = fop_read;
    fread(ss,sizeof(short),1,stream);	
    ReleasePtr(filesopen);

} /* TUTORread_short */

/* ******************************************************************* */

TUTORwrite_char(cc,findx)
unsigned char cc;
int findx;
	
{   FILE *stream;
    struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    if (tfp->kind == 2)
	{ /* socket */
	TUTORwrite_socket(tfp,(char FAR *) &cc,1L);
	}
    else
	{ /* file or serial port */
	stream = tfp->fp; /* get FILE pointer */
	fwrite(&cc,sizeof(unsigned char),1,stream);
	if (tfp->kind == 1) fflush(stream); /* flush serial port */
	}
    tfp->lastop = fop_write;
    ReleasePtr(filesopen);

} /* TUTORwrite_char */

/* ******************************************************************* */

TUTORread_char(cc,findx)
unsigned char *cc;
int findx;
	
{   FILE *stream;
    struct tutorfile FAR *tfp;

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    stream = tfp->fp; /* get FILE pointer */
    tfp->lastop = fop_read;
    fread(cc,sizeof(unsigned char),1,stream);	
    ReleasePtr(filesopen);

} /* TUTORread_char */

/* ******************************************************************* */

int TUTORget_char(findx, tryHard) /* read+return character or EOF */
int findx;
int tryHard; /* if TRUE, try hard (retry io port) to get character */
{   struct tutorfile FAR *tfp;
    int cc;

    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    tfp->lastop = fop_read;
    if (tfp->kind == 2)
	cc = TUTORgetchar_socket(tfp); /* socket */
   else
   	cc = fgetc(tfp->fp); /* file or serial port */
#ifndef SYSV
#ifndef IBMPC
#ifndef LINUX
    if (tryHard && cc == EOF && tfp->kind != 0)
	{ /* keep trying port for 5 seconds */
   	 int portNum, mask, tm, nFound;
  	struct timeval aTime;

	portNum = (tfp->kind == 2) ? tfp->stream : fileno(tfp->fp);
	mask = 1 << portNum;
	tm = mask;
	aTime.tv_sec = 5;  /* select timeout */
	aTime.tv_usec = 0;
	nFound = select(32,&tm,NULL,NULL,&aTime);
	if (nFound > 0 && (tm & mask))
		{ /* got character, go read it */
   		 if (tfp->kind == 2)
			cc = TUTORgetchar_socket(tfp); /* socket */
  		 else
   			cc = fgetc(tfp->fp); /* file or serial port */
		}
	/* else cc is left as EOF */
	}
#endif /* LINUX */
#endif /* IBMPC */
#endif /* SYSV */
    ReleasePtr(filesopen);
    return(cc);

} /* TUTORget_char */

/* ******************************************************************* */

int TUTORread_string(str,length,findx) /* read newline-terminated string */
unsigned char *str; /* pointer to buffer to read into */
int length; /* maximum length to read */
int findx; /* file index */
	
{   struct tutorfile FAR *tfp; /* pointer to ct file table entry */
    int nc; /* number characters read */
    int cc; /* last character read */

    tfp = (struct tutorfile FAR *)GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    tfp->lastop = fop_read;
    if ((feof(tfp->fp)) || (length <= 0)) {
	ReleasePtr(filesopen);
	return(0); /* nothing read */
    } /* feof if */
    nc = 0;
    cc = 0; /* for top of while test */
    do
	{
	cc = fgetc(tfp->fp);
	if (cc == EOF) cc = NEWLINE;
	str[nc++] = cc;
    } while (cc != NEWLINE && nc < length);
    ReleasePtr(filesopen);
    return(nc);

} /* TUTORread_string */

/* ******************************************************************* */

long TUTORread_number(findx)
int findx;
	
{   FILE *stream;
    struct tutorfile FAR *tfp;
    long lret;

    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    stream = tfp->fp; /* get FILE pointer */
    tfp->lastop = fop_read;
    fscanf(stream,"%ld",&lret);
    ReleasePtr(filesopen);
    return(lret);

} /* TUTORread_number */

/* ******************************************************************* */

TUTORungetc(findx,cc)
int findx;
int cc;
	{
	struct tutorfile FAR *tfp;
	int ret;

	tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);
	if (tfp->kind == 2)
		ret = TUTORungetc_socket(tfp,cc);
	else
		ret = ungetc(cc,tfp->fp);
	ReleasePtr(filesopen);

	return(ret);
	}

/* ******************************************************************* */

#ifndef IBMPC

#define CHUNKSZE 16384

static long flrdwr(ptr,pSize,count,findx,rwFlag) /* long read or write */
char FAR *ptr;	/* where the read is going */
int pSize;	/* size of object */
long count;	/* # of objects */
int findx;	/* index in file table */
int rwFlag;	/* TRUE: read, FALSE: write */
/* returns # of characters read */

{   int nReads,ii, nNew, toRead;
    long nIn;
    FILE *stream;
    struct tutorfile FAR *tfp;
    int isSerial;

    nIn = 0;
    tfp = (struct tutorfile FAR *) GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    tfp->lastop = (rwFlag ? fop_read: fop_write);
    if (tfp->kind == 2)
	{ /* socket */
	if (rwFlag)
		nIn = TUTORread_socket(tfp,ptr,pSize*count);
	else
		nIn = TUTORwrite_socket(tfp,ptr,pSize*count);
	ReleasePtr(filesopen);
	return(nIn);
	}
    isSerial = (tfp->kind == 1);
    stream = tfp->fp; /* get FILE pointer */
    count *= pSize; /* now just working in bytes */
    ReleasePtr(filesopen);
    if (!count)
	return(nIn);
	
    if ((ptr == NULL) || (stream == NULL))
        TUTORdump("flrdwr bad pointer");
    nReads = (count-1)/CHUNKSZE;
    for (ii=0; ii<=nReads; ii++) {
        toRead = (ii == nReads) ? (count - nReads*CHUNKSZE) : CHUNKSZE;
        if (rwFlag) nNew = fread(ptr,1,toRead,stream);
        else nNew = fwrite(ptr,1,toRead,stream);
        if (nNew == 0) {
            if (feof(stream)) 
                return(nIn); /* read to end of file */
            return(0L); /* error */
        }
        nIn += nNew;
        ptr += toRead;
    }
    if (!rwFlag && isSerial)
	fflush(stream);

    return(nIn);

} /* flrdwr */

/* ******************************************************************* */

#else

#define CHUNKSZE 1024

static long flrdwr(ptr,pSize,count,findx,rwFlag) /* long read or write */
char FAR *ptr;	/* where the read is going */
int pSize;	/* size of object */
long count;	/* # of objects */
int findx;	/* index in file table */
int rwFlag;	/* TRUE: read, FALSE: write */
	
{   int nReads,ii, nNew, toRead;
    long nIn;
    char FAR *fbuf; /* long pointer to local buffer */
    char buf[CHUNKSZE]; /* local buffer for read/write */
    FILE *stream;
    struct tutorfile FAR *tfp;
    int isSerial;

    nIn = 0;
    tfp = (struct tutorfile FAR *) GetPtr(filesopen);
    tfp += findx; /* index to table entry */
    stream = tfp->fp; /* get FILE pointer */
    tfp->lastop = (rwFlag ? fop_read: fop_write);
    isSerial = (tfp->kind == 1);
    count *= pSize; /* now just working in bytes */
    ReleasePtr(filesopen);
    if (!count)
	return(nIn);

    ReleasePtr(filesopen);
		
    if ((ptr == NULL) || (stream == NULL))
        TUTORdump("flrdwr bad pointer");
    nReads = (count-1)/CHUNKSZE;
    for (ii=0; ii<=nReads; ii++) {
        toRead = (ii == nReads) ? (count - nReads*CHUNKSZE) : CHUNKSZE;
        if (rwFlag) {
            nNew = fread(buf,1,toRead,stream);
            fbuf = buf; /* far pointer to local buffer */
            TUTORblock_move(fbuf,ptr,(long)toRead);
        } else {
            fbuf = buf; /* far pointer to local buffer */
            TUTORblock_move(ptr,fbuf,(long)toRead);
            nNew = fwrite(buf,1,toRead,stream);
        } /* else */
        if (nNew == 0) {
            if (feof(stream))
                return(nIn); /* read to end of file */
            return(0L); /* error */
        }
        nIn += nNew;
        ptr += toRead;
        if (nNew < toRead) 
            break;
    } /* for */
    if (!rwFlag && isSerial)
	fflush(stream);
    return(nIn);

} /* flrdwr */

#endif

/* ******************************************************************* */

TUTORreset_file(findx,option) /* reset to begin, end, or empty */
int findx; /* index in file table */
int option; /* option = 0 for start, 1 for end, 2 for empty */

{   struct tutorfile FAR *tfp;

    tfilerr = -1; /* no error yet */
    tfp = findx+(struct tutorfile FAR *) GetPtr(filesopen);

    switch (option) {

    case 0: /* start of file */
        if (tfp->kind == 0) { /* this only makes sense for normal file */
            fseek(tfp->fp, 0L, 0);
            tfp->lastop = fop_begin;
        }
        break;

    case 1: /* end of file */
        if (!tfp->ro) 
            fflush(tfp->fp); /* flush if write-able */
        if (tfp->kind == 0)
            fseek(tfp->fp,0L,2); /* seek to end if real file */
        tfp->lastop = fop_end;
        break;

    case 2: /* empty the file */
        if (tfp->ro) { /* read only */
            tfilerr = FILEPERMIT;
            ReleasePtr(filesopen);
            return;
        } /* filesopen if */
        if (tfp->kind == 1) { /* not meaningful for serial port */
            ReleasePtr(filesopen);
            return; 
        } /* serial port if */
        fclose(tfp->fp);
		tfp->fp = fopen(strf2n(tfp->fRef.path),WRMODE); /* truncate the file */
        if (tfp->fp == NULL) {
            TUTORclose(findx); /* close file if re-open failed */
            tfilerr = FILEPERMIT;
            ReleasePtr(filesopen);
            return;
        } /* open failed if */
        tfp->lastop = fop_empty;
 	break;

    } /* switch */

    ReleasePtr(filesopen);
    return;

} /* TUTORreset_file */

/* ******************************************************************* */

/* serial port support: */

#ifdef ANDREW
#ifdef ibm032
TUTORopen_serial(port,baud,dataB,parity,stopB) /* open RT serial port */
int port; /* port number */
int baud,dataB,parity; /* baud rate, data bits, parity flag */
double stopB; /* stop bits */
/* return file index, or 0 for failure */
{   int i;
    int nameLen;
    char filename[30];
    struct tutorfile FAR *theF;

    tfilerr = -1; /* no error yet */
    i = file_slot(); /* locate free file table slot */
    theF = i + (struct tutorfile FAR *) GetPtr(filesopen);

    /* construct the filename & open the file */
    strcpy(filename,"/dev/ttys");
    if (port == 2)
        port = 0; /* since port 2 is /dev/ttys0 */
    sprintf(filename+9,"%d",port);
    theF->fp = fopen(filename, RWMODE);
    if (theF->fp == NULL) { /* permission not granted */
        ReleasePtr(filesopen);
        tfilerr = FILEPERMIT;
        return(0);
    }

    /* set up file data */
    nameLen = strlen(filename);
    TUTORblock_move((char FAR *) filename,theF->fRef.path, (long) (nameLen+1));
    theF->kind = 1; /* serial port */
    theF->ro = FALSE;	/* read/write */
    theF->lastop = fop_open; /* end of file */
    theF->inuse = TRUE;

    extsetup(fileno(theF->fp),baud,dataB,parity,stopB); /* setup (handshaking, etc.) */
    /* rt serial port needs "reset end" for some reason */
    fseek(theF->fp, 0L, 2);

    ReleasePtr(filesopen);

    return(i);

} /* TUTORopen_serial */

#else
TUTORopen_serial(port,baud,datab,parity,stopb) /* open serial port */
int port; /* port number */
int baud,datab,parity;
double stopb;

{
	tfilerr = FILEMISSING; /* no such serial port exists */
	return(0);

} /* TUTORopen_serial */

#endif  /* ibm032 else */
#endif  /* ANDREW */

/* ******************************************************************* */
/* this should work for both UNIX and the PC */
TUTORtemp_file_name(baseN,tempN)	/* create a temporary file name */
FileRef FAR *baseN; /* base name, used for directory path */
FileRef FAR *tempN; /* to be filled with a currently unused file name */
/* returns TRUE for success */
{
	char FAR *result;
	/* we are creating a file name which will not overwrite any other file */

	TUTORcopy_fileref(tempN,baseN);
	TUTORcopy_fileref_name(tempN, (char FAR *) "cTXXXXXX");
	return (mktemp(tempN->path) ? TRUE : FALSE);
} /* TUTORtemp_file_name */


extern int alphasort();

static int no_dots();

static int no_dots(s)
char *s;
{
	if (s[0] == '.'
	    && (s[1] == '\0'
		|| (s[1] == '.' && s[2] == '\0')))
			return 0;
	return 1;
}

/* ******************************************************************* */

#ifdef SYSV

char FAR *TUTORread_dir(fref)
FileRef FAR *fref;

{	DIR *theDir; /* directory stream */
	struct dirent *theFile; /* next file in directory */
	char FAR *buf; /* buffer for file names */
	char FAR *buffP; /* pointer in buffer */
  	long sLen; /* size of buffer */
	long readLen; /* length of actual data */
	int nameLen; /* length of individual name */

	theDir = opendir(fref->path);
	sLen = 8*1024; /* crude - grab a big, but fixed-size buffer */
	if (theDir)
		buf = TUTORalloc(sLen, TRUE, "directory");
	if ((!theDir) || (!buf))
    	return(".\n..\n");
	TUTORzero(buf,sLen);
	readLen = 0;
	buffP = buf;
	do {
		theFile = readdir(theDir);
		if (!theFile)
			break; /* exit while */
		nameLen = strlen(theFile->d_name);
		if (nameLen) {
			readLen += nameLen+1;
			if (readLen >= sLen)
				break; /* buffer full */
			strcpy(buffP,theFile->d_name);
			buffP += nameLen;
			*buffP++ = NEWLINE;
		} /* nameLen if */
	} while (TRUE);
	*buffP = 0; /* insure terminating zero */
	closedir(theDir);
    return(buf);

} /* TUTORread_dir */

#else

char FAR *TUTORread_dir(fref)
FileRef FAR *fref;

{	char FAR *buf;
    struct direct **files;
	struct direct *file;
    int retVal, sLen, ii;

    retVal = scandir(&fref->path[0], &files, no_dots, alphasort);
    if (retVal == -1) {
		/* Couldn't open directory or malloc(3) failed */
		buf = TUTORalloc(1, TRUE, "directory");
		buf[0] = '\0';
    } else {
		sLen = 0;
		for (ii = 0; ii < retVal; ii++) {
			if (files[ii]->d_namlen != 1 || files[ii]->d_name[0] != '.')
				sLen += files[ii]->d_namlen + sizeof NEWLINES; /* extra chars for a newline */
		}
		if (sLen == 0)
			sLen = 1;
		buf = TUTORalloc(sLen, TRUE, "directory");
		buf[0] = '\0';
		for (ii = 0; ii < retVal; ii++) {
			if (files[ii]->d_namlen != 1 || files[ii]->d_name[0] != '.') {
				strcat(buf, files[ii]->d_name);
				strcat(buf, NEWLINES);
			}
		}
		free((char *)files);
    }
	
    return buf;

} /* TUTORread_dir */

#endif

/* ******************************************************************* */

TUTORdispose_dir(text)
char FAR *text;
{
	free(text);
}

TUTORinq_is_dir(fref)
FileRef FAR *fref;
{
	struct stat stbuf;
	
	if (stat(fref->path, &stbuf) == -1)
		return -1;

	return (stbuf.st_mode & S_IFDIR) ? 1 : 0;
}

/* ******************************************************************* */

int FindBinDir(cmdStr,binDir) /* locate directory containing cT */
char *cmdStr; /* pointer to cT command string */
char *binDir; /* returned with path to cT */

{	int ii;
	char *cP; /* working pointer */
	char curPath[CTPATHLEN+2]; /* current path we're examining */
	char cmd[CTPATHLEN+2]; /* command (binary file) name */
	char *pathP; /* pointer in global path string */
	
	*binDir = 0; /* pre-set for failure */
	
	/* pick up command name */

#ifdef EXECUTE
	if (cmdStr == NULL)
		strcpy(cmd,"cTx");
#else
	if (cmdStr == NULL)
		strcpy(cmd,"cT");
#endif
	else {
		ii = 0; /* index in command name */
		cP = cmdStr; /* point to command line string */
		while ((*cP == ' ') || (*cP == '\t'))
			cP++; /* skip over whitespace */
		while ((*cP) && (*cP != ' ') && (*cP != '\t')) {
			if ((*cP == '/') || (*cP == '~')) {
				cP++;
				ii = 0; /* new (possible) start of command */
			} else {
				cmd[ii++] = *cP++; /* add character to command building */
				if (ii >= CTPATHLEN) break; /* abort */
			}
		} /* while */
		cmd[ii] = 0; /* insure terminated */
	} /* else */
			
	/* check if file in current working directory */			

	pathP = getwd(curPath);
	if (CheckExists(pathP,cmd)) {
		strcpy(binDir,pathP);
		return(TRUE);
	}
		
	/* parse global path string */
	
	pathP = getenv("PATH");
	while (*pathP) {
		cP = pathP; /* start of next possible path */
		ii = 0;
		while ((*cP == ' ') || (*cP == '\t'))
			 cP++; /* skip leading whitespace */
		while (*cP && (*cP != ':')) {
			curPath[ii++] = *cP++;
			if (ii >= CTPATHLEN) 
				break; /* abort */
		} /* while */
		curPath[ii] = 0; /* terminate string */
		if (CheckExists(curPath,cmd)) {
			strcpy(binDir,curPath);
			return(TRUE);
		}
		if (!(*cP)) pathP = cP;
		else pathP = cP+1;
	} /* while */
	return(FALSE); /* didn't find file */
	
} /* FindBinDir */

/* ******************************************************************* */

static int CheckExists(path,cmd) /* check if command exists at path */
char *path;
char *cmd;

{	struct stat statB; /* buffer for file statistics */
	int statR;
	char fullPath[CTPATHLEN+4]; /* path+command */

	if ((strlen(path)+strlen(cmd)) >= CTPATHLEN)
		return(FALSE);
	strcpy(fullPath,path);
	AppendSlash(fullPath); /* append trailing slash */
	strcat(fullPath,cmd);
	statR = stat(fullPath,&statB);
	if (statR || (statB.st_size <= 0)) 
		return(FALSE);
	return(TRUE); /* found it */
	
} /* CheckExists */

/* ******************************************************************* */

int TUTORset_dir(path) /* set current working directory */
char FAR *path; /* directory path */

{	FileRef fRef;
	int ret;
	
    ret = TUTORcvt_path(strf2n(path),&fRef,currentDirP,FALSE);
    chdir(fRef.path);
	*currentDirP = fRef;
	if (ret) return(-1);
	else return(FILEMISSING);
	
} /* TUTORset_dir */
/* ******************************************************************* */

TUTORflush_file(findx) /* flush file buffer */
int findx; /* index in file table (returned by TUTORopen) */

{   struct tutorfile FAR *tfp;    
    FILE *ffp;
	int retF; /* return value */

    if (findx <= 0)
		return(FALSE);

	retF = TRUE; /* pre-set worked */
    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    ffp = tfp->fp;

    switch (tfp->kind) {
    case 0: /* normal file */
        if (ffp) {
			retF = fflush(ffp);
			retF = (retF ? FALSE: TRUE); /* FALSE if error */
			if (retF) 
				if (ferror(ffp)) retF = FALSE;
		}
        break;
    case 1: /* serial port */
        break;
    case 2: /* socket */
        break;
    case 4: /* EMS */
        break;
    case 5: /* XMS */
        break;
    } /* switch */

    ReleasePtr(filesopen); 
    return(retF);

} /* TUTORflush_file */

/* ******************************************************************* */
