/* *********************************************************************** */
/*                      BLACK BOX FOR PUNTUATION                           */
/* *********************************************************************** */
/* Module  : punc_box.c                                                    */
/* Author  : Peter Kornelisse                                              */
/* Place   : Delft University of Technology                                */
/*                                                                         */
/* Last update : March 23th 1989                                           */
/* *********************************************************************** */
/* (c) Copyright Carnegie Mellon University, 1989. May be used and copied  */
/* freely for educational purposes, but may not be sold without the        */
/* written consent of Carnegie Mellon University.                          */
/* *********************************************************************** */

#include <stdio.h>
#include "judge.h"

#ifdef ctproto
void  show_punct_machine(void);
void  init_punct_machine(void);
void  free_punct_machine(void);
/* struct  (untagged) FAR *enter_punct_machine(int  tag_index,unsigned char  FAR *symbol);
void  search_punct(struct  (untagged) FAR *word,struct  Tinstance_tmp FAR * FAR *list_of_instances); */
void  clear_index_punct_machine(void);
/* struct  (untagged) FAR *create_punct_info_block(int  punct_index,int  tag_index); */
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  TUTORdealloc(char  FAR *ptr);
void  add_to_list_of_instances(struct  Tinstance_tmp FAR * FAR *instances,int  tag_index);
/* void  clear_index_info_instances(struct  (untagged) FAR *info_instance); 
struct  (untagged) FAR *create_info_instances(struct  Twords_tmp FAR *group); 
void  free_info_instances(struct  (untagged) FAR *info_instance); */
void  show_instances(struct  Tinstance_tmp FAR *list_of_instances);
int  strlenf(char  FAR *aa);
#ifdef IBMPROTO
int _CDECL printf(const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
extern int printf(char *form,...);
#endif

static unsigned char punct[] = ".,!;:?'`";
static Tpunct_machine FAR *punct_machine;



/* *********************************************************************** */
/* Test function                                                           */
/* *********************************************************************** */
void show_punct_machine()
{
    int nr_punct,
        i;


    nr_punct = strlenf((char FAR *) punct);

    printf("\n PUNCT MACHINE: \n");

    for (i=0; i<nr_punct; i++)
    {
        if (punct_machine[i].info_instances != NULL)
        {
            printf("\nindex=%2d: diff_word=%2d:\n", i,punct_machine[i].info_instances->nr_groups);
            show_instances(punct_machine[i].info_instances->list_of_instances);
        };
    };
}
/* show_punct_machine */



/* *********************************************************************** */
void init_punct_machine()
{
    int length,
        i;


    length = strlenf((char FAR *) punct);
    punct_machine = (Tpunct_machine FAR *)TUTORalloc((long)(sizeof(Tpunct_machine)*length),TRUE,"ans");
    for (i=0; i<length; i++)
    {
        punct_machine[i].info_instances = NULL;
    };
}
/* init_punct_machine */


/* *********************************************************************** */
void free_punct_machine()
{
    int length, i;


    length = strlenf((char FAR *) punct);
    for (i=0; i<length; i++)
    {
        free_info_instances(punct_machine[i].info_instances);
    };
    TUTORdealloc((char FAR *)punct_machine);
}
/* free_punct_machine */



/* *********************************************************************** */
Tinfo_instances FAR *enter_punct_machine(tag_index, symbol)
int tag_index;
unsigned char FAR *symbol;
{
    int punct_index;
    Tinfo_instances FAR *tmp_info;


    punct_index = 0;
    while (punct[punct_index] != symbol[0])
    {
        punct_index++;
    };

    if (punct_machine[punct_index].info_instances == NULL)
    {
        tmp_info = create_punct_info_block(punct_index, tag_index);

    }
    else
    {
        add_to_list_of_instances(&punct_machine[punct_index].info_instances->list_of_instances, tag_index);
        tmp_info = punct_machine[punct_index].info_instances;

    };
    return(tmp_info);
}
/* enter_punct_machine */



/* *********************************************************************** */
void search_punct(word, list_of_instances)
Tword FAR *word;
Tinstance FAR * FAR *list_of_instances;
{
    int punct_index;


    punct_index = 0;
    while (punct[punct_index] != word->original_letters[0])
    {
        punct_index++;
    };

    if (punct_machine[punct_index].info_instances == NULL)
    {
        *list_of_instances = NULL;
    }
    else
    {
        *list_of_instances = punct_machine[punct_index].info_instances->list_of_instances;
    };
}
/* search_punct */


/* *********************************************************************** */
void clear_index_punct_machine()
{
    int length, i;


    length = strlenf((char FAR *) punct);
    for (i=0; i<length; i++)
        clear_index_info_instances(punct_machine[i].info_instances);
}
/* clear_index_punct_machine */



/* *********************************************************************** */
Tinfo_instances FAR *create_punct_info_block(punct_index, tag_index)
int punct_index;
int tag_index;
{
    Tinfo_instances FAR *tmp_info;


    tmp_info= create_info_instances(NULL);
    add_to_list_of_instances(&tmp_info->list_of_instances, tag_index);
    punct_machine[punct_index].info_instances = tmp_info;

    return(tmp_info);
}
/* create_punct_info_block */

