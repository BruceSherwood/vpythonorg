Hello World
From cTEdit on Linux
