
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#ifndef _ctutorh
#define _ctutorh

/* Definitions for compilation portion of ct. */

#ifndef setjmp_d
#include "setjmp.h"
#define setjmp_d
#endif

#ifndef _baseenvh
#include "baseenv.h"
#endif

#ifndef _computeh
#include "compute.h"
#endif

#ifndef _commandsh
#include "commands.h"
#endif


#ifdef DOSPC
#define CMPBUFL 20480	/* size of unit compilation buffer */
#define CMPBUFC 18000	/* value to check against for unit too long */
#else
#define CMPBUFL 32800	/* size of unit compilation buffer */
#define CMPBUFC 31000	/* value to check against for unit too long */
#endif

#define UNITNAME 1 /* illegal unit name */
#define BADCOMMAND 2 /* illegal command name */
#define CALCNOASSIGN 3 /* calc with no assignment */
#define BLANKCOMMAND 4 /* illegal blank command */
#define MISSINGUNIT 5 /* -do- non-existent unit */
#define BADTAG 6 /* bad tag (command ok) */
#define BADINDENT 7 /* bad indent level */
#define NOENDLOOP 8 /* loop unterminated */
#define NOENDIF 9 /* if unterminated */
#define NOENDARROW 10 /* arrow unterminated */
#define BADDEFINE 11 /* -define- must precede 1st unit */
#define BADELSEIF 12 /* cannot follow -else- */
#define BADELSE 13 /* cannot follow -else- */
#define BADTEXT 14 /* cannot find terminator */
#define DUPUNIT 15 /* duplicate unit name */
#define NOTIMPLEMENTED 16 /* command not implemented */
#define BADKNAME 17 /* unrecognized keyname */
#define MISSINGARG 18 /* missing arg in tag */
#define BADNAME 19 /* illegal chars in name */
#define BADMERGEG 20 /* merge,global: should stand alone */
#define NEEDCOMMA 21 /* use comma here. */
#define TOOMANY 22 /* too many arguments */
#define EXTRAIFMATCH 23 /* extra -ifmatch- */
#define NOLOOP 24 /* outloop/reloop/endloop with no loop */
#define EXTRADEFINE 25 /* more than one -define- in ieu */
#define NOTSTORABLE 26 /* canstore should have been TRUE */
#define ONEUSERDEF 27 /* only one define user: */
#define USERGLOBAL 28 /* user vars must be global */
#define DEFFLOAT 29 /* need define f: for now */
#define BADITERLOOP 30 /* iterative loop without := */
#define NEEDSEMI 31 /* use semicolon here */
#define NEEDCOLON 32 /* use colon here */
#define COMPMEM 33 /* out of memory during compile */
#define DUPDEF 34 /* duplicate defined name */
#define WRONGSEP 35 /* wrong separator */
#define ARGVAR 36 /* argument of unit must be variable */
#define MIXINDEF 37 /* cannot mix definite and indefinite dimensions */
#define UXARG 38 /* unit x cannot have arguments */

#define LastChar (cB[cI-1])

struct condctab { /* conditional command */
	int label; /* internal label of position */
	unsigned int pos; /* position of conditional clause */
}; /* condctab */

extern long now(); /* returns time in timer units (TU) */
extern int ViewHit(), ViewInput(), ViewRedraw(), ViewUpdate();
extern int preexec(), Wait(), texec();
extern int Rerun(), ScreenHit(), MyViewHit();
extern int ArrowViewHit();
extern int RunOneUnit(), RunFromUnit(), RunAllUnits(), Halt();
extern int Run(), Help(), Appendix();
extern int FindUnits();

#endif /* _ctutorh */
