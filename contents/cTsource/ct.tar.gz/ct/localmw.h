
#define ID_OK	     1
#define ID_CANCEL    2
#define ID_TMENU     100
#define ID_ABOUT     200
#define ID_STDINP    201
#define ID_STDINPTXT 202
#define ID_SEARCHTXT 203
#define ID_SEARCHNEW 204
#define ID_SEARCHSKP 205
#define ID_SEARCHREP 206
#define ID_SEARCHRPA 207

int FAR PASCAL WinMain(HANDLE, HANDLE, LPSTR, int);
BOOL FAR CtwInit(HANDLE);
long FAR PASCAL CtwWndProc(HWND, unsigned, WORD, LONG);
BOOL FAR PASCAL About(HWND, unsigned, WORD, LONG);
BOOL FAR PASCAL StdInpDlg(HWND,unsigned,WORD,LONG);
BOOL FAR PASCAL QRepInpDlg(HWND,unsigned,WORD,LONG);
