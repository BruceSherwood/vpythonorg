
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/


/* ******************************************************************* */

/* include file for expression compiler/code generator */

#ifndef _compileh
#define _compileh

#ifndef _computeh
#include "compute.h"
#endif

#ifndef _commandsh
#include "commands.h"
#endif

#define tonstk -1	/* operand on stack */
#define tundef -2	/* operand not assigned to register */

#define abstolerance 0.000000001


#define IHUGE 0x7fffffff

/* ------------------------------------------------------------------------------ */

extern double lcitof();
extern long lcftoi();		/* round double to integer conversion */
extern long lcint();
extern double lcffunct();
/* ------------------------------------------------------------------------------ */

#endif /* _compileh */


