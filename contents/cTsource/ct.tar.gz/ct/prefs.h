/*
A component of the cT (TM) programming environment.
(c) Copyright 1994 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#ifndef _prefsh
#define _prefsh

#include "basic.h"

struct PrefRec {
    long swapSize; /* max size of swap fie */
    long checkTime; /* checkpoint frequency */ 
    short recLen; /* sizeof(struct PrefRec) */
    short fontSize; /* editor font size */
    short fontFace; /* editor font face */
    short nTabs; /* editor spaces/tab */
    short fcolor; /* editor foreground color */
    short bcolor; /* editor background color */
    short snapShot; /* execute window snapshot flag */
    short dos_hcolor; /* (DOS) highlight color */
    short dos_sbint; /* (DOS) SoundBlaster interrupt */
    short dos_sbport; /* (DOS) SoundBlaster I/O port */
    short winSaveOnExit; /* TRUE if should save window settings on exit */
	TRect editWp;  /* editor window position */
	TRect execWp;  /* executor window position */
	TRect debugWp; /* debugger window position */
	TRect stackWp; /* debugger stack window postion */
	TRect msgWp;   /* message window position */
    short dddv[9];
    short debugMarkWin; /* TRUE if should show marker in a window */
    short wordWrap; /* TRUE if should word-wrap in editor window */
    char prefID[16]; /* identifying string */
    char fontFamily[64]; /* default editor font family */
    char swapPath[256]; /* path to swap file */
    char dos_printer[16]; /* (DOS) printer name */
    char unix_printer[64]; /* (UNIX) print command */
}; 

#endif /* prefsh */
