
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
 */


#include <stdio.h>
#include <signal.h>
#include "baseenv.h"
#include "compute.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "memory.h"

#ifdef ctproto
int  InitHandles(void);
char  FAR *GetPtr(unsigned int  mm);
int  ReleasePtr(unsigned int  mm);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORdump_handle(unsigned int  mm);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
struct  htab FAR *TUTORget_entry_mem(int  handle);
int  DeleteFromHandle(unsigned int  mm,long  di,long  dl);
int  InsertIntoHandle(unsigned int  mm,char  FAR *is,long  ip,long  il);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
char  FAR *TUTORrealloc(char  FAR *ptr,long  oldsize,long  newsize,int  abort);
int  memchain(int  calli);
int  TUTORdealloc(char  FAR *ptr);
long  TUTORinq_mem_available(void);
extern int  nomem(char  *msg);
int  pc_init_mem(void);
int  pc_drop_mem(void);
char  FAR *pc_get_mem(long  size,int  strategy,char  *label);
extern char  FAR *pc_alloc(long  size,int  strategy,char  *label);
int  pc_reduce_alloc(char  FAR *ptr,long  oldsize,long  newsize);
int  pc_mem_purge(long  target);
int  pc_mem_compress(void);
extern struct  htab FAR *pc_htab(int  handle);
int  pc_identify_handle(char  FAR *ptr,int  handle);
int  pc_mem_map(void);
void  TUTORdelete_swap(long  pos);
int  TUTORdump(char  *s);
int  TUTORtrace(char  *s);
extern int bzero(char *ptr,int lth);
char  FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
#endif /* ctproto */

extern long     lastmsec;
extern int      InitHandles();
extern char FAR *GetPtr();
extern int      ReleasePtr();
extern unsigned int TUTORhandle();
extern int      TUTORfree_handle();
extern int      TUTORdump_handle();
extern long     TUTORget_hsize();
extern int      TUTORset_hsize();
extern int      TUTORpurge_info();
extern int      AllowHandlePurge();
extern int      TUTORhandle_ispurged();
extern struct htab FAR *TUTORget_entry_mem();
extern int      DeleteFromHandle();
extern int      InsertIntoHandle();
extern char FAR *TUTORalloc();
extern char FAR *TUTORrealloc();
extern int      TUTORdealloc();
extern long     TUTORinq_mem_available();
extern int      nomem();
extern struct htab FAR *wm_htab();
extern char FAR *TUTORalloc();
extern int      TUTORdealloc();
extern int      TUTORdump();
extern char FAR *TUTORrealloc();
extern int      TUTORtrace();
extern int      TUTORtrace_n();
extern char FAR *strncpyf();
extern long     memtst();
extern void     TUTORinit_swap();
extern void     TUTORclose_swap();
extern long     TUTORwrite_swap();
extern int      TUTORexpand_swap();
extern void     TUTORread_swap();
extern void     TUTORscan_swap();

extern char FAR *malloc();
extern char FAR *realloc();

/* ******************************************************************* */

#define MEMLABEL 1

#define NMEMSTART 100
#define NMEMADD 50
#define MEMMASK 0x4000

/* ******************************************************************* */

static long     hmalloc = 0;	/* number handles allocated */
static struct htab FAR *htabp;	/* pointer to table of handles */
static short    mLowest;	/* index to start looking for empty slot */
static long     origmem;	/* original memory available */
static short baseOffset;	/* adjustment to basememp made to make it longword align */

extern char FAR *TUTORalloc();
extern char FAR *TUTORrealloc();
extern struct htab FAR *TUTORget_entry_mem();

wm_init_mem() { return; }

/* ******************************************************************* */

InitHandles() /* initialize handle memory management */

{	int ii; /* index in table */
	struct htab FAR *hp;

	if (hmalloc)
		return;		/* already initialized */
	hmalloc = NMEMSTART;	/* initialize memory management table */
	htabp = (struct htab FAR *)
		TUTORalloc((long) (sizeof(struct htab) * hmalloc), TRUE, "htab");
	for (ii = 0, hp = htabp; ii < hmalloc; ii++, hp++) {
#ifdef MEMVERIFY
		hp->label[0] = 0;
#endif
		hp->area = (char FAR *) -1;	/* handle not in use */
		hp->size = 0;
		hp->lockcount = hp->lastref = 0;
		hp->purge = 0;
	} /* for */

	/*
	 * want 0th entry to never be used so that a Memh of zero indicates
	 * no handle
	 */
	htabp[0].area = (char *) 7L;	/* will cause address error if used */
	mLowest = 1;		/* begin to look for empty spots at entry 1 */

} /* InitHandles */

/* ******************************************************************* */

char FAR *GetPtr(mm)
Memh mm;

{	struct htab FAR *pp;

	pp = TUTORget_entry_mem(mm);
#ifdef MEMVERIFY
if ((long)(pp->area) & 0x3) {
TUTORtrace_x("unaligned pointer ",(long)pp->area);
    TUTORdump("unaligned pointer in GetPtr");
}
#endif

	pp->lockcount++;
	return (pp->area);

} /* GetPtr */

/* ------------------------------------------------------------------- */

ReleasePtr(mm)
Memh mm;

{	struct htab FAR *pp;

	pp = TUTORget_entry_mem(mm);
	if (pp->lockcount == 0)
		TUTORtrace("Handle unlocked too many times");
	pp->lockcount--;
	pp->lastref = lastmsec;	/* save time of last reference */

} /* ReleasePtr */

/* ------------------------------------------------------------------- */

Memh TUTORhandle(name, size,purgewmrm) /* allocate new area of specified size */
char *name;	/* descriptive label */
long size;	/* size of area in bytes */
int purgewmrm;	/* if TRUE, set up purgeable wmrm */

{	int ii;	/* index in table */
	int handle;	/* actual handle value */
	struct htab FAR *hp;	/* pointer to next table entry */
	long tableSize;	/* new table size */
	long oldsize;
	long nhmalloc;	/* new num table entries */
	long allocsize; /* size to allocate */

	/* find an unused handle with enough memory */
	/* start looking at mLowest */

	for (ii = mLowest, hp = htabp + mLowest; ii < hmalloc; ii++, hp++)
		if (hp->area == (char FAR *) -1L)
			break;

	if (ii >= hmalloc) {
		/* allocate more handles since table full */
		oldsize = hmalloc * sizeof(struct htab);
		nhmalloc = hmalloc + NMEMADD;	/* allocate more handles */
		tableSize = nhmalloc * sizeof(struct htab);
		htabp = (struct htab FAR *)
			TUTORrealloc((char FAR *) htabp, oldsize, tableSize, TRUE);
		if (!htabp)
			nomem("out of handles");

		/* initialize new entries */
		for (ii = 0, hp = htabp + hmalloc; ii < NMEMADD; ii++, hp++) {
#ifdef MEMVERIFY
			hp->label[0] = 0;
#endif
			hp->area = (char FAR *) -1L;
			hp->size = 0;
			hp->lockcount = 0;
			hp->purge = M_NOPURGE;
			hp->lastref = 0;
			hp->position = -1;
			hp->rarg = 0;
		} /* for */
		ii = hmalloc;	/* index of open entry */
		hp = htabp + ii;
		hmalloc = nhmalloc;
	} /* ii if */
	mLowest = ii + 1; /* next time, start looking just past here */

	/* attempt to allocate memory */

	allocsize = ((size == 0) ? 8: size);
	hp->area = malloc(allocsize);
	if (!hp->area)
		nomem("out of memory");

	/* set up new handle */

#ifdef MEMVERIFY
	if (name)
		strncpyf(hp->label, (char FAR *) name, 8);
	else
		hp->label[0] = 0;
#endif
	hp->size = size;
	hp->lockcount = 0;
	hp->purge = M_NOPURGE;
	hp->position = -1;
	hp->rarg = 0;
	handle = ii | MEMMASK;
	return (handle);	/* Memh is index ored with mask */

} /* TUTORhandle */

/* ------------------------------------------------------------------- */

TUTORfree_handle(mm) /* recycle specified memory area */
Memh mm; /* handle on area */

{	register struct htab FAR *hp;
	unsigned int maskTest;

	maskTest = mm & MEMMASK;
	if (!maskTest)
		TUTORdump("Handle without mem-mask");

	mm ^= MEMMASK;	/* remove MEMMASK bit */
	if (!mm)
		TUTORdump("NULL handle in TUTORfree_handle");

	if (mm >= hmalloc)
		TUTORdump("mm too large in TUTORfree_handle");

	hp = htabp + mm;

#ifdef MEMVERIFY
	if ((long)(hp->area) == -1L)
		TUTORdump("free_handle called on free handle");
#endif
		
	if (hp->lockcount > 0)
		TUTORdump("Attempt to free locked handle");

	if (hp->area)
		TUTORdealloc(hp->area);
	
	/* If mem is in the swap file */
	if ((hp->purge & (M_WORM | M_WMRM)) && hp->position >= 0)
		TUTORdelete_swap(hp->position);
	
	if (mm <= mLowest)
		mLowest = mm;	/* start search here */
	hp->area = (char FAR *) -1L;

} /* TUTORfree_handle */

/* ------------------------------------------------------------------- */

TUTORdump_handle(mm) /* recycle specified memory area - always */
                     /*  (even if handle locked, etc.) */
Memh mm; /* handle on area */

{	register struct htab FAR *hp;
	unsigned int    maskTest;

	maskTest = mm & MEMMASK;
	if (!maskTest)
		TUTORdump("Handle without mem-mask");

	mm ^= MEMMASK;	/* remove MEMMASK bit */
	if (!mm)
		TUTORdump("NULL handle in TUTORdump_handle");

	if (mm >= hmalloc)
		TUTORdump("mm too large in TUTORdump_handle");

	hp = htabp + mm;

#ifdef MEMVERIFY
	if ((long)(hp->area) == -1L)
		TUTORdump("free_handle called on free handle");
#endif
		
	if (hp->area)
		TUTORdealloc(hp->area);
	
	/* If mem is in the swap file */
	if ((hp->purge & (M_WORM | M_WMRM)) && hp->position >= 0)
		TUTORdelete_swap(hp->position);
	
	if (mm <= mLowest)
		mLowest = mm;	/* start search here */
	hp->lockcount = 0;	/* handle is unlocked */
	hp->area = (char FAR *) -1L;
	
} /* TUTORdump_handle */

/* ------------------------------------------------------------------- */

int TUTORset_hsize(mm, newsize, abort)	/* reset size of memory area */
Memh mm;
long newsize;/* size to reset to */
int abort; /* TRUE if should abort if no memory */

{	struct htab FAR *h; /* pointer to area */
	long oldsize;/* previous size of area */
	char FAR *nptr;	/* pointer to new area */
	long allocsize;

	h = TUTORget_entry_mem(mm);
	if ((h->lockcount > 0) && (newsize > h->size))
		TUTORdump("Attempt to increase size of locked handle");
	oldsize = h->size;
	h->purge = 0; /* so this handle can't be purged */

	allocsize = ((newsize == 0) ? 8: newsize);
    	nptr = realloc(h->area,allocsize);

	if ((long) (nptr) == 0) {
		if (abort)
			nomem("no memory for size increase");
		return (FALSE);
	} /* nptr if */

	h->area = nptr;
	h->size = newsize;

	return (TRUE);

} /* TUTORset_hsize */

/* ------------------------------------------------------------------- */

/* get pointer to handle table entry, retrieve item from disk  */

struct htab FAR *TUTORget_entry_mem(handle) /* get pointer to mmth entry */
int handle;

{	register struct htab FAR *hp;
	int             mm;	/* index into handle table */
	unsigned int    maskTest;
	int             ptype;	/* purge/restore type */

	maskTest = handle & MEMMASK;
	if (!maskTest)
		TUTORdump("Handle without mem-mask");

	mm = handle ^ MEMMASK;	/* remove MEMMASK bit */
	if (!mm)
		TUTORdump("NULL handle in TUTORget_entry_mem");

	if (mm >= hmalloc)
		TUTORdump("mm too large in TUTORget_entry_mem");

	hp = htabp + mm;
	if (!hp->area) {
		TUTORdump("Inactive handle in TUTORget_entry_mem");
	} /* area if */
	return (hp);

} /* TUTORget_entry_mem */

/* ------------------------------------------------------------------- */

DeleteFromHandle(mm, di, dl) /* remove bytes from specified area */
Memh mm;
long di; /* index of first byte to delete */
long dl; /* number of bytes to delete */

{	long hl; /* size of area */
	long rmo; /* offset to bytes after deleted area */
	long rmn; /* number of remaining bytes after delete */
	register char FAR *rmp;	/* pointer to remaining bytes */
	register char FAR *sp;	/* pointer to area */
	register long   i;
	struct htab FAR *h;	/* handle on area */

	h = TUTORget_entry_mem(mm);
	hl = h->size;
	if ((dl <= 0) || (di < 0) || (di >= hl))
		return;
	if ((di + dl) > hl)
		dl = hl - di;	/* insure range legal */
	rmo = di + dl;
	rmn = hl - rmo;		/* number bytes after deleted area */
	rmp = h->area + rmo;	/* pointer to remaining bytes */
	sp = h->area + di;	/* pointer to bytes to delete */
	TUTORblock_move(rmp, sp, rmn);
	TUTORset_hsize(mm, (hl - dl), TRUE);	/* shrink size of area */

} /* DeleteFromHandle */

/* ------------------------------------------------------------------- */

InsertIntoHandle(mm, is, ip, il)/* add bytes to specified area */
Memh mm;
char FAR *is;	/* pointer to bytes to insert */
long ip;	/* position at which to insert */
long il;	/* number of bytes to insert */

{
	long            hl;	/* size of area */
	struct htab FAR *h;	/* handle on area */

	h = TUTORget_entry_mem(mm);
	if (h->lockcount > 0)
		TUTORtrace("Attempt to add bytes to locked handle");
	hl = h->size;
	if ((ip < 0) || (il <= 0))
		return;
	TUTORset_hsize(mm, (hl + il), TRUE);	/* expand area */
	TUTORblock_move(h->area + ip, h->area + ip + il, hl - ip);	/* move down */
	TUTORblock_move(is, h->area + ip, il);	/* insert new text */

} /* InsertIntoHandle */

/* ******************************************************************* */

char FAR *TUTORalloc(size, abort, label) /* allocate block of memory */
long size;
int abort;
char *label;

{	char FAR *mp;

	if (size == 0) 
		size = 8;
	mp = malloc(size);
	if ((mp == NULL) && abort)
		TUTORdump("alloc - out of memory");
	return (mp);

} /* TUTORalloc */

/* ******************************************************************* */

char FAR *TUTORrealloc(ptr, oldsize, newsize, abort)
char FAR *ptr;			/* pointer to previous memory block */
long oldsize;			/* not used on andrew, required for pc */
long newsize;
int abort;			/* TRUE if should abort on failure */

{
    char FAR *rp;

    if (newsize == 0) newsize = 8;
    rp = realloc(ptr, newsize);
    if (rp == NULL)
	TUTORdump("realloc - out of memory");
    return (rp);

} /* TUTORrealloc */


/* ******************************************************************* */

TUTORdealloc(ptr) /* deallocate a block of memory */
char FAR *ptr;

{
    free(ptr);

} /* TUTORdealloc */

/* ******************************************************************* */

static nomem(msg) /* process out-of-memory situation */
char *msg;

{
	TUTORdump(msg);

} /* nomem */

/* ******************************************************************* */

static struct htab FAR *wm_htab(handle) /* get ptr to htab entry */
int handle;

{
	register struct htab FAR *hp;
	int             mm;	/* index into handle table */
	unsigned int    maskTest;

	maskTest = handle & MEMMASK;
	if (!maskTest)
		TUTORdump("wm_htab handle without mem-mask");

	mm = handle ^ MEMMASK;	/* remove MEMMASK bit */
	if (!mm)
		TUTORdump("wm_htab NULL handle");

	if (mm >= hmalloc)
		TUTORdump("wm_htab handle too large");
	hp = htabp + mm;
	return (hp);

} /* wm_htab */

/* ******************************************************************* */

TUTORblock_move(sp, dp, nMove)	/* move bytes from one place to another */
	register char FAR *sp;	/* source pointer */
	register char FAR *dp;	/* dest pointer */
	long            nMove;	/* # of bytes to move */

{	register char  *endP;

	if (nMove <= 0)
		return;
	if (dp <= sp) {
		endP = sp + nMove;
		while (sp < endP)
			*dp++ = *sp++;
	} else {
		endP = sp;
		sp = sp + nMove - 1;
		dp = dp + nMove - 1;
		while (sp >= endP)
			*dp-- = *sp--;
	}

} /* TUTORblock_move */

/* ******************************************************************* */

TUTORzero(ptr, lth) /* zero a block of memory */
unsigned char FAR *ptr;
long lth;

{
#ifdef SYSV
	int ii;
	for (ii = 0; ii < lth; ii++)
		*(ptr++) = 0;
#else
	bzero(ptr, (int) lth);
#endif

} /* TUTORzero */

/* ******************************************************************* */

wm_mem_map()    /* dump memory map to file */

{   FILE *fp;
    FileRef mapname; /* map file name */
    struct htab FAR *hp;    /* pointer to handle table entry */
    char hlabel[10]; /* handle label */
    long lp;    /* long for pointer arithmetic */
    long lw;
    int ii,jj;

    /* build map file name */

    assoc_name(&sourcetable[0].fRef,(FileRef FAR *) &mapname,".map");

    /* open map file */

    fp = fopen(mapname.path,"w");
    if (fp == NULL) return(0);

    fprintf(fp,"memory map of %s\n",strf2n(sourcetable[0].fRef.path));

#ifdef MEMLABEL
    fprintf(fp,"handle table\n");
    for (ii=1, hp=htabp+1; ii<hmalloc;ii++, hp++) {
    strncpyf((char FAR *)hlabel,hp->label,8);
    hlabel[8] = '\0';
    jj = strlen(hlabel);
    while (jj<8)
        hlabel[jj++] = ' ';
    fprintf(fp,"%3x %s %8lx %8lx\n",ii,hlabel,(long)hp->area,(long)hp->size);
    } /* for */
    fprintf(fp,"\n");
#endif

    fclose(fp);

} /* wm_mem_map */


/* ******************************************************************* */

LockMemoryTable() { return; }     /* unused on UNIX systems */
UnlockMemoryTable() { return; }

/* ******************************************************************* */


