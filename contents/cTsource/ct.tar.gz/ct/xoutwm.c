
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/


/*

Handling external i/o for IBM RT PC serial port
July, 1986

Martin Schulman
CMU Physics Department
Office: CMU-2985
Home: 422-5007
Email: ms6t@andrew, ms6t@tf

The following C program accesses "planar serial port S1", one of two internal RS-232-C compatible ports brought to 10-pin connectors on the back of the IBM RT PC models 20 and 25 (floor standing).

1. Planar Serial Ports
Files "/dev/ttys0" and "/dev/ttys1" access ports marked "S2" and "S1", respectively, on the back of RT 20's and 25's.  Of course, to use the ports, your C program must be able to read these files.  But as it turns out, these files reside on the local hard disks, not the central file servers, and are usually read-protected from all but the superuser.  To see if your your files are also protected, enter: 

% ls -l /dev/ttys*

to a typescript prompt.  You should see lines resembling: 

crw-rw-rw-	1 root	12,	1 May 12	20:34	/dev/ttys0
crw-rw-rw-	1 root	12,	1 Jul 7		8:52	/dev/ttys1

The date and time parts needn't match exactly, but the letter "r" should appear three times to the left, as shown.  If they don't, you can change the protection with the following sequence of steps.

a.  Reboot the machine by entering a /bin2/reboot command to a typescript window % prompt, or by simultaneously pressing the ctrl-alt-pause keys.  Of course, you should save any work before doing this. 

b.  Soon after the ACIS Experimental Display screen clears, you will see something like:

4.2 BSD UNIX Standalone Boot Program $ Revision: 5.0 $
Default: hd(0,0)vmunix (just press Enter or wait ~30 seconds)
:

Before those 30 seconds are up, you should enter the phrase

: hd(0,0)vmunix

exactly as it appears above, followed by a return. 

c.  After a shortened version of the typical initialization sequence, you will be given a "#" prompt sign, for the local version of Unix.  Now, as the superuser of your own machine, you are able to change the protection of the local files by entering:

/bin2/chmod 666 /dev/ttys*

d.  Repeat the verification step given before step a to determine whether you have been successful.

e.  Reboot, and let the usual sequence of events occur.

This procedure should only be needed once per workstation, but in case it hasn't been done, it is possible to trap the problem in software (see below).  If it occurs, merely repeat the above steps a-e. 

2.  Parallel Printer Port
On most RT's on the CMU campus, there appears to be an IBM Monochrome Display and Printer Adapter card installed.  These cards bring female DB-9 and DB-25 connectors to the same slot on the rear of the machine.  By using an IBM DB-25 to Centronics cable (the same type used to connect many IBM PC's with parallel printer interfaces to Epson printers), the RT can send output to a printer.  Merely use the device driver "/dev/lp0" as the path. 

3.  Other
The "open" command is usable with all I/O, including the mouse, keyboard, floppy disk, and even machine memory.  Also, each window opened under the window manager appears as a pseudo-terminal, and can be accessed by using devices "/ttyp0" through "/ttypf".  Enter a ls -l /dev command to see what trouble you can get into.

The included file <sys/file.h> defines several variables which make it easy to specify what is to be done to the opened device.  For the serial ports, all we want to do is read or write, so the variable "O_RDWR" is sufficient.  If this had been a file, it may have been appropriate to specify other things, like appending what is written.  In such a case, the defined variables may be or'd together, as "O_RDWR || O_APPEND", and so on. 

The ports have many control options, detailed in TTY(4).  There are also some default options set, probably located in some configuration file on the local disk.  While the defaults may be quite satisfactory for most applications, it adds clarity to the program to define them explicitly, and it shows how to set them if they need to be changed. 

The ioctl call below sets a "New" terminal discipline, most likely required by this version of Unix on the RT's.  It's included here as an example, with the first argument being the file descriptor, the second one defining the type of control to be modified (symbolically defined by the <sgtty.h> file in the case of tty devices), and the third one providing the control parameter.  Note that the control parameter is passed by address, not just value, so that it can be modified in certain ioctl calls. 


The Unix manual entries for OPEN(2), TTY(4), and INTRO(2) specify the use of the following header files;

*/

#include "baseenv.h"

#ifdef SYSV
#define DONTDOIT
#endif

#ifdef LINUX
#define DONTDOIT
#endif

#ifndef DONTDOIT

#include "sys/file.h"
#include "sgtty.h"
#include "errno.h"


/**************************************************/

/*
This ioctl call modifies the "basic" tty port parameters.  The TTY(4) Unix manual reference describes the defined names for control.  To facilitate passing several parameters, basic is a structure defined by the <sgtty.h> include file.  The first two elements are clearly baud rates for the input and output, both just set to their (standard?) default values of 9600.  The next two set special characters for kill and erase, here disabled by using -1.  The last element turns off all the editing features that a tty channel can have (things like erase, kill, delete word,...), and passes only 8 bit binary words.  An application requiring a user to enter words on a terminal could really simplify the program by proper choice of this parameter. 

The New line discipline also allows several other parameters to be set with structures, but none are needed here in RAW mode. 
*/

extsetup(fd,baud,dataB,parity,stopB)   /* set up open serial port for -xout-/-xin- */
int fd;
int baud; /* baud rate */
int dataB; /* data bits (NOT USED) */
int parity; /* parity: 0 even, 1 odd, 2 none */
double stopB; /* stop bits (NOT USED) */
	{
#ifndef hp700
	int ldisc, speed, pFlag;
	struct sgttyb basic;
	extern int errno;

	ldisc=NTTYDISC;
	ioctl(fd,TIOCSETD,&ldisc); 

	speed = BaudRate(baud);
	pFlag = ParityFlag(parity);

	basic.sg_ispeed = speed;
	basic.sg_ospeed = speed;
	basic.sg_erase = -1 ;
	basic.sg_kill = -1 ;
	basic.sg_flags = RAW | pFlag;
	ioctl(fd,TIOCSETP,&basic);
#endif
	return;
	}

static int BaudRate(baud) /* translate baud into proper bit flag */
int baud;
	{
	switch (baud)
		{
		case 0: return (B0);
		case 50: return(B50);
		case 75: return(B75);
		case 110: return(B110);
		case 134: return(B134);
		case 150: return(B150);
		case 200: return(B200);
		case 300: return(B300);
		case 600: return(B600);
		case 1200: return(B1200);
		case 1800: return(B1800);
		case 2400: return(B2400);
		case 4800: return(B4800);
		case 9600: return(B9600);
		default: return(9600);
		}
	}

static int ParityFlag(parity) /* translate parity into proper system flag */
int parity;
	{
	if (parity == 0)
		return(EVENP);
	else if (parity == 1)
		return(ODDP);
	else
		return(ANYP); /* no parity */
	}

#else

int extsetup() { return(0); } /* dummy under SYSV */

#endif


