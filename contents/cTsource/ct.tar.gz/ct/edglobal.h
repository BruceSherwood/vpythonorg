
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Definitions for editor (& compiler)
KSW 9/88
*/

#ifndef _edglobalh
#define _edglobalh

extern Memh vsource;	/* pointer to view on source */

extern Memh editmenus;	/* editor menu definitions */
extern Memh dictH; /* dictionary info */

extern Memh searchH; /* search window */
extern char FAR *curSelUnit; /* currently selected unit */
extern int curSelEdit; /* index of editor on currently selected unit */

extern char binaryFileCurrent; /* TRUE if current binary matches binary file */

#endif /* _edglobalh */
