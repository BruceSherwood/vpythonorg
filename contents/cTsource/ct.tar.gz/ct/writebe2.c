
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* file to write BE2 statstream format files */

#include "baseenv.h"
#include "txt.h"
#include <stdio.h>
#include "tglobals.h"
#include "kglobals.h"

#ifdef ctproto
int  TUTORfwrite_be2_doc(int  sFlag,unsigned int  theD,long  sPos,long  ePos,int  fOut,char  FAR * FAR *mp,long  *mLen);
int  Be2Out(char  FAR *cP,int  cLen);
extern int  WriteNewl(void);
extern int  WriteTutorDefs(void);
extern int  WriteState(unsigned int  theD,long  curPos,long  *nPos);
extern int  LookFaceOpen(int  oldFace,int  newFace,int  lookFrom);
extern int  LookJustOpen(int  oldJust,int  newJust);
extern int  LookVisOpen(int  oldVis,int  newVis);
extern int  WriteTextb2(unsigned int  theD,long  startPos,long  endPos,int  styFlag);
extern char  *StyleName(int  nStyle);
long  TUTORwrite(char  FAR *ptr,int  pSize,long  count,int  findx);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
int  TUTORtrace(char  *s);
char  FAR *TUTORrealloc(char  FAR *ptr,long  oldsize,long  newsize,int  abort);
int  TUTORinq_file_err(int  findx);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  FindBlockTStyle(struct  _pdt FAR *pp,long  pos);
int  TUTORget_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  FontFamilyIndex(long  id);
int  AtTStyle(unsigned int  pd,long  pos,short  *styles);
int  TUTORcvt_toascii_chars(unsigned char  FAR *cp,long  clen);
struct  _tblk FAR *FindTBlock(struct  _ktd FAR *dp,long  pos,long  *pOff,long  *eOff);
int  _TUTORload_buffer_doc(struct  _ktd FAR *dp,long  pos);
#endif /* ctproto */

#ifdef macproto
#endif

/* style number definitions */
#define BOLDFACE 1
#define ITALICFACE 2
#define UNDERLINEFACE 3
#define OUTLINEFACE 4
#define SHADOWFACE 5
#define SUBFACE 6
#define SUPERFACE 7

#define BIGGERSTYLE 11
#define SMALLERSTYLE 12

#define LEFTJUSTIFY 21
#define CENTERJUSTIFY 22
#define RIGHTJUSTIFY 23

#define TVISIBLE 31
#define TINVISIBLE 32

#define SPECIALSTYLE 41

/* if the following is defined we will write out crlf for NEWLINE.  But
	cT 1.1 won't read such a datastream in correctly in all cases... */
/* #define IBMPCcrlf */

extern char *strf2n();
extern char FAR *TUTORrealloc();
extern long TUTORinq_file_pos();
extern struct  _tblk FAR *FindTBlock();
char *StyleName();

static int findx;
static char FAR *memP; /* if memP exists, we are writing to it rather than file */
static long memLen; /* current length of memP allocation */
static long memWritten; /* amount in memP already written */

/* variables for redoing text block file map */
static char memError; /* TRUE if ran out of memory when writing to memory */
static long FAR *tempAddr = FARNULL; /* temporary copies of address */

TUTORfwrite_be2_doc(sFlag,theD,sPos,ePos,fOut,mp,mLen)
int sFlag; /* stream flag  0: normal be2, 1: ascii only */
Memh theD;	/* document to be written */
long sPos, ePos; /* start and end position of write */
int fOut; /* file to write to (if writing to file) */
char FAR * FAR *mp; /* pointer to memory (if writing to memory) */
long *mLen; /* allocation length of memory area (if writing to memory) */
/* returns TRUE for success */
	{
	long nextPos; /* next position of style change */
	int nStyles; /* number of currently open style */
	int ii;
	int isStyled;	/* TRUE if the document is styled */
	DocP dP;	/* pointer to document */
	
	dP = (DocP) GetPtr(theD);
	isStyled = dP->styles ? TRUE : FALSE;
	ReleasePtr(theD);
	KillPtr(dP);
	
	findx = fOut; /* for Be2Out */

	if ((long)(mp))
		{ /* we are writing to memory */
		findx = NEARNULL;
		memWritten = 0;
		memP = *mp;
		memLen = *mLen;
		memError = FALSE;
		}
	else
		{ /* we are writing to file */
		findx = fOut;
		memP = FARNULL;
		}
	
	if (!isStyled || sFlag == 1)
		{ /* just need to write out text */
		WriteTextb2(theD,sPos,ePos,FALSE);
		}
	else
		{ /* write out styled document */
		
		/* put in header */
		Be2Out((char FAR *) "\\begindata{text, 204354}",24);
		WriteNewl();
		Be2Out((char FAR *) "\\textdsversion{11}",18);
		WriteNewl();
		Be2Out((char FAR *) "\\template{default}",18);
		WriteNewl();
		WriteTutorDefs();
	
		nStyles = WriteState(theD,sPos,&nextPos); /* show state at begin of write */
		while (sPos < ePos)
			{ /* until we get to the end... */
			if (nextPos > ePos)
				nextPos = ePos; /* if next change after end, clip to end */
			if (!WriteTextb2(theD,sPos,nextPos,TRUE)) break; /* output plain text */
			sPos = nextPos;

			/* close all open styles */
			while (nStyles)
				{
				Be2Out((char FAR *) "}",1);
				nStyles--;
				}
			if (sPos < ePos) /* we aren't at end, must be at start of new style */
				nStyles = WriteState(theD,sPos,&nextPos); /* write state at new position */
			}
	
		/* write trailer */
		Be2Out((char FAR *) "\\enddata{text,204354}",21);
		WriteNewl();
		} /* end of styled text write */
	
	if ((long)(mp))
		{ /* we were writing to memory */
		*mp = memP;
		*mLen = memWritten;
		ii = !memError;
		}
	else
		{ /* we were writing to file, check for error on file */
		ii = !TUTORinq_file_err(fOut);
		}

	return(ii);
	}

Be2Out(cP,cLen)	/* output text to file or memory */
char FAR *cP;	/* text to output */
int cLen;	/* length of text to output */
	{
	char FAR *tempP;	/* copy of cP */
	char FAR *destP;	/* where we write, if to memory */
	int extraCount; /* extra chars we are adding (for end of lines) */
	int ii;

#ifdef IBMPCcrlf
	/* count # of newlines, so we can make sure we have enough memory */
	ii = cLen;
	extraCount = 0;
	tempP = cP;
	while (ii--)
		if (*tempP == NEWLINE)
			extraCount++;
#else
	extraCount = 0;
#endif

	if ((long)(memP) && !memError)
		{ /* write to memory */
		if (memLen < memWritten + cLen+extraCount)
			{ /* need to make memP bigger */
			tempP = TUTORrealloc(memP,memLen, memLen + cLen+extraCount + 1000,TRUE);
			if (!(long)(tempP))
				{
				memError = TRUE;
				/* note memP still pointing at last valid memory allocation */
				return;
				}
			memP = tempP;
			memLen += cLen + 1000;
			}
#ifdef IBMPCcrlf
		/* translate NEWLINE to carriage return-linefeed */
		/* note that the NEWLINE is linefeed */
		ii = cLen;
		destP = memP+memWritten;
		while (ii--)
			{
			if (*cP == NEWLINE)
				*destP++ = 0xd; /* carriage return */
			*destP++ = *cP++;
			cP++;
			}
#else
		TUTORblock_move(cP,memP+memWritten,(long) cLen);
#endif
		memWritten += cLen;
		}
	else
		{ /* write to file */
#ifdef IBMPCcrlf
		tempP = cP;
		ii=0;
		while (ii < cLen)
			{
			while (ii < cLen && *tempP != NEWLINE)
				{ /* scan till we find newline */
				ii++;
				tempP++;
				}
			if (tempP > cP)
				TUTORwrite(cP,(int)sizeof(char),(long) (tempP-cP),findx);
			if (ii < cLen && *tempP == NEWLINE)
				{
				TUTORwrite_char(0xd,findx); /* write out carriage return */
				TUTORwrite_char(0xa,findx); /* write out linefeed */
				ii++;
				tempP++; /* to skip past newline */
				}
			cP = tempP;
			}
#else
		TUTORwrite(cP,(int)sizeof(char),(long) cLen,findx);
#endif
		}

	return;
	}

static WriteNewl()	/* output a newline */
	{
	Be2Out((char FAR *) NEWLINES,1);
	}

static WriteTutorDefs()	/* write out cT be2 header */
	{
	/* invisible definition */
	Be2Out((char FAR *) "\\define{invisible",17); WriteNewl();
	Be2Out((char FAR *) "}",1); WriteNewl();

	/* Serif font definition */
	Be2Out((char FAR *) "\\define{zserif",14); WriteNewl();
	Be2Out((char FAR *) "menu:[Font,Andy]",16); WriteNewl();
	Be2Out((char FAR *) "attr:[FontFamily Andy Int 0]}",29); WriteNewl();
	
	/* SansSerif font definition */
	Be2Out((char FAR *) "\\define{zsans",13); WriteNewl();
	Be2Out((char FAR *) "menu:[Font,AndySans]",20); WriteNewl();
	Be2Out((char FAR *) "attr:[FontFamily AndySans Int 0]}",33); WriteNewl();
	
	/* Fixed font definition */
	Be2Out((char FAR *) "\\define{zfixed",14); WriteNewl();
	Be2Out((char FAR *) "menu:[Font,AndyFixed]",21); WriteNewl();
	Be2Out((char FAR *) "attr:[FontFamily AndyFixed Int 0]}",34); WriteNewl();
	
	/* Symbol font definition */
	Be2Out((char FAR *) "\\define{zsymbol",15); WriteNewl();
	Be2Out((char FAR *) "menu:[Font,AndySymbol]",22); WriteNewl();
	Be2Out((char FAR *) "attr:[FontFamily AndySymbol Int 0]}",35); WriteNewl();
	}

/* percentage differences needed for each number of biggers */
#define NBIGGERSIZES 6
static short biggerSizes[NBIGGERSIZES] = {20,40,80,140,260,380};
/* we always get 1 SMALLER for each -20 */

static WriteState(theD,curPos,nPos)	/* write current style state */
Memh theD;	/* document */
long curPos;	/* position for which we are writing styles */
long *nPos;		/* to be set to next style change position */
	{
	short style;	/* current style data we are considering */
	short ii;
	REGISTER DocP dp;	/* pointer to document */
	StyleDatP pp;	/* pointer to document styles */
	Style1 SHUGE *s1p;	/* pointer to style block */
	short nextI;	/* index of next style block */
	int sNum;	/* code for style which we've encountered */
	char *theStyle;	/* style name to be written */
	int nStyle;		/* the # of styles written out */
	FontFamily FAR *ffp;	/* pointer to global font family table */
	char tempS[FILEL+1];	/* to contain font name */
	short styles[NSTYLES];	/* current styles */
	
	dp = (DocP) GetPtr(theD);
	
	nStyle = 0;
	AtTStyle(dp->styles,curPos,styles);
	
	style = styles[FACESTYLE];
	sNum = 0;
	while ((sNum = LookFaceOpen(0,style,sNum)) >= 0)
		{
		nStyle++;
		Be2Out((char FAR *) "\\",1);
		theStyle = StyleName(++sNum);
		Be2Out((char FAR *) theStyle,strlen(theStyle));
		Be2Out((char FAR *) "{",1);
		}
		
	style = styles[SIZESTYLE];
	if (style == DEFSTYLE)
		style = 0;
	if (style <= ABSSIZE)
		style = 0; /* no absolute sizes supported */
	if (style < 0)
		{
		while (style < 0)
			{
			nStyle++;
			Be2Out((char FAR *) "\\",1);
			theStyle = StyleName(SMALLERSTYLE);
			Be2Out((char FAR *) theStyle,strlen(theStyle));
			Be2Out((char FAR *) "{",1);
			style += 20;
			}
		}
	else if (style > 0)
		{
		/* first do BIGGERS that take us through our table sizes */
		ii = 0;
		while (ii < NBIGGERSIZES && style >= biggerSizes[ii])
			{
			nStyle++;
			Be2Out((char FAR *) "\\",1);
			theStyle = StyleName(BIGGERSTYLE);
			Be2Out((char FAR *) theStyle,strlen(theStyle));
			Be2Out((char FAR *) "{",1);
			ii++;
			}
		/* if we still have biggers left they come at 20% apiece */
		ii = 20;
		while (style >= biggerSizes[NBIGGERSIZES-1]+ii)
			{
			nStyle++;
			Be2Out((char FAR *) "\\",1);
			theStyle = StyleName(BIGGERSTYLE);
			Be2Out((char FAR *) theStyle,strlen(theStyle));
			Be2Out((char FAR *) "{",1);
			ii += 20;
			}
		}
	
	style = styles[PARASTYLE];
	if (sNum = LookJustOpen(FULLJUST,style))
		{
		nStyle++;
		Be2Out((char FAR *) "\\",1);
		theStyle = StyleName(sNum+20);
		Be2Out((char FAR *) theStyle,strlen(theStyle));
		Be2Out((char FAR *) "{",1);
		}
	if (sNum = LookVisOpen(0,style))
		{
		nStyle++;
		Be2Out((char FAR *) "\\",1);
		theStyle = StyleName(sNum);
		Be2Out((char FAR *) theStyle,strlen(theStyle));
		Be2Out((char FAR *) "{",1);
		}
	
	style = styles[FONTSTYLE];
	if (style != DEFSTYLE)
		{
		nStyle++;
		ii = FontFamilyIndex((long)style); /* index of font family in font family table */
		ffp = ii + (FontFamily FAR *) GetPtr(fontFamilies);
		Be2Out((char FAR *) "\\",1);
		TUTORget_fileref_name(&ffp->familyRef,(char FAR *) tempS);
		Be2Out(tempS,strlen(tempS));
		Be2Out((char FAR *) "{",1);
		ReleasePtr(fontFamilies);
		KillPtr(ffp);
		}
	
	/* figure out next position to consider */
	
	pp = (StyleDatP) GetPtr(dp->styles);
	nextI = FindBlockTStyle(pp,curPos);
	s1p = pp->styles+nextI;
	while (nextI < pp->sHead.dAnn && s1p->pos <= curPos)
		{
		s1p++;
		nextI++;
		}
	if (nextI >= pp->sHead.dAnn)
		{
		*nPos = dp->totLen+10; /* no more styles */
		}
	else
		*nPos = s1p->pos;
	ReleasePtr(dp->styles);
	KillPtr(pp);

	ReleasePtr(theD);
	KillPtr(dp);
	
	return(nStyle);
	}

static LookFaceOpen(oldFace, newFace, lookFrom)	/* calculate new face style */
int oldFace, newFace;	/* old & new face styles */
int lookFrom; /* 0 thru 7 low to hi */
	{
	register int ii;
	register short openFace;	/* the difference between old & new */
	
	openFace = newFace & ~oldFace;
	if (!openFace) return(-1); /* no faces opened */
	for (ii=lookFrom; ii < 8; ii++)
		if (openFace & 1<<ii) return(ii);
	return(-1);
	}

static LookJustOpen(oldJust,newJust)	/* calculate new justification */
register int oldJust, newJust;	/* old & new justifications */
	{
	oldJust &= JUSTMASK;
	newJust &= JUSTMASK;
	if (oldJust == newJust) return(0);
	if (newJust == FULLJUST) return(0);
	return((newJust>>1)+1);
	}

static LookVisOpen(oldVis,newVis)	/* calculate new visibility style */
register int oldVis, newVis;	/* old & new visibilities */
	{
	oldVis &= VISMASK;
	newVis &= VISMASK;
	if (oldVis == newVis)
		return(0);
	if (newVis == 0)
		return(0);
	return(TINVISIBLE);
	}

static WriteTextb2(theD,startPos,endPos,styFlag) /* write out characters */
Memh theD;	/* document being written */
long startPos, endPos;	/* portion of document begin written */
int styFlag; /* if TRUE, we need to escape certain characters */
	{
	TextBlock FAR *curBlock;	/* pointer to textblock being written */
	long startOff;	/* offset from beginning of textblock to our position */
	long endOff;	/* offset from our position to end of textblock */
	long totLen;	/* count of chars still needing to be written */
	REGISTER unsigned char FAR *tp;	/* pointer to text we are looking at */
	register int kk;
	register int outLen;	/* # of characters we can write in next chunk */
	register unsigned char cc;
	unsigned char c2;
	register int writeLen;	/* # of characters we have scanned & want to write */
	unsigned char FAR *writeP;	/* pointer to beginning of text still needing writing */
	DocP dp;
	
	dp = (DocP) GetPtr(theD);
	if (!dp->shortText)
		{
		if (endPos - startPos < dp->txtH.dAnn)
			{ /* put text into buffer */
			_TUTORload_buffer_doc(dp,startPos);
			curBlock = FARNULL;
			endOff = endPos - startPos;
			}
		else
			curBlock = FindTBlock(dp,startPos,&startOff,&endOff);
		}
	else
		{
		curBlock = FARNULL;
		endOff = endPos - startPos;
		}
	
	totLen = endPos - startPos;
	
	while (totLen > 0)
		{
		outLen = (totLen > endOff) ? endOff : totLen;
		if (curBlock)
			tp = (unsigned char FAR *) GetPtr(curBlock->text)+startOff;
		else
			tp = dp->text + startPos - dp->buffStart;
		writeP = tp;
		if (styFlag)
			{ /* we need to make sure certain characters are escaped */
			writeLen = 0;
			for (kk=0; kk<outLen; kk++)
				{
				/* if char is one of \{} need to put out a \ first */
				cc = *tp;
				if (cc == '{' || cc == '}' || cc == '\\')
					{ /* write what we have so far... */
					Be2Out((char FAR *) writeP,writeLen);
					Be2Out((char FAR *) "\\",1);
					/* set next write to current tp */
					writeP = tp;
					writeLen = 0;
					}
				else if (cc > 127)
					{ /* some special char */
					Be2Out((char FAR *) writeP,writeLen); /* what we have so far */
					c2 = cc;
					TUTORcvt_toascii_chars((unsigned char FAR *)&c2,1L);
					Be2Out((char FAR *) "?",1L);
					writeP = tp+1;
					writeLen = -1;
					}
				tp++;
				writeLen++;
				}
			}
		else
			{ /* unstyled text, just write it out */
			writeLen = outLen;
			}

		/* write remainder from this block */
		Be2Out((char FAR *) writeP,writeLen);
		if (curBlock)
			{
			ReleasePtr(curBlock->text);
			KillPtr(tp);
			}
		else
			break; /* we must be done */
		totLen -= outLen;
		if (totLen > 0)
			{ /* get text from next block */
			curBlock++;
			startOff = 0L;
			endOff = curBlock->tLen;
			}
		}
	ReleasePtr(theD);
	KillPtr(dp);
	
	return(TRUE);
	}

static char *StyleName(nStyle)	/* return style name */
int nStyle;	/* style code */
	{
	/* style strings */
	static char *faceStyles[] = {"bold","italic","underline","shadow","outline","subscript","superscript"};
	static char *sizeStyles[] = {"bigger","smaller"};
	static char *justStyles[] = {"flushleft","center","flushright"};
	static char *visStyles[] = {"visible","invisible"};
	static char *spStyle = "cTspecial";
	
	if (nStyle > 0 && nStyle < 11)
		return(faceStyles[nStyle-1]);
	if (nStyle > 10 && nStyle < 20)
		return(sizeStyles[nStyle-11]);
	if (nStyle > 20 && nStyle < 30)
		return(justStyles[nStyle-21]);
	if (nStyle > 30 && nStyle < 40)
		return(visStyles[nStyle-31]);
	if (nStyle >40 && nStyle <= 41)
		return(spStyle);

	return("Unknown");
	}
