
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/


#include "baseenv.h"
#include "kdefs.h"
#include "editmenu.h"
#include "tutor.h"
#include "editor.h"
#include "tglobals.h"
#include "edglobal.h"
#include "ecglobal.h"
#include "txt.h"
#include "txtv.h"
#include "fkeys.h"
#include "help.h"

#ifdef MAC
#ifdef THINKC5
#include <Types.h>
#include <Windows.h>
#else
#ifdef WERKS
#include <Types.h>
#include <Windows.h>
#else
#include <WindowMgr.h>
#endif
#endif
#endif

Memh helpmenus = HNULL;  /* editor menu definitions */
static int line_break; /* 0x0a or 0x0d */
static Memh theHelpH = 0;

#ifdef ctproto
extern int TUTORset_window_title(int wix,char *str);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,
 int ebsref,struct  _trect *theR,int  relInfo,int  mintw,int  wrap,
 unsigned int  doc,long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),
 int  ro,int  corner,int  erase,int  frame,int tabsz,int lm,int rm,int inhss,int type);
extern  int TUTORreset_file(int findx,int option);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORclose_doc(unsigned int  doc);
int  TUTORclose_panel(unsigned int  theV);
extern int TUTORclose_window(int wid);
int  TUTORclose_view(struct  tutorview FAR *vp);
int  TUTORforward_window(int  wix);
int  AllowHandlePurge(unsigned int  mm);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
long  TUTORinq_msec_clock(void);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
extern int KeyIndexList(HelpDat FAR *helpD,int key);
int  TUTORpush_event(struct  tutorevent *event);
extern  int TUTORset_abs_clip_rect(TRect FAR *cr);
int  TUTORinq_abs_clip_rect(struct  _trect *cr);
int  TUTORclip_window(int  wid);
int  openhelp(int  pid);
extern int TUTORzero(char SHUGE *ptr,long length);
int TUTORfree_event_memory(struct tutorevent FAR *event);
int  inithelp_menus(void);
int  prochelp(unsigned int  helpH,struct  tutorevent *event);
extern int  CycleActiveHelp(struct  _hinf FAR *helpD,int  nn);
extern int  ChangeActiveHelp(struct  _hinf FAR *helpD,struct  tutorview FAR *newV);
extern int  FixHelpSelection(unsigned int  helpH,struct  tutorview FAR *eview);
int  prochelpv(unsigned int  viewH,struct  tutorevent *event);
extern int  prochelpclick(struct  _hinf FAR *helpD,struct  tutorview FAR *view);
extern int  DrawHelpTitles(struct  _hinf FAR *helpD);
extern int  RedrawIndexTitle(struct  _hinf FAR *helpD);
extern int  HotClick(struct  _hinf FAR *helpD,int  itemN);
extern int  ListClick(struct  _hinf FAR *helpD,int  itemN,long  lineS,long  lineL);
extern int  IndexClick(struct  _hinf FAR *helpD,int  itemN,long  lineS,long  lineL);
extern int  ReadHelpHeader(void);
extern int  ReadPieceHelp(unsigned int  doc,long  start,long  len,int  type);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,int ebsref,
 struct  _trect *theR,int  relInfo,int  mintw,int  wrap,unsigned int  doc,
  long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),int  ro,int  corner,
 int  erase,int  frame,int tabsz,int lm,int rm,int inhss,int type);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  TUTORset_rect(struct  _trect *r,int  left,int  top,int  right,int  bottom);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORset_view(struct  tutorview FAR *vp);
struct  tutorview FAR *TUTORinit_view(int  sW,unsigned int  vDat,int  (*vProc)());
int  prochelpvstub(unsigned int  hv,struct  tutorevent *event);
int  TUTORget_zfont(char  *famS,int  size);
int  TUTORinq_abs_screen_size(int  *x,int  *y,int  *dx,int  *dy);
int  TUTORset_program_name(char  *pname);
int  TUTORcreate_window(int  top,int  left,int  xSize,int  ySize,int  type);
struct  tutorview FAR *TUTORinq_view(void);
int  TUTORnormal_cursor(void);
int  editormsg(char  *ss,int  aFlag);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORcopy_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  TUTORcopy_fileref_dir(struct  _fref FAR *dirname,struct  _fref FAR *fullname);
int  TUTORwait_cursor(void);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORshow_window(int  wix);
int  TUTORadd_menu(unsigned int  barh,char  *card,int  cp,char  *item,int  ip,int  keyBind,int  type,int  unit,double  unitArg,int  eType);
unsigned int  TUTORinit_menubar(int  nItems);
int  TUTORdelete_menu(unsigned int  barh,char  *card,char  *item);
int  TUTORpost_event(struct  tutorevent *event);
int  prochelpstub(unsigned int  wh,struct  tutorevent *event);
int  TUTORset_menubar(unsigned int  barh,struct  tutorview FAR *newMenuView);
int  TUTORset_event_mask(int  eventc,int  value);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
int  TUTORinsert_string_doc(unsigned int  doc,long  pos,unsigned char  FAR *ss,long  sLen);
int  EditorDefaultStyles(unsigned int  doc);
int  TUTORclear_window(int  wid);
int  TUTORclose_doc(unsigned int  doc);
int  TUTORto_clip_doc(unsigned int  doc,long  pos,long  len,int  doCut,long  *extraPos);
int  TUTORstyle_doc(unsigned int  doc,long  pos,long  len,int  type,int  dat,int  canCombine,long  *extraPos);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
int  TUTORinq_select_tview(unsigned int  theV,long  *pos,long  *len);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int  TUTORabs_move_to(int  x,int  y);
int  TUTORinq_abs_string_width(unsigned char  FAR *s,int  lth,int  *dx);
int  TUTORdraw_text(unsigned char  FAR *buf,int  count);
int  TUTORset_textfont(int  jj);
int  TUTORinq_select_line(unsigned int  theV,int  yy,long  *lineS,long  *lineL);
int  TUTORabs_line_to(int  x,int  y);
int  TUTORset_abs_view_rect(int  x1,int  y1,int  w,int  h);
int  TUTORclip_window(int  wid);
int  SetSelectPanel(struct  _tvdat FAR *vp,long  pos,long  len);
long  _TUTORline_pos_tview(struct  _viewp FAR *tvp,int  lineN);
int  RestartPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  selStart,long  selLen);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
int  RefreshPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  cpos,long  clen,long  newC,long  selStart,long  selLen,int  scroll,int force);
int  TUTORclose(int  findx);
long  hlp_read_number(int  findx);
int  TUTORungetc(int  findx,int  cc);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
int  TUTORread_char(unsigned char  *cc,int  findx);
int  TUTORget_char(int  findx,int  tryHard);
int  TUTORdump(char  *s);
int  TUTORfread_doc(unsigned int  doc,long  len,int  docKind,int  fInd);
int  TUTORseek(int  findx,long  pos);
int  TUTORclear_doc(unsigned int  doc);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
#ifdef IBMPROTO
int _CDECL sscanf(const char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef MAC
extern int sprintf(char *ss, char *form,...);
#ifdef macproto
extern int sscanf(char *ss, char *form, ...);
int ShowGrowIcon(int wn);
#endif
#endif

extern Memh TUTORnew_doc();
extern  struct tutorview FAR *TUTORinq_view();
extern struct tutorview FAR *TUTORinit_view();
extern int prochelpstub();
extern Memh TUTORinit_menubar();
extern long hlp_read_number();
extern int prochelpvstub();
extern Memh MakeTextPanel();
extern long TUTORget_len_doc();
extern long _TUTORline_pos_tview();
extern Memh _TUTORsave_read_tables();

/* ******************************************************************* */

openhelp(pid)   /* open help window */
int pid; /* id of parent window (only used on first open) */
/* returns TRUE if succesful */
    {
    short dwidth;
    TRect tRect;
    short trInf, listVSize;
    Memh doc;
    int wx,wy,wdx,wdy;
    struct tutorevent edevent;  /* event */
    HelpDat FAR *helpD;
    TextVDat FAR *vp;
    struct tutorview FAR *cv;
    int corner;
    TViewP tvp;
    
    if (HelpVp) {
    	TUTORforward_window(HelpWn);
        return(TRUE); /* help window is open already */
	}
	    
    
    /* initialize window and views */
    theHelpH = TUTORhandle("HelpDat",(long) sizeof(HelpDat),TRUE);
    if (!theHelpH)
        return(FALSE);
    TUTORwait_cursor();
    helpD = (HelpDat FAR *) GetPtr(theHelpH);
    TUTORzero((char FAR *)helpD,(long)sizeof(HelpDat));
    
    /* open file & read in help file header */
    helpD->helpFile.path[0] = '\0';
    TUTORcopy_fileref_dir(&helpD->helpFile,ctDirP);
    
    /* first we try reading long file in common directory */
    TUTORcopy_fileref_name(&helpD->helpFile,(char FAR *) HELPNAME);
    if (!ReadHelpHeader())
        { /* try reading short help */
        TUTORcopy_fileref_name(&helpD->helpFile,(char FAR *) HELPNAMES);
        if (!ReadHelpHeader())
            { /* can't find anything... */
            ReleasePtr(theHelpH);
            KillPtr(helpD);
            TUTORfree_handle(theHelpH);
            theHelpH = 0;
            editormsg("Cannot open help file!",TRUE);
            TUTORnormal_cursor();
            return(FALSE);
            }
        }
    
    helpD->boldListS = -1;
    helpD->boldIndexS = -1;
    cv = TUTORinq_view();
    
    /* create help window */
    HelpWn = TUTORcreate_window(-1,-1,windowsP[pid].wxsize,450,HELPW);
    TUTORset_window_title(HelpWn,"Help on cT");
    helpD->wp = windowsP[HelpWn].wp;
    helpD->wid = HelpWn;
    
    TUTORinq_abs_screen_size(&wx,&wy,&wdx,&wdy);
    listVSize = wdy/4; /* one quarter window height */
    if (listVSize > 150)
        listVSize = 150;
    helpD->listVSize = listVSize;
    
    helpD->titleF = TUTORget_zfont("zsans",HELPSIZE);

    /* create background window view */
    helpD->helpV = TUTORinit_view(HelpWn,theHelpH,prochelpvstub);
    helpD->helpV->caninput = FALSE; /* keys & menus don't go here */
    helpD->helpV->canclick = FALSE; /* neither do clicks */
    TUTORset_view(helpD->helpV);
    HelpVp = helpD->helpV;

    /* create index view */
    TUTORset_rect(&tRect,0,BANNERV,wdx-LISTH+1,BANNERV+listVSize);
    trInf = LEFTSTICK + TOPSTICK + RIGHTSTICK;
    doc = TUTORnew_doc(TRUE,FALSE);
    helpD->indexDocH = doc;
    helpD->nCurEntries = ReadPieceHelp(doc,helpD->entries[0].textStart,helpD->entries[0].textLen,0);
    helpD->curIndex = 0;
    helpD->indexh = MakeTextPanel(HelpWn,(long) theHelpH,0,0,&tRect,trInf,10,FALSE,doc,0L,-1L,TRUE,FALSE,
            FARNULL,TRUE,FALSE,FALSE,FALSE,-1,-1,-1,FALSE,5);
    vp = (TextVDat FAR *) GetPtr(helpD->indexh);
    helpD->indexV = vp->view;
    helpD->indexSh = vp->scrollv;
    ReleasePtr(helpD->indexh);
    KillPtr(vp);
    
    /* create list view */
    TUTORset_rect(&tRect,wdx-LISTH,BANNERV,wdx+1,BANNERV+listVSize);
    trInf = TOPSTICK + RIGHTSTICK;
    doc = TUTORnew_doc(TRUE,FALSE);
    ReadPieceHelp(doc,helpD->cStart,helpD->cLen,2);
    helpD->listDocH = doc;
    helpD->listH = MakeTextPanel(HelpWn,(long) theHelpH,0,0,&tRect,trInf,10,FALSE,doc,0L,
                    -1L,TRUE,FALSE,
            FARNULL,TRUE,FALSE,FALSE,FALSE,-1,-1,-1,FALSE,5);
    vp = (TextVDat FAR *) GetPtr(helpD->listH);
    helpD->listV = vp->view;
    helpD->listSh = vp->scrollv;
    ReleasePtr(helpD->listH);
    KillPtr(vp);
    
    /* set up body view */
#ifdef MAC
    corner = TRUE;
#else
    corner = FALSE;
#endif
    doc = TUTORnew_doc(FALSE,FALSE);
    helpD->bodyDocH = doc;
    EditorDefaultStyles(doc);
    TUTORinsert_string_doc(doc,0L,(unsigned char FAR *) " ",1L);
    trInf = LEFTSTICK + TOPSTICK + RIGHTSTICK + BOTTOMSTICK;
    TUTORset_rect(&tRect,0,BANNERV+listVSize,wdx+1,wdy);
    helpD->bodyh = MakeTextPanel(HelpWn,(long) theHelpH,0,0,&tRect,trInf,200,TRUE,doc,0L,-1L,TRUE,FALSE,
            FARNULL,TRUE,corner,FALSE,FALSE,-1,-1,-1,FALSE,5);
    vp = (TextVDat FAR *) GetPtr(helpD->bodyh);
    helpD->bodyV = vp->view;
    helpD->bodySh = vp->scrollv;
    TUTORset_key_focus(HelpWn,vp->view,FALSE);
    helpD->curActive = helpD->bodyV;
    vp->singleSel = TRUE; /* TRUE if should select on single click */
    tvp = (TViewP) GetPtr(vp->textv);
    tvp->singleSel = TRUE; /* TRUE if should select on single click */
    ReleasePtr(vp->textv);
    KillPtr(tvp);
    ReleasePtr(helpD->bodyh);
    KillPtr(vp);
 
    /* set event masks for the help window */
    TUTORset_event_mask(EVENT_KEY,TRUE);
    TUTORset_event_mask(EVENT_FKEY,TRUE);
    TUTORset_event_mask(EVENT_FWD,TRUE);
    TUTORset_event_mask(EVENT_MENU,TRUE);
    TUTORset_event_mask(EVENT_MSG,TRUE);
    TUTORset_event_mask(EVENT_LEFTDOWN,TRUE);
    TUTORset_event_mask(EVENT_RIGHTDOWN,TRUE);
    TUTORset_event_mask(EVENT_LEFTUP,TRUE);
    TUTORset_event_mask(EVENT_RIGHTUP,TRUE);
    TUTORset_event_mask(EVENT_DOWNMOVE,TRUE);
    TUTORset_event_mask(EVENT_WFOCUS,TRUE);
    TUTORset_event_mask(EVENT_SCROLL,TRUE);
    TUTORset_event_mask(EVENT_HOT,TRUE);
    TUTORset_event_mask(EVENT_VFOCUS,TRUE);
    TUTORset_event_mask(EVENT_DESTROY,TRUE);
    
    inithelp_menus();
    
    /* attach menus */
    TUTORset_menubar(helpmenus,helpD->bodyV); /* set menus for help window */
#ifdef THINKC5
    windowsP[HelpWn].wproc = (int(*)(...))(prochelpstub);
#else
    windowsP[HelpWn].wproc = (int(*)())(prochelpstub);
#endif
    windowsP[HelpWn].wH = theHelpH;
    
    TUTORset_view(cv);
    TUTORnormal_cursor();

    /* show window */
    TUTORshow_window(HelpWn);
#ifdef MAC
    SelectWindow((WindowPtr)windowsP[HelpWn].wp);
#endif

    ReleasePtr(theHelpH);
    KillPtr(helpD);
    
    return(TRUE);
    }

/* ******************************************************************* */
inithelp_menus() /* set up the editor menu bar */
    {
    
    /* start edit menu bar */
    if (!helpmenus)
    	helpmenus = TUTORinit_menubar(5);
    
    /* create edit menu items */
    TUTORadd_menu(helpmenus,NIL,0,"Main Index",10,0,edit_previndex,1,0.0,EVENT_MENU);
    TUTORadd_menu(helpmenus,NIL,0,"Previous Index",10,0,edit_previndex,0,0.0,EVENT_MENU);
#ifdef WINPC
    TUTORadd_menu(helpmenus,NIL,0,"Copy\tCtrl+C",10,'C',edit_copy,3,0.0,EVENT_MENU);
#else
	TUTORadd_menu(helpmenus,NIL,0,"Copy",10,'C',edit_copy,3,0.0,EVENT_MENU);
#endif
    TUTORadd_menu(helpmenus,NIL,0,"Close",10,0,edit_help,1,0.0,EVENT_MENU);

    }

prochelp(helpH,event)   /* event processor for help window (help menus) */
Memh helpH;     /* help data */
struct tutorevent *event; /* event to process */
    {
    int wn; /* window index */
    short ii;
    int jj;
    long lineS, lineL, startSelect, lenSelect;
    TextVDat FAR *vp;
    HelpDat FAR *helpD;
    TViewP tvp;
    int wx,wy,wdx,wdy;
    TRect cr; /* saved clip region */
    TRect tr; /* title rectangle */
    struct tutorview FAR *viewp;
    Memh tempDoc;
    int fixSelect;  /* if TRUE, fix selection after the event */
    char tempS[20];
    struct tutorevent ev; /* internally generated event */

    if (!HelpVp)
        return 0;
    helpD = (HelpDat FAR *) GetPtr(helpH);
    wn = helpD->wid;
    
    fixSelect = FALSE;
    
    switch (event->type) {

    case EVENT_REDRAW:
        /* we could get rid of prochelpv by putting it here */

        TUTORset_view(helpD->helpV); /* set to background view */
        TUTORinq_abs_screen_size(&wx,&wy,&wdx,&wdy);
        TUTORinq_abs_clip_rect(&cr); /* save clip */
        TUTORclip_window(wn); /* clip to entire window */
        tr.left = tr.top = 0;
        tr.right = windowsP[wn].wxsize-1;
        tr.bottom = windowsP[wn].wysize-1;
        TUTORdraw_abs_solid_rect((TRect FAR *)&tr,PAT_BACKGROUND);      
        TUTORset_abs_clip_rect((TRect FAR *) &cr); /* restore clip */

        viewp = windowsP[wn].lastView;
        while (viewp) {
            TUTORset_view(viewp);
            (*viewp->vproc) (viewp->vh,event);
            viewp = viewp->prevView;
        }
        event->type = -1; /* we handled it already */
        break;

    case EVENT_FWD:
        viewp = windowsP[wn].firstView;
        while (viewp)
            {
            if ((viewp != helpD->bodyV && viewp != helpD->listV && viewp != helpD->indexV) || viewp == helpD->curActive)
                {  /* activate non-active text view */
                TUTORset_view(viewp);
                (*viewp->vproc) (viewp->vh,event);
                }
            viewp = viewp->nextView;
            }
        event->type = -1;
        break;

    case EVENT_WMKILL:
        event->type = -1;
        if (HelpVp) {
        	ReleasePtr(helpH);
        	KillPtr(helpD);
        	TUTORclose_view(HelpVp);
        	helpH = HNULL;
        }
        break;
        
    case EVENT_DESTROY:
    	if (HelpVp && (event->view == HelpVp)) {
    		TUTORset_view(HelpVp);
			TUTORdelete_menu(helpmenus,"Option",NEARNULL); 
			TUTORclose_panel(helpD->indexh);
			TUTORclose_panel(helpD->listH);
			TUTORclose_panel(helpD->bodyh);
			TUTORclose_doc(helpD->indexDocH);
			TUTORclose_doc(helpD->listDocH);
			TUTORclose_doc(helpD->bodyDocH);
			if (helpD->searchKeyTxtH)
				TUTORfree_handle(helpD->searchKeyTxtH);
			ReleasePtr(helpH);
			KillPtr(helpD);
			TUTORfree_handle(helpH);    
			HelpVp = FARNULL;
			TUTORclose_window(HelpWn);
			HelpWn = -1;
			helpH = theHelpH = HNULL;
			line_break = 0;
		}
		event->type = -1;
        break;
        
    case EVENT_RIGHTDOWN:
    case EVENT_LEFTDOWN:
    case EVENT_RIGHTUP:
    case EVENT_LEFTUP:
    case EVENT_DOWNMOVE:
        if (!event->view || (event->view != helpD->bodyV &&
                event->view != helpD->listV && event->view != helpD->indexV))
            {
            if (event->view && (event->type == EVENT_LEFTDOWN || event->type == EVENT_RIGHTDOWN))
                { /* if the click is in a scroll bar, the active text view may change,
                        make sure we track this change in helpD->curActive */
                if (event->view->vh == helpD->indexSh)
                    helpD->curActive = helpD->indexV;
                else if (event->view->vh == helpD->bodySh)
                    helpD->curActive = helpD->bodyV;
                else if (event->view->vh == helpD->listSh)
                    helpD->curActive = helpD->listV;
                }
            break; /* pass the non text clicks on to their views */
            }
        
        if (event->view != helpD->curActive)
            { /* change active view */
            ChangeActiveHelp(helpD,event->view);
            if ((event->type == EVENT_LEFTDOWN || event->type == EVENT_RIGHTDOWN) &&
                    event->view != helpD->bodyV)
                {   /* change of focus click to list or index */
                    /* diddle the textpanel so that it doesn't throw away this click,
                        even though it is the change of focus click */
                vp = (TextVDat FAR *) GetPtr(event->view->vh);
                vp->focusClick = FALSE;
                ReleasePtr(event->view->vh);
                KillPtr(vp);
                }
            }
        /* let click go to view */
        if (event->view != helpD->bodyV && (event->type == EVENT_RIGHTUP ||
                event->type == EVENT_LEFTUP))
            fixSelect = TRUE;

        break;

    case EVENT_KEY:
        event->type = -1; /* handle keys here */
        for (ii=0; ii<event->nkeys; ii++) {
        	if (event->keys[ii] == '\t') { /* change active view */
            	CycleActiveHelp(helpD,1);
            	fixSelect = TRUE; /* make sure selection is valid */
            	event->view = helpD->curActive; /* so FixSelection works right */
            } else if (event->keys[ii] == NEWLINE && helpD->curActive != helpD->bodyV) {
            	/* activate an item */
            	prochelpclick(helpD,helpD->curActive);
            	fixSelect = TRUE;
            	event->view = helpD->curActive; /* so FixSelection works right */
            } else KeyIndexList(helpD,event->keys[ii]);
		} /* for */
        break;

    case EVENT_HOT:
        if (*(event->eDataP) == 'l' || *(event->eDataP) == 'i')
            {
            prochelpclick(helpD,helpD->curActive); /* double-click on index or list */
            event->view = helpD->curActive; /* so fixSelect works */
            }
        else
            {
            /* read the number we were passed */
            strcpyf((char FAR *) tempS, (char FAR *) event->eDataP);
            sscanf(tempS,"%d",&jj);
            HotClick(helpD,jj);
            event->view = helpD->indexV; /* so we fix up index selection */
            }
        fixSelect = TRUE;
        TUTORfree_event_memory((struct tutorevent FAR *) event);
        event->type = -1; /* we don't want to pass on this event */
        break;
    
    case EVENT_FKEY:
        if (event->value == KBACKTAB)
            {
            event->type = -1; /* handle it here */
            CycleActiveHelp(helpD,-1);
            fixSelect = TRUE;
            event->view = helpD->curActive; /* so FixSelection works right */
            break;
            }
        
        if (event->view == helpD->listV || event->view == helpD->indexV)
            {
            fixSelect = TRUE;
            if (event->value == KUP || event->value == KDOWN)
                event->value++; /* extend selection so that FixSelection does what
                                    we want */
            }
        
        if (event->value != KCOPY)
            break;
        
        /* special handling for copy */
        /* this is just like tview copy, but we need to put a default paragraph
            layout around all the copied text... */
        vp = (TextVDat FAR *) GetPtr(helpD->bodyh);
        TUTORinq_select_tview(vp->textv,&startSelect,&lenSelect);
        tempDoc = TUTORnew_doc(TRUE,TRUE);
        EditorDefaultStyles(tempDoc);
        TUTORchange_doc_doc(tempDoc,0L,0L,0L,0L,vp->textd,startSelect,lenSelect,&lineL,FALSE);
        ReleasePtr(helpD->bodyh);
        KillPtr(vp);
        TUTORstyle_doc(tempDoc,0L,lenSelect,PARASTYLE,PARADEFAULT,PARALMASK,NEARNULL);
        TUTORto_clip_doc(tempDoc,0L,lenSelect,FALSE,&lineL);
        TUTORclose_doc(tempDoc);
        event->type = -1; /* we handled this event */
        
        break;  
            
    case EVENT_MSG:
    case EVENT_MENU:
        switch (event->a1)
        {
        case edit_previndex: /* previous index */
            event->type = -1;
            if (helpD->curIndex == 0)
                break; /* no previous index for first index */
            if (event->a2 == 0)
                {
                ii = helpD->nCurEntries-1; /* last line */
                IndexClick(helpD,ii,0L,0L);
                }
            else
                IndexClick(helpD,-1,0L,0L); /* main index */
            fixSelect = TRUE;
            break;

	case edit_copy: /* copy */
	    event->type = -1;
	    TUTORzero((char FAR *)&ev,(long)sizeof(struct tutorevent));
	    ev.window = event->window; /* set up event fields */
	    ev.timestamp = event->timestamp; /* time event received */
	    ev.type = EVENT_FKEY;
	    ev.value = KCOPY;
	    TUTORpush_event(&ev);
	    break;

        case edit_help: /* close window */
            event->type = -1;
      		if (event->a2 == 0) {
      			TUTORforward_window(wn);
      		} else if ((event->a2 == 1) && HelpVp) {
            	ReleasePtr(helpH);
            	KillPtr(helpD);
            	helpH = HNULL;
            	TUTORclose_view(HelpVp);
            }
            break;
        
        default:
            break;
        } /* end of menu switch */
    } /* end of event switch */

	if (helpH) {
    	ReleasePtr(helpH);
    }
    KillPtr(helpD);

    /* pass on events we didn't handle */
    if (event->type > 0 && event->view) {
        TUTORset_view(event->view);
        (*event->view->vproc)(event->view->vh,event);
    }

#ifdef SINGLECLICK
	if (helpH) {
    	helpD = (HelpDat FAR *) GetPtr(helpH);
    	if (event->type == EVENT_LEFTUP && (event->view == helpD->indexV ||
            event->view == helpD->listV))
        	{
        	prochelpclick(helpD,helpD->curActive); /* click on index or list */
        	event->view = helpD->curActive; /* so fixSelect works */
        	fixSelect = TRUE;
        	}
    	ReleasePtr(helpH);
    	KillPtr(helpD);
    } /* helpH if */
#endif

    if (fixSelect)
        FixHelpSelection(helpH,event->view);
    
    return 0;
    }

static CycleActiveHelp(helpD,nn)
register HelpDat FAR *helpD;
int nn;
    {
    struct tutorview FAR *tempV[3];
    int ii;
    
    tempV[0] = helpD->bodyV;
    tempV[1] = helpD->indexV;
    tempV[2] = helpD->listV;
    
    for(ii=0; ii<3; ii++)
        if (helpD->curActive == tempV[ii])
            break;
    
    ii = (3+ii+nn) % 3;
    
    ChangeActiveHelp(helpD,tempV[ii]);
    TUTORset_key_focus(helpD->wid,helpD->curActive,FALSE);
    }

static ChangeActiveHelp(helpD, newV)
register HelpDat FAR *helpD;
struct tutorview FAR *newV;
    {
    TUTORset_view(helpD->curActive);
    
    helpD->curActive = newV;
    TUTORset_view(helpD->curActive);
    }

static FixHelpSelection(helpH, eview)
Memh helpH;
struct tutorview FAR *eview;
    {
    HelpDat FAR *helpD;
    TextVDat FAR *vp;
    TViewP tvp;
    int yy;
    long lineS, lineL;  /* start & len of line we want selected */
    Memh theV;
    
    helpD = (HelpDat FAR *) GetPtr(helpH);
    if (eview == helpD->listV)
        theV = helpD->listH;
    else
        theV = helpD->indexh;
    vp = (TextVDat FAR *) GetPtr(theV);
    tvp = (TViewP) GetPtr(vp->textv);
    yy = tvp->selA.vv;
    ReleasePtr(vp->textv);
    KillPtr(tvp);
    TUTORinq_select_line(vp->textv,yy,&lineS,&lineL);
    SetSelectPanel(vp,lineS,lineL);
    
    ReleasePtr(theV);
    KillPtr(vp);
    ReleasePtr(helpH);
    KillPtr(helpD);
    }

prochelpv(viewH,event)  /* event processor help background view */
Memh viewH; /* should == helpH */
struct tutorevent *event; /* event to process */
    {
    HelpDat FAR *helpD;
    
    if ((event->type == EVENT_WMKILL) || (event->type == EVENT_DESTROY)) {
    	prochelp(viewH,event);
    	return(0);
    }
    
    if (event->type != EVENT_REDRAW)
        return 0; /* only type this view handles */

    /* reset clip & view rects */
    helpD = (HelpDat FAR *) GetPtr(viewH);
    TUTORclip_window(event->window);
    TUTORset_abs_view_rect(0,0,event->x,event->y);
    TUTORabs_move_to(0,BANNERV);
    TUTORabs_line_to(event->x,BANNERV); /* line across top */
    TUTORabs_move_to(event->x-LISTH,0);
    TUTORabs_line_to(event->x-LISTH,helpD->listVSize+BANNERV); /* line seperating index from list */
    TUTORabs_move_to(0,helpD->listVSize+BANNERV);
    TUTORabs_line_to(event->x,helpD->listVSize+BANNERV); /* line seperating top views from body */
#ifdef MAC
    ShowGrowIcon(helpD->helpV->window);
#endif
    helpD->indexMid = (event->x - LISTH)/2;
    helpD->listMid = (event->x + event->x - LISTH)/2;
    DrawHelpTitles(helpD);
    
    ReleasePtr(viewH);
    KillPtr(helpD);
    return 0;
    }

static prochelpclick(helpD,view)
HelpDat FAR *helpD;
struct tutorview FAR *view; /* view of event */
    {
    long lineS,lineL;
    int whichV,ii;
    Memh textv;
    TextVDat FAR *vp;
    TViewP tvp;
    int yy;
    
    if (view == helpD->indexV) {
        whichV = 2;
        textv = helpD->indexh;
    } else {
        whichV = 1;
        textv = helpD->listH;
    }
    vp = (TextVDat FAR *) GetPtr(textv);
    tvp = (TViewP) GetPtr(vp->textv);
    yy = tvp->anchor.vv; /* where our selection currently is */
    ReleasePtr(vp->textv);
    KillPtr(tvp);
    ii = TUTORinq_select_line(vp->textv,yy,&lineS,&lineL);
    ReleasePtr(textv);
    KillPtr(vp);

    if (whichV == 1)
        ListClick(helpD,ii,lineS,lineL);
    else if (whichV == 2)
        IndexClick(helpD,ii,lineS,lineL);
    
    return 0;
    }

static char *listTitle = "\010Keywords";

static DrawHelpTitles(helpD)
HelpDat FAR *helpD;
    {
    int tempLen;
    
    TUTORset_textfont(helpD->titleF);
    
    TUTORinq_abs_string_width((unsigned char FAR *) helpD->indexT+1,helpD->indexT[0],&tempLen);
    TUTORabs_move_to(helpD->indexMid-tempLen/2,BANNERV-5);
    TUTORdraw_text((unsigned char FAR *) helpD->indexT+1,helpD->indexT[0]);
    
    TUTORinq_abs_string_width((unsigned char FAR *) listTitle+1,listTitle[0],&tempLen);
    TUTORabs_move_to(helpD->listMid-tempLen/2,BANNERV-5);
    TUTORdraw_text((unsigned char FAR *) listTitle+1,listTitle[0]);
    
    return 0;
    }

static RedrawIndexTitle(helpD)
HelpDat FAR *helpD;
    {
    int tempLen;
    TRect newRect;
    struct tutorview FAR *cv;
    TRect tr;
    
    cv = TUTORinq_view();
    TUTORset_view(helpD->helpV); /* set to full window view */
    TUTORset_textfont(helpD->titleF);
    
    /* erase old title */
    TUTORset_rect(&tr,2,2,2*helpD->indexMid-2,BANNERV-2);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
    
    /* draw new title */
    TUTORinq_abs_string_width((unsigned char FAR *) helpD->indexT+1,helpD->indexT[0],&tempLen);
    TUTORabs_move_to(helpD->indexMid-tempLen/2,BANNERV-5);
    TUTORdraw_text((unsigned char FAR *) helpD->indexT+1,helpD->indexT[0]);
    
    TUTORset_view(cv); /* restore view */
    
    return 0;
    }

static HotClick(helpD,itemN) /* handle hot test "See Also" */
HelpDat FAR *helpD;
int itemN;
    {
    TextVDat FAR *vp;
    int bodyParent, ii;
    long tempL1, tempL2;
    TViewP tvp;

    if (itemN < 0 || itemN >= helpD->nEntries)
        return(0); /* bad # */
    
    if (helpD->entries[itemN].type == 0)
        { /* a new index entry */
        vp = (TextVDat FAR *) GetPtr(helpD->indexh);
        TUTORset_view(vp->view);
        helpD->nCurEntries = ReadPieceHelp(vp->textd,helpD->entries[itemN].textStart,helpD->entries[itemN].textLen,0);
        helpD->curIndex = itemN;
        RedrawIndexTitle(helpD);
        RestartPanel(vp,0L,TUTORget_len_doc(vp->textd),0L,0L);
        ReleasePtr(helpD->indexh);
        KillPtr(vp);
        helpD->boldIndexS = -1; /* no bolding showing now */
        }
    else
        { /* new leaf */
        
        /* reset the body */
        vp = (TextVDat FAR *) GetPtr(helpD->bodyh);
        TUTORset_view(vp->view);
        helpD->curBody = itemN;
        bodyParent = ReadPieceHelp(vp->textd,helpD->entries[itemN].textStart,
                                    helpD->entries[itemN].textLen,1);
        RestartPanel(vp,0L,TUTORget_len_doc(vp->textd),0L,0L);
        ReleasePtr(helpD->bodyh);
        KillPtr(vp);

        /* reset the index properly */
        vp = (TextVDat FAR *) GetPtr(helpD->indexh);
        helpD->nCurEntries = ReadPieceHelp(vp->textd,helpD->entries[bodyParent].textStart,helpD->entries[bodyParent].textLen,0);
        helpD->curIndex = bodyParent;
        TUTORset_view(vp->view);
        RedrawIndexTitle(helpD);
        RestartPanel(vp,0L,TUTORget_len_doc(vp->textd),0L,0L);
        /* and make sure the proper line is bold */
        for (ii=0; ii<helpD->nCurEntries; ii++)
            { /* find the right line */
            if (helpD->indexNums[ii] == itemN)
                break; /* found it */
            }
        tvp = (TViewP) GetPtr(vp->textv);
        tempL1 = _TUTORline_pos_tview(tvp,ii);
        tempL2 = tvp->ld[ii].nDraw;
        ReleasePtr(vp->textv);
        KillPtr(tvp);
        TUTORstyle_doc(vp->textd,tempL1,tempL2,FACESTYLE,1,-1,NEARNULL);
        RefreshPanel(vp,tempL1,tempL2,tempL1,0L,0L,tempL1,0L,TRUE,FALSE);
        helpD->boldIndexS = tempL1;
        helpD->boldIndexL = tempL2;
        
        ReleasePtr(helpD->indexh);
        KillPtr(vp);
        }
    }

static ListClick(helpD,itemN,lineS,lineL)   /* handle click in keyword list */
HelpDat FAR *helpD;
int itemN; /* # of item clicked */
long lineS, lineL;
    {
    short bodyParent;
    TextVDat FAR *vp;
    long tempL1, tempL2;
    long startChange, lenChange;
    int ii;
    TViewP tvp;
    
    itemN = helpD->commands[itemN]; /* entry number of text to display */
    
    vp = (TextVDat FAR *) GetPtr(helpD->listH);
    TUTORset_view(vp->view);
    
    /* do bolding of clicked command */
    if (helpD->boldListS >= 0)
        { /* undo old bolding */
        tempL1 = helpD->boldListS;
        tempL2 = helpD->boldListL;
        TUTORstyle_doc(vp->textd,tempL1,tempL2,FACESTYLE,0,-1,NEARNULL);
        RefreshPanel(vp,tempL1,tempL2,tempL1,0L,0L,-1L,0L,TRUE,FALSE);
        }
    TUTORstyle_doc(vp->textd,lineS,lineL,FACESTYLE,1,1,NEARNULL);
    RefreshPanel(vp,lineS,lineL,lineS,0L,0L,lineS,0L,TRUE,FALSE);
    ReleasePtr(helpD->listH);
    KillPtr(vp);
    helpD->boldListS = lineS;
    helpD->boldListL = lineL;
    
    TUTORwait_cursor();
    
    /* reset body */
    vp = (TextVDat FAR *) GetPtr(helpD->bodyh);
    TUTORset_view(vp->view);
    helpD->curBody = itemN;
    bodyParent = ReadPieceHelp(vp->textd,helpD->entries[itemN].textStart,
                                helpD->entries[itemN].textLen,1);
    RestartPanel(vp,0L,TUTORget_len_doc(vp->textd),0L,0L);
    ReleasePtr(helpD->bodyh);
    KillPtr(vp);
    
    /* reset index */
    vp = (TextVDat FAR *) GetPtr(helpD->indexh);
    helpD->nCurEntries = ReadPieceHelp(vp->textd,helpD->entries[bodyParent].textStart,helpD->entries[bodyParent].textLen,0);
    helpD->curIndex = bodyParent;
    TUTORset_view(vp->view);
    RedrawIndexTitle(helpD);
    RestartPanel(vp,0L,TUTORget_len_doc(vp->textd),0L,0L);
    /* and make sure the proper line is bold */
    for (ii=0; ii<helpD->nCurEntries; ii++)
        { /* find the right line */
        if (helpD->indexNums[ii] == itemN)
            break; /* found it */
        }

    if (ii < helpD->nCurEntries)
        { /* we found line, bold it */
        tvp = (TViewP) GetPtr(vp->textv);
        tempL1 = _TUTORline_pos_tview(tvp,ii);
        tempL2 = tvp->ld[ii].nDraw;
        ReleasePtr(vp->textv);
        KillPtr(tvp);
        TUTORstyle_doc(vp->textd,tempL1,tempL2,FACESTYLE,1,-1,NEARNULL);
        RefreshPanel(vp,tempL1,tempL2,tempL1,0L,0L,tempL1,0L,TRUE,FALSE);
        helpD->boldIndexS = tempL1;
        helpD->boldIndexL = tempL2;
        }
    else /* couldn't find parent! */
        helpD->boldIndexS = -1;
    
    ReleasePtr(helpD->indexh);
    KillPtr(vp);
    
    vp = (TextVDat FAR *) GetPtr(helpD->listH);
    TUTORset_view(vp->view); /* set to list view  */
    
    ReleasePtr(helpD->listH);
    KillPtr(vp);
    
    TUTORnormal_cursor();
    
    return 0;
    }

static IndexClick(helpD,itemN,lineS,lineL)  /* click on index */
HelpDat FAR *helpD;
int itemN; /* # of item clicked */
long lineS, lineL; /* boundaries of previous bolding */
    {
    TextVDat FAR *vp;
    long tempL1, tempL2;
    int tableind;   /* index in help table of new item */
    
    if (itemN >= 0)
        tableind = helpD->indexNums[itemN]; /* entry # of text to display */
    else
        tableind = 0; /* go directly to main index */
    
    if (helpD->entries[tableind].type == 1)
        { /* if new body, do bolding of clicked index item */
        vp = (TextVDat FAR *) GetPtr(helpD->indexh);
        TUTORset_view(vp->view);
        if (helpD->boldIndexS >= 0)
            { /* undo old bolding */
            tempL1 = helpD->boldIndexS;
            tempL2 = helpD->boldIndexL;
            TUTORstyle_doc(vp->textd,tempL1,tempL2,FACESTYLE,0,1,NEARNULL);
            RefreshPanel(vp,tempL1,tempL2,tempL1,0L,0L,-1L,0L,TRUE,FALSE);
            }
        TUTORstyle_doc(vp->textd,lineS,lineL,FACESTYLE,1,-1,NEARNULL);
        RefreshPanel(vp,lineS,lineL,lineS,0L,0L,lineS,0L,TRUE,FALSE);
        ReleasePtr(helpD->indexh);
        KillPtr(vp);
        helpD->boldIndexS = lineS;
        helpD->boldIndexL = lineL;
        }

    if (helpD->entries[tableind].type == 0)
        { /* to another index */
        vp = (TextVDat FAR *) GetPtr(helpD->indexh);
        TUTORset_view(vp->view);
        helpD->nCurEntries = ReadPieceHelp(vp->textd,helpD->entries[tableind].textStart,helpD->entries[tableind].textLen,0);
        helpD->curIndex = tableind;
        RedrawIndexTitle(helpD);
        RestartPanel(vp,0L,TUTORget_len_doc(vp->textd),0L,0L);
        ReleasePtr(helpD->indexh);
        KillPtr(vp);
        helpD->boldIndexS = -1; /* no bolding showing now */
        }
    else
        { /* show new body */
        vp = (TextVDat FAR *) GetPtr(helpD->bodyh);
        TUTORset_view(vp->view);
        ReadPieceHelp(vp->textd,helpD->entries[tableind].textStart,helpD->entries[tableind].textLen,1);
        helpD->curBody = tableind;
        RestartPanel(vp,0L,TUTORget_len_doc(vp->textd),0L,0L);
        ReleasePtr(helpD->bodyh);
        KillPtr(vp);
        }
    vp = (TextVDat FAR *) GetPtr(helpD->indexh);
    TUTORset_view(vp->view); /* set to index view */
    
    ReleasePtr(helpD->indexh);
    KillPtr(vp);
    TUTORnormal_cursor();

    return 0;
    }

/* ******************************************************************* */

static int KeyIndexList(helpD,key) /* position keyword list by key */
HelpDat FAR *helpD; /* help info */
int key; /* key value */

{	long searchPos; /* current search position in document */
	char FAR *searchTxtP; /* pointer to document text */
	long startPos; /* start of current line */
	char keyWord[32]; /* current keyword */
	long docLen; /* length of keyword document */
	int kii; /* index in keyword */
	int tii; /* index in target chars */
	int curChar;
	long lineL; /* length of current keyword line */
	TextVDat FAR *vp; /* pointer to text view */
	long curTime;
	int curFind; /* number chars matched in current find */
	
	curTime = TUTORinq_msec_clock();
	if ((curTime-helpD->searchKeyTime) < 1500L) {
		if (helpD->nSearchKeys >= 5)
			return; /* full, nothing to do */
	} else {
		helpD->nSearchKeys = helpD->nSearchFind = helpD->searchKeyPos = 0; /* fresh start */
	}
	if ((key >= 'A') && (key <= 'Z'))
		key = key-'A'+'a'; /* always lower case */
	helpD->searchKeys[helpD->nSearchKeys++] = key;
	docLen = TUTORget_len_doc(helpD->listDocH);
	searchPos = helpD->searchKeyPos;

	if (!helpD->searchKeyTxtH) {
	    helpD->searchKeyTxtH = TUTORhandle("ListTxt",(docLen+2),TRUE);
		if (!helpD->searchKeyTxtH)
			return; /* no memory, can'd do it */
		TUTORpurge_info(helpD->searchKeyTxtH,M_WMRM,FARNULL,0);
		AllowHandlePurge(helpD->searchKeyTxtH);
		searchTxtP = GetPtr(helpD->searchKeyTxtH); /* pointer to txt */
		/* get text */
		TUTORget_string_doc(helpD->listDocH,0L,docLen,(unsigned char  FAR *)searchTxtP);		
	} else
		searchTxtP = GetPtr(helpD->searchKeyTxtH); /* pointer to txt */
		
	while (searchPos < docLen) {
		startPos = searchPos; /* start of line */
		keyWord[0] = 0;
		for(kii=0; kii<30; kii++) { /* extract next keyword */
			if (searchPos >= docLen)
				break; /* reached end of keyword list */
			keyWord[kii] = curChar = *(searchTxtP+searchPos++);
			if ((curChar == 0x0d) || (curChar == 0x0a)){
				keyWord[kii] =0; /* terminate */
				break; /* end of word */
			}
		} /* kii for */
		curFind = 0;
		for(tii=0; tii<helpD->nSearchKeys; tii++) {
			if ((keyWord[tii] >= 'A') && (keyWord[tii] <= 'Z'))
				keyWord[tii] = keyWord[tii]-'A'+'a';
			if (helpD->searchKeys[tii] == keyWord[tii])
				curFind++; /* number chars matched so far */
			else break; /* exit for */
		} /* for */
		if (curFind > helpD->nSearchFind) { /* found keyword starting with our letter(s) */
			lineL = strlen(keyWord); /* length of line */
			vp = (TextVDat FAR *)GetPtr(helpD->listH);
			TUTORset_view(vp->view);
			SetSelectPanel(vp,startPos,0L);
			ReleasePtr(helpD->listH);
			KillPtr(vp);
			helpD->searchKeyTime = TUTORinq_msec_clock();
			helpD->nSearchFind = curFind;
			helpD->searchKeyPos = searchPos;
			break; /* exit while */
		} /* curFind if */
	} /* while */
	
	ReleasePtr(helpD->searchKeyTxtH);
	
} /* KeyIndexList */

/* ******************************************************************* */

#ifdef MAC
#ifndef THINKC5
#ifndef WERKS
#include <WindowMgr.h>
#endif
#endif

static ShowGrowIcon(wn)
int wn;
    {
    register int left,top;
    Rect rr;
    WindowPtr curPort;
    
    GetPort(&curPort);
    left = curPort->portRect.right-15;
    top = curPort->portRect.bottom-15;
    
    SetRect(&rr,left,top,left+16,top+16);
    if (((WindowPeek) curPort)->hilited)
        {
        FrameRect(&rr);
        SetRect(&rr,left+3,top+3,left+10,top+10);
        FrameRect(&rr);
        TUTORabs_move_to(left+10,top+5);
        TUTORabs_line_to(left+13,top+5);
        TUTORabs_line_to(left+13,top+13);
        TUTORabs_line_to(left+5,top+13);
        TUTORabs_line_to(left+5,top+10);
        }
    else
        EraseRect(&rr);
    }
#endif

static ReadHelpHeader()
    {
    int infile;
    short ii, index;
    HelpDat FAR *helpD;

    helpD = (HelpDat FAR *) GetPtr(theHelpH);
    infile = TUTORopen(&helpD->helpFile,TRUE,FALSE,FALSE);
    if (!infile)
        {
        ReleasePtr(theHelpH);
        KillPtr(helpD);
        return(FALSE);
        }

    /* skip copyright, establish line break character */

	TUTORreset_file(infile,0);
    while (!line_break) {
        ii = TUTORget_char(infile,FALSE);
        if ((ii == 0x0d) || (ii == 0x0a)) {
        if (ii == 0x0d) {
            ii = TUTORget_char(infile,FALSE);
            if (ii != 0x0a) { /* terminates with 0x0d */
            TUTORungetc(infile,ii);
            ii = 0x0d; /* restore ii */
            }
        }
        line_break = ii; /* set break character */
        break;
        } /* ii if */
    } /* while */
        
    /* read entries table */
    helpD->nEntries = hlp_read_number(infile);
#ifdef CTDEBUG
    if (helpD->nEntries > MAXENTRIES)
        TUTORdump("Too many help entries");
#endif
    for (ii=0; ii<helpD->nEntries; ii++)
        {
        index = hlp_read_number(infile);
        helpD->entries[index].textStart = hlp_read_number(infile);
        helpD->entries[index].textLen = hlp_read_number(infile);
        helpD->entries[index].type = hlp_read_number(infile);
        }

    /* read commands table */
    helpD->nCommands = hlp_read_number(infile);
#ifdef CTDEBUG
    if (helpD->nCommands > MAXCOMMANDS)
        TUTORdump("Too many help commands");
#endif
    helpD->cStart = hlp_read_number(infile);
    helpD->cLen = hlp_read_number(infile);
    for (ii=0; ii<helpD->nCommands; ii++)
        helpD->commands[ii] = hlp_read_number(infile);

    TUTORclose(infile);
    ReleasePtr(theHelpH);
    KillPtr(helpD);
    return(TRUE);
    }

static ReadPieceHelp(doc,start,len,type)
Memh doc;   /* ktxt doc to reset */
long start, len; /* where text starts, & # of chars in text */
int type;   /* 0: index, 1: body, 2: commands */
/* returns 1st # read after text */
    {
    int infile;
    short ii;
    int retVal;
    char tempS[50];
    HelpDat FAR *helpD;
    unsigned char cc;
    
    helpD = (HelpDat FAR *) GetPtr(theHelpH);
    infile = TUTORopen(&helpD->helpFile,TRUE,FALSE,FALSE);

    TUTORclear_doc(doc);
    EditorDefaultStyles(doc);
    
    TUTORseek(infile,start);
    
    TUTORfread_doc(doc,len,5,infile);
    
    if (type == 0 && start != helpD->entries[0].textStart)
        { /* add "Previous Index" entry to index */
        TUTORinsert_string_doc(doc,TUTORget_len_doc(doc),
                (unsigned char FAR *) "Previous Index",14L);
        }
    
    /* hack to make sure entire piece is visible */
    TUTORstyle_doc(doc,0L,TUTORget_len_doc(doc),
                    PARASTYLE,0,VISMASK,NEARNULL);

    /* read the rest of the info for the entry, which follows text */
    if (type == 0)
        { /* index */
        retVal = hlp_read_number(infile);

#ifdef CTDEBUG
        if (retVal > MAXSUBS)
	    TUTORdump("Too many help subindices");
#endif
        for (ii=0; ii<retVal; ii++)
            helpD->indexNums[ii] = hlp_read_number(infile);
        while (line_break != (ii = TUTORget_char(infile,FALSE))) ; /* skip rest of line */
        helpD->indexT[0] = 0;
        while (helpD->indexT[0] < TITLELEN && (ii = TUTORget_char(infile,FALSE)) != line_break)
            {
            helpD->indexT[0]++;
            helpD->indexT[helpD->indexT[0]] = ii;
            }
        }
    else if (type == 1)
        { /* body */
        /* we need to skip trailing styles */
        while (TRUE)
            {
            TUTORread_char(&cc,infile);
            if (cc == '@')
                { /* style, skip 7 more chars */
                TUTORread((char FAR *)tempS,1,7L,infile);
                }
            else
                { /* all done */
                TUTORungetc(infile,cc); /* restore last char */
                break;
                }
            }
        retVal = hlp_read_number(infile);
        }
    else
        retVal = 0; /* no numbers to read */
    
    ReleasePtr(theHelpH);
    KillPtr(helpD);
    TUTORclose(infile);
    
#ifndef SINGLECLICK
    if (type == 0)
        TUTORstyle_hot_doc(doc,0L,TUTORget_len_doc(doc),(unsigned char FAR *) "index",5L);
    else if (type == 2)
        TUTORstyle_hot_doc(doc,0L,TUTORget_len_doc(doc),(unsigned char FAR *) "list",4L);
#endif

    return(retVal);
    }

/* ******************************************************************* */

static long hlp_read_number(findx) /* read number from file */
int findx;

{   char nstr[20]; /* numeric string */
    int nii; /* index in numeric string */
    unsigned char cc; /* current character code */
    long value; /* numeric value */
    
    nii = 0; /* no characters yet */
    value = 0;
    do {
        TUTORread_char(&cc,findx); /* read next character from file */
        if ((cc == ' ') || (cc == '\t') || 
            (cc == 0x0d) || (cc == 0x0a)) {
            if (nii) {
                TUTORungetc(findx,cc); /* put this char back */
                cc = 0; /* terminating space */
            }
        } else if ((cc >= '0') && (cc <= '9')) {
            nstr[nii++] = cc; /* add next numeric character */
        } else {
            TUTORungetc(findx,cc); /* put this char back */
            cc = 0; /* terminate if unexpected character */ 
        }
        if (nii >= 18)
            cc = 0; /* terminate if string too long */  
    } while (cc);
    nstr[nii++] = 0; /* terminate string */
    sscanf(nstr,"%ld",&value); /* convert ascii->numeric */
    return(value);
    
} /* hlp_read_number */

/* ******************************************************************* */
