
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Definitions for general globals
*/

#ifndef _tglobalsh
#define _tglobalsh

#define EDITWINDOWLIMIT 8
#define WINDOWLIMIT (6+EDITWINDOWLIMIT)
#define TIMINGLIMIT 20

/* #define DOPSCRIPT -- if this is defined lots of things will break */

#ifndef _tutorh
#include "tutor.h"
#endif

#ifndef setjmp_d
#include "setjmp.h"
#define setjmp_d
#endif

/* flags for cerror (most of which are in ctutor.h) */

#define SPECIFICERR -1 /* specific err with specific message */

struct unitdat
    {
    unsigned char name[NAMEL+1];
    short unitnum;
    };

struct unitnames { /* structure for unitnames */
    struct unitdat udata[1];
};

extern Coord coordZero, coordOne; /* frequently used constants */
extern double Infinite; /* 1/0 */
extern double Indefinite; /* 0/0 */
extern Memh filesopen; /* info about open files */
extern unsigned filesmalloc; /* number of items malloc-ed */
extern int ctedit;  /* TRUE if editor present */
extern int ctcomp;  /* TRUE if compiler present */
extern struct tutorwindow FAR *windowsP; /* table of windows */
extern Memh fontsH; /* table of active fonts */
extern int ExactMatchFont; /* TRUE if font matched exactly */
extern int isx11;  /* TRUE if running on X11 */
extern int nosourcelayout; /* TRUE if source not displayed */
extern int binaryOnly; /* TRUE if executor with binary file only */
extern int logevents; /* TRUE if logging events */
extern int playevents; /* TRUE if re-playing logged events */
extern int CompileAndExit; /* TRUE if should compile program and exit */
#ifdef DOPSCRIPT
extern char pscript;    /* TRUE if generating PostScript */
extern char *PSbuff;  /* buffer for postscript output */
extern char PostscriptFlag; /* TRUE if -p option active */
#endif

extern int pictur_id; /* unique id for picture */

extern char NewFontSize; /* TRUE if font size means newline.y, else top of Y to bottom of y */
extern int nevents; /* number events currently queued */

extern short modalW;    /* index of window that has modal state, or -1 if we are not in a modal state */

extern int ctmouse; /* TRUE if mouse present */
extern int ctexec;  /* TRUE if executor present */

/* scratch FAR variables: (tempS & tempR needed by executor) */
extern char FAR *tempFarS;
extern long FAR *tempFarL;
extern int FAR *tempFari;
extern unsigned int FAR *tempFarUi;
extern TRect FAR *tempFarR;

extern short textFont0; /* index to default textFONT */
extern short cursorFont0, cursorChar0; /* default cursor */
extern short patternFont0, patternChar0; /* default fill */
extern short iconFont0; /* default icon font */

extern Memh firstSetH; /* handle on first define set in chain */
extern Memh lastSetH; /* handle on last define set in chain */
extern Memh oldSetH; /* handle on old chain of define sets */
extern Memh globalSetH; /* handle on current global define set  */
extern Memh userSetH; /* handle on current local define set */
extern Memh localSetH; /* handle on local define set */
extern Memh wkSetH; /* handle on define set being compiled */
extern struct defset FAR *wkSetP; /* pointer to currently compiling */
extern Memh oldDescH; /* handle on previous array descriptors */

extern long gvaraddr; /* location of end of global vars */
extern int gvarzero;    /* TRUE if global variables must be zeroed */
extern struct sourcefile FAR *sourcetable;  /* table of source file names/pointers */
extern int ExecWn;  /* executor window number */
extern struct tutorview FAR *ExecVp;    /* executor main view pointer */
extern int CurEditWi; /* index of currently selected editor */
extern int EditWn[];    /* edit window number */
extern struct tutorview FAR *EditVp[];  /* edit main view pointer */
extern int timeflag; /* TRUE if timing in effect (timed pause or EnqueueEvent */
extern int tfilerr; /* >0 if error in file operation */
extern int ctutv;       /* cmututor version number */
extern Memh xtH;
extern struct exprt FAR *xtP; /* ptr to operators/operands description table */
extern unsigned char FAR *cmd_err_tab; /* TRUE if command can generate exec err */
extern int userExp; /*  0 = regular run-time author expression */
                    /*  1 = -compute- */
                    /* -1 = compile-time phase of -compute- */

extern FileRef FAR *sourceDirP;   /* directory where source file (either main .t file, or main binary) is found */
extern FileRef FAR *ctDirP;   /* directory where cT files can be found */
extern FileRef FAR *currentDirP;  /* current working directory */

extern Memh descH; /* array/argument descriptors */
extern char FAR *descP; /* pointer to array/argument descriptors */
extern Memh textpool;   /* styled text and strings */
extern int allcompiled; /* true if program completely compiled */
extern int compunit;  /* unit now being compiled */
extern long srcPos; /* position in current source document */
extern int seekcmd; /* last command found by Seekunit */
extern Memh lastBufferDoc;
extern long nextBufferPos;
/* runflag is current run state, rerunflag is how we started running */
/* waitflag is current wait state (or equal to runflag if running) */
extern char runflag, rerunflag, waitflag;
extern Memh unittabH; /* handle on unit table */
extern struct unitinfo FAR *unittab; /* info and binaries for the units */
extern int nunits;  /* current number of units */
extern Memh cmpH; /* handle on unit compilation buffer */
extern char cmpLocked; /* flag indicating whether cmpH is believed locked */
extern Memh pcodeh; /* handle on pcodes for current unit */
extern unsigned char FAR *pcodep; /* pointer to pcodes */
extern jmp_buf uenv; /* expression/compute error longjmp */

extern unsigned char FAR *cbody;    /* pointer to base of expression */
extern unsigned char FAR *bin;  /* byte address in binary document */
extern unsigned char FAR *cbase;    /* pointer to first byte of expression */
extern unsigned char FAR *cmpbuf;   /* pointer to unit compilation buffer */
extern unsigned int cmpl;   /* position within compilation buffer */
extern int seedrand; /* seed for random number generator */
extern Memh refhead; /* head of (marker) document-referenced chain */
extern int refnum; /* number entries in document-referenced chain */

/* function definitions from execdefs */
#ifndef SYMANTECH
extern double lcitof();  /* integer to float */
extern long lcftoi();  /* float to rounded integer */
extern double lcfcoord();  /* x/y co-ordinate float to float, rounding to nearest integer */
extern double evald(), evalduser();
extern double evalr();  /* evaluate and round to integer version of double */
extern Coord evalc(); /* evaluate and convert to coord type */
extern int ViewInput(), ViewUpdate(), Halt();
extern int texec(), Wait();
extern struct sline *pm(); /* pattern matching in -answer- */
extern long unstacks();
#endif

extern long maxSwapLen; /* max size of swap file */
extern char useXMS; /* use XMS memory on PC */
extern char useEMS; /* use EMS memory on PC */
extern char pcoldcolor; /* use old color defaults on PC */
extern char color_pref; /* TRUE if color preferences in effect */

extern int SysFontHeight; /* height of default (system) font */
extern int SysFontWidth; /* width of default (system) font */
extern int SysPal; /* size of hardware display palette (0 = TrueColor/no color) */
extern int SysColors; /* number colors set up by system */

#endif  /* _tglobalsh */
