/*
A component of the cT (TM) programming environment.
(c) Copyright 1997 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "baseenv.h"
#include "kdefs.h"
#include "editmenu.h"
#include "tutor.h"
#include "editor.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "edglobal.h"
#include "txt.h"
#include "txtv.h"
#include "ct_ctype.h"

/* *************************************************************** */

#ifdef ctproto
int  TUTORclose_doc(unsigned int  doc);
int  TUTORset_event_mask(int  eventc,int  value);
int  TUTORset_menubar(unsigned int  barh,struct  tutorview FAR *newMenuView);
unsigned int  TUTORinit_menubar(int  nItems);
int  TUTORadd_menu(unsigned int  barh,char  *card,int  cp,char  *item,int  ip,int  keyBind,int  type,int  unit,double  unitArg,int  eType);
int  RestartPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  selStart,long  selLen);
extern  int TUTORpost_event(struct tutorevent *event);
int  TUTORforward_window(int  wix);
extern int TUTORclose_window(int wid);
int  TUTORclose_view(struct  tutorview FAR *vp);
int  TUTORclose_panel(unsigned int  theV);
extern  int TUTORset_abs_clip_rect(TRect FAR *cr);
extern int TUTORarrow_cursor(int isTemp);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
extern int TUTORclip_window(int wix);
int  TUTORinq_abs_clip_rect(struct  _trect *cr);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,int ebsref,
 struct  _trect *theR,int  relInfo,int  mintw,int  wrap,unsigned int  doc,long  pos,
 long  len,int  wantV,int  wantH,int  (*KeyF)(),int  ro,int  corner,int  erase,
 int  frame,int tabsz,int lm,int rm,int inhss,int type);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
int  EditorDefaultStyles(unsigned int  doc);
int  TUTORclear_doc(unsigned int  doc);
extern int TUTORalert(int wn, char *msg);
extern  struct tutorview FAR *TUTORinit_view(int sW,unsigned int vDat,int (*vProc)());
int procTrace(Memh editH, struct tutorevent *cev);
int  TUTORcreate_window(int  top,int  left,int  xSize,int  ySize,int  type);
unsigned int  TUTORnew_doc(int  string,int  honorP);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORdealloc(char  FAR *ptr);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
extern TUTORfree_region(long regid);
long TUTORabs_save_region(int x1, int y1, int x2, int y2);
extern char *TUTORget_user(void);
int  TUTORset_comb_rule(int  rule);
extern int fuzzyeq(double x,double y);
extern double lcitof(long lv);
extern double floor(double dv);
extern int TUTOR68030_cache(void);
extern long qroundp(double dv);
extern long lcftoi(double dv);
int  lclocy(long  q);
int  lclocx(long  q);
int  killptr(char  FAR * FAR *ptr);
int CTpalette(int wn, Memh newPal,int flag);
extern int SetupCTDir(void);
extern FileRef *TUTORct_path(void);
extern int ReleasePtr(Memh mm);
extern int setexectitle(char *sn);
extern int TraceMsg(char FAR *s);
extern int TUTORrescale_message(void);
extern int TUTORshowt(double value,int nBefore,int nAfter, int showperiod, char *ss);
extern int TUTORshow(int type,double value, int sigfig, char *ss);
extern int SetFlushState(int arg);
extern int flush(void);
extern int signgam(void);
extern int TUTORzero(char SHUGE *zp, long len);
extern  int TUTORset_file_type(FileRef FAR *fName,int findx,int type,int xx,int yy);
extern int CTset_foreground_color(int color);
extern int CTset_background_color(int color);
extern char *strf2n(char FAR *x);
extern char *strnf2n(char FAR *x,int n);
extern char *strcpyf(char FAR *a,char FAR *b);
extern char *strncpyf(char FAR *a,char FAR *b,int n);
extern char *strcatf(char FAR *a,char FAR *b);
extern int strcmpf(char FAR *a,char FAR *b);
extern int strncmpf(char FAR *a,char FAR *b,int n);
extern int strlenf(char FAR *ss);
extern  int TUTORunset_clip_rectangle(void );
extern int TUTORdump(char *ss);
extern int TUTORset_textfont(int jj);
extern  int TUTORset_view(struct tutorview FAR *vp);
extern  struct tutorview FAR *TUTORinq_view(void );
extern double log(double xx);
extern char FAR *GetPtr(Memh mm);
extern double lcfcoord(double dv);  /* float to float, rounding to nearest integer */
#endif /* ctproto */

static Memh TraceDocH = HNULL; /* trace window document */ 
static Memh TracePanelH = HNULL; /* trace window panel */
static int TraceCount = 0; /* number messages */
static int LastCount = 0; /* count at last RedrawPanel */

struct tutorview FAR *TraceVp; /* trace window view */  
          
/* *************************************************************** */

TraceMsg(s)
char FAR *s; /* display trace message */   
/* no message flushes any not-yet-displayed messages */
	
{	int wix;
	struct tutorview FAR *cv; /* current view */
	int info; /* panel alignment */
	TextVDat FAR *vp; /* text panel info */
	long len; /* message length */    
	int needRefresh; /* TRUE if need to refresh text panel */

	needRefresh = FALSE;
	len = 0;
	if (s) {    
		TraceCount++;
		len = strlenf(s); /* length of string to insert */
	} else {
		needRefresh = TRUE; /* just redraw panel */ 
	}

	cv = TUTORinq_view();	/* get current view */
	
	/* initialize document */
	
	if (!TraceDocH) {
		TraceDocH = TUTORnew_doc(TRUE,TRUE); /* set up document */
		if (!TraceDocH) goto nomem;
		EditorDefaultStyles(TraceDocH);
	}
	
	/* initialize window, view and text panel if not already */
	/* set up */
	
	if (TraceWn < 0) {
    	TraceWn = TUTORcreate_window(-1,-1,0,0,TRACEW);
    	windowsP[TraceWn].wproc = (int(*)())(procTrace); 	
    }
    if (TraceWn < 0) goto nomem;
    
    if (!TraceVp) {
        TraceVp = TUTORinit_view(TraceWn,0,procTrace);
    	if (!TraceVp) goto nomem;   
    	TUTORset_view(TraceVp);
    	TUTORset_event_mask(EVENT_LEFTDOWN,TRUE);
    	TUTORset_event_mask(EVENT_LEFTUP,TRUE);
    	TUTORset_event_mask(EVENT_RIGHTDOWN,TRUE);
    	TUTORset_event_mask(EVENT_RIGHTUP,TRUE);
    	TUTORset_event_mask(EVENT_DOWNMOVE,TRUE);
    	TUTORset_event_mask(EVENT_MENU,TRUE);
    	TUTORset_event_mask(EVENT_MSG,TRUE);
    	TUTORset_event_mask(EVENT_FWD,TRUE);
    	TUTORset_event_mask(EVENT_VFOCUS,TRUE);
    	TUTORset_event_mask(EVENT_WFOCUS,TRUE);
    	TUTORset_event_mask(EVENT_SCROLL,TRUE);     
    	needRefresh = TRUE;
    }
 
    if (!TracePanelH) {
    	info = LEFTSTICK | RIGHTSTICK | TOPSTICK | BOTTOMSTICK;
    	TracePanelH = MakeTextPanel(TraceWn,(long)TraceDocH,0,0,NEARNULL,info,
            100,TRUE,TraceDocH,0L, -1L,TRUE,FALSE,FARNULL,TRUE,FALSE,FALSE,FALSE,
            -1,-1,-1,FALSE,6);
        if (!TracePanelH) goto nomem;     
        TUTORarrow_cursor(TRUE);
    }
    	           
 	/* add message to trace document */
 	
    TUTORset_view(TraceVp);     
    if (len)
    	InsertString(TraceDocH,0L,(char FAR *)s,len);

    /* draw text panel */
          
	if (needRefresh && (TraceCount != LastCount)) {  
		LastCount = TraceCount;
		len = TUTORget_len_doc(TraceDocH);
		vp = (TextVDat FAR *)GetPtr(TracePanelH);
		RestartPanel(vp,0L,len,0L,0L);
		ReleasePtr(TracePanelH);      
	}
	TUTORset_view(cv); /* restore view */
	return;
	
nomem:
	if (EditWn[0] >= 0) wix = EditWn[0];
	else wix = ExecWn;
	TUTORalert(wix,"No memory for trace message");
	if (s)
		TUTORalert(wix,strf2n(s));
	return;
	
} /* TraceMsg */                             
	
/* *************************************************************** */

procTrace(docH,event)   /* event processor for trace window */
Memh docH;
struct tutorevent *event; /* event to process */

{   TRect clipR; /* saved clip rectangle */
	TRect eraseR; /* rectangle to erase */
	struct tutorview FAR *viewp; 
	TextVDat FAR *vp; /* text panel info */
	Memh mpH; 

    if (TraceWn < 0) return(0); /* nothing to do */

    /* process message window events */

    switch (event->type) {

    case EVENT_REDRAW:
    	TUTORset_view(TraceVp);
        TUTORinq_abs_clip_rect(&clipR); /* save clip */
		TUTORclip_window(TraceWn); /* clip to entire window */
		eraseR.top = eraseR.left = 0;
		eraseR.bottom = windowsP[TraceWn].wysize;
		eraseR.right = windowsP[TraceWn].wxsize;
        TUTORdraw_abs_solid_rect((TRect FAR *)&eraseR,PAT_BACKGROUND);
        TUTORset_abs_clip_rect((TRect FAR *) &clipR); /* restore clip */
        viewp = windowsP[TraceWn].firstView; /* update everybody else */
        while (viewp) {
        	if (viewp != TraceVp) {
        		TUTORset_view(viewp);
        		(*viewp->vproc) (viewp->vh,event);
        	}
        	viewp = viewp->nextView;
        } /* while */
        event->type = -1;
        break;

    case EVENT_WMKILL: /* window closed by window manager */    
    	event->type = -1;
    	if (TraceVp)
    		TUTORclose_view(TraceVp); 
    	break;
    	 
    case EVENT_DESTROY: /* view destroyed */
    	mpH = TracePanelH;
    	TracePanelH = HNULL; /* recursive call won't hurt */
    	if (mpH)
			TUTORclose_panel(mpH);
		TraceVp = FARNULL; /* recursive call won't hurt */
		if (TraceWn >= 0)
        	TUTORclose_window(TraceWn);
        TraceWn = -1;
        if (TraceDocH)
        	TUTORclose_doc(TraceDocH);
        TraceDocH = HNULL;
        event->type = -1;
        break;
    	
    case EVENT_LEFTDOWN:
    case EVENT_RIGHTDOWN:
    case EVENT_LEFTUP:
    case EVENT_RIGHTUP:
    case EVENT_DOWNMOVE:
    	vp = (TextVDat FAR *)GetPtr(TracePanelH);
    	ReleasePtr(TracePanelH);
    	break;
        
    } /* event switch */
    
    /* pass event on to other views if still valid */
    
    if ((TraceWn >= 0) && TracePanelH && TraceVp && (event->type > 0)) {
        viewp = windowsP[TraceWn].firstView; /* update everybody else */
        while (viewp) {
        	if (viewp != TraceVp) {
        		TUTORset_view(viewp);
        		(*viewp->vproc) (viewp->vh,event);
        	}
        	viewp = viewp->nextView;
        } /* while */
    }
    return(0);
    
} /* procTrace */

/* *************************************************************** */
