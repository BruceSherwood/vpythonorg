
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "baseenv.h"
#include "txt.h"
#include "txtv.h"
#include "kdefs.h"

#ifdef ctproto
long  _TUTORscrollv_tview(unsigned int  theV,int  stype,long  arg);
extern int  HiliteLine(struct  _viewp FAR *tvp,int  l1,int  l2);
int  _TUTORscrollh_tview(unsigned int  theV,int  offset);
int  TUTORscroll_middleV(unsigned int  theV,long  pos);
int  TUTORwhere_pix_tview(unsigned int  theV,struct  _ps FAR *posp);
int  _TUTORpos2_line_tview(struct  _viewp FAR *tvp,long  pos);
char  FAR *GetPtr(unsigned int  mm);
int  _TUTORlayout_lines0(unsigned int  theV,long  pos,int  height,int  redo);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  _TUTORhilite_select(unsigned int  theV,int  onoff);
int  _TUTORdraw_tview(struct  _viewp FAR *tvp,int  startL,int  endL);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
int  _TUTORnew_bottom_tview(unsigned int  theV,struct  _viewp FAR *tvp);
long  _TUTORline_pos_tview(struct  _viewp FAR *tvp,int  lineN);
int  _TUTORdraw_caret_tview(struct  _viewp FAR *tvp,int  mess);
int  TUTORscroll_rect(struct  _trect *r,int  dh,int  dv);
int  _TUTORdraw_selr_tview(struct  _viewp FAR *tvp,struct  _ps FAR *p1,struct  _ps FAR *p2);
int  TUTORset_abs_clip_rect(struct  _trect FAR *cr);
int  _TUTORline2_vv_tview(struct  _viewp FAR *tvp,int  nn);
int  TUTORinq_abs_clip_rect(struct  _trect *cr);
int  TUTORcompress_darray(unsigned int  da,int  offset);
int  _TUTORshrink_layout_tview(struct  _viewp FAR *tvp,int  newTop,int  newBot);
#endif /* ctproto */

extern long _TUTORline_pos_tview();
extern char FAR *GetPtr();

long _TUTORscrollv_tview(theV,stype,arg)	/* do vertical scroll */
Memh theV;	/* tview */
int stype;	/* type of scroll (one of tokens in kdefs.h) */
long arg;	/* argument for scroll type */
/* returns position at beginning of new top line */
	{
	int viewHeight;	/* vertical size of view */
	int newHeight;	/* height of lines after scrolling */
	int oldcState;	/* to save & restore caret state */
	register int ii;
	int doLayout;	/* TRUE if we need to layout lines */
	REGISTER TViewP tvp;	/* pointer to tview */
	TRect tr;	/* rectangle around screen image to be shifted, or erased */
	long tempL;
	int oldBottom;	/* bottom line, before scrolling */
	int newTopLine;	/* index of line that will become the new top line */
	long retVal;
	int delV;	/* # of pixels we will shift screen image */
	int laidOut;	/* TRUE if we laid out lines */
	int hiliteFlag;	/* TRUE if we had selection hilit, FALSE if just caret */
	int shrinkFlag; /* 1: shrink off bottom, -1: shrink off top,
						0:shrink from both ends */
	int newTop, newBot; /* new top & bottom lines of layout when we shrink layout */
	register LineLayout FAR *lp;	/* pointer to line layouts */
	
	shrinkFlag = 0;
	tvp = (TViewP) GetPtr(theV);
	if (!tvp->scrollV)
		{ /* can't scroll vertically */
		stype = -99; /* invalid */
		}
	
	viewHeight = tvp->viewRect.bottom - tvp->viewRect.top + 1;
	switch (stype)
		{
		case sbToPos: /* scroll to character position arg (puts pos in top line) */
		case sbVDown: /* put line arg at top */
			if (stype == sbVDown)
				{
				arg = _TUTORline_pos_tview(tvp,(int) arg); /* position at start of line */
				shrinkFlag = -1;
				}
			else
				{
				if (arg >= tvp->bounds.pos + tvp->bounds.len)
					arg = tvp->bounds.pos + tvp->bounds.len - 1;
				shrinkFlag = (arg < tvp->layoutTop) ? 1 : -1;
				}
			
			if (arg == _TUTORline_pos_tview(tvp,tvp->topLine))
				break; /* nothing to do */
			
			/* make sure we have layout to display after scrolling */
			doLayout = FALSE;
			if (arg < tvp->layoutTop || arg > tvp->layoutBottom)
				doLayout = TRUE; /* desired position is outside existing layout */
			if (!doLayout)
				{ /* check to see if there is enough layout */
				ii = _TUTORpos2_line_tview(tvp,arg); /* which line */
				newHeight = 0;
				lp = (LineLayout FAR *) tvp->ld + ii;
				for (;ii<tvp->txtvH.dAnn;ii++, lp++)
					newHeight += lp->lineHeight;
				if (newHeight < viewHeight && tvp->layoutBottom < tvp->bounds.pos + tvp->bounds.len)
					doLayout = TRUE;
				}
			
			if (doLayout)
				{
				ReleasePtr(theV);
				KillPtr(tvp);
				_TUTORlayout_lines0(theV,arg,viewHeight,FALSE);
				tvp = (TViewP) GetPtr(theV);
				}
			/* figure out new top & bottom lines */
			tvp->topLine = _TUTORpos2_line_tview(tvp,arg);
			if (tvp->topLine >= tvp->txtvH.dAnn)
				tvp->topLine--; /* always require 1 line showing */
			_TUTORnew_bottom_tview(0,tvp);

			/* draw */
			TUTORdraw_abs_solid_rect(&tvp->viewRect,PAT_BACKGROUND);
			oldcState = tvp->caretState;
			tvp->caretState = FALSE; /* caret has been erased */
			_TUTORdraw_tview(tvp,tvp->topLine,tvp->botLine);
			TUTORwhere_pix_tview(theV,&tvp->anchor);
			TUTORwhere_pix_tview(theV,&tvp->selA);
			if (oldcState)
				_TUTORhilite_select(theV,TRUE);
			break;
		case sbVUp: /* put top line at vertical position arg */
			/* see if there is enough layout already above top that is showing */
			shrinkFlag = 1;
			newHeight = 0;
			ii = tvp->topLine-1;
			lp = (LineLayout FAR *) tvp->ld+ii;
			for (; ii>=0; ii--, lp--)
				{
				newHeight += lp->lineHeight;
				if (newHeight >= arg)
					{
					newTopLine = ii+1;
					break; /* we've found enough existing material */
					}
				}
			if (ii < 0 && tvp->layoutTop > tvp->bounds.pos)
				{ /* we need to layout lines above current top */
				tempL = tvp->layoutTop -1;
				ReleasePtr(theV);
				KillPtr(tvp);
				_TUTORlayout_lines0(theV,tempL,viewHeight-newHeight-1,FALSE);
				tvp = (TViewP) GetPtr(theV);
				tvp->topLine = _TUTORpos2_line_tview(tvp,tempL+1); /* line # of old top */
				TUTORwhere_pix_tview(theV,&tvp->anchor);
				TUTORwhere_pix_tview(theV,&tvp->selA);
				newHeight = 0;
				ii = tvp->topLine-1;
				lp = (LineLayout FAR *) tvp->ld+ii;
				for (; ii>= 0; ii--, lp--)
					{
					newHeight += lp->lineHeight;
					if (newHeight >= arg)
						{ /* found new top */
						newTopLine = ii+1;
						break;
						}
					}
				if (ii < 0)
					newTopLine = 0;
				}
			else if (ii < 0)
				{ /* there just isn't enough doc to go that far back */
				newTopLine = 0;
				}

			/* KSW: there used to be a test here so that we redrew only when
				tvp->topLine != newTopLine.  But then TUTORscroll_middleV didn't work
				when the top line was 0 before calling here */

			tvp->topLine = newTopLine;
			TUTORwhere_pix_tview(theV,&tvp->anchor);
			TUTORwhere_pix_tview(theV,&tvp->selA);
			_TUTORnew_bottom_tview(0,tvp);
			/* draw */
			TUTORdraw_abs_solid_rect(&tvp->viewRect,PAT_BACKGROUND);
			oldcState = tvp->caretState;
			tvp->caretState = FALSE; /* caret has been erased */
			_TUTORdraw_tview(tvp,tvp->topLine,tvp->botLine);
			if (oldcState)
				_TUTORhilite_select(theV,TRUE);
			break;
		
		case sbLineUp: /* scroll up (back in doc) 1 line  - arg ignored */
			shrinkFlag = 1;
			if (tvp->topLine == 0)
				{ /* we are at top of our layout, need to lay out more lines */
				if (tvp->layoutTop == tvp->bounds.pos)
					break; /* can't go back any further */
				tempL = tvp->layoutTop-1;
				ReleasePtr(theV);
				KillPtr(tvp);
				_TUTORlayout_lines0(theV,tempL,1,FALSE);
				tvp = (TViewP) GetPtr(theV);
				tvp->topLine = _TUTORpos2_line_tview(tvp,tempL); /* line # of new top */
				TUTORwhere_pix_tview(theV,&tvp->anchor);
				TUTORwhere_pix_tview(theV,&tvp->selA);
				laidOut = TRUE; /* indicates that we laid out lines */
				}
			else
				{ /* just shift existing things */
				tvp->topLine--;
				_TUTORnew_bottom_tview(0,tvp);
				laidOut = FALSE; /* we didn't layout */
				}
			
			/* handle existing hilighting */
			if (tvp->anchor.pos == tvp->selA.pos)
				{ /* only have caret, just turn it off */
				hiliteFlag = FALSE;
				_TUTORdraw_caret_tview(tvp,1);
				}
			else
				{ /* have selection region - we don't want to redraw it */
				hiliteFlag = TRUE;
				}
			
			tr = tvp->viewRect;
			tr.bottom = tvp->botV - tvp->ld[tvp->topLine].lineHeight;
			delV = tvp->ld[tvp->topLine].lineHeight;
			TUTORscroll_rect(&tr,0,delV);
			
			if (!laidOut)
				{ /* adjust selection positions (since we didn't lay out lines) */
				tvp->anchor.vv += delV;
				tvp->selA.vv += delV;
				}
			
			_TUTORdraw_tview(tvp,tvp->topLine,tvp->topLine);
			
			if (tvp->caretState)
				{ /* restore hiliting */
				if (!hiliteFlag)
					_TUTORdraw_caret_tview(tvp,2); /* turn caret back on */
				else
					{ /* we want to draw the portion of hiliting in newly drawn text */
					HiliteLine(tvp,tvp->topLine,tvp->topLine);
					}
				}
			
			/* erase extra stuff at bottom */
			tr.top = tvp->botV+1;
			tr.bottom = tvp->viewRect.bottom;
			TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_BACKGROUND);
			break;
		case sbLineDown: /* scroll down (further in doc) 1 line - arg ignored */
			shrinkFlag = -1;
			if (tvp->topLine == tvp->botLine)
				break; /* can't scroll down any further */

			if (tvp->botPos == tvp->layoutBottom &&
					tvp->bounds.pos + tvp->bounds.len > tvp->botPos)
				{ /* we are at bottom of our layout, need to lay out more lines */
				tempL = tvp->botPos;
				ReleasePtr(theV);
				KillPtr(tvp);
				_TUTORlayout_lines0(theV,tempL,1,FALSE);
				tvp = (TViewP) GetPtr(theV);
				}

			if (tvp->anchor.pos == tvp->selA.pos)
				{ /* only have caret, just turn it off */
				hiliteFlag = FALSE;
				_TUTORdraw_caret_tview(tvp,1);
				}
			else
				{ /* have selection region - we don't want to redraw it */
				hiliteFlag = TRUE;
				}
			
			tr = tvp->viewRect;
			
			if (tvp->botV > tvp->viewRect.bottom)
				{ /* erase partial last line */
				tr.top = tvp->botV - tvp->ld[tvp->botLine].lineHeight + 1;
				TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_BACKGROUND);
				ii = 0;
				}
			else
				ii = 1; /* don't redraw old bottom line */
			
			/* scroll existing text */
			delV = tvp->ld[tvp->topLine].lineHeight;
			tr.top = tvp->viewRect.top + delV;
			TUTORscroll_rect(&tr,0,-delV);
			tvp->anchor.vv -= delV;
			tvp->selA.vv -= delV;
			oldBottom = tvp->botLine;
			tvp->topLine++;
			_TUTORnew_bottom_tview(0,tvp);
			_TUTORdraw_tview(tvp,oldBottom+ii,tvp->botLine);

			if (tvp->caretState)
				{ /* restore hiliting */
				if (!hiliteFlag)
					_TUTORdraw_caret_tview(tvp,2); /* turn caret back on */
				else
					{ /* we want to draw the portion of hiliting in newly drawn text */
					HiliteLine(tvp,oldBottom+ii,tvp->botLine);
					}
				}
			break;
		
		default:
			break;
			
		} /* end of scroll switch */
	
	retVal = _TUTORline_pos_tview(tvp,tvp->topLine) - tvp->bounds.pos;
	
	if (tvp->txtvH.dAnn > MAXLAYOUTLINES+50)
		{ /* too many layout lines - get rid of some */
		newTop = (shrinkFlag != 1) ? tvp->topLine-5 : 0;
		newBot = (shrinkFlag != -1) ? tvp->botLine+5 : tvp->txtvH.dAnn;
		_TUTORshrink_layout_tview(tvp,newTop,newBot);
		ReleasePtr(theV);
		KillPtr(tvp);
		TUTORcompress_darray(theV,VIEWOFFSET);
		}
	else
		{
		ReleasePtr(theV);
		KillPtr(tvp);
		}

	return(retVal);
	}

static HiliteLine(tvp,l1,l2) /* do hiliting of just some lines */
register TViewP tvp;	/* pointer to tview */
int l1,l2; /* lines to be hilighted (if hilight region overlaps them) */
	{
	long start, end;	/* start & end position (in doc) of lines in question */
	long sel1;	/* position at start of hilight */
	long sel2;	/* position at end of hilight */
	long tempL;
	TRect cr;	/* rectangle for temporary clip */
	TRect clipR;	/* to save & restore clip rectangle */
	int lineTop;	/* top of first line */
	int lineBot;	/* bottom of last line */
	
	if (!tvp->highSel) {
		_TUTORdraw_caret_tview(tvp,1); /* erase caret */
		_TUTORdraw_caret_tview(tvp,2); /* draw caret */
		return(0);
	}
	if (l2 < l1)
		return(0);
	start = _TUTORline_pos_tview(tvp,l1);
	if (l1 != l2)
		end = _TUTORline_pos_tview(tvp,l2);
	else
		end = start;
	end += tvp->ld[l2].nc;
	
	sel1 = tvp->anchor.pos;
	sel2 = tvp->selA.pos;
	if (sel1 > sel2)
		{
		tempL = sel1;
		sel1 = sel2;
		sel2 = tempL;
		}
	
	if (start > sel2 || end < sel1)
		return(0); /* no hiliting in these lines */
	
	TUTORinq_abs_clip_rect(&clipR);
	lineTop = _TUTORline2_vv_tview(tvp,l1) - tvp->ld[l1].lineAsc;
	if (l2 == tvp->botLine)
		lineBot = tvp->viewRect.bottom; /* so that hilight of following lines shows */
	else if (l1 == l2)
		lineBot = lineTop + tvp->ld[l1].lineHeight-1;
	else
		lineBot = _TUTORline2_vv_tview(tvp,l2) - tvp->ld[l2].lineAsc + tvp->ld[l2].lineHeight - 1;
	
	cr.left = tvp->viewRect.left;
	cr.top = lineTop;
	cr.right = tvp->viewRect.right;
	cr.bottom = lineBot;
	TUTORset_abs_clip_rect((TRect FAR *) &cr);

	if (sel1 == tvp->anchor.pos)
		_TUTORdraw_selr_tview(tvp,&tvp->anchor,&tvp->selA);
	else
		_TUTORdraw_selr_tview(tvp,&tvp->selA,&tvp->anchor);
	
	TUTORset_abs_clip_rect((TRect FAR *) &clipR);
	
	return(0);
	}

_TUTORscrollh_tview(theV,offset)	/* horizontal scroll of tview */
Memh theV;	/* tview */
int offset; /* desired offset (should always be negative) */
	{
	REGISTER TViewP tvp;	/* pointer to tview */
	int viewWidth;	/* width of the view (in pixels) */
	register int del;	/* amount to shift view (in pixels) */
	int oldcState;	/* to save & restore caret state */
	
	if (offset > 0)
		offset = 0;
	
	tvp = (TViewP) GetPtr(theV);
	viewWidth = tvp->viewRect.right - tvp->viewRect.left+1;
/* scroll-change */
/*	if (offset < viewWidth - tvp->destWidth)
		offset = viewWidth - tvp->destWidth; */
	if (offset < viewWidth - HSCROLL_WIDTH)
		offset = viewWidth - HSCROLL_WIDTH; 	
	
	if (tvp->leftOff != offset && tvp->scrollH)
		{ /* do scroll */
		TUTORdraw_abs_solid_rect(&tvp->viewRect,PAT_BACKGROUND);
		oldcState = tvp->caretState;
		tvp->caretState = FALSE; /* caret isn't showing because we've erased it */
		del = offset - tvp->leftOff;
		tvp->anchor.hh += del;
		tvp->selA.hh += del;
		tvp->leftOff = offset;
		_TUTORdraw_tview(tvp,tvp->topLine,tvp->botLine);
		if (oldcState)
			_TUTORhilite_select(theV,TRUE);
		}
	
	ReleasePtr(theV);
	KillPtr(tvp);
	
	}

TUTORscroll_middleV(theV,pos) /* scroll so that pos is in the middle of the view */
Memh theV;	/* tview */
long pos;	/* position we want in the middle of the view */
	{
	TViewP tvp;	/* pointer to tview */
	int viewHeight;	/* vertical height (in pixels) of the view */
	int doit;	/* TRUE if we want to scroll */
	
	/* we want to scroll so that selection is in the middle of the view */
	/* make pos in top line, then scroll so that top line is at the
		vertical position which is the middle of the screen */

	tvp = (TViewP) GetPtr(theV);
	
	/* check to make sure we aren't scrolling when there isn't anything to scroll */
	doit = TRUE;
	if (tvp->bounds.len == 0)
		doit = FALSE; /* don't scroll when there isn't any text in view */
	else if (pos >= tvp->bounds.pos + tvp->bounds.len)
		pos = tvp->bounds.pos + tvp->bounds.len -1; /* push pos back into sanity */
	
	/* relayout lines so that pos is in top line */
	
	viewHeight = tvp->viewRect.bottom - tvp->viewRect.top + 1;
	ReleasePtr(theV);
	KillPtr(tvp);
	
	if (!doit)
		return(0);
	
	_TUTORlayout_lines0(theV,pos,viewHeight,TRUE);
	
	/* scroll so that pos is in the middle of the screen (third from top) */
	_TUTORscrollv_tview(theV,sbVUp,(long) viewHeight/3);
	
	return(0);
	}










