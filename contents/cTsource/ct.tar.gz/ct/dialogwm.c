
/* (c) Copyright Carnegie-Mellon University, 1988. */
/* May be used and copied freely for educational purposes, */
/* but may not be sold without the written consent of Carnegie-Mellon University. */

#include <stdio.h>
#include "baseenv.h"
#include "kdefs.h"
#include "tutor.h"
#include "editor.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "edglobal.h"
#include "compute.h"
#include "txt.h"
#include "fkeys.h"
#include "kglobals.h"
#include "prefs.h"
#include "editmenu.h"
#include "dialogwm.h"

#ifdef ANDREW
#define UNIX_SYS
#else
#ifdef SYSV
#define UNIX_SYS
#else
#ifdef X11
#define UNIX_SYS
#endif
#endif
#endif

#ifdef ctproto
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,
 int ebsref,struct  _trect *theR,int  relInfo,int  mintw,int  wrap,
 unsigned int  doc,long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),
 int  ro,int  corner,int  erase,int  frame,int tabsz,int lm,int rm,int inhss,int type);
extern char *PrefFaceStr(int index);
extern char *PrefColorStr(int index);
extern int PrefColorN(char *str);
long TUTORinq_symbolic_font_id(char  *fontName);
extern int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
extern int get_button_ref(Memh bH);
extern char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  TUTORalert(int  wn,char  *msg);
int  TUTORsavefile_dialog(int  wn,char  *msg,struct  _fref *filename,int  maxRet);
int  TUTORedit_dialog(int  wn,char  *msg,char  FAR *retS1,char *msg2,char  FAR *retS2,int  maxRet);
int  TUTORync_dialog(int  wn,char  *msg);
int  TUTORreadfile_dialog(int  wn,char  *msghdr,struct  _fref *filename,char *defname,int  maxRet,int  type,int  msgb,int  doRedraw);
extern int  SizeReadfileDialog(int  wn,struct  _trect FAR *bounds,struct  _DItem FAR *bb,int  redrawF);
int  TUTORmulti_line_dialog(int  wn,char  FAR * *msg,int  nmsg);
extern unsigned int  TUTORstart_dialog(int  wn,struct  _trect *bounds,int  kind,int  nItems,struct  _DItem *items,int  defaultB);
extern int  TUTORrun_dialog(unsigned int  dialog);
int  procdialogw(unsigned int  dialog,struct  tutorevent *event);
extern int  TUTORgettext_dialog(unsigned int  dialog,int  itemN,char  FAR *cp,int  maxChar);
extern int  TUTORclose_dialog(unsigned int  dialog,int  doRedraw);
int  procdialog(unsigned int  dialog,struct  tutorevent *cev);
extern int  TUTORdraw_dialog(struct  _dialinf FAR *dp,int  drawViews);
extern int  DrawItem(struct  _DItem *ip,int  drawAll);
extern int  DialogKeys(unsigned int  dialog,struct  tutorevent *cev);
extern int  ShiftFocusDialog(unsigned int  dialog,int  nChange);
int  ChangeFocusDialog(unsigned int  dialog,int  newItem,int  isClick,struct tutorevent *event);
extern int  ActivateDialogItem(struct  _dialinf FAR *dp,int  item,int  onoff);
extern int  KeyFilterDialog(long  dViewH,unsigned int  textv,struct  tutorevent *cev);
int  StartCompileMsg(int  wn);
int  EditCompileMsg(int  wn,char  *ms);
int  EndCompileMsg(int  wn);
unsigned int  TUTORnew_button(int  wn,unsigned int  owner,unsigned int  objH,int objR,
    struct  _trect *tr,int  kind,int  thick,int  bFont,char  *title,unsigned int titleD,unsigned int  destH,
    int  (*DestProc)(),int  destMsg,int  destMsg1,double  destMsg2,int  erase);
int  TUTORreset_button(unsigned int  bH,int  value,int  aFlag,int  eraseF);
int  TUTORinq_button_value(unsigned int  bH);
int  TUTORmove_button(unsigned int  bH,int  left,int  top,int  right,int  bottom);
int  TUTORclose_button(unsigned int  bH);
int  CThighlight_normal_button(struct  _buttonD FAR *bp);
int  CThighlight_checkbox_button(struct  _buttonD FAR *bp);
int  CThighlight_radio_button(struct  _buttonD FAR *bp);
int  CThighlight_3D_button(struct  _buttonD FAR *bp);
int  CThighlight_button(unsigned int  bH);
int  procbutton(unsigned int  bH,struct  tutorevent *event);
int  TUTORdraw_button(unsigned int  bH);
int  TUTORdraw_normal_button(struct  _buttonD FAR *bp);
int  TUTORdraw_3D_button(struct  _buttonD FAR *bp);
int  TUTORdraw_radio_button(struct  _buttonD FAR *bp);
int  TUTORdraw_checkbox_button(struct  _buttonD FAR *bp);
int  OpenFileDialog(unsigned int  dialog,int  itemN);
int  ESTextSelect(unsigned int  dialog,unsigned int  edH,struct  tutorevent *event);
int  TUTORset_rect(struct  _trect *r,int  left,int  top,int  right,int  bottom);
int  TUTORcvt_path(char  *ssx,struct  _fref FAR *fRef,struct  _fref FAR *baseRef,int isFile);
char  *strf2n(char  FAR *strp);
int  TUTORdispose_dir(char  FAR *path);
int  TUTORfree_region(long  id);
int  TUTORabs_restore_region(long  id,int  x1,int  y1);
int  OpenFileDialogstub(unsigned int  dialog,int  itemN);
char  FAR *TUTORread_dir(struct  _fref FAR *fref);
long  TUTORabs_save_region(int  x1,int  y1,int  x2,int  y2);
extern char *strcat(char *aa, char *bb);
int  TUTORcopy_fileref_dir(struct  _fref FAR *dirname,struct  _fref FAR *fullname);
int  procdialogstub(unsigned int  hv,struct  tutorevent *event);
int  TUTORset_textfont(int  jj);
int  TUTORget_zfont(char  *famS,int  size);
int  CTset_window_color(int  cn);
int  CTset_background_color(int  color);
int  CTset_foreground_color(int  color);
int  TUTORset_view(struct  tutorview FAR *vp);
struct  tutorview FAR *TUTORinit_view(int  sW,unsigned int  vDat,int  (*vProc)());
struct  tutorview FAR *TUTORinq_view(void);
char  FAR *GetPtr(unsigned int  mm);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORinq_abs_string_width(unsigned char  FAR *s,int  lth,int  *dx);
int  strlenf(char  FAR *aa);
int  TUTORinq_font_info(int  *ascent,int  *descent,int  *maxwidth,int  *leading);
int  TUTORinq_select_line(unsigned int  theV,int  yy,long  *lineS,long  *lineL);
int  ESTextSelectstub(long  dialog,unsigned int  edH,struct  tutorevent *event);
struct	tutorview FAR *TUTORinq_slider_view(unsigned int  theSBar);
int  TUTORinsert_string_doc(unsigned int  doc,long  pos,unsigned char  FAR *ss,long  sLen);
int  EditorDefaultStyles(unsigned int  doc);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  ReleasePtr(unsigned int  mm);
int  TUTORmessage(struct  tutorview FAR *vp,int  eKind,int  eVal);
int  TUTORset_select_tview(unsigned int  theV,long  pos,long  len,struct  _sbarinf *vb);
int  TUTORchange_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,unsigned char  FAR *cp,long  cLen,long  fromOff,unsigned int  styles,unsigned int  specialT,long  *extraPos,int  eupFlag);
int  TUTORclear_window(int  wid);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
int  interact(int  block);
int  TUTORflush(void);
int  procdialogwstub(unsigned int  dh,struct  tutorevent *event);
int  TUTORinq_event_mask(int  wid,int  eventc);
int  SetSelectPanel(struct  _tvdat FAR *vp,long  pos,long  len);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
int  TUTORset_abs_view_rect(int  x1,int  y1,int  w,int  h);
int  TUTORset_abs_clip_rect(struct  _trect FAR *cr);
int  TUTORforce_redraw(int  wix);
int  TUTORclose_view(struct  tutorview FAR *vp);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
long  TUTORget_len_doc(unsigned int  doc);
int  killptr(char  FAR * FAR *ptr);
int  TUTORpost_event(struct  tutorevent *event);
int  DrawPanel(unsigned int  edH);
int  TUTORdraw_text(unsigned char  FAR *buf,int  count);
int  TUTORabs_move_to(int  x,int  y);
int  TUTORinset_rect(struct  _trect FAR *rr,int  xx,int  yy);
int  TUTORframe_abs_rect(struct  _trect FAR *tr);
int  TUTORfree_handle(unsigned int  mm);
int  mvar_temp_cleanup(void);
extern char *strncpy(char *aa, char *bb, int nn);
int  RestartPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  selStart,long  selLen);
long  TUTORsearch_string_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sLen,long  pos,long  posEnd);
char  FAR *strcatf(char  FAR *aa,char  FAR *bb);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int  TUTORinq_select_tview(unsigned int  theV,long  *pos,long  *len);
extern int strlen(char *str);

char  FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
int  procbuttonstub(unsigned int  hv,struct  tutorevent *event);
int  TUTORabs_erase_rect(struct  _trect *tr,int  pattInd,int  pattC);
int  TUTORmove_rect(struct  _trect FAR *rr,int  xx,int  yy);
int  TUTORfill_abs_rect(struct  _trect FAR *tr,int  pattInd,int  pattC);
/* TUTORinq_is_dir() */
int  TUTORabs_line_to(int  x,int  y);
int  TUTORdraw_graphic_icons(int  iconFont,char  *s,int  len);
int  TUTORget_font2(long  fam,int  size,unsigned int  face,int cid);
long  TUTORinq_symbolic_font_id(char  *fontName);
int  TUTORdouble_click(short  *hh,short  *vv);
int  TUTORdump(char  *s);
#endif /* ctproto */

extern int OpenFileDialogstub();
extern int ESTextSelectstub();
extern char FAR *TUTORread_dir();
extern long TUTORsearch_string_doc();
extern struct tutorview FAR *TUTORinq_slider_view();
extern char *PrefFaceStr();
extern int PrefFaceN();
extern char *PrefColorStr();
extern int PrefColorN();

/* default font height (in pixel size) for editor (newFontSize TRUE for edit & dict windows) */
#define DIALOGFONT "zsans"
#define DIALOGFSIZE 16

#define BUTTONKIND 0
#define STEXTKIND 1
#define ETEXTKIND 2
#define ESTEXTKIND 3
#define CHECKKIND 4

/* #define SAVESCREEN */

extern Memh MakeTextPanel();
extern Memh TUTORnew_doc();
extern long TUTORget_len_doc();
extern Memh TUTORnew_button();
extern int procbuttonstub();
extern int procbutton();
extern char *FullName ();

extern int procdialogstub();
extern int procdialogwstub();
extern struct tutorview FAR *TUTORinq_view();
extern struct tutorview FAR *TUTORinit_view();
extern Memh TUTORstart_dialog();
extern int KeyFilterDialog();
extern long TUTORabs_save_region();
extern char *strf2n();
extern int proceditstub();
extern long TUTORabs_save_region();
extern int TUTORdispose_dir();
extern void draw_button_text();

/*
Dialogs are put up and run in a modal state.  This means that the user isn't allowed to do anything (other than
resizing windows) except work with the dialog.  This is accomplished by using the modalW flag.  Note that
with the present implementation a dialog box cannot bring up another dialog box.
*/

TUTORalert(wn,msg)
int wn;
char *msg;
    {
    DItem bb[2];
    TRect bounds;
    Memh dialog;
    
    /* set up areas */
    TUTORset_rect(&bounds,30,10,270,160);
    
    TUTORset_rect(&bb[0].rr,10,10,230,30);
    bb[0].text = msg;
    bb[0].kind = STEXTKIND;
    bb[0].ActionProc = NULL;
    
    TUTORset_rect(&bb[1].rr,9,109,72,132);
    bb[1].text = "OK";
    bb[1].kind = BUTTONKIND;
    bb[1].key = RETURN;
    bb[1].ActionProc = NULL;
    
    dialog = TUTORstart_dialog(wn,&bounds,OTHERDIALOG,2,bb,1);
    TUTORrun_dialog(dialog);
    TUTORclose_dialog(dialog,TRUE);
    
    }


TUTORsavefile_dialog(wn,msg,filename,maxRet)
int wn; /* window dialog should appear in */
char *msg;
FileRef *filename;
int maxRet; /* unused */
    {
    int retVal;
	char path[FILEL+2]; /* local copy of path */

    retVal = TUTORedit_dialog(wn,msg,(char FAR *) filename->path,NEARNULL,FARNULL,CTPATHLEN);
    if (retVal)
        { /* ok, need to convert file name (for ~ etc.) */
		strcpy(path,filename->path);
        TUTORcvt_path(path,(FileRef FAR *) filename, (FileRef FAR *)sourceDirP,TRUE);
        }

    return(retVal);
    }

TUTORedit_dialog(wn,msg,retS1,msg2,retS2,maxRet)
int wn; /* window dialog should appear in */
char *msg; /* message to display */
char FAR *retS1; /* editable reply (may have something in it to start) */
char *msg2; /* (optional) second message to display */
char FAR *retS2; /* (optional) second editable reply */
int maxRet; /* maximum size of return string (in both replies) */
/* returns TRUE for ok, FALSE for cancel */
    {
    DItem bb[6];
    TRect bounds;
    int nItems, retVal;
    Memh dialog;
    int hSize, ii;
    
    /* set up areas */
    hSize = windowsP[wn].wxsize - 40; /* space for 10 pixels on left, 30 on right */
    TUTORset_rect(&bounds,10,10,10+hSize,160);
    
    TUTORset_rect(&bb[0].rr,10,10,hSize-10,30);
    bb[0].text = msg;
    bb[0].kind = STEXTKIND;
    bb[0].ActionProc = NULL;
    
    TUTORset_rect(&bb[1].rr,19,109,72,132);
    bb[1].text = "OK";
    bb[1].kind = BUTTONKIND;
    bb[1].key = RETURN;
    bb[1].ActionProc = NULL;
    
    TUTORset_rect(&bb[2].rr,89,109,152,132);
    bb[2].text = "Cancel";
    bb[2].kind = BUTTONKIND;
    bb[2].key = 'c';
    bb[2].ActionProc = NULL;
    
    TUTORset_rect(&bb[3].rr,9,39,hSize-10+2,102);
    bb[3].text = retS1;
    bb[3].kind = ETEXTKIND;
    bb[3].ActionProc = NULL;
    
	nItems = 4; /* have 4 items set up at this point */
    if (retS2) { /* if 2nd editable text panel */
        nItems++;
        ii = (hSize-30)/2; /* size of each edit area */
        bb[3].rr.right = ii + 10;
        TUTORset_rect(&bb[4].rr,ii+20,40,hSize-10,100);
        bb[4].text = retS2;
        bb[4].kind = ETEXTKIND;
        bb[4].ActionProc = NULL;
		if (msg2) { /* if message for 2nd panel */
		    nItems++;
            TUTORset_rect(&bb[5].rr,ii+20,10,hSize-ii-10,30);
            bb[5].text = msg2;
            bb[5].kind = STEXTKIND;
            bb[5].ActionProc = NULL;		
		} /* msg2 if */
    } /* retS2 if */
    
    dialog = TUTORstart_dialog(wn,&bounds,OTHERDIALOG,nItems,bb,1);
    retVal = (1 == TUTORrun_dialog(dialog));
    if (retVal)
        {
        TUTORgettext_dialog(dialog,3,retS1,maxRet);
        if (retS2)
            TUTORgettext_dialog(dialog,4,retS2,maxRet);
        }
    TUTORclose_dialog(dialog,TRUE);
    
    return(retVal);
    }

/* ******************************************************************* */

TUTORok_dialog(wn,msg) 
int wn; /* window number for dialog */
char *msg; /* message string to display */
/* returns 0: ok, -2: can't save display, -3: not front window */

{	DItem bb[2];
    TRect bounds;
    int retVal;
    Memh dialog;
	int x1,y1,x2,y2;
	int doRedraw;
	long regionid;

	doRedraw = TRUE;
    TUTORset_rect(&bounds,30,10,270,160);

	if (wn == ExecWn) {
		if (runflag != halt) {
			if (!TUTORis_foreground())
				return(-3);
			doRedraw = FALSE;
		    x1 = bounds.left;
    		y1 = bounds.top;
    		x2 = bounds.right;
    		y2 = bounds.bottom;
    		if ((x2 > windowsP[wn].wxsize) || (y2 > windowsP[wn].wysize))
        		return(-2); /* not enough screen space */
        	regionid = TUTORabs_save_region(x1,y1,x2,y2);
        	if (!regionid) 
            	return(-2); /* no memory */
    	} /* runflag if */
	} /* wn if */
	
    /* set up areas */
    
    TUTORset_rect(&bb[0].rr,9,109,72,132);
    bb[0].text = "Ok";
    bb[0].kind = BUTTONKIND;
    bb[0].key = RETURN;
    bb[0].ActionProc = NULL;

    TUTORset_rect(&bb[1].rr,10,10,230,30);
    bb[1].text = msg;
    bb[1].kind = STEXTKIND;
    bb[1].ActionProc = NULL;
    
    dialog = TUTORstart_dialog(wn,&bounds,OTHERDIALOG,2,bb,0);
    retVal = TUTORrun_dialog(dialog);
    TUTORclose_dialog(dialog,doRedraw);
    if (!doRedraw) { /* restore saved screen */
        TUTORabs_restore_region(regionid,x1,y1);
        TUTORfree_region(regionid);
    }
    return(0);
	
} /* TUTORok_dialog */

/* ******************************************************************* */

TUTORync_dialog(wn,msg) /* yes, no, cancel dialog */
int wn; /* window where dialog will  appear */
char *msg; /* message to display */
/* returns 0: yes, 1: no, 2: cancel, -2: can't save display, -3: not front window */
    {
    DItem bb[4];
    TRect bounds;
    int retVal;
    Memh dialog;
	int x1,y1,x2,y2;
	int doRedraw;
	long regionid;

	doRedraw = TRUE;
    TUTORset_rect(&bounds,30,10,270,160);

	if (wn == ExecWn) {
		if (runflag != halt) {
			if (!TUTORis_foreground())
				return(-3);
			doRedraw = FALSE;
		    x1 = bounds.left;
    		y1 = bounds.top;
    		x2 = bounds.right;
    		y2 = bounds.bottom;
    		if ((x2 > windowsP[wn].wxsize) || (y2 > windowsP[wn].wysize))
        		return(-2); /* not enough screen space */
        	regionid = TUTORabs_save_region(x1,y1,x2,y2);
        	if (!regionid) 
            	return(-2); /* no memory */
    	} /* runflag if */
	} /* wn if */
	
    /* set up areas */
    
    TUTORset_rect(&bb[0].rr,9,69,72,92);
    bb[0].text = "Yes";
    bb[0].kind = BUTTONKIND;
    bb[0].key = RETURN;
    bb[0].ActionProc = NULL;
    
    TUTORset_rect(&bb[1].rr,9,109,72,132);
    bb[1].text = "No";
    bb[1].kind = BUTTONKIND;
    bb[1].key = 'n';
    bb[1].ActionProc = NULL;
    
    TUTORset_rect(&bb[2].rr,89,109,152,132);
    bb[2].text = "Cancel";
    bb[2].kind = BUTTONKIND;
    bb[2].key = 'c';
    bb[2].ActionProc = NULL;
    
    TUTORset_rect(&bb[3].rr,10,10,230,30);
    bb[3].text = msg;
    bb[3].kind = STEXTKIND;
    bb[3].ActionProc = NULL;
    
    dialog = TUTORstart_dialog(wn,&bounds,OTHERDIALOG,4,bb,0);
    retVal = TUTORrun_dialog(dialog);
    TUTORclose_dialog(dialog,doRedraw);
    if (!doRedraw) { /* restore saved screen */
        TUTORabs_restore_region(regionid,x1,y1);
        TUTORfree_region(regionid);
    }
    
    return(retVal);
    }


/* ******************************************************************* */

TUTORreadfile_dialog(wn, msghdr, filename, defname,maxRet, type, msgb, doRedraw)
int wn;
char *msghdr; /* dialog box header message */
FileRef *filename;
char *defname;
int maxRet; /* unused */
int type; /* 1: source, 2: binary, 3: another program (not used) */
int msgb; /* button message: 1 = open, 2 = create, 3 = open(swtich) */
int doRedraw; /* if TRUE must force redraw after dialog */
              /* if FALSE attempt to save screen behind dialog */
/* returns = 1 if all ok */
/*           2 if dialog canceled */
/*           3 if not enough screen space for dialog */
/*           4 if not enough memory for dialog */


{   DItem bb[4];
    int retVal;
    Memh dialog;
    TRect bounds;
    FileRef dirname;
    DialogDat FAR *dp;
    long regionid; /* id of saved screen region */
    int x1,y1,x2,y2; /* saved region */
    char dirString[FILEL+4];

    TUTORcopy_fileref_dir((FileRef FAR *) &dirname, (FileRef FAR *) filename);
#ifdef IBMPC
    dirString[0] = dirname.drive + 'a' - 1;
    dirString[1] = ':';
    dirString[2] = '\0';
    strcat(dirString,dirname.path);
#else
    if (dirname.path[0] == '\0')
        strcpy(dirname.path, "/");
    strcpy(dirString,dirname.path);
#endif
    /* set up areas */
    SizeReadfileDialog(wn,(TRect FAR *) &bounds,(DItem FAR *) bb,FALSE);
    x1 = bounds.left;
    y1 = bounds.top;
    x2 = bounds.right;
    y2 = bounds.bottom;
    if ((x2 > windowsP[wn].wxsize) || (y2 > windowsP[wn].wysize))
        return(3); /* not enough screen space */
    if (!doRedraw) {
        regionid = TUTORabs_save_region(x1,y1,x2,y2);
        if (!regionid) 
            return(4); /* no memory */
    }
    
    /* the path box */
    bb[0].text = dirString;
    bb[0].kind = ETEXTKIND;
    /* note that bb[0].text won't get changed, only a copy */
	/* is changed when it is edited */
    bb[0].ActionProc = NULL;

    /* file scroll region */
    bb[1].kind = ESTEXTKIND;
    bb[1].text = TUTORread_dir((FileRef FAR *)&dirname);
    if (bb[1].text == FARNULL)
    	return(4); /* no memory? */
    bb[1].ActionProc = NULL;
    
    /* "Open" or "Create" button */

    if (msgb == 2)
        bb[2].text = (char FAR *)"Create";
    else
        bb[2].text = (char FAR *) "Open";
    bb[2].kind = BUTTONKIND;
    bb[2].key = RETURN;
    bb[2].ActionProc = OpenFileDialogstub;
    
    /* "Cancel" button */
    bb[3].text = (char FAR *) "Cancel";
    bb[3].kind = BUTTONKIND;
    bb[3].key = 'c';
    bb[3].ActionProc = NULL;
    
    dialog = TUTORstart_dialog(wn,&bounds,FILEDIALOG,4,bb,2);
	if ((msgb == 3) || (msgb == 2)) { /* create or switch-file dialog */
		dp = (DialogDat FAR *) GetPtr(dialog);
		dp->willCreate = TRUE; /* allow create if file doesn't exist */
		ReleasePtr(dialog);
		KillPtr(dp);
	}
    retVal = TUTORrun_dialog(dialog);
    TUTORclose_dialog(dialog,doRedraw);
    if (!doRedraw) { /* restore saved screen */
        TUTORabs_restore_region(regionid,x1,y1);
        TUTORfree_region(regionid);
    }
    TUTORdispose_dir(bb[1].text);
    if (retVal == 2) {
        TUTORcvt_path(strf2n(bb[0].text),(FileRef FAR *) filename, (FileRef FAR *)FARNULL,TRUE);
        return 1;
    } else {
        return 2;
    }

} /* TUTORreadfile_dialog */

/* ******************************************************************* */

static SizeReadfileDialog(wn,bounds,bb,redrawF) /* set up sizes for items of readfile dialog */
int wn; /* window index of dialog  */
TRect FAR *bounds;  /* bounds of dialog */
DItem FAR *bb;  /* list of dialog items */
int redrawF;    /* TRUE if this is due to redraw */
    {
    TRect lbounds;
    int ii;
    int wsize, hsize;
    TRect tr;
    
    wsize = windowsP[wn].wxsize-45;
    if (wsize < 255)
        wsize = 255; /* minimum width */
    hsize = windowsP[wn].wysize-45;
    if (hsize < 100)
        hsize = 100; /* minimum height */
#ifdef IBMPC
    if (hsize > 250)
        hsize = 250; /* maximum height */
#else
    if (hsize > 350)
        hsize = 350; /* maximum height */
#endif
    lbounds = *bounds; /* get near copy */
    TUTORset_rect(&lbounds,25,20,20+wsize-1,20+hsize-1);
    *bounds = lbounds; /* update far copy */
    
    /* the path box */
    TUTORset_rect(&tr, bounds->left+5,bounds->top+5,bounds->right-5,bounds->top+30);
    bb[0].rr = tr;

    /* file scroll region */
    TUTORset_rect(&tr,bounds->left+5,bounds->top+35,bounds->right-100,bounds->bottom-5);
    bb[1].rr = tr;

    /* "Open" button */
    TUTORset_rect(&tr,bounds->right-80,bounds->top+35,bounds->right-20,bounds->top+55);
    bb[2].rr = tr;

    /* "Cancel" button */
    TUTORset_rect(&tr,bounds->right-80,bounds->top+75,bounds->right-20,bounds->top+95);
    bb[3].rr = tr;

    if (!redrawF)
        { /* this is initial creation, item boundaries should be relative to bounds */
        for (ii=0; ii<4; ii++)
            {
            bb[ii].rr.left -= bounds->left;
            bb[ii].rr.top -= bounds->top;
            bb[ii].rr.right -= bounds->left;
            bb[ii].rr.bottom -= bounds->top;
            }
        }
    return(0);
    }

/* ******************************************************************* */

TUTORfiletype_dialog() { return(-1); }
               
/* ******************************************************************* */

TUTORmulti_line_dialog(wn,msg,nmsg)
int wn; /* window */
char FAR *msg[8]; /* message lines */
int nmsg; /* number message lines */

{   DItem bb[9];
    TRect bounds;
    Memh dialog;
    int dfont; /* index of dialog font */
    int maxw; /* maximum message width */
    int dx; /* width of message */
    int crh; /* newline height */
    int ascent,descent,maxwidth,leading;
    int yp; /* current y position */
    int ii;
    
    if (nmsg > 8) nmsg = 8;
    dfont = TUTORget_zfont(DIALOGFONT,DIALOGFSIZE);
    TUTORset_textfont(dfont);

    /* set up areas */

    TUTORinq_font_info(&ascent,&descent,&maxwidth,&leading);
    crh = ascent+descent+leading;
    maxw = 0;
    for(ii=0; ii<nmsg; ii++) {
        TUTORinq_abs_string_width((unsigned char FAR *) msg[ii],(int)strlenf(msg[ii]),&dx);
        if (dx > maxw) maxw = dx; /* track maximum width */
    } /* for */
    TUTORset_rect(&bounds,30,10,80+maxw,10+((nmsg+4)*crh));
    
    yp = 10;
    for(ii=0; ii<nmsg; ii++) {
        TUTORset_rect(&bb[ii+1].rr,10,yp,32+maxw,yp+crh);
        yp += crh;
        bb[ii+1].text = msg[ii];
        bb[ii+1].kind = STEXTKIND;
        bb[ii + 1].ActionProc = NULL;
    } /* for */

    yp += crh;
    TUTORset_rect(&bb[0].rr,9,yp-1,72,yp+crh+2+2);
    bb[0].text = "OK";
    bb[0].kind = BUTTONKIND;
    bb[0].key = RETURN;
    bb[0].ActionProc = NULL;
    
    dialog = TUTORstart_dialog(wn,&bounds,OTHERDIALOG,nmsg+1,bb,1);
    TUTORrun_dialog(dialog);
    TUTORclose_dialog(dialog,TRUE);

} /* TUTORmulti_line_dialog */

/* ******************************************************************* */

#ifndef EXECUTE

int TUTORprefs_dialog(wn) /* preferences dialog */
int wn; /* window where dialog will  appear */
    
{	DItem bb[19];
    TRect bounds;
    int retVal;
    Memh dialog;
	int x1,y1,x2,y2;
	long regionid;
	char fontName[42]; /* font family name */
	char fontSize[10]; 
	char fontFace[42]; /* font face (bold, italic, etc) name */
	char fColor[12]; /* foreground color name */
	char bColor[12]; /* background color name */
	char spaceTab[12]; /* spaces/tab */
	char checkTime[14]; /* checkpoint frequency */
	char printCmd[40]; /* printer command */
	struct PrefRec FAR *prefPtr; /* pointer to preferences data */
	struct tutorevent cev; /* quit event */
	char *cp;

	prefPtr = FARNULL;
    TUTORset_rect(&bounds,30,10,370,260);
	
    /* set up areas */
    
    TUTORset_rect(&bb[0].rr,191,219,254,242);
    bb[0].text = "Ok";
    bb[0].kind = BUTTONKIND;
    bb[0].key = RETURN;
    bb[0].ActionProc = NULL;
    
    TUTORset_rect(&bb[1].rr,269,219,332,242);
    bb[1].text = "Cancel";
    bb[1].kind = BUTTONKIND;
    bb[1].key = 'c';
    bb[1].ActionProc = NULL;
    
    TUTORset_rect(&bb[2].rr,5,10,50,30);
    bb[2].text = "Font";
    bb[2].kind = STEXTKIND;
    bb[2].ActionProc = NULL;
    
	strncpy(fontName,pffamilynP,40);
	TUTORset_rect(&bb[3].rr,50,10,110,30);
    bb[3].text = fontName;
    bb[3].kind = ETEXTKIND;
    bb[3].ActionProc = NULL;
    
	TUTORset_rect(&bb[4].rr,115,10,155,30);
    bb[4].text = "Size";
    bb[4].kind = STEXTKIND;
    bb[4].ActionProc = NULL;

	sprintf(fontSize,"%d",pfsize);
	TUTORset_rect(&bb[5].rr,160,10,200,30);
    bb[5].text = fontSize;
    bb[5].kind = ETEXTKIND;
    bb[5].ActionProc = NULL;

	TUTORset_rect(&bb[6].rr,205,10,250,30);
    bb[6].text = "Face";
    bb[6].kind = STEXTKIND;
    bb[6].ActionProc = NULL;

	cp = PrefFaceStr(pfface);
	strncpy(fontFace,cp,40);
	TUTORset_rect(&bb[7].rr,255,10,320,30);
    bb[7].text = fontFace;
    bb[7].kind = ETEXTKIND;
    bb[7].ActionProc = NULL;

    TUTORset_rect(&bb[8].rr,5,50,90,70);
    bb[8].text = "Foreground";
    bb[8].kind = STEXTKIND;
    bb[8].ActionProc = NULL;
    
	cp = PrefColorStr(prfP->fcolor);
	strncpy(fColor,cp,10);
	TUTORset_rect(&bb[9].rr,95,50,155,70);
    bb[9].text = fColor;
    bb[9].kind = ETEXTKIND;
    bb[9].ActionProc = NULL;
    
    TUTORset_rect(&bb[10].rr,165,50,265,70);
    bb[10].text = "Background";
    bb[10].kind = STEXTKIND;
    bb[10].ActionProc = NULL;
    
	cp = PrefColorStr(prfP->bcolor);
	strncpy(bColor,cp,10);
	TUTORset_rect(&bb[11].rr,255,50,315,70);
    bb[11].text = bColor;
    bb[11].kind = ETEXTKIND;
    bb[11].ActionProc = NULL;

    TUTORset_rect(&bb[12].rr,5,90,90,110);
    bb[12].text = "Spaces/tab";
    bb[12].kind = STEXTKIND;
    bb[12].ActionProc = NULL;
    
	sprintf(spaceTab,"%d",prfP->nTabs);
	TUTORset_rect(&bb[13].rr,95,90,155,110);
    bb[13].text = spaceTab;
    bb[13].kind = ETEXTKIND;
    bb[13].ActionProc = NULL;

    TUTORset_rect(&bb[14].rr,165,90,265,110);
    bb[14].text = "Snapshot";
    bb[14].kind = CHECKKIND;
	bb[14].value = prfP->snapShot;
    bb[14].ActionProc = NULL;

    TUTORset_rect(&bb[15].rr,5,130,170,150);
    bb[15].text = "Checkpoint (seconds)";
    bb[15].kind = STEXTKIND;
    bb[15].ActionProc = NULL;
    
	sprintf(checkTime,"%ld",(long)prfP->checkTime);
	TUTORset_rect(&bb[16].rr,175,130,275,150);
    bb[16].text = checkTime;
    bb[16].kind = ETEXTKIND;
    bb[16].ActionProc = NULL;

    TUTORset_rect(&bb[17].rr,5,170,170,190);
    bb[17].text = "Print command";
    bb[17].kind = STEXTKIND;
    bb[17].ActionProc = NULL;
    
	strcpy(printCmd,pprntr);
	TUTORset_rect(&bb[18].rr,175,170,325,190);
    bb[18].text = printCmd;
    bb[18].kind = ETEXTKIND;
    bb[18].ActionProc = NULL;

    dialog = TUTORstart_dialog(wn,&bounds,OTHERDIALOG,19,bb,0);
    retVal = TUTORrun_dialog(dialog);

	/* assemble preferences data record */
	
	if (retVal == 0) {
	
		/* allocate memory for preferences */
	
		prefPtr = (struct PrefRec FAR *)TUTORalloc((long)sizeof(struct PrefRec),FALSE,"pref");
		if (!prefPtr) {
			TUTORclose_dialog(dialog,TRUE);
			TUTORalert(wn,"No memory, can't save preferences");
			return(0);
		} 
	
		/* fill record with data from dialog */
		
		TUTORzero((char FAR *)prefPtr,(long)sizeof(struct PrefRec));
		strcpyf(prefPtr->prefID,"cTpref"); /* set magic string */
		TUTORgettext_dialog(dialog,3,fontName,40);
		TUTORgettext_dialog(dialog,5,fontSize,8);
		TUTORgettext_dialog(dialog,7,fontFace,40);	
		TUTORgettext_dialog(dialog,9,fColor,10);
		TUTORgettext_dialog(dialog,11,bColor,10);
		TUTORgettext_dialog(dialog,13,spaceTab,10);
		TUTORgettext_dialog(dialog,16,checkTime,12);
		TUTORgettext_dialog(dialog,18,printCmd,39);
		strcpy(prefPtr->fontFamily,fontName); /* font family */
		sscanf(fontSize,"%d",&prefPtr->fontSize); /* font size */
		prefPtr->fontFace = PrefFaceN(fontFace); /* font face */
		prefPtr->fcolor = PrefColorN(fColor); /* foreground color */
		prefPtr->bcolor = PrefColorN(bColor); /* background color */
		sscanf(spaceTab,"%d",&prefPtr->nTabs); /* spaces/tab */
		prefPtr->snapShot = TUTORgetvalue_dialog(dialog,14);
		sscanf(checkTime,"%ld",&prefPtr->checkTime); /* checkpoint frequency */
		strcpy(prefPtr->unix_printer,printCmd); /* print command */
	} /* retVal if */
    TUTORclose_dialog(dialog,TRUE);

	if (retVal) return(0); /* canceled */
    
	retVal = WritePrefs(prefPtr); /* write preferences file */
	TUTORdealloc(prefPtr); /* release memory */
	
	if (!retVal) {
		TUTORalert(wn,"Can't write preferences file");
		return(0);
	}

	/* do quit dialog */
	
	TUTORset_rect(&bounds,30,10,300,160);
    TUTORset_rect(&bb[0].rr,9,109,72,132);
    bb[0].text = "Quit";
    bb[0].kind = BUTTONKIND;
    bb[0].key = RETURN;
    bb[0].ActionProc = NULL;
    
    TUTORset_rect(&bb[1].rr,89,109,152,132);
    bb[1].text = "Cancel";
    bb[1].kind = BUTTONKIND;
    bb[1].key = 'n';
    bb[1].ActionProc = NULL;
   
    TUTORset_rect(&bb[2].rr,20,10,230,40);
    bb[2].text = "Your changes have been saved";
    bb[2].kind = STEXTKIND;
    bb[2].ActionProc = NULL;

	TUTORset_rect(&bb[3].rr,10,45,230,75);
    bb[3].text = "but will not take effect until you quit cT";
    bb[3].kind = STEXTKIND;
    bb[3].ActionProc = NULL;
    
    dialog = TUTORstart_dialog(wn,&bounds,OTHERDIALOG,4,bb,0);
    retVal = TUTORrun_dialog(dialog);
    TUTORclose_dialog(dialog,TRUE);
   
    if (retVal == 0) {

        /* post quit event to main edit window */
        
        TUTORzero((char FAR *)&cev,(long)sizeof(struct tutorevent));
        cev.window = EditWn[0];
        cev.view = EditVp[0];
        cev.type = EVENT_MENU;
        cev.a1 = edit_quit;
        cev.timestamp = 0;
        TUTORpost_event(&cev);
	}
    return(1);

} /* TUTORprefs_dialog */

#endif

/* ******************************************************************* */

static Memh TUTORstart_dialog(wn,bounds,kind,nItems,items,defaultB) /* set up dialog */
int wn; /* window where dialog will appear */
TRect *bounds; /* dialog bounds */
int kind;   /* the kind of dialog */
int nItems; /* # of dialog items */
DItem *items; /* the dialog items */
int defaultB;
/* returns dialog result */
    {
    DialogDat FAR *dp;
    Memh dialog, doc;
    int ii, jj, firstEdit, thick;
    TRect tempR;
    TextVDat FAR *vp;
    long sLen;
    long dLen;
    long esPos;
    long esLen;
    int tFont;
    long extraDumm;
    ButtonDat FAR *bp;
    struct tutorview FAR *cv; /* current (parent) view */
    struct tutorview FAR *scrollView;   /* view of scroll bar */
	int bKind; /* 0 = normal button, 1 = check button */
    
    /* set up areas */
    dialog = TUTORhandle("dialogdt",(long) sizeof(DialogDat),TRUE);
    dp = (DialogDat FAR *) GetPtr(dialog);
    dp->bounds = bounds;
    dp->dialogKind = kind;
    dp->nItems = nItems;
    dp->items = items;
    dp->defaultB = defaultB;
    dp->keyView = windowsP[wn].KeyFocus;
	dp->willCreate = FALSE;
    
    /* set up view */
    cv = TUTORinq_view();
    dp->view = TUTORinit_view(wn,dialog,procdialogstub); /* sets up view that takes whole window */
    TUTORset_view(dp->view); /* set to dialog's view */
    if (cv) {
        CTset_foreground_color(cv->fgndColor.palette); /* set to parent's colors */
        CTset_background_color(cv->bgndColor.palette);
        CTset_window_color(cv->winColor.palette);
    }
    dp->view->dialogV = TRUE;
    dp->view->caninput = FALSE; /* dialog shouldn't grab key/menu focus */
    tFont = TUTORget_zfont(DIALOGFONT,DIALOGFSIZE);
    TUTORset_textfont(tFont);

    firstEdit = -1; /* indicates no edit fields */

    for (ii = 0; ii < nItems; ii++) {
        items[ii].rr.left += bounds->left;
        items[ii].rr.top += bounds->top;
        items[ii].rr.right += bounds->left;
        items[ii].rr.bottom += bounds->top;

        switch (items[ii].kind) {
        case BUTTONKIND:
		case CHECKKIND:
		bKind = ((items[ii].kind == BUTTONKIND) ? 0: 1);
        items[ii].itemH = TUTORnew_button(wn,dialog,0,0,&items[ii].rr,
                bKind,1,tFont,strf2n(items[ii].text),HNULL,
                dialog,procdialogstub,BSIGNAL,ii,0.0,FALSE);
            items[ii].thick = 0; /* so dialog drawing doesn't draw border */
            bp = (ButtonDat FAR *) GetPtr(items[ii].itemH);
            bp->view->dialogV = TRUE;
            items[ii].view = bp->view;
            ReleasePtr(items[ii].itemH);
			if (bKind) /* set checkbox value */
				TUTORreset_button(items[ii].itemH,items[ii].value,-1,-1);
            break;
        case STEXTKIND:
            items[ii].thick = 0;
            items[ii].itemH = 0;
            items[ii].view = FARNULL;
            break;
        case ETEXTKIND:
            if (firstEdit < 0)
                firstEdit = ii;
            items[ii].thick = 1;
            tempR = items[ii].rr;
#ifdef KSWnomore
            tempR.top -= 3;
            tempR.left -= 3;
            tempR.right -= 2;
            tempR.bottom += 3;
#endif
            doc = TUTORnew_doc(TRUE,TRUE);
            EditorDefaultStyles(doc);
            sLen = strlenf(items[ii].text);
            TUTORchange_doc(doc,0L,0L,0L,0L,items[ii].text,sLen,0L,HNULL,HNULL,
                            &extraDumm,FALSE);
            jj = LEFTSTICK | TOPSTICK | RIGHTSTICK;
        items[ii].itemH = MakeTextPanel(wn,(long) dialog,0,0,&tempR,jj,
            tempR.right - tempR.left,TRUE,
                    doc,0L,sLen,FALSE,FALSE,FARNULL,FALSE,FALSE,FALSE,FALSE,
                    -1,-1,-1,TRUE,4);
            vp = (TextVDat FAR *) GetPtr(items[ii].itemH);
            vp->view->dialogV = TRUE;
            items[ii].view = vp->view;
            TUTORset_select_tview(vp->textv,sLen,0L,NEARNULL);
            TUTORmessage(vp->view,EVENT_FWD,TRUE);
            ReleasePtr(items[ii].itemH);
            break;
        case ESTEXTKIND:
            if (firstEdit < 0)
                firstEdit = ii;
            items[ii].thick = 1;
            tempR = items[ii].rr;
            doc = TUTORnew_doc(TRUE,TRUE);
            EditorDefaultStyles(doc);
            sLen = strlenf(items[ii].text);
            TUTORinsert_string_doc(doc,0L,items[ii].text,sLen);
            dLen = sLen;
            jj = LEFTSTICK | TOPSTICK | RIGHTSTICK | BOTTOMSTICK;
        items[ii].itemH = MakeTextPanel(wn,(long) dp->view,0,0,&tempR,jj,
                tempR.right - tempR.left,TRUE,doc,0L,dLen,TRUE,FALSE,KeyFilterDialog,
                TRUE,FALSE,FALSE,FALSE,-1,-1,-1,TRUE,4);
            vp = (TextVDat FAR *) GetPtr(items[ii].itemH);
            vp->view->dialogV = TRUE;
            items[ii].view = vp->view;
	    scrollView = TUTORinq_slider_view(vp->scrollv);
            scrollView->dialogV = TRUE;
            vp->ClickFilter = ESTextSelectstub;
            vp->ownerDat = dialog;
            (void)TUTORinq_select_line(vp->textv, 0, &esPos, &esLen);
            /* SetSelectPanel(vp, esPos, esLen); */
            SetSelectPanel(vp, esPos, 0L);
            TUTORmessage(vp->view,EVENT_FWD,FALSE);
            ReleasePtr(items[ii].itemH);
            break;

        }
    }
    if (firstEdit >= 0)
        { /* we have some edit text area */
        dp->curItem = firstEdit;
        /* tell edittext that it is active */
        TUTORset_view(items[dp->curItem].view);
        TUTORmessage(items[dp->curItem].view,EVENT_FWD,TRUE);
        }
    else
        {
        dp->curItem = defaultB;
        if (dp->items[defaultB].kind == BUTTONKIND) 
            { /* increase button thickness to 2 */
            bp = (ButtonDat FAR *) GetPtr(items[defaultB].itemH);
            bp->thick = 2;
            ReleasePtr(items[defaultB].itemH);
            }
        }
    dp->savedKeys[0] = '\0'; /* no saved keys yet */

    ReleasePtr(dialog);

    modalW = wn;
    TUTORset_view(cv); /* restore view */

    return(dialog);
    }

static TUTORrun_dialog(dialog)
Memh dialog;
    {
    DialogDat FAR *dp;
    char saveMask[2];
    TextVDat FAR *vp;
    int retVal, curKind;
    ButtonDat FAR *bp;
    Memh curH;
    int dWindow;    /* window the dialog is running in */
    int (*saveProc)();
    Memh saveProcDat;
    
    dp = (DialogDat FAR *) GetPtr(dialog);
    TUTORset_view(dp->view);

#ifdef SAVESCREEN
    /* save area of screen where dialog will go */
    /* use window # + 100 (since pulldown menus use window #) as region id */
    /* note that we could recover from lack of memory by redrawing window at dialog end */
        dp->savedRegion = TUTORabs_save_region(FARNULL,(long) dp->view->window+100L,
        dp->bounds->left,dp->bounds->top,dp->bounds->right,dp->bounds->bottom);
#endif

    TUTORdraw_dialog(dp,TRUE);
    dp->result = dp->partialResult = -1;
    
    dWindow = dp->view->window;
    
    /* set up window event mask */
    saveMask[0] = TUTORinq_event_mask(dWindow,EVENT_MENU);
    windowsP[dWindow].eventMask[EVENT_MENU] = FALSE;
    
    curKind = dp->items[dp->curItem].kind;
    curH = dp->items[dp->curItem].itemH;
    if (curKind == BUTTONKIND)
        { /* set focus to button view */
        bp = (ButtonDat FAR *) GetPtr(curH);
        TUTORset_key_focus(dWindow,bp->view,FALSE);
        ReleasePtr(curH);
        }
    else if (curKind == ETEXTKIND || curKind == ESTEXTKIND)
        { /* set key focus to text edit */
        vp = (TextVDat FAR *) GetPtr(curH);
        TUTORset_key_focus(dWindow,vp->view,FALSE);
        ReleasePtr(curH);
        }
    else /* set key focus to dialog itself */
        TUTORset_key_focus(dWindow,dp->view,FALSE);
    
    /* replace the window's event handler with the dialog "window" event handler */
    saveProc = windowsP[dWindow].wproc;
    saveProcDat = windowsP[dWindow].wH;
    windowsP[dWindow].wproc = procdialogwstub;
    windowsP[dWindow].wH = dialog;

    while (dp->result < 0) {
        ReleasePtr(dialog);
        TUTORflush();
        interact(TRUE);
        dp = (DialogDat FAR *) GetPtr(dialog);
    }
    
    /* restore the window's normal event handler */
    windowsP[dWindow].wproc = saveProc;
    windowsP[dWindow].wH = saveProcDat;
    
    retVal = dp->result;
    
    TUTORset_key_focus(dWindow,dp->keyView,FALSE); /* restore key focus */
    windowsP[dWindow].eventMask[EVENT_MENU] = saveMask[0];
    
    ReleasePtr(dialog);
    return(retVal);
    }

procdialogw(dialog,event)
Memh dialog;
struct tutorevent *event;
    {
    struct tutorview FAR *viewp;
    int wn; /* window of event */
    int ii, nitems;
    DialogDat FAR *dp;
    
    wn = event->window;
    
    switch (event->type)
        {

    case EVENT_REDRAW:
        TUTORclear_window(wn);
        dp = (DialogDat  FAR *) GetPtr(dialog);
        
        if (dp->dialogKind == FILEDIALOG) /* reset sizes of dialog items */
            {
            SizeReadfileDialog(wn,(TRect FAR *) (dp->bounds), (DItem FAR *) (dp->items),TRUE);
            for (ii=2; ii<4; ii++) /* move both buttons */
                TUTORmove_button(dp->items[ii].itemH,dp->items[ii].rr.left,
                        dp->items[ii].rr.top, dp->items[ii].rr.right,
                        dp->items[ii].rr.bottom);
            }
        ReleasePtr(dialog);
        KillPtr(dp);
        
        /* we could get rid of prochelpv by putting it here */
        viewp = windowsP[wn].lastView;
        while (viewp)
            {
            TUTORset_view(viewp);
            (*viewp->vproc) (viewp->vh,event);
            viewp = viewp->prevView;
            }
        event->type = -1; /* we handled it already */
        break;

    case EVENT_FWD:
        viewp = windowsP[wn].firstView;
        while (viewp)
            {
            TUTORset_view(viewp);
            (*viewp->vproc) (viewp->vh,event);
            viewp = viewp->nextView;
            }
        event->type = -1;
        break;
    
    case EVENT_FKEY:
    case EVENT_KEY:
        DialogKeys(dialog,event);
        event->type = -1; /* already used up the keys */
        break;
    
    case EVENT_LEFTDOWN:
    case EVENT_RIGHTDOWN:
        /* on click, change the current view */
        /* find new view */
        dp = (DialogDat FAR *) GetPtr(dialog);
        nitems = dp->nItems;
        for (ii=0; ii<nitems; ii++)
            if (event->view == dp->items[ii].view)
                break;
        ReleasePtr(dialog);
        KillPtr(dp);
        if (ii < nitems)
        ChangeFocusDialog(dialog,ii,TRUE,event);
        break;
        
        }  /* end of switch */

    /* send on events we didn't handle */
    if (event->type > 0 && event->view && event->view->dialogV)
        {
        TUTORset_view(event->view);
        (*event->view->vproc)(event->view->vh,event);
        }
    
    return;
    }

static int TUTORgetvalue_dialog(dialog,itemN)
Memh dialog;
int itemN; /* which item */

    {
    DialogDat FAR *dp;
	ButtonDat FAR *bp;
    int value;
    
    dp = (DialogDat FAR *) GetPtr(dialog);
    bp = (ButtonDat FAR *) GetPtr(dp->items[itemN].itemH);
	value = bp->value;
    ReleasePtr(dp->items[itemN].itemH);
    ReleasePtr(dialog);
    return(value);
    }

static TUTORgettext_dialog(dialog,itemN,cp,maxChar)
Memh dialog;
int itemN; /* which item */
char FAR *cp; /* put chars here */
int maxChar; /* maximum # of chars we can use */
    {
    DialogDat FAR *dp;
    TextVDat FAR *vp;
    long docLen;
    
    dp = (DialogDat FAR *) GetPtr(dialog);
    vp = (TextVDat FAR *) GetPtr(dp->items[itemN].itemH);
    docLen = TUTORget_len_doc(vp->textd);
    if (docLen >= maxChar)
        docLen = maxChar - 1;
    TUTORget_string_doc(vp->textd,0L,docLen,cp);
    
    ReleasePtr(dp->items[itemN].itemH);
    ReleasePtr(dialog);
    return(0);
    }

static TUTORclose_dialog(dialog,doRedraw)
Memh dialog;
int doRedraw;
    {
    DialogDat FAR *dp;
    struct tutorview FAR *viewp;
    int ii;
    int window;
    
    dp = (DialogDat FAR *) GetPtr(dialog);
    viewp = dp->view;
    window = viewp->window;
    ReleasePtr(dialog); /* release before close because close frees handle */
    TUTORclose_view(viewp); /* destroy view */

    modalW = -1; /* we aren't in modal state anymore */
    
    if (doRedraw)
        TUTORforce_redraw(window);
    
    return(0);
    }

procdialog(dialog,cev) /* handle events to dialog main view */
Memh dialog;
struct tutorevent *cev;
    {
    DialogDat FAR *dp;
    int ii, jj;
    TextVDat FAR *vp;
    struct tutorview FAR *viewp;
    ButtonDat FAR *bp;
    Memh eDoc;

    dp = (DialogDat FAR *) GetPtr(dialog);
    
    switch(cev->type)
        {
        case EVENT_SIGNAL:
            if ((cev->a1 == BSIGNAL) && (dp->items[cev->value].kind == BUTTONKIND)) {
                dp->result = cev->value; /* click in button cev->value */
                if (dp->items[dp->result].ActionProc) {
                    dp->result = dp->items[dp->result].ActionProc(dialog, dp->result);
                }
            }
            break;
        case EVENT_REDRAW:
            /* reset view & clip rect of base dialog view */
            TUTORset_abs_clip_rect((TRect FAR *) dp->bounds);
            TUTORset_abs_view_rect(dp->bounds->left,dp->bounds->top,
                    dp->bounds->right - dp->bounds->left + 1,
                    dp->bounds->bottom - dp->bounds->top + 1);
            TUTORdraw_dialog(dp,FALSE);
            break;
        case EVENT_KEY:
            break;
        case EVENT_DESTROY:
            TUTORdraw_abs_solid_rect(dp->bounds, PAT_WHITE);
            /* tell all edittext views to close */
            for (ii=0; ii<dp->nItems; ii++)
                {
                if (dp->items[ii].kind == ETEXTKIND
                    || dp->items[ii].kind == ESTEXTKIND)
                    {
                    vp = (TextVDat FAR *) GetPtr(dp->items[ii].itemH);
                    viewp = vp->view;
                    eDoc = vp->textd;
                    ReleasePtr(dp->items[ii].itemH);
                    TUTORclose_view(viewp);
                    mvar_temp_cleanup();
                    }
                else if ((dp->items[ii].kind == BUTTONKIND) || (dp->items[ii].kind == CHECKKIND))
                    {
                    TUTORclose_view(dp->items[ii].view);
                    }
                }
            break;
        }
    
    ReleasePtr(dialog);
    if (cev->type == EVENT_DESTROY)
        TUTORfree_handle(dialog);

    return(0);
    }

static TUTORdraw_dialog(dp,drawViews)
DialogDat FAR *dp;
int drawViews; /* if TRUE, draw items that are views */
    {
    int ii;
    
    /* draw dialog box */
    TUTORdraw_abs_solid_rect(dp->bounds, PAT_WHITE);
    TUTORframe_abs_rect(dp->bounds);
    for (ii=0; ii<dp->nItems; ii++)
        DrawItem(dp->items+ii,drawViews || (dp->items[ii].kind == STEXTKIND));
    TUTORflush();
    }

static DrawItem(ip,drawAll)
DItem *ip;
int drawAll; /* if TRUE, draw whole item (rather than just bounding box) */
    {
    int ii;
    TRect tr;
    
    /* always draw frame */
    if (ip->thick)
        {
        tr = ip->rr;
        for (ii=0; ii<ip->thick; ii++)
            {
            TUTORframe_abs_rect((TRect FAR *) &tr);
            TUTORinset_rect((TRect FAR *) &tr,1,1);
            }
        }
    
    
    if (drawAll)
        {
        if (ip->kind == STEXTKIND)
            { /* static text just get text shown */
            tr = ip->rr;
            TUTORinset_rect((TRect FAR *) &tr,ip->thick,ip->thick);
            TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
            TUTORabs_move_to(ip->rr.left+10,ip->rr.top+14);
            TUTORdraw_text((unsigned char FAR *) ip->text,(int)strlenf(ip->text));
            }
        else if (ip->kind == ETEXTKIND || ip->kind == ESTEXTKIND)
            { /* editable text needs to update text view */
            DrawPanel(ip->itemH);
            }
        else
            { /* buttons */
            TUTORdraw_button(ip->itemH);
            }
        }
    
    return(0);
    }

static DialogKeys(dialog,cev) /* handle keys for dialog "window" */
Memh dialog;
struct tutorevent *cev;
    {
    unsigned char cc;
    int saveN, ii;
    DialogDat FAR *dp;
    Memh bH;
    ButtonDat FAR *bp;
    int whichButton;
    struct tutorevent tempEv;
    
    if (!cev->view)
        return(0); /* just to be sure */
    
    if (cev->type == EVENT_FKEY)
        {
        if (cev->value == KBACKTAB)
            ShiftFocusDialog(dialog,-1);
        else
            { /* just send event on */
            TUTORset_view(cev->view);
            (*cev->view->vproc)(cev->view->vh,cev);
            }
        return(0);
        }
    
    /* EVENT_KEY from here on */
    for (ii=0; ii<cev->nkeys; ii++)
        {
        cc = cev->keys[ii];
        if (cc != NEWLINE && cc != '\t')
            { /* normal key, just send it on */
                /* but only process one key */
            saveN = cev->nkeys;
            cev->nkeys = 1;
            cev->keys[0] = cc;
            TUTORset_view(cev->view);
            (*cev->view->vproc) (cev->view->vh,cev);
            cev->nkeys = saveN;
            }
        else if (cc == '\t')
            { /* change the active view */
            ShiftFocusDialog(dialog,1);
            /* keep this event's focus current: */
            cev->view = windowsP[cev->view->window].KeyFocus;
            }
        else
            { /* this is as if a button was pressed.  If the current item is a button, it is
                that button.  Otherwise, it is the default button */
			TUTORzero((char FAR *)&tempEv,(long)sizeof(struct tutorevent));
            dp = (DialogDat FAR *) GetPtr(dialog);
            whichButton = (dp->items[dp->curItem].kind == BUTTONKIND) ?
                            dp->curItem : dp->defaultB;
            
            /* send a signal to dialog as if the default button was pressed */
            bH = dp->items[whichButton].itemH;
            bp = (ButtonDat FAR *) GetPtr(bH);
            tempEv.type = EVENT_SIGNAL;
            tempEv.window = -1; /* not sent to a window */
            tempEv.timestamp = 0;
            tempEv.eDataP = FARNULL;
            tempEv.a5 = (long) bp->destH;
            tempEv.vproc = bp->DestProc;
            tempEv.a1 = bp->destMsg;
            tempEv.a2 = bp->ebshdrH;
			tempEv.a6 = bp->ebsref;
			tempEv.a3 = bp->destMsg2;
            tempEv.value = bp->destMsg1;
			ReleasePtr(dp->items[whichButton].itemH);
            TUTORpost_event(&tempEv);
            ReleasePtr(dialog);
            }
        }       /* end of nkeys loop */
    
    return(0);
    }

static ShiftFocusDialog(dialog, nChange)
Memh dialog;
int nChange; /* 1 or -1, the direction we should change item */
    {
    DialogDat FAR *dp;
    int newItem;
    
    dp = (DialogDat FAR *) GetPtr(dialog);
    
    /* figure out which is the new current item */
    newItem = dp->curItem+nChange;
    while (TRUE)
        { /* we need to scan items to skip static text */
        if (newItem >= dp->nItems)
            newItem = 0;
        else if (newItem < 0)
            newItem = dp->nItems-1;
        if (dp->items[newItem].kind != STEXTKIND)
            break;
        newItem += nChange;
        }
    
    ReleasePtr(dialog);
    ChangeFocusDialog(dialog,newItem,FALSE,NEARNULL);
    
    return(0);
    }

static ChangeFocusDialog(dialog,newItem,isClick,event)
Memh dialog;
int newItem;
int isClick;    /* TRUE if change is because of click */
struct tutorevent *event;
    {
    DialogDat FAR *dp;
    int oldItem;
    TextVDat FAR *vp;
    unsigned char tempS[FILEL+2];
    int len, promptlen, ii;
    unsigned char breakC;
    long edummy;
    struct tutorevent tempEv;
    struct tutorview FAR *cv;
    long docLen;
    
    dp = (DialogDat FAR *) GetPtr(dialog);
    if (isClick && ((dp->items[newItem].kind == BUTTONKIND) || 
          (dp->items[newItem].kind == CHECKKIND)))
        { /* we don't change focus to buttons on a click */
        ReleasePtr(dialog);
        return(0);
        }
    
    /* make newItem the new curItem */
    
    /* first deactivate old item */
    oldItem = dp->curItem;
    ActivateDialogItem(dp,oldItem,FALSE);
    dp->curItem = newItem;
    ActivateDialogItem(dp,newItem,TRUE);
    
    if (dp->dialogKind == FILEDIALOG && oldItem == 0)
        { /* we moved focus away from prompt line in file dialog.
            Change the prompt line to the directory of the list and
            search the list for the nearest string */
        
        /* figure out string for match */
        vp = (TextVDat FAR *) GetPtr(dp->items[0].itemH);
        len = TUTORget_string_doc(vp->textd,0L,(long) FILEL+2L,tempS);
#ifdef IBMPC
        breakC = '\\';
#else
        breakC = '/';
#endif
        if (tempS[len-1] != breakC)
            { /* was a file name, scroll to it */
            for (ii=len-1; ii>0; ii--)
                if (tempS[ii] == breakC)
                    {
                    ii++; /* so we don't include break char in string */
                    break;
                    }
        
            /* now replace text of prompt */
            promptlen = strlenf(dp->items[0].text);
            docLen = TUTORget_len_doc(vp->textd);
            TUTORchange_doc(vp->textd,0L,docLen,0L,docLen,
                (unsigned char FAR *) dp->items[0].text,(long) promptlen,
                0L,HNULL,HNULL,&edummy,FALSE);
            cv = TUTORinq_view();
            TUTORset_view(vp->view);
            RestartPanel(vp,0L,(long) promptlen,(long) promptlen,0L);
            TUTORset_view(cv);
        
            ReleasePtr(dp->items[0].itemH);
        
            /* do search for match string
                do this by mocking up an appropriate key event */
            tempEv.type = EVENT_KEY;
            tempEv.timestamp = dp->lastKeyTime + 1000; /* don't add to saved keys */
            tempEv.nkeys = len - ii;
            if (tempEv.nkeys > 15)
                tempEv.nkeys = 15;
            strncpy(tempEv.keys,tempS+ii,tempEv.nkeys);
        
            KeyFilterDialog((long) dialog,dp->items[1].itemH,&tempEv);
            }
        else
            {
        ReleasePtr(dp->items[0].itemH);
        if (dp->dialogKind == FILEDIALOG && newItem == 1 && isClick &&
        event)
        ESTextSelect((Memh)dialog,dp->items[1].itemH,event);
            }
        }
    
    ReleasePtr(dialog);
    TUTORflush(); /* make sure drawing happens */
    
    return(0);
    }

static ActivateDialogItem(dp,item,onoff)
DialogDat FAR *dp;
int item;
int onoff;
    {
    int kind;
    Memh itemH;
    ButtonDat FAR *bp;
    struct tutorview FAR *viewp;
    
    kind = dp->items[item].kind;
    itemH = dp->items[item].itemH;
    if (kind == BUTTONKIND) 
        {
        bp = (ButtonDat FAR *) GetPtr(itemH);
        bp->thick = onoff ? 2 :1;
        TUTORset_view(bp->view);
        if (onoff)
            TUTORset_key_focus(bp->view->window,bp->view,FALSE);
        ReleasePtr(itemH);
        TUTORdraw_button(itemH);
        }
    else if (kind == ETEXTKIND || kind == ESTEXTKIND)
        {
    viewp = dp->items[dp->curItem].view;
        if (onoff)
            TUTORset_key_focus(viewp->window,viewp,FALSE);
    TUTORset_view(viewp);
        TUTORmessage(viewp,EVENT_FWD,onoff);
        }
    
    return(0);
    }

static KeyFilterDialog(dViewH,textv,cev)
long dViewH; /* handle on dialog structure */
Memh textv; /* handle to ktxtview of text panel */
struct tutorevent *cev; /* the key event structure */
/* returns TRUE if we used key, FALSE otherwise */
    {
    int ii, jj;
    DialogDat FAR *dp;
    DocP docp;
    int retVal;
    long foundPos, endPos, docLen;
    long pos,len;
    unsigned char tempS[NSAVEKEYS+3];
    TextVDat FAR *vp;
    struct tutorevent tempEv;
    ButtonDat FAR *bp;
    struct tutorview FAR *cv;
    int whichButton;
    int kind;
    Memh itemH;
    long sLen;
    
    dp = (DialogDat FAR *) GetPtr((Memh)dViewH);
    
    if (dp->dialogKind != FILEDIALOG || dp->curItem != 1)
        { /* we didn't see anything we cared about */
        ReleasePtr((Memh) dViewH);
        return(FALSE); /* we didn't use up the keys */
        }
    
    /* create a string with a newline in it */
    tempS[0] = NEWLINE;
    tempS[1] = '\0';
    
    if (cev->type == EVENT_FKEY)
        {
        vp = (TextVDat FAR *) GetPtr(dp->items[1].itemH);
        TUTORinq_select_tview(vp->textv,&pos,&len);
        /* the only fkeys we care about are uparrow & downarrow */
        docp = (DocP) GetPtr(vp->textd);
        docLen = docp->totLen;
        if (cev->value == KDOWN)
            { /* search for newline following our line */
            pos = pos+len+1; /* position after our line */
            if (pos < docLen)
                {
                foundPos = TUTORsearch_string_doc(docp,(unsigned char FAR *) tempS,
                    1L,pos,docLen);
                if (foundPos > 0)
                    {
                    len = foundPos - pos;
                    }
                else
                    pos = -1;
                }
            else
                pos = -1;
            }
        else if (cev->value == KUP)
            {
            /* search for newline before the one just before our line */
            pos--;; /* just before preceeding newline */
            if (pos > 0)
                {
                foundPos = TUTORsearch_string_doc(docp,(unsigned char FAR *) tempS,
                    1L,pos,0L);
                if (foundPos > 0)
                    {
                    len = pos - (foundPos+1);
                    pos = foundPos+1;
                    }
                else
                    pos = -1;
                }
            else
                pos = -1;
            }
        else
            pos = -1; /* we don't care about other fkeys */
        
        ReleasePtr(vp->textd);
        if (pos > 0)
            {
            SetSelectPanel(vp,pos,len);
            }
        ReleasePtr(dp->items[1].itemH);
        ReleasePtr((Memh) dViewH);
        
        return(TRUE); /* we used up FKEY */
        }
    
    /* for file dialog (with focus on list) find the first item starting with this letter,
        appended to saveKeys if it was "soon enough" */

    vp = (TextVDat FAR *) GetPtr(dp->items[1].itemH);
    
    if (dp->savedKeys[0] && cev->timestamp < dp->lastKeyTime+500)
        { /* key was quick enough, add to saved keys */

        /* null terminate event characters */   
        if (cev->nkeys >= 16)
            { /* we lose at least one character... */
            cev->keys[15] = '\0';
            cev->nkeys = 15;
            }
        else
            cev->keys[cev->nkeys] = '\0';
        
        /* add event characters to saved characters */
        ii = strlenf((char FAR *) (dp->savedKeys));
        if (ii + cev->nkeys > NSAVEKEYS)
            { /* don't add too many keys */
            cev->keys[NSAVEKEYS-ii] = '\0'; /* just clip off extras */
            }
        strcatf((char FAR *) (dp->savedKeys),(char FAR *) (cev->keys));
        }
    else
        { /* greater than half-second, too long.  Overwrite saved keys */
        if (cev->nkeys > 15)
            cev->nkeys = 15; /* so null termination works */
        cev->keys[cev->nkeys] = '\0';
        strcpyf((char FAR *) (dp->savedKeys),(char FAR *) (cev->keys));
        }
    dp->lastKeyTime = cev->timestamp;
    
    /* the text panel is stored in dp->items[1].itemH */
    docp = (DocP) GetPtr(vp->textd);
    strcatf((char FAR *) tempS,(char FAR *) (dp->savedKeys));
    docLen = TUTORget_len_doc(vp->textd);
    sLen = strlenf((char FAR *) tempS);
    foundPos = TUTORsearch_string_doc(docp,(unsigned char FAR *) tempS,
            sLen,0L,docLen);
    if (foundPos >= 0)
        { /* we found something with right first letter, find end of line */
        foundPos++; /* so we skip preceeding newline */
        endPos = TUTORsearch_string_doc(docp,(unsigned char FAR *) tempS,1L,
            foundPos,docLen);
        if (endPos < 0)
            endPos = docLen;  /* last line doesn't end in NEWLINE? */
        }
    ReleasePtr(vp->textd);
    
    if (foundPos >= 0)
        { /* set selection */
        cv = TUTORinq_view();
        TUTORset_view(vp->view);
        SetSelectPanel(vp, foundPos, endPos-foundPos);
        TUTORset_view(cv);
        }
    ReleasePtr(dp->items[1].itemH);
    ReleasePtr((Memh)dViewH);
    
    return(TRUE); /* we use all the keys here */
    }
            
/* ******************************************************************* */

static int haveCMessg = 0;

StartCompileMsg(wn)
int wn;
    
{   int ii;
    int bTop,bRight;
    TRect tr;
    int tFont;

    /* draw dialog box */
    if (haveCMessg) return(0);
    bTop = windowsP[wn].wysize - 60;
    bRight = windowsP[wn].wxsize - 60;
    TUTORset_rect(&tr,30,bTop,bRight,bTop+30);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr, PAT_WHITE);
    for (ii=0; ii<3; ii++) {
        TUTORframe_abs_rect((TRect FAR *) &tr);
        TUTORinset_rect((TRect FAR *) &tr,-1, -1);
    }

    TUTORabs_move_to(35,bTop+14);
    tFont = TUTORget_zfont(DIALOGFONT,DIALOGFSIZE);
    TUTORset_textfont(tFont);
    TUTORdraw_text((unsigned char FAR *) "Compiling:",10);
    haveCMessg = 1;
    TUTORflush();

} /* StartCompileMsg */
            
/* ******************************************************************* */

EditCompileMsg(wn,ms)
int wn;
char *ms;
    
{   int bTop,bRight;
    TRect tr;
    int tFont;

    if (!haveCMessg) return(0);
    bTop = windowsP[wn].wysize - 60;
    bRight = windowsP[wn].wxsize - 60;
    TUTORset_rect(&tr,115,bTop+1,bRight-1,bTop+28);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr, PAT_WHITE);
    TUTORabs_move_to(117,bTop+14);
    tFont = TUTORget_zfont(DIALOGFONT,DIALOGFSIZE);
    TUTORset_textfont(tFont);
    TUTORdraw_text((unsigned char FAR *) ms,strlen(ms));
    TUTORflush();

} /* EditCompileMsg */
                
/* ******************************************************************* */

EndCompileMsg(wn)
int wn;
    
{
    if (!haveCMessg) return(0);
    if (wn == EditWn[0]) /* executor erases screen */
        TUTORforce_redraw(wn);
    haveCMessg = 0;

} /* EndCompileMsg */
                
/* ******************************************************************* */

Memh TUTORnew_button(wn,owner,objH,objR,tr,kind,thick,bFont,title,titleD,destH,DestProc,destMsg,
                     destMsg1,destMsg2,erase)
int wn; /* window where button will appear */
Memh owner; /* where we send our filter messages */
Memh objH; /* handle on object header */
int objR; /* object reference count */
TRect *tr; /* where button goes */
int kind; /* button kind 0: normal, 1: check, 2: radio */
int thick; /* thickness of button */
int bFont; /* font label should be drawn in */
char *title; /* label on button */
Memh titleD; /* handle on document containing label on button */
Memh destH; /* data for "button pressed" signal */
int (*DestProc) (); /* proc for "button pressed" signal */
int destMsg, destMsg1; /* message for "button pressed" signal */
double destMsg2; /* message for "button pressed" signal */
int erase; /* TRUE if we should erase this button on destruction */
    {
    Memh bH;
    ButtonDat FAR *bp;
    int ii, asc, desc, leading, height, insx;
    struct tutorview FAR *cv;
	TRect eR;
	long docLen;
	int maxX,maxY;
	int multiLine;
	TRect savClip;
	TRect tmpClip;
	short styles[NSTYLES];

    bH = TUTORhandle("buttndat",(long) sizeof(ButtonDat),TRUE);
    if (!bH)
        return(0);

    bp = (ButtonDat FAR *) GetPtr(bH);
	TUTORzero((char FAR *)bp,(long)sizeof(ButtonDat));
    bp->button_is_up = 0;
    /* set up view */
    bp->view = TUTORinit_view(wn,bH,procbuttonstub);
    cv = TUTORinq_view();
    TUTORset_view(bp->view);
    TUTORset_abs_view_rect(tr->left,tr->top,tr->right - tr->left + 1,tr->bottom - tr->top + 1);
    if (cv) {
       CTset_foreground_color(cv->fgndColor.palette); /* set to parent's colors */
       CTset_background_color(cv->bgndColor.palette);
    }
	if (bFont < 0) 
		bFont = textFont0;
	if (titleD)
		bp->titleDoc = titleD;
    bp->view->caninput = FALSE;
    bp->ebshdrH = objH;
    bp->ebsref = objR;
    bp->thick = thick;
    bp->bFont = bFont;
    bp->state = 1; /* draw normally */
    bp->eraseF = erase;
    bp->ecolor = winColor.palette; /* erase in current window color */
    bp->value = 0;
    strncpyf(bp->title,(char FAR *) title,MAXTITLE);
    bp->title[MAXTITLE] = '\0';
    bp->destH = destH;
    bp->DestProc = DestProc;
    bp->destMsg = destMsg;
    bp->destMsg1 = destMsg1;
    bp->destMsg2 = destMsg2;
    bp->owner = owner;
    insx = 0; /* dont know inset yet */
    TUTORset_textfont(bFont);
 
 	if (bp->titleDoc) {

		/* figure out where text should be */
		
    	switch (kind) {
    	case RADIOBUTTON:
    	case CHECKBOXBUTTON:    
    	case THREEDBUTTON:
        	insx = 16; /* adjustment for inset */
        	break;
    	default:
        	break;
    	} /* switch */     

    	/* force text to be centered if no paragraph style */
    	
    	docLen = TUTORget_len_doc(bp->titleDoc);
    	for(ii=0; ii<NSTYLES; ii++)
    		styles[ii] = DEFSTYLE;
        tdoc_getstyles(bp->titleDoc,0L,styles);
        if (styles[PARASTYLE] == DEFSTYLE) {
        	TUTORstyle_doc(bp->titleDoc,0L,docLen,PARASTYLE,CENTERJUST,0,NEARNULL);
        }
        
        /* plot and measure the text */
        
		savClip = tgclipR; /* save clip rectangle */
		tmpClip.left = tmpClip.top = 0;
		tmpClip.right = tmpClip.bottom = 0;
		TUTORset_abs_clip_rect((TRect FAR *) &tmpClip); /* clip everything */
		eR = *tr;
		/* TUTORinset_rect((TRect FAR *)&eR,3,3); */
    	multiLine = write_abs_text(bp->titleDoc,0L,docLen,eR.left+insx,eR.top,&eR,TRUE,&maxX,&maxY);
    	TUTORinq_font_info(&asc,&desc,NEARNULL,&leading);
    	height = 1+maxY-eR.top;
    	bp->tx = insx;
    	if (multiLine) {
    		bp->ty = ((eR.bottom-eR.top+1)-height)/2;
    	} else {
    		height -= leading+desc;
    	   	bp->ty = ((eR.bottom-eR.top+1)-height)/2;
    	} /* multiLine else */

    	if (bp->ty < 0) bp->ty = 0;
    	TUTORset_abs_clip_rect((TRect FAR *)&savClip); /* restore clip */
 	} else {
 	
 	    /* figure out where text should be */

    	switch (kind) {
    	case RADIOBUTTON:
    	case CHECKBOXBUTTON:    
    	case THREEDBUTTON:
        	insx = 3; /* adjustment for inset */
        	break;
    	default:
        	break;
    	} /* switch */  
    	
    	/* measure text */
    	    
    	TUTORinq_abs_string_width((unsigned char FAR *) title, strlen(title),&ii);
    	bp->tx = ((((tr->right-insx)-(tr->left+insx))+1) - ii) >> 1;
    	TUTORinq_font_info(&asc,&desc,NEARNULL,NEARNULL);
    	bp->ty = asc + ((tr->bottom - tr->top+1) - (asc+desc))/2;
    }

    bp->kind = kind;

    ReleasePtr(bH);

    /* draw the button */
    TUTORdraw_button(bH);
    TUTORset_view(cv); /* restore the view */

    return(bH);
    }

/* ******************************************************************* */

int TUTORset_button_font(bH) /* set to button font */
Memh bH; /* handle on button info */

{	ButtonDat FAR *bp;
	int tFont;
 
	bp = (ButtonDat FAR *) GetPtr(bH);
	tFont = bp->bFont;
	ReleasePtr(bH);
	TUTORset_textfont(tFont);
	return(tFont);
	
} /* TUTORset_button_font */

/* ******************************************************************* */

TUTORreset_button(bH, value, aFlag, eraseF)
Memh bH;
/* each flag can be -1: (ignore) 0,1: new value */
int value;
int aFlag;
int eraseF;
    
{   REGISTER ButtonDat FAR *bp;
    int redraw;
    
    redraw =  FALSE;
    bp = (ButtonDat FAR *) GetPtr(bH);
    bp->button_is_up = 0;
    if (value != -1) {
        bp->value = (value == 1);
        redraw = TRUE;
    }
    if (aFlag != -1) {
        bp->state = (aFlag == 1);
        redraw = TRUE;
    }
    if (eraseF != -1)
        bp->eraseF = (eraseF == 1);
    
    ReleasePtr(bH);
    KillPtr(bp);
    
    if (redraw)
        TUTORdraw_button(bH);

} /* TUTORreset_button */

/* ******************************************************************* */

struct tutorview FAR *TUTORinq_button_view(bH)
Memh bH; /* handle on button info */

{   ButtonDat FAR *bP;
    struct tutorview FAR *bV;

    if (!bH)
		return(FARNULL);
    bP = (ButtonDat FAR *)GetPtr(bH);
    bV = bP->view;
    ReleasePtr(bH);
    return(bV);

} /* TUTORinq_button_view */

/* ******************************************************************* */

int TUTORinq_button_value(bH) /* get current value of button */
Memh bH;
    
{   ButtonDat FAR *bp;
    int value;
    
    bp = (ButtonDat FAR *) GetPtr(bH);
    if (bp->ebshdrH)
    	value = bp->exValue; /* use executor's copy of value */
    else
    	value = bp->value;
    ReleasePtr(bH);
    return(value);
    
} /* TUTORinq_button_value */

/* ******************************************************************* */
    
int TUTORupdate_button_value(objH) /* update executor value of button */
Memh objH; /* handle on cT object header */

/* executor keeps a separate copy of the button value which is */
/* updated when the EVENT_SIGNAL reaches the executor - this way */
/* zvalue(..) stays in synch with button unit execution */

{	struct ebshdr FAR *objP; /* pointer to cT object header */
    Memh bH; /* handle on button info */
    ButtonDat FAR *bp; 

    if (!objH) return(0);
    objP = (struct ebshdr FAR *)GetPtr(objH);
    bH = objP->objectH; /* handle on button data */
    ReleasePtr(objH);
    if (!bH) return(0);
    bp = (ButtonDat FAR *)GetPtr(bH);
    bp->exValue = bp->value; /* update executor's copy of value */
    ReleasePtr(bH);
    return(1);
    
} /* TUTORupdate_button_value */

/* ******************************************************************* */

TUTORmove_button(bH, left, top, right, bottom) /* change button position, don't redraw */
Memh bH;
int left;
int top;
int right;
int bottom;
    {
    ButtonDat FAR *bp;
    struct tutorview FAR *cv;
    TRect rect;


    rect.bottom = bottom;
    rect.top = top;
    rect.left = left;
    rect.right = right;
    
    bp = (ButtonDat FAR *) GetPtr(bH);

    cv = TUTORinq_view();
    TUTORset_view(bp->view);
    TUTORset_abs_clip_rect((TRect FAR *)&rect);
    TUTORset_abs_view_rect(left,top,right-left,bottom-top);
    TUTORset_view(cv);

    ReleasePtr(bH);
    return(0);
    }

TUTORclose_button(bH) /* close button */
Memh bH;
    {
    ButtonDat FAR *bp;
    struct tutorview FAR *bv;

    bp = (ButtonDat FAR *) GetPtr(bH);
    bv = bp->view;
    ReleasePtr(bH);

    TUTORclose_view(bv); /* this will call procbutton with destroy message */
    return(0);
    }



/* these are the routines to show the various buttons being pressed. */
CThighlight_normal_button(bp)
ButtonDat FAR *bp;
{
    int ii;
    TRect tr;
    int svcolor;

    tr = bp->view->rr;
    /* erase what's currently there */
    TUTORinset_rect((TRect FAR *) &tr,3,3);
    svcolor = bgndColor.palette; /* save current background color */
    CTset_background_color(bp->ecolor);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
    CTset_background_color(svcolor);
    
    /* draw button where "shadow" was before*/
    TUTORmove_rect((TRect FAR *) &tr,3,3);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
  
	bp->ty += 3;
	bp->tx += 3;
  	draw_button_text(bp);
	bp->ty -= 3;
	bp->tx -= 3;
    for (ii=0; ii<bp->thick; ii++)
        {
        TUTORframe_abs_rect((TRect FAR *) &tr);
        TUTORinset_rect((TRect FAR *) &tr,-1,-1);
        }

    if (!bp->state)
        { /* grey out button by erasing with grey */
        TUTORabs_erase_rect(&tr, patternFont0, 8);
        }

}

CThighlight_checkbox_button(bp)
ButtonDat FAR *bp;
{
  ;
}

CThighlight_radio_button(bp)
ButtonDat FAR *bp;
{
  ;
}

CThighlight_3D_button(bp)
ButtonDat FAR *bp;
{
 ;
}

CThighlight_button (bH)
Memh bH;
{
    ButtonDat FAR *bp;

    bp = (ButtonDat FAR *) GetPtr(bH);
/*    if (bp->button_is_up == 1) {  */
        bp->button_is_up = 0;
        switch (bp->kind) {
            case NORMALBUTTON:
                CThighlight_normal_button(bp);
                break;
            case RADIOBUTTON:
                CThighlight_radio_button(bp);
                break;
            case CHECKBOXBUTTON:
                CThighlight_checkbox_button(bp);
                break;
            case THREEDBUTTON:
                CThighlight_3D_button(bp);
                break;
        }
 /* }  */
    ReleasePtr (bH);
}

procbutton(bH,event)    /* event processor buttons */
Memh bH;
struct tutorevent *event; /* event to process */
    {
    ButtonDat FAR *bp;
    struct tutorevent cev;
    char hitC;
    int sendHit, ii;
    TRect tr;
    int svcolor;

    sendHit = FALSE;
    switch(event->type)
        {
        case EVENT_REDRAW:
            TUTORdraw_button(bH);
            break;

        case EVENT_DOWNMOVE:
            bp = (ButtonDat FAR *) GetPtr(bH);
            tr = bp->view->rr;
            /* are we still in the button rectangle? */
            if (!(event->x >= tr.left && event->x <= tr.right &&
                event->y >= tr.top && event->y <= tr.bottom))
            /* no, so redraw the button up if need be */
                TUTORdraw_button(bH);
            else
                CThighlight_button (bH);
            ReleasePtr (bH);
            break;

        case EVENT_LEFTUP:
            bp = (ButtonDat FAR *) GetPtr (bH);
            tr = bp->view->rr;
            if (event->x >= tr.left && event->x <= tr.right &&
                event->y >= tr.top && event->y <= tr.bottom)
                    sendHit = TRUE;
            ReleasePtr (bH);
            TUTORdraw_button(bH);
            break;

        case EVENT_LEFTDOWN:
            CThighlight_button(bH);
            break;

        case EVENT_DESTROY:
            bp = (ButtonDat FAR *) GetPtr(bH);
            if (bp->eraseF) { /* erase the button */
                tr = bp->view->rr;
                svcolor = bgndColor.palette; /* save background color */
                CTset_background_color(bp->ecolor);
                TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
                CTset_background_color(svcolor);
            }
            ReleasePtr(bH);
            KillPtr(bp);
            TUTORfree_handle(bH);
            break;
            
        default:
            break;
        }
    
    if (sendHit)
        { /* tell destination that button has been hit */
        bp = (ButtonDat FAR *) GetPtr(bH);
        if (bp->state)
            { /* enabled button */
			TUTORzero((char FAR *)&cev,(long)sizeof(struct tutorevent));
            cev.type = EVENT_SIGNAL;
            cev.window = -1; /* not sent to a window */
            cev.a5 = (long) bp->destH;
            cev.timestamp = 0;
            cev.eDataP = FARNULL;
            cev.vproc = bp->DestProc;
            cev.a1 = bp->destMsg;
            cev.a2 = bp->ebshdrH;
			cev.a6 = bp->ebsref;
            cev.a3 = bp->destMsg2;
            cev.value = bp->destMsg1;
            TUTORpost_event(&cev);
            bp->value = !bp->value;
            TUTORdraw_button(bH);
            }
        ReleasePtr(bH);
        }

    return(0);
    }

/* ******************************************************************* */

static void draw_button_text(bp)
ButtonDat FAR *bp;

{   long docLen;
    int maxX,maxY;
    TRect tr;
   
    TUTORset_textfont(bp->bFont);
    tr = bp->view->rr;
    TUTORabs_move_to(tr.left+bp->tx,tr.top+bp->ty);
    if (bp->titleDoc) {
    	docLen = TUTORget_len_doc(bp->titleDoc);
    	write_abs_text(bp->titleDoc,0L,docLen,tr.left+bp->tx,tr.top+bp->ty,&bp->view->rr,TRUE,&maxX,&maxY);
    } else {
    	TUTORdraw_text((unsigned char FAR *) bp->title,strlenf((char FAR *) bp->title));
    }

} /* draw_button_text */

/* ******************************************************************* */

/* determine what kind of button it is, and dispatch
 * the pointer to the appropriate drawing routine.
 */
TUTORdraw_button(bH)
Memh bH;
    {
    ButtonDat FAR *bp;

    bp = (ButtonDat FAR *) GetPtr(bH);
/*    if (bp->button_is_up == 0) {  */
        bp->button_is_up = 1;
        switch (bp->kind) {
            case NORMALBUTTON:
                TUTORdraw_normal_button(bp);
                break;
            case RADIOBUTTON:
                TUTORdraw_radio_button(bp);
                break;
            case CHECKBOXBUTTON:
                TUTORdraw_checkbox_button(bp);
                break;
            case THREEDBUTTON:
                TUTORdraw_3D_button(bp);
                break;
        }
/*    }  */
    ReleasePtr (bH);
}

TUTORdraw_normal_button(bp)
ButtonDat FAR *bp;
{
    int ii;
    TRect tr;

    tr = bp->view->rr;
    /* erase what's currently there */
    TUTORinset_rect((TRect FAR *) &tr,3,3); 
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
    
    /* draw "shadow" */
    TUTORmove_rect((TRect FAR *) &tr,3,3);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
    TUTORfill_abs_rect((TRect FAR *) &tr,patternFont0,8);
    TUTORmove_rect((TRect FAR *) &tr,-3,-3);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
    
	draw_button_text(bp);
	
    for (ii=0; ii<bp->thick; ii++)
        {
        TUTORframe_abs_rect((TRect FAR *) &tr);
        TUTORinset_rect((TRect FAR *) &tr,-1,-1);
        }

    if (!bp->state)
        { /* grey out button by erasing with grey */
        TUTORabs_erase_rect(&tr, patternFont0, 8);
        }
    }


TUTORdraw_3D_button(bp)
ButtonDat FAR *bp;
{
    int ii;
    TRect tr;

    tr = bp->view->rr;
    /* erase what's currently there */
/*  TUTORinset_rect((TRect FAR *) &tr,-3,-3); */
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
    TUTORinset_rect((TRect FAR *) &tr,3,3);
    CTset_foreground_color (0);
    TUTORfill_abs_rect ((TRect FAR *) &tr, patternFont0, 8);


    /* 3-D style button. */
    TUTORframe_abs_rect((TRect FAR *) &tr);
    tr.top += 3;
    tr.left += 3;
/*    TUTORdraw_abs_solid_rect((TRect FAR *) &tr, PAT_BLACK);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_BLACK);
/*  TUTORfill_abs_rect ((TRect FAR *) &tr, patternFont0, 16);
    CTset_foreground_color (bp->view->fgndColor.palette);
    tr.top -= 3;
    tr.left -= 3;
    for (ii = 0; ii < 3; ii++) {
        TUTORabs_move_to (tr.left + ii, tr.bottom - ii);
        TUTORabs_line_to (tr.right - ii, tr.bottom - ii);
        TUTORabs_line_to (tr.right - ii, tr.top + ii);
    }


    /* draw "shadow" */
/*  TUTORmove_rect((TRect FAR *) &tr,3,3);
    TUTORfill_abs_rect((TRect FAR *) &tr,patternFont0,8);
    TUTORmove_rect((TRect FAR *) &tr,-3,-3);
    TUTORfill_abs_rect((TRect FAR *) &tr,patternFont0,8);*/
    
    TUTORabs_move_to(tr.left+bp->tx,tr.top+bp->ty);
    TUTORset_textfont(bp->bFont);
    TUTORdraw_text((unsigned char FAR *) bp->title,strlenf((char FAR *) bp->title));
 /* for (ii=0; ii<bp->thick; ii++)
        {
        TUTORframe_abs_rect((TRect FAR *) &tr);
        TUTORinset_rect((TRect FAR *) &tr,-1,-1);
        }
 */
    if (!bp->state)
        { /* grey out button by erasing with grey */
        TUTORabs_erase_rect(&tr, patternFont0, 8);
        }
}

TUTORdraw_radio_button(bp)
ButtonDat FAR *bp;
{
    int ii, fontindex;
	long fontid;
    TRect tr;

    tr = bp->view->rr;
    /* erase what's currently there */
/*  TUTORinset_rect((TRect FAR *) &tr,-3,-3); */
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
    TUTORinset_rect((TRect FAR *) &tr,3,3);
    
    /* draw the rectangle frame (just for me) */
    /* TUTORframe_abs_rect((TRect FAR *) &tr); */

    TUTORabs_move_to(tr.left + 10, tr.top + (tr.bottom - tr.top) / 2);
    fontid = TUTORinq_symbolic_font_id("zicons");
    fontindex = TUTORget_font2(fontid, 0, 0,0);
    if (bp->value)
        TUTORdraw_graphic_icons(fontindex, "TB", 2);
    else
        TUTORdraw_graphic_icons(fontindex, "T", 2);
/*    TUTORabs_move_to(tr.left + 23,tr.top+bp->ty - 3);
    TUTORset_textfont(bp->bFont);
    TUTORdraw_text((unsigned char FAR *) bp->title,strlenf((char FAR *) bp->title));
*/
	draw_button_text(bp);

    if (!bp->state)
        { /* grey out button by erasing with grey */
        TUTORabs_erase_rect(&tr, patternFont0, 8);
        }
    }

TUTORdraw_checkbox_button(bp)
ButtonDat FAR *bp;
{
    int ii, fset = 2, ascent, descent, w, leading, height;
    TRect tr;
    TRect cbx;

    tr = bp->view->rr;
    /* erase what's currently there */
/*  TUTORinset_rect((TRect FAR *) &tr,-3,-3); */
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
    TUTORinset_rect((TRect FAR *) &tr,3,3);

    /* draw the rectangle frame (just for me) */
    /* TUTORframe_abs_rect((TRect FAR *) &tr);     */

    /* draw the check box */
    TUTORinq_font_info (&ascent, &descent, &w, &leading);
    height = ascent; /* + descent + leading;    */
    cbx.top = (tr.bottom + tr.top) / 2 - height / 2;
    cbx.bottom = (tr.bottom + tr.top) / 2 + height / 2;
    cbx.left = tr.left + height / 4;
    cbx.right = cbx.left + height;

/*  cbx.top = tr.top + fset;
    cbx.bottom = tr.bottom - fset;
    cbx.left = tr.left + fset;
    cbx.right = cbx.left + (cbx.bottom - cbx.top); */
    TUTORframe_abs_rect((TRect FAR *) &cbx);

    if (bp->value) {
        /* draw the X in the box */
        TUTORabs_move_to (cbx.left, cbx.top);
        TUTORabs_line_to (cbx.right, cbx.bottom);
        TUTORabs_move_to (cbx.right, cbx.top);
        TUTORabs_line_to (cbx.left, cbx.bottom);
    }

 /*   TUTORabs_move_to(cbx.right + fset + 3, tr.top+bp->ty - 3);
    TUTORset_textfont(bp->bFont);
    TUTORdraw_text((unsigned char FAR *) bp->title,strlenf((char FAR *) bp->title));
*/
	draw_button_text(bp);
	
    if (!bp->state)
        { /* grey out button by erasing with grey */
        TUTORabs_erase_rect(&tr, patternFont0, 8);
        }
    }

OpenFileDialog(dialog, itemN) /* handle click in open button for file dialog */
Memh dialog;
int itemN;
{
/* 0 is the item with the path,
   1 is the item with the files */
    int retVal;
    DialogDat FAR *dp;
    TextVDat FAR *vp1;
    TextVDat FAR *vp2;
    long sPos, sLen, extraDumm;
	int fileid;
    char ss[256];
    char path[1024];
#ifdef UNIX_SYS
    char opath[1024];
#endif
    char FAR *text;
    long pathLen;
    FileRef fref;
    char breakC[2];
    long docLen;

    dp = (DialogDat FAR *)GetPtr(dialog);
    
    /* what is the current item. If curItem is 0 we will use the edited path.  Otherwise
        we will use the saved path in item[0].text along with the selected item from the
        list */
    
    if (dp->curItem == 0) { /* editable path is current, use it */
        vp1 = (TextVDat FAR *) GetPtr(dp->items[0].itemH);
        TUTORget_string_doc(vp1->textd,0L,TUTORget_len_doc(vp1->textd),(unsigned char FAR *) path);
        ReleasePtr(dp->items[0].itemH);
        ss[0] = '\0';
    } else { /* use list */
        vp1 = (TextVDat FAR *)GetPtr(dp->items[1].itemH);
        
        /* get the original, unedited path */
        strcpyf((char FAR *)path, dp->items[0].text);
        
        /* get the desired item */
        (void)TUTORinq_select_tview(vp1->textv,&sPos,&sLen);
        TUTORget_string_doc(vp1->textd,sPos,sLen,(unsigned char FAR *) ss);
        strcat(path, ss);
        ReleasePtr(dp->items[1].itemH);
    }

    /* convert the path string to a fileref */
    TUTORcvt_path(path,(FileRef FAR *) &fref,FARNULL,TRUE);

    switch (TUTORinq_is_dir((FileRef FAR *) &fref)) {
        case -1:    /* an error occurred */
			if (dp->willCreate) { /* check if should create file */
				strcpyf(dp->items[0].text,(char FAR *)path);
				fileid = TUTORopen((FileRef FAR *)&fref,FALSE,TRUE,FALSE);
    			if (fileid) {
        			TUTORset_file_type((FileRef FAR *) &fref,fileid,1, -10000,-10000);
        			TUTORclose(fileid); /* close new file */
					retVal = 2; /* open file */
					break;
				} /* fileid if */
			} /* willCreate if */
            TUTORbeep(NEARNULL, NEARNULL, NEARNULL, 0);
            retVal = -1;
            break;

        case 0:     /* a plain file */
            strcpyf(dp->items[0].text,(char FAR *)path);
            retVal = 2; /* the Open button */
            break;
        case 1:     /* a directory */
#ifdef UNIX_SYS
            if (!strcmp(ss,"..")) {
                if (!getwd(opath)) {
                    TUTORbeep(NEARNULL, NEARNULL, NEARNULL, 0);
                    break;
                }
                if (chdir(path)) {
                    (void)chdir(opath);
                    TUTORbeep(NEARNULL, NEARNULL, NEARNULL, 0);
                    break;
                }
                if (!getwd(path)) {
                    /* Ick! */
                }
                if (chdir(opath)) {
                    /* Really ick! */
                }
            }
#endif
#ifdef IBMPC
        pathLen = strlen(fref.path);
        if (pathLen && (fref.path[pathLen-1] == '.')) {
        /* current or parent directory */
        pathLen--; /* back up one period */
        if (fref.path[pathLen-1] == '.') { /* parent dir */
            if (fref.path[pathLen-2] == '\\')
            pathLen -= 2; /* remove period and backslash */
            while (pathLen && (fref.path[pathLen-1] != '\\') &&
               (fref.path[pathLen-1] != ':'))
            pathLen--; /* back over parent directory */
        }
        if (pathLen && (fref.path[pathLen-1] == '\\'))
            fref.path[pathLen-1] = '\0'; /* remove backslash */
        strcpy(path,fref.path); /* correct for top line display */
        }
#endif

#ifdef UNIX_SYS
            breakC[0] = '/';
#else
            breakC[0] = '\\';
#endif
        breakC[1] = '\0';

#ifdef IBMPC
        pathLen = strlen(fref.path);
        if ((pathLen == 0) ||
        ((pathLen == 1) && ((fref.path[0] == '\\') || (fref.path[0] == ':'))) ){
        fref.path[0] = fref.drive+'A'-1;
        fref.path[1] = ':';
        fref.path[2] = '\\';
        fref.path[3] = '\0';
        strcpy(path,fref.path);
        }
#endif

        text = TUTORread_dir((FileRef FAR *) &fref);
        if (text == FARNULL) {
        text = TUTORalloc(4L,TRUE,"dir");
        strcpyf(text,(char FAR *)breakC);
        }
        vp1 = (TextVDat FAR *) GetPtr(dp->items[1].itemH);
        SetSelectPanel(vp1,0L,0L);
            TUTORset_view(vp1->view);
            docLen = TUTORget_len_doc(vp1->textd);
            TUTORchange_doc(vp1->textd,0L,docLen,0L,docLen,
                text,(long)strlenf(text),0L,HNULL,HNULL,&extraDumm,FALSE);
            RestartPanel(vp1, 0L, TUTORget_len_doc(vp1->textd),0L, 0L);
            SetSelectPanel(vp1, 0L, 0L);
            TUTORdispose_dir(text);
            ReleasePtr(dp->items[1].itemH);

        strcpyf(dp->items[0].text,(char FAR *)path);

        pathLen = strlen(path);
        if (pathLen && (path[pathLen-1] != breakC[0])) {
        strcatf((char FAR *)path,(char FAR *) breakC);
        pathLen++;
        }
            strcpyf(dp->items[0].text,path); /* we are in trouble if pathlen > FILEL+3 */
            
            vp2 = (TextVDat FAR *)GetPtr(dp->items[0].itemH);
        TUTORset_view(vp2->view);
        SetSelectPanel(vp2,0L,0L);
            docLen = TUTORget_len_doc(vp2->textd);
            TUTORchange_doc(vp2->textd,0L,docLen,0L,docLen,
                (unsigned char FAR *) path,pathLen,0L,HNULL,HNULL,&extraDumm,FALSE);
        RestartPanel(vp2, 0L,(long) pathLen,(long)pathLen, 0L);
        SetSelectPanel(vp2,(long)pathLen,0L);
            ReleasePtr(dp->items[0].itemH);
            
            retVal = -1;
        break;

        default:
            TUTORdump("TUTORinq_is_dir");
            break;
    }

    ReleasePtr(dialog);
    
    return retVal; /* sets dp->result way up there to -1 */
}

ESTextSelect(dialog, edH, event) /* handle click in scrolling text for file dialog */
Memh dialog, edH;
register struct tutorevent *event;
{
    long sPos, sLen, doublePos, doubleLen;
    short oldX, oldY;
    TextVDat FAR *vp;
    DialogDat FAR *dp;
    int retVal;
    
    if (event->type != EVENT_LEFTDOWN) return TRUE;
    
    vp = (TextVDat FAR *)GetPtr(edH);
    (void)TUTORinq_select_line(vp->textv, event->y, &sPos, &sLen);
    if (TUTORdouble_click(&oldX,&oldY))
        { /* this may be double click, see if it is in the same line */
        TUTORinq_select_line(vp->textv,oldY,&doublePos,&doubleLen);
        if (doublePos == sPos)
        { /* double click in a line, act like open */
        sPos = -1; /* no need to set select */
            retVal = OpenFileDialog(dialog, 2);
            if (retVal > -1)
                { /* we got plain file, we're done */
                /* set dialog result so that dialog finishes */
                dp = (DialogDat FAR *) GetPtr(dialog);
                dp->result = retVal;
                ReleasePtr(dialog);
                }
            }
    }
    if (sPos >= 0)
    SetSelectPanel(vp, sPos, sLen);
    ReleasePtr(edH);
    
    return TRUE;
}
               
/* ******************************************************************* */

int get_button_ref(objH) /* get reference count from button */
Memh objH; /* handle on cT object header */

{   struct ebshdr FAR *objP; /* pointer to cT object header */
    Memh bH; /* handle on button info */
    ButtonDat FAR *bp;
    int refcnt;

    if (!objH) return(0);
    objP = (struct ebshdr FAR *)GetPtr(objH);
    bH = objP->objectH; /* handle on button data */
    ReleasePtr(objH);
    if (!bH) return(0);
    bp = (ButtonDat FAR *)GetPtr(bH);
    refcnt = bp->ebsref; /* get reference count (unique id) */
    ReleasePtr(bH);
    return(refcnt);
    
} /* get_button_ref */

/* ******************************************************************* */

TUTORinput_dialog() { return(-1); }

/* ******************************************************************* */
