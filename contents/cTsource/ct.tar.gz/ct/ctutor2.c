
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Part of the command compiler.
*/

#include <stdio.h>
#include "ctutor.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "txt.h"
#include "exprdefs.h"
#include "yacc.h"
#include "ct_ctype.h"
#include "fkeys.h"

#ifdef ctproto
extern int TUTORlog(char *mmss);
extern int valid_style(int sN);
static int compile_video_tag(struct keywdinf *videoList);
extern int compile_unit_and_arg(void);
extern int TUTORdump(char *msg);
extern int TUTORtrace_n(char *str,long val);
extern int tstda(int opc);
extern int cmpbuf_long(long vv);
extern int compile_long_value(long vv);
int  compile2(void);
int  pbscan(unsigned char  FAR *str,int  indx,char *target);
int  compile_short_value(int  vv);
int  compile_float_value(double  vv);
int  compile_float(void);
int  compile_simple_numeric(int  nmask,int  fmask,int  stopl);
int  compile_general(struct  expra *exps,int  nmin,int  nmax);
int  compile_marker(int  storef,int  semic);
int  compile_file(int  storef);
int  compile_txtype(int  type,int storef);
int  skip_white_cB(void);
int  next_cB(void);
int  extract_keyword_cB(char  *kname,int  maxl,int  spaces,int  *term);
int  extract_touch_keywords(int  *ttrm,int  stopC,int  simpleF);
int  identify_keys_equal(void);
int  identify_key_name(int  *tbits,int  *term);
int  compile_multiple_keywords(struct  keywdinf *klist);
int  compile_single_keyword(struct  keywdinf *klist,int  *term);
int  identify_keyword(struct  keywdinf *klist,int  *term);
int  compile_keyword_and_args(struct  keywdinf *klist,int  *term);
int  compile_points(int  min,int  limit,int  type,int  stopl,int  cont,int  czxy,
             int  blank,int  coarse,int  skip);
extern int  compile_write(int  contin,int condtl);
extern int  CheckSimpleWrite(unsigned int  doc,long  pos,long  len);
extern int  compile_text(void);
int  compile_general_text(int  terminator,int  trim,int  begin);
extern long  tdoc_diffstyle(unsigned int  theD,long  baseP);
int  tdoc_getstyles(unsigned int  theD,long  pos,short  *styles);
int  compile_embed(int  docOrBuff);
int  cmpbuf_write_cmd(int  code);
extern int  cmpbuf_string(int  len,long  loc,int  newlf);
extern int  textpool_string(long  len,long  loc);
int  extract_unit(char  *unitn,int  *term,int  iFlag);
int  cmpbuf_plant_word(unsigned int  addr,int  n);
int  cmpbuf_word(int  n);
int  cerror(int  errnumber,char  *execstr);
int  compile(struct  expra *exap);
int  add_dest(int  type,int  label,unsigned int  pos);
int  satisfy_xref(int  index,int  kind,int  label,unsigned int  adest);
int  cmpbuf_xref(int  kind,int  label);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
long  TUTORget_len_doc(unsigned int  doc);
int  FindArrowIndent(void);
int  compile_ubranch(int  kind,int  label);
int  compile_cbranch(int  logic,int  kind,int  label);
int  add_xref(int  kind,int  label,unsigned int  aref,unsigned int  adest);
int  plant_xref(int  iref,unsigned int  adest);
int  cmpbuf_flt(double  d);
extern int strncmpf(char FAR *aa,char FAR *bb,int nn);
int  compile3(void);
struct  keywdinf *GetKeyNames(void);
int  RefillBuffer(void);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
int  appenddoc(unsigned int  theDoc,char  FAR *sP,int  sLen);
char  FAR *GetPtr(unsigned int  mm);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  AtTStyle(unsigned int  pd,long  pos,short  *styles);
int  FindBlockTStyle(struct  _pdt FAR *pp,long  pos);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
int  MatchUnitName(unsigned char  *name);
extern int cmp_mem_free(void);
extern int cmp_mem_lock(void);
#endif /* ctproto */

#ifdef IBMPC
extern char *strcpy(char *aa, char *bb);
#endif


extern long TUTORget_len_doc();
extern char *strf2n();
extern long tdoc_diffstyle();
extern struct keywdinf *GetKeyNames();

static struct keywdinf afterlist[7] = { {"key",1}, 
       {"left down",2}, {"left up",3}, {"right down",4}, {"right up",5}, 
       {"down move",6}, {NULL,0} };

static struct keywdinf inhiblist[18] = { {"reset",0},{"erase",INHERASE},{"arrow",INHARROW},
       {"anserase",INHANSERASE},{"blanks",INHBLANKS}, /* {"jkeys",5}, */ {"display",INHDISPLAY},
       {"startdraw",INHSTARTDRAW},{"update",INHUPDATE},{"supsubadjust",INHSUPSUB}, /* {"pixpalette",10}, */
       {"objdelete",INHOBJDEL}, {"degree",INHDEGREE}, {"optionmenu",INHOPTION}, {"buttonfont",INHBFONT}, 
       {"objects",INHOBJECT}, {"editdraw",INHEDITD}, {"fuzzyeq",INHFUZZY}, {NULL,0} };

static struct keywdinf specslist[15] = { {"clear",0} ,{"nomark",1},{"nookno",2},
       {"noops",3},{"nospell",4},{"okcap",5},{"okextra",6},
       {"okspell",7},{"punc",8},{"noorder",9},{"novars",10},
       {"okassign",11},{"okcaps",5},{"okorder",9}, {NULL,0} };
/* note synonyms:  okcaps = okcap, okorder = noorder */

static struct keywdinf judgelist[12] = { {"ok",1},{"wrong",2},{"no",3},
       {"unjudge",4},{"exit",5},{"ignore",6},{"quit",7},
       {"okquit",8},{"noquit",9},{"exdent",10},{"rejudge",11}, {NULL,0} };

static struct keywdinf modelist[6] = { {"write",1},{"rewrite",2},{"erase",3},{"inverse",4},{"xor",5},{NULL,0} };

static struct keywdinf videolist[2] = { {"movie",2}, {NULL,0} };
       
static struct keywdinf videolist1[12] = { {"no scale",1}, {"scale",2}, {"center",3}, 
       {"play",4}, {"controller",5}, {"ctrl",5}, {"range",6}, {"sound",7}, {"ctrl rect",8}, 
       {"loop",9}, {"palette",10}, {NULL,0} };

static struct keywdinf vsetlist[14] = { {"rectangle",0}, {"rect",0}, {"no scale",1},
       {"scale",2}, {"center",3}, {"play",4}, {"controller",5}, {"ctrl",5}, {"range",6}, 
       {"sound",7}, {"ctrl rect",8}, {"loop",9}, {"palette",10}, {NULL,0} };

static struct keywdinf enablelist[3] = { {"touch",1},{"ext",2},{NULL,0} };

static struct keywdinf embedlist[18] = { {"cr",-1},{"tab",-2},{"quote",-3},
       {"s",C_SHOW},{"show",C_SHOW},{"t",C_SHOWT},{"showt",C_SHOWT},
       {"e",C_SHOWE},{"showe",C_SHOWE},{"z",C_SHOWZ},{"showz",C_SHOWZ},
       {"b",C_SHOWB},{"showb",C_SHOWB},{"o",C_SHOWO},{"showo",C_SHOWO},
       {"h",C_SHOWH},{"showh",C_SHOWH}, {NULL,0} };

static struct keywdinf servlist[5] = { {"absolute",0}, {"logical",1}, {"local",2}, 
     /*  {"appletalk",3}, */ {"ptp",4}, {NULL,0} };

static struct keywdinf seriallist[4] = { {"even",0}, {"odd",1}, {"none",2}, {NULL,0} };

static struct keywdinf movelist[3] = { {"icon",0}, {"icons",0}, {NULL,0} };

static struct keywdinf colorlist[5] = { {"rgb",0}, {"hsv",1}, {"rgb palette",2}, 
                                        {"hsv palette",3}, {NULL,0} };

static struct keywdinf ddelist[9] = { {"servers",1}, {"topics",2}, { "items",3},
                                      {"connect",4}, {"request",5},
                                      {"advise",6}, {"poke",7}, {"execute",8}, {NULL,0} };

static long txt_src_start;  /* position of last write in source */
static long txt_src_len;    /* length of last write */
static long txt_pool_start; /* position of write in text pool */
static long txt_pool_len;   /* length of write in text pool */
static int txt_embed;  /* TRUE if embed in last write */
static int txt_lastc;  /* terminating char of last write (0 or NEWLINE) */
static int txt_end;    /* command code for end of continued write */
                       /* C_ENDTEXT, C_ENDTEXT1... */
#define TXT_OPTMAX 3 /* max number command locations saved */  
static short txt_optn; /* number command locations saved */
static unsigned int txt_optp[TXT_OPTMAX]; /* saved command locations */
static int set_type; /* expression type for -set- command */

static short nPalette; /* number of slots in current set of palette commands */
static unsigned int nPaletteWhere; /* position in cmpbuf where we are planting nPalette */

extern int oldCmnd; /* compin */

/* ******************************************************************* */

compile2() {
int i, j, k, argcount;
int nvargs,naargs; /* number value, address args */
long loc, iInd,iInd2;
char c, ws[NAMEL+1];
int termc;
struct expra wkexa; /* scratch analyzer params */
struct expra exas[4];
int term; /* terminating character */
int bits; /* bits for enable/disable etc */
int indentlv; /* command indent level */
struct arg_desc FAR *adp; /* pointer to argument descriptor */
int valuef; /* TRUE if processing value args, false if address args */
long svst; /* saved start of expression in source */
int coarsef; /* TRUE if coarse grid allowed */
int cosyst; /* co-ordinate system: 0 = absolute, 1 = relative, 2 = graph */
int thislabel; /* internal branch label to satisfy */
struct indenter *idP; /* pointer to indent table entry */
struct locref *xrP; /* pointer to cross-reference table entry */
int lindext; /* loop index type */
int lfloatf; /* non-zero (mask) if index variable is float */
int linc1; /* TRUE if integer increment-by-1 */
int lconstf; /* TRUE if loop begin, end, inc all constant */
long lcbegin; /* constant loop begin value */
long lcend; /* constant loop end value */
long lcinc; /* constant loop increment value */
long len;
long dummy;
int itemonly; /* item-only flag for -menu- */
unsigned short FAR *cmpsp; /* pointer in cmpbuf */
int balanceC; /* balancing character - ) or ] */

switch(newcmd) {

case C_ARROW:
case C_RARROW:
case C_GARROW:
    /* indent info at indentlevel-1 (arrow0kind pushed after arrowkind) */
    /* indicate we are in post-arrow indented code */
    indent[indentlevel-1].lastif = 0;
    if (newcmd == C_ARROW) {
        cosyst = 0; /* absolute co-ordinates */
        coarsef = TRUE; /* coarse grid allowed */
    } else {
        coarsef = FALSE;
        if (newcmd == C_RARROW) cosyst = 1;
        else if (newcmd == C_GARROW) cosyst = 2;
    } 
    compile_points(1,2,cosyst,FALSE,FALSE,FALSE,1,coarsef,FALSE);
    break;

case C_IFMATCH:
    /* arrow info at indentlevel-1 (anskind already pushed) */
    idP = &indent[indentlevel-1];
    if (idP->lastif > 1)
        cerror(EXTRAIFMATCH,NEARNULL);
    /* satisfy forward ref to ifmatch */
    thislabel = xrefP[idP->headref].label;
    satisfy_xref(idP->headref,R_ARROW1,thislabel,
                 (unsigned int)cmpl);
    add_dest(RD_IFMATCH,thislabel,cmpl); /* mark this point in binary */
    idP->nextlabel = 0; /* mark label satisfied */
    /* indicate we are in -ifmatch- indented code */
    idP->lastif = 2; 
    cmpbuf_xref(R_ARROW2,thislabel+1); /* forward ref to endarrow */
    break;

case C_ENDARROW:
    /* indent info at indentlevel+1 because it is already popped */
    idP = &indent[indentlevel+1];
    thislabel = xrefP[idP->headref].label;
    /* satisfy forward refs to ifmatch if not already satisfied */
    if (idP->nextlabel) {
        satisfy_xref(indent[indentlevel+1].headref,R_ARROW1,thislabel,
                    (unsigned int)cmpl);
        add_dest(RD_IFMATCH,thislabel,cmpl);
    }
    /* satisfy forward refs to endarrow */
    satisfy_xref(indent[indentlevel+1].headref,R_ARROW2,thislabel+1,
                 (unsigned int)cmpl);
    add_dest(RD_ENDARROW,thislabel+1,cmpl); /* mark this point in binary */
    break;

case C_PREANS: /* psuedo-command for start of answer */
    chkeol = FALSE;
    indent[indentlevel].nextlabel = thislabel = labelID++;
    cmpbuf_xref(R_PREANS,thislabel); /* forward ref to endans */
    break;

case C_ENDANS: /* psuedo-command for end of answer or ifmatch */
    chkeol = FALSE;
    /* arrow info at top of stack, answer info popped (indentlevel+1) */
    if ((i = FindArrowIndent()) > 0 && (indent[i].lastif > 1)) {
        /* this is for an ifmatch: don't want ENDANS executed */
        /* or get infinite loop */
        addcmd = -1; /* no command code in binary */
    } /* lastif if */
    /* insert C_ENDANS if needed, mark dest to break compiled */
    /* code block */
    if (addcmd >= 0) cmpbuf_word(C_ENDANS);
    add_dest(RD_ENDANS,indent[indentlevel+1].nextlabel,cmpl); 
    /* satisfy forward reference from preans or ifmatch */
    satisfy_xref(indent[indentlevel].headref,R_PREANS,
                 indent[indentlevel+1].nextlabel,
                 (unsigned int)cmpl);
    addcmd = -1; /* command code(s) already added */
    break;

case C_PALETTE:
case C_NEWPAL:
    usesColor |= 3;
    skip_white_cB();
    if (cB[cI] == NEWLINE) { /* blank tag form */
    	/* compile command here & make addcmd -1 so that we won't be repeatable */
        cmpbuf_word(C_NEWPAL); /* always compile as -newpal- */
        addcmd = -1;
        break;
    }
        
    /* check for "palette screen;screen variable" form */
    
	loc = pbscan(cB,cI,";"); /* look for semicolon */
	iInd = pbscan(cB,cI,","); /* look for comma */
	if ((loc < 0) && (iInd < 0) && (addcmd == C_PALETTE)) {
		compile_marker(FALSE,FALSE);
		addcmd = C_FPALETTE;
		break;
	} else if (loc >= 0) { /* found a semicolon */
		if ((iInd < 0) || (iInd > loc)) { /* no comma, or follows semicolon */
			loc = cI;
			extract_keyword_cB(ws,32,FALSE,&term); /* extract possible "screen" */
			if ((term == ';') && (strcmp(ws,"screen") == 0)) {
				cerror(SPECIFICERR,"Use palette file name form");
			}
		}
	}
    if (!continFlag)
        { /* start of new -palette- or -newpal- */
        nPalette = 0;
        nPaletteWhere = cmpl+2;
        }
    
    /* put in a 0.  For the first palette command of a sequence this will be
        a placeholder for the # of entries.  For continued palette commands the
        0 will be an indication of continuation */
    compile_short_value(0);
    
    /* compile arguments */
    if (!continFlag)
        { /* is this array type or simple type? */
        
        /* compile slot expression to determine if array */
        /* then back up and prepare to compile slot again */
        
        svst = cI; /* save position in source */
        loc = cmpl; /* save position in binary */
        iInd = unittab[compunit].nrefs; /* save number branch points */
        wkexa = defexp; 
        wkexa.arrayok = TRUE; /* allow unindexed array */
        wkexa.reqstore = TRUE;
        compile(&wkexa); /* compile first expression */
        i = wkexa.warray; /* TRUE if undimensioned array */
        cI = svst; /* back up to slot expression */
        cmpl = loc; /* restore position in binary */
        unittab[compunit].nrefs = iInd;
        
        compile_short_value(i); /* undimensioned array flag */
        if (i)
            { /* compile rest of arrays */
            for (j=0; j<7 && wkexa.lastchar != NEWLINE; j++)
                {
                compile(&wkexa);
                if (xtP[wkexa.exprtype].array != 2)
                    cerror(SPECIFICERR,"In array type palette command all arguments should be arrays.");
                }
            
            /* plant a -1 where we keep # of palette entries to indicate arrays */
            cmpbuf_plant_word(nPaletteWhere,-1);
            
            /* compile the command here & make addcmd -1 so that we won't repeat this command */
            cmpbuf_word(newcmd);
            addcmd = -1;
            /* note that the number of palette entries was left as 0 */
            break;
            }
        
        /* if we get here it is not an array type */
        term = compile_simple_numeric(0x80,0x00,TRUE); /* compile slot */
        if (newcmd == C_NEWPAL || term != NEWLINE)
            term = compile_simple_numeric(0x3c,0xe0,FALSE);
        /* else it was just a palette command with only the slot argument */
        }
    else
        { /* must be continued simple type */
        compile_short_value(0); /* not array form */
        term = compile_simple_numeric(0x80,0x00,TRUE); /* compile slot */
        if (newcmd == C_NEWPAL || term != NEWLINE)
            term = compile_simple_numeric(0x3c,0xe0,FALSE); /* compile the rest */
        /* else it was a palette command with only the slot argument */
        }
    
    /* plant the new # of entries */
    nPalette++;
    cmpbuf_plant_word(nPaletteWhere,nPalette);
    break;

case C_WEBPAL:
	skip_white_cB();
	break;

case C_RGB:
case C_HSV:
    usesColor |= 1;
    compile_simple_numeric(0x19c,0x70,FALSE);
    break;

case C_COLOR:
    usesColor |= 1;
    skip_white_cB(); /* skip leading white space */
 
    /* determine basic form of color command - palette, or rgb/hsv */
    
    valuef = FALSE; /* pre-set for palette form */
    i = pbscan(cB,cI,","); /* check if comma present */
    if (i >= 0) {
    	i = pbscan(cB,i+1,","); /* check if a second comma */
    	if (i >= 0)
    		valuef = TRUE;
    }
    if (valuef) { /* rgb/hsv form */
    	argcount = 0;
    	do {
    		if ((argcount == 0) && (cB[cI] == ';')) { /* fgnd arg not present */
    			cI++; /* advance past semicolon */
    			skip_white_cB();
    			term = ';';
    			compile_short_value(4); /* 4 = no value */
    		} else {
    			j = 0; /* 0 = search entire color space */
    			i = identify_keyword(colorlist,&term);   
    			if (i == 0) i = 2; /* rgb */
    			else if (i == 1) i = 3; /* hsv */
    			else if (i == 2) j = 1; /* rgb search in palette */
    			else if (i == 3) j = 1; /* rgb search in palette */
    			compile_short_value(i); /* 2 = rgb, 3 = hsv */
    			compile_short_value(j); /* 0 = search sys colors, 1 = search palette */
    			if (term != ',')
    				cerror(NEEDCOMMA,NEARNULL);
    			compile_simple_numeric(0x40,0xc0,TRUE);
    			wkexa = defexp;
            	wkexa.rtype = TFLOAT; /* require floating result */
            	wkexa.tsemic = TRUE; /* allow termination on semicolon */
            	compile(&wkexa); /* evaluate numeric expression */
            	term = wkexa.lastchar;
            	if ((term != NEWLINE) && (term != ';'))
            		cerror(NEEDSEMI,NEARNULL);
    		}
    		argcount++;
    	} while ((term == ';') && (argcount < 2));
    } else { /* palette form */
    	if ((cB[cI] == ',') || (cB[cI] == ';')) {
        	cI++; /* advance past comma */
        	compile_short_value(0); /* 1st arg not present */
        	compile_simple_numeric(0x80,0x00,FALSE); 
    	} else {
        	compile_short_value(1); /* 1st arg present */
        	wkexa = defexp;
            wkexa.rtype = TINT; /* require integer result */
            wkexa.tsemic = TRUE; /* allow termination on semicolon */
            compile(&wkexa); /* evaluate numeric expression */
            term = wkexa.lastchar;
            if (term != NEWLINE) /* second argument present */
        		compile_simple_numeric(0x80,0x00,FALSE);
    	}
    }
    break;

case C_WCOLOR:
    usesColor |= 1;
    skip_white_cB(); /* skip leading white space */
 
    /* determine basic form of wcolor command - palette, or rgb/hsv */
    
    valuef = FALSE; /* pre-set for palette form */
    i = pbscan(cB,cI,","); /* check if comma present */
    if (i >= 0) 
    	valuef = TRUE;
    if (valuef) { /* rgb/hsv form */
    	i = identify_keyword(colorlist,&term);   
    	if (i == 0) i = 2; /* rgb */
    	else i = 3; /* hsv */
    	compile_short_value(i);
    	term = compile_simple_numeric(0xe0,0xe0,FALSE);
    } else { /* palette form */
        compile_short_value(1); /* palette form */
        compile_simple_numeric(0x80,0x00,FALSE);
    }
    break;
    
case C_WTITLE:
	compile_marker(FALSE,FALSE);
	break;

case C_GETRGB:
case C_GETHSV:
    /* decide whether this is a slot-based getrgb
        slot ; slotn , red , green , blue
      or an absolute getrgb
        hue , sat , val ; red , green , blue */
    
    i = pbscan(cB,cI,";"); /* position of semicolon */
    if (i < pbscan(cB,cI,","))
        { /* semicolon is first, must be slot-based */
        i = TRUE; /* slot-based flag */
        compile_short_value(i);
        k = 4; /* # of address arguments we want */
        }
    else
        { /* absolute (semicolon is after commas) */
        i = FALSE; /* slot-based flag */
        compile_short_value(i);
        /* compile 2 floats */
        j = compile_simple_numeric(0x40,0xc0,TRUE);
        k = 3; /* # of address arguments we want */
        }
    
    /* now compile the argument that terminates with a semicolon */
    wkexa = defexp;
    wkexa.tsemic = TRUE;
    wkexa.tcomma = FALSE;
    wkexa.rtype = i ? TINT : TFLOAT;
    compile(&wkexa);
    
    /* set up to compile address arguments */
    for (i=0; i<k; i++)
        {
        exas[i] = defexp;
        exas[i].reqstore = TRUE;
        }
    
    /* compile them */
    compile_general(exas,k,k);
    
    /* make sure they were all storable */
    
    for (i=0; i<k; i++)
        if (!exas[i].canstore)
            cerror(NOTSTORABLE,NEARNULL);
    
    break;
    
#ifdef KSWnomore
    wkexa = defexp;
    wkexa.rtype = TINT; /* require integer expression */
    wkexa.tsemic = TRUE; /* allow semicolon terminator */
    compile(&wkexa); /* palette index expression */
    i = (wkexa.lastchar == ';'); /* TRUE if slot based getrgb */
    compile_short_value(i);
    if (i)
    { /* slot based */
        wkexa = defexp;
        wkexa.reqstore = TRUE; /* store-ability info required */
        for (i=0; i<4; i++) {
            compile(&wkexa);
            if (!wkexa.canstore) cerror(NOTSTORABLE,NEARNULL);
        } /* for */
    } else
    { /* explicit */
        /* get the next two value arguments */
        wkexa.rtype = TFLOAT;
        wkexa.tsemic = FALSE; /* second can't have semicolon as terminator */
        compile(&wkexa);
        wkexa.tsemic = TRUE; /* for third, semicolon is only legal terminator */
        wkexa.tcomma = FALSE;
        compile(&wkexa);
        
        /* now get three address arguments */
        wkexa = defexp;
        wkexa.reqstore = TRUE; /* we will need storeability info */
        for (i=0; i<3; i++)
        {
            compile(&wkexa);
            if (!wkexa.canstore)
                cerror(NOTSTORABLE,NEARNULL);
        }
    }

    break;

#endif

case C_PRESS:
    /* add command to remember uloc and break compiled */
    /* code blocks */
    cmpbuf_word(C_MARKPT); 
    compile_simple_numeric(0xa0,0x00,FALSE);
    break;

case C_CLRKEY:
case C_GETKEY:
    /* add command to remember uloc and break compiled */
    /* code blocks */
    cmpbuf_word(C_MARKPT); 
    break;

case C_FOCUS:
    skip_white_cB();
    if (cB[cI] != NEWLINE)
        term = compile_txtype(TXEDIT,TRUE);
    break;

case C_COARSE:
    allowcoarse = TRUE;
    compile_simple_numeric(0x40,0x00,FALSE);
    break;

case C_RESCALE:
    compile_simple_numeric(0x18,0x00,FALSE);
    break;

case C_CALC:
    wkexa = defexp;
    wkexa.tcomma = FALSE; /* comma not legal terminator */
    wkexa.calc = TRUE; /* mark -calc- command */
    wkexa.allowm = TRUE;
    compile(&wkexa);
    wkexa.exprtype = xtP[wkexa.exprtype].trel; /* simplify */
    if (wkexa.exprtype == TINT) addcmd = C_ICALC;
    else if (wkexa.exprtype == TBYTE) addcmd = C_ICALC;
    else if (wkexa.exprtype == TMARK) addcmd = C_MCALC;
    break;

case C_FINE:
    compile_points(1,2,0,FALSE,FALSE,FALSE,0,FALSE,FALSE);
    break;

case C_RANDU: /* randu x or randu  x,n */
    wkexa = defexp;
    wkexa.reqstore = TRUE; /* store-ability info required */
    compile(&wkexa);
    if (!wkexa.canstore) cerror(NOTSTORABLE,NEARNULL);
    compile_simple_numeric(0x180,0x00,FALSE);
    break;

case C_INHIBIT:
    skip_white_cB(); /* skip leading white space */
    term = cB[cI];
    while (term != NEWLINE) {
        i = identify_keyword(inhiblist,&term);
        compile_short_value(i); /* add keyword value */
        if (i == INHSTARTDRAW) { 
            if (term == '(') {
                cI--;  /* back up to balance parens */
                wkexa = defexp;
                compile(&wkexa); /* compile startdraw count */
                term = wkexa.lastchar; /* update terminator */
            } else {
                compile_short_value(1); /* add default count = 1 */
            } /* term else */
        } /* startdraw if */
        if ((term != NEWLINE) && (term != ','))
	    cerror(NEEDCOMMA,NEARNULL);
    } /* while */
    break;

case C_ALLOW: 
    compile_multiple_keywords(inhiblist); 
    break;

case C_SPECS:
    compile_multiple_keywords(specslist);
    break;

case C_JUDGE:
    i = compile_single_keyword(judgelist,&term);
    break;

case C_MODE:
    i = compile_single_keyword(modelist,&term);
    break;

case C_VIDEO:  
    skip_white_cB(); /* skip leading white space */
    if (cB[cI] == NEWLINE) {
    	if (continFlag) addcmd = -1; /* don't need command */
    	break; /* blank tag form */
    }
	if (continFlag) { /* continued */
        cmpl -= 4; /* remove previous C_VIDEO, C_VWAIT */
        skip_white_cB();
        term = cB[cI]; /* get next character */
	} else { 
		cmpbuf_word(C_VCLOSE); /* command to close+interrupt */
    	i = identify_keyword(videolist,&term);
    	if ((i != 2) && (term != NEWLINE))
        	cerror(TOOMANY,NEARNULL);
    	compile_short_value(i); /* add keyword value */
    	if (i != 2)  /* must be movie at present */
    		cerror(SPECIFICERR,"Keyword should be \"movie\".");
    	if (term != ';')
    		cerror(NEEDSEMI,NEARNULL);
    	term = compile_marker(FALSE,TRUE); /* evaluate marker expr */
    	if (term != NEWLINE) {
    		term = compile_points(2,2,0,TRUE,FALSE,FALSE,FALSE,FALSE,FALSE);
    		if (term) term = NEWLINE;
    	} /* term if */
    } /* continFlag else */
    while (term != NEWLINE) {
    	term = compile_video_tag(videolist1);
    }; /* while */
    cmpbuf_word(addcmd);
    addcmd = C_VWAIT; /* add command to wait after video */
    break;

case C_VSET:
    skip_white_cB(); /* skip leading white space */
    if (cB[cI] == NEWLINE) {
    	if (continFlag) addcmd = -1; /* don't need command */
    	break; /* blank tag form */
    }
	if (continFlag) { /* continued */
        cmpl -= 4; /* remove previous C_VSET, C_VWAIT */
        skip_white_cB();
    }
	do {
		term = compile_video_tag(vsetlist);
	} while (term != NEWLINE);
	cmpbuf_word(addcmd);
	addcmd = C_VWAIT; /* add command to wait after video */
    break;

case C_VPLAY: /* start, stop, speed - all optional numeric expressions */
    skip_white_cB();
    term = cB[cI];
    if ((term == ',') || (term == NEWLINE)) compile_float_value(0.0);
    else term = compile_simple_numeric(0x80,0x80,TRUE);

    if (term != NEWLINE) skip_white_cB();
    if ((cB[cI] == ',') || (term == NEWLINE)) compile_float_value(-1.0);
    else term = compile_simple_numeric(0x80,0x80,TRUE);

    if (term != NEWLINE) skip_white_cB();
    if ((cB[cI] == ',') || (term == NEWLINE)) compile_float_value(100.0);
    else compile_simple_numeric(0x80,0x80,FALSE);
    cmpbuf_word(addcmd);
    addcmd = C_VWAIT; /* add command to wait after video */
    break;


case C_OKCMD:
case C_NOCMD:
    compile_simple_numeric(0x180,0x00,FALSE);
    break;

case C_ENABLE:
case C_DISABLE:
    bits = 0; /* no option bits set yet */
    do {
        i = identify_keyword(enablelist,&term);
        if (i == 1) { /* touch */
            if (term == '(') {
            	bits |= extract_touch_keywords(&term,')',TRUE);
            	if (term == ')') {
            		term = cB[cI]; /* get terminator after touch() */
            		if (term != NEWLINE) cI++;
            	}
            } else bits |= (1 << TLDOWN); /* default is left/down */ 
        } else bits |= (1 << ENABLEEXT); /* ext */
        if ((term != ',') && (term != NEWLINE))
	    cerror(NEEDCOMMA,NEARNULL);
    } while (term != NEWLINE);
    compile_short_value(bits); /* add touch/ext bits */
    break;

 case C_SHOW:
    cmpbuf_word(wrapwrite ? C_BEGINTEXT : C_BEGINTEXT4);
    wkexa = defexp;
    wkexa.reqstore = TRUE; /* store-ability info required */
    wkexa.allowm = TRUE; /* allow marker result */
    compile(&wkexa);
    if (wkexa.exprtype != TMARK)
        compile_simple_numeric(0x1c0,0x40,FALSE);
    cmpbuf_word(newcmd);
    if (wkexa.exprtype != TMARK && !wrapwrite)
        addcmd = C_ENDTEXT1;
    else
        addcmd = C_ENDTEXT; /* marker show sets txt_doc to marker doc */
    break;

 case C_SHOWT:
    cmpbuf_word(wrapwrite ? C_BEGINTEXT : C_BEGINTEXT1);
    wkexa = defexp;
    wkexa.rtype = TFLOAT; /* require floating result */
    compile(&wkexa);
    compile_simple_numeric(0x1c0,0x00,FALSE);
    cmpbuf_word(newcmd);
    addcmd = wrapwrite ? C_ENDTEXT : C_ENDTEXT1;
    break;

 case C_SHOWB: 
 case C_SHOWO:
 case C_SHOWH:
    cmpbuf_word(wrapwrite ? C_BEGINTEXT : C_BEGINTEXT1);
    wkexa = defexp;
    wkexa.reqstore = TRUE; /* store-ability info required */
    compile(&wkexa);
    compile_simple_numeric(0x180,0x00,FALSE);
    cmpbuf_word(newcmd);
    addcmd = wrapwrite ? C_ENDTEXT : C_ENDTEXT1;
    break;

case C_WRITE: 
    chkeol = FALSE; /* suppress NEWLINE check */
    compile_write(continFlag,condFlag);
    addcmd = -1; /* don't add any more commands to binary */
    break;

case C_ENDTEXT:
    addcmd = -1;
    chkeol = FALSE;
    if (txt_end < 0) break; /* nothing to do */
    
    /* build -write- command for any text left dangling */
    
    if (txt_src_len) {
        len = TUTORget_len_doc(textpool);
        txt_pool_len += txt_src_len;
        cmp_mem_free();
        TUTORchange_doc_doc(textpool,len,0L,0L,len,source,
                      txt_src_start,txt_src_len,&dummy,FALSE);  
        /* re-aquire pointer */
        cmp_mem_lock();
    } /* txt_src_len if */
    if (txt_pool_len) {
        cmpbuf_word(TEXTARG);
        cmpbuf_long((long)txt_pool_start);
        cmpbuf_long((long)txt_pool_len);
        cmpbuf_write_cmd(C_WRITE); /* add -write- command */
    } /* txt_pool_len if */
    cmpbuf_write_cmd(txt_end); /* add appropriate C_ENDTEXT(*) */
    txt_src_len = txt_pool_len = 0;
    txt_end = -1; /* never get duplicate endtext */
    break;

case C_PLOT:
	loc = startofline+cI;
	do {
		i = TUTORcharat_doc(source,loc);
		if ((i == ' ') || (i == '\t'))
			loc++;
		else break;
	} while (TRUE);
	if ((i == PIXMAPSPECIAL) || (i == BITMAPSPECIAL) || (i == ICONSPECIAL)) {
		if ((cB[cI] == PIXMAPSPECIAL) || (cB[cI] == BITMAPSPECIAL) ||
		    (cB[cI] == ICONSPECIAL)) cI++;
		skip_white_cB();
		textpool_string(1L,loc);
		addcmd = C_PLOTI;
		break;
	}
    iInd = 0;
    do {
        term = compile_simple_numeric(0x80,0x00,TRUE);
        if (iInd++ > 30)
            cerror(TOOMANY,NEARNULL);
    } while (term != NEWLINE);
    break;

case C_TEXT:
case C_RTEXT:
case C_GTEXT:
    chkeol = FALSE;
    skip_white_cB();
    term = cB[cI] == NEWLINE; /* check if blank tag */
    if (!term) {
        if (newcmd == C_TEXT) /* process optional co-ordinates */
            term = compile_points(0,2,0,TRUE,FALSE,FALSE,2,TRUE,FALSE);
        else if (newcmd == C_RTEXT)
            term = compile_points(0,2,1,TRUE,FALSE,FALSE,2,FALSE,FALSE);
        else
            term = compile_points(0,2,2,TRUE,FALSE,FALSE,2,FALSE,FALSE);
    }
    if (term) { /* stopped on newline */
        cmpbuf_word(newcmd); /* complete -text- command */
        compile_text();
        addcmd = C_ENDTEXT; /* insert end command after write */
    } else {
        compile_marker(FALSE,FALSE);
        if (newcmd == C_TEXT) addcmd = C_TEXTM;
        else if (newcmd == C_RTEXT) addcmd = C_RTEXTM;
        else if (newcmd == C_GTEXT) addcmd = C_GTEXTM;
        newcmd = oldCmnd = oldcmd = C_TEXTM; /* set harmlessly */
    }
    break;

case C_STRING:
    chkeol = FALSE;
    term = compile_marker(TRUE,FALSE); /* compile marker expr */
    if (term != NEWLINE)
        cerror(SPECIFICERR,"Tag should contain just a marker.");
    cmpbuf_word(newcmd); /* complete -string- command */
    compile_text();
    cmpbuf_word(C_ENDTEXT); /* insert end command after -write- */
	if (DebugWn >= 0)
		cmpbuf_word(C_STEPNULL); /* add something for debugger to step on */
	addcmd = -1;
    break;

case C_APPEND:
case C_REPLACE:
    compile_marker(TRUE,FALSE); /* compile first marker expr */
    compile_marker(FALSE,FALSE); /* compile 2nd marker expr */
    break;

case C_EXACT:
case C_EXACTW:
    if ((i = FindArrowIndent()) >= 0)
        if (indent[i].lastif == 0)
            cerror(SPECIFICERR,"answer command in post-arrow indent");
    compile_general_text(NEWLINE,FALSE,FALSE);
    break;

case C_ANSWER:
case C_WRONG:
    if ((i = FindArrowIndent()) >= 0)
        if (indent[i].lastif == 0)
            cerror(SPECIFICERR,"answer command in post-arrow indent");
    compile_general_text(NEWLINE,TRUE,FALSE);
    break;

case C_ANSV:
case C_WRONGV:
    if ((compunit == 0) && (csourcen != 0))
        cerror(SPECIFICERR,"This command not legal in -use-d IEU.");
    if ((i = FindArrowIndent()) >= 0)
        if (indent[i].lastif == 0)
            cerror(SPECIFICERR,"answer command in post-arrow indent");
    term = compile_simple_numeric(0x80,0x80,TRUE);
    if (term == NEWLINE) break; /* one tag form */
    wkexa = defexp;
    wkexa.tpercent = TRUE; /* allow percent sign to terminate */
    wkexa.rtype = TFLOAT; /* require floating result */
    compile(&wkexa);
    compile_short_value(wkexa.lastchar == '%'); /* flag percent/abs */  
    break;

case C_MENU:
    itemonly = FALSE; /* pre-set card+item, not item only */
	if (DebugWn >= 0)
		cmpbuf_word(C_STEPOVER); /* indicate a block of commands to step over */
    
    /* check if blank tag or leading semicolon */
    
    skip_white_cB();
    term = cB[cI];
    if (term == NEWLINE) break; /* blank tag form */
    else if (term == ';') {
        cI++; /* skip leading semicolon, compile as item only */
        itemonly = TRUE;
    }

    /* compile card or item argument */

    term = compile_general_text(-2,TRUE,FALSE);
    wkexa = defexp; 
    wkexa.tcolon = wkexa.tsemic = TRUE; 
    wkexa.rtype = TINT; /* want integer results */
    if (term == ',') {
        compile(&wkexa); /* compile card/item priority */
        term = wkexa.lastchar;
    } else compile_short_value(0); /* add zero priority */
    if (term == ';') {
        if (itemonly)
            cerror(TOOMANY,NEARNULL);
        compile_short_value(TRUE); /* card/item form */
        term = compile_general_text(-2,TRUE,TRUE);
        if (term == ',') {
            compile(&wkexa); /* compile item priority */
            term = wkexa.lastchar;
        } else compile_short_value(0); /* add zero priority */
    } else {
        compile_short_value(FALSE); /* item only */
    } /* term else */
    if (term == NEWLINE) {
        compile_short_value(-1); /* add unit number = none */
        break;
    } else if (term != ':')
        cerror(SPECIFICERR, "Statement should end with : or end of line.");

    /* process unit name and possible argument */

    i = extract_unit(NEARNULL,&term,TRUE);
    if (i == -2)
        cerror(MISSINGUNIT,NEARNULL);
    else if (i == -1) /* indirect unit reference */
        cmpbuf_word(MUNIT);
    else /* normal unit ref */
        compile_short_value(i); /* add unit number */
    
    if (term == '(') {
        compile_short_value(TRUE); /* mark argument present */
        cI--; /* back up to balance parens */
        compile_simple_numeric(0x80,0x80,FALSE);
    } else {
        compile_short_value(FALSE); /* no arugment */
    } /* term else */
    break;

case C_ZERO:
    wkexa = defexp;
    wkexa.arrayok = TRUE; /* allow whole array */
    wkexa.reqstore = TRUE; /* get store-ability info */
    wkexa.allowm = TRUE; /* allow marker expression */
    compile(&wkexa); /* compile buffer expression */
    if (!wkexa.canstore) 
        cerror(NOTSTORABLE,NEARNULL); 
    i = wkexa.warray; /* non-zero if undimensioned */
    if ((wkexa.exprtype == TMARK) || (wkexa.exprtype == MARRAY))
        addcmd = C_ZEROM; /* marker-zero */     
    j = wkexa.lastchar != NEWLINE; /* length present flag */
    if  (j) {
        wkexa = defexp;
        wkexa.rtype =  TINT; /* get integer length */
        compile(&wkexa);
    } /* j (lastchar) if */
    compile_short_value(i); /* add array flag */
    compile_short_value(j); /* add length flag */
    break;

case C_SET:
    wkexa.lastchar = -1; /* pre-set for newline check */
    j = 0; /* number items for this command */
    if (continFlag) {
        addcmd = C_SETC; /* set for continued -set- */
    } else {
        wkexa = defexp;
        wkexa.arrayok = TRUE; /* allow whole array */
        wkexa.reqstore = TRUE; /* get store-ability info */
        wkexa.allowm = TRUE; /* allow marker expression */
        wkexa.tassign = TRUE; /* allow assignment terminator */
        compile(&wkexa); /* compile buffer expression */
        if (!wkexa.canstore) cerror(NOTSTORABLE,NEARNULL); 
        set_type = wkexa.exprtype; /* save expression type */
        if (set_type == IARRAY) {
            set_type = TINT;
        } else if (set_type == BARRAY) {
            set_type = TINT;
        } else if (set_type == FARRAY) {
            set_type = TFLOAT;
        } else if (set_type == MARRAY) {
            set_type = TMARK;
        } else if (set_type == TBYTE) {
            set_type = TINT;
        }
        i = wkexa.warray; /* non-zero if whole array */
        compile_short_value(i); /* add array flag */
        if (wkexa.lastchar != '=') 
            cerror(SPECIFICERR, "Need := after first variable."); 
    } /* continued else */
    while (wkexa.lastchar != NEWLINE) {
        if (j++ > 40) { /* break command up if too long */
            cmpbuf_word(addcmd); /* finish command */
            addcmd = C_SETC; /* now continued -set- */
            j = 0; /* re-set count */
        } /* j if */
        wkexa = defexp;
        wkexa.rtype = set_type; /* set type required */
        compile(&wkexa); /* compile next expression */
        if (wkexa.lastchar == ',') { /* check for dangling comma */
            skip_white_cB(); 
            if (cB[cI] == NEWLINE)
                wkexa.lastchar = NEWLINE; /* mark end of this line */
        }
    } /* while */
    break;

case C_SERVER:
case C_SOCKET:
    unittab[compunit].hasfile = TRUE;
    term = compile_file(TRUE); /* compile file argument */
    if (term == NEWLINE) 
        break; /* single argument */
    i = identify_keyword(servlist,&term);
    compile_short_value(i);
    term = compile_marker(FALSE,FALSE); /* evaluate address expr */
    if (((i == 1) || (i == 4)) && (term != NEWLINE)) { /* logical address */
        if (newcmd == C_SOCKET)
            compile_simple_numeric(0x80,0x00,FALSE); /* instance index */
        else if (i == 1)
        	compile_marker(FALSE,FALSE); /* server info */
    } /* i else-if */
    if (newcmd == C_SOCKET) {
    	cmpbuf_word(addcmd);
    	addcmd = C_SOCKWAIT;
    }
    break;

case C_DDE:
    i = identify_keyword(ddelist,&term);
    compile_short_value(i);

    switch (i) {
    
    case 1: /* servers */
    case 2: /* topics */
    case 3: /* items */
	wkexa = defexp;
    	wkexa.rtype = TMARK; /* require marker expression */
    	wkexa.mfunctst = FALSE; /* marker functions not store-able */
    	wkexa.reqstore = TRUE;
	compile(&wkexa); /* compile info buffer expression */
	if (i >= 2) /* topics */
	    compile_marker(FALSE,FALSE); /* server name */
	if (i == 3) /* items */
	    compile_marker(FALSE,FALSE); /* topic name */
    	break;
    	
    case 4: /* connect */
	term = compile_txtype(TXDDE,TRUE);
	compile_marker(FALSE,FALSE); /* server name */
	compile_marker(FALSE,FALSE); /* topic name */
    	break;
    	
    case 5: /* request */
	term = compile_txtype(TXDDE,TRUE);
	compile_marker(FALSE,FALSE); /* item name */
	wkexa = defexp;
    	wkexa.rtype = TMARK; /* require marker expression */
    	wkexa.mfunctst = FALSE; /* marker functions not store-able */
    	wkexa.reqstore = TRUE;
	compile(&wkexa); /* compile reply buffer expression */
    	break;
    	
    case 6: /* advise */
	term = compile_txtype(TXDDE,TRUE);
	compile_marker(FALSE,FALSE); /* item name */
	compile_unit_and_arg(); /* unit */
    	break;
    	
    case 7: /* poke */
	term = compile_txtype(TXDDE,TRUE);
	compile_marker(FALSE,FALSE); /* item name */
	compile_marker(FALSE,FALSE); /* value */
	break;
    	
    case 8: /* execute */
	term = compile_txtype(TXDDE,TRUE);
	compile_marker(FALSE,FALSE); /* value */
    	break;
    	
    } /* switch */
    break;
	
case C_GETSERV:
    term = compile_marker(FALSE,FALSE);
    if (term == NEWLINE) break;
    wkexa = defexp;
    wkexa.rtype = TINT; /* integer result */
    wkexa.tsemic = TRUE; /* require semicolon */
    wkexa.tcomma = FALSE;
    compile(&wkexa); /* compile index expression */
    wkexa = defexp; 
    wkexa.rtype = TMARK; /* require marker expression */
    wkexa.mfunctst = FALSE; /* marker functions not store-able */
    wkexa.reqstore = TRUE;
    compile(&wkexa); /* compile info buffer expression */
    if (!wkexa.canstore)
        cerror(SPECIFICERR,"Must be able to store into this variable.");
    break;

case C_SERIAL:
    term = compile_file(TRUE); /* compile file variable */
    if (term == NEWLINE) break;
    compile_simple_numeric(0x20,0x00,TRUE); /* port,baud,databits */
    i = identify_keyword(seriallist,&term); /* parity keyword */
    compile_short_value(i); 
    compile_simple_numeric(0x80,0x80,FALSE); /* stopbits */
    break;

case C_BEEP:
    if (cB[cI] == NEWLINE) break;
    cmpbuf_word(C_MARKPT); /* add command to remember uloc */
    do {
        compile_simple_numeric(0x40,0x40,TRUE);
        wkexa = defexp;
        wkexa.rtype = TINT; /* integer result */
        wkexa.tcomma = FALSE;
        wkexa.tsemic = TRUE; /* look for semicolon terminator */
        compile(&wkexa);
    } while (wkexa.lastchar != NEWLINE);
    break;

case C_COMPUTE:
    if ((compunit ==0) && (csourcen != 0))
        cerror(SPECIFICERR,"This command not legal in -use-d IEU yet.");
    wkexa = defexp;
    wkexa.rtype = 0; /* accept either int/float */
    wkexa.reqstore = TRUE; /* store-able */
    compile(&wkexa);
    if (!wkexa.canstore) 
        cerror(NOTSTORABLE,NEARNULL);
    if (wkexa.lastchar != NEWLINE)
        compile_marker(FALSE,FALSE);
    break;

case C_MOVE:
case C_RMOVE:
case C_GMOVE:
    identify_keyword(movelist,&term); /* only icon/icons for now */

    coarsef = FALSE; /* coarse grid not allowed */
    if (newcmd == C_MOVE) { 
        cosyst = 0; /* absolute */
        coarsef = TRUE; /* coarse grid allowed */
    } else if (newcmd == C_RMOVE) cosyst = 1; /* relative */
    else if (newcmd == C_GMOVE) cosyst = 2; /* graphing */
    /* compile from; to; */
    compile_points(2,2,cosyst,TRUE,FALSE,FALSE,FALSE,coarsef,FALSE); 

    i = j = 0; /* initialize erase and plot counts */
    wkexa = defexp;
    wkexa.rtype = TINT; /* integer expressions */
    wkexa.tsemic = TRUE; /* allow semicolon */
    do {
        compile(&wkexa);
        i++; /* number icons in erase list */
        term = wkexa.lastchar;
    } while ((term != NEWLINE) && (term != ';'));
    if (term == ';') {
        do {
            term = compile_simple_numeric(0x80,0x00,TRUE);
            j++; /* number icons in plot list */
        } while (term != NEWLINE);
    } /* term if */
    if ((i+j) > 30)
        cerror(TOOMANY,NEARNULL);
    compile_short_value(i); /* length of erase list */
    compile_short_value(j); /* length of plot list */
    break;

case C_PAUSE:
    cmpbuf_word(C_MARKPT); /* add command to remember uloc */
    i = j = FALSE; /* no numeric tag, no keys= option */
    skip_white_cB(); /* skip leading white space */
    term = cB[cI];
    if (term != NEWLINE)
        j = identify_keys_equal(); /* check for keys= option */
    if ((term != NEWLINE) && (!j)) {
        i = TRUE; /* numeric tag present */
        term = compile_simple_numeric(0x80,0x80,TRUE);
        if (term != NEWLINE)
            j = identify_keys_equal(); /* check for keys= again */
    }
    if (j) {
        argcount = 0; /* number keys in list */
        do {
            k = identify_key_name(&bits,&term);
            compile_short_value(k);
            if (k == KTOUCH)
                compile_short_value(bits);
            if (++argcount > 30)
                cerror(TOOMANY,NEARNULL);
        } while (term != NEWLINE);
        compile_short_value(argcount); /* length of key list */
    } 
    compile_short_value(i); /* time present flag */
    compile_short_value(j); /* keys= present flag */
    break;

case C_IF:
    /* indent info is at indentlevel not indentlevel+1 because already pushed */
    idP = &indent[indentlevel];
    idP->headref = compile_cbranch(FALSE,R_IF1,labelID); 
    idP->lastif = C_IF;
    idP->nextlabel = labelID++; /* next else/elseif/endif */
    idP->endlabel = labelID++; /* endif */
    addcmd = -1; /* command code already in binary */
    break;

case C_ENDIF:
    /* indent info is at indentlevel+1, not indentlevel because already popped */
    idP = &indent[indentlevel+1];
    /* resolve forward reference from previous if/else/elseif */
    thislabel = idP->nextlabel;
    satisfy_xref(idP->headref,R_IF1,thislabel,(unsigned int)cmpl); 
    add_dest(RD_ENDIF,thislabel,cmpl); /* mark this point in binary */
    /* resolve forward references from ends of if/elseif/else clauses */
    thislabel = idP->endlabel;
    satisfy_xref(idP->headref,R_IF2,thislabel,(unsigned int)cmpl);
    addcmd = -1; /* no command code in binary */
    add_dest(RD_ENDIF,thislabel,cmpl); /* mark this point in binary */
    break;

case C_ELSE:
    idP = &indent[indentlevel];

    /* determine case/else or if/else */

    if (idP->stype == caseexprkind) {

        /* handle else used with case */

        indentlv = indentlevel-1; /* case info is one down in stack */
        idP = &indent[indentlv];
        /* add branch at end of previous clause */
        if (idP->lastif == C_CASE)
            cerror(BADELSE,NEARNULL); /* empty case statement */
        if (idP->lastif == C_ELSE)
            cerror(BADELSE,NEARNULL); /* multiple else statements */
        idP->lastif = C_ELSE;
        compile_ubranch(R_CASE3,idP->endlabel); /* finish previous clause */
        thislabel = xrefP[idP->headref].label;   /* thislabel = fwd reference to else */
        /* resolve forward reference from -case- */
        satisfy_xref(idP->headref,R_CASE1,thislabel,cmpl); 
        add_dest(RD_CASEELSE,thislabel,cmpl);
        /* resolve forward reference from begin of previous clause */
        satisfy_xref(idP->headref,R_CLAUSE,idP->nextlabel,cmpl); 
        addcmd = -1;
        add_dest(RD_CASEELSE,idP->nextlabel,cmpl); /* mark this point in binary */
        idP->nextlabel = 0; /* for endcase = already satisfied */
        break;
    } /* caseexprkind if  */

    /* handle else used with if */

    if (idP->lastif == C_ELSE)
        cerror(BADELSE,NEARNULL); /* multiple else statements */
    idP->lastif = C_ELSE;   

    /* add branch at end of previous if/elseif clause */

    thislabel = idP->endlabel;
    compile_ubranch(R_IF2,thislabel);

    /* resolve forward reference from previous if/elseif */

    thislabel = idP->nextlabel;
    satisfy_xref(idP->headref,R_IF1,thislabel,(unsigned int)cmpl);
    idP->nextlabel = labelID++; /* assign new next label */
    add_dest(RD_ELSE,thislabel,cmpl);
    addcmd = -1; /* no command code in binary */
    break;

case C_ELSEIF:
    idP = &indent[indentlevel];
    if (idP->lastif == C_ELSE)
        cerror(BADELSE,NEARNULL); /* elseif after else */
    idP->lastif = C_ELSEIF;

    /* add branch at end of previous if/elseif clause */

    thislabel = idP->endlabel;
    compile_ubranch(R_IF2,thislabel);

    /* resolve forward reference from previous if/elseif */

    thislabel = idP->nextlabel;
    satisfy_xref(idP->headref,R_IF1,thislabel,(unsigned int)cmpl);
    add_dest(RD_ELSEIF,thislabel,cmpl);

    /* build if part of elseif */

    idP->nextlabel = thislabel = labelID++; /* assign new label */
    compile_cbranch(FALSE,R_IF1,thislabel); /* branch around if-ed code */
    addcmd = -1; /* command code already in binary */
    break;

case C_OUTIF:
case C_OUTCASE:
case C_OUTLOOP:
case C_RELOOP:
    idP = &indent[breaklevel];
    if (newcmd == C_OUTLOOP) {
        i = R_LOOP2; /* branch to loop exit */
        thislabel = idP->endlabel;
    } else if (newcmd == C_RELOOP) {
        i = R_LOOP3; /* branch to loop top */
        thislabel = idP->nextlabel;
    } else if (newcmd == C_OUTCASE) {
        i = R_CASE3; /* branch to case end */
        /* case info is one down on stack */
        thislabel = indent[breaklevel-1].endlabel;
    } else {
        i = R_IF2;
        thislabel = idP->endlabel;
    }
    skip_white_cB();
    if (cB[cI] == NEWLINE) /* blank tag */
        compile_ubranch(i,thislabel); /* unconditional branch */
    else /* conditional */
        compile_cbranch(TRUE,i,thislabel); /* branch on condition */
    idP->lastif = addcmd;
    addcmd = -1; /* command code already in binary */
    break;

case C_LOOP:     
    addcmd = -1; /* no need to add command code */
    idP = &indent[indentlevel];
    idP->headref = unittab[compunit].nrefs;
    idP->nextlabel = labelID++; /* label for loop head */
    labelID++; /* label for loop body */
    idP->endlabel = labelID++; /* label for loop end */
    cmpbuf_word(C_LBEGIN); /* begin-of-loop marker */
    
    /* handle blank tag form */

    if (cB[cI] == NEWLINE) { /* blank tag form */
        idP->headloc = cmpl;
        add_dest(RD_LOOP3,idP->nextlabel,cmpl); /* mark top of loop */
        compile_short_value(-1);
        /* add branch to end of loop */
        cmpbuf_word(ULOCADDR);
        add_xref(R_LOOP2,idP->endlabel,cmpl,-1); /* add to reloc table */
        cmpbuf_word(0); /* address planted later */
        cmpbuf_word(C_BRANCHF); /* branch if false */       
        break;
    } /* blank tag */
    
    loc = pbscan(cB,cI,","); /* check for iterative form */
    if (loc >= 0) { /* iterative form */
        loc = cI; /* pos of index expression */

        /* compile index variable without generating p-code to */
        /* determine type */

        wkexa = defexp;
        wkexa.tassign = TRUE; /* terminate on assignment */
        wkexa.nogen = TRUE; /* suppress p-code */
        compile(&wkexa); /* compile index variable */
        /* set int/float mask for following expressions */
        lindext = xtP[wkexa.exprtype].trel; /* simplify index type */
        lfloatf = (lindext == TFLOAT) ? 0xff: 0; 
        
        /* compile beginning value without generating p-code to */
        /* determine if constant */
        
        wkexa = defexp;
        wkexa.nogen = TRUE; /* suppress p-code */
        wkexa.rtype = lindext;
        compile(&wkexa);
        lconstf = (!lfloatf) && wkexa.isconst; /* TRUE if integer constant */
        lcbegin = wkexa.iconst; /* save constant begin value */

        /* compile ending value without generating p-code to */
        /* determine if constant */
        
        if (lconstf) {
            compile(&wkexa);
            lconstf = lconstf && wkexa.isconst; /* TRUE if constant */
            lcend = wkexa.iconst; /* save constant end value */
            term = wkexa.lastchar; 
        } /* lconstf if */
        
        /* compile increment without generating p-code to */
       /* determine if constant */
        
        if (lconstf) {
            if (term != NEWLINE) {
                compile(&wkexa);
                lconstf = lconstf && wkexa.isconst; 
                lcinc = wkexa.iconst; /* save constant increment */
            } else lcinc = 1; /* constant increment = 1 */
        } /* lconstf if */

        /* check if constant begin, end, increment loop can ever execute */
        
        if (lconstf) { /* loop has constant begin, end, inc */
            if (lcinc == 0) cerror(SPECIFICERR,"loop increment is zero");
            else if (lcinc > 0) {
                if (lcbegin > lcend) 
                    lconstf = FALSE; /* dont optimize */
            } else if (lcinc < 0) {
                if (lcbegin < lcend)
                    lconstf = FALSE; /* dont optimize */
            }
        } /* lconstf if */
    
        /* compile initial assignment */

        cI = loc; /* re-set to begin of index expression */
        wkexa = defexp;
        wkexa.calc = TRUE; /* flag as calc-type expression */
        compile(&wkexa); /* compile index variable */
        iInd = cI; /* position of end expression */
        
        if (!lconstf) { 
        
            /* compile ending value expression */

            wkexa = defexp;
            wkexa.rtype = lindext;
            compile(&wkexa); /* compile end expression */
            term = wkexa.lastchar; /* get terminating character */

            /* compile increment */

            linc1 = FALSE; /* TRUE if index integer, increment by 1 */
            if (term != NEWLINE) {
                wkexa = defexp;
                wkexa.rtype = lindext;
                compile(&wkexa); /* compile increment expression */
            } else if (lfloatf == 0) { 
                linc1 = TRUE; /* integer, increment by 1 */
            } else compile_float_value(1.0);
        } /* lconstf if */
        
        /* add fwd refs and command code for loop init */

        iInd2 = cmpbuf_xref(R_LOOP1,idP->nextlabel+1); /* body */
        cmpbuf_xref(R_LOOP2,idP->endlabel); /* exit */
        if (lfloatf) cmpbuf_word(C_FLOOPINIT);
        else {
            if (lconstf) cmpbuf_word(C_ICLOOPINIT);
            else if (linc1) cmpbuf_word(C_ILOOP1INIT);
            else cmpbuf_word(C_ILOOPINIT);
        }
        
        /* mark head of loop */

        idP->headloc = cmpl; /* top of loop */
        add_dest(RD_LOOP3,idP->nextlabel,cmpl); /* mark this point */

        /* compile index variable */

        cI = loc; /* back up to index expression */
        wkexa = defexp;
        wkexa.rtype = lindext;
        wkexa.reqstore = TRUE; /* want store-ability info */
        wkexa.tassign = TRUE; /* stop on assignment */
        compile(&wkexa);
        if (!wkexa.canstore) cerror(NOTSTORABLE,NEARNULL); 
        if (wkexa.lastchar != '=')
            cerror(SPECIFICERR,"Expected := after loop index.");
        wkexa.rtype = wkexa.exprtype; /* set int/float */

        /* compile ending value expression again */

        cI = iInd; /* set to end expr */
        term = compile_simple_numeric(0x80,lfloatf,TRUE); /* compile end expr */

        /* compile increment again */

        if (term != NEWLINE)
            compile_simple_numeric(0x80,lfloatf,FALSE); /* compile increment */
        else if (lfloatf) compile_float_value(1.0);
        else if (lconstf) compile_short_value(1);

        /* add fwd ref to loop end and command code */

        cmpbuf_xref(R_LOOP2,idP->endlabel); /* loop exit */
        if (lfloatf) cmpbuf_word(C_FLOOPINC); /* floating index */
        else if (lconstf) cmpbuf_word(C_ICLOOPINC); /* int const begin,end,inc */
        else if (linc1) cmpbuf_word(C_ILOOP1); /* integer index, inc by 1 */
        else cmpbuf_word(C_ILOOPINC); /* integer index */

        /* satisfy init command fwd reference to loop body */

        plant_xref((int)iInd2,(unsigned int)cmpl); /* body of loop */
        add_dest(RD_LOOP1,idP->nextlabel+1,cmpl); /* mark this point */
    } else { /* simple conditional form */
        idP->headloc = cmpl;
        add_dest(RD_LOOP3,idP->nextlabel,cmpl);
        compile_cbranch(FALSE,R_LOOP2,idP->endlabel);
    }
    break;

case C_ENDLOOP:
    cmpbuf_word(C_LEND); /* end-of-loop marker */
    /* indent info is at indentlevel+1 because already popped */
    indentlv = indentlevel+1;
    idP = &indent[indentlv];
    compile_ubranch(R_LOOP3,idP->nextlabel); /* branch to begin of loop */  
    /* resolve forward references to end of loop */
    satisfy_xref(idP->headref,R_LOOP2,idP->endlabel,(unsigned int)cmpl); 
    /* reslove references to begin of loop */
    satisfy_xref(idP->headref,R_LOOP3,idP->nextlabel,
                 (unsigned int)idP->headloc);
    add_dest(RD_LOOP2,idP->endlabel,cmpl);
    addcmd = -1;
    break;

case C_JUMP:
    cmpbuf_word(C_OBJW); /* insert command to interrupt before jump */
case C_DO:

    /* process unit name */

    i = extract_unit(ws,&term,TRUE);
    if (i == -2) {
        if (strcmp(ws, "x") == 0) {
            compile_short_value(UNITX);
			if ((term == '(') || (term == '['))
				cerror(UXARG,NEARNULL);
        } else
            cerror(MISSINGUNIT,NEARNULL);
    } else if (i == -1) /* indirect unit reference */
        cmpbuf_word(MUNIT);
    else /* normal unit ref */
        compile_short_value(i); /* add unit number */

    /* process arguments to unit */

    nvargs = naargs = 0;
    valuef = TRUE; /* assume start with value arguments */
    if (term == '{')
    	cerror(WRONGSEP,NEARNULL);
    if ((term == '(') || (term == '[')) {
	if (term == '(') balanceC = ')';
	else balanceC = ']';
        skip_white_cB();
        if (cB[cI] == ';') {
            valuef = FALSE; /* no value arguments */
            cI++; /* skip over semicolon */
        } /* cB if */
        do {
            wkexa = defexp;
            wkexa.reqstore = TRUE;
            wkexa.allowm = TRUE; /* allow marker expressions */
            wkexa.tparen = TRUE; /* allow paren to terminate */
            if (valuef) {
                wkexa.tsemic = TRUE; /* allow semicolon */
            } else {
                wkexa.arrayok = TRUE; /* allow whole array */
                wkexa.allowf = TRUE; /* file var allowed */
                wkexa.allowscrn = TRUE; /* screen var allowed */
                wkexa.allowbutn = TRUE; /* button var allowed */
                wkexa.allowslid = TRUE; /* slider var allowed */
                wkexa.allowedit = TRUE; /* edit var allowed */
                wkexa.allowtouch = TRUE; /* touch var allowed */
                wkexa.allowdde = TRUE; /* DDE variable allowed */
            }
            compile(&wkexa);
            term = wkexa.lastchar; /* save terminating character */
            if (valuef) {
                nvargs++;
            } else {
                if (!wkexa.canstore)
                    cerror(SPECIFICERR,"Address argument must be variable.");
                naargs++;
            }
            if (term == ';') 
                valuef = FALSE; /* switch to addr args */
	} while (term != balanceC);
    } /* term if */
    skip_white_cB(); /* skip any trailing whitespace */
    compile_short_value(nvargs);
    compile_short_value(naargs);
    break;

case C_RESHAPE:
    cerror(SPECIFICERR,"Command not implemented yet");
    break;

case C_IMAIN:
case C_IJUDGE:
case C_IARROW:
case C_ERASEU:
case C_NEXT:
case C_BACK:
case C_FINISHU:

    /* process unit name */

    i = extract_unit(ws,&term,TRUE);
    if (i == -2) { /* didn't find unit */
        if (strcmp(ws,"x") == 0) {
            addcmd = -1; /* command is a no-op if unit x */
            break;
        } else if (strcmp(ws,"q") == 0) {
            compile_short_value(0); /* unit #0 = not set */
        } else cerror(MISSINGUNIT,NEARNULL);
    } else if (i == -1)
        cmpbuf_word(MUNIT); /* indirect unit reference */
    else /* normal unit reference */
        compile_short_value(i); /* add unit number */
    break;

case C_OUTUNIT:
    compile_simple_numeric(0x180,0x00,FALSE);
    break;

case C_JUMPOUT:
    skip_white_cB();
    nvargs = 0;
	if ((cB[cI] == NEWLINE) || (cB[cI] == 0)) {
		compile_short_value(2); /* blank tag = q = quit */
	} else {
		iInd = cI;
    	extract_keyword_cB(ws,32,FALSE,&term); /* extract possible "x" or "q" */
		if (strcmp(ws,"x") == 0) {
			compile_short_value(1); /* 1 = x = no-op */
		} else if (strcmp(ws,"q") == 0) {
			compile_short_value(2); /* 2 = q = quit */
		} else {
			cI = iInd; /* back up to begin of name */
			compile_short_value(0); /* 0 = program name */
			term = compile_marker(FALSE,TRUE); /* evaluate marker expr */
			if (term != NEWLINE) { /* process value arguments */
        		do {
            		wkexa = defexp;
            		wkexa.reqstore = TRUE;
            		wkexa.allowm = TRUE; /* allow marker expressions */
            		compile(&wkexa);
            		term = wkexa.lastchar; /* save terminating character */
                	nvargs++;
                	if (nvargs > MAXPASSVAL)
						cerror(SPECIFICERR,"Too many arguments");
        		} while (term != NEWLINE);
    		} /* term if */
    	} /* else */
	} /* non-blank tag else */
	compile_short_value(nvargs); /* add number of arguments */
    break;

case C_DMP:
case C_CMDS:
    break;
 
default: 
    compile3();
    break;

} /* end of switch */

} /* compile2 */

/* ******************************************************************* */

static int compile_video_tag(videoList)
struct keywdinf *videoList;

{	int vii;
	int term;
	struct expra wkexa; /* scratch analyzer params */
	
	vii = identify_keyword(videoList,&term);
    compile_short_value(vii); /* add keyword value */
    if ((vii == 0) || (vii == 8)) { /* rectangle or ctrl rect */
    	term = compile_points(2,2,0,TRUE,FALSE,FALSE,0,FALSE,FALSE);
    	if (term) term = NEWLINE;
    	else term = ';';
    } else if (vii == 6) { /* range */
    	wkexa = defexp;
        wkexa.rtype = TFLOAT; /* require floating result */
        compile(&wkexa); /* evaluate numeric expression */
    	wkexa = defexp;
        wkexa.rtype = TFLOAT; /* require floating result */
        wkexa.tsemic = TRUE; /* allow termination on semicolon */
        compile(&wkexa); /* evaluate numeric expression */
        term = wkexa.lastchar;
    } else if (vii == 7) { /* sound */
    	wkexa = defexp;
        wkexa.rtype = TFLOAT; /* require floating result */
        wkexa.tsemic = TRUE; /* allow termination on semicolon */
        compile(&wkexa); /* evaluate numeric expression */
        term = wkexa.lastchar;
    } else if ((vii == 9) || (vii == 10)) { /* loop, palette */
    	if (term != ',') {
    		compile_short_value(-1);
    	} else {
        	wkexa = defexp;
        	wkexa.rtype = TINT; /* require integer result */
        	wkexa.tsemic = TRUE; /* allow termination on semicolon */
        	compile(&wkexa); /* evaluate numeric expression */
        	term = wkexa.lastchar;
        }
	}
    if ((term != ';') && (term != NEWLINE))
    	cerror(NEEDSEMI,NEARNULL);
    return(term);
    
} /* compile_video_tag */

/* ******************************************************************* */

compile_short_value(vv) /* add pcodes for 16 bit integer value */
int vv; /* value */

{
    cmpbuf_word(TKEYWORD); /* add keyword code and value */
    cmpbuf_word(vv);

} /* compile_short_value */

/* ******************************************************************* */

compile_long_value(vv) /* add pcodes for 32 bit integer value */
long vv; /* value */

{
    cmpbuf_word(ILITERAL); /* add integer literal code and value */
    cmpbuf_long(vv);

} /* compile_long_value */

/* ******************************************************************* */

compile_float_value(vv) /* add pcodes for floating value */
double vv; /* value */

{
    cmpbuf_word(FLITERAL); 
    cmpbuf_flt(vv);

} /* compile_float_value */

/* ******************************************************************* */

int compile_float() /* compile single floating expression */
/* returns terminating character */

{   struct expra wkexa; /* expression analyzer params */

    wkexa = defexp;
    wkexa.rtype = TFLOAT; /* require floating result */
    wkexa.tsemic = TRUE; /* allow semicolon */
    compile(&wkexa);
    return(wkexa.lastchar); /* return terminator */

} /* compile_float */

/* ******************************************************************* */

int compile_simple_numeric(nmask,fmask,stopl) /* compile arithmetic expressions */
/* returns terminating character */
int nmask; /* bits for legal argument counts (9 bits) */
           /* e.g. 0xc0 = 1 or 2 arguments legal */
int fmask; /* bits for floating arguments (8 bits ) */
           /* e.g. 0x80 = 1st argument is floating */
int stopl; /* TRUE if should stop after last argument */

{   struct expra exper; /* expr analyzer params for argument */
    int nargs; /* number arguments so far */
    long loc; /* position in input string */
    int bitm; /* bit mask for argument */
    int endm; /* bit mask for remaining legal counts */

    exper = defexp; /* set to default expression analyzer params */
    nargs = 0; /* argument count */
    endm = 0xff; /* 1-8 arguments */

    exper.lastchar = -1;
    if (cI && (cB[cI-1] == NEWLINE)) /* check if past NEWLINE */
        exper.lastchar = NEWLINE; 

    /* process arguments */

    while (exper.lastchar != NEWLINE) {

        /* check for end of arguments */

        bitm = 0x100 >> nargs;
        if (nmask & bitm) {
            loc = cI;
            exper.lastchar = next_cB(); /* check if blank tag */
            if (exper.lastchar == NEWLINE) {
                break; /* exit while */
            }
            cI = loc; /* set back to 1st character */
            if (stopl) break; /* exit while */
        } /* min if */

        /* process next argument */

        nargs++;
        if (nargs > 8) cerror(TOOMANY,NEARNULL);
        if ((nmask & endm) == 0)
            cerror(TOOMANY,NEARNULL);
        endm = endm >> 1;
        bitm = 0x100 >> nargs;
        if (fmask & bitm) 
            exper.rtype = TFLOAT; /* require float */
        else exper.rtype = TINT; /* require int */
        compile(&exper); /* compile argument */
    } /* while */

    if ((nmask & (0x100 >> nargs)) == 0)
        cerror(SPECIFICERR,"Too many arguments or too few arguments.");

    return(exper.lastchar); /* return terminating character */

} /* compile_simple_numeric */

/* ******************************************************************* */
/* returns number of expressions processed */
compile_general(exps,nmin,nmax)
struct expra *exps; /* table of expr analyzer params */
int nmin; /* minimum number of arguments */
int nmax; /* maximum num arguments = length of table */

{   int nargs; /* number arguments processed */
    int term; /* terminating character */

    /* check if already at end - nothing to do */
    skip_white_cB(); /* skip leading white space */
    if (exps->tembed) { /* check if embed legal terminator */
        if (cI && (cB[cI-1] == '|') && (cB[cI] == '>')) {
            cI++; /* advance past terminator */
            if (nmin) cerror(MISSINGARG,NEARNULL);
            return(0);
        }
    } else if (cI && cB[cI-1] == NEWLINE) {
        if (nmin) cerror(MISSINGARG,NEARNULL);
        return(0); /* exit if at terminator */
    } /* else */

    /* loop to process expressions */

    nargs = 0;
    do {
        nargs++;
        if (nargs > nmax) 
            cerror(TOOMANY,NEARNULL);
        compile(exps);
        term = exps->lastchar;
        if (term == NEWLINE) 
            break;
        if (exps->tembed && (term == '>'))
            break;
        exps++; /* advance to next table entry */
    } while ((term != NEWLINE) && (term != '>'));

    if (nargs < nmin) cerror(MISSINGARG,NEARNULL);
    return(nargs);

} /* compile_general */

/* ******************************************************************* */

int compile_marker(storef,semic) /* compile single marker expression */
/* returns terminating character */
int storef; /* TRUE if must be store-able */
int semic; /* TRUE if semicolon legal terminator */

{   struct expra wkexa; /* expression analyzer params */

    wkexa = defexp;
    wkexa.rtype = TMARK; /* require marker result */
    wkexa.reqstore = storef;
    wkexa.tsemic = semic;
    compile(&wkexa);
    if (storef && (!wkexa.canstore))
        cerror(SPECIFICERR,"Must be able to store into this variable.");
    return(wkexa.lastchar); /* return terminator */

} /* compile_marker */

/* ******************************************************************* */

int compile_file(storef) /* compile single file expression */
/* returns terminating character */
int storef; /* TRUE if need store-ability info */

{   struct expra wkexa; /* expression analyzer params */
    long filetyp;

    filetyp = ((long)TXFILE << 16)+TXTYPE;
    wkexa = defexp;
    wkexa.rtype = filetyp; /* require file result */
    wkexa.tsemic = TRUE; /* allow semicolon */
    wkexa.reqstore = storef;
    compile(&wkexa);
    if (wkexa.exprtype != filetyp) {
        cerror(SPECIFICERR,"This argument must be a file descriptor.");
    } else if (!wkexa.canstore) 
        cerror(SPECIFICERR,"Cannot use file descriptor in an expression.");
    else if ((wkexa.lastchar != NEWLINE) && (wkexa.lastchar != ';'))
        cerror(NEEDSEMI,NEARNULL);
    return(wkexa.lastchar); /* return terminator */

} /* compile_file */

/* ******************************************************************* */

int compile_txtype(type,storef) /* compile single bitmap/button/etc expression */
/* returns terminating character */
int type; /* TXSCREEN, TXBUTTON, etc */
int storef; /* TRUE if want to require store-able */

{   struct expra wkexa; /* expression analyzer params */
    long typcod;

    typcod = ((long)type << 16)+TXTYPE;
    wkexa = defexp;
    wkexa.rtype = typcod; /* require pixmap/button/etc result */
    wkexa.tsemic = TRUE; /* allow semicolon */
    wkexa.reqstore = storef; 
    compile(&wkexa);
    if (wkexa.exprtype != typcod) {
        cerror(SPECIFICERR,"Incorrect variable type for this argument.");
    } else if (storef && !wkexa.canstore) 
        cerror(SPECIFICERR,"This argument must be a variable.");
    else if ((wkexa.lastchar != NEWLINE) && (wkexa.lastchar != ';'))
        cerror(NEEDSEMI,NEARNULL);
    return(wkexa.lastchar); /* return terminator */

} /* compile_txtype */

/* ******************************************************************* */

skip_white_cB() /* skip white space in cB */

{
    while ((cB[cI] == ' ') || (cB[cI] == '\t'))
        cI++; /* skip leading white space */

} /* skip_white_cB */

/* ******************************************************************* */

int next_cB() /* read next non-blank character from cB */

{   register char   c;
    
    do {
        if (cI >= nBuffChars) { /* end of cB buffer */
            cI = nBuffChars;
            return(NEWLINE);
        } /* cI if */
        c = cB[cI++];
    } while (c == ' ' || (c == '\t' ));
    return (c);

} /* next_cB */

/* ******************************************************************* */

int extract_keyword_cB(kname,maxl,spaces,term) /* extract keyword/name from cB */
/* returns length of name */
char *kname; /* returned containing name */
int maxl; /* length of kname buffer including terminating 0 */
int spaces; /* TRUE if embedded spaces are allowed */
int *term; /* returned terminating character */

{   int ki; /* index in keyword */
    int kl; /* length of keyword */

    /* extract next keyword from source */

    skip_white_cB(); /* skip leading white space */
    ki = 0; /* index in key name */
    while (CTisalnum(cB[cI]) || cB[cI] == '_' || (spaces && (cB[cI] == ' '))) {
        if (cB[cI] != ' ')
            kname[ki++] = cB[cI++]; /* build key name */
        else if (ki && kname[ki-1] != ' ')
            kname[ki++] = cB[cI++]; /* allow one space */
        else cI++; /* collapse multiple spaces to one */
        if (ki >= (maxl-1)) { /* check if keyword too big */
            *term = -1;
            return(0); /* return zero length */
        } /* ki if */   
    } /* while */
    while (ki && (kname[ki-1] == ' '))
        ki--; /* remove trailing spaces */
    kname[ki] = '\0'; /* set end of string */
    skip_white_cB(); /* skip trailing white space */
    *term = cB[cI]; /* return terminator */
    if (*term != NEWLINE) cI++; /* advance to next keyword */

    return(strlen(kname));

} /* extract_keyword_cB */

/* ******************************************************************* */

int extract_touch_keywords(ttrm,stopC,simpleF) /* identify touch(*) options (left:down;right:up etc) */
/* returns TLDOWN, TLUP, TLMOVE, TRDOWN, TRUP, TRMOVE bits */
int *ttrm; /* terminator following left paren */
int stopC;  /* character that terminates the expression */
int simpleF;    /* if TRUE, we only accept down, up, move (only used by C_ENABLE) */

{   int bits; /* accumulated bits */
    int bitpos; /* base bit position for left/right */
    int lrstate; /* 0 = no left/right, 1 = left/right specified */
    int term; /* terminating character code */
    static char kwd[20]; /* current keyword */
    static char *action[] = {"down", "up", "move", "double", "upmove" };
    int ii; /* index in action list */
    int nActions;   /* # of actions in list we will allow */

    bits = 0; /* no bits set yet */
    lrstate = 0;
    bitpos = TLDOWN; /* assume left: by default */
    nActions = 5;

    /* assume starting just after left paren */

    if (simpleF && cB[cI-1] != '(') 
        cerror(SPECIFICERR,"Format is touch or touch(options).");

    term = stopC+1; /* so we always go thru while at least once */
    while ((term != stopC) && (term != NEWLINE)) {
        extract_keyword_cB(kwd,20,FALSE,&term);
        if (term == ':') {
            if (strcmp(kwd,"left") == 0) bitpos = TLDOWN;
            else if (strcmp(kwd,"right") == 0) bitpos = TRDOWN;
            else cerror(SPECIFICERR,"Format is left: etc. or right: etc."); 
            if (lrstate) cerror(NEEDSEMI,NEARNULL);
            lrstate = 1;
        } else if ((term == ',') || (term == ';') || (term == stopC)) {
            for (ii = 0; ii < nActions; ii ++) {
                if (strcmp(kwd,action[ii]) == 0) break; 
            } /* for */
            if ((ii >= nActions) || (simpleF && (ii > 2))) {
                if (simpleF)
                    cerror(SPECIFICERR,"Actions are down, up, or move.");
                else
                    cerror(SPECIFICERR,"Actions are down, up, move, double.");
            }
            if (ii == 3) {
               if (bitpos == TLDOWN) ii = TLDOUBLE-TLDOWN;
               else ii = TRDOUBLE-TRDOWN;
            } else if (ii == 4) {
            	if (lrstate || (term == ',')) 
            		cerror(NEEDSEMI,NEARNULL);
            	bitpos = 0;
            	ii = TUPMOVE;
            }
            bits = bits | (1 << (bitpos+ii));
            if (term == ';') lrstate = 0; /* next is left or right or upmove */
        } else {
            if (simpleF)
                cerror(SPECIFICERR,"Format is touch(left:down,up,move; right:down,up,move).");
            else
                cerror(SPECIFICERR,"Format is left:down,up,move,double; right:down,etc.");
        }
    } /* term while */
    skip_white_cB(); /* skip to terminator after right paren */
    *ttrm = term; /* return terminator */
    return(bits);
  
} /* extract_touch_keywords */

/* ******************************************************************* */

static char keystr[5] = "keys";

int identify_keys_equal() /* identify "keys =" option */
/* returns TRUE if keys= */

{   int start; /* initial cI */

    skip_white_cB();
    start = cI;
    if (strncmpf((char FAR *) &cB[cI],(char FAR *)keystr,4) == 0) {
        cI += 4; 
        skip_white_cB(); 
        if (cB[cI++] == '=') 
            return(TRUE);
    } /* strncmpf if */

    cI = start; /* reset to begin of string */
    return(FALSE);

} /* identify_keys_equal */

/* ******************************************************************* */ 

int identify_key_name(tbits,term) /* identify key/touch */
int *tbits; /* touch option bits */
int *term; /* returned terminator */

{   int nonblank; /* non-blank character count */
    int code; /* key code */
    int ii;
    struct keywdinf *keylist;

    *tbits = 0; /* no touch option bits yet */
    skip_white_cB(); /* skip leading white space */

    /* check for single character key name (a,A,+, etc) */

    nonblank = 0;
    ii = cI;
    while ((cB[ii] != ',') && (cB[ii] != NEWLINE)) {
        if (cB[ii] != ' ') nonblank++;
        ii++;
    } /* while */
    if (nonblank == 0) 
        cerror(BADKNAME,NEARNULL);
    else if (nonblank == 1) { /* single character code */
        code = cB[cI];
        *term = cB[ii]; /* return terminator */
        cI = ii+1; /* advance past terminator */
        return(code); /* return key value */
    } /* nonblank else-if */

    keylist = GetKeyNames();
    code = identify_keyword(keylist,term);
    if (code == KTOUCH) { /* touch */
        if (*term == '(') {
            *tbits = extract_touch_keywords(term,')',TRUE); 
            if (*term == ')') {
            	*term = cB[cI]; /* get terminator after touch() */
            	if (*term != NEWLINE) cI++;
            }
        } else
            *tbits |= (1 << TLDOWN); /* default is left/down */ 
    } /* touch if */
    if ((*term != ',') && (*term != NEWLINE))
	cerror(NEEDCOMMA,NEARNULL);

    return(code);
    
} /* identify_key_name */

/* ******************************************************************* */

int compile_multiple_keywords(klist) /* compile a list of keywords */
/* returns number keywords found */
struct keywdinf *klist; /* list of keywords */

{   int kn;
    int nargs;
    int term;

    nargs = 0;
    skip_white_cB(); /* skip leading white space */
    term = cB[cI];
    while (term != NEWLINE) {
        nargs++; /* increment number keywords found */
        kn = identify_keyword(klist,&term);
        if ((term != ',') && (term != NEWLINE))
	    cerror(NEEDCOMMA,NEARNULL);
        compile_short_value(kn); /* add keyword value */
    } /* while */
    return(nargs);

} /* compile_multiple_keywords */

/* ******************************************************************* */

int compile_single_keyword(klist,term) /* compile one keyword */
/* returns keyword value */
struct keywdinf *klist; /* list of keywords */
int *term; /* terminating character (returned) */

{   int kn;

    kn = identify_keyword(klist,term);

    if ((*term != ',') && (*term != NEWLINE))
	cerror(NEEDCOMMA,NEARNULL);
    compile_short_value(kn); /* add keyword value */
    return(kn);

} /* compile_single_keyword */

/* ******************************************************************* */

int identify_keyword(klist,term) /* process pre-defined keyword */
/* returns numeric value corresponding to keyword */
struct keywdinf *klist; /* table of keywords/values */
int *term; /* terminating character (returned) */

{   char kname[20]; /* current keyword name from source */
    int nl; /* length of name */
    int ki; /* index in keyword list */

    /* extract next keyword from source */

    extract_keyword_cB(kname,20,TRUE,term);

    /* search list for keyword */
    
    ki = 0; /* index in keyword list */
    while (klist[ki].name) {
        if (strcmp(kname,klist[ki].name) == 0) 
            return(klist[ki].value);
        ki++;
    } /* while */

    cerror(SPECIFICERR,"Unrecognized keyword.");

} /* identify_keyword */

/* ******************************************************************* */

compile_keyword_and_args(klist,term)
struct keywdinf *klist; /* list of keywords */
int *term; /* terminator (assumed set on call) */
    
{   int kwcode; /* current keyword code */
    int unitn; /* unit number */
    unsigned int icon_plant; /* location to plant icon count */
    int num_icons; /* number icon tags */
    int icod; /* code for internal keyword */
    struct expra exper; /* expression analyzer params */
    int aii; /* index in arrays */

    kwcode = *term = 0; /* no keyword yet */
    while (*term != NEWLINE) {
    	skip_white_cB();
    	if (cB[cI] == NEWLINE)
    		break; /* end of arguments */
        if (kwcode && (*term != ';'))
            cerror(SPECIFICERR,"Seperate keyword phrases with semicolons.");
        
        kwcode = identify_keyword(klist,term);
        if (*term != ',' && *term != NEWLINE && *term != ';')
            cerror(SPECIFICERR,"Keyword should end with comma or semicolon.");
    
        keyword_counter++; /* count number keywords processed */
        compile_short_value(kwcode); /* add keyword value */
        switch (kwcode) {

        case KW_EDITABLE: /* keywords with int true/false arg */
        case KW_CORNER:   /* or no argument */
        case KW_DEFMENU:
        case KW_FACEMENU:
        case KW_FONTMENU:
        case KW_SIZEMENU:
        case KW_COLORMENU:
        case KW_JUSTMENU:
        case KW_HSCROLL:
        case KW_VSCROLL:
        case KW_FRAME:
        case KW_ACTIVE:
        case KW_ERASE:
        case KW_READONLY:
        case KW_READWRITE:
        case KW_WRITEONLY:
        case KW_STYLED:
        case KW_PLAIN:
        case KW_BOLD:
        case KW_ITALIC:
        case KW_PLAINEST:
        case KW_SUPSCRIPT:
        case KW_SUBSCRIPT:
        case KW_FULLJUST:
        case KW_LEFTJUST:
        case KW_RIGHTJUST:
        case KW_CENTER:
        case KW_BLACK:
        case KW_WHITE:
        case KW_RED:
        case KW_GREEN:
        case KW_BLUE:
        case KW_YELLOW:
        case KW_CYAN:
        case KW_MAGENTA:
        case KW_SERIF:
        case KW_SANS:
        case KW_SYMBOL:
        case KW_TYPEWRITER:
        case KW_BIGGER:
        case KW_SMALLER:
        case KW_HIGHLIGHT:
        case KW_UPHOT:
        case KW_FOCUSCLK:
        case KW_SINGLESEL:
        case KW_DEFCOLORST:
		case KW_SUPSUBADJ:
            if (*term == ',') {
                exper = defexp;
                exper.rtype = TINT; /* require integer result */
                exper.tsemic = TRUE; /* allow termination on semicolon */
                compile(&exper); /* evaluate numeric expression */
                *term = exper.lastchar;
			} else if (kwcode == KW_SUPSUBADJ) {
				compile_short_value(0); /* FALSE */
            } else {
                compile_short_value(-1); /* TRUE */
            } 
            break;
            
        case KW_ROUNDBOX: /* keywords with no additional arguments */
        case KW_CHECK:
        case KW_RADIO:
        case KW_THREED:  /* changed 6/3/91 BJM */
            if (*term == ',')
                cerror(TOOMANY,NEARNULL);
        break; /* no additional arguments */

        case KW_VALUE: /* floating value */
        case KW_PAGE:
        case KW_LINE:
        case KW_TAB:
        case KW_LEFTMAR:
        case KW_RIGHTMAR:
        case KW_NEWLINEH:
        case KW_SUPSUB:
            if (*term != ',')
                cerror(MISSINGARG,NEARNULL);
            exper = defexp;
            exper.rtype = TFLOAT; /* require floating result */
            exper.tsemic = TRUE; /* allow termination on semicolon */
            compile(&exper); /* evaluate numeric expression */
            *term = exper.lastchar;
            break;

        case KW_SELECT: /* marker expression */
        case KW_VISIBLE:
        case KW_HOTSTYLE:
        case KW_DYNC:
        case KW_DALERT:
        case KW_DOK:     
        case KW_FNAME:
            *term = compile_marker(FALSE,TRUE); /* marker expression */
            break;

        case KW_RANGE:
            if (*term != ',')
                cerror(MISSINGARG,NEARNULL);
            exper = defexp;
            exper.rtype = TFLOAT; /* require floating result */
            compile(&exper); /* evaluate numeric expression */
            *term = exper.lastchar;
            exper = defexp;
            exper.rtype = TFLOAT; /* require floating result */
            exper.tsemic = TRUE; /* allow termination on semicolon */
            compile(&exper); /* evaluate numeric expression */
            *term = exper.lastchar;
            break;

        case KW_ICON:
            compile_marker(FALSE,FALSE); /* marker expression */
            cmpbuf_word(TKEYWORD); /* add keyword for short value */
            icon_plant = cmpl; /* remember where to plant value */
            cmpbuf_word(0); /* dummy value, planted later */
            num_icons = 0; 
            do { /* compile icon expressions */
                exper = defexp;
                exper.rtype = TINT; /* require integer result */
                exper.tsemic = TRUE; /* allow termination on semicolon */
                compile(&exper); /* evaluate numeric expression */
                *term = exper.lastchar;
                num_icons++;
            } while ((*term != NEWLINE) && (*term != ';'));
            if (num_icons > 100)
                cerror(TOOMANY,NEARNULL);
            cmpbuf_plant_word(icon_plant,num_icons); /* plant number icons */
            break;

        case KW_BEFORE:
        case KW_AFTER:
        case KW_HOTUNIT:
            if (*term != ',')
                cerror(NEEDCOMMA,NEARNULL);
            if (kwcode != KW_HOTUNIT) {
            	/* look up event type keyword */
            	icod = identify_keyword(afterlist,term);
            	compile_short_value(icod);
            }
            unitn = extract_unit(NEARNULL,term,TRUE);
            if (unitn == -2) {
                cerror(MISSINGUNIT,NEARNULL);
            } else if (unitn == -1) /* indirect unit reference */
                cmpbuf_word(MUNIT);
            else compile_short_value(unitn); /* normal unit reference */
            if (*term == '(') {
                compile_short_value(TRUE); /* mark argument present */
                cI--; /* back up to balance parens */
                *term = compile_float();
            } else {
                compile_short_value(FALSE); /* no argument */
            } /* term else */
            break;
            
        case KW_SYSFONTHT: /* single numeric store-able argument */
        case KW_PALETTESZ:
        case KW_DEFCOLOR:
            exper = defexp;
    		exper.reqstore = TRUE; /* store-ability info required */
    		exper.tsemic = TRUE; /* allow termination on semicolon */
    		compile(&exper);
    		if (!exper.canstore) cerror(NOTSTORABLE,NEARNULL);
    		*term = exper.lastchar;
        	break;
        	
        case KW_DEFRGB:
        	for (aii=0; aii<3; aii++) {
                exper = defexp;
        		exper.arrayok = TRUE; /* allow whole array */
        		exper.reqstore = TRUE; /* get store-ability info */
        		compile(&exper); /* compile buffer expression */
        		if (!exper.canstore) 
        			cerror(NOTSTORABLE,NEARNULL); 
        		compile_short_value((int)(exper.warray)); /* add array flag */
        		if (!exper.warray)
        			cerror(SPECIFICERR,"Must use array here");
        		*term = exper.lastchar;
        	} /* for */
        	break;
        
        case KW_DEFFGND:
        case KW_DEFBGND:
			for (aii=0; aii<3; aii++) {
                exper = defexp;
        		exper.reqstore = TRUE; /* get store-ability info */
        		compile(&exper); /* compile buffer expression */
        		if (!exper.canstore) 
        			cerror(NOTSTORABLE,NEARNULL); 
        		*term = exper.lastchar;
        	} /* for */
        	break;

        case KW_DINPUT:
        	compile_marker(FALSE,FALSE);
        	compile_marker(FALSE,FALSE);
        	*term = compile_marker(TRUE,TRUE);
        	break;
        	
        case KW_DPRINTS:
        case KW_DPRINTX:
        	skip_white_cB();
        	*term = cB[cI];
        	break;
        	
        case KW_IMAGESTYLE:
        	*term = compile_txtype(TXSCREEN,TRUE);
        	break;
        	
        default:
            cerror(SPECIFICERR,"didn't recognize keyword");

        } /* switch */
    } /* while */

    return(0);

} /* compile_keyword_and_args */

/* ******************************************************************* */

static unsigned char skippnd = FALSE; /* TRUE if skip  pending */
static int lastdrw = 0; /* last operation: SKIP, TPOINT, TDOT */
static long lastskp; /* position of last SKIP operator */
static int totpoints; /* total points (over continued command) */

int compile_points(min,limit,type,stopl,cont,czxy,blank,coarse,skip)
/* returns TRUE if stopped on NEWLINE, FALSE otherwise */

int min; /* minimum number of points required */
int limit; /* +n = maximum number points allowed */
           /*  0 = no limit */
           /* -n = break command at/around n points */
int type; /* 0 = absolute (fixed point (Coord) expressions) */
          /* 1 = relative (floating expressions) */
          /* 2 = graphing (floating expressions) */
          /* 3 = integer non-coordinate expressions */
int stopl; /* TRUE if should stop when limit reached (else error) */
int cont; /* TRUE if continued command */
int czxy; /* TRUE if continued command may need zxy */
int blank; /* TRUE if blank tag legal */
           /* 1 = blank tag = single point zwherex,zwherey */
           /* 2 = blank tag = no arguments */
int coarse; /* TRUE if coarse grid allowed */
int skip; /* TRUE if skip allowed */

{   struct expra coordexa; /* expr analyzer params for co-ordinates */
    int npoints; /* number points so far */
    int loc; /* index in source */
    short FAR *sbinp; /* pointer in compile buffer */
    int breakloc; /* point at which to break up command */
    int wcont; /* TRUE if should continue digesting points */
    int didpnt; /* TRUE if processed a point */
    int ist; /* TRUE if 1st tag */
    char c;
 
    if (!cont) {
        skippnd = FALSE; /* not continued, no skip pending */
        lastdrw = 0; /* not continued, no previous draw op */
        totpoints = 0; /* total num points for command+continuation */
    }
    coordexa = defexp; /* set up expr analyzer for co-ordinates */
    coordexa.tsemic = TRUE; /* semicolon is legal terminator */
    if (type == 0) coordexa.rtype = TCOORD; /* require Coord result */
    else if (type == 3) coordexa.rtype = TINT; /* require integer result */
    else coordexa.rtype = TFLOAT; /* require floating result */

    /* check for indefinite-length with a line too long to fit in cB */

    breakloc = 0; /* no need to break up command yet */
    loc = cI;
    if (buffFull && (limit < 0)) {
        while ((loc = pbscan(cB,loc,";")) >= 0) {
            breakloc = loc++; /* find last semicolon */
        } /* while */
    } /* buffFull */

    wcont = TRUE; /* set to continue loop */
    didpnt = FALSE; /* no point processed yet */
    ist = TRUE; /* first tag */
    npoints = 0;

    do {
        if (ist) { /* first tag */
            ist = FALSE;
            loc = cI; /* starting position of tag */
            c = next_cB(); /* check for leading semicolon */
            if ((c == NEWLINE) && (blank == 2)) 
                return(0); /* blank tag legal = no arguments */
            if ((c == ';') || (cont && (!skippnd) && czxy) || 
                ((c == NEWLINE) && blank)){
                if ((c == ';') || ((c == NEWLINE) && blank)){
                    skippnd = lastdrw = 0; /* no dangling skip */
                    coordexa.lastchar = c; /* update terminator */
                } else cI = loc;

                /* insert code for zwherex, zwherey */
                /* floating or fixed (Coord) */
    
                if (type == 0) 
                    cmpbuf_word(ZXYA);  /* absolute, coord */
                else if (type == 1) 
                    cmpbuf_word(ZXYR);  /* relative */
                else if (type == 2)
                    cmpbuf_word(ZXYG); /* graphing */
                else 
                    cmpbuf_word(ZXYI); /* absolute, integer */
                if (skip) 
                    cmpbuf_word(TPOINT); 
                npoints++; /* number points encountered */
    
                loc = cI; /* starting position of next tag */
                c = next_cB(); /* check if at end of line */
                if (c == NEWLINE) {
                    coordexa.lastchar = c;
                } else cI = loc; /* set back to start of tag */
            } else cI = loc; /* back up to starting char */
        } else {

            /* evaluate first expression: x, coarse or skip */

            coordexa.allowsk = skip; /* SKIP allowed/not */
            compile(&coordexa); /* evaluate x or coarse */
            if (coordexa.lastchar == ';' && cB[cI] == NEWLINE) {
                /* the semicolon can be ignored because it is the last thing on line */
                /* this handles the skip & coarse case.  The fine case is handled below */
                coordexa.lastchar = NEWLINE;
            }

            if (coordexa.exprtype == SKIP) {
                /* handle skip */

                if (coordexa.lastchar == ',')
                cerror(NEEDSEMI,NEARNULL);
                skippnd = TRUE;
                didpnt = FALSE; /* no point processed yet */
            } else if (coordexa.lastchar == ',') { 

                /* handle fine grid */

                coordexa.allowsk = FALSE; /* no skip */
                compile(&coordexa); /* evaluate y */
                if (coordexa.lastchar == ';' && cB[cI] == NEWLINE) {
                    /* the semicolon can be ignored because it is the last thing on line */
                    coordexa.lastchar = NEWLINE;
                }
                didpnt = TRUE;
            } else { 

                /* handle coarse grid */

                if (!coarse || !allowcoarse)
                    cerror(SPECIFICERR,"Coordinates should be x,y; ");
                cmpbuf_word(COTOFN); /* add coarse-to-fine */
                didpnt = TRUE;
            } /* coarse else */

            /* handle skip */
        
            if (skippnd) {

                /* handle skip;x,y;skip; - convert to dot */

                if (lastdrw == SKIP) {
                    sbinp = (short FAR *)(&cmpbuf[lastskp]);
                    *sbinp = TDOT; /* convert to dot */
                }
                if (didpnt) {
                    lastskp = cmpl; /* loc of last skip operator */
                    cmpbuf_word(SKIP); /* add skip operator */
                    skippnd = FALSE;
                    lastdrw = SKIP;
                    npoints++; /* number points encountered */
                } /* didpnt if */
            } else { 
                npoints++; /* number points encountered */
                if (skip) {

                    /* if command allows skip, must label point */

                    cmpbuf_word(TPOINT); /* add point operator */
                    lastdrw = TPOINT;
                } /* skip if */
            } /* skippnd else */
        } /* semicolon else */

        if ((limit > 0) && ((totpoints+npoints) > limit)) 
            cerror(TOOMANY,NEARNULL);
        if (coordexa.lastchar == ',') cerror(NEEDSEMI,NEARNULL);
        if (coordexa.lastchar == NEWLINE) wcont = FALSE;

        /* check if running out of input */

        if (breakloc && (cI >= breakloc)) wcont = FALSE;

        /* check if producing too many points */

        if ((limit < 0) && (npoints >= (-limit))) wcont = FALSE;
        if (stopl && (npoints >= limit))
            wcont = FALSE;
    } while (wcont);

    /* treat as continued command if had to break command up */

    totpoints += npoints; /* total for command + continuation */
    if (stopl) {
        if (totpoints < min)
            cerror(MISSINGARG,NEARNULL);
    } else {
        if (coordexa.lastchar != NEWLINE) {
            refillBuff = TRUE; 
        } else {
            if (totpoints < min)
                cerror(MISSINGARG,NEARNULL);
        } /* newline else */
    } /* stopl else */
    return(coordexa.lastchar == NEWLINE);

} /* compile_points */

/* ******************************************************************* */

static compile_write(contin,condtl) 
int contin; /* TRUE if continued */
int condtl; /* TRUE if conditional */

{   short styles[NSTYLES]; /* array for current styles */
    int i;
    long loc,end;
    long embedBegin; /* position at start of embed */
    int term; /* keyword terminating character */
    int embedf; /* TRUE if embed(s) */
    long len;
    unsigned char c;
    DocP dp;
    long dummy;
		
    /* if continued, add text from previous -write- to text pool */
    
    if (contin) { 
        if (txt_lastc == NEWLINE) 
            txt_src_len++; /* include NEWLINE */
        len = TUTORget_len_doc(textpool);
        cmp_mem_free(); /* release compile buffer */
        TUTORchange_doc_doc(textpool,len,0L,0L,len,source,
                            txt_src_start,txt_src_len,&dummy,FALSE);

        txt_pool_len += txt_src_len;
        if (txt_lastc != NEWLINE) {
            /* add newline to textpool */
            /* this probably happened because preceeding line ended in comment */
            appenddoc(textpool,(char FAR *) NEWLINES,1);
            txt_pool_len++; /* to account for newline */
        }
        cmp_mem_lock(); /* reaquire compile buffer */
    } else {
        txt_embed = 0; /* no embeds yet */
        txt_optn = 0; /* no commands yet */
        len = TUTORget_len_doc(textpool);
        txt_pool_start = len-unittab[compunit].textp;
        txt_pool_len = 0;
        /* add C_BEGINTEXT if start of new -write- */
        cmpbuf_write_cmd(C_BEGINTEXT);
    }
    
    /* get length of this write */
    
    i = cI;
    while ((cB[i] != NEWLINE) && cB[i])
        i++;
    txt_lastc = cB[i]; /* save terminating character */
    if (txt_lastc == NEWLINE && TUTORcharat_doc(source,startofline+i-ciStart) != NEWLINE)
        txt_lastc = 0; /* write was terminated early due to comment 
                            we don't want to include $ as if it were newline */
    
    txt_end = C_ENDTEXT; /* initialize text end command */
    txt_src_start = loc = startofline+cI;
    end = srcEnd;

    while (loc < end) { /* scan thru chars */
    
        /* check for embedded operation */

        c = cB[cI];
        if (c == '<'  && cB[cI+1] == '|') { /* if embed */
            embedBegin = loc;
            /* compile text up to embed */
            len = TUTORget_len_doc(textpool);
            txt_src_len = loc-txt_src_start;
            txt_pool_len += txt_src_len;
            if (txt_pool_len) {
                if (txt_src_len) {
                    cmp_mem_free(); /* release buffers */
                    TUTORchange_doc_doc(textpool,len,0L,0L,len,source,
                                txt_src_start,txt_src_len,&dummy,FALSE);    
                    /* re-aquire pointers */
                    cmp_mem_lock(); 
                    } /* txt_src_len if */
                cmpbuf_word(TEXTARG);
                cmpbuf_long((long)txt_pool_start);
                cmpbuf_long((long)txt_pool_len);
                cmpbuf_write_cmd(C_WRITE);
            } /* txt_pool_len if */
            cI += 2;
            if (buffFull)
                RefillBuffer(); /* make sure expression in buffer */
            txt_embed = TRUE; /* flag embed encountered */
            compile_embed(TRUE);
            txt_pool_len = txt_src_len = 0;
            txt_src_start = loc = startofline+cI; /* new start of text */
            txt_pool_start = TUTORget_len_doc(textpool)-unittab[compunit].textp;
            
            /* we have just finished embed */
    
            if (tdoc_getstyles(source,embedBegin,styles)) {
        
                /* wrap styles around embeded show */

                if (styles[PARASTYLE] != DEFSTYLE)
                    styles[PARASTYLE] &= ~VISMASK; /* force visible */
                for (i=0; i<NSTYLES; i++) {
                    if (styles[i] != DEFSTYLE) {
                        compile_short_value(i); /* what kind of style */
                        compile_short_value(styles[i]); /* style */
                    }
                } /* for */
                cmpbuf_word(C_WRAPSTYLE);
            } /* styled if */
        } else { /* not embed */
            if (c == NEWLINE) 
                break; /* exit while */
            loc++;
            cI++;
            if (buffFull && !cB[cI]) { /* need to recharge buffer */
                RefillBuffer();
                if (nBuffChars == 0)
                    break; /* end of unit */
                srcPos += nBuffChars;
            }
        } /* embed else */
    } /* end while */
    if (loc >= end) {
        srcPos = end;
        cI = 0;
        cerror(BADTAG,NEARNULL);
    }
    
    txt_src_len = loc-txt_src_start; /* length of text remaining */
    
} /* compile_write */

/* ******************************************************************* */

static CheckSimpleWrite(doc,pos,len)
Memh doc;
long pos, len;  /* defines region of interest */
/* returns 0 if region is default styled, 1 otherwise */
    {
    DocP dp;
    short styles[NSTYLES];
    StyleDatP sp;
    Style1 SHUGE *s1p;
    int ii, nextStyle;
    
    dp = (DocP) GetPtr(doc);
    if (!dp->styles)
        { /* no styles at all */
        ReleasePtr(doc);
        KillPtr(dp);
        return(0);
        }
    
    nextStyle = AtTStyle(dp->styles,pos,styles);
    /* check for non-default styles at pos */
    for (ii=0; ii<NSTYLES; ii++)
        if (styles[ii] != DEFSTYLE)
            break;
    
    if (ii >= NSTYLES)
        { /* all styles were default, check for style change in region of interest */
        if (nextStyle >= 0)
            { /* there is another style */
            valid_style(nextStyle);
            sp = (StyleDatP) GetPtr(dp->styles);
            if (sp->styles[nextStyle].pos < pos+len)
                ii = 0; /* so it is less than NSTYLES */
            ReleasePtr(dp->styles);
            KillPtr(sp);
            }
        }
    
    ReleasePtr(doc);
    KillPtr(dp);
    return((ii >= NSTYLES) ? 0 : 1);
    }

/* ******************************************************************* */

static compile_text() 

{   short styles[NSTYLES]; /* array for current styles */
    int i;
    long start,loc, end;
    long embedBegin; /* position at start of embed */
    int term; /* keyword terminating character */
    unsigned char c;
    char foundEmbed;
    
    /* have to read in first line of text */
  
    cI = 0;
    startofline = srcPos;
    RefillBuffer();
    if (nBuffChars == 0)  /* nothing to read - error */
        cerror(SPECIFICERR, "Text must end with a backslash.");
    srcPos += nBuffChars;
    
    start = loc = startofline+cI;
    end = srcEnd;
    
    foundEmbed = FALSE;
    
    if (cB[cI] == '\\') {
        /* empty text.  leave source at backslash and we're done */
        srcPos = startofline;
    } else while (loc < end) { /* scan thru chars */
        
        /* check for embedded operation */

	c = cB[cI];
	if (c == '<'  && cB[cI+1] == '|') { /* if embed */
            foundEmbed = TRUE;
	    embedBegin = loc;

            textpool_string((loc-start),start);   
            cmpbuf_word(C_WRITE);
            cI += 2;
            if (buffFull)
                RefillBuffer(); /* make sure expression in buffer */
            compile_embed(TRUE);

            /* we have just finished embed */

            if (tdoc_getstyles(source,embedBegin,styles)) {
        
                /* wrap styles around embeded show */

                if (styles[PARASTYLE] != DEFSTYLE)
                    styles[PARASTYLE] &= ~VISMASK; /* force visible */
                for (i=0; i<NSTYLES; i++) {
                    if (styles[i] != DEFSTYLE)
                        {
                        compile_short_value(i); /* which style */
                        compile_short_value(styles[i]); /* style */
                        }
                }
                cmpbuf_word(C_WRAPSTYLE);
            } /* styled if */
            start = loc = startofline+cI; /* new start of text */
        } else { /* not embed */
            if (c == NEWLINE) {
                
                /* recharge buffer with next line */
/*                startofline = srcPos; */
				startofline = loc+1; /* changed ---- dma 5/21/97 */
                cI = 0;
                RefillBuffer();
                if (nBuffChars == 0) {
                    /* unit ended without end of text */
                    loc = end; /* force error */
                    break;
                }
                if (cB[cI]  == '\\') {
                	srcPos = loc+1; /* added ---- dma 5/21/97 */
                    break; /* text terminated */
                } else {
                    srcPos += nBuffChars;
                    cI = -1; /* so later cI++ puts cI back to 0 */
                }
            } /* NEWLINE if */
            loc++;
            cI++;
            if (buffFull && !cB[cI]) { /* need to recharge buffer */
                RefillBuffer();
                if (nBuffChars == 0) {
                    /* unit ended without end of text */
                    loc = end; /* force error */
                    break; /* end of unit */
                }
                srcPos += nBuffChars;
            }
        } /* embed else */
    } /* end while */
    if (loc >= end) {
        srcPos = end;
        cI = 0;
        cerror(SPECIFICERR, "Text must end with a backslash.");
    }
    textpool_string((loc-start), start);
    if (foundEmbed || newcmd == C_STRING)
        cmpbuf_word(C_WRITE);
    else /* non-embed text command */
        cmpbuf_word(C_WRITE2); /* so execution runs directly from textpool */

} /* compile_text */

/* ******************************************************************* */

int compile_general_text(terminator,trim,begin) 
/* returns terminating character */
int terminator; /* = NEWLINE (answer/wrong/exact/exactw) */
            /* = -1 (file name; accept only alphanumeric, slash, period) */
            /* = -2 (menu -- undecided yet how to treat) */
int trim;    /* = TRUE if should discard leading and trailing white space */
             /*   (all but exact, exactw) */
int begin;   /* = TRUE if should insert special begintext to append */
             /*   this string after previous */

{   int out;
    short styles[NSTYLES]; /* array for current styles */
    int i;
    long start,loc;
    long styleChange; /* position where style changes */
    int term; /* keyword terminating character */
    unsigned char cc;

    /* strip leading whitespace */

    if (trim)
        skip_white_cB();

    start = loc = startofline+cI;
    out = FALSE;
    /* get pos of next style change */
    styleChange = tdoc_diffstyle(source,startofline);
    if (begin)
        cmpbuf_word(C_BEGINTEXT3); /* add text setup */
    else
        cmpbuf_word(C_BEGINTEXT2);

    do { /* scan thru chars */
        if (loc >= styleChange) {
            /* style change not allowed... */
            cI = styleChange - startofline; /* position at style change */
            cerror(SPECIFICERR, "Styles are not allowed here.");
        }

        /* check for embedded operation */

	cc = cB[cI];
        if (cc == 0) cerror(BADTAG,NEARNULL);
        if (cc == '<'  && cB[cI+1] == '|') { /* if embed */
            cmpbuf_string((unsigned int)(loc-start),start,FALSE);   
            cmpbuf_word(C_WRITE1);  
            cI += 2;
            compile_embed(FALSE);
            start = loc = startofline+cI; /* new start of text */ 
        } else { /* not embed */
            cI++; 
            if ((cc == NEWLINE) || (cc == terminator)) out = TRUE;
            else switch (terminator) {
                case -1: /* file name:  permit .-_/ and \ and ~ */
                    if (!(CTisalnum(cc) || cc == ' ' || cc == '.' || 
                       cc == '-' || cc == '_' || cc == '/' || 
                       cc == '\\' || cc == ':' || cc == '~')) 
                        out = TRUE;
                    break;
                case -2: /* menu:  terminators are ,;: */
                    if (cc == ',' || cc == ';' || cc == ':') 
                        out = TRUE;
                    break;
            } /* terminator switch */
            if (out) break; /* exit while */
            loc++;
        } /* embed else */
    } while (TRUE);

    cmpbuf_string((unsigned int) (loc-start), start,FALSE);
    cmpbuf_word(C_WRITE1); /* finish last -write- */
    cmpbuf_word(C_ENDTEXT2); /* end embedded commands */
    return(cc);

} /* compile_general_text */

/* ******************************************************************* */

static long tdoc_diffstyle(theD,baseP)
Memh theD; /* Tutor document */
long baseP; /* the position of the "base" style */
/* returns position after baseP where style next changes
        (or position past doc end if there are no more style changes) */
    {
    DocP dp;
    long nextStyle;
    short styleInd;
    StyleDatP sp;
    Style1 SHUGE *s1p, SHUGE *s1End;
    
    dp = (DocP) GetPtr(theD);
    if (!dp->styles)
        nextStyle = dp->totLen + 1000L;
    else
        {
        sp = (StyleDatP) GetPtr(dp->styles);
        styleInd = FindBlockTStyle(sp,baseP);
        s1p = sp->styles + styleInd;
        s1End = sp->styles + sp->sHead.dAnn; /* just past last style */
        while (s1p < s1End && s1p->pos <= baseP)
            s1p++;
        if (s1p < s1End)
            nextStyle = s1p->pos; /* found another style starting after baseP */
        else
            nextStyle = dp->totLen + 1000L;
        ReleasePtr(dp->styles);
        KillPtr(sp);
        }
    ReleasePtr(theD);
    KillPtr(dp);
    
    return(nextStyle);
    }

/* ******************************************************************* */

compile_embed(docOrBuff) /* compile embedded show command */
int docOrBuff;  /* TRUE if show goes to document, FALSE if to buff */
{   int embedc; /* command code */
    int term; /* terminating character */
    long npos,nlen; /* position/length in textpool */
    int nlegal; /* number tags legal in show */
    struct expra shexa[3]; /* expr analyzer params for embedded shows */
    int ii;
    char cc;

    /* identify embedded command */

    embedc = identify_keyword(embedlist,&term);
    if (term == '|') {

        /* process cr, tab, quote embeds */

        if (embedc >= 0) cerror(BADTAG,NEARNULL);
        term = cB[cI++]; /* end after > */

        /* build 1-char -write- command */

        if (embedc == -1) cc = NEWLINE;   /* <|cr|> */
        else if (embedc == -2) cc = '\t'; /* <|tab|> */
        else cc = '"';                    /* <|quote|> */
        if (docOrBuff) { /* write goes to document */
            nlen = TUTORget_len_doc(textpool);
            npos = nlen-unittab[compunit].textp;
            InsertString(textpool,nlen,(char FAR *) &cc,1L); 
            cmpbuf_word(TEXTARG);
            cmpbuf_long((long)(npos));
            cmpbuf_long(1L);
            cmpbuf_write_cmd(C_WRITE);
        } else { /* write goes to buffer */
            cmpbuf_word(TEXTARG1);
            cmpbuf_word(1); /* length */
            cmpbuf[cmpl++] = cc; /* character code */
            cmpbuf[cmpl++] = 0; /* fill to align on word boundary */
            cmpbuf_write_cmd(C_WRITE1);
        }
    } else { 

        /* process embedded show */

        if (term != ',') cerror(BADTAG,NEARNULL); 
        nlegal = 2;
        shexa[0] = shexa[1] = shexa[2] = defexp;
        shexa[0].tembed = shexa[1].tembed = shexa[2].tembed = TRUE;
        shexa[1].rtype = shexa[2].rtype = TINT;
        if (embedc == C_SHOW) {
            shexa[0].reqstore = TRUE; /* store-ability info required */
            shexa[0].allowm = TRUE; /* allow markers */
            shexa[2].rtype = TFLOAT; /* last arg is float */
            nlegal = 3;
        } else if (embedc == C_SHOWT) {
            shexa[0].rtype = TFLOAT; /* require float value */
            nlegal = 3;
       } else if ((embedc == C_SHOWE) || (embedc == C_SHOWZ)){
            shexa[0].rtype = TFLOAT; /* require float value */
            nlegal = 2;
        } else if ((embedc == C_SHOWO) || (embedc == C_SHOWB) ||
               (embedc == C_SHOWH)) {
            shexa[0].reqstore = TRUE; /* store-ability info required */
        } /* else if */
        ii = compile_general(&shexa[0],1,nlegal);
        if ((shexa[0].exprtype == TMARK) && (ii > 1))
            cerror(SPECIFICERR,"Too many arguments on show of marker");
        term = shexa[ii-1].lastchar; /* get terminator */
        cmpbuf_write_cmd(embedc);
    } /* show else */
    if (term != '>') cerror(BADTAG,NEARNULL);

} /* compile_embed */

/* ******************************************************************* */

cmpbuf_write_cmd(code) /* add -write- related command code to binary */
int code;

{
    if ((txt_optn >= 0) && (txt_optn < TXT_OPTMAX))
        txt_optp[txt_optn++] = cmpl; /* record command position */
    else txt_optn = -1; /* no longer recording positions */
    cmpbuf_word(code); /* add command code to binary */
    
} /* cmpbuf_write_cmd */

/* ******************************************************************* */

static cmpbuf_string(len, loc,newlf) /* add string to binary */
int len;  /* length of text */
long loc; /* position in source document */
int newlf; /* if TRUE preceed string with newline */
{   int npos; /* position relative to text for unit */

    cmpbuf_word(TEXTARG1);
    cmpbuf_word(len + (newlf ? 1 : 0));
    if (newlf)
        cmpbuf[cmpl++] = NEWLINE;
    TUTORget_string_doc(source,loc,(long) len,(unsigned char FAR *) (cmpbuf+cmpl));
    cmpl += len;
    if (cmpl & 1) 
        cmpbuf[cmpl++] = '\0'; /* align on word boundary */

} /* cmpbuf_string */

/* ******************************************************************* */

textpool_string(len, loc) /* add string to binary */
long len;  /* length of text */
long loc; /* position in source document */

{   long npos; /* position relative to text for unit */
    long poolLen;
    long extraDumm;

    poolLen = TUTORget_len_doc(textpool);
    npos = poolLen-unittab[compunit].textp;
    
    cmpbuf_word(TEXTARG);
    cmpbuf_long(npos);
    cmpbuf_long(len);
    
    cmp_mem_free(); /* release buffers */
    TUTORchange_doc_doc(textpool,poolLen,0L,0L,poolLen,source,loc,(long) len,
            &extraDumm,FALSE);
    cmp_mem_lock(); /* re-aquire pointers */

} /* textpool_string */

/* ******************************************************************* */

int extract_unit(unitn,term,iFlag) /* extract unit name, return unit number */
char *unitn; /* returned = unit name */
int *term; /* returned = terminating character */
int iFlag;  /* TRUE if we allow (marker) indirect unit references */
/* for direct references we return the unit number.
    An indirect reference is indicated with a return of -1.
    Failure is indicated with a return of -2 */

{   char uname[NAMEL+1]; /* unit name */
    int rpareni; /* index of right paren */
    int rparenc; /* character after right paren */
    char *balanceStr; /* ) or ] */
    int ii;

    if (unitn)
        *unitn = '\0'; /* pre-clear unit name string */
    if (iFlag) { 
        /* check for indirect reference */
        skip_white_cB();
	if ((cB[cI] == '(') || (cB[cI] == '[')) {
	    /* find terminating right paren or bracket */
	    if (cB[cI] == '(') balanceStr = ")";
	    else balanceStr = "]";
	    rpareni = pbscan(cB,cI+1,balanceStr);
            if (rpareni >= 0) {
                rpareni++; /* advance past right paren */
                while ((cB[rpareni] == ' ') || (cB[rpareni] == '\t'))
                    rpareni++; /* skip over white space */
                /* save char and force end of expression */
                rparenc = cB[rpareni];
                cB[rpareni] = NEWLINE; /* end expression */
            }
            /* start of indirect reference */
	    compile_marker(FALSE,FALSE);
	    if ((rpareni >= 0) && (rparenc == NEWLINE) && (cI > rpareni))
		cI = rpareni; /* back up to newline */
            /* restore cB */
            if (rpareni >= 0) { /* restore character */
                cB[rpareni] = rparenc; 
            }
            *term = rparenc; /* return termminating char */
            return(-1); /* indicates indirect reference */
        }
    }
    
    extract_keyword_cB(uname,32,FALSE,term); /* extract unit name from cB */

    /* look up unit name */

    ii = MatchUnitName((unsigned char *) uname);
    if (ii < 1)
        ii = -2; /* failure (or match with *ieu) gives -2 return */
    
    if (unitn)
        strcpy(unitn,uname); /* return unit name */
    return(ii);

} /* extract_unit */

/* ******************************************************************* */

static int FindArrowIndent()
/* returns indent level of most recent arrow, or -1 if can't find */

{   int ilevel; /* index in indentlevel[] */

    ilevel = indentlevel-1;
    while (ilevel >= 0 && (indent[ilevel].stype != arrowkind))
        ilevel--;
    return(ilevel);

} /* FindArrowIndent */

/* ******************************************************************* */

static cmp_mem_free() 

{
    if (xtP) { /* allow expr table to move around */
        ReleasePtr(xtH); 
        xtP = NULL;
    }
        
    /* release compile buffer for memory management */

    if (cmpLocked){ /* free compile buffer */
        ReleasePtr(cmpH);
        KillPtr(cmpbuf);
        cmpLocked = FALSE;
    } /* cmpLocked if */

} /* cmp_mem_free */

/* ******************************************************************* */

static cmp_mem_lock()

{
    /* re-aquire expr table pointer */

    if (xtP == NULL)
        xtP = (struct exprt FAR *) GetPtr(xtH); 

    /* re-aquire compile buffer */
    
    if (!cmpLocked) {
        cmpbuf = (unsigned char FAR *) GetPtr(cmpH);
        cmpLocked = TRUE;
        defexp.pcode = cmpbuf; /* pcode output to cmpbuf, cmpl */
    }

} /* cmp_mem_lock */

/* ******************************************************************* */
