
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Declarations matching ecglobal.c

KSW 9/88
*/

#ifndef _ecglobalh
#define _ecglobalh

#ifndef setjmp_d
#include "setjmp.h"
#define setjmp_d
#endif

#ifndef _computeh
#include "compute.h"
#endif


/* not needed by compiler */
extern Memh ed1H;   /* editor text view */
extern int twf; /* trace window debugging (PC) */
extern int spyf;    /* profiling on/off flag */
extern int lforkf;  /* layout fork flag (-d) option on command */
extern int DictWn;  /* dictionary window number */
extern struct tutorview FAR *DictVp;    /* dictionary main view */
extern int MsgWn; /* message window number */
extern struct tutorview FAR *MsgVp; /* message main view */
extern Memh MsgDocH; /* handle on message document */
extern Memh MsgPanelH; /* handle on message text panel */
extern int AboutWn; /* about box window number */
extern struct tutorview FAR *AboutVp; /* about box view */
extern int HelpWn;  /* help window number */
extern struct tutorview FAR *HelpVp;  /* help main view number */
extern int DebugWn;  /* debugger window number */
extern struct tutorview FAR *DebugVp;  /* debugger main view number */
extern int TraceWn; /* trace window number */
extern int SelectWn; /* select program window */
extern struct tutorview FAR *SelectVp; /* select program view */
extern FileRef binaryFile; /* file where current binary is stored */
extern short mkall; /* marks entire source document */
extern int newsrfile;   /* TRUE if newly-created source file */
extern int fileSpecified; /* non-zero if file name specified */
extern char exechalt;

/* needed by compiler */

extern long lvaraddr; /* local define address -- no. of stack vars used */
extern Memh source;  /* source read from disk */
extern int sourcemalloc;            /* number of table entries */
extern int csourcen;    /* index of current source in sourcetable */
extern int codegen; /* TRUE if can generate compiled code */
extern int ExecWinX; /* initial executor window X size */
extern int ExecWinY; /* initial executor window Y size */
extern int usesColor; /* TRUE if program has -color- commands */
extern Memh unitNames;
extern unsigned unitmalloc; /* number of unit slots malloc-ed */
extern int labelID; /* current internal branch label */
/* needed by compiler in only 1 place */
extern jmp_buf errjmpbuff; /* general compile/execution error longjmp */ /* only in cerror */

/* needed only by compiler */

#endif  /* _ecglobalh */
