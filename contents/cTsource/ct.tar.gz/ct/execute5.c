
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University. */

/* less frequently used commands */

#include "execdefs.h"
#include "eglobals.h"
#include "ecglobal.h"
#include "tglobals.h"
#include "exprdefs.h"
#include "fkeys.h"
#include "kglobals.h"

/* ******************************************************************* */

#ifdef ctproto
extern Memh LoadTable(char *tableFile,int *tableSize);
extern int TUTORdump(char *str);
extern int TUTORload_palette(FileRef FAR *fRef);
long  TUTORget_hsize(unsigned int  mm);
extern int TUTORfree_palette(Memh palH);
extern Memh TUTORalloc_palette(int pSlots);
extern void TUTORset_color(int select,struct tutorColor *newColor);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
int TUTORset_window_title(int wid,char *wt);
extern int  mvar_temp_cleanup(void);
extern int arraybnds(void);
extern int TUTORset_sub_new(int sub,int new);
int  lclocy(long  q);
int  lclocx(long  q);
long  FloatToCoord(double  zz);
extern int cmd_supsub(void);
int  TUTORset_textfont(int  jj);
extern int TUTORset_color_rgb(int select,int SysOrPal,double rr,double gg,double bb);
int  TUTORfree_handle(unsigned int  mm);
int  mvar_assign(struct markvar SHUGE *vaddr,struct  markvar SHUGE *mx);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
int  mvar_init(struct  markvar SHUGE *mp);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
extern int TUTORrelease_font(int findx,long fam,int size,unsigned int face,int forget);
int ex_arrayerr(void);
int  cmd_fine(void);
int  cmd_rescale(void);
int  cmd_coarse(void);
int  cmd_palette(void);
int  cmd_newpal(void);
int  xpalette(int  newflag);
int cmd_webpal(void);
extern double  ReadArr(int atype,int  stacki,int  ind);
extern int  SetSlot(struct  CTcolorentry FAR *cep,int  slot,double  red,double  green,double  blue,int  ffall,int  bfall,int  reserve);
int  cmd_rgb(void);
int  cmd_hsv(void);
int  hsvrgb(int  type);
int  cmd_getrgb(void);
int  cmd_gethsv(void);
int cmd_fpalette(void);
int  xgetrgb(int  type);
int  cmd_wcolor(void);
int cmd_wtitle(void);
int  cmd_clip(void);
int  cmd_rclip(void);
int  cmd_gclip(void);
int  argclip(int  type);
int  cmd_enable(void);
int  cmd_disable(void);
int  cmd_press(void);
int  cmd_clrkey(void);
int  cmd_getkey(void);
int cmd_newline(void);
int  cmd_font(void);
int cmd_fontp(void);
int  cmd_icons(void);
int  cmd_pattern(void);
int  cmd_cursor(void);
int  cmd_beep(void);
int  cmd_execute(void);
int  cmd_svers(void);
int  cmd_eraseu(void);
int  cmd_reshape(void);
int  cmd_finishu(void);
int  cmd_iarrow(void);
int  cmd_ijudge(void);
int  cmd_imain(void);
int cmd_sticky(void);
int  CTmap_default_color(int  cn);
char  FAR *GetPtr(unsigned int  mm);
extern int TUTORzero(char SHUGE *ptr,long lth);
int  execerr(char  *msgstr);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  CTpalette(int  wn,unsigned int  newPal,int  newFlag,unsigned int  defPal);
unsigned int  TUTORcopy_handle(unsigned int  mm);
int  setclip(void);
int  ResetFine(void);
long  IntToCoord(int  xx);
long  pc_ega_rescale(void);
int  sizetv(int  opc);
int  TUTORfree_handle(unsigned int  mm);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  CTanimate_color(int  cn,unsigned int  red,unsigned int  green,unsigned int  blue);
int  TUTORhsv_to_rgb(double  hue,double  saturation,double  value,double  *red,double  *green,double  *blue);
int  xlegal_color(int  colorn);
int  graph_to_fine(double  gx,double  gy,long  *cx,long  *cy);
int  relative_to_fine(double  rx,double  ry,long  *cx,long  *cy);
int  CTset_window_color(int  cn);
int  fputvar(unsigned char SHUGE *vaddr,int  vkind,double  fvalue);
int  iputvar(unsigned char SHUGE *vaddr,int  vkind,long  ivalue);
int  TUTORrgb_to_hsv(double  red,double  green,double  blue,double  *hue,double  *saturation,double  *value);
int  CTinq_rgb_system(int  cn,double  *red,double  *green,double  *blue);
int  CTmap_color(int  wn,int  cn,int  foreFlag);
extern int TUTORsize_exec_window(int xx,int yy);
struct  tutorview FAR *findview(int  ww,int  xx,int  yy);
int  TUTORinq_wmg_busy(int  window);
int  TUTORpoll_events(int  block);
int  setkey(int  cc);
int  set_exec_pt(unsigned int  uloc);
long  get_exec_pt(void);
int  TUTORpost_event(struct  tutorevent *event);
long  TUTORinq_msec_clock(void);
int  enable(int  bits);
int  flush(void);
int  LockExec(void);
int  TUTORget_font2(long fam,int  size,unsigned int  face,int cid);
int  UnlockExec(void);
long TUTORparse_font_family(struct  _fref *fontTag,struct  _fref *familyName,int  isFont,int  oneTag,int  *fontSize);
int  marker_file_name(struct  markvar FAR *mx,struct  _fref FAR *fullRef,int  symbolic);
int  TUTORset_fill(int  fInd,int  fChar);
long  ResetTextSize(int  force,int  showmessage);
extern int xpfont(int type);
int  TUTORcvt_font_size(long  ffid,int  crsize,int  *realSize);
int  settouchkey(struct  tutorevent FAR *event);
int  TUTORget_zfont(char  *famS,int  size);
int  executeit(char  *ss);
int  marker_to_string(struct  markvar FAR *mx,char  *s,int  limit);
int  TUTORbeep(int  *ff,int  *dur,int  *volume,int  nbeep);
int  TUTORset_cursor(int  cInd,int  cChar);
#endif /* ctproto */

#ifdef macproto
extern int sprintf(char *ss, char *form, ...);
extern int printf(char *form, ...);
extern long Mac_Zncolors(void);
#endif

#ifdef IBMPC
extern Coord pc_ega_rescale(void);
#endif


extern struct  tutorview FAR *findview();
double ReadArr();
extern long TUTORget_len_doc();
extern long l_bin();
extern long l_read();
extern double f_bin();
extern double f_read();
extern long array_addr();
extern  double lcfsysv();
extern  long lcmsysa();
extern  long lcbitcnt();
extern double CoordToFloat();
extern long pass_addr();
extern long get_exec_pt();
extern  int TimedPauseStub();
extern double evalduser();
extern Memh darrowv(); /* handle on arrow text */
extern Memh dtextv();   /* handle on displayed text */
extern  Coord IntToCoord();
extern  Coord FloatToCoord();
extern  Coord DivCoord();
extern  long TUTORwrite();
extern char FAR *GetPtr();
extern  long TUTORread();
extern long lcftoi();
extern Memh TUTORcopy_handle();
extern long TUTORinq_msec_clock();
extern long  ResetTextSize();

/* ******************************************************************* */

extern int execrun; /* executor run/return flag */
extern int MillionsColor,ReadOnlyColor;

#ifndef long_align
#define long_read(addr) (*(long SHUGE *)(addr))
#define flt_read(addr) (*(double SHUGE *)(addr))
#else
#define long_read(addr) (l_read(addr))
#define flt_read(addr) (f_read(addr))
#endif

/* ------------------------------------------------------------------- */

cmd_fine() /* -fine- command execution */

{   register int nn;

    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* pop stack */

    exS.FineDone = TRUE;
    exS.RegionXmin = coordZero;
    exS.RegionYmin = coordZero;
    if (nn == 2) { /* fine x,y */
        exS.FineW = istack[0];
        exS.FineH = istack[1]; 
    } else { /* fine x1,y1; x2,y2 */
        exS.RegionXmin = istack[0];
        exS.RegionYmin = istack[1];
        exS.FineW = istack[2]-exS.RegionXmin+coordOne;
        exS.FineH = istack[3]-exS.RegionYmin+coordOne;
    }
    exS.MarginEndX = exS.RegionXmax = exS.RegionXmin+exS.FineW-coordOne;
    exS.MarginEndY = exS.RegionYmax = exS.RegionYmin+exS.FineH-coordOne;
    exS.ClipX = exS.RegionXmin;
    exS.ClipY = exS.RegionYmin;
    exS.ClipX2 = exS.RegionXmax;
    exS.ClipY2 = exS.RegionYmax;
    ResetFine();
    /* keep copy of current font for later blank tag -font- commands */
    exS.rescaleFont = exS.baseFont; 
    /* also keep copy of CharHeight */
    exS.rescaleCharHeight = exS.CharHeight; 
    setclip();

} /* cmd_fine */

/* ------------------------------------------------------------------- */

cmd_rescale() /* -rescale- command execution */

{   register int nn;

    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* pop stack */

    exS.RescaleX = (istack[0] < 0) ? TRUE : FALSE;
    exS.RescaleY = (istack[1] <0 ) ? TRUE : FALSE;
    exS.RoundCircles = (istack[2] < 0) ? TRUE : FALSE;
    exS.RescaleT = (istack[3] < 0) ? TRUE : FALSE;
    exS.ConstrainScale = TRUE;
    if (nn > 4)
            exS.ConstrainScale = (istack[4] < 0) ? TRUE : FALSE;
#ifdef DOSPC
    if (exS.RoundCircles)
        exS.yfudge = pc_ega_rescale();
    else exS.yfudge = IntToCoord(1);
#endif
    ResetFine();
    /* keep copy of current font for later blank tag -font- commands */
    exS.rescaleFont = exS.baseFont; 
    /* also keep copy of CharHeight */
    exS.rescaleCharHeight = exS.CharHeight; 
    setclip();

} /* cmd_rescale */

/* ------------------------------------------------------------------- */

cmd_coarse() /* -coarse- command execution */

{
    iresP = istack; /* pop stack */
    exS.CoarseW = istack[0];
    exS.CoarseH = istack[1];

} /* cmd_coarse */

/* ------------------------------------------------------------------- */

static short nPaletteRead, nPaletteWanted;
static Memh newPalette;

cmd_palette() { xpalette(FALSE); }
cmd_newpal() {xpalette(TRUE); }

xpalette(newflag)
int newflag;
    {
    int nInt, restoring;
    struct CTcolorentry FAR *cep; /* pointer in new palette */
    struct CTcolorentry FAR *newp; /* pointer to new palette */
	struct CTcolorentry FAR *defp; /* pointer to default palette */
    int ii;
    int slot;   /* the slot we are setting */
    int error;
    long tempL;
    Memh defPal;
    short arrayForm;    /* TRUE if this command is done with arrays */
    double red, green, blue;
    short ffall, bfall, reserve;
    int continued;  /* TRUE if we are working on a continued palette */
    int TrueColor; /* TRUE if TrueColor (non-pallete) display */
    int nCopy; /* number colors to copy from previous palette */
  
    if (ReadOnlyColor) {
		iresP = istack; /* void stack */
		fresP = fstack;
		exS.zreturn = 0;
		return(0);
    }
    
	execrun = FALSE; /* return from executor after command */
	waitflag = atgetkey;
	paletteRef++; /* identify this palette */
	
    nInt = iresP - istack; /* # of integer arguments */
    if (nInt == 0) { /* blank tag -newpal- */
        defPal = exS.oldcolor ? TUTORcopy_handle(oldDefaultPalette) : HNULL;
        if (!defPal)
        	exS.zreturn = 0;
        exS.zreturn = CTpalette(ExecWn,defPal,2,HNULL);
        return(0);
    }

    exS.didPalette++; /* remember we changed palette */     
    if (newflag) newflag = 2; /* 2 = new executor palette */
    arrayForm = istack[1];
    
    /* are we restoring? (just slot argument), or setting slots? */
    if (arrayForm)
        restoring = (nInt < 7); /* we have only the first array */
    else
        restoring = (fresP == fstack); /* there are no rgb args */
    
    /* clear stack */
    iresP = istack;
    fresP = fstack;
    
    TrueColor = MillionsColor;
  /*  if (Mac_Zncolors() >= 0x1000000L)
        TrueColor = TRUE; */ /* TrueColor machine */

    error = 0; /* no error */
    
    if (istack[0] != 0)
        { /* we are starting a sequence of palette commands */
        continued = FALSE;
        nPaletteRead = 0;
        if (arrayForm)
            { /* the # of slots wanted is minimum length of arrays */
            nPaletteWanted = istack[5]; /* # of items in first array */
            ii = 9; /* # of items in second array */
            while (ii < nInt)
                { /* look thru all the arrays present */
                if (istack[ii] < nPaletteWanted) 
                    nPaletteWanted = istack[ii];
                ii += 4; /* look at info for next array */
                }
            if (nPaletteWanted <= 0)
                ex_arrayerr();
            }
        else /* simple case, the # of palette slots is in istack[0] */
            nPaletteWanted = istack[0]; /* # of entries that are following */
        
        tempL = sizeof(struct CTcolorentry) * 256L;
        newPalette = TUTORalloc_palette(256);
        if (!newPalette)
            execerr("Out of memory on -palette-.");
        cep = newp = (struct CTcolorentry FAR *) GetPtr(newPalette);
        }
    else
        { /* we are continuing with previous palette commands */
        if (!newPalette) { /* previous -palette- command failed */
        	exS.zreturn = 0;
        	return(0);
        }
        cep = newp = (struct CTcolorentry FAR *) GetPtr(newPalette);
        continued = TRUE;
        }
    
    if (arrayForm)
        { /* handle array */
        for (ii=0; ii<nPaletteWanted && !error; ii++)
            { /* for every array entry */
            slot = ReadArr(arrayForm,2,ii);
            if (slot == color_defaultf || slot == color_defaultb)
                slot = CTmap_default_color(slot);
            if ((slot >= 0) && (slot <= 255)) {
             
 	           if (!restoring)
 	               {
					red = ReadArr(arrayForm,6,ii);
					green = ReadArr(arrayForm,10,ii);
					blue = ReadArr(arrayForm,14,ii);
    	            ffall = (nInt > 18) ? ReadArr(arrayForm,18,ii) : color_black;
					bfall = (nInt > 22) ? ReadArr(arrayForm,22,ii) : ffall;
					reserve = (nInt > 26) ? (ReadArr(arrayForm,26,ii) == -1) : FALSE;
					if (reserve && TrueColor) {
						ReleasePtr(newPalette);
						KillPtr(cep);
						KillPtr(newp);
						TUTORfree_palette(newPalette);
						newPalette = HNULL;
						exS.zreturn = 0; /* can't reserve color */
						return(0);
					}
  					error = SetSlot(cep,slot,red,green,blue,ffall,bfall,reserve);
                }
            else /* restoring */
                if (!error)
                    (cep+slot)->isSet = -1;
            }/* slot */
        } 
        }
    else /* non-array form */
        {
        /* read the new entry */
        slot = istack[2];
        if (slot == color_defaultf || slot == color_defaultb)
            slot = CTmap_default_color(slot);
        if (slot < 0 || slot > 255)
            {
            error = 1; /* bad slot number */
            /* set variables so we proceed to error processing */
            restoring = TRUE;
            }
        
        if (!restoring)
            {
            ii = 3; /* index to ffall on stack */
            reserve = (nInt > ii+2) ? (istack[ii+2] == -1) : FALSE;
            ffall = (nInt > ii) ? istack[ii] : color_black;
            bfall = (nInt > ii+1) ? istack[ii+1] : ffall;
            red = fstack[0];
            green = fstack[1];
            blue = fstack[2];
            if (reserve && TrueColor) {
                ReleasePtr(newPalette);
                TUTORfree_palette(newPalette);
                newPalette = HNULL;
                exS.zreturn = 0; /* can't reserve color */
                return(0);
            }
            error = SetSlot(cep,slot,red,green,blue,ffall,bfall,reserve);
            }
        else /* restoring */
            if (!error)
                (cep+slot)->isSet = -1; /* so that CTpalette will restore */
        }
   

	/* add our eight basic colors, if possible */
	
	defPal = exS.oldcolor ? oldDefaultPalette : defaultPalette;
	if (newflag) {
		nCopy = 8; /* copy only the 8 basic colors */
	} else {
		if (windowsP[CurrentWindow].paletteH) 
			defPal = windowsP[CurrentWindow].paletteH;
		nCopy = TUTORget_hsize(defPal)/sizeof(struct CTcolorentry);
	}
	defp = (struct CTcolorentry FAR *) GetPtr(defPal);
	for(ii=0; ii<nCopy; ii++) {
		if ((newp+ii)->isSet == 0) {
			TUTORblock_move((char FAR *)(defp+ii),(char FAR *)(newp+ii),
			                (long)sizeof(struct CTcolorentry));
		} else if (((newp+ii)->red == (defp+ii)->red) &&
		           ((newp+ii)->green == (defp+ii)->green) &&
		           ((newp+ii)->blue == (defp+ii)->blue) &&
		           (!(newp+ii)->reserved) && (!(defp+ii)->reserved)) {
			(newp+ii)->realV = (defp+ii)->realV; /* try to get same slot */
		}
	}
	ReleasePtr(defPal);
	KillPtr(defp);
    ReleasePtr(newPalette);
    KillPtr(cep);
    KillPtr(newp);
    
    if (error)
        { /* we had some error */
        TUTORfree_palette(newPalette);
        newPalette = HNULL;
        if (error == 1)
            execerr("Bad color slot number.");
        else if (error == 2)
            execerr("Invalid color fall-back index.");
        }
    
    nPaletteRead++;
    if (nPaletteRead >= nPaletteWanted || arrayForm)
        { /* we've got the whole palette */
         /* attach newPalette to window */
        exS.zreturn = CTpalette(ExecWn,newPalette,newflag, defPal);      
        /* clean up */
        newPalette = HNULL;
        }
    
    return(0);
    }


static double ReadArr(form,stacki, ind) /* read array value with array store info on stack */
int form; /* 1 = normal array, 2 = dynamic array */
int stacki; /* index on integer stack where array's storability info starts */
int ind;    /* index in array we want to read (0 based) */
    {
    char SHUGE *addr;
    double retv;
    int size;
    long SHUGE *llp;
    
    addr = (char SHUGE *)istack[stacki+2]; /* address of array contents */
    if (form == 1)
        addr += ARRAYHDR; /* bias past array header */
    else {
        llp = ((long SHUGE *)addr)+1;
        addr = (char SHUGE *)*llp; /* address of actual array */
    }
    size = sizetv(istack[stacki+1]);
    addr += size*ind; /* offset to correct item */
    switch(size)
        {
    case 1: /* byte */
        retv = *(unsigned char SHUGE *)addr; break;
    case 4: /* int */
        retv = long_read(addr); break;
    default: /* floating */
        retv = *(double SHUGE *) addr; break;
        }
    
    return(retv);
    }

static SetSlot(cep,slot,red,green,blue,ffall,bfall,reserve)
register struct CTcolorentry FAR *cep;
int slot;   /* which slot we are setting */
double red, green, blue; /* rgb from 0 to 100 % */
int ffall, bfall;   /* fallbacks for this slot */
int reserve;    /* TRUE if we want this slot reserved for color animation */
/* returns 0 for ok, 2 if there is an error with fallbacks */
    {
    int error;
    double hue,saturation,value;
    
    cep += slot; /* refer to correct slot */
    
    error = 0;
    cep->isSet = 1;
    cep->foreFall = ffall;
    cep->backFall = bfall;
    cep->reserved = reserve;
    cep->red = (((double) 0xffff) * red)/100.0;
    cep->green = (((double) 0xffff) * green)/100.0;
    cep->blue = (((double) 0xffff) * blue)/100.0;	
    TUTORrgb_to_hsv(red,green,blue,&hue,&saturation,&value);
    cep->cHue = hue*4.0;
   	cep->cSaturation = saturation*4.0;
    cep->cValue = value*4.0;
    cep->realV = -1;
    
    /* check fallbacks */
    if (ffall < -2 || ffall > slot ||
            (ffall == slot && slot > 1))
        error = 2;
    if (bfall < -2 || bfall > slot ||
            (bfall == slot && slot > 1))
        error = 2;
    
    return(error);
    }

/* ------------------------------------------------------------------- */

cmd_fpalette()

{   FileRef fRef; /* palette file */
    int pRet; /* return value */
    Memh palH; /* handle on palette */
    struct CTcolorentry FAR *palP; /* pointer in palette */

    iresP = istack; /* pop stacks */
    fresP = fstack;
    markP = markstack;
	
    exS.zretinf = 0; /* pre-set zretinf = no colors installed */
  	if (ReadOnlyColor) {
		exS.zreturn = FILENOTSUP;
		return(0);
    }  
      
    paletteRef++; /* identify this palette */
    exS.didPalette++;

    marker_file_name(markP,(FileRef FAR *) &fRef,TRUE);

    pRet = TUTORload_palette((FileRef FAR *)&fRef);
    if (pRet > 0) {
		exS.zreturn = -1;
		exS.zretinf = pRet;
    } else
		exS.zreturn = -pRet;
    execrun = FALSE; /* return from executor after command */
    waitflag = atgetkey;
	       
    return(0);
	
} /* cmd_fpalette */

/* ------------------------------------------------------------------- */

cmd_webpal() /* -webpal- command execution */

{	Memh webbinH; /* handle on Web palette data */
	int binSize; /* size of web palette binary data */
    Memh palH; /* handle on new palette */
    struct CTcolorentry FAR *palP; /* pointer in new palette */
    char FAR *buffP; /* buffer for palette file contents */ 
    char FAR *tP; /* pointer in buffer */
    int retV; /* return value */
    int nColors; /* number colors in palette */
    int pii,pjj; /* indexes in palette */
    unsigned int rr,gg,bb; /* color components */  

    iresP = istack; /* pop stacks */
    fresP = fstack;
    markP = markstack;
	
	exS.zreturn = -1; /* pre-set zreturn = all ok */
    exS.zretinf = 0;  /* pre-set zretinf = no colors installed */
  	if (ReadOnlyColor) {
		exS.zreturn = FILENOTSUP;
		return(0);
    }  
      
    paletteRef++; /* identify this palette */
    exS.didPalette++;

	/* get palette data from resource */

	webbinH = LoadTable("webpal.bin",&binSize);
	if (!webbinH) {
		exS.zreturn = FILEMISSING;
		return(0);
	}

	/* trim unused colors from end of palette */

	buffP = GetPtr(webbinH);     
	nColors = binSize/3; /* number of palette entries */
	if (nColors > 256) nColors = 256; 
	for(pii=nColors-1; pii>1; pii--) { /* white, black are first two */
		tP = buffP+(pii*3);
		if ((*tP == 0) && (*(tP+1) == 0) && (*(tP+2) == 0)) {
			nColors--; /* not a real entry */
		}
	} /* for */

    /* allocate new palette */
	
    palH = TUTORalloc_palette(256); /* set up new palette */
    if (!palH) {
		exS.zreturn = FILEMEM;
		return(0);
    }

	/* build palette from raw data in resource */

    palP = (struct CTcolorentry FAR *)GetPtr(palH);
	tP = buffP;
	for(pii=0; pii<nColors; pii++) {
		rr = (*tP++ & 0xff) << 8;
		gg = (*tP++ & 0xff) << 8;
		bb = (*tP++ & 0xff) << 8;    
		if (rr == 0xff00) rr = 0xffff;
	    if (gg == 0xff00) gg = 0xffff;
	    if (bb == 0xff00) bb = 0xffff;
		CTset_color_entry(palP+pii,rr,gg,bb,0,0,FALSE);
	    (palP+pii)->realV = pii;
	} /* for */
	ReleasePtr(webbinH);
    ReleasePtr(palH);

	TUTORfree_handle(webbinH); /* release raw data */

    /* install the palette */

    immediatePalette(palH);
	exS.zretinf = nColors;
   
	return(0);

} /* cmd_webpal */

/* ------------------------------------------------------------------- */

cmd_rgb() { hsvrgb(0); } /* -rgb- command execution */
cmd_hsv() { hsvrgb(1); } /* -hsv- command execution */

hsvrgb(type) /* rgb and hsv command executions */
int type; /* 0 = rgb command, 1 = hsv command */
    {
    register int ni,nf;
    int slotn; /* palette slot number */
    int fall[2]; /* fall-back slot numbers */
    double cv[3]; /* rgb or hsv value */
    register int ii; /* index in color value */
    Memh palette;
    REGISTER struct CTcolorentry FAR *cep;
    unsigned int red, green, blue;

    ni = iresP-istack; /* number items on integer stack */
    nf = fresP-fstack; /* number items on floating stack */
    iresP = istack; /* pop integer stack */
    fresP = fstack; /* pop floating stack */

    exS.zreturn = -1; /* pre-set zreturn = all ok */
    palette = windowsP[ExecWn].paletteH;

    if (ni < 1)
        { /* blank tag -rgb-, restore all animating slots to their original values */
        if (palette)
            {
            cep = (struct CTcolorentry FAR *) GetPtr(palette);
            for (ii=0; ii<CurrentPaletteSize; ii++, cep++)
                if (cep->reserved)
                    CTanimate_color(ii,cep->red,cep->green,cep->blue);
            
            ReleasePtr(palette);
            KillPtr(cep);
            }
        /* else don't do anything, because default palette doesn't animate */
        return;
        }
    
    /* we are dealing with only 1 slot */
    
    /* get the color slot */
    slotn = istack[0]; 
    if (slotn == color_defaultf || slotn == color_defaultb)
        slotn = CTmap_default_color(slotn);
    xlegal_color(slotn);

    if (palette)
        {
        cep = (struct CTcolorentry FAR *) GetPtr(palette);
    
        if (slotn >= CurrentPaletteSize || !cep[slotn].reserved)
            { /* can't change this color */
            exS.zreturn = 0;
            ReleasePtr(palette);
            KillPtr(cep);
            return(0);
            }
        }
    else
        { /* default palette, can't animate, can't change fallback */
        exS.zreturn = 0;
        return(0);
        }
    
    /* at this point we have cep, and slotn refers to a changeable palette slot */
    
    if (ni == 1 && nf == 0)
        { /* 1 tag = restore single palette slot to the original values */
        cep += slotn; /* refer to correct cT slot */
        CTanimate_color(slotn,cep->red,cep->green,cep->blue);
        ReleasePtr(palette);
        KillPtr(cep);
        return(0);
        }

    if (ni >= 2)
        fall[0] = istack[1];
    else
        {
        fall[0] = color_defaultf;
        fall[1] = color_defaultb;
        }
    fall[1] = fall[0];
    if (ni == 3)
        fall[1] = istack[2];
    
    for (ii=0; ii<2; ii++)
        if (fall[ii] < -2 || fall[ii] > slotn ||
                (fall[ii] == slotn && slotn > 1))
            execerr("Invalid color fall-back index.");

    cep[slotn].foreFall = fall[0];
    cep[slotn].backFall = fall[1];
    ReleasePtr(palette);
    KillPtr(cep);

    cv[0] = fstack[0]; /* pick up rgb or hsv value */
    cv[1] = fstack[1];
    cv[2] = fstack[2];

    /* setting red-green-blue or hue-saturation-value palette */
    /* check and restrict values to 0-100, except for hue */

    for (ii = (type == 1) ? 1 : 0; ii<3; ii++)
        {
        if (cv[ii] < 0.0)
            cv[ii] = 0.0;
        else if (cv[ii] > 100.0)
            cv[ii] = 100.0;
        }

    if (type == 1)
        TUTORhsv_to_rgb(cv[0],cv[1],cv[2],&cv[0],&cv[1],&cv[2]);

    red = ((double) 0xffff) * cv[0]/100.0;
    green = ((double) 0xffff) * cv[1]/100.0;
    blue = ((double) 0xffff) * cv[2]/100.0;
    CTanimate_color(slotn,red,green,blue);

    return(0);
    }           /* hsvrgb */

/* ------------------------------------------------------------------- */

cmd_getrgb() { xgetrgb(0); } /* -getrgb- command execution */
cmd_gethsv() { xgetrgb(1); } /* -gethsv- command execution */
xgetrgb(type) /* getrgb and gethsv commands */
int type; /* = 0 = getrgb */
          /*   1 = gethsv */

{   int si; /* index in arguments stack */
    int pslotn; /* pallete slot number */
    int slotn; /* actual slot number */
    double rgb[3];
    int ii;
    int ni,nf;
    Memh palette;
    struct CTcolorentry FAR *cep;
    int slotbased;  /* TRUE if slot-based getrgb command */

    iresP = istack; /* pop stack */
    fresP = fstack;

    slotbased = istack[0];
    
    if (slotbased)
        {
        pslotn = istack[1];
        if (pslotn == color_defaultf || pslotn == color_defaultb)
            pslotn = CTmap_default_color(pslotn);
        xlegal_color(pslotn); /* check legal range */
        slotn = CTmap_color(ExecWn,pslotn,TRUE);
        
        palette = windowsP[ExecWn].paletteH;
        if (!palette)
            palette = defaultPalette;
        cep = (struct CTcolorentry FAR *) GetPtr(palette);
        cep += slotn;
        
        ii = FALSE;
        if (cep->reserved)
            { /* animating color, may have changed.  We need to ask system */
            ii = CTinq_rgb_system(slotn,&rgb[0],&rgb[1],&rgb[2]);
            /* if ii is false, it indicates system doesn't know about color.  In
                which case it hasn't been animated & we can use cT's palette */
            }
        
        if (!ii)
            { /* use cT's palette to determine the color */
            rgb[0] = (double) cep->red * 100.0 / (double) 0xffff;
            rgb[1] = (double) cep->green * 100.0 / (double) 0xffff;
            rgb[2] = (double) cep->blue * 100.0 / (double) 0xffff;
            }
        ReleasePtr(palette);
        KillPtr(cep);
        }
    else
        { /* non slot-based */
        rgb[0] = fstack[0];
        	if (rgb[0] < 0.0) rgb[0] = 0.0;
        if (type == 1) {  /* gethsv */
        	if (rgb[0] > 100.0) rgb[0] = 100.0;
        } else { 
            if (rgb[0] > 360.0) rgb[0] = 360.0;
        }
        rgb[1] = fstack[1];
        if (rgb[1] < 0.0) rgb[1] = 0.0;
        else if (rgb[1] > 100.0) rgb[1] = 100.0;
        rgb[2] = fstack[2];
        if (rgb[2] < 0.0) rgb[2] = 0.0;
        else if (rgb[2] > 100.0) rgb[2] = 100.0;
        }
    
    if (type == 1) /* gethsv */
        TUTORrgb_to_hsv(rgb[0],rgb[1],rgb[2],
            &rgb[0],&rgb[1],&rgb[2]);
    else if (type == 0 && !slotbased)
        TUTORhsv_to_rgb(rgb[0],rgb[1],rgb[2],
            &rgb[0],&rgb[1],&rgb[2]);

    /* store integer slot and floating r,g,b */

    if (slotbased)
        { /* store integer slot */
        iputvar((unsigned char SHUGE *)istack[4],(int)istack[3],(long)slotn);
        si = 6; /* index of 2nd storinf package */
        }
    else /* not slot based */
        {
        si = 1; /* index of storinf package for "red" */
        }
    
    for(ii=0; ii<3; ii++) { /* store r,g,b */
        fputvar((unsigned char SHUGE *)istack[si+2],(int)istack[si+1],rgb[ii]);
        si += 4; /* advance to next storinf data */
    } /* for */

} /* xgetrgb */

/* ------------------------------------------------------------------- */

cmd_wcolor() /* -wcolor- command execution */

{   double red,green,blue;
    double hue,sat,val;
    
    struct CTcolorentry FAR *palP;
    
    iresP = istack; /* void stacks */
    fresP = fstack;
    
    if (istack[0] == 1) { /* palette form */
        xlegal_color((int)istack[1]); /* check legal */
        CTset_window_color((int)istack[1]);
        return(0);
    }
    if (istack[0] == 2) { /* rgb form */
        red = fstack[0];
        green = fstack[1];
        blue = fstack[2];
    } else { /* hsv form */
        hue = fstack[0];
        sat = fstack[1];
        val = fstack[2];
        TUTORhsv_to_rgb(hue,sat,val,&red,&green,&blue);
    }
    TUTORset_color_rgb(2,0,red,green,blue); /* set window color */
    return(0);

} /* cmd_wcolor */

/* ------------------------------------------------------------------- */

int cmd_wtitle() /* -wtitle- command execution */

{   char wTitle[82];
	long len;

	markP = markstack; /* void stack */
	len = markP->len;
	if (len > 80) len = 80;
	TUTORget_string_doc(markP->doc,markP->pos,len,(unsigned char FAR *)&wTitle[0]);
	TUTORset_window_title(ExecWn,wTitle);
	return(0);
	
} /* cmd_wtitle */

/* ------------------------------------------------------------------- */

cmd_clip()  { argclip(0); } /* -clip-  command execution */
cmd_rclip() { argclip(1); } /* -rclip- command execution */
cmd_gclip() { argclip(2); } /* -gclip- command execution */

argclip(type) /* clip, rclip, gclip command executions */
int type; /* 0 = clip, 1 = rclip, 2 = gclip */

{   int nn;
    register Coord x1,y1,x2,y2;
    Coord tempC1, tempC2;

    nn = (type == 0) ? (iresP-istack) : (fresP - fstack); /* number items on stack */
    iresP = istack; /* pop stacks */
    fresP = fstack;

    if (nn == 0) {

        /* set to unclip if blank tag form */

        x1 = exS.RegionXmin;
        y1 = exS.RegionYmin;
        x2 = exS.RegionXmax;
        y2 = exS.RegionYmax; 
    } else {

        /* obtain clip region */

        if (type == 0) {
            x1 = istack[0];
            y1 = istack[1];
            x2 = istack[2];
            y2 = istack[3];
        } else if (type == 1) {
            relative_to_fine(fstack[0],fstack[1],&tempC1,&tempC2);
            x1 = tempC1;
            y1 = tempC2;
            relative_to_fine(fstack[2],fstack[3],&tempC1,&tempC2);
            x2 = tempC1;
            y2 = tempC2;
        } else if (type == 2) {
            graph_to_fine(fstack[0],fstack[1],&tempC1,&tempC2);
            x1 = tempC1;
            y1 = tempC2;
            graph_to_fine(fstack[2],fstack[3],&tempC1,&tempC2);
            x2 = tempC1;
            y2 = tempC2;
        } /* else */
    } /* nn else */

    /* normalize clip region */

    if (x1 < x2) { /* get x1,y1 < x2,y2 */
        exS.ClipX = x1;
        exS.ClipX2 = x2; 
    } else {
        exS.ClipX = x2;
        exS.ClipX2 = x1; 
    } /* x1 < x2 else */
    if (y1 < y2) {
        exS.ClipY = y1;
        exS.ClipY2 = y2; 
    } else {
        exS.ClipY = y2;
        exS.ClipY2 = y1; 
    } /* y1 < y2 else */

    /* apply clip region */

    setclip();
    exS.outcnt += 2; 
    OUTGO;
 
} /* argclip */

/* ------------------------------------------------------------------- */

cmd_enable() /* -enable- command execution */

{
    exS.enablebits = *(--iresP);
    enable(exS.enablebits);

} /* cmd_enable */

/* ------------------------------------------------------------------- */

cmd_disable() /* -disable- command execution */

{   register int bits;

    bits = *(--iresP);
    exS.enablebits = exS.enablebits & ~bits;
    enable(exS.enablebits);

} /* cmd_disable */

/* ------------------------------------------------------------------- */

cmd_press() /* -press- command */

{   int nn;
    register int key,tx,ty;
    struct tutorevent event;

    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* pop stack */
    
    /* interrupt if event queue nearly full */
    
    if (nevents >= EVENTLIMIT-4) {
        set_exec_pt(exS.markpt); /* back up to -markpt- cmd */
        execrun = FALSE; /* return from executor */
        waitflag = atinterrupt;
        TUTORpoll_events(TRUE); /* blocking poll */
        return(0);
    } /* nevents if */
        
    key = istack[0];
    if (nn == 1) {
        if (key >= KTOUCH)
            execerr("1-argument -press- must not have touch key.");
        else if (key >= 512)
            execerr("-press- keyset value must be less than 512.");
        else if ((key >= 128) && (key < 0xa0))
            execerr("-press- letter value must be less than 128.");
        else {
            event.type = (key > 255) ? EVENT_FKEY : EVENT_KEY;
            event.view = exS.baseView;
            event.window = exS.baseView->window;
            event.nkeys = 1;
            event.eDataP = FARNULL;
            if (event.type == EVENT_KEY)
                event.keys[0] = key;
            else
                event.value = key;
            event.pressed = TRUE;
            event.timestamp = 0;
            TUTORpost_event(&event);
        }
    } else {
        if (!(key >= KTOUCH && key <= KTOUCH+5))
            execerr("3-argument -press- requires touch key.");
        tx = istack[1];
        ty = istack[2];
        switch(key) {

        case KTOUCH:
            event.type = EVENT_LEFTDOWN; break;
        case KTOUCH+1:
            event.type = EVENT_LEFTUP; break;
        case KTOUCH+2:
            event.type = EVENT_DOWNMOVE;
            event.leftdown = TRUE;
            event.rightdown = FALSE;
            break;
        case KTOUCH+3:
            event.type = EVENT_RIGHTDOWN; break;
        case KTOUCH+4:
            event.type = EVENT_RIGHTUP; break;
        case KTOUCH+5:
            event.type = EVENT_DOWNMOVE;
            event.leftdown = FALSE;
            event.rightdown = TRUE;
            break;

        } /* switch */
        event.x = tx;
        event.y = ty;
        event.pressed = TRUE;
        event.view = exS.baseView;
        event.window = exS.baseView->window;
        event.timestamp = 0;
        event.eDataP = FARNULL;
        TUTORpost_event(&event);
    } /* nn else */

} /* cmd_press */

/* ------------------------------------------------------------------- */

cmd_clrkey() /* -clrkey- command execution */

{   register unsigned int loc;

    TUTORpoll_events(FALSE); /* make sure pending events are read */
    if (nevents || TUTORinq_wmg_busy(-1))
        { /* event queue not empty or window manager is busy, we need to interrupt */
        set_exec_pt(get_exec_pt()-2); /* so we restart at clrkey */
        execrun = FALSE;
        waitflag = atgetkey;
        exS.inOver = TRUE; /* step over this process */
        /* events not to executor will get processed.  Events to the executor
            will bring us back to clrkey, where they are thrown away.  We
            won't get past clrkey until there aren't any events left */
        setkey(-1);
        return;
        }
    setkey(-1);
    exS.inOver = FALSE; /* resume step */
    
} /* cmd_clrkey */

/* ------------------------------------------------------------------- */

cmd_getkey() /* -getkey- command execution */

{
    register int ii, evind, exwind;
    register struct tutorevent FAR *evp;
    int needStop;   /* TRUE if we have to stop execution */
    struct tutorview FAR *mouseV;   /* view where mouse click goes */
    int key; /* key value */
    
    setkey(-1); /* in case we don't find anything */
    needStop = FALSE;
    exS.proc_obj_unit = 0; /* allow button/slider/hot interrupt */
    exS.loopcounter++;

    /* first we look for event. If we don't find one, call poll_events and
        look again */
    
    exwind = exS.baseView->window;
    for (ii=0; ii<2; ii++)
        { /* we scan eventque for events twice */
        /* find the top real event for executor window */
        evp = eventque;
        evind = 0;
        while (evind < nevents && (evp->type == -1 || evp->window != exwind))
            {
            evind++;
            evp++;
            }
        
        if (evind >= nevents)
            {
            if (ii == 0)
                {
                TUTORpoll_events(FALSE); /* first time, ask system for events */
		if (TUTORinq_wmg_busy(ExecWn))
                    { /* window manager started something, we need to interrupt */
                    execrun = FALSE;
                    waitflag = atgetkey;
                    return(0);
                    }
                }
            else
                return(0); /* there really isn't anything */
            }
        else
            break; /* we found something */
        }

    switch(evp->type)
        {
    case EVENT_LEFTDOWN:
    case EVENT_LEFTUP:
    case EVENT_RIGHTDOWN:
    case EVENT_RIGHTUP:
    case EVENT_DOWNMOVE:
        if (evp->type == EVENT_LEFTDOWN || evp->type == EVENT_RIGHTDOWN)
            mouseV = findview(exwind,evp->x,evp->y);
        else
            mouseV = windowsP[exwind].MouseFocus;
        if (mouseV == exS.baseView ||
                mouseV == exS.arr.aView)
            { /* this is a key for the executor */
            settouchkey(evp);
            evp->type = -1; /* cancel the event, we've used it */
            }
        else
            needStop = TRUE; /* we need to stop to let this touch thru */
        break;
    case EVENT_FKEY:
        if (windowsP[exwind].KeyFocus == exS.baseView ||
                windowsP[exwind].KeyFocus == exS.arr.aView)
            { /* this is a key for the executor */
            if (evp->value == NEWLINE)
            	evp->value = KNEXT;
            setkey(evp->value);
            evp->type = -1; /* cancel the event, we've used it */
            }
        else
            needStop = TRUE;
        break;
    case EVENT_KEY:
        if (windowsP[exwind].KeyFocus == exS.baseView ||
                windowsP[exwind].KeyFocus == exS.arr.aView)
            { /* this is a key for the executor */
            key = evp->keys[0];
            if (key == NEWLINE)
            	key = KNEXT; /* newlines are really NEXTs */
            setkey(key);
            if (evp->nkeys <= 1) {
                evp->type = -1; /* cancel the event, we've used it */
            } else
                { /* just delete the one key we've used */
                evp->nkeys--;
                for (ii=0; ii<evp->nkeys; ii++)
                    evp->keys[ii] = evp->keys[ii+1];
                }
            }
        else
            needStop = TRUE;
        break;
    default:
        /* not an event that getkey wants */
        /* but there may be events following it that we want, so stop execution
            so that the interact loop can process events */
        if (nevents > 1)
            needStop = TRUE;
        break;
        }   /* end of switch */
    
    if (needStop)
        { /* stop executor */
            execrun = FALSE; /* return from executor */
            waitflag = atgetkey;
        }
    return(0);
    
} /* cmd_getkey */

/* ------------------------------------------------------------------- */  

cmd_supsub() /* -supsub- command execution */

{	double fy;
	int nf;
    
    nf = fresP-fstack;
    fresP = fstack; /* void stack */
    if (!nf) {
    	exS.SupSub = -1;
    } else {
    	fy = fstack[0];
    	exS.SupSub = lclocy(FloatToCoord(fy)+exS.RegionYmin);
    }
    TUTORset_sub_new(exS.SupSub,exS.newLine);
	return(0);
	
} /* cmd_supsub */

/* ------------------------------------------------------------------- */  

cmd_newline() /* -newline- command execution */

{   double fy;
	int nf;

	nf = fresP-fstack;
	fresP = fstack; /* void stack */
	if (!nf) {
		exS.newLine = 0;
	} else {
		fy = fstack[0];
    	exS.newLine = lclocy(FloatToCoord(fy)+exS.RegionYmin);
    }
    TUTORset_sub_new(exS.SupSub,exS.newLine);
	return(0);
	
} /* cmd_newline */

/* ------------------------------------------------------------------- */  

cmd_font()  { xpfont(0); } /* -font-  command execution */
cmd_fontp() { xpfont(1); } /* -fontp- command execution */

static xpfont(ctype) /* -font- and -fontp- commands */
int ctype; /* 0 = font, 1 = fontp */

{   int nn;
    long famid; /* font family id */
    int pixelHeight; /* font size in pixels */
    int fsize; /* font size as understood by local system */
    FileRef fRef;
    FileRef famName;
    struct tutorfont FAR *theF; /* pointer to font entry */
    FontFamily FAR *famP; /* pointer to font family entry */
    int fii; /* index in font table */
   	int fParse; /* type for parse_font */
   	
    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* void stack */
    markP = markstack;
    ExactMatchFont = TRUE; /* assume everything will work */
    exS.zreturn = -1;

	if (ctype == 0) {
	
		/* -font- command */
		
	    if (nn == 0) {
	    
	    	/* blank tag - reset to base font */

	        if (NewFontSize && exS.rescaleFont != -1) {
	            /* reset font to base font at time of last -rescale- */
	            exS.baseFont = exS.rescaleFont;
	        } else {
	            /* reset font to default font */
	            exS.baseFont = textFont0;
	        }
	        exS.CharHeight = exS.rescaleCharHeight;
	        ResetTextSize(TRUE,FALSE);
	        return(0);
	    } /* nn == 0 */
	} 
	
	/* pick up font size */
	
	fsize = exS.CharHeight = istack[0];

    /* figure out font family name */
    
    marker_file_name(markP,(FileRef FAR *)&fRef,TRUE); 

	fParse = (ctype == 1 ? 2: 1);
    famid = TUTORparse_font_family(&fRef,&famName,fParse,FALSE,NEARNULL);
    if (ctype == 0) {
    	fsize = TUTORcvt_font_size(famid,15,&pixelHeight);
    } 
    UnlockExec(); /* allow memory management of executor items */
    exS.baseFont = TUTORget_font2(famid,fsize,0,103); /* some font in this family */
    LockExec(); /* restore pointers to executor items */

    ResetTextSize(TRUE,FALSE);
    
    /* set zreturn to indicate success/failure */
        
    fii = exS.textFont;
    if (fii < 0) fii = 0;
    theF = fii+(struct tutorfont FAR *) GetPtr(fontsH);
    if (theF->badFont)
        ExactMatchFont = FALSE;
    if (!ExactMatchFont) {
        exS.zreturn = 0;
        theF->badFont = TRUE; /* remember font not correct */
    }
    
    ReleasePtr(fontsH);
    ExactMatchFont = TRUE; /* leave set harmlessly */

} /* xpfont */

/* ------------------------------------------------------------------- */

cmd_icons() /* -icons- command execution */
    
{   FileRef fRef;
    FileRef famName;
    long famid; /* font family id */
    int fsize; /* font size */

    iresP = istack; /* void stack */
    markP = markstack;
    if (exS.iconFont >= 0)
        TUTORrelease_font(exS.iconFont,(long)0,0,0,FALSE);
    marker_file_name(markP,(FileRef FAR *) &fRef,TRUE);
    famid = TUTORparse_font_family(&fRef,&famName,0,TRUE,&fsize);
    UnlockExec(); /* allow memory management of executor items */
    exS.iconFont = TUTORget_font2(famid,fsize,0,104);
    LockExec(); /* restore pointers to executor items */

} /* cmd_icons */

/* ------------------------------------------------------------------- */

cmd_pattern() /* -pattern- command execution */

{   int nn;
    register int fontn; /* font number */
    register int charn; /* character number */
    long famid; /* font family id */
    int fsize; /* font size */
    FileRef fRef;
    FileRef famName;

    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* void stack */
    markP = markstack;

    if (nn == 0) { /* no tag, set to default */
        fontn = patternFont0;
        charn = patternChar0;
    } else { /* get new font */
        marker_file_name(markP,(FileRef FAR *) &fRef,TRUE); /* evaluate file name expression */
        famid = TUTORparse_font_family(&fRef,&famName,0,TRUE,&fsize);
        UnlockExec(); /* allow memory management of executor items */
	fontn = TUTORget_font2(famid,fsize,0,105);
        LockExec(); /* restore pointers to executor items */
        charn = istack[0];
    } /* nn else */
    TUTORset_fill(fontn,charn);
    exS.patternFont = fontn;
    exS.patternChar = charn;

} /* cmd_pattern */

/* ------------------------------------------------------------------- */

cmd_cursor() /* -cursor- command execution */

{   int nn;
    register int fontn; /* font number */
    register int charn; /* character number */
    long famid; /* font family id */
    int fsize; /* font size */
    FileRef fRef;
    FileRef famName;

    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* void stack */
    markP = markstack;

    if (nn == 0) { /* no tag, set to default */
        fontn = cursorFont0;
        charn = cursorChar0;
    } else { /* get new font */
        /* evaluate file name expression */
        marker_file_name(markP,(FileRef FAR *) &fRef,TRUE); 
        famid = TUTORparse_font_family(&fRef,&famName,0,TRUE,&fsize);
        UnlockExec(); /* allow memory management of executor items */
	fontn = TUTORget_font2(famid,fsize,0,106);
        LockExec(); /* restore pointers to executor items */
        charn = istack[0];
    } /* nn else */
  
    exS.cursorFont = fontn;
    exS.cursorChar = charn;
    TUTORset_cursor(exS.cursorFont,exS.cursorChar);
    
    execrun = FALSE; /* return from executor to allow cursor update */
    waitflag = atinterrupt;
    TUTORpoll_events(FALSE);

} /* cmd_cursor */

/* ------------------------------------------------------------------- */

static int nextBeep = 0;    /* index of next beep to play */
static long beepLeft = 0;   /* if nonzero, amount of next beep still to be played */

#define MAXBEEPTIME 5000

cmd_beep() /* -beep- command execution */

{   register int nn;
    register int ii; /* index in integer stack */
    int fi; /* index in floating stack */
    register int nbeeps;
    int ff[10],dur[10],vol[10];
    long beepTime;  /* total time taken by next call to TUTORbeep */

    nn = iresP-istack;
    iresP = istack;
    fresP = fstack;
    exS.loopcounter += 50; /* crude accounting for expensive operation */

    if (nn == 0) {
        TUTORbeep(NEARNULL,NEARNULL,NEARNULL,0);
        return(0); /* done if blank tag form */
    }
    
    nbeeps = 0;
    ii = nextBeep*2;
    fi = nextBeep;
    beepTime = 0;
    
    while (ii < nn) {
        ff[nbeeps] = istack[ii++]; /* pick up next triplet */
        if (beepLeft) {
            dur[nbeeps] = beepLeft;
            beepLeft = 0;
            fi++; /* move index forward to next beep */
        }
        else
            dur[nbeeps] = fstack[fi++] * 1000;
        beepTime += dur[nbeeps];
        vol[nbeeps++] = istack[ii++];
        if (beepTime >= MAXBEEPTIME)
        { /* total beeping time more than 5 seconds */
            if (nbeeps > 1) {
                nbeeps--; /* just don't do the last beep */
                fi--; /* fix index for set of nextBeep below */
            }
            else
            { /* break a long beep into pieces */
                beepLeft = beepTime - MAXBEEPTIME;
                dur[nbeeps-1] -= beepLeft;
                fi--; /* fix index for set of nextBeep below */
            }
            TUTORbeep(ff,dur,vol,nbeeps);
            
            /* exit to interact loop */
            nextBeep = fi;
            set_exec_pt(exS.markpt);
            waitflag = atinterrupt;
            execrun = FALSE;
            return(0);
        }
        if (nbeeps >= 10) { /* filled up triplet array, do beeps */
            TUTORbeep(ff,dur,vol,nbeeps);
            nbeeps = 0; /* re-set triplet count */
       } /* nbeeps if */
    } /* while */
    
    if (nbeeps)
        TUTORbeep(ff,dur,vol,nbeeps); /* finish any remaining */

    nextBeep = 0;   /* start at beginning on next beep command */
    
} /* cmd_beep */

/* ------------------------------------------------------------------- */

cmd_execute()  /* -execute- command */

{   char execstr[1002]; /* string containing UNIX command to execute */

    iresP = istack; /* void stacks */
    markP = markstack;

    flush(); /* flush output before doing lengthy process */

    marker_to_string(markP,execstr,1000);

#ifndef ANDREW
#ifndef X11
#ifndef WINPC
    execerr( "-execute- command legal on Andrew system only.");
#endif
#endif
#endif
    executeit(execstr); /* execute UNIX command */

} /* cmd_execute */

/* ------------------------------------------------------------------- */

cmd_svers() /* special psuedo-command in ieu */

{   FileRef fRef;
    struct unitinfo FAR *up; /* pointer to unit table entry */
    unsigned char SHUGE *vaddr; /* address of variable */
    struct arg_desc FAR *argp; /* pointer to argument descriptors */
    long argtype; /* type of current argument */
    long lS; /* (long)sizeof(long) */
    unsigned char SHUGE *lstackp; /* pointer to local variables */
    long iValue; /* integer value */
    double fValue; /* floating value */
    long strSize; /* size of marker string */
    char SHUGE *argMemP; /* pointer in jumpout arguments */
    int aii; /* index in arguments */
    Memh defpH;

    iresP = istack; /* void stack */
    ctutv = istack[0]; /* set version of this binary */
    exS.ClipText = istack[1]; /* TRUE if text clipped at bottom margin */
    /* read newFontSize flag - TRUE if font size means newline.y */
    NewFontSize = istack[2];
    exS.wrapWrite = istack[3];
    exS.oldcolor = istack[4];
    exS.CharHeight = (NewFontSize ? 15 : 13);
    pcoldcolor = istack[5];
    ExecWinX = istack[6];
    ExecWinY = istack[7];
    lS = sizeof(long);
    
    if (ExecWinX && ((exS.desX != ExecWinX) || (exS.desY != ExecWinY))) {
        TUTORsize_exec_window(ExecWinX,ExecWinY); 
        exS.desX = ExecWinX;
        exS.desY = ExecWinY;
        /* after command, exit and handle redraw */
        execrun = FALSE; 
        waitflag = atinterrupt;
    }
    
#ifdef IBMPC
    if (pcoldcolor) {
        CTset_foreground_color(color_defaultf);
        CTset_background_color(color_defaultb);
        CTset_window_color(color_defaultb);
        FullScreenErase();
    }
#endif

    if (exS.oldcolor) { /* put in palette allowing color animation of all */
    	defpH = TUTORcopy_handle(oldDefaultPalette);
    	if (defpH)
        	CTpalette(ExecWn,defpH,TRUE,HNULL);
	}
	
    /* get base font */
    exS.yfudge = IntToCoord(1); /* no ega rescale yet */
    exS.baseFont = TUTORget_zfont("zserif",exS.CharHeight);
    /* and rescale properly */
    ResetFine();

    /* now set default fonts & font info to match the font calculated in ResetTextSize */
    iconFont0 = textFont0 = exS.textFont = exS.iconFont = exS.baseFont;
    exS.rescaleCharHeight = exS.CharHeight; 
    exS.rescaleFont = -1;  /* indicate no fine/rescale encountered yet */

    /* pass -jumpout- arguments if present */
    
    up = &unittab[exS.mainunit];
    if (exS.JargN && exS.JinfoH && up->nvargs) {
        if (exS.JargN != up->nvargs) 
            execerr("-jumpout- had incorrect number of arguments.");
        argp = (struct arg_desc FAR *)(descP+up->descp+up->argdesc);
        argMemP = GetPtr(exS.JinfoH);
        lstackp = exS.stackP+exS.mainlvars;
        for(aii=0; aii<exS.JargN; aii++) {
            TUTORblock_move(argMemP,(char FAR *)&argtype,lS);
            argMemP += lS;
            if (argtype != argp->ltype)
                if ((argtype == TMARK) || (argp->ltype == TMARK)) {
                    ReleasePtr(exS.JinfoH);
                    KillPtr(argMemP);
                    execerr("-jumpout- pass-by-value type mismatch.");
                }
            if (argp->global) vaddr = exS.stackP+argp->addr;
            else vaddr = lstackp+argp->addr;
            if (argtype == TFLOAT) {
                TUTORblock_move(argMemP,(char FAR *)&fValue,(long)sizeof(double));
                argMemP += sizeof(double);
                fputvar(vaddr,(int)argp->ltype,fValue);
            } else if (argtype == TMARK) {
                TUTORblock_move(argMemP,(char FAR *)&strSize,lS);
                argMemP += lS;
                mvar_init(markP); /* initialize new temp marker */
                InsertString(markP->doc,0L,argMemP,strSize);
                markP->pos = 0; /* wrap marker around string */
                markP->len = markP->doclen = strSize;       
                argMemP += strSize; 
                mvar_assign((struct markvar SHUGE *)vaddr,markP);
            } else {
                TUTORblock_move(argMemP,(char FAR *)&iValue,lS);
                argMemP += lS;
                iputvar(vaddr,(int)argp->ltype,iValue);
            }
            argp++; /* advance pointer in arguments */
        } /* for */
        ReleasePtr(exS.JinfoH);
        TUTORfree_handle(exS.JinfoH); /* release arguments memory */
        exS.JinfoH = HNULL;
        exS.JargN = 0;
    } /* JinfoH if */
    exS.outcnt += 10;
    
} /* cmd_svers */

/* ------------------------------------------------------------------- */

cmd_eraseu() /* -eraseu- command execution */
      
{
    iresP = istack; /* void stack */
    exS.arr.eraseuunit = istack[0];

} /* cmd_eraseu */

/* ------------------------------------------------------------------- */

cmd_reshape() /* -reshape- command execution */
      
{
    iresP = istack; /* void stack */
    execerr("This command isn't implemented yet.");

} /* cmd_reshape */

/* ------------------------------------------------------------------- */

cmd_finishu() /* -finishu- command execution */
      
{
    iresP = istack; /* void stack */
    exS.finishunit = istack[0];

} /* cmd_finishu */

/* ------------------------------------------------------------------- */
 
cmd_iarrow() /* -iarrow- command execution */
 
{
    iresP = istack; /* void stack */
    exS.arr.iarrowunit = istack[0];

} /* cmd_iarrow */

/* ------------------------------------------------------------------- */

cmd_ijudge() /* -ijudge- command execution */

{
    iresP = istack;
    exS.arr.ijudgeunit = istack[0];

} /* cmd_ijudge */

/* ------------------------------------------------------------------- */

cmd_imain() /* -imain- command execution */

{
    iresP = istack;
    exS.imainunit = istack[0];

} /* cmd_imain */

/* ------------------------------------------------------------------- */

cmd_sticky() /* -sticky- command execution */

{	struct markvar SHUGE *mx; /* temp marker */

    iresP = istack; /* void stack */
    markP = markstack;

    if (markP->vaddr >= 0) {
        mx = (struct markvar SHUGE *)(exS.stackP+markP->vaddr);
        if (istack[4] < 0) mx->alteredF |= 16;
        else mx->alteredF = mx->alteredF & 0xffef;
    } /* addr if */
    mvar_temp_cleanup(); /* clean up temporary docs */

} /* cmd_sticky */

/* ------------------------------------------------------------------- */
