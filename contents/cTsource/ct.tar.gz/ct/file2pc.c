
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* ******************************************************************* */

#include <stdio.h>

#include "baseenv.h"
#include "compute.h"
#include "ecglobal.h"
#include "tfiledef.h"
#include "tglobals.h"
#include "kglobals.h"

#include <bios.h>
#include <dos.h>
#ifdef TURBOC
#include <dir.h>
#include <io.h>
#endif
#include <sys\stat.h>

#ifdef ctproto
extern char FAR *pc_lp(long pp);
extern long pc_pl(char FAR *pp);
extern char FAR *pc_np(char FAR *pp);
extern int strlenf(char FAR *path);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  TUTORrename_file(struct  _fref FAR *fOld,struct  _fref FAR *fNew);
int  TUTORdelete_file(struct  _fref FAR *fRef);
int  TUTORopen_serial(int  port,int  baud,int  datab,int  parity,double  stopb);
int  TUTORopen_ems(long  FAR *size);
void  pc_close_ems(int  handle);
int  TUTORopen_xms(long  FAR *size);
void  pc_close_xms(int  handle);
char  FAR *TUTORread_dir(struct  _fref FAR *fref);
int  TUTORdispose_dir(char  FAR *path);
int  TUTORsound(struct  _fref FAR *fRef,long  soundid);
/* extern int86(); */
extern int strcmp(char *aa, char *bb);
int  setfptr(int  FAR *aptr,unsigned int  seg,unsigned int  adr);
/* extern int86x(); */
/* extern segread(); */
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  file_slot(void);
int  s_setup(short  port,unsigned int  commparams);
/* extern _dos_setdrive(); */
char  *strf2n(char  FAR *strp);
/* extern _dos_getdrive(); */
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int  TUTORdump(char  *s);
/* extern findnext() */
extern TUTORblock_move(char FAR *sp, char FAR *dp, long lth);
extern char *strcat(char *aa, char *bb);
extern int strlen(char *str);
extern char *strncpy(char *aa, char *bb, int nn);
/* extern findfirst() */
extern int TUTORzero(char FAR *ptr,long lth);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
char  FAR *strcatf(char  FAR *aa,char  FAR *bb);
extern char *strcpy(char *aa, char *bb);
/* extern pc_xms(); */
/* extern pc_xms_init(); */
extern int stat(char *path, struct stat *buffer);
int  TUTORdealloc(char  FAR *ptr);
/* extern qsort_pc() */
int  strcmpnw(char  FAR *aa,char  FAR *bb);
char  FAR *TUTORrealloc(char  FAR *ptr,long  oldsize,long  newsize,int  abort);
#ifdef IBMPROTO
int _CDECL unlink(const char *);
int _CDECL rename(const char *, const char *);
extern int sb_reset(void);
extern int sb_time(int time);
extern int sb_speaker(void);
extern int sb_output(int page,int offset,int length);
extern long TUTORinq_msec_clock(void);
#endif /* IBMPROTO */
#endif /* ctproto */

extern char FAR *pc_lp();
extern long pc_pl();
static long flrdwr();
long TUTORwrite_socket();
long TUTORread_socket();
extern char *strf2n();
extern void pc_map_ems();
extern long pc_rdwr_ems();
extern void pc_close_ems();
extern long pc_rdwr_xms();
extern void pc_close_xms();

long ems_segment;
long ems_offset;
int xms_driver = 0;
short xms_c_handle;
long xms_c_offset;

extern int pcv_sndw;

#define RMODE "rb"
#define RMODEB "rb"
#define WMODE "wb"
#define WMODEB "wb"
#define WRMODE "wb+"
#define RWMODE "rb+"
#define AMODE "ab"
#define AMODEB "ab"
#define EMS_PGSZ 0x4000

#ifdef TURBOC
#define _COM_110  0x00
#define _COM_150  0x20
#define _COM_300  0x40
#define _COM_600  0x60
#define _COM_1200 0x80
#define _COM_2400 0xa0
#define _COM_4800 0xc0
#define _COM_9600 0xe0
#define _COM_EVENPARITY 0x18
#define _COM_ODDPARITY 0x08
#define _COM_NOPARITY 0x00
#define _COM_STOP1 0x00
#define _COM_STOP2 0x04
#define _COM_CHR7 0x02
#define _COM_CHR8 0x03
#endif /* TURBOC */

/* ******************************************************************* */

int TUTORrename_file(fOld,fNew) /* rename file, return TRUE if worked */
FileRef FAR *fOld, FAR *fNew;

{   int rret;
    char tempS[FILEL+1];
    unsigned int curdrive, nDrives;

    if (fOld->drive != fNew->drive)
    TUTORdump("Attempt to change drives in TUTORrename_file");

    _dos_getdrive(&curdrive);
    _dos_setdrive((unsigned int) fOld->drive,&nDrives);
    strcpyf((char FAR *) tempS,fNew->path);
    rret = rename(strf2n(fOld->path),tempS);
    _dos_setdrive(curdrive,&nDrives); /* restore drive */
    return(rret == 0);

} /* TUTORrename_file */

/* ******************************************************************* */

int TUTORdelete_file(fRef) /* delete file, return TRUE if worked */
FileRef FAR *fRef;

{   int dret;
    unsigned int curdrive, nDrives;

    _dos_getdrive(&curdrive);
    _dos_setdrive((unsigned int) fRef->drive,&nDrives);
    dret = unlink(strf2n(fRef->path));
    _dos_setdrive(curdrive,&nDrives); /* restore drive */
    return(dret == 0);

} /* TUTORdelete_file */

/* ******************************************************************* */

/* serial port support: */

TUTORopen_serial(port,baud,datab,parity,stopb) /* open serial port */
int port; /* port number */
int baud,datab,parity;
double stopb;

{
    int params; /* initialization fields for bios request */
    struct tutorfile FAR *tfp; /* pointer to ct file table entry */
    int fi; /* index in tutor file table */
    char portn[8]; /* com port name */

    /* check input values reasonable */
    port--;
    if ((port < 0) || (port > 1) || (baud <= 0) || (baud > 9600) ||
        (parity < 0) || (parity > 2) || (stopb < 0) || (stopb > 2) ||
        (datab < 7) || (datab > 8)) {
        tfilerr = FILEMISSING; /* no such serial port exists */
        return(0);
    } /* port if */

    /* condition serial port - set appropriate bit for baud rate */

    params = 0;
    switch (baud) {
    case 110:
        params |= _COM_110;
        break;
    case 150:
        params |= _COM_150;
        break;
    case 300:
        params |= _COM_300;
        break;
    case 600:
        params |= _COM_600;
        break;
    case 1200:
        params |= _COM_1200;
        break;
    case 2400:
        params |= _COM_2400;
        break;
    case 4800:
        params |= _COM_4800;
        break;
    case 9600:
        params |= _COM_9600;
        break;
    default:
        tfilerr = FILEMISSING;
        return 0;
    }
    
    /* set bit for parity */
    switch (parity) {
    case 0:
        params |= _COM_EVENPARITY;
        break;
    case 1:
        params |= _COM_ODDPARITY;
        break;
    case 2:
        params |= _COM_NOPARITY;
        break;
    default:
        tfilerr = FILEMISSING;
        return 0;
    }

    /* set bit for number stop bits */
    if (stopb == 1.0) {
        params |= _COM_STOP1;
    }
    else
    if (stopb == 2.0) {
        params |= _COM_STOP2;
    }
    else {
        tfilerr = FILEMISSING;
        return 0;
    }
    
    /* set bit for number data bits */
    switch (datab) {
    case 7:
        params |= _COM_CHR7;
        break;
    case 8:
        params |= _COM_CHR8;
        break;
    default:
        tfilerr = FILEMISSING;
        return 0;
    }
        
    if (s_setup(port, params) == 0) {
        tfilerr = FILEMISSING;
        return 0;
    }

    /* find slot in ct file table */

    fi = file_slot(); /* locate slot in ct file table */
    tfp = fi + (struct tutorfile FAR *) GetPtr(filesopen);

    /* set up ct file table entry */
    tfp->kind = 1; /* serial port */
    tfp->vloc = -1;
    tfp->ro = FALSE;
    tfp->lastop = fop_open;
    tfp->styled = FALSE;
    tfp->inuse = TRUE;
    tfp->fp = (FILE *)1; /* value to make the file look open */
    tfp->stream = port;
    ReleasePtr(filesopen);
    tfilerr = -1; /* file opened successfully */

    return(fi);

} /* TUTORopen_serial */

/* ******************************************************************* */

int TUTORopen_ems(size) /* open file */
long FAR *size;

{   struct tutorfile FAR *tfp; /* pointer to file table entry */
    union REGS inr, outr;
    struct SREGS segr;
    char FAR *mptr;
    char FAR *segment;
    long handle;
    unsigned int pages;
    char devhdr[10];
    int ii;

    *size = 0;
    if (!useEMS)
    return(0);
    inr.h.ah = 0x35;
    inr.h.al = 0x67;
    segread(&segr);
    int86x(0x21, &inr, &outr, &segr);

    /* test for existence of driver */
    setfptr((int FAR *)&mptr,segr.es, 0);
    if ((long)mptr) {
        for (ii = 0; ii < 8; ii++) {
            devhdr[ii] = *(mptr + ii + 10);
        }
        devhdr[8] = '\0';
    } else {
        return 0;
    }
    if (strcmp(devhdr, "EMMXXXX0")) {
        return 0;
    }

    /* check for functionality */
    inr.h.ah = 0x40;
    int86(0x67, &inr, &outr);
    if (outr.h.ah) {
        return 0;
    }

    /* determine version compatibility */
    inr.h.ah = 0x46;
    int86(0x67, &inr, &outr);
    if (outr.h.ah) {
        return 0;
    }
    if (outr.h.al < 0x30) { /* 3.0 in BCD (upper 4 bits are before decimal place) */
        return 0;
    }

    /* determine segment address */
    inr.h.ah = 0x41;
    int86(0x67, &inr, &outr);
    if (outr.h.ah) {
        return 0;
    }
    ems_segment = outr.x.bx;

    /* determine available pages */
    inr.h.ah = 0x42;
    int86(0x67, &inr, &outr);
    if (outr.h.ah) {
        return 0;
    }

    /* allocate all but one page */
    inr.h.ah = 0x43;
    inr.x.bx = pages = outr.x.dx - 1;
    if (!inr.x.bx) {
        return 0;
    }
    int86(0x67, &inr, &outr);
    if (outr.h.ah) {
        return 0;
    }
    /* set up file table entry */
    tfilerr = -1; /* no error yet */
    ii = file_slot(); /* locate free file table slot */
    tfp = ii + (struct tutorfile FAR *) GetPtr(filesopen);
    tfp->inuse = TRUE; /* mark file table entry in use */
    tfp->lastop = fop_open; /* no operations yet */
    tfp->kind = 4; /* EMS "file" */
    tfp->stream = outr.x.dx;
    ReleasePtr(filesopen);
    *size = (long)(pages)*16L*1024L;
    return(ii); /* return index in file table */

} /* TUTORopen_ems */

/* ******************************************************************* */

void pc_close_ems(handle)
int handle;
{
    union REGS inr, outr;
    int ii = 0;

    /* release handle */
    inr.h.al = 0x67;
    inr.h.ah = 0x45;
    inr.x.dx = handle;

    /* Take ten tries at releasing the handle.  The EMM may be too
        busy to deal with us, but it's important that we let go of
        the EMS pages. */
    do {
        int86(0x67, &inr, &outr);
        ii++;
    } while (outr.h.ah && (ii < 10));
}

/* ******************************************************************* */

/*
TUTORopen_xms tests to see if XMS is available, allocates some,
and returns the file index of the XMS "file".  It also put the
amount allocated into *size.
*/

int TUTORopen_xms(size)
long FAR *size;

{   struct tutorfile FAR *tfp;
    union REGS regio;
    struct SREGS segr;
    int ii;
    unsigned int kblock; /* size (K) of largest xms block */

    *size = 0; /* no memory allocated yet */
    if (!useXMS)
    return(0);

    if (xms_driver == FALSE) {
        xms_driver = pc_xms_init();
        if (xms_driver == FALSE) return 0;
    }

    /* query free memory */
    segread(&segr);
    regio.h.ah = 0x08;
    pc_xms(&regio, &segr);
    kblock = regio.x.ax;
    if (kblock <= 0x20)
    return(0);

    /* allocate memory and get handle */
    regio.h.ah = 0x09;
    regio.x.dx = kblock; /* ask for largest available block */
    pc_xms(&regio, &segr);
    if (regio.x.ax == 0) {
        return 0;
    }

    /* create file table entry */
    tfilerr = -1;
    ii = file_slot();    /* get a free file table spot */
    tfp = ii + (struct tutorfile FAR*) GetPtr(filesopen);
    tfp->inuse = TRUE;
    tfp->lastop = fop_open; /* no operations yet */
    tfp->kind = 5; /* XMS "file" */
    tfp->stream = regio.x.dx;
    ReleasePtr(filesopen);

    *size = (long)(kblock)*1024L;
    return(ii);

} /* TUTORopen_xms */

/* ******************************************************************* */

/*
pc_close_xms takes an XMS handle and tells the driver
to close it.
*/
void pc_close_xms(handle)
int handle;
{
    union REGS regio;
    struct SREGS segr;

    if (xms_driver == FALSE) return;

    regio.x.ax = 0;

    regio.h.ah = 0x0a;
    regio.x.dx = handle;
    segread(&segr);
    pc_xms(&regio, &segr);

}

/* ******************************************************************* */

#ifdef TURBOC

char FAR *TUTORread_dir(fref)
FileRef FAR *fref;

{   int retf;
    int len;
    char FAR *retp; /* pointer to directory buffer */
    long retalloc; /* size of directory buffer */
    long blen; /* number characters in directory buffer */
    int nfiles; /* number file names in buffer */
    int ii;
    struct ffblk ffblk;
    char dirpath[CTPATHLEN];
    char fname[16];
    char FAR *path;
    char FAR *ccp; /* pointer in directory buffer */
    char FAR *ccq; /* pointer in directory buffer */

    path = fref->path;
    len = strlenf(path);
    if (len >= (CTPATHLEN-8))
    return(FARNULL); /* exit if path too long */
    if ((len >=2) && (path[1] == ':'))
    path += 2; /* skip over drive specifier */

    /* build path + wildcard string */

    fname[0] = fref->drive + 'a' - 1;
    fname[1] = ':';
    fname[2] = '\0';
    strcpy(dirpath,fname); /* put in drive specifier */
    if (path[0] != '\\')
    strcat(dirpath,"\\");
    strcatf((char FAR *)dirpath,path);  /* add path name */
    len = strlen(dirpath);
    if (dirpath[len-1] != '\\')
    strcat(dirpath,"\\");
    strcat(dirpath,"*.*"); /* look at all files in this directory */

    /* set up to search directory */

    retalloc = 1000; /* set initial buffer size */
    blen = 0; /* number characters in buffer */
    nfiles = 0; /* number file names in buffer */
    retp = TUTORalloc(retalloc,FALSE,"dirlst");
    if (retp == NULL)
    return(FARNULL);
    TUTORzero(retp,retalloc); /* pre-zero buffer */

    /* get next file name and add to buffer */
    /* file names are made fixed width: name, [spaces], cr */

    retf = findfirst(dirpath,&ffblk,FA_DIREC);
    while (retf >= 0) {
    strncpy(fname,ffblk.ff_name,13);
    len = strlen(fname);
    for (ii=len; ii<12; ii++)
        strcat(fname," "); /* space fill to 12 characters */
    strcat(fname,"\n");
    len = 13;
    nfiles++;
    TUTORblock_move((char FAR *)fname,(retp+blen),(long)(len+1));
    blen += len;
    retf = findnext(&ffblk); /* find next file */
    if (blen >= (retalloc-15)) {

        /* reallocate buffer if not enough space */

        retp = TUTORrealloc(retp,retalloc,retalloc+1000L,FALSE);
        if (retp == NULL)
        return(FARNULL);
        TUTORzero(retp+retalloc,1000L); /* zero new space */
        retalloc += 1000L;
    } /* blen if */
    } /* retf while */

    /* sort file names */

    qsort_pc(retp,nfiles,13,strcmpnw);

    /* convert upper case to lower case, remove spaces */

    ccp = retp;
    ccq = ccp;
    while (*ccp) {
    if ((*ccp >= 'A') && (*ccp <= 'Z'))
        *ccq++ = *ccp-'A'+'a';
    else if (*ccp != ' ')
        *ccq++ = *ccp;
    ccp++;
    } /* while */
    *ccq++ = '\0'; /* insure trailing zero */

    return(retp);

} /* TUTORread_dir */

#else

char FAR *TUTORread_dir(fref)
FileRef FAR *fref;

{
    return(FARNULL);

} /* TUTORread_dir */

#endif

/* ******************************************************************* */

TUTORdispose_dir(path)
char FAR *path;

{
    TUTORdealloc(path);

} /* TUTORdispose_dir */

/* ******************************************************************* */

#ifdef TURBOC

int TUTORinq_is_dir(fref) /* check if directory */
/* returns = -1 if error, 0 if file, 1 if directory */
FileRef FAR *fref; /* path to directory or file */

{   struct stat statb;
    int retf;
    int len;
    char path[CTPATHLEN+4];

    len = strlenf(fref->path);
    if (len > CTPATHLEN)
    return(-1);
    if ((len > 1) && (fref->path[1] == ':')) {
    strcpyf((char FAR *)path,fref->path);
    } else {
    path[0] = fref->drive+'a'-1; /* add drive specifier */
    path[1] = ':';
    path[2] = '\0';
    if (fref->path[0] != '\\') {
        strcat(path,"\\");
        len++;
    }
    strcatf((char FAR *)path,fref->path);
    len += 2;
    }
    if (len < 3)
    return(1); /* root directory */
    if ((len == 3) && (path[2] == '\\'))
    return(1); /* root directory */
    if (path[len-1] == '.')  /* current or parent directory */
    return(1);
    if (path[len-1] == '\\')
    path[len-1] = '\0';  /* remove trailing slash */
    retf = stat(path,&statb);
    if (retf < 0)
    return(-1);
    if (statb.st_mode & S_IFDIR)
    return(1);
    return(0);

} /* TUTORinq_is_dir */

#endif

/* ******************************************************************* */

int TUTORsound(fRef,soundid) /* play sound file */
FileRef FAR *fRef;
long soundid;

{   int fileid; /* index of file */
    long filesiz; /* size of sound file */
    long filepos; /* current position in sound file */
    char FAR *aP; /* pointer to original buffer allocated */
    char FAR *bufptr; /* pointer to sound buffer */
    char FAR *endptr; /* pointer to end of buffer */
    long lp; /* for pointer arithmetic */
    long bufsiz; /* size of sound buffer */
    long nread; /* number bytes read */
    int retc; /* error return code */
    int offset; /* offset past header in 1st block */
    int waitv; /* idle time for given sampling rate */
    int hdrbias; /* bias within file header */
    int timeC; /* coded sampling rate */
    int sampc; /* samples/second */
    double scale; /* scale factor for idle time */
    int sblaster; /* TRUE if should play thru SoundBlaster */
    int speaker; /* TRUE if should play thru speaker */
    int sbret; /* return from SoundBlaster functions */
    int sberr; /* SoundBlaster error flag */
    unsigned int sb_page,sb_page2;
    unsigned int sb_offset,sb_offset2;
    long itime;

    speaker = TRUE; /* pre-set to use built-in speaker */
    sblaster = FALSE;
    if (psbport) { /* sound blaster present */
        if (sb_reset() == 0) { /* if SoundBlaster responding */
            speaker = FALSE;
            sblaster = TRUE;
        }
    } 

    if (soundid) /* only one sound per file at present */
        return(FILEIMPROPERTYPE);

    fileid = TUTORopen(fRef,TRUE,FALSE,FALSE);
    if (fileid == 0)
        return(FILEMISSING);

    /* determine size of sound file */

    TUTORinq_file_info(fRef,NEARNULL,&filesiz,NEARNULL,NEARNULL,NEARNULL);
    if (filesiz <= 0) {
        TUTORclose(fileid);
        return(-1);  /* nothing to do */
    }

    /* allocate buffer for sound file read(s) */

    bufsiz = filesiz; /* set up buffer size */
    if (bufsiz > 0xfff0L)
        bufsiz = 0xfff0L;
    bufptr = aP = TUTORalloc(bufsiz,FALSE,"sound");
    if (bufptr == FARNULL) {
        bufsiz = 18000; /* try small buffer */
        bufptr = aP = TUTORalloc(bufsiz,FALSE,"sound");
    }
    if (bufptr == FARNULL) { /* no memory for buffer */
        TUTORclose(fileid);
        return(FILEQUOTA);
    }
    
    /* if SoundBlaster, adjust buffer to be entirely */
    /* within 64K page for DMA xfer to DSP */
    
    if (sblaster) {
    
        /* compute DMA page and offset of begin of buffer */
        
        sb_page = FP_SEG(bufptr);
        sb_offset = FP_OFF(bufptr);
        sb_offset += ((sb_page & 0xfff) << 4);
        sb_page = (sb_page >> 12) & 0xf;
        
        /* compute DMA page and offset of end of buffer */
        
        lp = pc_pl(bufptr);
        lp = lp+bufsiz-1; /* address of end of buffer */
        endptr = pc_lp(lp);
        endptr = pc_np(endptr);
        sb_page2 = FP_SEG(endptr);
        sb_offset2 = FP_OFF(endptr);
        sb_offset2 += ((sb_page2 & 0xfff) << 4);
        sb_page2 = (sb_page2 >> 12) & 0xf;
        
        if (sb_page != sb_page2) {
        
            /* if buffer spans page boundary, decide which */
            /* page to use */
            
            if ((0x10000L-sb_offset) >= (bufsiz/2)) {
                bufsiz = 0x10000L-sb_offset;
            } else {
                bufsiz = bufsiz-(0x10000L-sb_offset);
                sb_page = sb_page2;
                sb_offset = 0; /* begin of 2nd page */
                bufptr = MK_FP((sb_page << 12),sb_offset);
            } /* else */
            bufsiz &= (~1); /* make buffer length even */
        } /* page if */
    }

    /* read and play sound file in chunks */

    filepos = 0; /* starting position */
    retc = -1; /* pre-set no error */
    waitv = pcv_sndw; /* idle loop counter */
    timeC = 131; /* 8000 samples/second */
    while ((filepos < filesiz) && (retc < 0)) {

        /* read next chunk of file */

        if ((filesiz-filepos) < bufsiz)
            bufsiz = filesiz-filepos; /* adjust length for last read */
        nread = TUTORread(bufptr,1,bufsiz,fileid);
        if (nread != bufsiz) {
            retc = FILERANGE;
            break;
        }

        /* check if recognize *.voc header */

        offset = 0;
        sampc = -1; /* pre-set sampling rate unknown */
        if (filepos == 0) {

            /* special actions for begin of file */
            /* examine *.VOC file header */
            
            if (strncmpf(bufptr,(char FAR *)"Creative Voice File",19) == 0) {
                hdrbias = *(int FAR *)(bufptr+0x14);
                if ((hdrbias > 0) && (hdrbias < bufsiz)) {
                    if (*(bufptr+hdrbias) == 1) { /* sound data header */
                        sampc = timeC = *(bufptr+hdrbias+4);
                    }
                } /* hdrbias if */
            } /* strncmpf if */

            /* determine sampling rate */
            
            if (sampc >= 0) { /* if found sampling rate */
                sampc = sampc-256;
                sampc = -1000000.0/(double)sampc;
                scale = (double)sampc/8000.0; /* default is 8000 samples/sec */
                waitv = scale*waitv; /* adjust idle loop counter */
                offset = hdrbias+6; /* bias to sound data */
            } /* sampc if */

            /* initialize SoundBlaster hardware */
    
            if (sblaster) {
                sberr = sb_time(timeC);
                sbret = sb_speaker();
                if (sbret) sberr = TRUE;
                if (!sberr) {
                    /* magic - idle for 100 msec */
                    /* don't know why this is neccessary dma 4/24/92 */
                    itime = TUTORinq_msec_clock();
                    while ((TUTORinq_msec_clock()-itime) < 100L) ;
                } else {
                    sblaster = FALSE; /* give up on SoundBlaster */
                    speaker = TRUE; /* use speaker */
                }
            } /* sblaster */
        } /* filepos */

        /* play next chunk of file */

        if (speaker) {
            outp(97,inp(97) | 3);
            outp(67,176);
            outp(66,0);
            outp(66,0);
            outp(67,144);
            pc_digit_snd(bufptr+offset,(int)bufsiz-offset,(int)waitv);
            outp(67,182);
            outp(66,51);
            outp(66,5);
        } else if (sblaster) {
            if (filepos) {
                sb_reset(); /* crude - we didn't acknowledge interrupt */
                sb_time(timeC);
                sb_speaker();
                itime = TUTORinq_msec_clock();
                while ((TUTORinq_msec_clock()-itime) < 100L) ;
            }
            sb_offset2 = sb_offset+offset;
            sb_output((int)sb_page,(int)sb_offset2,(int)(bufsiz-offset));
        }

        filepos += nread;
    } /* while */

    /* close file, release buffer */

    pc_sound_off();
    TUTORclose(fileid);
    TUTORdealloc(aP);
    return(retc);

} /* TUTORsound */

/* ******************************************************************* */
