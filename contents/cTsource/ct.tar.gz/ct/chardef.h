
/* definitions of character data structures */

#define PLAINSTYLE 0
#define BOLDSTYLE 1
#define ITALICSTYLE 2
#define UNDERLINESTYLE 4
#define OUTLINESTYLE 8

#define CHARACTERS 0
#define GRAPHICS 1

#pragma pack(2)

struct pcccode	{ /* 16-bit encoding code translation */
    short sRangeE;      /* starting encoded value for this chunk */
    short sRangeI;      /* starting index in char defs for this chunk */
    short nRange;       /* number entries in this chunk */
}; /* pccode */

struct pcchar16 { /* 16-bit encoding character definition */
    long map;	      /* displacement to bit map for this char */
    short pdx,pdy;      /* pen x,y increment */
    short bndx,bndy;    /* displacement from pen to top,left of char bounding box */
    short mapw;	      /* width	of character bit map */
    short maph;	      /* height of character bit map */
}; /* pcchar16 */

struct pccharl { /* large-format character definition */
    unsigned short map; /* displacement to bit map for this char */
    short pdx,pdy;      /* pen x,y increment */
    short bndx,bndy;    /* displacement from pen to top,left of char bounding box */
    short bnw;	      /* width	of char bounding box */
    short bnh;	      /* height of char bounding box */
    short mapdx,mapdy;  /* displacement from top,left of bounding box */
		      /* to top,left of character bit map */
    short mapw;	      /* width	of character bit map */
    short maph;	      /* height of character bit map */
}; /* pccharl */

struct pcchars { /* small-format character definition */
    unsigned short map;	/* displacement to bit map for this char */
    char pdx,pdy;	/* pen x,y increment */
    char bndx,bndy;	/* displacement from pen to top,left of char bounding box */
    unsigned char bnw;	/* width  of char bounding box */
    unsigned char bnh;	/* height of char bounding box */
    char mapdx,mapdy;	/* displacement from top,left of bounding box */
			/* to top,left of character bit map */
    unsigned char mapw; /* width  of character bit map */
    unsigned char maph; /* height of character bit map */
}; /* pcchars */

struct pcfont { /* font definition (8-bit encoding) */
    char family[10];	     /* family name */
    char ident[4];	     /* identifier ("ct") */
    char notused[6];	     /* reserved space for future use */
    unsigned char size;      /* font size */
    unsigned char dstyle;    /* font design styles */
            /* least sig bit = bold */
                     /* next = italic */
                     /* next = underline */
                     /* next = outline */
    unsigned char astyle;   /* algorithmically generated styles */
            /* least sig bit = bold */
                     /* next = italic */
                     /* next = underline */
                     /* next = outline */
    unsigned char format;   
            /* least sig bit = char definition type */
			/* 0 = small-format 8-bit char defs */
			/* 1 = large-format 8-bit char defs */
		     /* next = font type */
			/* 0 = characters */
			/* 1 = icons */
		     /* next = encoding */
			/* 0 =	8-bit */
			/* 1 = 16-bit (always large-format chars ) */
    short newline;    /* newline height */
    short maxwidth;   /* maximum character width */
    short ascent;     /* ascent  for all characters in font */
    short descent;    /* descent for all characters in font */
    unsigned char first8;    /* 8-bit encoding first character in font */
    unsigned char nchars8;   /* 8-bit encoding number characters in font */
    unsigned short ddef;	 /* displacement to char definitions within font */
    unsigned short dmap;	 /* displacement to bit-maps within font */
    unsigned char FAR *rdef; /* pointer to char defs in memory */
    unsigned char FAR *rmap; /* pointer to bit-maps in memory */
}; /* pcfont */

struct pcfont16 { /* font definition (16-bit encoding) */
    char family[10];	     /* family name */
    char ident[4];	     /* identifier ("ct") */
    char notuseda[2];
    unsigned short first16;  /* 16 bit encoding first character */
    unsigned short last16;   /* 16 bit encoding last character */
    unsigned char size;      /* font size */
    unsigned char dstyle;    /* font design styles */
            /* least sig bit = bold */
                     /* next = italic */
                     /* next = underline */
                     /* next = outline */
    unsigned char astyle;   /* algorithmically generated styles */
            /* least sig bit = bold */
                     /* next = italic */
                     /* next = underline */
                     /* next = outline */
    unsigned char format;   
            /* least sig bit = char definition type */
			/* 0 = small-format 8-bit char defs */
			/* 1 = large-format 8-bit char defs */
		     /* next = font type */
			/* 0 = characters */
			/* 1 = icons */
		     /* next = encoding */
			/* 0 =	8-bit */
			/* 1 = 16-bit (always large-format chars ) */
    short newline;    /* newline height */
    short maxwidth;   /* maximum character width */
    short ascent;     /* ascent  for all characters in font */
    short descent;    /* descent for all characters in font */
    unsigned short ddef; /* displacement to char definitions within font */
    long dmap;		 /* displacement to bit-maps within font */
    short nencode;	 /* number entries in encoding table */
    unsigned short dencod; /* displacement to encoding table */
    char notusedc[4];	 /* reserved space for future use */
}; /* pcfont16 */


struct pcfont816 { /* font definition 8 or 16 bit (macintosh) */
    char family[10];	    /* family name */
    char ident[4];          /* identifier ("ct") */
    char notused[2];        /* reserved space for future use */
	unsigned short first16;   /* 16 bit encoding first character */
	unsigned short nchars16;  /* 16 bit encoding number characters */
    unsigned char size;     /* font size */
    unsigned char dstyle;   /* font design styles */
            /* least sig bit = bold */
                     /* next = italic */
                     /* next = underline */
                     /* next = outline */
    unsigned char astyle;   /* algorithmically generated styles */
            /* least sig bit = bold */
                     /* next = italic */
                     /* next = underline */
                     /* next = outline */
    unsigned char format;   
            /* least sig bit = char definition type */
					    /* 0 = small-format char defs */
					    /* 1 = large-format char defs */
				     /* next = font type */
					    /* 0 = characters */
					    /* 1 = icons */
					 /* next = encoding */
					    /* 0 =  8-bit */
					    /* 1 = 16-bit */
#ifdef LINUX
    short newline;    /* newline height */
    short maxwidth;   /* maximum character width */
    short ascent;     /* ascent  for all characters in font */
    short descent;    /* descent for all characters in font */
#else
    int newline;    /* newline height */
    int maxwidth;   /* maximum character width */
    int ascent;     /* ascent  for all characters in font */
    int descent;    /* descent for all characters in font */
#endif
    unsigned char first8;    /* 8-bit encoding first character in font */
    unsigned char nchars8;   /* 8-bit encoding number characters in font */
#ifdef LINUX
    unsigned short ddef;	    /* displacement to char definitions within font */
    unsigned short dmap;	    /* displacement to bit-maps within font */
#else
    unsigned int ddef;	    /* displacement to char definitions within font */
    unsigned int dmap;	    /* displacement to bit-maps within font */
#endif
    unsigned char FAR *rdef;	/* pointer to char defs in memory */
    unsigned char FAR *rmap;	/* pointer to bit-maps in memory */
}; /* pcfont816 */


#pragma pack( )
