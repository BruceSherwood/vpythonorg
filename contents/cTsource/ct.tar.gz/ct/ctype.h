/*
	Routines for LightspeedC

	(C) Copyright  1986. THINK Technologies, Inc.  All rights reserved.
*/

#ifndef _ctypeh_
#define _ctypeh_

/* NOTE: the ctype array lives in stddata_ctype.c */

extern char __ctype[];

#define _alpha_ 1
#define _digit_ 2
#define _hex_	4
#define _octal_	8
#define	_ascii_	16
#define	_cntrl_	32
#define _punct_	64
#define _space_	128

/* The c passed by the programmer should always be declared as an int or an
	unsigned char, not a char, otherwise these tests will behave
	unpredictably with values of c which are greater than 127 since chars
	are typically  sign extended to ints so array bounds become negative */


#define	isalnum(c) (__ctype[(c)+1]&(_alpha_|_digit_))

#define	isalpha(c) (__ctype[(c)+1]&_alpha_)

#define	isascii(c) (__ctype[(c)+1]&_ascii_)

#define	iscntrl(c) (__ctype[(c)+1]&_cntrl_)

#define iscsym(c)  ((__ctype[(c)+1]&(_alpha_|_digit_))|| (c) == '_')

#define iscsymf(c) ((__ctype[(c)+1]&_alpha_)|| (c) == '_')

#define isdigit(c) (__ctype[(c)+1]&_digit_)

#define isgraph(c) ((c) >= '!' && (c) <= '~')

#define	isodigit(c) (__ctype[(c)+1]&_octal_)

#define	isprint(c) (((c)>=32)&&((c)<=255))

#define	ispunct(c) (__ctype[(c)+1]&_punct_)

#define	isspace(c) (__ctype[(c)+1]&_space_)

#define	isxdigit(c) (__ctype[(c)+1]&_hex_)

#define toascii(c)	(c&0x7F)

#endif
