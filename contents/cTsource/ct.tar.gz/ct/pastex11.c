
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* #define SELECTION_PASTE */

#include <X11/Xatom.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <X11/cursorfont.h>
#include <X11/keysym.h>

#include <stdio.h>

#include "baseenv.h"
#include "txt.h"
#include "tglobals.h"
#include "chardef.h"

#ifdef WINPC
#include <windows.h>
#endif

#ifndef IBMPC

#ifdef SYSV
#define sys_typesh
#include "wmx11.h"
#else
#include <sys/wait.h>
#include <sys/time.h>
#ifdef WM
#include "wmclient.h"
#endif
#endif

#endif /* IBMPC */

#ifdef WINPC
extern HWND CurrentWinH; /* handle on current window */
extern HDC CurrentDC; /* current window's device context */
#endif

#ifdef ctproto
extern long TUTORload_region(FileRef FAR *fr);
extern int strlenf(char FAR *cc);
int  TUTORfread_graphic_doc(unsigned int  doc,int  type,int  find);
extern unsigned int  MakeGraphicChar(struct  pcfont FAR *fontp,int  charN);
unsigned int  ReadPCX(int  find);
int  TUTORto_clip_doc(unsigned int  doc,long  pos,long  len,int  doCut,long  *extraPos);
long  TUTORfrom_clip_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,long  *extraPos,int  saveDo);
int  AllowHandlePurge(unsigned int  mm);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
extern TUTORblock_move(char FAR *sp, char FAR *dp, long lth);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORadd_inset_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,int  kind,unsigned int  dat,long  *extraPos);
unsigned int  wmg_load_font(struct  _fref FAR *fontPath,int  index);
int  TUTORinq_fref(int  findx,struct  _fref FAR *fref);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
long  TUTORget_len_doc(unsigned int  doc);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int  TUTORget_char(int  findx,int  tryHard);
extern int TUTORzero(char FAR *ptr,long lth);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
int  TUTORsave_do_doc(unsigned int  doc,long  pos,long  len,int  op,long  newLen);
int  TUTORchange_doc(unsigned int  doc,long  pos,long  len,long  mpos,long  mlen,unsigned char  FAR *cp,long  cLen,long  fromOff,unsigned int  styles,unsigned int  specialT,long  *extraPos,int  eupFlag);
#endif /* ctproto */

extern char FAR *GetPtr();
long TUTORget_len_doc();
Memh TUTORnew_doc();
extern char FAR *TUTORalloc();
long n_editorpaste();
extern unsigned int  wmg_load_font();
Memh MakeGraphicChar();
Memh ReadPCX();
long TUTORread();

static Memh clipboardDoc=0;
#ifdef IBMPC
#define PC_PASTE
#else
static char selectionOwner = FALSE;
extern Display *display;
#define PC_PASTE
#endif

/* ******************************************************************* */


TUTORto_clip_doc(doc,pos,len,doCut,extraPos) /* do copy/cut */
Memh doc;
long pos,len;
int doCut; /* TRUE if we are cutting */
long *extraPos; /* to be set to position where real end of change is
                    (due to paragraph styles) - in terms of doc AFTER change */
/* returns success flag */
    {
    long clipLen;
    long extraDumm;
    long mLen;
    char FAR *memBuff;
    
    if (!len)
        return(FALSE); /* we don't copy nothing */

#ifndef PC_PASTE
    /* create a memory copy (in be2 datastream) of doc */
    memBuff = TUTORalloc(1000L,FALSE,"cutbuff");
    if (!memBuff)
        return (FALSE);

    mLen = 1000L;
    TUTORfwrite_be2_doc(0,doc,pos,pos+len,0,
            (char FAR * FAR *) &memBuff,&mLen);
    
    if (isx11)
        ToClipboardX11(memBuff,mLen);
    else
        ToClipboardWM(memBuff,mLen);
    TUTORdealloc(memBuff);


    if (isx11)
#else
    if (TRUE)
#endif
        { /* copy to internal clip document */
    
        if (!clipboardDoc)
            { /* create document for handling cut/copy/paste */
            clipboardDoc = TUTORnew_doc(TRUE,FALSE);
            }

        clipLen = TUTORget_len_doc(clipboardDoc);
        TUTORchange_doc_doc(clipboardDoc,0L,clipLen,0L,clipLen,
            doc,pos,len,extraPos,FALSE);
        }
    
    if (doCut)
        {
        TUTORchange_doc(doc,pos,len,pos,len,FARNULL,0L,0L,HNULL,HNULL,extraPos,FALSE);
        }
    
    return(TRUE);
    }

long TUTORfrom_clip_doc(doc,pos,len,mpos, mlen,extraPos, saveDo) /* paste */
Memh doc;
long pos,len;
long mpos, mlen; /* bounds of "marker" that we are changing */
long *extraPos; /* to be set to position where real end of change is
                    (due to paragraph styles) - in terms of doc AFTER change */
int saveDo; /* TRUE if should save action (for later undo) */
/* returns # of chars added */
    {
    long clipLen;
    int aFlag; /* TRUE if this looks like append */
    char FAR *cutBuff;
    int nBytes;
    long tempL;
    
#ifndef PC_PASTE
    if (!isx11)
        { /* ask wm to send us clipboard */
        wm_ReadFromCutBuffer(0);
        TUTORflush();
        /* we will get an EVENT_PASTE event */
        return(0L);
        }

    /* for x11 check to see whether we own both selection & cut buffer */
#ifdef SELECTION_PASTE
    if (selectionOwner)
#else
    if (TRUE)
#endif
        { /* need to check cut buffer */
        cutBuff = XFetchBytes(display,&nBytes);
        if (cutBuff && (nBytes < 24 ||
                (0 != strncmp(cutBuff,"\\begindata{text, 204354}",24))))
            { /* we don't own cut buffer, use it */
            n_editorpaste(FALSE,doc,pos,len,mpos,mlen,cutBuff,(long) nBytes,0,&tempL);
            return(tempL);
            }
        /* else the cut buffer contains cT stuff.  Fall through and use our internal copy */
        /* note that if the cut buffer was filled from a seperate cT process we've blown it */
        }
    else
        { /* we don't own selection, ask for current selection */
        Atom dataProp;
        
        dataProp = XInternAtom(display,"cT clip",FALSE);
        XConvertSelection(display,XA_PRIMARY,XA_STRING,dataProp,windows[0].wp,CurrentTime);
        return(0L);
        }
#endif /* PC_PASTE */
    
    if (!clipboardDoc)
        { /* nothing cut/copied yet */
        *extraPos = pos+len;
        return(0L);
        }
    
    clipLen = TUTORget_len_doc(clipboardDoc);
    if (saveDo)
        TUTORsave_do_doc(doc,pos,len,1,clipLen);
    
    aFlag = (len == 0);
    TUTORchange_doc_doc(doc,pos,len,mpos,mlen,
            clipboardDoc,0L,clipLen,extraPos,FALSE);
    
    return(clipLen);
    }


#ifndef PC_PASTE

/* paste & replace for unix */
long n_editorpaste(ro,doc,startSelect,lenSelect,mpos,mlen,cp,len,type, nAdd)
int ro; /* view read-only flag */
Memh doc; /* panel data */
long startSelect,lenSelect; /* where we are pasting */
long mpos, mlen; /* the "marker" that is getting changed */
char FAR *cp; /* new chars */
long len; /* length of new chars */
int type; /* 0: be2 datastream, 1: string */
long *nAdd; /* to be set to # of chars added */
    {   
    Memh tempDoc;
    long tempL, extraPos;

    if (ro || len <= 0)
        { /* nothing to do but free memory */
        *nAdd = 0L;
        return(-1L);
        }
        
    if (type == 0)
        { /* convert datastream to doc */
        tempDoc = TUTORnew_doc(TRUE,TRUE);
        TUTORread_be2_doc(0,tempDoc,(unsigned char FAR *) cp,len);
        tempL = TUTORget_len_doc(tempDoc);
        TUTORsave_do_doc(doc,startSelect,lenSelect,1,tempL);
        TUTORchange_doc_doc(doc,startSelect,lenSelect,mpos,mlen,
                tempDoc,0L,tempL,&extraPos,FALSE);
        }
    else if (type == 1)
        { /* string */
        TUTORsave_do_doc(doc,startSelect,lenSelect,1,len);
        TUTORchange_doc(doc,startSelect,lenSelect,mpos,mlen,
                (unsigned char FAR *) cp,len,0L,HNULL,HNULL,&extraPos,FALSE);
        tempL = len;
        }
    else
        { /* nothing done */
        tempL = 0;
        lenSelect = 0; /* so that extraPos calc works out correctly */
        }
    
    *nAdd = tempL;
    extraPos += lenSelect - tempL; /* convert to position in doc BEFORE change */
    
    return(extraPos);
    }

/******  routines for WM support of cut & paste *******/
ToClipboardWM(mbuff,len)
char FAR *mbuff;
long len;
    {
    wm_WriteToCutBuffer();  /* tell wm to start putting stuff in cut buffer */
    fwrite(mbuff,1,len,winout);
    putc('\0', winout); /* add terminating zero (finishes cut buffer) */
    }

/******  routines for X11 support of cut & paste ********/

ToClipboardX11(mbuff,len)
char FAR *mbuff;
long len;
    {
    long owner, tempL;
    
    /* put the bytes to cut buffer */
    XStoreBytes(display,mbuff,(int) len);
    
#ifdef SELECTION_PASTE
    if (!selectionOwner)
        { /* tell server that we own selection */
        owner = windows[0].wp;
        XSetSelectionOwner(display,XA_PRIMARY,owner,CurrentTime);
        if (owner == (tempL = XGetSelectionOwner(display,XA_PRIMARY)))
            { /* we are the selection owner */
            selectionOwner = TRUE;
            }
        /* else didn't get selection ownership for some reason */
        }
#endif
    }

HandleSelectionRequest(report)
XEvent *report;
    {
    char FAR *mp;
    long mlen;
    XEvent xev;
    
    if (!selectionOwner)
        {
        return(0);
        }

    if (report->xselectionrequest.target == XA_STRING)
        { /* requestor wants string, we can do that */
        /* create string */
        mp = TUTORalloc(1000L,FALSE,"selrqbuf");
        if (mp)
            {
            TUTORfwrite_be2_doc(1,clipboardDoc,0L,TUTORget_len_doc(clipboardDoc),0,
                        (char FAR * FAR *) &mp, &mlen);
    
            /* send string to requestor */
            XChangeProperty(display,report->xselectionrequest.requestor,
                report->xselectionrequest.property,XA_STRING,8,PropModeReplace,
                (unsigned char *) mp,(int) mlen);
            TUTORdealloc(mp);
            
            xev.xselection.target = report->xselectionrequest.property;
            }
        }
    else
        { /* we can't fufill request */
        xev.xselection.property = None;
        }
    
    /* notify requestor */
    xev.xselection.type = SelectionNotify;
    xev.xselection.requestor = report->xselectionrequest.requestor;
    xev.xselection.selection = report->xselectionrequest.selection;
    xev.xselection.target = report->xselectionrequest.target;
    xev.xselection.time = report->xselectionrequest.time;
    XSendEvent(display,report->xselectionrequest.requestor,TRUE,
            0,&xev);
    }


HandleSelectionClear(report)
XEvent *report;
    {
    /* we don't own selection anymore */
    selectionOwner = FALSE;
    
    /* we can get rid of our clipboard doc (since it isn't valid) */
    TUTORclear_doc(clipboardDoc);
    }

#endif


















































































































































































































































































































































































































































































































































































































































































































































