
/* fdbct input type */
/* fdbct input output type */

#define FAR 
#include <stdio.h>
#include "baseenv.h"

#ifdef IBMPC
#define WOPEN "wb"
unsigned int _stklen = 32767;
#endif

#ifdef X11
#define WOPEN "w"
#endif

#ifdef ANDREW
#define WOPEN "w"
#endif

#include "chardef.h"

/* #define NULL 0L */
#define MAXLINE 400

#ifdef ctproto
extern int main(int,char **);
extern int ReadHeader(FILE *inFile,struct pcfont816 *fontP,int *inputType);
extern int ReadChar(FILE *inFile,int inputType, struct pccharl *charP, unsigned char **maps, int *sizes, int *exists, struct pcfont816 *fontP);
static int ReadNums(char *cp,short *sp1,short *sp2);
static int ReadRaster(FILE *inFile,unsigned char *cMap,int sizeX,int sizeY,int rowBytes,int nRasterLines);
static int ReadFdbCharHeader(FILE *inFile,struct pccharl *charP);
static int ReadBdfCharHeader(FILE *inFile,struct pccharl *charP, struct pcfont816 *fontP);
static int WritePCFont(FILE *outFile,struct pcfont816 *fontP,struct pccharl *chars, unsigned char **maps, int *sizes, int *exists, int style, int type, int iType);
static int fgets2(char *ss,int nn,FILE *inFile);
extern char FAR *malloc(long len);
extern int strcmp(char *,char *);
extern int strcpy(char *, char *);
extern int strncmp(char *,char *,int);
#endif

#define FDBIN 0
#define BDFIN 1

char FAR *malloc();
static short nextChar = -1; /* used if encounter new Character line */
                            /* (due to no-raster char) */

#ifdef X11
#define MAXCHARS 32767
#else
#define MAXCHARS 256
#endif

unsigned int first_char; /* first character in font */
unsigned int num_chars; /* number characters in font */

/* ******************************************************************* */

main(argn,argc)
int argn;
char **argc;
    
{   struct pcfont816 fontP; /* pointer to font data */
    struct pccharl *chars; /* character info for MAXCHARS characters */
    struct pccharl *charP;
    unsigned char *maps[MAXCHARS]; /* maps for characters */
    int sizes[MAXCHARS]; /* sizes of bitmaps for the characters */
    int exists[MAXCHARS]; /* existence flag for each character */
    int ii,jj;
    char *inName;    /* name of input file */
    char outname[1024]; /* constructed name of output file */
    FILE *infile, *outfile;
    int style; /* face style of font (for struct pcfont.dstyle) */
    int type; /* type of font (for struct pcfont.format 2nd bit) */
    char *argP;
    int inputType; /* type of input file, one of FDBIN, BDFIN */

    outname[0] = '\0'; /* no output file name yet */
	chars = (struct pccharl FAR *)
			   malloc((long)(MAXCHARS*sizeof(struct pccharl)));

    /* infile should be opened from argument to main */
    if (argn <= 1) {
        /* tell user the usage */
        printf("Usage: fdbct input-file [output-file] [type(biuog)]\n");
		return(0);
    }

    inName = argc[1];
    infile = fopen(inName,"r");
    if (!infile) {
        printf("Can't open file %s\n",inName);
        return(0);
    }

    /* set type and style of font */
    style = PLAINSTYLE;
    type = GRAPHICS;
	first_char = num_chars = 0;
    if (argn > 2) {
        /* read type argument */
        if (argn > 3)
            argP = argc[3];
        else
            argP = argc[2];
        while(*argP) {
            if (*argP == 'b')
                style |= BOLDSTYLE;
            if (*argP == 'i')
                style |= ITALICSTYLE;
            if (*argP == 'u')
                style |= UNDERLINESTYLE;
            if (*argP == 'o')
                style |= OUTLINESTYLE;
            if (*argP == 'g')
                type = GRAPHICS;
            argP++;
        } /* while */
    } /* argn if */

    /* get output file name if specified */

    if (argn > 3) {
        argP = argc[2];
        strcpy(outname,argP);
    } /* argn if */

    /* -------------- initializations ----------------- */

    for (ii=0; ii<10; ii++)
        fontP.family[ii] = '\0';
    for (ii=0; ii<6; ii++)
        fontP.notused[ii] = '\0';
    fontP.ident[0] = 'c';
    fontP.ident[1] = 't';
    fontP.ident[2] = fontP.ident[3] = '\0';
    for (ii=0; ii<MAXCHARS; ii++)
        maps[ii] = NULL;
    for (ii=0, charP=chars; ii<MAXCHARS; ii++, charP++) {
        /* default data for characters */
        charP->map = 0;
        charP->pdx = charP->pdy = 0;
        charP->bndx = charP->bndy = 0;
        charP->bnw = charP->bnh = 0;
        charP->mapdx = charP->mapdy = 0;
        charP->mapw = charP->maph = 0;
         /* mapw,maph == 0 indicates character has no raster image */
        exists[ii] = 0; /* character doesn't exist */
    } /* for */
    
	/* -------------- read header ------------------ */

    if (!ReadHeader(infile,&fontP,&inputType))
		return(0); /* failure */
    
	/* -------------- read characters -------------- */

    while (ReadChar(infile,inputType,chars,maps,sizes,exists,&fontP))
            ; /* just keep reading... */
    fclose(infile);
    
    /* -------------- finish up -------------------- */

    if (outname[0] == 0) {
        ii = strlen(inName)-1;
        while(ii && (inName[ii] != '/'))
            ii--; /* back up over file name component */
        if ((inName[ii] == '/'))
            ii++; /* index of 1st char of file name component */
        jj = 0;
        while(inName[ii] && (inName[ii] != '.') && (jj < 1000)) {
            outname[jj++] = inName[ii++];
        } /* while */
		outname[jj] = '\0';
#ifdef IBMPC
		strcat(outname,".fpc");
#else
		strcat(outname,".fct");
#endif
    } /* outname if */
    outfile = fopen(outname,WOPEN);
    if (!outfile) {
        printf("Can't open file %s\n",outname);
        return(0);
    }

    WritePCFont(outfile,&fontP,chars,maps,sizes,exists,style,type,inputType);
	fclose(outfile);

	return(0);
    
} /* main */

/* ******************************************************************* */

ReadHeader(inFile,fontP,iType) /* read header info of fdb input file */
FILE *inFile;
struct pcfont816 *fontP;
int *iType; /* to be set to input file type */
/* returns 1 for success, 0 for failure */

{   char tempS[200];
    int size, tempI;
    char *cp;

    fgets2(tempS,199,inFile);
    if (!strcmp(tempS,"$magic 509"))
        *iType = FDBIN;
    else if (!strncmp(tempS,"STARTFONT",9))
        *iType = BDFIN;
    else {
        printf("Don't recognize input file type.\n");
        fclose(inFile);
        return(0);
    } /* else */

    if (*iType == FDBIN) {
        fgets(tempS,199,inFile); /* fontname line, skip it */
        fgets2(tempS,199,inFile); /* $ familyname */
        if (strlen(tempS+12) > 9) {
            /* familyname too long, truncate it */
            tempS[12+9] = '\0';
        }
        strcpy(fontP->family,tempS+12);
        fgets(tempS,199,inFile); /* rotation */
        fgets(tempS,199,inFile); /* pointsize */
        sscanf(tempS+11,"%d",&size);
        fontP->size = size;
    
        /* skip the rest of the info (we will construct from characters) */
        /* we will read thru first "character" line */
        while (1) {
            fgets(tempS,199,inFile);
			if (!strncmp(tempS,"$Comment 16 bit encoding",24)) 
				fontP->format |= 4; /* set 16-bit encoding flag */
            if (!strncmp(tempS,"$character",10)) {
                /* found character number, read it */
                ReadNums(tempS,&nextChar,NULL);
                break;
            }
        } /* while */
	} else { /* BDFIN input file type */
        
        while (fgets(tempS,199,inFile))
            {
            if (0 == strncmp(tempS,"FAMILY_NAME",11))
                { /* family name */
                /* strip name at end */
                tempI = strlen(tempS);
                cp = tempS+tempI-1;
                while (*cp != '"')
                    cp--;
                *cp = '\0'; /* strip trailing quote */
                /* strip name at begin */
                cp = tempS;
                while (*cp != '"')
                    cp++;
                cp++; /* strip leading quote */
                if (strlen(cp) > 4)
                    cp[4] = '\0';
                strcpy(fontP->family,cp);
                }
            else if (0 == strncmp(tempS,"SIZE",4))
                { /* size */
                sscanf(tempS+5,"%d",&size);
                fontP->size = size;
                }
            else if (0 == strncmp(tempS,"ENCODING",8))
                { /* hit first char */
                sscanf(tempS+9,"%d",&tempI);
                nextChar = tempI;
                break;
                }
            else if (0 == strncmp(tempS,"FONTBOUNDINGBOX",15))
                { /* bounding box line */
                sscanf(tempS+16,"%d %d",&tempI,&size);
                fontP->newline = size;
                }
            else if (0 == strncmp(tempS,"FONT_ASCENT",11))
                { /* font ascent */
                sscanf(tempS+12,"%d",&tempI);
                fontP->ascent = tempI;
                }
            else if (0 == strncmp(tempS,"FONT_DESCENT",12))
                { /* font descent */
                sscanf(tempS+13,"%d",&tempI);
                fontP->descent = tempI;
                }
            /* all other lines we skip */
            }
        }

    return(1);
    }

/* ******************************************************************* */

ReadChar(inFile,iType,chars, maps,sizes,exists,fontP) /* read in 1 character of data */
FILE *inFile;
int iType; /* input type, one of FDBIN, BDFIN (ignored, assummed FDBIN) */
struct pccharl *chars; /* pointer to character data */
unsigned char **maps; /* pointer to maps */
int *sizes; /* sizes of bitmaps */
int *exists; /* existence flag for characters */
struct pcfont816 *fontP; /* pointer to font data */
/* returns TRUE on success, FALSE for failure (such as EOF) */
    {
    char inLine[MAXLINE]; /* input buffer */
    short rowBytes;
    struct pccharl *charP; /* pointer to character we are reading this time */
    short charN;
    char *lp;
    int tempI;

    if (nextChar < 0)
        { /* have no next char info, get it */
        if (NULL == fgets(inLine,MAXLINE-1,inFile)) return(0); /* EOF probably */
        if (iType == FDBIN)
            {
            if (!strncmp(inLine,"$end",4)) return(0); /* end of data in fdb file */
            ReadNums(inLine,&charN,NULL); /* read character # */
            }
        else /* BDFIN type */
            {
            lp = inLine; /* for start of while */
            while ((0 != strncmp(inLine,"ENCODING",8)) && lp)
                {
                lp = fgets(inLine,MAXLINE-1,inFile); /* skip lines */
                }
            if (!lp)
                return(0); /* end of file */
            sscanf(inLine+9,"%d",&tempI);
            charN = tempI;

            if (charN < 0)
                { /* non-iso character, skip it */
                while (lp = fgets(inLine,MAXLINE-1,inFile))
                    {
                    if (0 == strncmp(inLine,"ENDCHAR",7))
                        break; /* finished this char */
                    }
                return(lp ? 1 : 0); /* returns FALSE if we ran out of file */
                }
            }
        }
    else
        {
        charN = nextChar;
        }

    charP = chars + charN;
    exists[charN] = 1; /* mark character as existing */
    nextChar = -1;
    
    /* read character header info */
    if (iType == FDBIN)
        ReadFdbCharHeader(inFile,charP);
    else
        ReadBdfCharHeader(inFile,charP,fontP);

    /* allocate bitmap for character */
    rowBytes = (charP->bnw+7)/8;
    sizes[charN] = rowBytes*charP->bnh;
	maps[charN] = (unsigned char FAR *)malloc((long)sizes[charN]);
    if (!maps[charN])
        {
        printf("Cannot allocate memory");
        return(0);
        }
    
    /* read raster image */
    ReadRaster(inFile,maps[charN],charP->bnw,charP->bnh,rowBytes,charP->bnh);

    /* set bitmap size to bounding box size  (ought to be able to be different) */
    charP->mapw = charP->bnw;
    charP->maph = charP->bnh;
    charP->mapdx = 0;
    charP->mapdy = 0;

    return(1);
    }

/* ******************************************************************* */

static ReadFdbCharHeader(inFile,charP)
FILE *inFile;
struct pccharl *charP; /* pointer to character we are reading this time */
/* returns TRUE if need to read raster */
    {
    char inLine[MAXLINE]; /* input buffer */
    short tempS, tempT;

    while (1)
        {
        fgets(inLine,MAXLINE-1,inFile);
        if (!strncmp(inLine,"$box",4))
            {
            ReadNums(inLine,&tempS,&tempT);
            charP->bnh = tempT;
            charP->bnw = tempS;
            }
        else if (!strncmp(inLine,"$origin",7))
            {
            ReadNums(inLine,&tempS,&tempT);
            charP->bndx = -tempS;
            charP->bndy = -tempT;
            }
        else if (!strncmp(inLine,"$spacing",8))
            {
            ReadNums(inLine,&tempS,&tempT);
            charP->pdx = tempS;
            charP->pdy = tempT;
            }
        else if (!strncmp(inLine,"$raster",7))
            break; /* finished header */
        else if (!strncmp(inLine,"$character",10))
            {
            ReadNums(inLine,&nextChar,NULL); /* store the info from this line for next call */
            return(0); /* finished current char already */
            }
        }
    return(1); /* need to read raster */
    }

/* ******************************************************************* */
    
static ReadBdfCharHeader(inFile,charP,fontP)
FILE *inFile;
struct pccharl *charP; /* pointer to character we are reading this time */
struct pcfont816 *fontP; /* pointer to font data */
/* returns TRUE if need to read raster */
    {
    char inLine[MAXLINE]; /* input buffer */
    int tempS, tempT, tempA, tempB;

    while (1)
        {
        fgets(inLine,MAXLINE-1,inFile);
        if (0 == strncmp(inLine, "DWIDTH",6))
            { /* spacing */
            sscanf(inLine+7,"%d %d",&tempS,&tempT);
            charP->pdx = tempS;
            charP->pdy = tempT;
            }
        else if (0 == strncmp(inLine, "BBX",3))
            { /* char bounding box */
            sscanf(inLine+3,"%d %d %d %d",&tempS,&tempT,&tempA,&tempB);
            charP->bnw = tempS;
            charP->bnh = tempT;
            charP->bndx = tempA;
            charP->bndy = -tempB - tempT;
            }
        else if (0 == strncmp(inLine, "BITMAP",6))
            break; /* done with header */
        /* skip all other lines */
        }
    return(1); /* always need to read raster */
    }

/* ******************************************************************* */

static ReadNums(cp,sp1,sp2)
register char *cp; /* character data */
register short *sp1, *sp2; /* to be filled with numbers (sp2 may be NIL - don't use) */
    {
    short negFlag;
    register short ii;
    char *cpOld;
    
    negFlag = 0;
    cpOld = cp;
    
    /* scan for first number */
    ii = 0;
    while (*cp && *cp > '9' || *cp < '0') cp++;
    if (cp > cpOld && *(cp-1) == '-')
        negFlag = 1;
    
    /* convert first number */
    ii = 0;
    while (*cp <= '9' && *cp >= '0')
        ii = 10 * ii + *cp++ - '0';
    if (negFlag)
        ii = -ii;
    *sp1 = ii;
    
    if (!sp2) return;
    
    negFlag = 0;
    ii = 0;
    cpOld = cp;
    /* scan for second number */
    while (*cp > '9' || *cp < '0') cp++;
    if (cp > cpOld && *(cp-1) == '-')
        negFlag = 1;
    
    /* convert second number */
    ii = 0;
    while (*cp <= '9' && *cp >= '0')
        ii = 10 * ii + *cp++ - '0';
    if (negFlag)
        ii = -ii;
    *sp2 = ii;
    
    return;
    }

/* ******************************************************************* */

static ReadRaster(inFile,cMap,sizeX,sizeY,rowBytes,nRasterLines)
FILE *inFile;
unsigned char *cMap; /* character bitmap */
int sizeX,sizeY; /* size of character */
int rowBytes; /* # of bytes per row */
int nRasterLines;
    {
    short ii,jj;
    char inLine[MAXLINE];
    unsigned hexIn;
    
    for (ii=0; ii<sizeY; ii++)
        { /* for every line... */
        fgets(inLine,MAXLINE-1,inFile);
        for (jj=0; jj<rowBytes; jj++)
            { /* for every byte we can use */
            sscanf(inLine+2*jj,"%2x",&hexIn);
            *cMap++ = hexIn; /* we can use this byte */
            }
        }
    
    /* skip unread raster lines */
    for (ii = nRasterLines-sizeY; ii>0; ii--)
		fgets(inLine,MAXLINE-1,inFile);

    return(0);
    }

/* ******************************************************************* */

static WritePCFont(outFile,fontP,chars,maps,sizes,exists,style,type,iType)
FILE *outFile;
struct pcfont816 *fontP; /* font information */
struct pccharl *chars; /* character information */
unsigned char **maps; /* bitmaps */
int *sizes; /* sizes of bitmaps */
int *exists; /* existence flag for characters */
int style; /* face style (bold, italic,...) of font */
int type; /* type of font (characters or icons) */
int iType; /* input type (one of FDBIN or BDFIN) */
    
{    int ii;
    long curPos; /* current displacement to bitmap */
    char useSmall; /* TRUE if we are using small-character format */
    struct pcfont816 fonthdr; /* font header information */
    struct pcchars smallChar; /* small character structure */
    struct pccharl largeChar; /* large character structure */
    long tempL;
    int rowBytes;
    int cidata,codata;
    int jj,bx,by,bi,bw;
    unsigned char *p32, *p160;

    /* find first character we have */
    
    first_char = 0;
    while (!exists[first_char] && first_char < MAXCHARS)
        first_char++;
    /* find last character we have */
    ii = MAXCHARS-1;    /* all chars */
    while (!exists[ii] && ii >= 0)
        ii--;
    if (first_char > MAXCHARS-1 || ii < 0) { /* no characters at all, fail */
        printf("No characters were read\n");
		return(0);
    }
    num_chars = ii - first_char + 1;
	if (fontP->format & 4) { /* 16-bit encoding */
		fontP->first16 = first_char;
		fontP->nchars16 = num_chars;
	} else { /* 8-bit encoding */
		fontP->first8 = first_char;
		fontP->nchars8 = num_chars;
	}

    if (!exists[160] && ii > 160 && exists[32]) {
        /* full font but non-breaking space is missing, copy regular space */
        exists[160] = 1;
        chars[160] = chars[32];
        rowBytes = (chars[32].bnw+7)/8;
        sizes[160] = rowBytes*chars[32].bnh;
		maps[160] = (unsigned char FAR *)malloc((long)sizes[160]);
        
        /* copy map */
        p160 = maps[160];
        p32 = maps[32];
        for (jj=0; jj<sizes[160]; jj++)  
            *p160++ = *p32++;
    } /* exists if */
    
    /* reverse bit order for X11 */

#ifdef X11
#ifndef hp700
#ifndef SOLARIS
    for (jj=first_char; jj<(first_char+num_chars); jj++) {
        if (maps[jj] == NULL)
            continue; /* this character doesn't exist */
        p32 = maps[jj];
        bw = chars[jj].mapw; /* compute width of char in bytes */
        bw = (bw+7) >> 3;
        for(by = 0; by < chars[jj].maph; by++) {
            for(bx = 0; bx < bw; bx++) {
                cidata = *p32;
                codata = 0;
                for(bi = 0; bi < 8; bi++) {
                    if (cidata & (1 << bi))
                        codata |= 0x80 >> bi;
                } /* bi for */
                *p32++ = codata;
            } /* bx for */
        } /* by for */
	} /* jj for */
#endif
#endif
#endif
    
    /* find out whether we can use small character format */
    /* & set rest of header info while we're at it */
    useSmall = ThruFont(fontP,chars,maps,first_char,first_char+num_chars,iType,type);
    
    /* figure out the rest of the header info */
    fontP->rmap = NULL;
    fontP->rdef = NULL;
    fontP->ddef = sizeof(struct pcfont816);
    if (useSmall)
        fontP->dmap = sizeof(struct pcfont816) + num_chars*sizeof(struct pcchars);
    else
        fontP->dmap = sizeof(struct pcfont816) + num_chars*sizeof(struct pccharl);
    fontP->dstyle = style;
    fontP->astyle = 0;
    fontP->format |= ((useSmall ? 0 : 1) + 2*type);

    /* write out data */
    
    /* header */

    fonthdr = *fontP;
    fwrite((char *)&fonthdr,sizeof(struct pcfont816),1,outFile);
    
    /* char data */
    curPos = 0; /* current displacement to bitmap */
    for (ii=first_char; ii<first_char+num_chars; ii++) {
        if (maps[ii] != NULL) {
            /* calculate & update character rastermap position in file */
            chars[ii].map = curPos;
            curPos += sizes[ii];
        }
        
        /* note: character really exists only if exists[ii] == 1 */
        /* we write out data for all characters even if they don't exist */
        /* non-existant chars have all fields (including map) set to zero */

        if (useSmall) {
            LtoSChar(chars+ii,&smallChar);
            fwrite((char *) &smallChar,sizeof(struct pcchars),1,outFile);
        } else {
            largeChar = *(chars+ii);
            fwrite((char *)(&largeChar),sizeof(struct pccharl),1,outFile);
        } /* useSmall else */
    } /* for */

    /* bitmaps */
    for (ii=first_char; ii<first_char+num_chars; ii++) {
        if (maps[ii] != NULL) {
            tempL = fwrite((char *)  maps[ii],sizeof(char),sizes[ii],outFile);
            /* printf("Writing map for %d %ld\n",ii,tempL); */
        }
    } /* for */

	return(0);

} /* WritePCFont */
    
/* ******************************************************************* */

ThruFont(fontP,chars,maps,first,last1,iType,type) /* look thru whole font */
struct pcfont816 *fontP;
struct pccharl *chars;
unsigned char **maps; /* bitmaps for chars (empty if char doesn't exist) */
int first; /* first character in font */
int last1; /* last character + 1 in font */
int iType; /* input type (one of FDBIN, BDFIN) */
int type; /* font type (GRAPHICS or CHARACTERS) */
/* returns 1 if can use small character format */
    {
    int ii;
    struct pccharl *cp;
    int smChar;
    int ascent, descent; /* calculated ascent & descent of font */
    int testWidth; /* sum of widths of lower case letters */

    /* this routine looks thru all the characters in the font.  It sets the remainder of the
       font header information and decides whether the small character format can
       be used */
    /* note that the ascent and descent are calculated for the whole font,
       while all the rest of the quantities are for chars we are actually
       going to use */

    smChar = 1; /* assume we can use small character format */
    fontP->maxwidth = 0;
    ascent = 0;
    descent = 0;
    testWidth = 0;
    for (ii=first, cp=chars+first; ii<last1; ii++,cp++)
        {
        if (maps[ii] == NULL)
            continue; /* this character doesn't exist */

        /* font header info */
        if (cp->bnw > fontP->maxwidth)
            fontP->maxwidth = cp->bnw;
        if (-cp->bndy > ascent)
            ascent = -cp->bndy;
        if (cp->bnh + cp->bndy > descent)
            descent = cp->bnh + cp->bndy;

        if (ii >= 'a' && ii <= 'z')
            testWidth += cp->pdx;

        /* check for small character format */
        if (cp->pdx < -128 || cp->pdx > 127)
            smChar = 0;
        if (cp->pdy < -128 || cp->pdy > 127)
            smChar = 0;
        if (cp->bndx < -128 || cp->bndx > 127)
            smChar = 0;
        if (cp->bndy < -128 || cp->bndy > 127)
            smChar = 0;
        if (cp->bnw < 0 || cp->bnw > 255)
            smChar = 0;
        if (cp->bnh < 0 || cp->bnh > 255)
            smChar = 0;
        if (cp->mapdx < -128 || cp->mapdx > 127)
            smChar = 0;
        if (cp->mapdy < -128 || cp->mapdy > 127)
            smChar = 0;
        if (cp->mapw < 0 || cp->mapw > 255)
            smChar = 0;
        if (cp->maph < 0 || cp->maph > 255)
            smChar = 0;
        }

    /* keep looking at font to get correct ascent, descent */
    for (ii = last1, cp= chars+last1; ii < MAXCHARS; ii++,cp++)
        {
        if (maps[ii] == NULL)
            continue; /* this character doesn't exist */

        /* font header info */
        if (-cp->bndy > ascent)
            ascent = -cp->bndy;
        if (cp->bnh + cp->bndy > descent)
            descent = cp->bnh + cp->bndy;
        }


    /* use our calculated quantities */
    fontP->ascent = ascent;
    fontP->descent = descent;
    if (type == GRAPHICS)
		fontP->newline = ascent+descent + 2; /* leading of 2 */
    else
        { /* calculate correct newline height */
        fontP->newline = CalcNewline(ascent+descent,testWidth);
        }
    

    return(smChar);
    }

CalcNewline(yy,tWidth)
int yy; /* ascent + descent of font */
int tWidth; /* sum of width of lower case letters */
    {
    int maxLead;
    int curLead;
    int aspect;

    /* to conform to other computers, we want fonts to have a width to
       width ratio of about 45%.  But we require at least one pixel
       of leading and no more leading than 1/3 yy */

    curLead = 1;
    maxLead = yy/3;
    aspect = ((long) tWidth*100)/((long) (yy+curLead)*26);

    while (aspect > 46 && curLead < maxLead)
        {
        curLead++;
        aspect = ((long) tWidth*100)/((long) (yy+curLead)*26);
        }

    return(yy+curLead);
    }


LtoSChar(charL,charS) /* convert pccharl struct to pcchars */
struct pccharl *charL;
struct pcchars *charS;
    {
    charS->map = charL->map;
    charS->pdx = charL->pdx;
    charS->pdy = charL->pdy;
    charS->bndx = charL->bndx;
    charS->bndy = charL->bndy;
    charS->bnw = charL->bnw;
    charS->bnh = charL->bnh;
    charS->mapdx = charL->mapdx;
    charS->mapdy = charL->mapdy;
    charS->mapw = charL->mapw;
    charS->maph = charL->maph;

    return;
    }

/* assorted utilities */

static fgets2(ss,nn,inFile) /* fget without trailing \n */
char *ss;
int nn;
FILE *inFile;
    {
    char *tp, *tEnd;
    
    fgets(ss,nn,inFile);
    tp = ss;
    tEnd = ss+nn;
    while (*tp != '\n' && tp < tEnd && *tp)
        tp++;
    if (*tp == '\n')
        *tp = 0; /* get rid of newline */
    
    return;
    }
