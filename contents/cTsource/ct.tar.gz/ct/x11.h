
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#ifndef _x11ih
#define _x11ih

typedef char *Ptr;

#ifdef LINUX
#define ctproto
#endif

#define NEWLINE '\n'
#define NEWLINES "\n"
#define RETURN '\r'

#define FAR /* far pointer declaration for IBM-PC */
#define SHUGE /* huge pointer declaration for IBM-PC */
#define CDECL /* C pointer declaration for IBM-PC */
#define Farp(x) ((char *) (x))
#define NEARNULL 0L
#define FARNULL 0L

#define HPurge(x) /* purge */
#define HNoPurge(x) /* nopurge */
#define FastReleasePtr(x) /* fast release of handle */

#define FILEL 1024  /* max file name length */

#define EVENTLIMIT 100		/* maximum number events to stack up */

#ifdef ibm032
/* define ctproto */
#endif

/* file reference structure: */
typedef struct _fref {
	char path[FILEL+2]; /* file path */
	short nameInd;	/* index to where file name starts */
} FileRef;

/* machine-dependent graphics definitions */

/* text face definitions */

#define style_plain 0
#define style_bold 1		
#define style_italic 2

/* text/pattern mode definitions */

#define	SRC_COPY 0	/* mode rewrite */
#define	SRC_OR	1	/* mode write */
#define	SRC_XOR	2	/* mode xor */
#define	SRC_BIC	3	/* mode erase */
#define	NOT_SRC_COPY 4	/* mode inverse */
#define	NOT_SRC_OR 5
#define	NOT_SRC_XOR 6
#define	NOT_SRC_BIC 7

  /* for filling a solid rect */
#define PAT_BLACK  1
#define PAT_WHITE  20
#define PAT_BACKGROUND -1

#ifdef ANDREW
#define NFSIZES 6
#endif
#ifndef NFSIZES
#define NFSIZES 5
#endif

/* scroll bar part codes */
#define inButton 10
#define inCheckBox 11
#define inUpButton 20
#define inDownButton 21
#define inPageUp 22
#define inPageDown 23
#define inThumb 129

#define BADPOINTER -3

struct saved_region {
	int format; /* 0 = native screen format, 1 = XImage */
	int width; /* width of region */
	int height; /* height of region */
	
	/* definitions for saved native screen region */
	
	int offsetX, offsetY; /* offsets from -get- origin to image origin */
	long PixID; /* Pixmap id of saved region */
	
	/* definitions for color image */
	
	int wExec; /* TRUE if window created for execute window */
	char FAR *imageP; /* pointer to XImage */
	unsigned int nativePal; /* handle on image (cT format) palette */
	unsigned int palDataH; /* handle on pixels in palettized form */
	unsigned int rgbDataH; /* handle on pixels in 3-byte RGB form */
}; /* saved_region */

#endif  /*  _x11ih */

