

/* (c) Copyright Carnegie-Mellon University, 1988. */
/* May be used and copied freely for educational purposes, */
/* but may not be sold without the written consent of Carnegie-Mellon University. */

/* TUTORgraphics package */

#include "dospc.h"
#include <stdio.h>
#include <float.h>
#include <signal.h>
#include <bios.h>
#include <dos.h>
#ifdef TURBOC
#include <alloc.h>
#else
#include <malloc.h>
#endif
#include <setjmp.h>
#include <process.h>
#include <stdlib.h>
#include <string.h>
#ifdef MSC
#include <direct.h>
#endif
#include <sys\types.h>
#include <sys\timeb.h>
#include <sys\stat.h>

#include "time.h"

#include "memory.h"
#include "execdefs.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "eglobals.h"
#include "edglobal.h"
#include "editor.h"
#include "tgraphpc.h"
#include "tfiledef.h"
#include "kglobals.h"

/* ******************************************************************* */

#ifdef ctproto
int  igraphpc(int  argc,char  * *argv);
int  TUTORstartup(int  argc,char  * *argv,struct  _fref FAR *filenameR);
int  TUTORclose_copyright(void);
int  TUTORdone_startup(void);
int  pc_init_mem(void);
int  InitHandles(void);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  wmg_palette(int  wid,int  new);
int  CTinit_color(void);
/* extern int86x(); */
/* extern segread(); */
/* extern int86(); */
extern void exit(int status);
/* extern pc_inst_mcga(); */
/* extern videoid(); */
/* extern ident87(); */
int  TUTORcopy_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  TUTORcvt_file_name(char  *ssx,struct  _fref FAR *fRef,struct  _fref FAR *baseRef);

int  ctconfig(void);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
/* extern pc_clip(); */
/* extern pc_on(); */
/* extern pc_crit_init(); */
/* extern pc_mouse_drv(); */
int  CTset_background_color(int  color);
int  CTset_foreground_color(int  color);
int  wmg_wipe(void);
int  wmg_font(long  fonth);
/* extern sysfont_chrh(); */
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
extern unsigned char FAR *sysfont_addr();
extern char FAR *pc_lp(long pp);
extern long pc_pl(char FAR *pp);
/* extern TUTORset(); */
/* extern farcalloc(); */
/* extern _OvrInitExt() */
/* extern _OvrInitEms() */
int  TUTORcopy_fileref_dir(struct  _fref FAR *dirname,struct  _fref FAR *fullname);
/* extern getcwd(); */
/* extern _dos_getdrive(); */
int  pd_init(void);
int  TUTORdealloc(char  FAR *ptr);
/* extern pc_off(); */
/* extern pc_char(); */
int  wmg_color(int  fc,int  bc);
/* extern pc_font(); */
int  TUTORclose(int  findx);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
char  FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
struct  htab FAR *pc_htab(int  handle);
char  *strf2n(char  FAR *strp);
/* extern _dos_setdrive(); */
int  assoc_name(struct  _fref FAR *fn,struct  _fref FAR *bfilen,char  *extnNew);
long  TUTORinq_msec_clock(void);
#ifdef IBMPROTO
int _CDECL printf(const char *, ...);
int _CDECL fclose(FILE *);
int _CDECL fprintf(FILE *, const char *, ...);
FILE * _CDECL fopen(const char *, const char *);
#endif /* IBMPROTO */
#endif /* ctproto */

/* ******************************************************************* */

extern  int TUTORcopy_fileref(struct _fref FAR *fDest,struct _fref FAR *fSource);
extern  int TUTORcmp_fileref(struct _fref FAR *f1,struct _fref FAR *f2);
extern  int TUTORcopy_fileref_name(struct _fref FAR *fRef,char FAR *name);
extern  int TUTORcopy_fileref_dir(struct _fref FAR *dset,struct _fref FAR *dirname);
extern  int TUTORsymbolic_fileref(struct _fref FAR *fRef, char FAR *syms);
extern int TUTORget_fileref_name(struct _fref FAR *fRef, char FAR *name);
extern  int TUTORpurge_info(unsigned int mm,int ptype,int (*restoreproc)(),int restorearg);
extern  int Be2WriteKDoc(unsigned int theD,long sPos,long ePos,int rFlag,FILE *fOut,char FAR * FAR *mp, long *mLen);
extern  long TUTORinq_font_ptr(int nn);
extern  long lcftoi(double dv);
extern  int ctmain(int argc,char * *argv);
extern  char far *GetPtr(unsigned int mm);
extern  int ReleasePtr(unsigned int mm);
extern  char *FullName(char *file,char FAR *path);
extern  int TUTORset_window(int wid);
extern  char *strf2n(char far *strp);
extern  char far *strcpyf(char far *aa,char far *bb);
extern  char far *strcatf(char far *aa,char far *bb);
extern  char far *strncpyf(char far *aa,char far *bb,int nn);
extern  int strncmpf(char far *aa,char far *bb,int nn);
extern  int strlenf(char far *aa);
extern  char far *strncatf(char far *aa,char far *bb,int nn);
extern  int pd_init(void );
extern  int pd_flush(void );
extern  int pd_menumouse(struct tutorevent *event);
extern  int pd_selectcard(int ww,int card);
extern  int pd_display_bar(int ww);
extern  int pd_enter(int wix);
extern  int pd_restore(void );
extern  int pd_menu_change(int ww);
extern  int pd_item_change(int ww,int cardi);
extern  int pd_find_high_menu(int ww,int type,int card,int position,int priority);
extern  int pd_find_itemdn(int ww,int type,int cardi,int n);
extern  int pd_bar_hit(int ww,int mx);
extern  int pd_card_hit(int ww,int card,int my);
extern double lcfdiv(double aa, double bb);
extern  int TUTORopen(FileRef FAR *fRef,int rf,int wf,int af);
extern  int TUTORclose(int findx);
extern  int TUTORinq_file_info(FileRef FAR *fRef,int *waccess,long *length,long *modtim,int *posx,int *posy);
extern  long TUTORinq_file_pos(int findx);
extern  int TUTORinq_file_err(int findx);
extern  int TUTORseek(int findx,long pos);
extern  long TUTORwrite(char FAR *ptr,int pSize,long count,int findx);
extern  long TUTORread(char FAR *ptr,int pSize,long count,int findx);
extern  int TUTORwrite_int(int ii,int findx);
extern  int TUTORread_int(int *ii,int findx);
extern  int TUTORwrite_short(short ss,int findx);
extern  int TUTORread_short(short *ss,int findx);
extern  int TUTORwrite_char(unsigned char cc,int findx);
extern  int TUTORread_char(unsigned char *cc,int findx);
extern  int TUTORget_char(int findx);
extern  long TUTORread_number(int findx);
extern  int TUTORreset_file(int findx,int option);

/* ------------------------------------------------------------------- */

extern  int main(int argc,char * *argv);
extern  int wmg_restore_font(unsigned int unitH,char FAR *up,long uLen,int unitn);
extern  int TUTORstartup(int argc,char * *argv, FileRef FAR *filename);
extern  int TUTORinit_palette(void );
extern  int TUTORsystem_tasks(void );
extern  int TUTORpoll_events(int block);
extern  int TUTORselect_window(int wix);
extern  int TUTORforward_window(int wix);
extern  int TUTORclose_copyright(void );
extern  int TUTORdone_startup(void );
extern  int TUTORset_program_name(char *pname);
extern  int TUTORhide_window(int wInd);
extern  int TUTORshow_window(int wix);
extern  int TUTORwindow_init(void );
extern  int TUTORsync(void );
extern  int TUTORflush(void );
extern  int machineflush(void );
extern  int TUTORset_event_mask(int eventc,int value);
extern  int TUTORabs_move_to(int x,int y);
extern  int TUTORabs_move(int x,int y);
extern  int TUTORdraw_dot(Coord x1,Coord y1);
extern  int TUTORdraw_line(Coord x1,Coord y1,Coord x2,Coord y2);
extern  int TUTORabs_line_to(int x,int y);
extern  int TUTORline_to(Coord x,Coord y);
extern  int TUTORdraw_polyline(int num_pts,Coord *x,Coord *y);
extern  int TUTORdraw_rectangle(Coord x1,Coord y1,Coord x2,Coord y2);
extern  int TUTORdraw_arc(int calledby,Coord xc,Coord yc,Coord x1,Coord y1,Coord x2,Coord y2,double startAngle,double arcAngle,int unbroken);
extern  int TUTORfill_rectangle(Coord x1,Coord y1,Coord x2,Coord y2);
static  int FillTrapezoid(int x1,int y1,int dx1,int x2,int y2,int dx2);
extern  int TUTORfill_polygon(int npoints,Coord *fx,Coord *fy);
extern  int fill_general(int npoints,int top,Coord *fx,Coord *fy);
extern  int find_fill_extremes(Coord *small,Coord *large,Coord *left,Coord *right,int *top,int npoints,Coord *fx,Coord *fy);
extern  int fill_horizontal(Coord left,Coord right,Coord small);
extern  int fill_vertical(Coord left,Coord small,Coord large);
extern  int horizontal_top(Coord *p_toplength,int *p_itemp,int *p_count,int top,int npoints,Coord *fx,Coord *fy);
static  int pc_trapezoid(int x1,int y1,int w1,int x2,int y2,int w2,long fh,int c, int lastF);
static  struct pcfont FAR *pc_fix_font(long fh);
extern  int TUTORinvert_abs_rect(int x1,int y1,int x2,int y2);
extern  int TUTORmove_abs_rect(int x1,int y1,int x2,int y2,int newx,int newy);
extern  int TUTORclear_screen(void );
extern  int TUTORbeep(int *ff,int *dur,int *volume,int nbeep);
extern  int TUTORstop_sound(void );
extern  int TUTORset_comb_rule(int rule);
extern  int TUTORpalette(int index,double red,double green,double blue,int defaultindex);
extern  int TUTORinq_palette(int paletteN,int *realN,double *redV,double *greenV,double *blueV);
extern  int TUTORinq_closest_palette(double redv,double greenv,double bluev);
extern  int TUTORrestore_palette(int color);
extern  int CTset_foreground_color(int color);
extern  int CTset_background_color(int color);
extern  int CTset_window_color(int color);
extern  long TUTORinq_msec_clock(void );
extern  int TUTORinq_abs_pen_pos(int *x,int *y);
extern  int TUTORstart_menubar(unsigned int barh);
extern  char far *TUTORzfont(char far *fName);
extern  int ConvertSystemName(char *fName);
extern  int TUTORmouse_off(void );
extern  int TUTORmouse_on(void );
extern  int TUTORset_cursor(int cInd,int cChar);
static  char far *fontchrmap(struct pcfont far *f,int cc,int *bytesx,int *bytesy,int *hotx,int *hoty);
extern  int TUTORarrow_cursor(int isTemp);
extern  int TUTORset_abs_space_shim(long shim);
extern  int TUTORhilite(int x1,int y1,int x2,int y2);
extern  int TUTORdraw_text(unsigned char far *buf,int count);
extern  int TUTORshim_move(int nMove);
extern  int TUTORtext_flush(void );
extern  int displayffv(int x,int y,int op,int format,double value);
extern  int TUTORnormal_cursor(void );
extern  int TUTORwait_cursor(void );
extern  int TUTORresume_cursor(void );
extern  int TUTORdraw_graphic_icons(char *s);
extern  int TUTORdraw_alpha_icons(char *s);
extern  int TUTORinq_font_info(int *ascent,int *descent,int *maxwidth,int *leading);
extern  int TUTORinq_abs_string_width(unsigned char far *s,int lth,int *dx);
extern  int FSize2Index(int fSize,int defIndex);
extern  int FIndex2Size(int fIndex,int defIndex);
extern  int TUTORexit_machine(void );
extern  int wmg_on(void );
extern  int wmg_off(void );
extern  int wmg_font(long fonth);
extern  int wmg_layout(void );
extern  int wmg_fwd(int wix);
extern  int wmg_arrange(int focus);
extern  int wmg_frame(int wix);
extern  int wmg_outline(int x1,int y1,int x2,int y2,int md);
extern  int wmg_focus(int fwix);
extern  int wmg_hide(int wix);
extern  int wmg_window_pt(int x,int y);
extern  int wmg_wipe(void );
extern  int wmg_color(int fc,int bc);
extern  int TUTORtrace(char *s);
extern  int TUTORtrace_d(char *s,double nn);
extern  int TUTORtrace_n(char *s,long nn);
extern  int TUTORtrace_n_n(char *s,long nn,long mm);
extern  int TUTORtrace_x(char *s,long nn);
extern  int windmp(void );
extern  int TUTORdump(char *s);

extern unsigned char far *sysfont_addr();
extern char *FullName();
extern char far *pc_np(char far *ptr);
extern long pc_pl(char far *ptr);
extern char far *pc_lp(long addr);
extern int pc_float();
extern int pc_mouse_drv();
extern char FAR *fontchrmap();

extern int lforkf;  /* layout fork flag (-d option) */
extern int twf;     /* dma debug option */
extern int spyf;    /* profiling flag */
extern int codegen; /* compiled code flag */
extern struct sourcefile far *sourcetable;  /* source file names/pointers */

extern int pcv_mouseqi;     /* index in mouse queue */
extern int pcv_mouseq[];    /* mouse queue */
extern int pcv_sndw;    /* delay count for sound generator */
extern int vga_isoff;
extern int vga_wmode;
extern int vga_foregnd,vga_backgnd;
extern int vga_clipx,vga_clipy,vga_clipw,vga_cliph;

/* ******************************************************************* */

extern int wmg_xo[WINDOWLIMIT];    /* window x origin */
extern int wmg_yo[WINDOWLIMIT];    /* window y origin */
extern int wmg_xs[WINDOWLIMIT];    /* window x size */
extern int wmg_ys[WINDOWLIMIT];    /* window y size */
extern int wmg_next[WINDOWLIMIT];  /* index of next (upper, forwards) window */
extern int wmg_prev[WINDOWLIMIT];  /* index of previous (lower, behind) window */
extern int wmg_obscured[WINDOWLIMIT];   /* TRUE if window obscured */
extern int wmg_hidden[WINDOWLIMIT]; /* TRUE if window hidden */
extern int wmg_select; /* window selected for move/resize operation */
extern int wmg_top;    /* index of topmost window */
extern int wmg_bottom; /* index of bottommost window */
extern int wmg_px;     /* physical x screen size */
extern int wmg_py;     /* physical y screen size */
extern int wmg_ncolors;   /* number colors available */
extern int pd_menualt[WINDOWLIMIT]; /* menus altered table */

extern int pd_mw; /* current window for menu operations */
extern int pd_barheight; /* pull-down menu bar height */
extern int pd_wmctrlw; /* control button width */

/* ******************************************************************* */

extern Memh wmFonth; /* handle on currently selected text font */
extern struct pcfont far *wmFont; /* currently selected text font */

extern int mousef;  /* TRUE if mouse present */
extern int nmouseb; /* number buttons on mouse */
extern int mousex;  /* current mouse x position */
extern int mousey;  /* current mouse y position */
extern int mouses;  /* current mouse mode/button status */
extern int buttonmsk;   /* mask for mouse button bits */
extern int mouseld; /* window of mouse left-down */
extern int mouserd; /* window of mouse right-down */
extern char far *mousestat; /* save buffer for mouse status */
extern int mouseqo; /* output pointer in circular mouse queue */

extern Memh sysfonth; /* handle on system characters font */

extern int vmbios; /* original bios video mode */
extern struct videoid vid;  /* vga, ega, cga, mda info */
extern int vgaf,egaf,mcgaf,cgaf; /* TRUE for appropriate video system */
extern int tginit; /* TRUE if initializations completed */

extern long mem_conv; /* conventional memory found */
extern long mem_xms; /* xms found */
extern long mem_ems; /* ems found */
extern long mem_disk; /* disk swap found */

/* ******************************************************************* */

igraphpc(argc, argv)
int argc;
char **argv;

{   union REGS inr; /* input  registers for int86 */
    union REGS outr; /* output registers for int86 */
    struct SREGS segr; /* segment registers for int86x */
    struct pcchars FAR *chrdef; /* pointer to character defs table */
    char palette[17]; /* palette plus overscan register */
    struct pcfont FAR *sysfont;  /* pointer to system characters font */
    struct pcchars FAR *sysdef;  /* pointer to system font character defs */
    long fsize; /* size of font structure */
    char far *cp;
    char *cc;
    double av,bv,cv;
    long rtime;
    int forcevid; /* graphics adapter specified on cmd line */
    FileRef fname; /* file name for font/code page operations */
    int fontfi; /* index of font file in file table */
    int codefi; /* index of code page file in file table */
    char codepn[14]; /* file name for code page data */
    struct tutorfile FAR *tfp; /* pointer to file table */
    struct pcfont far *fontptr; /* pointer to falcon font in memory */
    int FAR *tickp; /* pointer to BIOS tick count */
    long tickc; /* counter used to establish machine speed */
    int i;

    mem_conv = mem_ems = mem_xms = mem_disk = 0;

    ctconfig(); /* determine editor, executor, etc */

    /* process command-line options */

    forcevid = -1; /* no video type specified yet */
    logevents = playevents = FALSE; /* not loging/replaying events */
    for(i=1; i<argc; i++) {
/*  if ((strcmp(argv[i],"/CGA") == 0) || (strcmp(argv[i],"/cga") == 0))
        forcevid = 2;  */
    if ((strcmp(argv[i],"/EGA") == 0) || (strcmp(argv[i],"/ega") == 0))
        forcevid = 3;
    if ((strcmp(argv[i],"/MCGA") == 0) || (strcmp(argv[i],"/mcga") == 0))
        forcevid = 4;
    if ((strcmp(argv[i],"/VGA") == 0) || (strcmp(argv[i],"/vga") == 0))
        forcevid = 5;
    if ((strcmp(argv[i],"/LOG") == 0) || (strcmp(argv[i],"/log") == 0))
        logevents = TRUE;
    if ((strcmp(argv[i],"/REPLAY") == 0) || (strcmp(argv[i],"/replay") == 0))
        playevents = TRUE;
    } /* for */

    TUTORcvt_file_name(argv[0],(FileRef FAR *) &ctDir, FARNULL);
    TUTORcopy_fileref_name((FileRef FAR *) &ctDir, (char FAR *) ""); /* strip ct executeable name from path */

    pc_init_mem();  /* initalize memory manager */
    ident87();  /* check for math co-processor */
    _control87(MCW_EM,MCW_EM);  /* suppress coprocessor exceptions */

     /* determine relative speed of this machine */

    tickp = (int FAR *)(0x46cL);
    tickc = 0; /* initialize count */
    i = *tickp; /* get current timer value */
    while (i == *tickp); /* wait for timer to tick */
    i = *tickp; /* get current timer value */
    while (i == *tickp) /* wait for timer to tick again, keeping count */
    tickc++;
    pcv_sndw = (double)tickc*(140.0/13805.0);

    /* save current video mode */

    inr.h.ah = 0x0f; /* get video mode */
    int86(0x10,&inr,&outr);
    vmbios = outr.h.al; /* save original video mode */

    /* determine type of video board and monitor */

    vgaf = egaf = mcgaf = cgaf = FALSE;
    vid.subsystem0 = vid.display0 = 0;
    vid.subsystem1 = vid.display1 = 0;
    videoid(&vid);
    if ((forcevid == 3) && (vid.subsystem0 == 4)) {
    printf("cant select ega mode on mcga\n");
    exit(0);
    } /* forcevid if */

    if (forcevid >= 0)
    vid.subsystem0 = forcevid;

    wmg_px = 640;
    if (vid.subsystem0 == 5) { /* vga */
    vgaf = TRUE;
    inr.h.al = 0x12;    /* 640*480 16 color */
    wmg_py = 480;
    wmg_ncolors = 16;
    } else if (vid.subsystem0 == 4) { /* mcga */
    mcgaf = TRUE;
    inr.h.al = 0x11;    /* 640*480 2 color */
    wmg_py = 480;
    wmg_ncolors = 2;
    pc_inst_mcga(); /* set to use mcga graphics routines */
    } else if (vid.subsystem0 == 3) { /* ega */
    egaf = TRUE;
    wmg_py = 350;
    if (vid.display0 != 1){
        inr.h.al = 0x10; /* 640*350 16 color */
        wmg_ncolors = 16;
    } else {
        inr.h.al = 0x0f; /* 640*350 monochrome */
        wmg_ncolors = 2;
    }
#ifdef Nosuch
    } else if (vid.subsystem0 == 2) {
    cgaf = TRUE;
    inr.h.al = 6; /* 640*200 2 color */
    wmg_py = 200;
    wmg_ncolors = 2;
    pc_inst_cga(); /* install cga routines */
#endif
    } else {
    printf("ega or vga only");
    exit(0);
    }
    inr.h.ah = 0;   /* set video mode */
    int86(0x10,&inr,&outr);

    /* initialize palette registers */

    for(i=0; i<16; i++)
    palette[i] = i; /* values for palette registers */
    palette[16] = 0;    /* set overscan = zblack */
    segread(&segr);
    cp = (char far *)(palette);
    inr.h.ah = 0x10;    /* misc functions */
    inr.h.al = 2;   /* set palette plus overscan */
    inr.x.dx = FP_OFF(cp);
    segr.es = FP_SEG(cp);
    int86x(0x10,&inr,&outr,&segr);

    InitHandles();

    windowsP = (struct tutorwindow FAR *)TUTORalloc(
              (long)(WINDOWLIMIT*sizeof(struct tutorwindow)),TRUE,"win t");

    /* set up colors for drawing of falcon icon (outside of window!) */
    /* we will set up palettes as if window 0 is forward */
    CTinit_color(); /* initialize color (create default cT palette) */
    windowsP[0].palette = HNULL;
    paletteSize = 8;
    nRealColors = (wmg_ncolors < 8) ? wmg_ncolors : 8;
    windowsP[0].nRealColors = nRealColors;
    windowsP[0].paletteSize = 8;
    wmg_palette(0,TRUE); /* make that palette active */

    /* allocate files-open table */

    filesmalloc = 2;
    filesopen = TUTORhandle("files  ",(long)(filesmalloc*sizeof(struct tutorfile)),FALSE);
    tfp = (struct tutorfile FAR *) GetPtr(filesopen);
    tfp->inuse = (tfp+1)->inuse = FALSE;
    ReleasePtr(filesopen);

    /* set up font using system character bit-maps */

    fsize = sizeof(struct pcfont)+256*sizeof(struct pcchars);
    sysfonth = TUTORhandle("sysfont",fsize,TRUE);
    sysfont = (struct pcfont FAR *)GetPtr(sysfonth);
    cp = (char FAR *)sysfont;
    sysfont->rmap = sysfont_addr();  /* pointer to bit maps for font */
    sysfont->rdef = cp+sizeof(struct pcfont);
    sysdef = (struct pcchars FAR *)sysfont->rdef;
    sysfont->dmap = 0;   /* bit maps not within font */
    sysfont->ddef = sizeof(struct pcfont); /* defs are within font */
    strcpyf(sysfont->family,(char FAR *)"system");
    sysfont->first = 0;
    sysfont->nchars = 255;
    sysfont->newline = sysfont_chrh();
    sysfont->ascent = 13;
    sysfont->descent = 4;
    sysfont->maxwidth = 12;
    sysfont->size = 10;
    sysfont->dstyle = 0; /* plain */
    sysfont->astyle = 0; /* can't generate bold, italic, underline */
    sysfont->format = 0; /* small defs, character font */
    for(i=0; i<256; i++) {
    chrdef = sysdef+i;
    chrdef->map = sysfont->newline*i;
    chrdef->pdx = 8;    /* x increment always 8 */
    chrdef->pdy = 0;    /* y increment always 0 */
    chrdef->bndx = 0;
    chrdef->bndy = -sysfont->ascent;
    chrdef->bnw = 8;
    chrdef->bnh = sysfont->newline;
    chrdef->mapdx = chrdef->mapdy = 0;
    chrdef->mapw = 8;
    chrdef->maph = sysfont->newline;
    } /* for */
    ReleasePtr(sysfonth); /* release system font */

    wmg_font((long)sysfonth); /* select system font */
    wmg_wipe();
    pd_barheight = wmFont->ascent+wmFont->descent;
    CTset_foreground_color(color_defaultf);
    CTset_background_color(color_defaultb);

    /* interrogate to see if mouse present */

    nmouseb = buttonmsk = mouses = 0;
    mouseqo = mousef = 0;
    mouseld = mouserd = -1;
    inr.x.ax = 0;
    i = int86(0x33,&inr,&outr);
    if ((int)outr.x.ax == -1) {
    mousef = TRUE; /* mouse present */
    nmouseb = outr.x.bx;
    for(i=0; i<nmouseb; i++)
        buttonmsk |= (1 << i);
    } /* ax if */

    /* initializations for hardware mouse */

    if (mousef) {

    /* save initial mouse status */

    inr.x.ax = 21;  /* get storage requirements */
    i = int86(0x33,&inr,&outr);
    mousestat = TUTORalloc((long)outr.x.bx+2,TRUE,"mouse");
    segread(&segr);
    inr.x.ax = 22;  /* save mouse status */
    inr.x.dx = FP_OFF(mousestat);
    segr.es = FP_SEG(mousestat);
    i = int86x(0x33,&inr,&outr,&segr);

    /* set user defined subroutine for mouse events */

    segread(&segr);
    inr.x.ax = 12;      /* set user-defined subroutine */
    inr.x.cx = 0x7f;    /* trap all conditions */
    cp = (char FAR *)(pc_mouse_drv);
    inr.x.dx = FP_OFF(cp);
    segr.es = FP_SEG(cp);
    i = int86x(0x33,&inr,&outr,&segr);

    /* set initial mouse position */

    inr.x.ax = 4;
    inr.x.cx = 640/2;
    inr.x.dx = 300;
    i = int86(0x33,&inr,&outr);

    /* expose mouse cursor */

    inr.x.ax = 1;
    i = int86(0x33,&inr,&outr);
    } /* mousef if */

    /* install critical error handler for ct */
    /* (suppresses "Abort, Retry, Ignore, Fail?" handler) */

    pc_crit_init();

    /* plot falcon icon */

    pc_on(); /* insure graphics on */
    pc_clip(0,0,wmg_px,wmg_py); /* allow full screen */
    fontptr = NULL; /* pre-set no falcon font */
    if (ctedit) {
	TUTORcopy_fileref((FileRef FAR *) &fname,(FileRef FAR *) &ctDir);
	if (vid.subsystem0 == 2)
	    TUTORcopy_fileref_name((FileRef FAR *) &fname,(char FAR *) "physacc.fpc");
	else
	    TUTORcopy_fileref_name((FileRef FAR *) &fname,(char FAR *) "physacc.fpc");
	fontfi = TUTORopen((FileRef FAR *) &fname,TRUE,FALSE,FALSE);
	if (fontfi) {

	    /* determine size of font file */

	    TUTORinq_file_info((FileRef FAR *) &fname,NEARNULL,&fsize,NEARNULL,NEARNULL,NEARNULL);

	    /* allocate memory and read font from disk */

	    fontptr = (struct pcfont far *)TUTORalloc((long)fsize,TRUE,"falcon");
	    i = TUTORread((char FAR *)fontptr,1,(long)fsize,fontfi);
	    TUTORclose(fontfi);
	    if ((i != fsize) || (fsize == 0)) {
		TUTORdealloc((char FAR *)fontptr);
		fontptr = NULL;
	    }
	} /* fontfi if */

	/* set up font and display falcon icon */

	if (fontptr) {

	    /* set up pointers within font */

	    cp = (char far *)(fontptr);
	    fontptr->rdef = cp+fontptr->ddef;
	    fontptr->rmap = cp+fontptr->dmap;
	    pc_font(fontptr); /* select as current font */

	    /* display icon */

	    wmg_color(color_white,color_black);
	    pc_mode(3); /* mode inverse */
	    if (vid.subsystem0 == 2) pc_char(72,2,'!');
	    else pc_char(72,32,'!');
	    pc_mode(0); /* mode write */
	    pc_off(); /* disable drawing till inits finished */

	    /* release memory */

	    TUTORdealloc((char FAR *)fontptr);
	} /* fontptr if */
    } /* ctedit if */

    /* read code-page conversion table for current code page */

    inr.x.ax = 0x6601; /* get active code page */
    int86(0x21,&inr,&outr);
    if (outr.x.cflag)
	outr.x.bx = 437; /* default to english */
    sprintf(codepn,"code%d.pag",outr.x.bx); /* form file name */
    TUTORcopy_fileref((FileRef FAR *) &fname,(FileRef FAR *) &ctDir);
    TUTORcopy_fileref_name((FileRef FAR *) &fname,(char FAR *) codepn);
    codefi = TUTORopen((FileRef FAR *) &fname,TRUE,FALSE,FALSE);
    if (codefi) {

	/* read code page data from disk */

	fsize = TUTORread((char FAR *)pc2ct,1,128L,codefi);
	i = TUTORread((char FAR *)ct2pc,1,128L,codefi);
	TUTORclose(codefi);
	if ((i != fsize) || (fsize != 128))
	    codefi = 0; /* didn't work */
    } /* codefi if */
    if (!codefi) { /* zero conversion tables if no code page data */
	for(i=0; i<128; i++)
	    ct2pc[i] = pc2ct[i] = 0;
    }

} /* igraphpc */

/* ******************************************************************* */

int start_executor() /* post event to begin execution */

{   struct tutorevent event;

    TUTORpoll_events(FALSE); /* allow initial redraws into que */
    event.type = EVENT_MSG;
    event.window = ExecWn;
    event.dp = FARNULL;
    event.value = event.id = event.timestamp = 0;
    event.view = ExecVp;
    event.a1 = exec_run;
    TUTORpost_event(&event);

} /* start executor */

/* ******************************************************************* */

TUTORstartup(argc,argv,filenameR)
int argc;
char **argv; 
FileRef FAR *filenameR;

{   char **a;
    char *c;
    char FAR *cf;
    int i, j; /* work variables */
    FileRef cwd; /* path to current directory */
    FileRef filen; /* file name */
    double yy;
    unsigned int curDrive;

    /* initialization of variables altered by command line options */

    nosourcelayout = 0;
    lforkf = FALSE;
    twf = FALSE;        /* turn off trace window debug stuff */
    spyf = FALSE;       /* turn off profiling */
    codegen = TRUE;     /* default is compiled codes */

    pd_init();
    if (ctedit) /* check if editor present */
    pd_wmctrlw = 10; /* width of window-control button */

    /* set up FileRef for current working directory */

    _dos_getdrive(&curDrive);
    cwd.drive = curDrive;
    getcwd(cwd.path,FILEL);
    if (cwd.path[1] == ':')
    strcpy(cwd.path,cwd.path+2); /* get rid of drive specifier */
    i = strlen(cwd.path);
    if (cwd.path[i-1] != '\\') { /* path should terminate with \ */
    cwd.path[i] = '\\';
    i++; /* adjust length */
    cwd.path[i] = '\0'; /* insure null termination */
    }
    cwd.nameInd = i;

    /* set up FileRef for source file */

    TUTORcopy_fileref(filenameR,(FileRef FAR *) &cwd);
    TUTORcopy_fileref_name(filenameR, (char FAR *) "untitled.t"); /* the default */
    if (argc > 1)
    for (a = argv + 1, i = argc; --i; a++) {
        j = **a;
        if ((j != '-') && (j != '+') && (j != '/'))
        TUTORcvt_file_name(*a,filenameR,(FileRef FAR *) &cwd);
    } /* for */

    /* sourceDir and currentDir are both set to where source was found */
    TUTORcopy_fileref_dir((FileRef FAR *) &sourceDir, filenameR);
    TUTORcopy_fileref_dir((FileRef FAR *) &currentDir, filenameR);

} /* TUTORstartup */

/* ******************************************************************* */

TUTORclose_copyright() /* clear copyright notice early */
    { ; }

/* ******************************************************************* */

TUTORdone_startup() /* finish startup tasks */

{
    /* clear copyright notice would be here */
}

/* ******************************************************************* */

#ifdef TURBOC

pc_init_mem()

{   int ii;
    struct memhdr FAR *memp;
    struct memhdr FAR *memp2;
    union REGS inr, outr;
    long meml, low, high, templ;
    long totalm; /* total memory found */
    long timeri;
    int emsov,xmsov; /* ems/xms overlay use flags */

    if ((long)basememp) return; /* exit if memory already set up */

    meml = farcoreleft(); /* find out how much */
    meml -= 2048; /* leave a bit unallocated */
    basememp = (struct memhdr FAR *)farcalloc(1L,meml);
    if (basememp == FARNULL) {
    printf("initial memory allocation failed\n");
    exit(0);
    }
    totalm = mem_conv = meml;
    low = membase[0] = pc_pl((char FAR *)basememp);
    high = low + meml;
    TUTORset((char FAR *)basememp, meml, 0x0);
    basememp->used = 0;
    basememp->length = meml - sizeof(struct memhdr);
    basememp->handle = 0;
#ifdef MEMLABEL
    basememp->label[0] = '\0';
#endif
    templ = pc_pl((char FAR *)basememp) + basememp->length;
    memp = (struct memhdr FAR *)pc_lp(templ);
    memp->used = TRUE;
    memp->length = 0;
    memp->handle = 0;
#ifdef MEMLABEL
    memp->label[0] = '\0';
#endif
    origmem = high - low;

#ifdef Nosuchz
    if (emsov == 0) printf("overlays in EMS\n");
    if (xmsov == 0) printf("overlays in XMS\n");
    printf("initial memory found %ld\n",totalm);
    printf("base address: %lx\n",(long)basememp);
    printf("remaining free: %lx\n",(long)farcoreleft());
    timeri = TUTORinq_msec_clock();
    while ((TUTORinq_msec_clock()-timeri) < 3000L);
#endif

} /* pc_init_mem */

#endif /* turboc */

/* ******************************************************************* */

#ifdef MSC
pc_init_mem()

{   int ii;
    struct memhdr FAR *memp;
    struct memhdr FAR *memp2;
    union REGS inr, outr;
    long meml, low, high, templ;
    long totalm; /* total memory found */

    if ((long)basememp) return; /* exit if already set up */

    /* by requesting too much, we get back how much is really there */

    inr.h.ah = 0x48;        /* allocate memory */
    inr.x.bx = 0x7ffff;    /* number of 64 byte chunks */
    intdos(&inr, &outr);
    if (!outr.x.cflag || (outr.x.bx < 1000)) {
    printf("Insufficient memory to run.\n");
    exit(0);
    }
    inr.x.bx = outr.x.bx - 128; /* leave 2K */
    meml = (long)inr.x.bx * 16L; /* convert bytes */
    intdos(&inr, &outr);
    if (outr.x.cflag) {
    printf("Initial memory allocation failed: %ld\n", meml);
    exit(0);
    }
    totalm = meml;
    setfptr((int FAR *)&basememp, outr.x.ax, 0);
    low = membase[0] = pc_pl((char FAR *)basememp);
    high = low + meml;
    TUTORset((char FAR *)basememp, meml, 0x0);
    basememp->used = 0;
    basememp->length = meml - sizeof(struct memhdr);
    basememp->handle = 0;
#ifdef MEMLABEL
    basememp->label[0] = '\0';
#endif
    templ = pc_pl((char FAR *)basememp) + basememp->length;
    memp = (struct memhdr FAR *)pc_lp(templ);
    memp->used = TRUE;
    memp->length = 0;
    memp->handle = 0;
#ifdef MEMLABEL
    memp->label[0] = '\0';
#endif

    for (ii = 1; ii < 4; ii++) {
    inr.x.bx = 0x7ffff;
    intdos(&inr, &outr);
    if (!outr.x.cflag || (outr.x.bx < 256))
        break;
    inr.x.bx = outr.x.bx - 128;
    meml = (long)inr.x.bx * 16L;
    intdos(&inr, &outr);
    if (outr.x.cflag)
        break;
    totalm += meml; /* accumulate total memory found */
    setfptr((int FAR *)&memp, outr.x.ax, 0);
    membase[ii] = pc_pl((char FAR *)memp);
    TUTORset((char FAR *)basememp, meml, 0x0);
    memp->used = 0;
    memp->length = meml - sizeof(struct memhdr);
    memp->handle = 0;
#ifdef MEMLABEL
    memp->label[0] = '\0';
#endif
    templ = pc_pl((char FAR *)memp) + memp->length;
    memp = (struct memhdr FAR *)pc_lp(templ);
    memp->used = TRUE;
    memp->length = 0;
    memp->handle = 0;
#ifdef MEMLABEL
    memp->label[0] = '\0';
#endif
    /* make the new segment of memory appear continuous with the rest */
    if (membase[ii] < low) { /* add to the front */
        memp->length = pc_pl((char FAR *)basememp) - pc_pl((char FAR *)memp) - sizeof(struct memhdr);
        basememp = (struct memhdr FAR *)pc_lp(templ);
    } else if (membase[ii] > high) {  /* add to the back */
        templ = pc_pl((char FAR *)basememp) + basememp->length;
        memp = (struct memhdr FAR *)pc_lp(templ);
        memp->length = membase[ii] - pc_pl((char FAR *)memp) - sizeof(struct memhdr);
    } else {  /* insert into the middle */
        templ = membase[ii];
        memp = (struct memhdr FAR *)pc_lp(templ);
        for (memp2 = basememp; /* move down the mem segment */
          pc_pl((char FAR *)memp2)+memp2->length < pc_pl((char FAR *)memp);
        memp = (struct memhdr FAR *)pc_lp(pc_pl((char FAR *)memp)+memp->length));
        if (memp2->used == 0) {
        printf("Memory corruption in init_mem()\n");
        exit(0);
        }
        meml = memp2->length;
        memp2->length = pc_pl((char FAR *)memp) - pc_pl((char FAR *)memp2) - sizeof(struct memhdr);
        templ = pc_pl((char FAR *)memp) + memp->length;
        memp = (struct memhdr FAR *)pc_lp(templ);
        templ = pc_pl((char FAR *)memp2) + meml;
        memp->length = templ - pc_pl((char FAR *)memp) - sizeof(struct memhdr);
    } /* high/low else */
    } /* for */
    origmem = high - low;
/* debug - dma */
{   long timeri;

    printf("initial memory found %ld\n",totalm);
    timeri = TUTORinq_msec_clock();
    while ((TUTORinq_msec_clock()-timeri) < 3000L);
}
/* end debug */
} /* pc_init_mem */

#endif /* msc */

/* ******************************************************************* */

InitHandles()    /* initialize handle memory management */
    
{   int ii; /* index in table */
    struct htab FAR *hp;

    if (hmalloc) return(0); /* already initialized */
    hmalloc = NMEMSTART;    /* initialize memory management table */
    htabp = (struct htab FAR *)
    TUTORalloc((long)(sizeof(struct htab)*hmalloc),TRUE,"htab");
    for (ii=0, hp=htabp; ii<hmalloc; ii++, hp++) {
        hp->area = (char FAR *) -1L; /* handle not in use */
        hp->size = 0;
        hp->lockcount = hp->lastref = 0;
        hp->purge = 0;
#ifdef MEMLABEL
        hp->label[0] = '\0';
#endif
    } /* for */

    /* want 0th entry to never be used so that a Memh of zero indicates no handle */
    htabp[0].area = (char FAR *) 7L; /* will cause address error if used */
    mLowest = 1; /* begin to look for empty spots at entry 1 */

} /* InitHandles */

/* ******************************************************************* */
#ifdef NosUch
pc_mem_map()    /* dump memory map to file */

{   FILE *fp;
    FileRef mapname; /* map file name */
    struct memhdr FAR *memp;    /* pointer to area header */
    struct htab FAR *hp;    /* pointer to handle table entry */
    char hlabel[10]; /* handle label */
    long lp;    /* long for pointer arithmetic */
    long lw;
    unsigned int curDrive, nDrives;
    int ii,jj;

    /* build map file name */

    assoc_name(&sourcetable[0].fRef,(FileRef FAR *) &mapname,".map");

    /* open map file */

    _dos_getdrive(&curDrive);
    _dos_setdrive((unsigned int) mapname.drive,&nDrives);
    fp = fopen(mapname.path,"w");
    _dos_setdrive(curDrive,&nDrives); /* restore drive */
    if (fp == NULL) return(0);

    fprintf(fp,"memory map of %s\n",strf2n(sourcetable[0].fRef.path));

    strncpyf(hlabel,lastlabel,8);
    hlabel[9] = '\0';
    if ((hlabel[0] > 'z') || (hlabel[0] < 'a'))
    hlabel[0] = '\0';
    fprintf(fp,"lastptr: %lx lastsize: %lx  %s\n",lastptr,lastsize,hlabel);

    memp = basememp; /* begin at start of memory */
    while (memp->length) {
    if (memp->handle) {
        hp = pc_htab(memp->handle);
        strncpyf((char FAR *)hlabel,hp->label,8);
        hlabel[8] = '\0';
        fprintf(fp,"%8lx %8lx %1d %4x %2d %2x %8lx %s\n",(long)memp,memp->length,
            memp->used,memp->handle,hp->lockcount,hp->purge,
            (long)hp->lastref,hlabel);
    } else {
#ifdef MEMLABEL
        strncpyf((char FAR *)hlabel,memp->label,8);
#else
        hlabel[0] = '\0';
#endif
        hlabel[8] = '\0';
        fprintf(fp,"%8lx %8lx %1d %s\n",
           (long)memp,memp->length,memp->used,hlabel);
    } /* handle else */
    lp = pc_pl((char FAR *)memp)+memp->length;
    memp = (struct memhdr FAR *)pc_lp(lp);
    } /* while */

#ifdef MEMLABEL
    fprintf(fp,"handle table\n");
    for (ii=1, hp=htabp+1; ii<hmalloc;ii++, hp++) {
    strncpyf((char FAR *)hlabel,hp->label,8);
    hlabel[8] = '\0';
    jj = strlen(hlabel);
    while (jj<8)
        hlabel[jj++] = ' ';
    fprintf(fp,"%3x %s %8lx %8lx\n",ii,hlabel,(long)hp->area,(long)hp->size);
    } /* for */
    fprintf(fp,"\n");
#endif

    fclose(fp);

} /* pc_mem_map */
#endif
/* ******************************************************************* */

mem_msg()

{   long timeri;
    int cfont;
    int xx,yy;
    char msg[256];

    if (!ctedit) return; /* no display for executor */

    xx = 72;
    if (vid.subsystem0 == 2) yy = 2+220;
    else yy = 32+220;

    pc_on(); /* insure graphics on */
    pc_clip(0,0,wmg_px,wmg_py); /* allow full screen */
    cfont = TUTORget_zfont("system",10);
    TUTORset_textfont(cfont);
    TUTORabs_move_to(xx,yy);
    TUTORset_comb_rule(SRC_OR);  /* mode write */
    sprintf(msg,"Mem %ld XMS %ld EMS %ld Swap %ld ",mem_conv,mem_xms,
	    mem_ems,mem_disk);
    TUTORdraw_text((unsigned char FAR *) msg,strlen(msg));
    timeri = TUTORinq_msec_clock();
    while ((TUTORinq_msec_clock()-timeri) < 2000L);

}
