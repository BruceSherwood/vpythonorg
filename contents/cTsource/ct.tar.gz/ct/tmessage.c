/*
A component of the cT (TM) programming environment.
(c) Copyright 1997 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "baseenv.h"
#include "kdefs.h"
#include "editmenu.h"
#include "tutor.h"
#include "editor.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "edglobal.h"
#include "txt.h"
#include "txtv.h"
#include "ct_ctype.h"

/* *************************************************************** */

#ifdef ctproto
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,
 int ebsref,struct  _trect *theR,int  relInfo,int  mintw,int  wrap,
 unsigned int  doc,long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),
 int  ro,int  corner,int  erase,int  frame,int tabsz,int lm,int rm,int inhss,int type);
int  TUTORclose_doc(unsigned int  doc);
int  TUTORset_event_mask(int  eventc,int  value);
int  TUTORset_menubar(unsigned int  barh,struct  tutorview FAR *newMenuView);
unsigned int  TUTORinit_menubar(int  nItems);
int  TUTORadd_menu(unsigned int  barh,char  *card,int  cp,char  *item,int  ip,int  keyBind,int  type,int  unit,double  unitArg,int  eType);
int  RestartPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  selStart,long  selLen);
extern  int TUTORpost_event(struct tutorevent *event);
int  TUTORforward_window(int  wix);
extern int TUTORclose_window(int wid);
int  TUTORclose_view(struct  tutorview FAR *vp);
int  TUTORclose_panel(unsigned int  theV);
extern  int TUTORset_abs_clip_rect(TRect FAR *cr);
extern int TUTORarrow_cursor(int isTemp);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
extern int TUTORclip_window(int wix);
int  TUTORinq_abs_clip_rect(struct  _trect *cr);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,int ebsref,
 struct  _trect *theR,int  relInfo,int  mintw,int  wrap,unsigned int  doc,long  pos,
 long  len,int  wantV,int  wantH,int  (*KeyF)(),int  ro,int  corner,int  erase,
 int  frame,int tabsz,int lm,int rm,int inhss,int type);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
int  EditorDefaultStyles(unsigned int  doc);
int  TUTORclear_doc(unsigned int  doc);
extern int TUTORalert(int wn, char *msg);
extern  struct tutorview FAR *TUTORinit_view(int sW,unsigned int vDat,int (*vProc)());
int  procmsgstub(unsigned int  viewH,struct  tutorevent *event);
int procmsg(Memh editH, struct tutorevent *cev);
int  TUTORcreate_window(int  top,int  left,int  xSize,int  ySize,int  type);
unsigned int  TUTORnew_doc(int  string,int  honorP);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORdealloc(char  FAR *ptr);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
extern TUTORfree_region(long regid);
long TUTORabs_save_region(int x1, int y1, int x2, int y2);
extern char *TUTORget_user(void);
int  TUTORset_comb_rule(int  rule);
extern int fuzzyeq(double x,double y);
extern double lcitof(long lv);
extern double floor(double dv);
extern int TUTOR68030_cache(void);
extern long qroundp(double dv);
extern long lcftoi(double dv);
int  lclocy(long  q);
int  lclocx(long  q);
int  killptr(char  FAR * FAR *ptr);
extern int SetupCTDir(void);
extern FileRef *TUTORct_path(void);
extern int ReleasePtr(Memh mm);
extern int setexectitle(char *sn);
extern int TMessage(char FAR *s);
extern int TMessage(char FAR *s);
extern int TUTORrescale_message(void);
extern int TUTORshowt(double value,int nBefore,int nAfter, int showperiod, char *ss);
extern int TUTORshow(int type,double value, int sigfig, char *ss);
extern int SetFlushState(int arg);
extern int flush(void);
/* extern int signgam(void); */
extern int TUTORzero(char SHUGE *zp, long len);
extern  int TUTORset_file_type(FileRef FAR *fName,int findx,int type,int xx,int yy);
extern int CTset_foreground_color(int color);
extern int CTset_background_color(int color);
extern char *strf2n(char FAR *x);
extern char *strnf2n(char FAR *x,int n);
extern char *strcpyf(char FAR *a,char FAR *b);
extern char *strncpyf(char FAR *a,char FAR *b,int n);
extern char *strcatf(char FAR *a,char FAR *b);
extern int strcmpf(char FAR *a,char FAR *b);
extern int strncmpf(char FAR *a,char FAR *b,int n);
extern int strlenf(char FAR *ss);
extern  int TUTORunset_clip_rectangle(void );
extern int TUTORdump(char *ss);
extern int TUTORset_textfont(int jj);
extern  int TUTORset_view(struct tutorview FAR *vp);
extern  struct tutorview FAR *TUTORinq_view(void );
extern double log(double xx);
extern char FAR *GetPtr(Memh mm);
extern double lcfcoord(double dv);  /* float to float, rounding to nearest integer */
#endif /* ctproto */

extern int procmsgstub();
extern struct tutorview *TUTORinq_view();
extern struct tutorview *TUTORinit_view();

static Memh MsgMenu = HNULL; /* message window menu bar */

/* *************************************************************** */

TMessage(s)
char FAR *s; /* if s exists, the message.  Otherwise close message window */
	
{	int wix;
	struct tutorview FAR *cv; /* current view */
	int info; /* panel alignment */
	TextVDat FAR *vp; /* text panel info */
	long len; /* message length */
	struct tutorevent killEvt; /* event to kill message window */
	
	/* destroy window if no message */
	
	if (!s) {
		if (MsgWn >= 0) {
			TUTORzero((char FAR *)&killEvt,(long)sizeof(struct tutorevent));
			killEvt.window = MsgWn;
			killEvt.type = EVENT_DESTROY;
			TUTORpost_event(&killEvt);
		} /* MsgWn */
		return(0);
	} /* s */
	
	cv = TUTORinq_view();	/* get current view */
	
	/* initialize document, put message in document */
	
	if (!MsgDocH) {
		MsgDocH = TUTORnew_doc(TRUE,TRUE); /* set up document */
		if (!MsgDocH) goto nomem;
		EditorDefaultStyles(MsgDocH);
	}
	TUTORclear_doc(MsgDocH);
	len = strlenf(s);
    InsertString(MsgDocH,0L,(char FAR *)s,len);
	
	/* initialize window, menus, view and text panel if not already */
	/* set up */
	
	if (MsgWn < 0) {
    	MsgWn = TUTORcreate_window(-1,-1,0,0,MESGW);
    	windowsP[MsgWn].wproc = (int(*)())(procmsgstub); 	
    }
    if (MsgWn < 0) goto nomem;
    
    if (!MsgVp) {
        MsgVp = TUTORinit_view(MsgWn,0,procmsgstub);
    	if (!MsgVp) goto nomem;
    }
    TUTORset_view(MsgVp);
    if (!MsgMenu) {
    	MsgMenu = TUTORinit_menubar(3);
    	if (!MsgMenu) goto nomem;
    	TUTORadd_menu(MsgMenu,NIL,10,"Edit Program",60,0,exec_toedit,1,0.0,EVENT_MENU); 
    }
    TUTORset_event_mask(EVENT_LEFTDOWN,TRUE);
    TUTORset_event_mask(EVENT_LEFTUP,TRUE);
    TUTORset_event_mask(EVENT_RIGHTDOWN,TRUE);
    TUTORset_event_mask(EVENT_RIGHTUP,TRUE);
    TUTORset_event_mask(EVENT_DOWNMOVE,TRUE);
    TUTORset_event_mask(EVENT_MENU,TRUE);
    TUTORset_event_mask(EVENT_MSG,TRUE);
    TUTORset_event_mask(EVENT_FWD,TRUE);
    TUTORset_event_mask(EVENT_VFOCUS,TRUE);
    TUTORset_event_mask(EVENT_WFOCUS,TRUE);
    TUTORset_event_mask(EVENT_SCROLL,TRUE);
	TUTORset_event_mask(EVENT_KEY,TRUE);
	TUTORset_event_mask(EVENT_DESTROY,TRUE);
    if (!MsgPanelH) {
    	info = LEFTSTICK | RIGHTSTICK | TOPSTICK | BOTTOMSTICK;
    	MsgPanelH = MakeTextPanel(MsgWn,(long)MsgDocH,0,0,NEARNULL,info,
            100,TRUE,MsgDocH,0L, -1L,TRUE,FALSE,FARNULL,TRUE,FALSE,FALSE,FALSE,
            -1,-1,-1,FALSE,6);
        if (!MsgPanelH) goto nomem;
        vp = (TextVDat FAR *)GetPtr(MsgPanelH);
        TUTORset_menubar(MsgMenu,vp->view);
        ReleasePtr(MsgPanelH);
    }  
    
    /* focus on message window */        
    
    TUTORforward_window(MsgWn); /* focus on message window */
	TUTORarrow_cursor(TRUE);
    
    /* redraw text panel */

	vp = (TextVDat FAR *)GetPtr(MsgPanelH);
	RestartPanel(vp,0L,len,0L,0L);
	ReleasePtr(MsgPanelH);
       	
	TUTORset_view(cv); /* restore view */
	return;
	
nomem:
	if (EditWn[0] >= 0) wix = EditWn[0];
	else wix = ExecWn;
	TUTORalert(wix,"No memory for error message");
	if (s)
		TUTORalert(wix,strf2n(s));
	return;
	
} /* TMessage */
	
/* *************************************************************** */

procmsg(docH,event)   /* event processor for message window */
Memh docH;
struct tutorevent *event; /* event to process */

{   TRect clipR; /* saved clip rectangle */
	TRect eraseR; /* rectangle to erase */
	struct tutorview FAR *viewp; 
	TextVDat FAR *vp; /* text panel info */
	Memh mpH; 

    if (MsgWn < 0) return(0); /* nothing to do */

    /* process message window events */

    switch (event->type) {

    case EVENT_REDRAW:
    	TUTORset_view(MsgVp);
        TUTORinq_abs_clip_rect(&clipR); /* save clip */
		TUTORclip_window(MsgWn); /* clip to entire window */
		eraseR.top = eraseR.left = 0;
		eraseR.bottom = windowsP[MsgWn].wysize;
		eraseR.right = windowsP[MsgWn].wxsize;
        TUTORdraw_abs_solid_rect((TRect FAR *)&eraseR,PAT_BACKGROUND);
        TUTORset_abs_clip_rect((TRect FAR *) &clipR); /* restore clip */
        viewp = windowsP[MsgWn].firstView; /* update everybody else */
        while (viewp) {
        	if (viewp != MsgVp) {
        		TUTORset_view(viewp);
        		(*viewp->vproc) (viewp->vh,event);
        	}
        	viewp = viewp->nextView;
        } /* while */
        event->type = -1;
        break;

    case EVENT_WMKILL: /* window closed by window manager */    
    case EVENT_DESTROY: /* view destroyed */
    	mpH = MsgPanelH;
    	MsgPanelH = HNULL; /* recursive call won't hurt */
    	if (mpH)
			TUTORclose_panel(mpH);
		viewp = MsgVp;
		MsgVp = FARNULL; /* recursive call won't hurt */
		if (viewp)
			TUTORclose_view(viewp);
		if (MsgWn >= 0)
        	TUTORclose_window(MsgWn);
        MsgWn = -1;
        if (MsgDocH)
        	TUTORclose_doc(MsgDocH);
        MsgDocH = HNULL;
        event->type = -1;
        break;
       
    case EVENT_KEY:
        event->type = -1;
    	if (EditWn[0] >= 0) { /* switch to editor */
            TUTORset_view(EditVp[0]); /* set to editor view */
            TUTORforward_window(EditWn[0]);
#ifndef MAC
            TUTORmessage(EditVp[0],EVENT_VFOCUS,TRUE);
            TUTORnormal_cursor();
#endif
		}
    	break;
    	
    case EVENT_MENU:
        event->type = -1;
    	if ((EditWn[0] >= 0) && (event->a1 == exec_toedit)) { /* message->editor transition */
            TUTORset_view(EditVp[0]); /* set to editor view */
            TUTORforward_window(EditWn[0]);
#ifndef MAC
            TUTORmessage(EditVp[0],EVENT_VFOCUS,TRUE);
            TUTORnormal_cursor();
#endif
		}
    	break;
    	
    case EVENT_LEFTDOWN:
    case EVENT_RIGHTDOWN:
    case EVENT_LEFTUP:
    case EVENT_RIGHTUP:
    case EVENT_DOWNMOVE:
    	vp = (TextVDat FAR *)GetPtr(MsgPanelH);
    	ReleasePtr(MsgPanelH);
    	break;
        
    } /* event switch */
    
    /* pass event on to other views if still valid */
    
    if ((MsgWn >= 0) && MsgPanelH && MsgVp && (event->type > 0)) {
        viewp = windowsP[MsgWn].firstView; /* update everybody else */
        while (viewp) {
        	if (viewp != MsgVp) {
        		TUTORset_view(viewp);
        		(*viewp->vproc) (viewp->vh,event);
        	}
        	viewp = viewp->nextView;
        } /* while */
    }
    return(0);
    
} /* procmsg */

/* *************************************************************** */
