
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>
#include <string.h>
#include <memory.h>
#include <Menus.h>
#include <fonts.h>
#include <quickdraw.h>

#include "ctutor.h"
#include "exprdefs.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "ct_ctype.h"
#include "exprdefs.h"
#include "yacc.h"


/* ******************************************************************* */

#ifdef ctproto
int WriteTables(char *fn);
#endif /* ctproto */

/* ******************************************************************* */

#define D 1  /* D for commands which allow blank tags, otherwise T */
#define T 2
#define B 3  /* B for commands which must have blank tags. */
#define C 4  /* C for those that end in a colon (e.g., float:) */
#define EQK 5  /* EQK for those that end in equals (e.g., keys=) */

struct command {
    char name[15];
    int term;
    int code;
}; /* command */

static struct command cmdtable[] = {

"\1\0",B, 0,
"$nocliptext",D,ENVIC,
"$nostylemark",D,ENVIC,
"$oldcolor",D,ENVIC,
"$oldfontsize",D,ENVIC,
"$pcoldcolor",D,ENVIC,
"$syntaxlevel",D,ENVIC,
"$window",D,ENVIC,
"$writewrap",D,ENVIC,
"adddir",T,C_ADDDIR,
"addfile", T, C_ADDFILE,
"alloc",T,C_ALLOC,
"allow", D, C_ALLOW,
"ansv", T, C_ANSV,
"answer", D, C_ANSWER,
"append",T,C_APPEND,
"arrow", D, C_ARROW,
"at", T, C_AT,
"atnm", T, C_ATNM,
"axes", D, C_AXES,
"back", T, C_BACK,
"beep", D, C_BEEP,
"block", T, C_BLOCK,
"bounds", T, C_BOUNDS,
"box", D, C_BOX,
"button", T, C_BUTTON,
"calc", T, C_CALC,

"cancel",D,C_CANCEL,
"case", T, C_CASE,
"circle", T, C_CIRCLE,
"circleb", T, C_CIRCLEB,
"clip", D, C_CLIP,
"clrkey", B, C_CLRKEY,
"cmds", D,C_CMDS,
"coarse", T, C_COARSE,
"color",T,C_COLOR,
"compute", T, C_COMPUTE,
"cursor", D, C_CURSOR,
"datain", T, C_DATAIN,
"dataout", T, C_DATAOUT,
"dde",T,C_DDE,
"define", D, C_DEFINE,
"delfile", T, C_DELFILE,
"delta", T, C_DELTA,
"dialog",T,C_DIALOG,
"disable", T, C_DISABLE,
"disk", T, C_DISK,
"dma",D,C_DMA,
"dmp", D, C_DMP,
"do", T, C_DO,
"dot", T, C_DOT,
"draw", T, C_DRAW,

"edit",T,C_EDIT,
"else", D, C_ELSE,
"elseif", D, C_ELSEIF,
"enable", T, C_ENABLE,
"endarrow", B, C_ENDARROW,
"endcase", B, C_ENDCASE,
"endif", D, C_ENDIF,
"endloop", B, C_ENDLOOP,
"erase", D, C_ERASE,
"eraseu", D, C_ERASEU,
"exact", D, C_EXACT,
"exactw", D, C_EXACTW,
"execute", T, C_EXEC,
"fill", T, C_FILL,
"fine", T, C_FINE,
"finishu", T, C_FINISHU,
"focus", D, C_FOCUS,
"font", D, C_FONT,
"fontp", T, C_FONTP,
"forget", T, C_FORGET,

"garrow", D, C_GARROW,
"gat", T, C_GAT,
"gatnm", T, C_GATNM,
"gbox", D, C_GBOX,
"gbutton",T,C_GBUTTON,
"gcircle", T, C_GCIRCLE,
"gcircleb", T, C_GCIRCLEB,
"gclip", D, C_GCLIP,
"gdisk", T, C_GDISK,
"gdot", T, C_GDOT,
"gdraw", T, C_GDRAW,
"gedit",T,C_GEDIT,
"gerase", T, C_GERASE,
"get",T,C_GET,
"gethsv",T, C_GETHSV,
"getkey", B, C_GETKEY,
"getrgb",T, C_GETRGB,
"getserv",T,C_GETSERV,
"gfill", T, C_GFILL,
"gget",T,C_GGET,
"gmove", T, C_GMOVE,
"gorigin", D, C_GORIGIN,
"gput",T,C_GPUT,
"gslider",T,C_GSLIDER,
"gtext", D, C_GTEXT,
"gtouch",T,C_GTOUCH,
"gvector", T, C_GVECTOR,
"hbar", T, C_HBAR,
"hsv", D, C_HSV,

"iarrow", T, C_IARROW,
"icons", T, C_ICONS,
"if", D, C_IF,
"ifmatch", B, C_IFMATCH,
"ijudge", T, C_IJUDGE,
"imain", T, C_IMAIN,
"inhibit", D, C_INHIBIT,

"judge", D, C_JUDGE,
"jump", T, C_JUMP,
"jumpout", D, C_JUMPOUT,

"labelx", T, C_LABELX,
"labely", T, C_LABELY,

"loop", D, C_LOOP,
"lscalex", T, C_LSCALEX,
"lscaley", T, C_LSCALEY,
"markx", T, C_MARKX,
"marky", T, C_MARKY,
"menu", D, C_MENU,
"mode", T, C_MODE,
"move", T, C_MOVE,
"newline", T, C_NEWLINE,
"newpal", D, C_NEWPAL,
"next", T, C_NEXT,
"no", D, C_NOCMD,
"numout",T,C_NUMOUT,
"ok", D, C_OKCMD,
"outcase", D, C_OUTCASE,
"outif", D, C_OUTIF,
"outloop", D, C_OUTLOOP,
"outunit", D, C_OUTUNIT,
"palette", T, C_PALETTE,
"pattern", D, C_PATTERN,
"pause", D, C_PAUSE,
"pict",D,C_PICT,
"plot", T, C_PLOT,
"polar", D, C_POLAR,
"press", T, C_PRESS,
"print", T,C_PRINT,
"put",T,C_PUT,

"randu", T, C_RANDU,
"rarrow", D, C_RARROW,
"rat", T, C_RAT,
"ratnm", T, C_RATNM,
"rbox", T, C_RBOX,
"rbutton",T,C_RBUTTON,
"rcircle", T, C_RCIRCLE,
"rcircleb", T, C_RCIRCLEB,
"rclip", D, C_RCLIP,
"rdisk", T, C_RDISK,
"rdot", T, C_RDOT,
"rdraw", T, C_RDRAW,
"readln",T,C_READLN,
"redit",T,C_REDIT,
"reloop", D, C_RELOOP,

"replace",T,C_REPLACE,
"rerase", T, C_RERASE,
"rescale", T, C_RESCALE,
"reset", T, C_RESET,
"reshape",T, C_RESHAPE,

"rfill", T, C_RFILL,
"rgb", D, C_RGB,
"rget",T,C_RGET,
"rmove", T, C_RMOVE,
"rorigin", D, C_RORIGIN,
"rotate", D, C_ROTATE,
"rput",T,C_RPUT,
"rslider",T,C_RSLIDER,
"rtext", D, C_RTEXT,
"rtouch",T,C_RTOUCH,
"rvector", T, C_RVECTOR,

"scalex", T, C_SCALEX,
"scaley", T, C_SCALEY,
"serial", T, C_SERIAL,
"server",T,C_SERVER,
"set", T, C_SET,
"setdir", T, C_SETDIR,
"setfile", T, C_SETFILE,

"show", T, C_SHOW,
"showb", T, C_SHOWB,
"showe",T,C_SHOWE,
"showh", T, C_SHOWH,
"showo", T, C_SHOWO,
"showt", T, C_SHOWT,
"showz",T,C_SHOWZ,
"size", D, C_SIZE,
"slider", T, C_SLIDER,
"socket", T, C_SOCKET,
"sound",T,C_SOUND,
"specs", D, C_SPECS,
"sticky",T,C_STICKY,
"string",T,C_STRING,
"style",T,C_STYLE,
"supsub",T,C_SUPSUB,
"sysinfo",T,C_SYSINFO,

"text", D, C_TEXT,
"thick", D, C_THICK,
"touch", T, C_TOUCH,
"unit", T, C_UNIT,
"use", T, USE,
"vbar", T, C_VBAR,
"vector", T, C_VECTOR,
"video",D,C_VIDEO,
"vplay",D,C_VPLAY,
"vset",T,C_VSET,
"vshow",T,C_VSHOW,
"vstep",T,C_VSTEP,
"wcolor",T,C_WCOLOR,
"write", T, C_WRITE,
"wrong", D, C_WRONG,
"wrongv", T, C_WRONGV,
"wtitle",T,C_WTITLE,
"xin", T, C_XIN,
"xout", T, C_XOUT,
"zero", D, C_ZERO,
"zzzzzz\0", B, 0,

};  /* cmdtable */

/* ******************************************************************* */

struct zfctd {			/* reserved function definition */
	char name[12];
	short code;
	short type;
};

/* 0 = retfunct  (FUNCT) */
/* 1 = retcfunct (function code) */
/* 2 = retsys    (SYSVAR) */
/* 3 = iretsys   (ISYSVAR) */
/* 4 = mretsys   (MSYSVAR) */
/* 5 = integer   (ILITERAL) */

static struct zfctd zfcttab[] = {
	"frac", FRAC, 0,
	"int", INT, 0,
	"round", ROUND, 0,
	"sign", SIGN, 0,
	"comp", COMP, 0,
	"bitcnt", BITCNT, 0,
	"zcode", ZCODE, 0,
	"zchar", ZCHAR, 0,
	"zfirst", ZFIRST, 0,
	"zlast", ZLAST, 0,
	"zbase", ZBASE, 0,
	"znext", ZNEXT, 0,
	"zprevious", ZPREVIOUS, 0,
	"zcopy", ZCOPY, 0,
	"zaltered", ZALTERED, 0,
	"zstart", ZSTART, 0,
	"zend", ZEND, 0,
	"zlocate", ZPOSITION, 0,
	"zks",ZKS,0,
	"sin", SIN, 0,
	"cos", COS, 0,
	"tan", TAN, 0,
	"csc", CSC, 0,
	"sec", SECANT, 0,
	"cot", COT, 0,
	"arcsin", ARCSIN, 0,
	"arccos", ARCCOS, 0,
	"arccsc", ARCCSC, 0,
	"arcsec", ARCSEC, 0,
	"arccot", ARCCOT, 0,
	"sqrt", SQRT, 0,
	"abs", ABS, 0,
	"exp", EXP, 0,
	"log", LOG, 0,
	"ln", LN, 0,
	"sinh", SINH, 0,
	"cosh", COSH, 0,
	"tanh", TANH, 0,
	"gamma", GAMMA, 0,
	"alog", ALOG, 0,
	"zeditsel",ZTEXTSEL,0,
	"zeditvis",ZTEXTVIS,0,
	"zedittext",ZEDITBASE,0,
	"zvalue",ZVALUEB,0,
	"zhotinfo",ZHOTINFOE,0,
	"zhotsel",ZHOTSEL,0,
	"znextword",ZNEXTWORD,0,
	"znextline",ZNEXTLINE,0,
	"znumeric",ZNEXTNUM,0,
	"znextexpr",ZNEXTEXPR,0,
	"zfilename",ZFILENAME,0,
	"zfilepath",ZFILEPATH,0,
	"znicons",ZNICONS,0,
	"zswidth",ZSWIDTH,0,
	"zsheight",ZSHEIGHT,0,
	"factorial",ZFACTORIAL,0, 

	"zextent", ZEXTENT, 1,
	"zsamemark", ZSAMEMARK, 1,
	"zprecede", ZPRECEDE, 1,
	"zsearch", ZSEARCH, 1,
	"zsetmark", ZSETMARK, 1,
	"ztextat", ZTEXTAT, 1,
	"arctan", ARCTAN, 1,
	"combin",ZCOMB,1,
	"not", NOT, 1,
	"mod", MOD, 1,
	"zlength", ZLENGTH, 1,
	"zrgbn",ZRGBN,1,
	"zhsvn",ZHSVN,1,
	"zhasstyle",ZHASSTYLE,1,
	"ziconcode",ZICONCODE,1,
	"ziconfile",ZICONFILE,1,

	"zxmin", ZXMIN, 2,
	"zymin", ZYMIN, 2,
	"zxmax", ZXMAX, 2,
	"zymax", ZYMAX, 2,
	"zclock", ZCLOCK, 2,
	"zday", ZDAY, 2,
	"zdblclick",ZDBLCLICK,2,
	"zforeground",ZFORWARD,2,
	"zmode",ZMODE,2,

	"ztouchx", ZTOUCHX, 2,
	"ztouchy", ZTOUCHY, 2,
	"zgtouchx", ZGTOUCHX, 2,
	"zgtouchy", ZGTOUCHY, 2,
	"zrtouchx", ZRTOUCHX, 2,
	"zrtouchy", ZRTOUCHY, 2,
	"zwherex", ZWHEREX, 2,
	"zwherey", ZWHEREY, 2,
	"zvlength", ZVLENGTH, 2,
	"zvtime", ZVTIME, 2,
	"zvplaying", ZVPLAYING, 2,
		
	"zjcount", ZJCOUNT, 3,
	"zdevice", ZDEVICE, 3,
	"zkey", ZKEY, 3,
	"zeditkey", ZEDITKEY, 3,
	"zeditx", ZEDITX, 3,
	"zedity", ZEDITY, 3,
	"zretinf", ZRETINF, 3,
	"zreturn", ZRETURN, 3,
	"zreshape", ZRESHAPE, 3,
	"zjudged", ZJUDGED, 3,
	"zanscnt", ZANSCNT, 3,
	"zcaps", ZCAPS, 3,
	"zentire", ZENTIRE, 3,
	"zextra", ZEXTRA, 3,
	"zntries", ZNTRIES, 3,
	"zopcnt", ZOPCNT, 3,
	"zvarcnt", ZVARCNT, 3,
	"zorder", ZORDER, 3,
	"zspell", ZSPELL, 3,
	"zwcount", ZWCOUNT, 3,
	"zheight", ZHEIGHT, 3,
	"zwidth", ZWIDTH, 3,
	"zxpixels", ZXPIXELS, 3,
	"zypixels", ZYPIXELS, 3,
	"zncolors", ZNCOLORS, 3,
	"zcolorf", ZCOLORF, 3,
	"zcolorb", ZCOLORB, 3,
	"zwcolor", ZWCOLOR, 3,
	"zleftdown", ZLEFTDOWN, 3,
	"zrightdown", ZRIGHTDOWN, 3,
	"zmousex", ZMOUSEX, 2,
	"zmousey", ZMOUSEY, 2,
	"zvwidth", ZVWIDTH, 3,
	"zvheight", ZVHEIGHT, 3,
	"zvcheight", ZVCHEIGHT, 3,

	"zempty", ZEMPTY, 4,
	"zarrowm", ZARROWM, 4,
	"zhomedir", ZHOMEDIR, 4,
	"zcurrentdir", ZCURRENTDIR, 4,
	"zuser", ZUSER, 4,
	"zsans", ZSANS, 4,
	"zserif", ZSERIF, 4,
	"zfixed", ZFIXED, 4,
	"zsymbol", ZSYMBOL, 4,
	"zpatterns", ZPATTERNS, 4,
	"zicons", ZICONS, 4,
	"zcursors", ZCURSORS, 4,
	"zmachine", ZMACHINE, 4,
	"zmainu", ZMAINU, 4,
	"zcurrentu", ZCURRENTU, 4,
	"zarrowsel", ZARROWSEL, 4,
	"zfromprog", ZFROMPROG, 4,
	"zdate", ZDATE, 4,
	"ztime", ZTIME, 4,
	"zclipboard", ZCLIPBOARD, 4,

	"zdefaultb",color_defaultb,5,
	"zdefaultf",color_defaultf,5,
	"zblack", color_black,5,
	"zwhite",color_white,5,
	"zred",2,5,
	"zgreen",3,5,
	"zblue",4,5,
	"zyellow",5,5,
	"zcyan",6,5,
	"zmagenta",7,5,
	"ZBLACK", color_black,5,
	"ZWHITE",color_white,5,
	"ZRED",2,5,
	"ZGREEN",3,5,
	"ZBLUE",4,5,
	"ZYELLOW",5,5,
	"ZCYAN",6,5,
	"ZMAGENTA",7,5,

	"zedit",ZEDIT,6,
	"zslider",ZSLIDER,6,
	"zbutton",ZBUTTON,6,
	"zdde",ZDDE,6,

	"\0", -1, -1,

}; /* zfcttab */


/* ******************************************************************* */

void main(void);

void main()

{   FILE *table;
    int wl,tablel;
  
	/* write command data to file */
	
    table = fopen("commands.tab","wb");
    if (!table) {
		printf("can't create file commands.tab\n");
	/*	exit(1); */
		return;
    }
    tablel = sizeof(cmdtable);
    wl = fwrite(cmdtable,1,tablel,table); /* write next chunk */
    fclose(table);

	/* write functions data to file */
	
    table = fopen("function.tab","wb");
    if (!table) {
		printf("can't create file function.tab\n");
		return;
    }
    tablel = sizeof(zfcttab);
    wl = fwrite(zfcttab,1,tablel,table); /* write next chunk */
    fclose(table);
    
    /* add command + function data to resource forks */
 
#ifdef __MC68K__ 
    WriteTables("ctauthor.68k.�.rsrc");
    WriteTables("ctexec.68k.�.rsrc");
#else
    WriteTables("ctauthor.ppc.�.rsrc");
    WriteTables("ctexec.ppc.�.rsrc"); 
#endif

 	return;
 	
} /* main */

/* ******************************************************************* */

int WriteTables(fileName)
char *fileName;

{	Str255 resFileN;
	int vRefNum; /* reference number for resource fork */
	Handle resH; /* handle on CTcm or CTfn resource */
	long len; /* length of resource data */
	int cii; /* index in resource data */
	char *resP; /* pointer in resource data */
	char *dataP; /* pointer in original data */
	
	
	strcpy((char *)&resFileN[0],fileName);
	CtoPstr((char *)&resFileN[0]);
	vRefNum = OpenResFile(resFileN);
	if (vRefNum == -1)
		return(2); /* failed */
		
	/* add commands resource */
	
	resH = GetResource('CTcm',128);
	if (resH) {
		RemoveResource(resH);
		DisposeHandle(resH);
		len = sizeof(cmdtable);
		resH = NewHandle(len);
		HLock(resH);
		resP = (char *)*resH;
		dataP = (char *)cmdtable;
		for(cii=0; cii<len; cii++) 
			*resP++ = *dataP++;
		HUnlock(resH);
		AddResource(resH,'CTcm',128,"\pCommands");
	}
	
	/* add functions resource */
		
	resH = GetResource('CTfn',128);
	if (resH) {
		RemoveResource(resH);
		DisposeHandle(resH);
		len = sizeof(zfcttab);
		resH = NewHandle(len);
		HLock(resH);
		resP = (char *)*resH;
		dataP = (char *)zfcttab;
		for(cii=0; cii<len; cii++) 
			*resP++ = *dataP++;
		HUnlock(resH);
		AddResource(resH,'CTfn',128,"\pFunctions");
	}
	CloseResFile(vRefNum);
	return(0);
	
} /* WritePalette */

/* ******************************************************************* */

