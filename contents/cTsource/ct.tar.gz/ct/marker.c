
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "baseenv.h"
#include "tutor.h"
#include "txt.h"
#include "compute.h"

#ifdef ctproto
extern int TUTORzero(char SHUGE *ptr,long length);
int  _TUTORinternal_marker(struct  markvar FAR *mp,unsigned int  stackH,long  rloc);
int  _TUTORclose_internal_marker(int  ind);
int  _TUTORinq_state_internal_marker(int  ind,long  *pos,long  *len,int  *altered);
int  _TUTORset_state_internal_marker(int  ind,long  pos,long  len,int  altered);
int  _TUTORupdate_markers_doc(struct  _ktd FAR *dp,long  mpos,long  mlen,long  cpos,long  clen,long  newlen,long  sEnd);
char  FAR *GetPtr(unsigned int  mm);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  TUTORdump(char  *s);
int  mvar_detach_doc2(struct  markvar FAR *mvarP,unsigned int  docH,unsigned char  FAR *stackP,unsigned int  stackH);
int  mvar_attach_doc2(struct  markvar FAR *mvarP,unsigned int  docH,unsigned char  FAR *stackP,unsigned int  stackH);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
#endif /* ctproto */

extern Memh TUTORhandle();

Memh internalMarkers = 0; /* "stack" for internal markers */
static short nMarks;

_TUTORinternal_marker(mpF,markerH,rloc)
struct markvar SHUGE *mpF; /* marker to be put in stack & attached to doc */
			/* needs doc,pos,len,altered,pcode fields set */
Memh markerH; /* handle that marker should be put in (0 if want internal) */
long rloc; /* when markerH != 0, offset from begin of handle to marker variable */
/* for !markerH returns index of marker variable in stack, else returns 0 */
	{
	struct markvar SHUGE *mp;
	register struct markvar SHUGE *mvarP;
	unsigned char SHUGE *arrayP;
	register int ii;
	int retVal;
	
	mp = mpF; /* convert far->huge */
	if (!markerH)
		{ /* get slot for marker in pool of internal markers */
		if (!internalMarkers)
			{
			internalMarkers = TUTORhandle("markstck",(long) sizeof(struct markvar)*20L,TRUE);
			nMarks = 20;
			arrayP = (unsigned char SHUGE *) GetPtr(internalMarkers);
			mvarP = (struct markvar SHUGE *) arrayP;
			for (ii=0; ii<20; ii++, mvarP++)
				mvarP->doc = 0;
			mvarP = (struct markvar SHUGE *) arrayP;
			retVal = 0;
			}
		else
			{
			arrayP = (unsigned char SHUGE *) GetPtr(internalMarkers);
			mvarP = (struct markvar SHUGE *) arrayP;
			for (ii=0; ii<nMarks; ii++, mvarP++)
				if (!mvarP->doc)
					break;
			retVal = ii;
			if (ii >= nMarks)
				{ /* need to allocate more space */
				ReleasePtr(internalMarkers);
				KillPtr(arrayP);
				nMarks += 20;
				TUTORset_hsize(internalMarkers,(long) (sizeof(struct markvar)*((long)nMarks)), TRUE);
				arrayP = (unsigned char SHUGE *) GetPtr(internalMarkers);
				mvarP = ((struct markvar SHUGE *) arrayP) + (nMarks-20);
				for (ii=0; ii<20; ii++,mvarP++)
					TUTORzero((char SHUGE *)mvarP,(long)sizeof(struct markvar));
				mvarP -= 20;
				}
			}
		markerH = internalMarkers;
		}
	else
		{
		arrayP = (unsigned char SHUGE *) GetPtr(markerH);
		mvarP = (struct markvar SHUGE *) (arrayP+rloc);
		retVal = 0;
		}

	*mvarP = *mp;
	mvarP->nextm = mvarP->prevm = -1;
	mvarP->attached = FALSE;
	mvarP->ctvar = FALSE;
	mvar_attach_doc2(mvarP,mp->doc,arrayP,markerH);
	ReleasePtr(markerH);
	KillPtr(arrayP);

	return(retVal);
	}

_TUTORclose_internal_marker(ind)
register int ind;
	{
	register struct markvar SHUGE *mp;
	REGISTER unsigned char SHUGE *stackP;
	
	if (ind < 0)
		TUTORdump("bad index to TUTORclose_internal_marker");
	stackP = (unsigned char SHUGE *) GetPtr(internalMarkers);
	mp = ((struct markvar SHUGE *) stackP) + ind;
	mvar_detach_doc2(mp,mp->doc,stackP,internalMarkers);
	mp->doc = 0;
	ReleasePtr(internalMarkers);
	KillPtr(stackP);
	}

_TUTORinq_state_internal_marker(ind,pos,len,altered)
register int ind; /* index in internal marker stack */
long *pos, *len;
register int *altered;
	{
	REGISTER struct markvar SHUGE *mp;
	
	if (ind < 0)
		TUTORdump("bad index to TUTORclose_internal_marker");
	mp = (struct markvar SHUGE *) GetPtr(internalMarkers);
	mp += ind;
	
	if (pos)
		*pos = mp->pos;
	if (len)
		*len = mp->len;
	if (altered)
		*altered = mp->alteredF & 1;
	ReleasePtr(internalMarkers);
	KillPtr(mp);
	
	return(0);
	}

_TUTORset_state_internal_marker(ind,pos,len,altered)
int ind; /* index in internal marker stack */
long pos, len;
register int altered;
	{
	REGISTER struct markvar SHUGE *mp;
	
	mp = (struct markvar SHUGE *) GetPtr(internalMarkers);
	mp += ind;
	
	if (pos >= 0)
		mp->pos = pos;
	if (len >= 0)
		mp->len = len;
	if (altered >= 0)
		mp->alteredF = (mp->alteredF & 0xfe) | (altered & 1);
	ReleasePtr(internalMarkers);
	KillPtr(mp);
	
	return(0);
	}

_TUTORupdate_markers_doc(dp,mpos,mlen,cpos,clen,newlen,sEnd)
register DocP dp;	/* pointer to text document */
long mpos, mlen;	/* bounds of "marker" getting appended to */
long cpos, clen;	/* bounds of area of change (should be within mpos,mlen) */
register long newlen;	/* # of new chars */
long sEnd;	/* position at end of extra alterations due to styles */
	{
	Memh mStack, oldStack;
	char SHUGE *mStackP;
	register struct markvar SHUGE *mm;
	register long cend;		/* end of the change area */
	register long mnext;
	int altered;
	
	/* note:
		for -append-: mpos/mlen describe the marker getting appended to
				cpos will be mpos+mlen, clen will be 0
		for -replace-: mpos/mlen is the marker being replaced
				cpos will be mpos, clen will be mlen
		
		for operations on a edit textview: mpos/mlen are from the marker on the
				-edit- command.  cpos/clen will be the selection region
	*/

if (!dp->updateM)
TUTORdump("updateM not set?");	
	if (!dp->updateM || dp->headM < 0) 
		return(0); /* this document doesn't update markers, or there are no markers */
	
	/* update affected marker variables */

	mnext = dp->headM; /* rel addr of next marker var */
	mStack = dp->nextHandle;
	cend = cpos+clen;
	mStackP = GetPtr(mStack);
	while (mnext >= 0)
		{
		mm = (struct markvar SHUGE *)(mStackP+mnext);
		mm->doclen = dp->totLen; /* update total length */
		
		altered = FALSE;
		if (newlen)
			{ /* take care of append */
			if ((mm->pos == mpos) && (mm->len == mlen))
				{ /* equivalent markers stay equivalent */
				mm->len += newlen;
				altered = TRUE;
				}
			else if (mm->pos > cend)
				{ /* markers past the append are pushed on */
				mm->pos += newlen;
			} else if ((mm->alteredF & 16) && (mm->pos == cend)) {
				mm->len += newlen;
				mm->pos = cpos;
			} else if ((mm->alteredF & 16) && (mm->pos+mm->len == cpos)) {
				mm->len += newlen;
			} else if (mm->pos == cend &&
					!(cpos == mpos && clen == 0 && mlen > 0))
				{ /* markers that start AT the end of the change are usually
					pushed on.  The only exception is for a zero length change
					region at the beginning of a marker.  This will only happen
					in a text view with the insertion caret at the view begin */
				mm->pos += newlen;
				}
			else if ((mm->pos+mm->len) > cend)
				{
				mm->len += newlen;
				altered = TRUE;
				}
			else if ((mlen > 0) && ((mm->pos+mm->len) == cend))
				{
				mm->len += newlen;
				altered = TRUE;
				}
#ifdef KSWnomore
			else {
				if (((mm->pos+mm->len >= cend && (mm->pos < cend ||
					pFlag && mm->pos == opos))))
					{ /* markers that start before append position and end at or after it are extended */
					mm->len += newlen;
					altered = TRUE;
					}
				else if (mm->pos > cend || (!pFlag && mm->pos == cend))
					{ /* markers that start at or beyond append position are moved */
					/* (in prepend case only markers beyond append position are moved) */
					mm->pos += newlen;
					}
			} /* ctvar else */
#endif
		}
		
		if (clen)
			{ /* take care of deletions (deleting clen chars at cpos) */
			if ((mm->pos+mm->len) <= cpos)
				{ /* deletion past marker */
				; /* no action */
				}
			else if (cend <= mm->pos)
				{ /* deletion completely before marker */
				mm->pos -= clen;
				}
			else if (cpos < mm->pos)
				{ /* del overlaps from below */
				mm->len = (mm->pos + mm->len)-cend;
				if (mm->len < 0)
					mm->len = 0;
				mm->pos = cpos;
				altered = TRUE;
				}
			else if (cend <= mm->pos+mm->len)
				{ /* del within marker */
				mm->len -= clen;
				altered = TRUE;
				}
			else
				{ /* del overlaps marker to above */
				mm->len = cpos - mm->pos;
				altered = TRUE;
				}
			}

		if (dp->styles)
			{ /* take care of alteration due to style changes */
			if (mm->pos < sEnd && mm->pos + mm->len > cpos)
				{
				altered = TRUE;
				}
			}
		
		if (altered)
			{
			mm->alteredF |= 1; /* set altered bit */
			mm->alteredF &= (~4); /* clear unit bit */
			}
		
		mnext = mm->nextm;
		if (mStack != mm->nextstack && mnext >= 0)
			{ /* need to look at a different stack */
			oldStack = mStack;
			mStack = mm->nextstack;
				{
				ReleasePtr(oldStack);
				KillPtr(mStackP);
				mStackP = GetPtr(mStack);
				}
			}
		}
	ReleasePtr(mStack);
	KillPtr(mStackP);

	return(0);
	}

