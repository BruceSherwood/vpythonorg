
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#ifndef _commandsh
#define _commandsh

#define C_MIN 450

/* commands in ctutor1.c */

#define COMMENT 451
#define BLANK 452
#define CMDERR 453
#define ENVIC 454
#define C_DEFINE 455
#define CONTDEFINE 456
#define INDENT 457
#define USE 458
#define DEFINEEND 459
#define UNITSTART 460
#define UNITEND 461
#define C_RAT 462
#define C_RATNM 463
#define C_RDOT 464
#define C_RDRAW 465
#define C_RFILL 466 
#define C_RERASE 467
#define C_GAT 468
#define C_GATNM 469
#define C_GDOT 470
#define C_GDRAW 471
#define C_GFILL 472
#define C_GERASE 473
#define C_HBAR 474
#define C_VBAR 475
#define C_POLAR 476
#define C_RORIGIN 477
#define C_GORIGIN 478
#define C_SCALEX 479
#define C_SCALEY 480
#define C_LSCALEX 481
#define C_LSCALEY 482
#define C_MARKX 483
#define C_MARKY 484
#define C_LABELX 485
#define C_LABELY 486
#define C_SIZE 487
#define C_ROTATE 488
#define C_CIRCLE 489
#define C_RCIRCLE 490
#define C_GCIRCLE 491
#define C_CIRCLEB 492
#define C_RCIRCLEB 493
#define C_GCIRCLEB 494
#define C_BOX 495
#define C_RBOX 496
#define C_GBOX 497
#define C_VECTOR 498
#define C_RVECTOR 499
#define C_GVECTOR 500
#define C_ERASE 501
#define C_AXES 502
#define C_BOUNDS 503
#define C_CLIP 504
#define C_RCLIP 505
#define C_GCLIP 506
#define C_DISK 507
#define C_VSTEP 508
#define C_VSHOW 509
#define C_RDISK 510
#define C_GDISK 511
#define C_DELTA 512
#define C_FONT 513
#define C_PATTERN 514
#define C_CURSOR 515
#define C_ICONS 516
#define C_EXEC 517
#define C_ADDFILE 518
#define C_SETFILE 519
#define C_DELFILE 520
#define C_RESET 521
#define C_XIN 522
#define C_XOUT 523
#define C_DATAOUT 524
#define C_DATAIN 525
#define C_NUMOUT 526
#define C_READLN 527
#define C_COND 528
#define C_CONDEND 529
#define C_CONDDONE 530
#define C_UNIT 531
#define C_DEFINEEND 532
#define C_CASE 533
#define C_CLAUSE 534
#define C_ENDCLAUSE 535 
#define C_ENDCASE 536
#define C_AT 537
#define C_ATNM 538
#define C_FILL 539
#define C_DOT 540
#define C_DRAW 541
#define C_CONDOUT 542
#define C_CASEM 543
#define C_CASET 544
#define C_ERASEP 545
#define C_TOUCH 546
#define C_RTOUCH 547
#define C_GTOUCH 548
#define C_BUTTON 549
#define C_RBUTTON 550
#define C_GBUTTON 551
#define C_SLIDER 552
#define C_RSLIDER 553
#define C_GSLIDER 554
#define C_EDIT 555
#define C_REDIT 556
#define C_GEDIT 557
#define C_BUTTONR 558
#define C_RBUTTONR 559
#define C_GBUTTONR 560
#define C_SLIDERR 561
#define C_RSLIDERR 562
#define C_GSLIDERR 563
#define C_EDITR 564
#define C_REDITR 565
#define C_GEDITR 566
#define C_CANCEL 567
#define C_FONTP 568
#define C_NEWLINE 569
#define C_SUPSUB 570
#define C_PLOTI 571
#define C_PRINT 572 
#define C_FPALETTE 573
#define C_STEP 574
#define C_STEPOVER 575
#define C_BEGINUNIT 576
#define C_STEPNULL 577  
#define C_VCLOSE 578

/* 578-579 unused */

/* commands in ctutor2.c */

#define C_STRING 580
#define C_APPEND 581
#define C_REPLACE 582
#define C_EXACT 583
#define C_EXACTW 584
#define C_ANSWER 585
#define C_WRONG 586
#define C_ANSV 587
#define C_WRONGV 588
#define C_MENU 589
#define C_ZERO 590
#define C_SET 591
#define C_SERVER 592
#define C_SOCKET 593
#define C_GETSERV 594
#define C_SERIAL 595
#define C_BEEP 596
#define C_COMPUTE 597
#define C_MOVE 598
#define C_RMOVE 599
#define C_GMOVE 600
#define C_PAUSE 601
#define C_IF 602
#define C_ENDIF 603
#define C_ELSE 604
#define C_ELSEIF 605
#define C_OUTIF 606
#define C_OUTCASE 607
#define C_OUTLOOP 608
#define C_RELOOP 609
#define C_LOOP 610 
#define C_ENDLOOP 611
#define C_JUMP 612
#define C_DO 613
#define C_IMAIN 614
#define C_IJUDGE 615
#define C_IARROW 616
#define C_ERASEU 617
#define C_NEXT 618
#define C_BACK 619
#define C_OUTUNIT 620
#define C_DMP 621
#define C_CMDS 622
#define C_SLICE 623
#define C_LBEGIN 624
#define C_LEND 625
#define C_BRANCHT 626
#define C_BRANCHF 627
#define C_BRANCH 628
#define C_ARROW 629
#define C_RARROW 630
#define C_GARROW 631
#define C_IFMATCH 632
#define C_ENDARROW 633
#define C_PREANS 634
#define C_ENDANS 635
#define C_RGB 636
#define C_HSV 637   
#define C_GETRGB 638
#define C_GETHSV 639
#define C_PRESS 640
#define C_CLRKEY 641
#define C_GETKEY 642
#define C_COARSE 643
#define C_RESCALE 644
#define C_COLOR 645
#define C_WCOLOR 646
#define C_CALC 647
#define C_FINE 648
#define C_ENDUNIT 649
#define C_SVERS 650
#define C_ICALC 651
#define C_MCALC 652
#define C_BEGINTEXT 653
#define C_BEGINTEXT1 654
#define C_BEGINTEXT2 655
#define C_BEGINTEXT3 656
#define C_BEGINTEXT4 657
#define C_ENDTEXT1 658
#define C_ENDTEXT2 659
#define C_WRITE1 660
#define C_WRITE2 661
#define C_SETC 662
#define C_ILOOPINIT 663
#define C_ILOOP1INIT 664
#define C_FLOOPINIT 665
#define C_ILOOPINC 666
#define C_ILOOP1 667
#define C_FLOOPINC 668
#define C_ICLOOPINIT 669
#define C_ICLOOPINC 670
#define C_MARKPT 671
#define C_WRAPSTYLE 672
#define C_ARROW1 673
#define C_ARROW2 674
#define C_ARROW3 675
#define C_ZEROM 676
#define C_RESHAPE 677
#define C_FINISHU 678
#define C_JUMPOUT 679
#define C_FOCUS 680
#define C_PALETTE 681
#define C_NEWPAL 682
#define C_RANDU 683
#define C_INHIBIT 684
#define C_ALLOW 685
#define C_SPECS 686
#define C_JUDGE 687
#define C_MODE 688
#define C_VIDEO 689 
#define C_VSET 690
#define C_VPLAY 691
#define C_OKCMD 692
#define C_NOCMD 693
#define C_ENABLE 694
#define C_DISABLE 695
#define C_SHOW 696
#define C_SHOWT 697
#define C_SHOWB 698 
#define C_SHOWO 699
#define C_SHOWH 700
#define C_WRITE 701
#define C_ENDTEXT 702
#define C_PLOT 703
#define C_TEXT 704
#define C_RTEXT 705
#define C_GTEXT 706
#define C_TEXTM 707
#define C_RTEXTM 708
#define C_GTEXTM 709
#define C_OBJW 710
#define C_VWAIT 711
#define C_SOCKWAIT 712
#define C_DDE 713
#define C_WTITLE 714

/* commands in ctutor3.c */

#define C_STYLE 715
#define C_FILESEL 716
#define C_HOT 717
#define C_GET 718
#define C_PUT 719
#define C_RGET 720
#define C_RPUT 721
#define C_GGET 722
#define C_GPUT 723
#define C_SOUND 724
#define C_ALLOC 725
#define C_PICT 726
#define C_SHOWZ 727
#define C_SHOWE 728
#define C_FORGET 729
#define C_BLOCK 730
#define C_THICK 731
#define C_DMA 732
#define C_SYSINFO 733
#define C_DIALOG 734
#define C_STICKY 735
#define C_SETDIR 736
#define C_ADDDIR 737
#define C_DELDIR 738
#define C_GETDIR 739
#define C_WEBPAL 740

#define C_MAX 742


/* non-command tokens */

#define CLEAR 0 /* for specs and similar commands */

#define NOMARK 1 /* for specs */
#define NOOKNO 2
#define NOOPS 3
#define NOSPELL 4
#define OKCAP 5
#define OKEXTRA 6
#define OKSPELL 7
#define PUNC 8
#define NOORDER 9
#define NOVARS 10
#define OKASSIGN 11

#define INHERASE 1
#define INHARROW 2
#define INHANSERASE 3
#define INHBLANKS 4
#define INHJKEYS 5
#define INHDISPLAY 6
#define INHSTARTDRAW 7
#define INHUPDATE 8
#define INHSUPSUB 9
/* 10 unused */
#define INHOBJDEL 11
#define INHDEGREE 12
#define INHOPTION 13
#define INHBFONT 14
#define INHOBJECT 15
#define INHEDITD 16
#define INHFUZZY 17

#define TLDOWN 1 /* touch left: down */
#define TLUP 2
#define TLMOVE 3
#define TRDOWN 4
#define TRUP 5
#define TRMOVE 6
#define ENABLEEXT 7
#define TLDOUBLE 8
#define TRDOUBLE 9
#define TUPMOVE 10

#define UNITX 4095 /* fallthru unit x, as in do expr,A,x,B */

#endif /* _commandsh */
