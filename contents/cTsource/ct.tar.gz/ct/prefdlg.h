/*
A component of the cT (TM) programming environment.
(c) Copyright 1994 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

struct PrefRec {
	char prefID[10]; /* identifying string */
    char fontFamily[64]; /* default editor font family */
    int fontSize; /* editor font size */
    int fontFace; /* editor font face */
    int nTabs; /* editor spaces/tab */
    int fcolor; /* editor foreground color */
    int bcolor; /* editor background color */
    int snapShot; /* execute window snapshot flag */
    char swapPath[CTPATHLEN+2]; /* path to swap file */
    long swapSize; /* max size of swap fie */
    long checkTime; /* checkpoint frequency */
    int dos_hcolor;       /* (DOS) highlight color */
    char dos_printer[10]; /* (DOS) printer name */
    int dos_sbint;        /* (DOS) SoundBlaster interrupt */
    int dos_sbport;       /* (DOS) SoundBlaster I/O port */
	char unix_printer[40]; /* (UNIX) print command */
    int winSaveOnExit; /* TRUE if should save window settings on exit */
    int winSet; /* window settings present flag */
    int axx; /* author window X position */
    int aWidth; /* author window width */
    int ayy; /* author window Y position */
    int aHeight; /* author window height */
    int exx; /* execute window X position */
    int eWidth; /* execute window width */
    int eyy; /* execute window Y position */
    int eHeight; /* execute window height */
    char zzscr[200]; /* future expansion */
}; 
