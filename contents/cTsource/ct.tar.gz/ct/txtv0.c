
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "baseenv.h"
#include "txt.h"
#include "txtv.h"
#include "tutor.h"
#include "editor.h"
#include "kdefs.h"

#ifdef ctproto
extern void TUTORset_color(int select,struct tutorColor FAR *newColor);
long  TUTORget_len_doc(unsigned int  doc);
struct  tutorview FAR *TUTORinq_view(void);
extern int TUTORzero(char SHUGE *ptr,long lth);
unsigned int  TUTORnew_tview(struct  tutorview FAR *ownerV,unsigned int  doc,long  pos,long  len,
struct  _trect FAR *vRect,int  style,int  dWidth,int  wordWrap,int inhss);
int  TUTORclose_tview(unsigned int  theV);
int  TUTORupdate_tview(unsigned int  theV);
int  TUTORresize_tview(unsigned int  theV,struct  _trect FAR *vRect,int  dWidth,struct  _sbarinf *sbv,struct  _sbarinf *sbh);
int  _TUTORdraw_tview(struct  _viewp FAR *tvp,int  startL,int  endL);
int  TUTORchange_tview(unsigned int  theV,long  pos,long  len,long  rpos,long  rlen,long  newC,long  selS,long  selL,struct  _sbarinf *vb,int force);
extern long  ChangePos(long  pos,long  rpos,long  rlen,long  newC,int bStick);
extern int  ResetView(unsigned int  theV,long  pos,long  selS,long  selL,struct  _sbarinf *vb);
extern int  ChangeSelect(unsigned int  theV,long  selS,long  selL);
extern int  SelectVisibleTView(struct  _viewp FAR *tvp,int  *shortScroll);
extern int  FastOk(struct  _viewp FAR *tvp,int  line,long  pos);
extern int  SetupSomeLines(unsigned int  theV,struct  _viewp FAR *tvp,long  *pos,long  *len,int  startLine,int  endLine,int  *height,int  *heightNew);
extern int  _TUTORpartial_layout(struct  _viewp FAR *tvp,long  pos,long  len,unsigned int  *layoutH);
int  TUTORinq_select_tview(unsigned int  theV,long  *pos,long  *len);
int  _TUTORlayout_lines0(unsigned int  theV,long  pos,int  height,int  redo);
extern long  AdjustStart(struct  _viewp FAR *tvp,long  startPos);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
long  _TUTORline_pos_tview(struct  _viewp FAR *tvp,int  lineN);
char  FAR *GetPtr(unsigned int  mm);
int  _TUTORhilite_select(unsigned int  theV,int  onoff);
int  TUTORfree_handle(unsigned int  mm);
int  mvar_detach_doc2(struct  markvar FAR *mvarP,unsigned int  docH,unsigned char  FAR *stackP,unsigned int  stackH);
int  TUTORwhere_pix_tview(unsigned int  theV,struct  _ps FAR *posp);
int  _TUTORinternal_marker(struct  markvar FAR *mp,unsigned int  stackH,long  rloc);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORdump(char  *s);
int  TUTORdraw_doc(unsigned int  doc,long  pos,long  len,
       struct tutorColor FAR *fc,int  left,int	width,int  height,int  wordB,
       int  nLines,char  FAR *cliLay,int  pStart,int  *lastHeight,int  *maxH,int SupSubAdj);
int  TUTORabs_move_to(int  x,int  y);
int  _TUTORinfo_hbar_tview(struct  _viewp FAR *tvp,struct  _sbarinf *sbh);
int  _TUTORinfo_vbar_tview(struct  _viewp FAR *tvp,struct  _sbarinf *vb);
int  _TUTORnew_bottom_tview(unsigned int  theV,struct  _viewp FAR *tvp);
int  _TUTORshrink_layout_tview(struct  _viewp FAR *tvp,int  newTop,int  newBot);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
int  TUTORscroll_rect(struct  _trect *r,int  dh,int  dv);
int  TUTORdelete_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nDel);
int  TUTORscroll_middleV(unsigned int  theV,long  pos);
int  TUTORcompress_darray(unsigned int  da,int  offset);
int  TUTORdraw0_doc(unsigned int  doc,long  pos,long  len,int  left,struct  _linelay FAR *liLay);
long  _TUTORscrollv_tview(unsigned int  theV,int  stype,long  arg);
int  _TUTORline2_vv_tview(struct  _viewp FAR *tvp,int  nn);
int  TUTORreplace_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  replaceN,int  newN,char  FAR *datP);
int  TUTORinq_comb_rule(void);
int  FindBlockTypeTStyle(struct  _pdt FAR *pp,long  ps,int  type);
int  _TUTORpos2_line_tview(struct  _viewp FAR *tvp,long  pos);
int  _TUTORlayout_lines(struct  _ktd FAR *dp,long  pos,long  len,int  width,int  wordB,int  curX,struct  _pdt FAR *sp,int  styleInd,struct  _linelay FAR *liLay,short  *curStyles,struct  _paral *pLay,struct  _spt2 FAR *stp,int  stind);
int  _TUTORload_buffer_doc(struct  _ktd FAR *dp,long  pos);
int  _TUTORset_textfont_doc(struct  _ktd FAR *dp,short  *curStyles);
int  _TUTORsetup_layout(struct  _ktd FAR *dp,long  pos,long  len,int  *styleInd,struct  _pdt FAR * *styleP,short  *curStyles,struct  _paral *pLay,int  *stind,struct  _spt2 FAR * *stp,int  fillDef);
long  TUTORsearch_string_doc(struct  _ktd FAR *dp,unsigned char  FAR *ss,long  sLen,long  pos,long  posEnd);
int  AtTStyle(unsigned int  pd,long  pos,short  *styles);
#endif /* ctproto */

extern long TUTORget_len_doc();
extern long _TUTORline_pos_tview();
extern long TUTORsearch_string_doc();
extern char FAR *GetPtr();
extern long ChangePos();
long AdjustStart();
struct  tutorview FAR *TUTORinq_view();

extern int SupSubOff;

int VIEWOFFSET;

Memh TUTORnew_tview(ownerV,doc,pos,len,vRect,style,dWidth, wordWrap,inhss)
struct tutorview FAR *ownerV; /* "owning" view - a text panel */
Memh doc; /* document this will be a view of */
long pos,len;   /* bounds of view in doc */
TRect FAR *vRect; /* view rectangle */
int style; /* Mac or AndrewStyle */
int dWidth; /* display width (incl margins) */
int wordWrap;   /* TRUE if we should break lines on word boundaries */
int inhss; /* TRUE if should inhibit sup/sub line height adjustment */
    {
    Memh theV;  /* the new tview to be created */
    REGISTER TViewP tvp;    /* pointer to tview */
    int viewHeight; /* height of tview */
    struct markvar mbounds; /* marker on tview (for creation of internal marker) */
    int supsubH,newlineH; /* subscript/superscript/newline for this view */
    int svSupSubOff;
    
    TUTORzero((char SHUGE *)&mbounds,(long)sizeof(struct markvar));
    theV = TUTORhandle("textview",(long) sizeof(TextView), TRUE);
    if (!theV)
        return(0);
    supsubH = -1; /* default */
    newlineH = 0;
    if (ownerV) {
    	supsubH = ownerV->SupSub;
    	newlineH = ownerV->newlineH;
    }
    
    /* set up view data structure */
    
    tvp = (TViewP) GetPtr(theV);
    TUTORzero((char SHUGE *)tvp,(long)sizeof(TextView));
VIEWOFFSET = ((char SHUGE *) &tvp->nArrays) - ((char FAR *) &tvp->self); /* should be #define */
    tvp->doc = doc;

    mbounds.doc = doc;
    mbounds.pos = pos;
    mbounds.len = len;
    mbounds.alteredF = 0;
	if ((pos <= 0) && (len >= TUTORget_len_doc(doc))) {
		mbounds.alteredF |= 16; /* always include changes at edges */
	}
    _TUTORinternal_marker(&mbounds,theV,
            (long) ((char FAR *) &tvp->bounds - (char FAR *) &tvp->self));
    tvp->layoutTop = tvp->layoutBottom = pos;
    
    tvp->self = theV;
    tvp->ownerV = ownerV;
    
    tvp->viewRect = *vRect;
    tvp->destWidth = dWidth;
    tvp->wrap = wordWrap;
    tvp->vActive = FALSE;
    
    tvp->leftOff = 0;
    tvp->anchor.pos = 0L;
    tvp->anchor.atEnd = FALSE;
    tvp->caretState = FALSE;
    tvp->duringClick = FALSE;
    tvp->hotPos = tvp->hotLen = -1; /* no hot text hit yet */
    tvp->idHot = 0;
    tvp->singleSel = FALSE;
    tvp->highSel = TRUE;
    tvp->dySupSub = supsubH;
    tvp->inhSupSub = inhss;
    tvp->newLine = newlineH;
    
    /* scrollable flags, if TRUE, set to TRUE in MakeTextPanel */
    tvp->scrollH = FALSE;
    tvp->scrollV = FALSE;
    
    
    tvp->noRedraw = FALSE;
    
    tvp->nArrays = 1L;
    tvp->offsets[0] = ((char FAR *) &tvp->txtvH) - ((char FAR *) &tvp->self);
    tvp->totalSize = sizeof(TextView);
    tvp->txtvH.dAnn = 0;
    tvp->txtvH.dAnAlloc = 1;
    tvp->txtvH.nBuff = 20;
    tvp->txtvH.itemSize = sizeof(LineLayout);
    
    /* create linestarts for first page */
    tvp->ld[0].nc = 0;
    tvp->topLine = tvp->botLine = 0;
    viewHeight = tvp->viewRect.bottom - tvp->viewRect.top + 1;
    svSupSubOff = SupSubOff; /* save sup/sub setting */
    SupSubOff = inhss; /* set for this panel */
    ReleasePtr(theV);
    KillPtr(tvp);
    _TUTORlayout_lines0(theV,pos,viewHeight,TRUE);
    SupSubOff = svSupSubOff; /* restore setting */
    /* TUTORupdate_tview(theV); /* draw text of view */

    /* finish setup */
    tvp = (TViewP) GetPtr(theV);
    TUTORwhere_pix_tview(theV,&tvp->anchor);
    tvp->selA = tvp->anchor;
    
    ReleasePtr(theV);
    KillPtr(tvp);
    return(theV);
    }
    

TUTORclose_tview(theV) /* close view (but not doc nor scroll bars) */
Memh theV;  /* tview to be closed */
    {
    REGISTER TViewP tvp;    /* pointer to tview */
    struct markvar SHUGE *mp;   /* pointer to bounds marker */
    
    tvp = (TViewP) GetPtr(theV);
    /* close bounds marker */
    mp = (struct markvar SHUGE *) &(tvp->bounds);
    mvar_detach_doc2(mp,tvp->doc,(unsigned char FAR *) tvp,theV);
    
    ReleasePtr(theV);
    KillPtr(tvp);
    
    _TUTORhilite_select(theV,FALSE);
    TUTORfree_handle(theV);
    }

TUTORupdate_tview(theV) /* draw all the view */
Memh theV;  /* tview to be drawn */
    {
    REGISTER TViewP tvp;    /* pointer to tview */
    
    tvp = (TViewP) GetPtr(theV);

    tvp->caretState = FALSE; /* because view has been erased */
    _TUTORdraw_tview(tvp,tvp->topLine,tvp->botLine);
/* if ((tvp->layoutTop < tvp->bounds.pos) || 
    (tvp->layoutBottom > (tvp->bounds.pos+tvp->bounds.len)))
   TUTORdump("txtv0 1"); */
   if (tvp->layoutTop < tvp->bounds.pos)
   	tvp->layoutTop = tvp->bounds.pos;
   if (tvp->layoutBottom > (tvp->bounds.pos+tvp->bounds.len))
   	tvp->layoutBottom = tvp->bounds.pos+tvp->bounds.len;
    ReleasePtr(theV);
    KillPtr(tvp);
    _TUTORhilite_select(theV,TRUE);
    
    return(0);
    }

TUTORresize_tview(theV,vRect,dWidth,sbv,sbh) /* change the view size */
Memh theV;  /* tview to be resized */
TRect FAR *vRect;   /* new view rect */
int dWidth; /* new destination width */
SBarInfo *sbv;  /* vertical scroll bar info */
SBarInfo *sbh;  /* horizontal scroll bar info */
    {
    REGISTER TViewP tvp;    /* pointer to tview */
    TRect oldRect;  /* view rect before resizing */
    int oldHeight;  /* height of view rect before resizing */
    int newHeight;  /* height of view rect after resizing */
    long pos;   /* starting position of top line of view */
    int ii;
    
    /* Note: only a change in destination width changes the linestarts */
        
    tvp = (TViewP) GetPtr(theV);
    oldHeight = tvp->viewRect.bottom - tvp->viewRect.top + 1;
    
    oldRect = tvp->viewRect;
    tvp->viewRect = *vRect;
    newHeight = tvp->viewRect.bottom - tvp->viewRect.top + 1;
    if (dWidth != tvp->destWidth)
        { /* we will need to layout lines all over again */
        tvp->destWidth = dWidth;
        
        /* layout new lines so that current top position is at, or close to, top */
        pos = _TUTORline_pos_tview(tvp,tvp->topLine);
        ReleasePtr(theV);   
        KillPtr(tvp);   
        _TUTORlayout_lines0(theV,pos,newHeight,TRUE);
        tvp = (TViewP) GetPtr(theV);
        }
    else
        { /* make sure that enough lines are laid out */
        if (newHeight > oldHeight &&
                tvp->layoutBottom < tvp->bounds.pos + tvp->bounds.len)
            { /* layout extra lines */
            pos = tvp->botPos;
            ReleasePtr(theV);
            KillPtr(tvp);
            _TUTORlayout_lines0(theV,pos,newHeight - oldHeight,FALSE);
            tvp = (TViewP) GetPtr(theV);
            }
        _TUTORnew_bottom_tview(HNULL,tvp); /* set new bottom */
        }
    
    /* reset positions */
    TUTORwhere_pix_tview(theV,&tvp->anchor);
    TUTORwhere_pix_tview(theV,&tvp->selA);
    
    /* set scroll info */
    _TUTORinfo_vbar_tview(tvp,sbv);
    _TUTORinfo_hbar_tview(tvp,sbh);
    
    ReleasePtr(theV);
    KillPtr(tvp);
    return(0);
    }

_TUTORdraw_tview(tvp,startL,endL)
register TViewP tvp;    /* pointer to tview */
int startL, endL; /* start & end lines relative to linestarts */
    {
    int nLines; /* # of lines to draw */
    register long pos, len; /* portion of document we want drawn */
    register int ii;
    int penOff; /* distance from the top of view we start pen at */
    register LineLayout FAR *lp;    /* pointer to line layouts */
    
    /* sanity checks */
    if (startL < 0)
        startL = 0;
    if (endL >= tvp->txtvH.dAnn)
        endL = tvp->txtvH.dAnn-1;
    
    nLines = endL - startL + 1;
    if (nLines <= 0)
        return(0); /* nothing to draw */
    
    /* figure out pos & len  && where pen belongs */
    pos = tvp->layoutTop;
    len = 0;
    lp = (LineLayout FAR *) tvp->ld;
    for (ii=0; ii<startL; ii++, lp++)
        pos += lp->nc;
    for (ii=startL; ii<=endL; ii++,lp++)
        len += lp->nc;
    penOff = 0;
    lp = (LineLayout FAR *) tvp->ld + tvp->topLine;
    for (ii=tvp->topLine; ii<startL; ii++, lp++)
        penOff += lp->lineHeight;
    
    TUTORabs_move_to(tvp->viewRect.left+tvp->leftOff,tvp->viewRect.top + penOff);
    lp = (LineLayout FAR *) tvp->ld + startL;
    ii = (startL == 0 || (lp-1)->endNewline); /* is this line start of paragraph? */
    TUTORdraw_doc(tvp->doc,pos,len,&tvp->fColor,tvp->viewRect.left+tvp->leftOff,tvp->destWidth,32767,tvp->wrap,
                    nLines,(char FAR *) lp, ii, NEARNULL,NEARNULL,tvp->inhSupSub);
    
    return(0);
    }

TUTORchange_tview(theV,pos,len,rpos,rlen,newC,selS,selL,vb,force)
Memh theV;  /* tview */
long pos,len; /* the region changed (the WHOLE region) - len is in terms of doc BEFORE change */
long rpos,rlen; /* the region where characters were replaced */
long newC;  /* # of characters added to document */
long selS, selL; /* bounds where selection should end up (if selS < 0, don't move selection) */
SBarInfo *vb;   /* to be set to scroll bar info */
int force; /* TRUE if should force full update */
    {
    REGISTER TViewP tvp;    /* pointer to tview */
    long tempL, tempL2, tempL3;
    long rend;  /* rpos+rlen */
    int startLine;  /* first line effected by change */
    int endLine;    /* last line effected by change */
    int newLines;   /* # of lines just laid out */
    int jj;
    register int ii;
    long del;   /* # of characters a line changes */
    int fillHeight; /* height of tview */
    int height; /* height we have filled so far */
    int heightBefore;   /* height of lines preceeding change */
    int heightOld;  /* total height of lines that are changed (which are discarded) */
    int heightNew;  /* total height of newly laid out lines */
    int heightAfter;    /* height of lines in view after changed lines */
    int oldBottom;  /* -1 if bottom line of view changed, else is old bottom line */
    int curStart;   /* current line we want to start laying out */
    int curEnd;     /* current line we want to stop laying out at */
    int oldBotV;    /* coordinate of bottom of view, before change */
    int nDelLines;  /* # of lines we add due to change */
    int bStick; /* TRUE if begin of view is sticky */
    long cselP; /* current selection position */
    long cselL; /* current selection length */
    TRect tr;   /* rectangle used to erase background */
    long ncPrevOld; /* # of chars in line previous to line of pos
                        (or -1 if start isn't backed up) */
    LineLayout FAR *lp; /* pointer to line layouts */
    int lpinc; /* TRUE if lp incremented */
    long rlpos; /* starting position for re-layout */
    int fullDrawF; /* TRUE if need to do full redraw */
    int delEnd; /* TRUE if delete at end of view */
    long bpos; /* begin of tvp->bounds */
    long bend; /* end of tvp->bounds */
    int topF,bottomF;
    int svSupSub; /* saved superscript / subscript setting */
    
    tvp = (TViewP) GetPtr(theV);
    svSupSub = SupSubOff;
    SupSubOff = tvp->inhSupSub; /* set sup/sub inhibit */
#ifdef DOCVERIFY
{
long tempLx;
int linenx;

if ((tvp->txtvH.dAnn > 0) && (!force))
    {
    linenx = tvp->txtvH.dAnn-1; /* last line */
    tempLx = _TUTORline_pos_tview(tvp,linenx) + tvp->ld[linenx].nc;
    if (tempLx != tvp->layoutBottom)
		TUTORdump("txtv0 2"); 
    linenx = 0;
    }
}
#endif

    if (tvp->bounds.alteredF & 1)
        { /* turn off hiliting because we'll be redrawing this */
        _TUTORhilite_select(theV,FALSE);
        }
    bStick = TRUE; /* assume begin of view sticky */
    fullDrawF = force; /* don't need full redraw yet unless forced */
    delEnd = FALSE; /* don't know if delete at end yet */
    rlpos = pos;
    bpos = tvp->bounds.pos;
    bend = bpos+tvp->bounds.len;
    if ((tvp->layoutTop >= bpos) && (tvp->layoutTop < bend))
        rlpos = tvp->layoutTop; /* use old top if still legal */
    fillHeight = tvp->viewRect.bottom - tvp->viewRect.top + 1; /* space we want to fill */
    if (tvp->txtvH.dAnn == 0)
        { /* currently no lines in layout - just do line layout from scratch */
        if (pos > bend)
            pos = bend - 1;
        if (pos < tvp->bounds.pos)
            pos = tvp->bounds.pos;
        rlpos = pos; /* redraw at current position */
        fullDrawF = TRUE; /* flag need to redraw entire view */
        }
    
    /* for edit panel, check if change outside marker (not just view) bounds */
    /* this is essentially a set of kludges designed to force a full redraw for */
    /* any case the layout code might not handle correctly */
    
    if (tvp->editcmd || tvp->arrowcmd || tvp->dialog || tvp->debug) {
        if (bend && (pos == 0) && (newC > 0))
            fullDrawF = TRUE;
        if (((pos+len) > bend) || ((rpos+rlen) > bend)) {
            /* exempt single char erase at end of view from full redraw */
            if ((pos != tvp->bounds.len) || (len != 1) || newC || 
                (rpos != pos) || (rlen != len))
                fullDrawF = TRUE;
            else delEnd = TRUE; /* single char delete at end of view */
        }
        if ((pos == bpos) && (len == 0) && (rpos == pos) && rlen && (!newC)) {
            fullDrawF = TRUE; /* delete, at beginning */
            selS = bpos;
            selL = 0; /* no selection */
        }
        if ((pos < bpos) || (rpos < bpos)) {
            rlpos = tvp->layoutTop;
            if (rlpos < bpos)
                rlpos = bpos;
            if (rlpos > bend)
                rlpos = bend;
            fullDrawF = TRUE;
        }
        if ((pos+len+newC-rlen) > bend)
            fullDrawF = TRUE;
        if (selS > 0) {
            if ((selS+selL) > bend) {
                selS = bend;
                selL = 0;
                fullDrawF = TRUE;
            }
        } /* selS if */
        
        /* check selection in bounds */
        
        if (newC) { /* if adding characters, select is at end of region */
            cselP = rpos+rlen;
            cselL = 0;
        } else if (selS < 0) { /* not changing selection */
            TUTORinq_select_tview(theV,&cselP,&cselL); /* get current values */
        } else {
            cselP = selS;
            cselL = selL;
        }
        if (cselP < bpos) {
            if (selL) /* zero-length doesn't become non-zero */
                selL = (cselP+cselL)-bpos;
            if (selL < 0) selL = 0;
            cselP = selS = bpos;
            cselL = selL;
            fullDrawF = TRUE;
        }
        if (cselP+cselL > bend) {
            if (newC && (selS >= bend)) {
                selS = bend;
                selL = 0; /* at end of text */
            } else if ((cselP >= bpos) & (cselP <= bend)) {
                selS = cselP;
                if (selL) /* zero-length doesn't become non-zero */
                    selL = bend-selS;
            } else {
                selS = bend;
                selL = 0;
            }
            if (!delEnd) fullDrawF = TRUE;
        }
    } /* editcmd if */
    
    if (fullDrawF) { /* redraw entire view */
        ReleasePtr(theV);
        ResetView(theV,rlpos,selS,selL,vb);
        SupSubOff = svSupSub; /* restore sup/sub setting */
        return(0);
    } /* fullDrawF if */
    
    if (rlen || newC)
        { /* document changed size, need to update positions */
        rend = rpos+rlen;
        if ((rpos < tvp->layoutBottom && rend > tvp->layoutTop) ||
                rlen == 0 && (rpos == tvp->layoutBottom || rpos == tvp->layoutTop))
            { /* character changes took place within linestarts area -
                need to update nc field of linestarts in change region */
            if (rend <= tvp->bounds.pos)
                bStick = FALSE; /* begin of 1st line not sticky */
            tempL = tvp->layoutTop; /* start position of current line */
            lp = (LineLayout FAR *) tvp->ld;
            lpinc = FALSE; /* not incremented yet */
            tempL2 = tempL + lp->nc; /* end position of current line */
            ii = 0; /* current line */
            while (tempL <= rend)
                {
                if (rlen && rpos < tempL2 && rend >= tempL2)
                    { /* change includes end of line, so newline at end is doubtful */
                    lp->endNewline = FALSE;
                    }
                if (tempL2 < rpos)
                    del = 0; /* completely before change */
                else if (rlen == 0)
                    {
                    del = 0;
                    }
                else
                    { /* some characters being replaced */
                    if (tempL2 == rpos)
                        del = 0; /* change is in following line */
                    else if (tempL <= rpos && tempL2 >= rend)
                        { /* line completely encloses change */
                        del = -rlen;
                        }
                    else if (tempL < rpos)
                        { /* line overlaps change from below */
                        del = rpos - tempL2;
                        }
                    else if (tempL >= rpos)
                        { /* change covers line completely or line overlaps change to above */
                        del = tempL - rend;
                        if (-del >= lp->nc)
                            del = -((long) lp->nc); /* can't reduce line below 0 chars */
                        }
                    else
			TUTORdump("txtv0 3");
                    }
                
                tempL = tempL2;
                lp->nc += del;
                ii++;
                lp++;
                lpinc = TRUE; /* we need to decrement at end */
                if (ii >= tvp->txtvH.dAnn)
                    break; /* there are no more lines to look at */
                tempL2 += lp->nc;
                }

            /* add new characters to last changed line */
            if (lpinc) lp--;
            lp->nc += newC;
            
            } /* end of changes to linestarts nc field */
        
        /* change layoutTop & layoutBottom to be in terms of after change */
        if (!bStick && rend <= tvp->layoutTop)
            tvp->layoutTop += newC-rlen; /* change is before view */
        else if (rend < tvp->layoutTop || (rlen > 0 && rend == tvp->layoutTop))
            tvp->layoutTop += newC - rlen;
        else if (rend > tvp->layoutTop && tvp->layoutTop >= rpos)
            tvp->layoutTop = rpos;
        if (rend <= tvp->layoutBottom)
            tvp->layoutBottom += newC - rlen;
        else if (rpos < tvp->layoutBottom)
            tvp->layoutBottom = rpos + newC;
        
        /* change selection positions */
        tvp->selA.pos = ChangePos(tvp->selA.pos,rpos,rlen,newC,bStick);
        tvp->anchor.pos = ChangePos(tvp->anchor.pos,rpos,rlen,newC,bStick);
        
        len += newC - rlen; /* so len is in terms of document after change */
        
        /* kludge - keep length legal */
        if ((pos+len) > (tvp->bounds.pos+tvp->bounds.len))
            len = tvp->bounds.len-pos;
        } /* end of changes due to change in chars of doc */
    
    /* now all character positions are in terms of document AFTER change */
    /*  all except botPos, which is done in TUTORnew_bottom_tview */
    
    if (!(tvp->bounds.alteredF & 1))
        { /* text of view not altered */
        _TUTORinfo_vbar_tview(tvp,vb); /* need info even if no change */
        ReleasePtr(theV);
        KillPtr(tvp);
        SupSubOff = svSupSub; /* restore sup/sub setting */
        return(0);
        }
    tvp->bounds.alteredF &= ~1; /* clear doc altered flag */
    
    bottomF = ((pos < tvp->layoutBottom) || (pos == tvp->layoutBottom && rlen)) ;
    topF = ((pos >= tvp->layoutTop) || (pos+len > tvp->layoutTop) || ((len == 0) && (pos == tvp->layoutTop)));
      
    if (topF && bottomF)
        { /* we will have to change linestarts & display */
        /* what line does change start at? */
        startLine = 0;
        lp = (LineLayout FAR *) tvp->ld;
        tempL = tvp->layoutTop + lp->nc; /* end of current line */

        /* the tvp...nc > 0 clause (below) is so that a line that has had all chars taken away
            from it in the linestarts adjustment code above will be considered the
            start of the change, rather than getting skipped */
        while (lp->nc > 0 && (tempL < pos || tempL == pos && lp->endNewline))
            {
            startLine++;
            lp++;
            tempL += lp->nc;
            }
        
        /* startLine is now line index where change starts */
        endLine = startLine;
        tempL2 = tempL;
        while (endLine < tvp->txtvH.dAnn-1 && tempL2 < pos+len)
            {
            endLine++;
            lp++;
            tempL2 += lp->nc;
            }
        /* endLine is now the line index where change ends */
        
        /* the change can effect 1 line previous to startLine, if that previous line
            wasn't ended by a newline */
        if (startLine > 0 && !tvp->ld[startLine-1].endNewline)
            {
            tempL -= tvp->ld[startLine].nc;
            startLine--;
            ncPrevOld = tvp->ld[startLine].nc; /* # of chars in line before change start */
            }
        else
            ncPrevOld = -1; /* we didn't back up start */
        
        /* the change can possibly effect lines through a line with newline */
        lp = (LineLayout FAR *) tvp->ld + endLine;
        while (endLine < tvp->txtvH.dAnn-1 && !lp->endNewline)
            {
            endLine++;
            lp++;
            }
        /* this also accumulates completely deleted lines into change region */
        
        if (endLine < tvp->topLine || (startLine > tvp->botLine &&
                tvp->botPos < tvp->bounds.pos + tvp->bounds.len + rlen - newC))
            { /* change outside visible range */
            /* just get rid of the layout that was affected.  We don't need to draw */
            if (endLine < tvp->topLine)
                { /* change before visible */
                ii = endLine+1; /* new top line of layout */
                jj = tvp->txtvH.dAnn; /* new bottom line of layout */
                }
            else
                { /* change after visible */
                ii = 0;
                jj = startLine-1;
                }
            _TUTORshrink_layout_tview(tvp,ii,jj);
            _TUTORinfo_vbar_tview(tvp,vb); /* keep scroll bar in tune */
            ReleasePtr(theV);
            KillPtr(tvp);
            SupSubOff = svSupSub; /* restore sup/sub setting */
            return(0);
            }
        
        /* we now need to layout lines and draw */

        if (startLine <= tvp->botLine)
            { /* normal case, tempL contains end position of startLine */
            tempL -= tvp->ld[startLine].nc; /* now is the begin position of startLine */
            /* make tempL2 the length of the region we need to layout */
            tempL2 = 0;
            ii = startLine;
            lp = (LineLayout FAR *) tvp->ld + startLine;
            while (ii <= endLine)
                {
                tempL2 += lp->nc;
                ii++;
                lp++;
                }
            
            if (pos < tvp->layoutTop)
                { /* make sure the new layout start will be on a line boundary.  This
                        is a problem when an invisible style is applied that starts
                        before the layoutTop and extends into the layout.  Note that
                        we don't adjust line counts, the assumption here is that all
                        of the additional material will fit into the top line... */
                tempL3 = AdjustStart(tvp,tempL);
                if (tempL != tempL3)
                    { /* start has been moved back */
                    tvp->layoutTop = tempL3;
                    tempL2 += tempL - tempL3;
                    tempL = tempL3;
                    }
                }
            }
        else
            { /* adding characters to end of view (a new line) */
            /* assumming here that rlen was 0 */
            if (rlen != 0)
		TUTORdump("txtv0 4");
            tempL = tvp->layoutBottom - newC;
            tempL2 = tvp->bounds.pos + tvp->bounds.len - tempL;
            }
        
        /* now do layout */
        height = 0; /* height we already have filled */
        lp = (LineLayout FAR *) tvp->ld + tvp->topLine;
        for (ii=tvp->topLine; ii<startLine; ii++, lp++)
            height += lp->lineHeight;
        heightBefore = height; /* height of material before change */

        heightOld = 0; /* height of visible old material */
        jj = (startLine >= tvp->topLine) ? startLine : tvp->topLine;
        lp = (LineLayout FAR *) tvp->ld + jj;
        for (ii=jj; ii<=endLine && ii< tvp->txtvH.dAnn; ii++, lp++)
            heightOld += lp->lineHeight;
        
        if (endLine >= tvp->botLine)
            oldBottom = -1; /* indicates that bottom line was changed */
        else
            oldBottom = tvp->botLine;
        oldBotV = tvp->botV;
        
        heightNew = 0; /* height of new material */
        curStart = startLine;
        curEnd = endLine;
        nDelLines = 0;
        do
            { /* layout lines until we have enough to fill screen */
            newLines = SetupSomeLines(theV,tvp,&tempL,&tempL2,curStart,curEnd,
                                        &height,&heightNew);
            tvp = (TViewP) GetPtr(theV); /* since SetupSomeLines did ReleasePtr */
            /* reset curStart & curEnd for next call to TUTORreplace_darray */
            nDelLines += newLines - (curEnd - curStart + 1);
            curStart += newLines;
            curEnd = curStart-1; /* so we don't replace anything on subsequent layouts */
            } while (height < fillHeight && tempL2);

        if (height < fillHeight)
            { /* we ran out of new material and it didn't fill up screen */
            /* account for old material following change */
            heightAfter = 0;
            lp = (LineLayout FAR *) tvp->ld + curStart;
            for (ii=curStart; ii<tvp->txtvH.dAnn; ii++, lp++)
                {
                if (height >= fillHeight)
                    break;
                height += lp->lineHeight;
                heightAfter += lp->lineHeight;
                }
            if (height >= fillHeight)
                curStart = ii; /* line following last line we examined */
            else
                { /* still not enough, lay out more of doc till we have enough */
                tempL = tvp->layoutBottom;
                tempL2 = tvp->bounds.pos + tvp->bounds.len - tempL;
                curStart = tvp->txtvH.dAnn;
                curEnd = curStart-1; /* we aren't replacing anything */
                while (tempL2 > 0 && height < fillHeight)
                    {
                    newLines = SetupSomeLines(theV,tvp,&tempL,&tempL2,curStart,curEnd,
                                                &height,&heightAfter);
                    tvp = (TViewP) GetPtr(theV); /* since SetupSomeLines did ReleasePtr */
                    curStart += newLines;
                    curEnd = curStart-1;
                    nDelLines += newLines;
                    }
                /* we've either laid out enough to fill screen, or run out of document */
                tvp->layoutBottom = tempL;
                }
            }
        else if (tempL2 != 0)
            { /* we filled up screen before laying out all of the change */
            /* delete old layout following the change, since it is not continuous with
                    the new layout */
            TUTORdelete_darray(theV,(char FAR *) tvp,VIEWOFFSET,0,curStart,(int)(tvp->txtvH.dAnn - curStart));
            tvp->layoutBottom = tempL;
            }
        
        
        if (startLine < tvp->topLine)
            { /* change extended from before visible into what is visible
                shift so that top of change is new top line */
            tvp->topLine = startLine;
            }
        
        /* oldBottom is current index of the bottommost line now showing,
                that was showing before change */
        if (oldBottom >= 0)
            oldBottom += nDelLines;
        else
            { /* the old bottom line was changed - last showing was startLine-1 */
                /* but if startLine-1 is above top, no lines now showing were showing before */
            oldBottom = startLine-1;
            if (oldBottom < tvp->topLine)
                oldBottom = -1; /* line wasn't showing before */
            }
        
        _TUTORnew_bottom_tview(0,tvp); /* recalculate bottom line & botPos */

#ifdef DOCVERIFY
{
long tempLz;
int linenz;

if (tvp->txtvH.dAnn > 0)
    {
    linenz = tvp->txtvH.dAnn-1; /* last line */
    tempLz = _TUTORline_pos_tview(tvp,linenz) + tvp->ld[linenz].nc;
    if (tempLz != tvp->layoutBottom)
	TUTORdump("txtv0 5");
    linenz = 0;
    }
}
#endif
        /* draw */
        
        tr = tvp->viewRect;
        
        if (heightNew > heightOld)
            { /* new material is larger than what it replaced */
            if (heightBefore + heightNew < fillHeight && heightAfter > 0)
                { /* we want to shift trailing lines down */
                /* shift trailing lines we do want */
                tr.top += heightBefore + heightOld;
                tr.bottom = tr.top;
                ii = endLine + 1 + nDelLines;
                lp = (LineLayout FAR *) tvp->ld + ii;
                for (; ii<= tvp->botLine; ii++, lp++)
                    tr.bottom += lp->lineHeight;
                tr.bottom--; /* for on-pixel coords */
                TUTORscroll_rect(&tr,0,heightNew - heightOld);
                /* erase old area */
                tr.bottom = tr.top-1;
                tr.top -= heightOld;
                TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_BACKGROUND);
                /* draw new lines */
                _TUTORdraw_tview(tvp,startLine,endLine+nDelLines);
                
                /* erase anything after new bottom */
                tr.bottom = tvp->viewRect.bottom;
                tr.top = tvp->botV+1;
                TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_BACKGROUND);
                }
            else
                { /* we don't need any trailing lines */
                tr.top += heightBefore; /* don't erase stuff we want to keep */
                TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_BACKGROUND);
                _TUTORdraw_tview(tvp,startLine,tvp->botLine);
                }
            }
        else if (heightNew < heightOld)
            { /* erase old */
            tr.top += heightBefore;
            tr.bottom = tr.top + heightOld-1;
            TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_BACKGROUND);

            if (oldBotV > tr.bottom)
                { /* scroll up trailing text */
                tr.top = tr.bottom+1;
                tr.bottom = oldBotV;
                if (tr.bottom > tvp->viewRect.bottom)
                    tr.bottom = tvp->viewRect.bottom;
                TUTORscroll_rect(&tr,0,heightNew - heightOld);
                }
            _TUTORdraw_tview(tvp,startLine,curStart-1);
            if (oldBottom >= 0)
                _TUTORdraw_tview(tvp,oldBottom,tvp->botLine);
            }
        else
            { /* heightNew == heightOld - most frequent case */

            /* check for fast draw */
            tempL = _TUTORline_pos_tview(tvp,endLine);      
            if (rlen == 0 && tvp->selA.pos == pos &&
                    (startLine == endLine || (startLine == endLine-1 &&
                    tvp->ld[startLine].nc == ncPrevOld)) &&
                    pos+newC == tvp->ld[endLine].nDraw + tempL &&
		    tvp->vActive && /* check active because we are using selA as position */
                    FastOk(tvp,endLine,pos))

                { /* redraw fast */
                TUTORabs_move_to(tvp->selA.hh,tvp->selA.vv);
                TUTORdraw0_doc(tvp->doc,pos,newC,tvp->viewRect.left+tvp->leftOff,
                        &tvp->ld[startLine]);
                }
            else
                { /* wasn't drawn fast, draw normally */
                tr.top += heightBefore;
                tr.bottom = tr.top + heightOld-1;
                TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_BACKGROUND);
                ii = (endLine < tvp->botLine) ? endLine : tvp->botLine;
                _TUTORdraw_tview(tvp,startLine,ii);
                }
            }
        
        /* fix up selection */
        ReleasePtr(theV); /* because ChangeSelect unlocks theV */
        KillPtr(tvp);
        ChangeSelect(theV,selS,selL);
        tvp = (TViewP) GetPtr(theV);

        _TUTORinfo_vbar_tview(tvp,vb);

        /* make sure we don't have too many linestarts */
        if (tvp->txtvH.dAnn > MAXLAYOUTLINES+50)
            { /* too many layout lines - get rid of some */
            _TUTORshrink_layout_tview(tvp,tvp->topLine-5,tvp->botLine+5);
            }

        ReleasePtr(theV);
        KillPtr(tvp);
        TUTORcompress_darray(theV,VIEWOFFSET);
        }
    else /* change is outside current linestarts */
        {
        /* all the character positions (except botPos) are already set, the
            line layout doesn't change, we don't have to draw, so we're almost done */
        if (rpos < tvp->botPos)
            tvp->botPos += newC - rlen;
        
        if (selS >= 0L)
            { /* scroll so that selection shows */
            ReleasePtr(theV); /* because TUTORscroll_middleV may resize theV */
            KillPtr(tvp);
            TUTORscroll_middleV(theV,selS);
            tvp = (TViewP) GetPtr(theV);
            }
        
        _TUTORinfo_vbar_tview(tvp,vb); /* keep scroll bar in tune */

        ReleasePtr(theV);
        KillPtr(tvp);
        }
    SupSubOff = svSupSub; /* restore sup/sub setting */    
    return(0);
    } /* TUTORchange_tview */

static long ChangePos(pos,rpos,rlen,newC,bStick) /* helper routine for change_tview */
register long pos;  /* position to be modified */
register long rpos, rlen;   /* where change occurred */
register long newC; /* # of new characters */
int bStick; /* TRUE if begin of view is sticky */
/* returns modified position */
    {
    long rend; /* end of change */
    
    if ((pos < rpos) || (bStick && pos == rpos))
        return(pos);
    
    rend = rpos + rlen;
    if (pos >= rend)
        pos += newC - rlen;
    else
        { /* pos is in range of change */
        pos = rpos;
        }
    return(pos);
    }

static ResetView(theV,pos,selS,selL,vb) /* helper routine for change_tview */
Memh theV;  /* tview */
long pos; /* where change started, we want this visible */
long selS, selL; /* where selection should be (if selS < 0 don't move selection) */
SBarInfo *vb;   /* to be filled with vertical scroll bar info */
    {
    REGISTER TViewP tvp;    /* pointer to tview */
    int fillHeight;     /* height of view */
    TRect rr;   /* rectangle used to erase */
    
    /* this routine displays view when a change was not visible */
    
    tvp = (TViewP) GetPtr(theV);
    
    if (pos > tvp->bounds.pos + tvp->bounds.len)
        pos = tvp->bounds.pos + tvp->bounds.len - 1;
    if (pos < tvp->bounds.pos)
        pos = tvp->bounds.pos;
#ifdef NOsuch   
    if (tvp->botLine >= 0)
        { /* erase all visible lines */
        rr = tvp->viewRect;
        rr.bottom = _TUTORline2_vv_tview(tvp,tvp->botLine);
        rr.bottom += tvp->ld[tvp->botLine].lineHeight - tvp->ld[tvp->botLine].lineAsc;
        TUTORdraw_abs_solid_rect((TRect FAR *) &rr,PAT_BACKGROUND);
        tvp->caretState = FALSE;
        }
    else
        { /* no lines to erase, just turn off caret */
        _TUTORhilite_select(theV,FALSE);
        }
#endif
    
    if (tvp->botLine >= 0)
        { /* erase all visible lines */
        rr = tvp->viewRect;
        if (tvp->botLine < tvp->txtvH.dAnAlloc) {
            rr.bottom = _TUTORline2_vv_tview(tvp,tvp->botLine);
            rr.bottom += tvp->ld[tvp->botLine].lineHeight - tvp->ld[tvp->botLine].lineAsc;
        }
        TUTORdraw_abs_solid_rect((TRect FAR *) &rr,PAT_BACKGROUND);
        tvp->caretState = FALSE;
        }
    else
        { /* no lines to erase, just turn off caret */
        _TUTORhilite_select(theV,FALSE);
        }
        
    /* layout lines */
    fillHeight = tvp->viewRect.bottom - tvp->viewRect.top + 1;
    ReleasePtr(theV);
    KillPtr(tvp);
    _TUTORlayout_lines0(theV,pos,fillHeight,TRUE);

    /* draw */
    tvp = (TViewP) GetPtr(theV);
    _TUTORnew_bottom_tview(HNULL,tvp);
    
    _TUTORdraw_tview(tvp,tvp->topLine,tvp->botLine);
    
    /* show selection */
    tvp->anchor.atEnd = TRUE; /* force to end in this special case */
    
    ReleasePtr(theV); /* because ChangeSelect unlocks theV */
    KillPtr(tvp);
    ChangeSelect(theV,selS,selL);
    tvp = (TViewP) GetPtr(theV);
    
    _TUTORinfo_vbar_tview(tvp,vb);
    ReleasePtr(theV);
    KillPtr(tvp);
    
    return(0);
    }
        
static ChangeSelect(theV,selS,selL) /* helper routine for change_tview */
Memh theV;  /* tview */
register long selS, selL; /* where selection should be (if selS < 0 don't move selection) */
    {
    REGISTER TViewP tvp;    /* pointer to tview */
    int scrollFlag; /* if TRUE, we need to scroll */
    int shortScroll;    /* if TRUE, the scroll is just 1 line */
    
    tvp = (TViewP) GetPtr(theV);
    
    if (selS >= 0) /* reset anchor position */
        tvp->anchor.pos = selS;
    
    /* leave sel1 at end if it was before... */
    if (tvp->anchor.pos == tvp->bounds.pos + tvp->bounds.len &&
            tvp->anchor.pos == tvp->layoutBottom)
        { /* ...unless we are at end of last line, when we need to set atEnd carefully */
        tvp->anchor.atEnd = !(tvp->ld[tvp->botLine].endNewline);
        }
    TUTORwhere_pix_tview(tvp->self,&tvp->anchor);

    if (selS < 0)
        { /* we aren't changing selection */
        /* make selS the beginning of existing selection */
        selS = tvp->anchor.pos;
        if (selS > tvp->selA.pos)
            selS = tvp->selA.pos; /* active end is below anchor */
        if (selS < tvp->bounds.pos)
            selS = tvp->bounds.pos;
        /* reset selA pixel position */
        TUTORwhere_pix_tview(tvp->self,&tvp->selA);
        }
    else if (selL == 0) {
        tvp->selA = tvp->anchor;
    } else
        {
        tvp->selA.pos = selS + selL;
        tvp->selA.atEnd = TRUE; /* try to keep selA from going to extra lines */
        TUTORwhere_pix_tview(tvp->self,&tvp->selA);
        }
    _TUTORhilite_select(tvp->self,TRUE); /* turn hiliting back on */
    
    /* make sure selection is on screen */
    scrollFlag = SelectVisibleTView(tvp,&shortScroll);
    
    ReleasePtr(theV);
    KillPtr(tvp);
    
    if (scrollFlag)
        {
        if (shortScroll)
            _TUTORscrollv_tview(theV,sbLineDown,1L);
        else
            TUTORscroll_middleV(theV,selS);
        }
    
    return;
    }

static SelectVisibleTView(tvp,shortScroll)
register TViewP tvp;    /* pointer to tview */
int *shortScroll;   /* set to TRUE if selection NOT visible but can be seen with simple scroll */
/* returns FALSE if selection not visible */
    {
    int scrollFlag; /* TRUE if we need to scroll view */
    int AnLine; /* copy of selA.nLine */
    
    AnLine = tvp->selA.nLine;
    if (AnLine < 0)
        AnLine = 0;
    if (AnLine < tvp->topLine || tvp->anchor.nLine > tvp->botLine + 1)
        { /* selection is very off screen, big scroll */
        scrollFlag = TRUE;
        *shortScroll = FALSE;
        }
    else if (tvp->anchor.nLine < tvp->botLine ||
            (AnLine >= tvp->topLine && AnLine < tvp->botLine))
        { /* at least part of selection is on screen, don't scroll */
        scrollFlag = FALSE;
        }
    else
        { /* complicated case, consider carefully.  Look at vertical position of caret */
        /* tvp->anchor is either botLine or botLine+1 */
        if (tvp->botV >= tvp->viewRect.bottom)
            { /* we are at bottom of view, scroll */
            scrollFlag = TRUE;
            *shortScroll = (tvp->anchor.nLine == tvp->botLine);
            }
        else
            { /* botLine hasn't reached bottom of view yet */
            /* we only need to scroll in the case where caret, on empty line,
                has just passed bottom of screen */
            if (tvp->anchor.nLine > tvp->botLine &&
                    tvp->botV + tvp->ld[tvp->botLine].lineHeight >= tvp->viewRect.bottom)
                {
                scrollFlag = TRUE;
                *shortScroll = TRUE;
                }
            else
                scrollFlag = FALSE;
            }
        }
    
    return(scrollFlag);
    }

static FastOk(tvp,line,pos) /* check styles for fast redraw */
register TViewP tvp;    /* pointer to tview */
int line;   /* line of view we are checking */
long pos;   /* position of start of change */
/* returns TRUE if we can do a fast redraw */
    {
    DocP dp;    /* pointer to document */
    StyleDatP sp;   /* pointer to document styles */
    int justif; /* justification */
    register Style1 SHUGE *s1p;   /* pointer to current style block */
    int curMode;    /* current drawing mode */
    int retVal; /* the return value */
    
    retVal = FALSE;
    dp = (DocP) GetPtr(tvp->doc);
    if (!dp->styles)
        {
        justif = dp->defStyles[PARASTYLE] & JUSTMASK;
        }
    else
        {
        sp = (StyleDatP) GetPtr(dp->styles);
        s1p = sp->styles + FindBlockTypeTStyle(sp,pos,PARASTYLE);
        if (s1p->dat == DEFSTYLE)
            justif = dp->defStyles[PARASTYLE] & JUSTMASK;
        else
            justif = s1p->dat & JUSTMASK;
        ReleasePtr(dp->styles);
        KillPtr(sp);
        }

    if (justif == LEFTJUST || (justif == FULLJUST && (tvp->ld[line].endNewline ||
                line == tvp->botLine)))
        retVal = TRUE;
    
    ReleasePtr(tvp->doc);
    KillPtr(dp);
    
    curMode = TUTORinq_comb_rule();
    if (curMode == SRC_COPY || curMode == NOT_SRC_COPY)
        retVal = FALSE; /* because modes rewrite & inverse need special background handling */
    
    return(retVal);
    }

/* general purpose line layout: */
static SetupSomeLines(theV,tvp,pos,len,startLine,endLine,height,heightNew)
Memh theV; /* tview */
REGISTER TViewP tvp;    /* pointer to tview */
long *pos;  /* position where layout starts, changed to position at end of layout */
long *len;  /* amount needing to be laid out, change to amount remaining after layout */
int startLine, endLine; /* lines in theV which are being replaced by this layout */
int *height;    /* total height filled in view, we add new layout height */
int *heightNew; /* total height of changed layout, we add new layout height */
    {
    Memh newLay;    /* handle to new line layouts */
    REGISTER LineLayout FAR *liLay; /* pointer to newLay */
    LineLayout FAR *saveLi; /* to save & restore liLay */
    int newLines;   /* # of new lines */
    int ii;
    int newHeight;  /* total new layout height */
    int newStart;   /* index in new layout of lines we actually use (usually 0) */
    register long tempL;
    
    newLines = _TUTORpartial_layout(tvp,*pos,*len,&newLay);
    liLay = (LineLayout FAR *) GetPtr(newLay);
    newStart = 0;
    
    /* account for height & chars of newly laid out lines */
    saveLi = liLay;
    liLay += newStart;
    tempL = *pos;
    newHeight = 0;
    for (ii=newStart; ii<newLines; ii++, liLay++)
        {
        newHeight += liLay->lineHeight;
        *pos += liLay->nc;
        }
    *len -= (*pos - tempL);
    *height += newHeight;
    *heightNew += newHeight;
    liLay = saveLi;
    
    /* make sure a new invisible line at either end of new layout combines with an
        adjoining invisible line in old layout */
    if (newLines && liLay->lineAsc == 0 && startLine > 0 && tvp->ld[startLine-1].lineAsc == 0)
        { /* merge out first line of new layout */
        newStart = 1; /* we won't be using the first line */
        tvp->ld[startLine-1].nc += liLay->nc; /* add chars to previous invisible line */
        *height -= liLay->lineHeight;
        *heightNew -= liLay->lineHeight;
        }
    if (newLines && liLay[newLines-1].lineAsc == 0 && tvp->txtvH.dAnn > endLine+1 &&
            tvp->ld[endLine+1].lineAsc == 0 && *len == 0)
        { /* merge out last line of new layout */
            /* note that *len == 0 guarantees that the new layout and the old
                layout really abut */
        tvp->ld[endLine+1].nc += liLay[newLines-1].nc;
        ii = tvp->ld[newLines-1].lineHeight;
        *height -= ii;
        *heightNew -= ii;
        newLines--;
        }
    
    /* splice new layout into tview */
    ReleasePtr(theV);
    KillPtr(tvp);
    TUTORreplace_darray(theV,FARNULL,VIEWOFFSET,0,startLine,
            endLine-startLine+1,newLines-newStart,(char FAR *) (liLay+newStart));
    ReleasePtr(newLay);
    KillPtr(liLay);
    TUTORfree_handle(newLay);

    return(newLines);
    }

/* layout some lines: */
static _TUTORpartial_layout(tvp,pos,len,layoutH)
register TViewP tvp;    /* pointer to tview */
long pos, len;  /* region we want laid out */
Memh *layoutH;  /* to be filled with new layout information */
/* returns # of new lines in layout */
    {
    LineLayout FAR *liLay;  /* pointer to line layouts */
    REGISTER DocP dp;   /* pointer to document */
    StyleDatP sp;   /* pointer to document styles */
    short curStyles[NSTYLES];   /* current document styles */
    ParagraphLayout pLay;   /* current paragraph layout */
    int styleInd;   /* index of next style block */
    SpecialTP stp;  /* pointer to document's special text info */
    int stind;  /* index of next special text block */
    int nLines; /* # of lines laid out */
    long layoutMemL; /* memory size for layout */
    
    /* allocate memory for calculation of layout */
    
    if (len < 0)
	TUTORdump("txtv0 6");
    nLines = (len > MAXLAYOUTLINES) ? MAXLAYOUTLINES : len; /* worst case guess */
    layoutMemL = (long)sizeof(LineLayout)*(long)nLines;
    *layoutH = TUTORhandle("templlay",layoutMemL, FALSE);
    if (!(*layoutH))
	TUTORdump("txtv0 7");

    /* do the layout */
    
    liLay = (LineLayout FAR *) GetPtr(*layoutH);
    TUTORzero((char SHUGE *)liLay,layoutMemL);
    dp = (DocP) GetPtr(tvp->doc);
    _TUTORsetup_layout(dp,pos,len,&styleInd,&sp,curStyles,&pLay,&stind,&stp,TRUE);
    _TUTORset_textfont_doc(dp,curStyles);
    if (!dp->shortText)
        _TUTORload_buffer_doc(dp,pos);
    
    nLines = _TUTORlayout_lines(dp,pos,len,tvp->destWidth,tvp->wrap,0,sp,styleInd,
        liLay,curStyles,&pLay,stp,stind);
    ReleasePtr(*layoutH);
    KillPtr(liLay);
    
    /* clean up */
    
    if (sp)
        {
        ReleasePtr(dp->styles);
        KillPtr(sp);
        }
    if (stp)
        {
        ReleasePtr(dp->specialT);
        KillPtr(stp);
        }
    ReleasePtr(tvp->doc);
    KillPtr(dp);

    return(nLines);
    }

/* layout large number of lines */
_TUTORlayout_lines0(theV,pos,height,redo)
Memh theV;  /* tview */
long pos;   /* position we want laid out */
int height; /* how much we want laid out */
int redo;   /* if TRUE, redo layout no matter what */
    {
    int modeFlag;   /* 0: layout all new, 1: layout down, 2: layout up */
    REGISTER TViewP tvp;    /* pointer to tview */
    long startPos;  /* position (in document) where we start laying out lines */
    long oldTop;    /* -1 if we are completely replacing old layout,
                        else it is the old top line */
    int viewHeight; /* height of view */
    int ii;
    int newHeight;  /* amount we've laid out */
    int foundHeight;    /* total height we've found in view */
    long tempL;
    long curPos;    /* current position */
    long curLen;    /* amount of doc we have left to layout */
    register int startLine; /* first line we are replacing in tview */
    register int endLine;   /* last line we are replacing in tview */
    int newLines;   /* # of newly laid out lines */
    
    tvp = (TViewP) GetPtr(theV);
    newHeight = 0;
    
    viewHeight = tvp->viewRect.bottom - tvp->viewRect.top + 1;
    if (pos > tvp->layoutBottom || redo)
        modeFlag = 0;
    else if (pos == tvp->layoutBottom)
        modeFlag = 1;
    else if (pos >= tvp->layoutTop)
        { /* pos is in existing layout, but we need to make sure there is enough layout
            following it */
        ii = _TUTORpos2_line_tview(tvp,pos); /* get line # of line of pos */
        while (ii < tvp->txtvH.dAnn)
            {
            newHeight += tvp->ld[ii++].lineHeight;
            }
        if (newHeight >= height)
            { /* there is already enough layout, we don't need to do anything */
            ReleasePtr(theV);
            KillPtr(tvp);
            return(0);
            }
        /* else we need some additional layout */
        pos = tvp->layoutBottom;
        modeFlag = 1;
        height -= newHeight; /* to account for height in existing layout */
        }
    else
        { /* pos is before existing layout */
        if (height < viewHeight)
            modeFlag = 2;
        else
            modeFlag = 0;
        }
    
    /* if modeFlag is 0 we redoing layout,
            we will have to search backwards for NEWLINE to find a certain line break.
            Existing layout may get appended to new layout (unless redo is TRUE).
        if modeFlag is 1, we are continuing current layout downwards, so pos is known
            to be a good linebreak
        if modeFlag is 2, we have to guess at a good backwards position to start layout
            from.  If it turns out that wasn't far enough, we'll have to recurse */
    
    if (modeFlag == 1 || modeFlag == 0)
        startPos = pos;
    else if (modeFlag == 2)
        { /* count # of chars in view to get estimate of how far back to go */
        tempL = 0;
        foundHeight = 0;
        for (ii=tvp->topLine; ii<= tvp->botLine; ii++)
            {
            tempL += tvp->ld[ii].nc; /* sum of # of chars */
            foundHeight += tvp->ld[ii].lineHeight; /* sum of line heights */
            }
        tempL = tvp->layoutBottom - tvp->layoutTop;
        if (foundHeight)
            startPos = pos - (tempL * height)/foundHeight;  /* linear extrapolation */
        else /* no lines in view??? */
            startPos = pos;
        if (startPos < tvp->bounds.pos)
            startPos = tvp->bounds.pos;
        }
    
    if ((modeFlag == 0 || modeFlag == 2) && startPos > tvp->bounds.pos)
        { /* we need to search backwards for a correct boundary.  It should be a newline
            and it shouldn't be in the middle of an invisible style */
        startPos = AdjustStart(tvp,startPos);
        }
    
    /* now format from startPos until we fill height, or get to tvp->layoutTop */
    curPos = startPos;
    tempL = tvp->bounds.pos + tvp->bounds.len;
    if (redo || startPos >= tvp->layoutTop)
        curLen = tempL - startPos;
    else
        curLen = tvp->layoutTop - startPos; /* layout just to current layout */
    
    if (modeFlag == 0)
        {
        if (startPos > tvp->layoutBottom || redo)
            { /* we want to completely replace existing layout */
            endLine = tvp->txtvH.dAnn-1;
            oldTop = -1; /* we are totally replacing old layout */
            }
        else
            { /* we may append existing layout to new layout */
            endLine = -1; /* to insert before first line */
            oldTop = tvp->layoutTop; /* in case we run new layout up to old */
            }
        tvp->layoutTop = startPos;
        startLine = 0;
        }
    else if (modeFlag == 1)
        { /* we want to append to existing layout */
        startLine = tvp->txtvH.dAnn;
        endLine = startLine-1;
        }
    else /* modeFlag == 2 */
        { /* we want to insert before existing layout */
        tvp->layoutTop = startPos;
        startLine = 0;
        endLine = -1; /* so we insert before first line */
        }
    do
        {
        newLines = SetupSomeLines(theV,tvp,&curPos,&curLen,startLine,endLine,&newHeight,&ii);
        tvp = (TViewP) GetPtr(theV); /* since SetupSomeLines did ReleasePtr */
        startLine += newLines;
        endLine = startLine - 1;
        } while (curLen > 0 && (modeFlag == 2 || newHeight < height));
    
    if (modeFlag == 1)
        tvp->layoutBottom = curPos; /* that's as far as we got */
    else if (modeFlag == 0)
        {
        if (redo || oldTop == -1) /* we weren't trying to append existing layout */
            tvp->layoutBottom = curPos; /* as far as we got */
        else if (curPos < oldTop)
            { /* we didn't get up to existing layout */
            tvp->layoutBottom = curPos;
            TUTORdelete_darray(theV,(char FAR *) tvp,VIEWOFFSET,0,startLine,
                                tvp->txtvH.dAnn - startLine); /* delete previous layout */
            }
        /* else we laid out up to previous layout */
        }
    
    if (modeFlag == 0 || modeFlag == 2)
        { /* new top line is line containing pos */
        tvp->topLine = _TUTORpos2_line_tview(tvp,pos);
        _TUTORnew_bottom_tview(0,tvp);
        }
    
    /* we're done, unless in mode 2 we haven't laid out enough */
    ii = FALSE; /* by default don't recurse */
    if (modeFlag == 2 && newHeight < height && tvp->layoutTop > tvp->bounds.pos)
        ii = TRUE; /* recurse */

    ReleasePtr(theV);
    KillPtr(tvp);
    if (ii)
        _TUTORlayout_lines0(theV,startPos-1,height - newHeight,FALSE);
    
    return(0);
    }

static long AdjustStart(tvp,startPos) /* make sure layout start is in good place */
register TViewP tvp;    /* pointer to tview */
long startPos;  /* position we are checking */
/* returns a good layout start position (which is <= startPos) */
    {
    DocP dp;    /* pointer to doc */
    unsigned char tempS[2]; /* search target */
    StyleDatP sp;   /* pointer to document styles */
    register Style1 SHUGE *s1p;   /* pointer to style block */
    int styleInd;   /* index of style block */
    short curStyles[NSTYLES];   /* current document styles */
    long tempL;
    
    /* search backwards for a correct boundary.  It should be a newline
            and it shouldn't be in the middle of an invisible style */
    dp = (DocP) GetPtr(tvp->doc);
    tempS[0] = NEWLINE;
    startPos = TUTORsearch_string_doc(dp,(unsigned char FAR *) tempS,1L,startPos,
                                    tvp->bounds.pos);
    if (startPos == -1L) /* didn't find a newline further back */
        startPos = tvp->bounds.pos; /* so start at begin of view range */
    else
        startPos++; /* start AFTER newline */
    if (startPos > tvp->bounds.pos && dp->styles)
        { /* make sure we aren't in middle of invisible style */
        styleInd = AtTStyle(dp->styles,startPos,curStyles);
        if (curStyles[PARASTYLE] & VISMASK)
            { /* we are in invisible style, look backwards at styles till we find
                the start of this invisibility */
            sp = (StyleDatP) GetPtr(dp->styles);
            s1p = ((Style1 SHUGE *) sp->styles) + ((styleInd == -1) ? (sp->sHead.dAnn-1) : (styleInd-1));
            
            /* we will look backwards till we find a visible paragraph style start,
                which is one paragraph style too far back, so remember the last
                place that an invisible paragraph started.  This all assummes that
                the default style for the document is visible,
                and that DEFSTYLE & VISMASK is 0 */
            while (s1p > ((Style1 SHUGE *) sp->styles) && s1p->pos >= tvp->bounds.pos)
                {
                if (s1p->type == PARASTYLE)
                    {
                    if (s1p->dat & VISMASK)
                        tempL = s1p->pos; /* a previous set to invisible */
                    else
                        break; /* found a visible style */
                    }
                s1p--;
                }
            if (s1p > ((Style1 SHUGE *) sp->styles) && s1p->pos >= tvp->bounds.pos)
                startPos = tempL; /* start of invisibility (we found a visible) */
            else
                startPos = tvp->bounds.pos; /* start of view is invisible */
            ReleasePtr(dp->styles);
            KillPtr(sp);
            } /* end of search backwards due to invisibility */
        } /* end of check when doc is styled */
    ReleasePtr(tvp->doc);
    KillPtr(dp);
    
    return(startPos);
    }

TUTORinq_select_tview(theV,pos,len) /* returns view selection */
Memh theV;  /* tview */
register long *pos, *len;   /* to be set to view selection */
/* returns TRUE if pos is at beginning of view */
    {
    REGISTER TViewP tvp;    /* pointer to tview */
    int atStart;    /* set to TRUE if selection is at view start (return value) */
    
    tvp = (TViewP) GetPtr(theV);
    *pos = (tvp->anchor.pos < tvp->selA.pos) ? tvp->anchor.pos : tvp->selA.pos;
    *len = tvp->selA.pos - tvp->anchor.pos;
    if (*len < 0)
        *len = -(*len);
    atStart = (*pos == tvp->bounds.pos);
    ReleasePtr(theV);
    KillPtr(tvp);
    
    return(atStart);
    }
