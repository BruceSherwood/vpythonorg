
/* (c) Copyright Carnegie-Mellon University, 1987. */
/* May be used and copied freely for educational purposes, */
/* but may not be sold without the written consent of Carnegie-Mellon University. */

#ifndef DOSPC
#define DOSPC

#define TURBOC 1
/* #define MSC 1 */

typedef char *Ptr;

#define NEWLINE '\n'
#define NEWLINES "\n"
#define RETURN '\r'

#define FAR far
#define Farp(x) ((char FAR *) (x))
#define SHUGE FAR
#ifdef TURBOC
#define NEARNULL 0
#define FARNULL 0L
#else
#define NEARNULL ((void *)0)
#define FARNULL ((char _far *)0)
#endif

#define BADPOINTER -3

#define HPurge(x) /* purge */
#define HNoPurge(x) /* nopurge */

#define FILEL 94  /* max file name length */

#define EVENTLIMIT 20 /* maximum number events to stack up */

#define MAXNEARLEN 1024 /* max size for far->near conversion */

/* file reference structure: */
typedef struct _fref {
    char path[FILEL+2]; /* full path, including name */
    unsigned char nameInd;  /* index in path where bare file name starts */
    char drive;     /* 1 - a:,  2 - b:, etc. */
} FileRef;

#define ctproto

/* machine-dependent graphics definitions */

/* text face definitions */

#define style_plain 0
#define style_bold 1        
#define style_italic 2

/* text/pattern mode definitions */

#define SRC_COPY 0  /* mode rewrite */
#define SRC_OR  1   /* mode write */
#define SRC_XOR 2   /* mode xor */
#define SRC_BIC 3   /* mode erase */
#define NOT_SRC_COPY 4  /* mode inverse */
#define NOT_SRC_OR 5
#define NOT_SRC_XOR 6
#define NOT_SRC_BIC 7

  /* for filling a solid rect */
#define PAT_BLACK  1
#define PAT_WHITE  20
#define PAT_BACKGROUND -1

#define NFSIZES 6

/* scroll bar part codes */
#define inButton 10
#define inCheckBox 11
#define inUpButton 20
#define inDownButton 21
#define inPageUp 22
#define inPageDown 23
#define inThumb 129

#endif	/* DOSPC */
