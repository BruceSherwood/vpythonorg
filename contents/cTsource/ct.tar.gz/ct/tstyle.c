
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "baseenv.h"
#include "txt.h"

#ifdef ctproto
extern int valid_style(int SN);
extern int TUTORlog(char *str);
unsigned int  NewTStyle(void);
int  CloseTStyle(unsigned int  pd);
int  AtTStyle(unsigned int  pd,long  pos,short  *styles);
int  AddHotTStyle(unsigned int  pd,long  start,long  len,long  docLen,unsigned char  FAR *ss,long  sLen);
int  AddTStyle(unsigned int  pd,long  start,long  len,long  docLen,int  type,int  newDat,int  combF);
int  CombineStyles(int  type,int  oldStyle,int  newDat,int  combF);
int  CheckKeepTStyle(unsigned int  pd);
int  InsertTStyle(unsigned int  pd,long  start,long  len,int  expandEnd);
int  DeleteTStyle(unsigned int  pd,long  start,long  len);
int  SpliceTStyle(unsigned int  pd,unsigned int  newPd,long  toStart,long  fromStart,long  fromLen,long  docLen);
extern int  SpliceHotText(unsigned int  *hotList,unsigned int  pd,short  *hotDat);
extern int  KillTStyle(unsigned int  pd,struct  _pdt FAR *pp,int  ind,int  nn,int  killHot);
int  FindBlockTypeTStyle(struct  _pdt FAR *pp,long  ps,int  type);
int  FindBlockTStyle(struct  _pdt FAR *pp,long  pos);
int  CheckOrdering(struct  _pdt FAR *pp,char  *ss);
unsigned int  NewHotList(void);
int  CloseHotList(unsigned int  hl);
int  AddHotList(unsigned int  hl,unsigned char  FAR *ss,long  len);
int  TUTORchange_hot_text(unsigned int  pd,int  id,char  FAR *ss,long  sLen);
extern int  DeleteHotList(unsigned int  hl,int  id);
unsigned char  FAR *GetHotstringTStyle(unsigned int  pd,int  id,long  *len,long  *spos,long  *slen,int  getS);
char  FAR *GetPtr(unsigned int  mm);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  TUTORfree_handle(unsigned int  mm);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORinsert_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nIns);
int  TUTORdump(char  *s);
int  TUTORcompress_darray(unsigned int  da,int  offset);
int  TUTORdelete_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  nDel);
int  TUTORdealloc(char  FAR *ptr);
int  TUTORreplace_darray(unsigned int  da,char  FAR *dp,int  offset,int  arrayN,int  ind,int  replaceN,int  newN,char  FAR *datP);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
extern int sprintf(char *ss, char *form,...);
#endif

extern char FAR *GetPtr();
extern Memh NewHotList();
unsigned char FAR *GetHotstringTStyle();

/* ksw-documentation
	Styles for a document are stored in a StyleDat structure, which mostly consists of
	a long variable sized array (styles).  The data in the array consists of style
	changes.  So a bold style, in an otherwise plain document is represented by a
	"block" with type FACESTYLE and dat bold at the start of the style and a "block"
	with type FACESTYLE and dat plain at the end of the style.
	
	The blocks in the array styles are always kept sorted, first by position, and then,
	for all blocks at the same position, by type.
	
	What does the dat mean for the various styles?
	FONTSTYLE: the font family number (used in calls to TUTORset_textfont2, for example)
	SIZESTYLE: the percentage bigger or smaller than the "default size".  0 means the
		same size as the "default size".  1 means 1% larger, -1 means 1% smaller.
		If the dat is <= ABSSIZE (which is a large negative number) then
		the dat means the actual size -(dat - ABSSIZE).  When we make an absolute size
		bigger or smaller we first convert the absolute size into an amount bigger
		or smaller than size 13.  Note that sizes are system point sizes and not
		actual screen sizes.
	FACESTYLE: dat is bits ORed together to indicate the face.  1:bold, 2: italic,
		4: underline, 8:outline, 16: shadow, 32: subscript, 64: superscript.  Plain
		is therefore 0.
	PARASTYLE: a paragraph style is three styles ORed together.  The 0th bit is
		invisibility (1 for invisible), the next two bits are the justification,
		the rest of the style is a paragraph layout.  The paragraph layout is really
		an index into the paragraph layout table (after >> 3).
	COLORSTYLE: the palette number to use for the foreground color of the text, or
		the background color when drawing in mode inverse.  The palette is the standard
		cT default palette.
	HOTSTYLE: The dat is an index
		into the hotlist associated with this style data. A HOTSTYLE of DEFSTYLE just
		means that the text is not hot.
	
	In addition every style can have the value DEFSTYLE.  This means that the style is
	"default".  When the document is drawn or otherwise uses styles, DEFSTYLEs are
	replaced by the values stored in the defStyle fields of the document.  This indirection
	is neccesary in cT so that pieces of the editor document (which have style DEFSTYLE)
	can be displayed in styles determined at runtime, without going thru the heavyweight
	process of changing a style structure.
	
	The paragraph style can have an additional complication - the visibility and the
	justification are set, but the paragraph layout can be PARADEFAULT.  This indicates
	that we don't use the paragraph layout table but use the document's default layout.
	This is so that at execution the documents can have a different layout (for example
	the margins are 0) than for the editor (where there are non-zero margins) and still
	preserve the justification data.
	
	Documents that don't have styles are assummed to have the DEFSTYLEs over all
	their text.  Note that this is subtly different than having no styles at all.
	
	DEFSTYLEs may have to combine in some circumstances (a FACESTYLE being added, or
	a justificiaton).  In that case the following values for DEFSTYLE:  face 0,
	paragraph PARADEFAULT | LEFTJUST | VISIBLE, size 0.
	
	Note that a style data of DEFSTYLE does NOT mean "replace with the style in the
	document's defStyle field."  It means "replace with the doc's defStyle field AT THE
	TIME OF DISPLAY!"  So DEFSTYLEs from different documents (that have different values
	in their defStyles) are treated the same.
	
	An important subelement of the style structure is the hotList, which is a handle
	which is itself a complex structure.  It is used only in documents where there is
	hot text, it is used to store the associated strings.  See below for explanation
*/


extern void DumpStyles(Memh doc);

void DumpStyles(doc) /* dump current style structures */
Memh doc; /* handle on document */

{	DocP dP; /* pointer to document structure */
	StyleDatP sP; /* pointer to top level style structure */
	Style1 SHUGE *s1P; /* pointer to single style entry */
	int ii;
	char msg[80];
	
	dP = (DocP) GetPtr(doc);
	if (!dP->styles) {
		sprintf(msg,"document %x has no styles\n",(unsigned int)doc);
		TUTORlog(msg);
	} else {
		sprintf(msg,"styles for document %x\n",(unsigned int)doc);
		TUTORlog(msg);
		sP = (StyleDatP)GetPtr(dP->styles);
		if (sP->styles) {
			sprintf(msg,"pos type dat  nn %d\n",sP->sHead.dAnn);
			TUTORlog(msg);
			s1P = sP->styles; /* pointer to first style entry */
			for(ii=0; ii<sP->sHead.dAnn; ii++) {
				sprintf(msg,"  %ld    %ld   %ld \n",(long)s1P->pos,(long)s1P->type,(long)s1P->dat);
				TUTORlog(msg);
				if ((s1P->type < 0) || (s1P->type >= NSTYLES))
					TUTORdump("bad style 1");
				s1P++;
			}
		}
		ReleasePtr(dP->styles);
	}
	ReleasePtr(doc);
	
} /* DumpStyles */


Memh NewTStyle()	/* create an empty style structure */
/* returns the new style structure */
	{
	Memh pd;	/* the style structure we are creating */
	REGISTER StyleDatP pp;	/* pointer into the style structure */
	register Style1 SHUGE *s1p;	/* pointer to styles */
	register int ii;
	
	/* allocate handle with space for initial styles */
	pd = TUTORhandle("StyleDat",(long) sizeof(StyleDat),TRUE);
	pp = (StyleDatP) GetPtr(pd);
	pp->prevBlock = 0;
	pp->hotList = HNULL;	/* no associated hot text yet */
	pp->nArrays = 1;
	pp->totalSize = sizeof(StyleDat);
	pp->offsets = ((char SHUGE *) &pp->sHead.dAnn) - ((char SHUGE *) &pp->prevBlock);
	pp->sHead.dAnn = NSTYLES;
	pp->sHead.dAnAlloc = NSTYLES;
	pp->sHead.nBuff = 10;
	
	/* every style structure has at least one style block for each kind of style.
		That style block is at position 0.  For all styles it starts out as DEFSTYLE */
	pp->sHead.itemSize = sizeof(Style1);
	s1p = ((Style1 SHUGE *) pp->styles);
	for (ii=0; ii<NSTYLES; ii++, s1p++)
		{
		pp->nStyles[ii] = 1;
		s1p->pos = 0L;
		s1p->type = ii;
		s1p->dat = DEFSTYLE; /* indicates default */
		}
	
	ReleasePtr(pd);
	KillPtr(pp);
	return(pd);
	}

CloseTStyle(pd) /* get rid of a style structure */
Memh pd;	/* handle to style structure */
/* no return */
	{
	REGISTER StyleDatP pp; /* pointer to style structure */
	
	pp = (StyleDatP) GetPtr(pd);
	if (pp->hotList)
		TUTORfree_handle(pp->hotList);
	ReleasePtr(pd);
	KillPtr(pp);
	TUTORfree_handle(pd);
	}

AtTStyle(pd,pos,styles) /* get styles at pos (including change at pos) */
Memh pd;	/* handle to style structure */
long pos;	/* position in document that we are looking at */
register short *styles; /* to be set to styles at pos */
/* returns index of next block (at or forward from pos) or -1 for no more styles */
	{
	StyleDatP pp;	/* pointer to style structure */
	register Style1 SHUGE *s1p;	/* pointer to styles */
	Style1 SHUGE *endP;	/* pointer to last style */
	int curBlock;	/* array index of block s1p is pointing at */
	int nFound;	/* count of styles that we have found current style for */
	register int ii;
	long pos0;	/* temporary copy of current position */
	char found[NSTYLES];	/* TRUE for each style when we've found current style */
	int retVal;
	
	pp = (StyleDatP) GetPtr(pd);
	nFound = 0;
	
	/* every style for which we have only 1 block is easy to find */
	for (ii=0; ii<NSTYLES; ii++)
		{
		if (pp->nStyles[ii] == 1)
			{ /* there is only one block for this type, which must be at position 0,
				so the relevant block is the iith block (due to sorting) */
			found[ii] = TRUE;	/* we've found the style for this type */
			styles[ii] = pp->styles[ii].dat;
			nFound++;
			}
		else
			found[ii] = FALSE;
		}

	if (nFound < NSTYLES)
		{ /* scan backwards till we have style for every type */
	
		curBlock = FindBlockTStyle(pp,pos);
		s1p = ((Style1 SHUGE *) pp->styles) + curBlock;
		/* note that s1p may be at beginning of sequence of blocks at the same position.
			We want it past this sequence so that we look at all the blocks in the sequence. */
	
		endP = ((Style1 SHUGE *) pp->styles) + pp->sHead.dAnn;
		pos0 = s1p->pos;
		while (s1p < endP && s1p->pos == pos0)
			s1p++; /* scan forward */
		s1p--; /* go back to last block in sequence at pos0 */
		curBlock = s1p - (Style1 SHUGE *)pp->styles;
	
		/* now we do the backwards scan */
		/* note that we are guaranteed to terminate because of the blocks for
			every type that are at position 0 */
		while (nFound < NSTYLES) /* while we haven't found everything... */
			{
			valid_style(s1p->type);
			if (!found[s1p->type])
				{
				styles[s1p->type] = s1p->dat;
				found[s1p->type] = TRUE;
				nFound++;
				}
			s1p--;
			}
		
		retVal = curBlock + 1;
		if (retVal >= pp->sHead.dAnn)
			retVal = -1; /* no more styles */
		} /* end of if nFound < NSTYLES */
	else
		{ /* every type is a single style, there must be no style blocks beyond
			the blocks at position 0 */
		retVal = -1; /* there can't be any blocks past pos */
		}
	
	ReleasePtr(pd);
	KillPtr(pp);
	
	return(retVal);
	}

AddTStyle(pd, start, len, docLen, type, newDat, combF) /* add a new style */
Memh pd;	/* style structure we are adding to */
long start,len; /* bounds of new style */
long docLen;	/* size of document */
register int type; /* which kind of style (font, size, face, para, color or hot) */
int newDat; /* new data */
			/* for a HOTSTYLE this is index to hottext already added with AddHotList */
int combF;	/* for FACESTYLE, 1: xor, -1: or, 0 replace */
			/* for size - TRUE if size change is relative */
			/* for para - mask of portion of style (invis, just, layout) that is
				changing, or 0 if we are changing the whole style */
	{
	StyleDatP pp;	/* pointer to style structure */
	int curBlock;	/* index of block we are looking at (s1p) */
	int prevBlock;	/* index of block preceeding curBlock */
	register Style1 SHUGE *s1p; /* pointer to style data (usually at curBlock) */
	register Style1 SHUGE *s1p2;	/* temporary pointer to style data */
	int ii, jj;
	short restoreStyle;	/* the style we need to place at start+len */
	short newStyle;	/* the style we need to add at the current position */
	long curPos;	/* current position */
	register long send;  /* start+len */
	
	/*
	AddTStyle is the routine that makes changes to the style structure.  Even getting rid
	of a style is "adding" a style - you add a DEFSTYLE over the area where there was
	a style before.
	
	The style data structure has blocks of styles of various types all mixed together.
	When we add a style of a particular type it is important that we change only those
	blocks of the given type.  This is just a complicating detail.
	
	Another, more important, complicating detail is that we make sure that there are
	never two succesive blocks of the same type that have the same data.  This
	guarantees that all blocks truly represent actual changes and simplifies code
	elsewhere, as well as minimizing storage.
	
	The algorithm for adding a style is straightforward.
		1) Find out what the style currently is at start, save that as restoreStyle
		2) At start put in a block with the new style.
		3) scan thru the styles to start+len.  Change each style to the new style.
		4) Whenever a the newly changed block has the same style as the preceeding
			block, delete the newly changed block
		5) At start+len put in a block with the style restoreStyle
	
	This is complicated by the fact that the style we are applying can combine
	with the existing styles.  Then the style blocks we put in are actually some
	combination (calculated by CombineStyles)
	*/
	
	if (docLen == 0)
		return(0); /* styles are gone because document is gone */

	if (len <= 0)
		return(TRUE); /* nothing to do */
	
	pp = (StyleDatP) GetPtr(pd);
	
#ifdef DOCVERIFY
	CheckOrdering(pp,"AddTStyle0");
#endif

	/* curBlock is index of block of style type that is in effect at pos */
	curBlock = FindBlockTypeTStyle(pp,start,type);
	
	send = start+len;
	
	/* find prevBlock (block of type that immediately preceeds curBlock) */
	if (curBlock < NSTYLES) /* curBlock is one of the blocks at position 0 */
		prevBlock = -1; /* no previous */
	else
		{ /* scan backwards to find previous block */
		s1p = ((Style1 SHUGE *) pp->styles) + curBlock;
		s1p--; /* start looking at previous block */
		while (s1p->type != type)
			s1p--; /* back up till we find another of correct type */
		prevBlock = s1p - (Style1 SHUGE *)pp->styles;
		}
	
	/* special check for FACESTYLE to see if we can really xor */
	/* FACESTYLEs can only xor if there are no style changes within the range
		start to start+len */
	if (type == FACESTYLE && combF == 1)
		{
		if (newDat)
			{ /* the style being applied is not plain, check for changes */
			s1p2 = s1p = ((Style1 SHUGE *) pp->styles) + curBlock;
			ii = curBlock;
			while (s1p2->pos < send && ii < pp->sHead.dAnn)
				{ /* scan for style changes in range */
				if (s1p2->type == FACESTYLE && s1p2->dat != DEFSTYLE)
					{
					if ((s1p2->dat & newDat) != (s1p->dat & newDat))
						{ /* found a style change - can't xor */
						combF = 0;
						break;
						}
					}
				s1p2++;
				ii++;
				}
			}
		else
			combF = 0; /* plain never xors */
		}
	
	/*
		now look over entire range of change.  At the start we may insert a new style
		block.  Otherwise we just replace the styles with the new style.  In either
		case the style dat to be put in depends both on the argument newDat and on
		what the style currently is (see CombineStyles).  Then, once the data has
		been added or changed we check for redundant blocks by seeing if the current
		block has the same style as the previous one.  Redundant blocks are deleted.
	*/
	/*	We have to do some special handling of hot styles to handle an odd case.
		Normally when a new style splits an existing style we just duplicate the
		style.  We can't do this for hot styles because of the connection between
		the hot style data and a piece of memory somewhere.  (For instance, we might
		later on delete one of the split hot styles.  So that we don't delete
		the hot style data incorrectly we'd need usage counts, etc.).  So when
		a hot text is split we set the style of the second portion to DEFSTYLE.
		In effect the hot style shrinks to cover only the part before the split.
	*/

	curPos = start;
	s1p = ((Style1 SHUGE *) pp->styles) + curBlock;
	
	if (type == HOTSTYLE)
		{ /* restoreStyle remembers id of hot text that may possibly be deleted */
		restoreStyle = DEFSTYLE;
		}
	
	while (curPos  < send)
		{
		if (type == HOTSTYLE && restoreStyle != DEFSTYLE)
			{ /* we are completely forgetting about some hot style, delete the text */
			DeleteHotList(pp->hotList,restoreStyle);
			}
		
		if (type != HOTSTYLE || s1p->pos == curPos)
			restoreStyle = s1p->dat; /* normal case */
		else
			{ /* HOTSTYLE at start.  We will be inserting a new block, in this
				case we will never completely delete a style range.  To make sure
				that we don't delete the text of a range with DeleteHotList above
				we set restoreStyle to DEFSTYLE.   This also has the desired effect of
				collapsing a split hot area to the first piece.  It is a safe
				manipulation only because each hot area will always have a distinct
				dat field, the id of the text */
			restoreStyle = DEFSTYLE;
			}
		
		/* calculate new style to be put in the current position */
		newStyle = CombineStyles(type,restoreStyle,newDat, combF);
		
		if (s1p->pos == curPos)
			{ /* replace existing style */
			s1p->dat = newStyle;
			}
		else
			{ /* insert a new block (will only happen at start) */
			/* find correct place to insert style */
				/* so that we maintain order by position and style type */
			ii = 1;
			s1p2 = ((Style1 SHUGE *) pp->styles) + curBlock+1;
			while (curBlock+(long)ii < pp->sHead.dAnn && (s1p2->pos < start ||
					(s1p2->type < type && s1p2->pos == start)))
				{
				ii++;
				s1p2++;
				}
			
			ReleasePtr(pd);
			KillPtr(pp);
			TUTORinsert_darray(pd,FARNULL,STYLEOFFSET,0,curBlock+ii,1);
			/* get pointers back */
			pp = (StyleDatP) GetPtr(pd);
			s1p = ((Style1 SHUGE *) pp->styles) + (curBlock + ii);
			
			(pp->nStyles[type])++;
			s1p->dat = newStyle;
			s1p->pos = start;
			s1p->type = type;
			prevBlock = curBlock;
			curBlock += ii;
			}

#ifdef DOCVERIFY
	CheckOrdering(pp,"AddTStyle1");
#endif

		if (prevBlock >= 0 && pp->styles[prevBlock].dat == s1p->dat)
			{ /* adjacent blocks with same data, delete current */
				/* note that we don't delete underlying hot text.  We are compressing
					two blocks with the same style into one.  We will still want
					the hot text for that new one style block */
			KillTStyle(pd,pp,curBlock,1,FALSE);

			(pp->nStyles[type])--;
			curBlock--; /* back up to account for lost block */
			s1p--;
			/* note that in this case prevBlock doesn't get changed */
			}
		else
			prevBlock = curBlock;
		
		/* get next curBlock */
		/* usually next curBlock is the next block of the type we are working on
			but if we can't find another in the range of the change we want
			curBlock to be set to where we will insert a recovery block, maintaining
			position and type sort order */
		curBlock++;
		s1p++;
		while (curBlock < pp->sHead.dAnn && s1p->pos <= send)
			{
			if (s1p->type == type)
				break;
			if (s1p->pos == send && s1p->type > type)
				break;
			curBlock++;
			s1p++;
			}
			
		if (curBlock >= pp->sHead.dAnn)
			break; /* no more blocks */
		
		curPos = s1p->pos; /* current position is position of the next block */
		}
	
#ifdef DOCVERIFY
	CheckOrdering(pp,"AddTStyle2");
#endif

	if (curBlock >= pp->sHead.dAnn || s1p->type != type || s1p->pos != send)
		{  /* add block representing recovery from new style */
		ReleasePtr(pd);
		KillPtr(pp);
		TUTORinsert_darray(pd,FARNULL,STYLEOFFSET,0,curBlock,1);
		/* recover pointers (pd was unlocked in insert_darray) */
		pp = (StyleDatP) GetPtr(pd);
		s1p = ((Style1 SHUGE *) pp->styles) + curBlock;
		
		(pp->nStyles[type])++;
		s1p->dat = restoreStyle;
		s1p->pos = send;
		s1p->type = type;
		}

#ifdef DOCVERIFY
	CheckOrdering(pp,"AddTStyle3");
#endif

	/* s1p & curBlock refer to the recovery block, either one we added or
		a block that started at the end of our change.  prevBlock refers to
		the last style within the change region */
	
	if (s1p->dat == pp->styles[prevBlock].dat)
		{ /* recovery block is redundant, get rid of it */
		KillTStyle(pd,pp,curBlock,1,FALSE);
		(pp->nStyles[type])--;
		curBlock = prevBlock;
		s1p = (Style1 SHUGE *) pp->styles + curBlock;
		}
	
	/* s1p & curBlock refer to the block in effect at the end of change range */
	
#ifdef DOCVERIFY
	CheckOrdering(pp,"AddTStyle4");
#endif

	if (type == HOTSTYLE && restoreStyle == DEFSTYLE)
		{ /* because HOTSTYLE can have a DEFSTYLE recovery when normally there would be
			a non-zero, we may have put in a DEFSTYLE recovery block which will be followed
			be a DEFSTYLE hotstyle.  Check for this */
		s1p2 = s1p+1;
		ii = 1;
		while (curBlock+ii < pp->sHead.dAnn && s1p2->type != HOTSTYLE)
			{
			s1p2++;
			ii++;
			}
		if (curBlock+ii < pp->sHead.dAnn && s1p2->dat == DEFSTYLE)
			{ /* redundant block, delete it */
			KillTStyle(pd,pp,curBlock+ii,1,FALSE);
			}
		}
	
	/* get rid of any styles at or after document end */
	if (pp->sHead.dAnn) {
		s1p = ((Style1 SHUGE *) pp->styles) + (pp->sHead.dAnn-1); /* last style */
		while (s1p->pos >= docLen)
			{
			valid_style(s1p->type);
			if (s1p == pp->styles)
				break;
			if ((s1p->type >= 0) && (s1p->type < NSTYLES))
				(pp->nStyles[s1p->type])--;
			s1p--;
			}
		valid_style(s1p->type);
		pp->sHead.dAnn = (s1p - (Style1 SHUGE *)pp->styles) + 1;
	}
	
#ifdef DOCVERIFY
	if (pp->sHead.dAnn < NSTYLES)
		TUTORdump("Too few styles 1");
	CheckOrdering(pp,"AddTStyle5");
#endif

	if (type == HOTSTYLE)
		TUTORcompress_darray(pp->hotList,HOTOFFSET);

	ReleasePtr(pd);
	KillPtr(pp);
	
	return(0);
	}

int CombineStyles(type, oldStyle, newDat, combF)
int type; /* style type */
register int oldStyle; /* current style */
register int newDat; /* data being added */
int combF; /* for FACESTYLE, 1: xor, -1: or, 0 replace */
			/* for SIZESTYLE, whether we add new size to old (i.e. whether change is relative) */
			/* for para - which field, 0: all, else by mask */
	{
	if (newDat == DEFSTYLE)
		return(DEFSTYLE);
	
	switch (type)
		{
		case FACESTYLE:
			if (oldStyle == DEFSTYLE)
				oldStyle = 0; /* DEFSTYLE combines as plain */
			
			if (combF == 1) /* xor */
				newDat = oldStyle ^ newDat;
			else if (combF == -1)
				{ /* or */
				newDat = newDat ? (oldStyle | newDat) : 0;
				}
			/* else simple replace, newDat not modified */
			
			break;
		
		case SIZESTYLE:
			/* Note that we don't do bigger/smallers on absolute sizes */
			if (combF)
				{
				if (oldStyle == DEFSTYLE)
					oldStyle = 0; /* DEFSTYLE combines as "not bigger nor smaller" */
				else if (oldStyle <= ABSSIZE)
					{ /* change oldStyle into a size bigger or smaller than 13 */
					oldStyle = -((oldStyle - ABSSIZE)*100)/13 - 100;
					}
				newDat += oldStyle;
				}
			if (!newDat)
				newDat = DEFSTYLE;
			break;
		
		case PARASTYLE:
			if (combF)
				{
				if (oldStyle == DEFSTYLE)
					{ /* DEFSTYLE combines as default layout, left justified, visible */
					oldStyle = PARADEFAULT | LEFTJUST;
					}
				newDat = (oldStyle & ~combF) | (newDat & combF);
				if (newDat == PARADEFAULT | LEFTJUST)
					newDat = DEFSTYLE;
				}
			/* else we don't do anything */
			break;
		
		default:
			break;
		}
	return(newDat);
	}

AddHotTStyle(pd,start,len,docLen,ss,sLen)	/* add a hot style */
Memh pd;	/* the style structure we are changing */
long start,len;	/* where style goes */
long docLen;	/* length of document */
unsigned char FAR *ss;	/* the hot text info string */
long sLen;	/* the length of ss */
	{
	int id;	/* the id assigned to this hot text */
	StyleDatP pp;	/* pointer at style structure (pd) */
	
	pp = (StyleDatP) GetPtr(pd);
	if (!pp->hotList)
		{
		pp->hotList = NewHotList();
		}
	
	/* attempt to add text */
	id = AddHotList(pp->hotList,ss,sLen);

	ReleasePtr(pd);
	KillPtr(pp);
	
	if (id)
		{
		AddTStyle(pd,start,len,docLen,HOTSTYLE,id,FALSE);
		return(TRUE);
		}
	else
		return(FALSE); /* couldn't add style */
	
	}

CheckKeepTStyle(pd) /* check if pd has only default styles */
Memh pd;	/* the style structure we are checking */
	{
	register int jj;
	register int ii;
	REGISTER StyleDatP pp;
	
	pp = (StyleDatP) GetPtr(pd);
#ifdef DOCVERIFY
	if (pp->sHead.dAnn < NSTYLES)
		TUTORdump("Too few styles 2");
#endif
	/* check if there are still styles */
	jj = TRUE; /* indicates that there are still styles */
	if (pp->sHead.dAnn == NSTYLES)
		{ /* we have minimum # of styles, check if they are all default */
		for (ii=0; ii<NSTYLES; ii++)
			if (pp->styles[ii].dat != DEFSTYLE)
				break; /* not default */
		if (ii >= NSTYLES)
			jj = FALSE; /* all styles are default */
		}
	ReleasePtr(pd);
	KillPtr(pp);
	
	return(jj);
	}

/* adjust styles for insertion of characters in document: */
InsertTStyle(pd,start,len,expandEnd)
Memh pd;	/* style structure */
register long start;	/* where insertion starts */
register long len;		/* length of insertion */
register int expandEnd; /* if TRUE we push styles AT start (except paragraph style)
							forward by len */
	{
	StyleDatP pp;	/* pointer to style structure (pd) */
	unsigned short curBlock;	/* index of the current style block we are considering */
	register Style1 SHUGE *s1p;	/* pointer to current style (indexed by curBlock) */
	register Style1 SHUGE *endP;	/* pointer to last style block */
	Style1 SHUGE *tempP;	/* scratch, for remembering a value of s1p */
	Style1 tempStyle;
	
	if (!pd || len == 0)
		return(0);

	if (start == 0)
		expandEnd = FALSE; /* can't push blocks at 0 forward */

	pp = (StyleDatP) GetPtr(pd);
	curBlock = FindBlockTStyle(pp,start);
	s1p = ((Style1 SHUGE *) pp->styles) + curBlock;
	endP = ((Style1 SHUGE *) pp->styles) + pp->sHead.dAnn;
	while (s1p < endP && s1p->pos < start)
		s1p++; /* scan to blocks at or after pos */
	
	if (expandEnd && s1p < endP && s1p->pos == start)
		{ /* look for paragraph style at position start */
		tempP = s1p; /* remember original s1p */
		while (s1p < endP && s1p->pos == start)
			{
			if (s1p->type == PARASTYLE)
				break; /* found a paragraph style */
			s1p++;
			}
		if (s1p < endP && s1p->type == PARASTYLE && s1p->pos == start)
			{
			if (s1p == tempP)
				s1p++; /* paragraph style was first one, just skip it */
			else
				{ /* to preserve ordering we have to delete the paragraph style
						from where it is and reinsert it before all the other
						styles at position start */
				tempStyle = *s1p; /* remember the style */
				KillTStyle(pd,pp,s1p - (Style1 SHUGE *) (pp->styles),1,TRUE);
				TUTORinsert_darray(pd,(char SHUGE *) pp,STYLEOFFSET,0,
									tempP - (Style1 SHUGE *) (pp->styles),1);
				*tempP = tempStyle;
				s1p = tempP+1; /* start work after paragraph style */
				}
			}
		else
			s1p = tempP; /* didn't find paragraph style at start, nothing to do */
		}
	
	while (s1p < endP)
		{
		if (s1p->pos > start || expandEnd)
			s1p->pos += len;
		s1p++;
		}

#ifdef DOCVERIFY
	CheckOrdering(pp,"InsertTStyle");
#endif

	ReleasePtr(pd);
	KillPtr(pp);
	
	return(0);
	}

DeleteTStyle(pd,start,len) /* modify styles for deletion of chars in document */
Memh pd;	/* style structure */
register long start,len;	/* where characters were deleted in document */
	{
	StyleDatP pp;	/* pointer to style structure */
	register Style1 SHUGE *s1p, SHUGE *s1p2;	/* pointers to style blocks */
	register Style1 SHUGE *endP;	/* pointer to last style block */
	short restoreStyles[NSTYLES];	/* to keep track of styles we will put back */
	unsigned short curBlock;	/* index of current style block */
	char doRestore[NSTYLES];	/* to flag which styles need recovery */
	register int ii;
	int firstDelete;	/* index of first block to delete */
	
	if (!pd || len == 0)
		return 0;
	
	/* blocks in the range of the delete are destroyed.  At the end of the delete
		range we recover every style.  Blocks past the range are moved back */
	
	pp = (StyleDatP) GetPtr(pd);
	curBlock = FindBlockTStyle(pp,start);
	s1p = ((Style1 SHUGE *) pp->styles) + curBlock;
	endP = ((Style1 SHUGE *) pp->styles) + pp->sHead.dAnn; /* just past last block */
	while (s1p < endP && s1p->pos < start)
		s1p++; /* scan to blocks at or after pos */
	
	if (s1p < endP)
		{
		valid_style(s1p->type);
		for (ii=0; ii<NSTYLES; ii++)
			doRestore[ii] = FALSE; /* initialize doRestore */
		firstDelete = s1p - (Style1 SHUGE *)pp->styles;
		while (s1p < endP && s1p->pos < start+len)
			{ /* we want to remember any style starting in the deleted area */
				/* note that we only remember the last style for each type */
			if (s1p->type == HOTSTYLE && doRestore[HOTSTYLE] && s1p->dat == DEFSTYLE)
				{ /* we have found the end of a hotstyle that we are completely
						deleting, delete the hot text */
				DeleteHotList(pp->hotList,restoreStyles[HOTSTYLE]);
				}
			doRestore[s1p->type] = TRUE;	/* we need restoration for this type */
			restoreStyles[s1p->type] = s1p->dat;
			(pp->nStyles[s1p->type])--;
			s1p++;
			}
		
		/* now delete unneeded blocks (those whose position is within delete range) */
		ii = s1p - (Style1 SHUGE *)pp->styles; /* index of first block to not delete */
		ii -= firstDelete; /* # of blocks to delete */
		KillTStyle(pd,pp,firstDelete,ii,FALSE);
		s1p -= ii; /* compensate for deleted blocks */
		endP -= ii;
		
		/* s1p is now pointing at first block at or after start+len, or
			past the last block */
		/* we are at the end of the deletion area.  We will be putting
			any needed restoration blocks here.  An existing block starting
			at exactly start+len will, in effect, be our restoration block
			and we don't need to add another.  Either an existing block
			used for restoration, or one we add may have the same style as
			the preceeding block of this type.  We have to search back to
			find that preceeding block so that we can check */
	
		for (ii=0; ii<NSTYLES; ii++)
			{ /* for each style */
			if (!doRestore[ii] && (s1p >= endP ||
					(s1p->pos > start+len || s1p->type > ii)))
				{
				continue; /* nothing to do for this type */
				}
			/* either we are restoring or s1p->type == ii && s1p->pos == start+len 
					(which is for deleting newly redundant blocks) */
			
			if (s1p >= ((Style1 SHUGE *) pp->styles)+NSTYLES)
				{ /* look for preceeding block of this type */
				s1p2 = s1p-1;
				while (s1p2->type != ii)
					s1p2--;
				}
			else
				s1p2 = FARNULL;
			if (s1p < endP && s1p->pos == start+len && s1p->type == ii)
				{ /* have block of this type */
				if (s1p2 && s1p2->dat == s1p->dat)
					{ /* delete the redundant block (the one we just added) */
					KillTStyle(pd,pp,(int) (s1p-(Style1 SHUGE *)pp->styles),1,FALSE);
					(pp->nStyles[ii])--;
					/* note that s1p is now pointing at following block, as desired */
					endP--;
					}
				else
					{
					s1p->pos -= len;
					s1p++; /* get to next style */
					}
				}
			else if (!s1p2 || (restoreStyles[ii] != s1p2->dat))
				{ /* we need a new restoration block */
				/* note that we never insert unless we previously deleted,
					so we know that there is already space */
				TUTORinsert_darray(pd,(char FAR *) pp,STYLEOFFSET,0,(int) (s1p - (Style1 SHUGE *)pp->styles),1);
				(pp->nStyles[ii])++;
				s1p->type = ii;
				s1p->dat = restoreStyles[ii];
				s1p->pos = start;
				s1p++;
				endP++;
				}
			}
		
		/* s1p is now pointing at first block past all the action */		
		/* all the blocks that are after the delete area need to be shifted */
		endP = ((Style1 SHUGE *) pp->styles) + pp->sHead.dAnn;
		while (s1p < endP)
			{
			valid_style(s1p->type);
			s1p->pos -= len;
			s1p++;
			}
		}
	/* else delete is past last block - nothing to do */
	
#ifdef DOCVERIFY
	if (pp->sHead.dAnn < NSTYLES)
		TUTORdump("Too few styles 3");
	CheckOrdering(pp,"DeleteTStyle");
#endif

	ReleasePtr(pd);
	KillPtr(pp);
	return(0);
	}

/* take styles from one style structure and put them into another style structure: */
SpliceTStyle(pd,sourcePd,toStart,fromStart,fromLen,docLen)
Memh pd; /* style structure to be changed (destination) */
Memh sourcePd; /* style structure from which we take styles (source) */
long toStart; /* position (in document of pd) where styles are being added */
long fromStart,fromLen; /* text positions (in document of sourcePd) to copy styles from */
long docLen;	/* length of document (of pd) */
	{
	/* a crude implementation:
		InsertTStyle to get space, then
		AddTStyle of each new style in the right place
	a better implementation would directly splice the data structures */

	StyleDatP sourcepP;	/* pointer to style structure of sourcepd */
	StyleDatP pp;	/* pointer to style structure of pd */
	register Style1 SHUGE *newS, SHUGE *sEnd; /* current & last style block of sourcePd */
	Style1 SHUGE *s1p;	/* pointer to style block in pd */
	Memh hotList;	/* the hot list of pd (which existed or is being created) */
	char hadHot;	/* TRUE if pd had hotlist before this routine */
	int addStyle;	/* TRUE if we want to add the current style to pd */
	short curDat[NSTYLES];	/* current accumulated style */
	short newStyle;	/* the style we may add */
	register int ii;
	long oldPos[NSTYLES]; /* positions where we will start next style of each type */
	long offset;	/* to convert positions from sourcePd to pd */
	long tempL;
	
#ifdef DOCVERIFY
	sourcepP = (StyleDatP) GetPtr(sourcePd);
	if (sourcepP->sHead.dAnn <= 0)
		TUTORdump("bad style 2");
	ReleasePtr(sourcePd);
#endif
			
	InsertTStyle(pd,toStart,fromLen,TRUE);
	
	AtTStyle(sourcePd,fromStart,curDat); /* get styles at fromStart in sourcePd */
	for (ii=0; ii<NSTYLES; ii++)
		{
		oldPos[ii] = fromStart;
		}
	
	/* now get pointer to additional styles in sourcePd */
	
	sourcepP = (StyleDatP) GetPtr(sourcePd);
	ii = FindBlockTStyle(sourcepP,fromStart);
	newS = ((Style1 SHUGE *) sourcepP->styles) + ii; /* points to first block before or at fromStart */
	sEnd = ((Style1 SHUGE *) sourcepP->styles) + sourcepP->sHead.dAnn; /* points just past last valid style1 block */
	while (newS < sEnd && newS->pos <= fromStart)
		newS++; /* get newS to point to next block following fromStart */
	
	if (sourcepP->hotList)
		{ /* there is possiblity of hot text being passed */
		pp = (StyleDatP) GetPtr(pd);
		hotList = pp->hotList;
		if (hotList)
			{ /* we have a hotList already.  Since we don't want hotstyles to be split
					we have to see if there is a non-default hotstyle extending over the
					insertion point.  If there is the portion of it that follows the
					insertion point will have to be changed to DEFSTYLE */
			ii = FindBlockTypeTStyle(pp,toStart,HOTSTYLE);
			s1p = (Style1 SHUGE *) pp->styles + ii;
			/* note that because of the InsertTStyle that has already been done at
				position toStart, s1p must be referring to a block that extends over
				the insertion position */
			if (s1p->dat != DEFSTYLE)
				{ /* we need to change style */
				/* find the next HOTSTYLE block */
				s1p++;
				ii++;
				while (ii < pp->sHead.dAnn)
					{
					if (s1p->type == HOTSTYLE)
						break;
					valid_style(s1p->type);
					ii++;
					s1p++;
					}
				tempL = (ii < pp->sHead.dAnn) ? s1p->pos : docLen;
				tempL -= toStart; /* convert position to len from toStart */
				ReleasePtr(pd);
				KillPtr(pp);
				AddTStyle(pd,toStart,tempL,docLen,HOTSTYLE,DEFSTYLE,FALSE);
				}
			else
				{
				ReleasePtr(pd);
				KillPtr(pp);
				}
			}
		else
			{
			ReleasePtr(pd);
			KillPtr(pp);
			}
		hadHot = hotList ? TRUE : FALSE;
		}
	else
		{ /* we won't be adding hot text (note that all sourcepP HOTSTYLE is DEFSTYLE) */
		hotList = HNULL;
		hadHot = FALSE;
		}
	
	offset = toStart - fromStart;
	while (newS < sEnd && newS->pos < fromStart+fromLen)
		{ /* add style blocks */
		/* for each block we add the style of the PREVIOUS block of the same type */
		addStyle = TRUE;
		if (newS->type == HOTSTYLE)
			{
			addStyle = SpliceHotText(&hotList,sourcePd,&curDat[HOTSTYLE]);
			}

		if (addStyle)
			{
			newStyle = curDat[newS->type];
			AddTStyle(pd,oldPos[newS->type]+offset, newS->pos-oldPos[newS->type],docLen,newS->type,
						newStyle,0);
			}
		oldPos[newS->type] = newS->pos;
		curDat[newS->type] = newS->dat;
		newS++;
		}
	
	/* now, for every style, put in style up to end,
		this will also put in styles that had only 1 value in sourcePd */
	for (ii=0; ii<NSTYLES; ii++)
		{
		addStyle = TRUE;
		if (ii == HOTSTYLE)
			{
			addStyle = SpliceHotText(&hotList,sourcePd,&curDat[HOTSTYLE]);
			}
		AddTStyle(pd,oldPos[ii]+offset,fromStart+fromLen-oldPos[ii],docLen,
				ii,curDat[ii],0);
		}
	
#ifdef DOCVERIFY
	CheckOrdering(sourcepP,"SpliceTStyle");
#endif

	if (!hadHot && hotList)
		{ /* add new hot list */
		pp = (StyleDatP) GetPtr(pd);
#ifdef DOCVERIFY
		if (pp->hotList)
			TUTORdump("Leaking hot text");
#endif
		pp->hotList = hotList;
		ReleasePtr(pd);
		KillPtr(pp);
		}
	
	ReleasePtr(sourcePd);
	KillPtr(sourcepP);
	
	return 0;
	}

static SpliceHotText(hotList,pd,hotDat) /* helper routine for SpliceTStyle, handles hottext */
Memh *hotList;	/* hot list that is being modified (may be created here) */
Memh pd;	/* style structure of source of hot data */
short *hotDat;	/* the style data of the hot style being spliced */
/* returns TRUE if we can add a style */
	{
	int addStyle; /* the return value */
	unsigned char FAR *utp; /* pointer to hot text info string */
	long hotLen;	/* length of hot text info string */
	long spos, slen;	/* position & length of hot text (in document of pd) */
	
	if (!*hotList && *hotDat != DEFSTYLE)
		{ /* create new hot list */
		*hotList = NewHotList();
		}
	
	if (*hotDat == DEFSTYLE)
		return(TRUE); /* just go ahead & add default style */
	
	utp = GetHotstringTStyle(pd,*hotDat, &hotLen, &spos, &slen, TRUE);
	if (utp)
		{
		*hotDat = AddHotList(*hotList,utp,hotLen);
		TUTORdealloc((char FAR *) utp);
		}
	else
		*hotDat = 0;
	
	if (*hotDat == 0)
		addStyle = FALSE; /* couldn't add hot text */
	else
		addStyle = TRUE;
	
	return(addStyle);
	}

static KillTStyle(pd,pp,ind,nn,killHot) /* helper routine.  Destroys style blocks */
Memh pd;	/* style structure we are modifying */
register StyleDatP pp;	/* pointer to pd */
register int ind;	/* index of 1st style block we want to destroy */
register int nn;	/* the number of style blocks to be destroyed */
int killHot;	/* if TRUE, kill associated hot text */
	{
	register int ii;
	register Style1 SHUGE *s1p;	/* pointer to style blocks */
	
	if (killHot && pp->hotList)
		{ /* check to delete hot styles */
		s1p = (Style1 SHUGE *) pp->styles + ind;
		for (ii=0; ii<nn; ii++, s1p++)
			if (s1p->type == HOTSTYLE && s1p->dat > 0)
				{ /* delete the hot style data */
				DeleteHotList(pp->hotList,s1p->dat);
				}
		}
	
	TUTORdelete_darray(pd,(char FAR *) pp,STYLEOFFSET,0,ind,nn);
	}

FindBlockTypeTStyle(pp,ps,type) /* find block by position and type */
StyleDatP pp;	/* pointer to style strucutre */
long ps;	/* position */
register int type;	/* kind of style we are looking for */
/* returns block of type AT or before ps */
	{
	register Style1 SHUGE *s1p, SHUGE *s1p2;	/* pointers to style blocks */
	Style1 SHUGE *endP;	/* pointer to last style block of structure */
	register int blockN;	/* index of current block */
	register int endN;	/* indices of last style block + 1 */
	
	if (pp->nStyles[type] == 1)
		return(type); /* only one block, the first one at 0 */

	blockN = FindBlockTStyle(pp,ps); /* get block closest to position */
	s1p = ((Style1 SHUGE *) pp->styles) + blockN;
	
	/* we need to check if our type is also at position of block blockN */
	s1p2 = s1p;
	endN = pp->sHead.dAnn;
	while (blockN < endN && s1p2->pos == s1p->pos)
		{
		if (s1p2->type == type)
			return((int) (s1p2 -(Style1 SHUGE *) pp->styles));
		s1p2++;
		blockN++;
		}
	/* otherwise, scan backwards till we hit our type */
	while (s1p->type != type)
		s1p--;
	
	return((int) (s1p - (Style1 SHUGE *)pp->styles));
	}

FindBlockTStyle(pp,pos) /* find block by position */
StyleDatP pp;	/* pointer to style structure */
register long pos; /* position */
/* returns first block at position before or at pos */
	{
	register Style1 SHUGE *bot, SHUGE *top, SHUGE *mid; /* pointers to style blocks 
													(for binary search) */
	int posInd;	/* index of some block at the right position */
	
	if (pos == 0L)
		return(0);
	
	/* find a block at pos, or the last one before pos */
	top = ((Style1 SHUGE *) pp->styles) + (pp->sHead.dAnn-1);
	if (pos >= top->pos)
		posInd = top - (Style1 SHUGE *)pp->styles;
	else
		{ /* have to do binary search */
		bot = ((Style1 SHUGE *) pp->styles) + (NSTYLES-1); /* last block at position 0 */
	
		while(bot <= top)
			{
			mid = bot + (top-bot)/2;
		
			if (mid->pos == pos)
				{
				break; /* found exact match! */
				}
			if (mid->pos < pos)
				bot = mid+1;
			else
				top = mid-1;
			}
		if (mid->pos > pos)
			mid--; /* we're one too high */
		posInd = mid - (Style1 SHUGE *)pp->styles;
		}
	
	/* posInd now contains address of block at proper position.  Now scan back until
		we find the first block at that position */
	mid = ((Style1 SHUGE *) pp->styles) + posInd;
	bot = mid - 1;
	while (bot->pos == mid->pos)
		bot--;
	
	return(1 + (int) (bot - (Style1 SHUGE *)pp->styles));
	}

#ifdef DOCVERIFY
CheckOrdering(pp,ss) /* verify that style blocks are ordered correctly */
StyleDatP pp;	/* pointer to style structure */
char *ss;	/* string giving caller's name */
	{
	register Style1 SHUGE *s1p;	/* pointer to current style block */
	register Style1 SHUGE *s1End;	/* pointer to last style block */
	register int lastType;	/* most recently encountered style type */
	register long lastPos;	/* position of most recently encountered block */
	char tempS[100];	/* scratch for creating error message */
	int lastHot; /* last hot id we've seen */
	
	lastHot = DEFSTYLE; /* no hot id seen so far */
	
	s1p = ((Style1 SHUGE *) pp->styles);
	s1End = s1p + pp->sHead.dAnn - 1;
	
	lastType = s1p->type;
	lastPos = s1p->pos;
	if (s1p->type == HOTSTYLE && s1p->dat != DEFSTYLE)
		lastHot = s1p->dat;
	
	s1p++;
	
	while (s1p <= s1End)
		{
		if (s1p->pos < lastPos || (s1p->pos == lastPos && s1p->type < lastType))
			{ /* ordering error */
			sprintf(tempS,"TStyle ordering error %s",ss);
			TUTORdump(tempS);
			}
		if (s1p->type == HOTSTYLE)
			{
			if (s1p->dat == 0)
				TUTORdump("0 hotstyle?");

			if (s1p->dat != DEFSTYLE)
				{
#ifdef CHECKHOT
	/* this check will fail at AddTStyle1 even in cases where it shouldn't.  This is
		because at that point we may expect succesive blocks with the same data, which
		will then be cleaned up later on in AddTStyle */
				if (s1p->dat == lastHot)
					{
					sprintf(tempS,"Redundant hotstyle %s",ss);
					TUTORdump(tempS);
					}
#endif
				lastHot = s1p->dat;
				}
			}
		lastPos = s1p->pos;
		lastType = s1p->type;
		s1p++;
		}
	
	return(0);
	}

#endif

/* ksw-documentation  hot text
	All of the hot text for a document is stored in a single handle,
	the hot text handle, which is itself stored in the styles structure
	of the document.  The hot text handle has two variable length arrays in
	it.  The second array is just all the text.  The first is a list of
	positions, lengths and ids of the various pieces of hot text.
	These are postions and lengths relative in the first (the text) array.
	The ids are what associates a given hot text with the document.  The
	data of the hot text style (stored in the doc's style structure) is a
	unique id #.  This id # is one of the id numbers in the hot text handle's
	first table.
	Note that, therefore, there is no relation between position of the hot
	text style in the document and position of the hot text itself in
	the hot text handle.
	
	This entire implementation is somewhat unsatisfactory.  There are, here
	and there, a lot of complications due to the hot text being stored as
	one seperate blob for the whole document.  It does, however, have the virtue
	of cutting down the number of handles the memory manager will have to deal
	with and allowing for the possibility of the hot text itself being a
	document (namely having styles) rather than just text.
	
	An alternative implementation would be to have each piece of hot text stored
	in a seperate handle.  The the data field of the hot text style (in
	the document's style handle) would just be that handle.  Simpler, but
	more handles.
*/

Memh NewHotList()
/* returns new hot list handle */
	{
	Memh hl;	/* the hot list handle */
	REGISTER HotList FAR *hlp;	/* pointer to hot list structure */
	register int ii;
	
	/* allocate handle with space for initial styles */
	hl = TUTORhandle("HotList",(long) sizeof(HotList),TRUE);
	hlp = (HotList FAR *) GetPtr(hl);
	hlp->nextid = 1;
	hlp->nArrays = 2;
	hlp->totalSize = sizeof(HotList);
	hlp->offsets[0] = ((char FAR *) &hlp->listhead.dAnn) - ((char FAR *) hlp);
	hlp->offsets[1] = ((char FAR *) &hlp->texthead.dAnn) - ((char FAR *) hlp);
	hlp->listhead.dAnn = 0;
	hlp->listhead.dAnAlloc = 1;
	hlp->listhead.nBuff = 3;
	hlp->listhead.itemSize = sizeof(HotL1);
	hlp->texthead.dAnn = 0;
	hlp->texthead.dAnAlloc = 20;
	hlp->texthead.nBuff = 100;
	hlp->texthead.itemSize = 1;
	
	ReleasePtr(hl);
	KillPtr(hlp);
	return(hl);
	}

CloseHotList(hl) /* dispose of hot list */
Memh hl;	/* the hot list to close */
	{
	TUTORfree_handle(hl);
	}

AddHotList(hl,ss,len)	/* add a new hot text string */
register Memh hl;	/* the hot list to modify */
unsigned char FAR *ss;	/* the new info string */
long len;	/* length of the new info string */
/* returns new style id, or 0 if error */
	{
	REGISTER HotList FAR *hlp;	/* pointer to hot list structure */
	int newid;	/* the new hot list id - used for style block data */
	long pos;	/* end position of current text */
	DArrayHeader FAR *thead;	/* pointer to dynamic array header */
	HotL1 tempHot;	/* used to create new hot text entry in dynamic array */
	int ok;	/* if TRUE, we were able to add the hot text entry */
	
	if (!ss)
		return(0);
	
	hlp = (HotList FAR *) GetPtr(hl);
	thead = (DArrayHeader FAR *) ((char FAR *) hlp + hlp->offsets[1]);
	pos = thead->dAnn;
	if (hlp->nextid < 0x7fff && pos+len < 0x7fff)
		newid = hlp->nextid++;	/* the new id for this piece of hot text */
	else
		newid = 0; /* we've run out of ids, or out of space in handle */
	ReleasePtr(hl);
	KillPtr(hlp);
	if (newid == 0)
		return(0); /* can't add another, out of ids */
	
	/* add the text into the second variable-size array */
	ok = TUTORreplace_darray(hl,FARNULL,HOTOFFSET,1,pos,0,(int) len,(char FAR *) ss);
	if (!ok)
		return(0); /* couldn't allocate */
	
	/* add the HotL1 block describing the position & length of this text in hl */
	tempHot.pos = pos;
	tempHot.len = len;
	tempHot.id = newid;
	ok = TUTORreplace_darray(hl,FARNULL,HOTOFFSET,0,-1,0,1,(char FAR *) &tempHot);
	if (!ok)
		{ /* couldn't allocate */
		TUTORdelete_darray(hl,FARNULL,HOTOFFSET,1,pos,len); /* delete text */
		return(0);
		}
	
	return(newid);
	}

TUTORchange_hot_text(pd,id,ss,sLen) /* change a hot text info string */
Memh pd;	/* the style structure */
register int id;	/* the hot text id (which is the style block data) */
char FAR *ss;	/* the new hot text info */
long sLen;		/* length of the new hot text info */
	{
	StyleDatP pp;	/* pointer to style structure */
	REGISTER HotList FAR *hlp;	/* pointer to hot list structure */
	REGISTER HotL1 FAR *hp;		/* pointer to hot text items */
	int pos, len;	/* original position & length of hot info string in handle */
	register int ii;
	
	pp = (StyleDatP) GetPtr(pd);
	if (pp->hotList)
		{
		hlp = (HotList FAR *) GetPtr(pp->hotList);
		
		/* find the item */
		hp = (HotL1 FAR *) hlp->list;
		for (ii=0; ii<hlp->listhead.dAnn; ii++,hp++)
			if (hp->id == id)
				break;
		if (ii < hlp->listhead.dAnn)
			{ /* found it */
			pos = hp->pos;
			len = hp->len; /* remember original length of string */
			hp->len = (int) sLen; /* change the length the string */
			
			/* now update positions of all following blocks */
			hp = (HotL1 FAR *) hlp->list;
			for (ii=0; ii<hlp->listhead.dAnn; ii++,hp++)
				if (hp->pos > pos)
					hp->pos += sLen - len;
			}
		else
			pos = -1; /* didn't find it */
		
		ReleasePtr(pp->hotList);
		KillPtr(hlp);
		
		if (pos >= 0)
			{ /* change hot text string */
			TUTORreplace_darray(pp->hotList,FARNULL,HOTOFFSET,1,pos,len,(int) sLen,ss);
			}
		}
	
	ReleasePtr(pd);
	KillPtr(pp);
	}

static DeleteHotList(hl,id) /* delete a hot text info string */
Memh hl;	/* hot text structure to change */
register int id;	/* id of hot text to delete */
	{
	REGISTER HotList FAR *hlp;	/* pointer to hot text structure */
	register HotL1 FAR *hp;		/* pointer to hot text header blocks */
	register int ii;
	register int ind;	/* index of header we want to delete */
	long pos, len;	/* position & length of hot text info string in handle */
	
	hlp = (HotList FAR *) GetPtr(hl);
	
	/* find the right item */
	hp = (HotL1 FAR *) hlp->list;
	for (ii=0; ii<hlp->listhead.dAnn; ii++,hp++)
		if (hp->id == id)
			break;
	
	if (ii < hlp->listhead.dAnn)
		{ /* found item, delete it */
		pos = hp->pos;
		len = hp->len;
		TUTORdelete_darray(hl,(char FAR *) hlp,HOTOFFSET,1,(int) hp->pos,hp->len); /* delete text */
		ind = hp - (HotL1 FAR *) hlp->list; /* index of header to delete */
		TUTORdelete_darray(hl,(char FAR *) hlp,HOTOFFSET,0,ind,1);
		
		/* update positions of other list items */
		hp = (HotL1 FAR *) hlp->list;
		for (ii=0; ii<hlp->listhead.dAnn; ii++,hp++)
			if (hp->pos > pos)
				hp->pos -= len;
		}
	
	ReleasePtr(hl);
	KillPtr(hlp);
	
	return(0);
	}

unsigned char FAR *GetHotstringTStyle(pd,id, len, spos, slen, getS) /* get hot text info string */
Memh pd;	/* the style structure */
int id;		/* the hot text id whose string we are looking for */
long *len;	/* returns the length of the string we found */
long *spos, *slen;	/* position and length of hot style */
int getS;	/* TRUE if we want to get string */
/* returns a TUTORalloc'ed string containing the hot text string (or FARNULL on error) */
	{
	StyleDatP pp;	/* pointer at style structure */
	HotList FAR *hlp;	/* pointer at hot text structure */
	DArrayHeader FAR *thead;	/* pointer to hot text dynamic array header */
	int ii;
	register HotL1 FAR *hp;		/* pointer to hot text header */
	char FAR *retVal;		/* returned string pointer (info string) */
	char FAR *text;			/* the hot text itself */
	register Style1 SHUGE *s1p;	/* pointer to style blocks in pd */
	int s1count;	/* index of s1p in styles */
	
	retVal = FARNULL;
	
	if (!pd)
		return(FARNULL);
	
	pp = (StyleDatP) GetPtr(pd);
	s1p = (Style1 SHUGE *) pp->styles;
	s1count = 0;
	while ((s1p->type != HOTSTYLE || s1p->dat != id) && s1count < pp->sHead.dAnn)
		{
		s1p++;
		s1count++;
		}
	if (s1count >= pp->sHead.dAnn)
		{ /* couldn't find hottext style */
		*spos = -1;
		*slen = -1;
		ReleasePtr(pd);
		return(FARNULL);
		}

	/* we found start of hot style */
	*spos = s1p->pos;
	/* end of hot style is next style block with type HOTSTYLE */
	while ((s1p->type != HOTSTYLE || s1p->dat == id) && s1count < pp->sHead.dAnn)
		{
		s1p++;
		s1count++;
		}
	if (s1count >= pp->sHead.dAnn)
		{ /* hot style extends to end of document */
		*slen = -1; /* caller needs to consider document length */
		}
	else
		*slen = s1p->pos - *spos;

	/* get hot string */

	if (pp->hotList)
		{
		hlp = (HotList FAR *) GetPtr(pp->hotList);
		/* find the right item */
		hp = (HotL1 FAR *) hlp->list;
		for (ii=0; ii<hlp->listhead.dAnn; ii++,hp++)
			if (hp->id == id)
				break;
		
		*len = hp->len;
		if (ii < hlp->listhead.dAnn && getS)
			{ /* found id & want string, get it */
			retVal = TUTORalloc((long) hp->len+1L,FALSE,"hottemp");
			if (retVal)
				{
				text = (char FAR *) ((char FAR *) hlp + hlp->offsets[1] +
										sizeof(DArrayHeader) + hp->pos);
				TUTORblock_move(text,retVal,(long) hp->len);
				retVal[hp->len] = '\0'; /* null terminate */
				}
			}
		
		ReleasePtr(pp->hotList);
		KillPtr(hlp);
		}
	
	ReleasePtr(pd);
	KillPtr(pp);
	
	/* note that caller is responsible for deallocating passed string */
	return((unsigned char FAR *) retVal);
	}

int valid_style(sN) /* check valid style index */
int sN;

{
	if ((sN < 0) || (sN >= NSTYLES))
		TUTORdump("invalid style");
		
	return(0);
	
} /* valid_style */
