
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#ifndef _txtvh
#define _txtvh

#ifndef _txth
#include "txt.h"
#endif

/* position structure */
typedef struct _ps
    {  /* position information structure */
    short hh; /* horizontal position (in local coords) */
    short vv; /* vertical position */
    long pos;   /* char position */
    short nLine;    /* line number (relative to start of linestarts) */
    char atEnd, unusedC;    /* flag for at end of line (as opposed to begin) */
    } Position;

typedef struct _viewp
    {
    Memh self;  /* so we can get back to ourselves */
    Memh doc;
    struct markvar bounds;  /* character position bounds of view */
    struct tutorview FAR *ownerV;       /*  owning view */
    TRect   viewRect;   /* rectangle view appears in */
    TRect eraseRect; /* rectangle to erase (dict,help ) */
    short   destWidth;  /* width to format text to */
    char vActive;	 /*  nonzero if active */
    char wrap;      /* TRUE if we wrap at edge of destWidth */
    char caretState; /* TRUE if caret/hilighting is currently enabled */
    char scrollH;   /* TRUE if view can scroll horizontally */
    char scrollV;   /* TRUE if view can scroll vertically */
    char editcmd; /* TRUE if -edit- command view */
    char arrowcmd; /* TRUE if -arrow- command view */
    char textmcmd; /* TRUE if -textm- command view */
    char dialog; /* TRUE if text panel in dialog view */
    char dict; /* TRUE if dict or help window */
	char message; /* TRUE if message window */
	char debug; /* TRUE if debug expression panel */
	char inhSupSub; /* TRUE if superscript/subscript offset in layout disabled */
	char hiInactive; /* TRUE is should retain highlighting while inactive */
    int dispMode; /* mode (write/xor/etc) to display in, or -1 */
    struct tutorColor fColor; /* default foreground color */
    int idHot; /* hot text identifier */
    long hotPos; /* position of last hot text hit */
    long hotLen; /* length of last hot text hit */
    short   leftOff;        /* offset due to horizontal scroll */

    /* variables for handling selection */
    Position anchor;    /* current anchor position (== either sel1 or sel2) */
    Position selA;      /* active end of selection */
    char byWord;        /* TRUE if current selection is begin done by word */
    char duringClick;   /* TRUE if we are currently working on a click (mouse is down) */
    char singleSel; /* TRUE if single click selects (treated as double click) */
    char upHot; /* TRUE if will process hot text on up move */
    char highSel; /* TRUE if will highlight selection */
    char    noRedraw;   /* if TRUE, no redrawing is done */

	int newLine; /* minimum newline height */
	int dySupSub; /* superscript/subscript */
    short topLine;  /* top line showing (index relative to start of linestarts) */
    short botLine;  /* bottom line showing */
    long layoutTop, layoutBottom;   /* character position bounds of linestarts */
                /* NOTE: topPos/botPos don't refer to the same span as topLine/botLine */
    long botPos;    /* character position after last character showing */
    short botV;     /* vertical position on screen of bottom of last line showing */
    
    /* dynamic array for linestarts info */
    long nArrays;       /* should always be 1 */
    long offsets[1];    /* offsets (in bytes) from begin of handle to header of each darray */
    long totalSize;     /* total size of the handle */
    DArrayHeader txtvH;
    LineLayout ld[1];
    } TextView;

typedef TextView FAR *TViewP;

extern int VIEWOFFSET; /* should be a define */

/* width of imaginary screen for horizontal scroll */
#define HSCROLL_WIDTH 1536 

/* editor styles */
/* these styles differentiate behaviour on delete keys, pastes and scroll bar interactions */ 
#define MACSTYLE 0
#define ANDREWSTYLE 1
#define PCSTYLE 2

#endif
