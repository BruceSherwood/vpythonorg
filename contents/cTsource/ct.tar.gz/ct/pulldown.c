
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* pulldown.c:  Pull-down menu support. */

#include "baseenv.h"
#include "kglobals.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "tutor.h"
#include "editmenu.h"
#include "editor.h"
#include "fkeys.h"
#include "eglobals.h"
#include "commands.h"

#ifdef ctproto
int  pd_init(void);
int  pd_flush(void);
int  pd_menumouse(struct  tutorevent *event);
int  pd_menukey(struct  tutorevent *event);
int  pd_menuredraw(struct  tutorevent *event);
int  pd_selectcard(int  wix,int  card);
int  pd_selectitem(int  ww,int  card,int  itempos);
int  pd_in_menu(int  xx,int  yy);
int  pd_display_bar(int  wx);
int  pd_enter(int  menw);
int  pd_restore(void);
extern int  pd_menu_change(int  ww);
extern int  pd_item_change(int  ww,int  cardi);
int  pd_find_high_menu(int  ww,int  type,int  card,int  position,int  priority);
int  pd_find_itemdn(int  ww,int  type,int  cardi,int  n);
int  pd_bar_hit(int  ww,int  mx,int  *barpos);
int  pd_card_hit(int  ww,int  card,int  my,int  *itempos);
int  TUTORinq_wmg_busy(int  window);
int  TUTORinq_overlap(struct  _trect *r1,struct  _trect *r2);
int  pd_save_region(void);
int  pd_restore_region(void);
int  wmg_outline(int  x1,int  y1,int  x2,int  y2,int  md);
int  TUTORforward_window(int  wix);
int  TUTORset_cursor(int  cInd,int  cChar);
int  FullHalt(void);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
long  TUTORinq_msec_clock(void);
int  TUTORresume_cursor(void);
int  wmg_layout(void);
int  machineflush(void);
int  TUTORdraw_text(unsigned char  FAR *buf,int  count);
int  strlenf(char  FAR *aa);
int  TUTORabs_move_to(int  x,int  y);
int  TUTORframe_abs_rect(struct  _trect FAR *tr);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
int  TUTORset_abs_clip_rect(struct  _trect FAR *cr);
int  TUTORset_rect(struct  _trect *r,int  left,int  top,int  right,int  bottom);
int  TUTORmouse_off(void);
int  TUTORset_comb_rule(int  rule);
int  TUTORabs_line_to(int  x,int  y);
int  wmg_frame(int  wix);
int  TUTORinq_abs_string_width(unsigned char  FAR *s,int  lth,int  *dx);
int  TUTORmouse_on(void);
int  CTset_background_color(int  color);
int  CTset_foreground_color(int  color);
int  TUTORset_textfont(int  jj);
int  TUTORset_window(int  wid);
int  TUTORinq_font_info(int  *ascent,int  *descent,int  *maxwidth,int  *leading);
int  TUTORget_zfont(char  *famS,int  size);
int  wmg_on(void);
int  TUTORfree_region(long  id);
int  TUTORabs_restore_region(long  id,int  x1,int  y1);
long  TUTORabs_save_region(int  x1,int  y1,int  x2,int  y2);
#endif /* ctproto */

extern long TUTORinq_msec_clock();

int wmg_xo[WINDOWLIMIT];    /* window x origin */
int wmg_yo[WINDOWLIMIT];    /* window y origin */
int wmg_xs[WINDOWLIMIT];    /* window x size */
int wmg_ys[WINDOWLIMIT];    /* window y size */
int wmg_sxo[WINDOWLIMIT];   /* saved window x origin */
int wmg_syo[WINDOWLIMIT];   /* saved window y origin */
int wmg_sxs[WINDOWLIMIT];   /* saved window x size */
int wmg_sys[WINDOWLIMIT];   /* saved window y size */
int wmg_next[WINDOWLIMIT];  /* index of next (upper, forwards) window */
int wmg_prev[WINDOWLIMIT];  /* index of previous (lower, behind) window */
int wmg_obscured[WINDOWLIMIT];  /* TRUE if window obscured */
int wmg_hidden[WINDOWLIMIT];    /* TRUE if window hidden */
int wmg_top;    /* index of topmost window */
int wmg_bottom; /* index of bottommost window */
int wmg_px; /* physical x screen size */
int wmg_py; /* physical y screen size */
int wmg_select; /* window selected for move/resize operation */

static int wmg_olx1,wmg_oly1;  /* outline of selected window */
static int wmg_olx2,wmg_oly2;
static int wmg_bx,wmg_by;  /* base x,y position for window move/resize */
static int wmg_sizesel; /* corner or edge selection for resize */

int pd_menualt[WINDOWLIMIT]; /* menus altered table */

int pd_mw; /* current window for menu operations */
int pd_barheight; /* pull-down menu bar height */
int pd_wmctrlw; /* control button width */

static int pd_itemheight; 
static int pd_charwidth;
static int pd_state[WINDOWLIMIT]; /* menu state (idle, card selected, etc) */
static int pd_cardx1; /* upper left corner of card */
static int pd_cardy1;
static int pd_cardx2; /* lower right corner of card */
static int pd_cardy2;
static int pd_cardsel; /* menu card currently selected */
static long pd_region_id = 0; /* id of region saved under card */
static int pd_itemx1;  /* upper left corner of selected item */
static int pd_itemy1;
static int pd_itemx2;  /* lower right corner of selected item */
static int pd_itemy2;
static int pd_itemsel;  /* menu item currently selected */
static int pd_cardpos;  /* position of currently selected card */
static int pd_itempos;  /* position of currently selected item */
static int pd_lastwin;  /* window of last card selection */
static int pd_lastcard; /* last card selected */
static int pd_font = 0; /* font index used in menu bar/items */
static int pd_ascent;  /* for font used in menu bar/items */
static long pd_mode;  /* saved mode */
static int pd_swix;     /* saved window index */
static int pd_sx, pd_sy; /* saved x,y position */
static int pd_fc, pd_bc; /* saved foreground, background colors */
static int pd_cx, pd_cy, pd_cw, pd_ch; /* saved clip region */
static int pd_thick; /* saved line thickness */

static int fontid; /* save/restore current font index */

/* ********** window management and pull-down menus ********** */

pd_init()  /* initialize the pull-down menu states */

{   int i;

    for (i=0; i<WINDOWLIMIT; i++) {
        wmg_xo[i] = wmg_yo[i] = 0;
        wmg_xs[i] = wmg_ys[i] = 0;
        wmg_sxs[i] = wmg_sys[i] = 0;
        wmg_next[i] = wmg_prev[i] = -1;
        wmg_obscured[i] = wmg_hidden[i] = FALSE;
        pd_state[i]= 0;
    } /* for */
    pd_mw = -1; /* no window selected for menu operations */
    pd_region_id = 0; /* no region saved under menu */
    pd_cardsel = pd_lastcard = -1;
    pd_wmctrlw = 0; /* assume no window-control button */
    wmg_select = -1; /* no window selected for size/move */
    wmg_top = wmg_bottom = -1;

} /* pd_init */

/* ******************************************************************* */

pd_flush() /* driven by TUTORflush() */

{
    if (windowsP[CurrentWindow].wp && (!wmg_hidden[CurrentWindow])) {
        if(flushMenu && pd_menualt[CurrentWindow]) {
        if (!wmg_obscured[CurrentWindow])
            pd_display_bar(CurrentWindow); /* update menu bar */
        } /* flushMenu if */
    } /* windows if */
}

/* ******************************************************************* */

pd_menumouse(event) /* check for and process menu mouse event */
                    /* returns TRUE if menu-related mouse event */
struct tutorevent *event;

{   int ww; /* index of window */
    int card;   /* index of card within bar */
    int item;   /* index of item within card */
    int dx,dy;  /* displacement from mouse starting position */
    int xx,yy;  /* actual screen position */
    int winalt; /* TRUE if window lay-out altered */
    int i, ii;
    Memh barh;  /* handle on menu bar */
    TutorMenuBar FAR *bar; /* pointer to menu bar structure */
    struct tutorwindow FAR *wp; /* pointer to window info */

    if (event->type < 0) return(FALSE); /* not menu event if no event */
    if (modalW != -1) return(FALSE); /* not menu event if dialog box up */

    ww = event->window;
    winalt = FALSE;

    /* check for click outside of window */

    if ((ww < 0) || (pd_mw >= 0) || (wmg_select >= 0)) {
    i = FALSE; /* TRUE if should swallow event */

    /* terminate menu operation if event not for menu window */

    if ((pd_mw >= 0) && (pd_mw != ww)) {
        ww = pd_mw;
        pd_selectcard(ww,-1); /* clear card select */
        pd_state[ww] = 0; /* clear menu status */
            i = TRUE;
    } /* pd_mw if */

    /* terminate move/resize operation if event not for move window */

    if ((wmg_select >= 0) && (wmg_select != ww)) {
        pd_state[wmg_select] = 0; /* clear move status */
        wmg_select = -1;
            i = TRUE;
    } /* wmg_select if */

    if (ww < 0) i = TRUE; /* swallow event if not in any window */

    if (i) 
            return(TRUE); /* swallow event */
    } /* menu/select if */


    switch (pd_state[ww]) {

    /* 0 = normal execution - no menu/window operation in progress */

    case 0:
    if (event->y >= 0) break; /* not menu if not in menu bar */

#ifdef IBMPC

    /* left or right click in window box is resize */

    if (pd_wmctrlw && (pd_state[ww] == 0) &&
        (event->x >= (wmg_xs[ww]-pd_wmctrlw-2)) &&
        (event->x <= wmg_xs[ww])) {
        if (event->type == EVENT_LEFTDOWN) {

        /* check if full size - return to saved size */

        if ((wmg_xs[ww] == (wmg_px-4)) &&
            (wmg_ys[ww] == (wmg_py-4))) {
            if (wmg_sxs[ww]) {
            wmg_xo[ww] = wmg_sxo[ww];
            wmg_yo[ww] = wmg_syo[ww];
            wmg_xs[ww] = wmg_sxs[ww];
            wmg_ys[ww] = wmg_sys[ww];
            }

        /* if not full size, expand to full size */

        } else {

            /* save current size */

            wmg_sxo[ww] = wmg_xo[ww];
            wmg_syo[ww] = wmg_yo[ww];
            wmg_sxs[ww] = wmg_xs[ww];
            wmg_sys[ww] = wmg_ys[ww];

            /* expand to full size */

            wmg_xo[ww] = 2;
            wmg_yo[ww] = 2;
            wmg_xs[ww] = wmg_px-4;
            wmg_ys[ww] = wmg_py-4;
        }
        winalt = TRUE;
        break; /* exit case */
        } else if (event->type == EVENT_RIGHTDOWN) {
        pd_state[ww] = 3; /* window resize */
        TUTORset_cursor(cursorFont0,5);
        } /* event->type if */
    } /* pd_wmctrlw if */

    /* right click in menu bar is window move */

    else if ((event->y >= (-pd_barheight)) && (event->x >= 0) &&
        (event->x <= wmg_xs[ww]) && (event->type == EVENT_RIGHTDOWN)) {
        if (pd_state[ww] == 0)
        pd_state[ww] = 2; /* window move */
    } /* event->type if */

    if (pd_state[ww]) {
        if (pd_mw >=0)
            pd_selectcard(pd_mw,-1); /* clear menu */
        TUTORforward_window(ww);
        wmg_select = ww;
        wmg_bx = event->x; /* save base x,y position */
        wmg_by = event->y;
        wmg_olx1 = wmg_xo[wmg_select]-2;
        wmg_oly1 = wmg_yo[wmg_select]-2;
        wmg_olx2 = wmg_xo[wmg_select]+wmg_xs[wmg_select]+1;
        wmg_oly2 = wmg_yo[wmg_select]+wmg_ys[wmg_select]+1;
        wmg_outline(wmg_olx1,wmg_oly1,wmg_olx2,wmg_oly2,4);
        return(TRUE);
    } /* state if */
#endif

    /* if down event on card title, select card */

    if (event->type == EVENT_LEFTDOWN) {
        card = pd_bar_hit(ww,event->x,&pd_cardpos);
        if (card >= 0) {
        pd_selectcard(ww,card);
        pd_state[ww] = 1; /* selected card */
        } /* card if */
        return(TRUE);   /* swallow left click in title bar */
    } else if (event->type == EVENT_RIGHTDOWN)
        return(TRUE); /* swallow right click in title bar */
    break;

    /* 1 = menu operation in progress */

    case 1:
    switch (event->type) {

    case EVENT_LEFTDOWN:

        /* if event on title bar, on card, select card */
        /* (but clicking on title of already selected card deselects) */

        if (event->y < 0) {
        card = pd_bar_hit(ww,event->x,&pd_cardpos);
        if (card >= 0) {
            if (card == pd_cardsel) {
            pd_selectcard(ww,-1); /* clear card selection */
                pd_state[ww] = 0;
            } else {
            pd_selectcard(ww,card); /* select new card */
            }
        } /* card if */
        } /* event-> y if */
        return(TRUE);

    case EVENT_LEFTUP:

            /* if event on title bar, select card */

            if (event->y < 0) {
        card = pd_bar_hit(ww,event->x,&pd_cardpos);
        if (card >= 0) 
                    pd_selectcard(ww,card);
                else {
            pd_selectcard(ww,-1);
            pd_state[ww] = 0;
            } /* card else */

            /* if up event outside card, forget it */

        } else if ((event->x < pd_cardx1) || (event->x > pd_cardx2) ||
        (event->y < pd_cardy1) || (event->y > pd_cardy2)) {
        pd_selectcard(ww,-1); /* clear card selection */
        pd_state[ww] = 0;

            /* up event within card - identify item */

        } else {
        item = pd_card_hit(ww,pd_cardsel,event->y,&i);
        if (item >= 0) {

            /* if window not top, first bring forward */

            TUTORforward_window(ww);

            /* generate menu event */

            event->window = pd_lastwin = ww;
            event->view = FARNULL;
            event->eDataP = FARNULL;
            event->value = item;
            event->timestamp = TUTORinq_msec_clock();
            barh = windowsP[ww].menus;
            bar = (TutorMenuBar FAR *) GetPtr(barh);
            
            event->a1 = bar->items[event->value].type;
                    
			/* handle executor quit-running */
			
			if ((ww == ExecWn) && (event->a1 == exec_quit)) {
#ifndef CTEDIT
				exS.ExecQuit = TRUE;
				exS.ExecQuitTime = TUTORinq_msec_clock();
#endif
			}
			   
            /* some menus are really FKEYs */

            switch(event->a1) {
            case edit_cut:
            case exec_cut:
                ii = KCUT; break;
            case edit_copy:
            case exec_copy:
                ii = KCOPY; break;
            case edit_paste:
            case exec_paste:
                ii = KPASTE; break;
            case edit_undo:
                ii = KUNDO; break;
            case edit_clear:
                ii = -8; /* indicates key rather than fkey */
                break;
            default:
                ii = 0; /* really is a menu */
            }
            
            if (ii == 0) { /* really menu */        
                event->type = bar->items[event->value].eventType;
                event->a2 = bar->items[event->value].unit;
                event->a3 = bar->items[event->value].unitArg;
                event->a4 = (long) barh;
            } else { /* key or fkey */
                event->type = (ii > 0) ? EVENT_FKEY : EVENT_KEY;
                event->nkeys = 1;
                event->value = ii;
                event->keys[0] = -ii;
                event->view = windowsP[event->window].KeyFocus;
            }
            ReleasePtr(barh);
            eventque[nevents++] = *event;

            /* halt executor if event on another window */

                    if ((ww != ExecWn) && (runflag != halt))
            FullHalt();
        } /* item if */
        pd_selectcard(ww,-1);
        pd_state[ww] = 0;
        } /* else */
            return(TRUE); /* state 1 always menu-related */

    case EVENT_DOWNMOVE:
    case EVENT_UPMOVE:

        /* if move event outside card, clear item select */

        if ((event->x < pd_cardx1) || (event->x > pd_cardx2) ||
        (event->y < pd_cardy1) || (event->y > pd_cardy2)) {
        pd_selectitem(ww,pd_cardsel,-1);

        /* move event within card - identify item */

        } else if (pd_itemsel < 0 || event->y < pd_itemy1 || event->y > pd_itemy2) {
        /* move to new item */ 
        item = pd_card_hit(ww,pd_cardsel,event->y,&i);
        if ((item >= 0) && (i >= 0)) {
            pd_selectitem(ww,pd_cardsel,i);
        } /* item if */
        } /* else */
            return(TRUE); /* state 1 always menu-related */

    } /* event switch */

    /* 2 = window move operation in progress */

    case 2:
    if (wmg_select < 0)
        return(TRUE); /* state 2 always menu related */
    wmg_outline(wmg_olx1,wmg_oly1,wmg_olx2,wmg_oly2,4);

    /* compute new position for outline if moved */

    if (event->type == EVENT_DOWNMOVE) {
        dx = event->x-wmg_bx;
        dy = event->y-wmg_by;
        if ((wmg_olx1+dx) < 0) dx = -wmg_olx1;
        if ((wmg_olx2+dx) > (wmg_px-1)) dx = wmg_px-1-wmg_olx2;
        if ((wmg_oly1+dy) < 0) dy = -wmg_oly1;
        if ((wmg_oly2+dy) > (wmg_py-1)) dy = wmg_py-1-wmg_oly2;
        wmg_olx1 += dx;
        wmg_olx2 += dx;
        wmg_oly1 += dy;
        wmg_oly2 += dy;
        wmg_bx += dx;
        wmg_by += dy;
        wmg_outline(wmg_olx1,wmg_oly1,wmg_olx2,wmg_oly2,4);
        return(TRUE); /* window-related event */
    } else {

        /* move window to new position */

        wmg_xo[wmg_select] = wmg_olx1+2;
        wmg_yo[wmg_select] = wmg_oly1+2;
        winalt = TRUE;
        break;
    } /* event type else */

    /* 3 = window re-size operation, find corner/edge to drag */

    case 3:

    /* cancel re-size operation if right button up */

    if (event->type == EVENT_RIGHTUP) {
        TUTORresume_cursor();
        winalt = TRUE; /* cancel window re-size */
        break;
    } else if (event->type != EVENT_DOWNMOVE)
        break; /* ignore everything else but move */

    /* check if should grab corner */

    wmg_sizesel = -1; /* haven't grabbed anything yet */
    xx = event->x+wmg_xo[wmg_select]; /* convert to absolute */
    yy = event->y+wmg_yo[wmg_select]+pd_barheight;
    if (((xx >= wmg_olx2) && (yy <= (wmg_oly1+8))) ||
        ((yy <= wmg_oly1) && (xx >= (wmg_olx2-8))))
        wmg_sizesel = 1;
    else if (((xx >= wmg_olx2) && (yy >= (wmg_oly2-8))) ||
         ((yy >= wmg_oly2) && (xx >= (wmg_olx2-8))))
        wmg_sizesel = 3;
    else if (((xx <= wmg_olx1) && (yy >= (wmg_oly2-8))) ||
         ((yy >= wmg_oly2) && (xx <= (wmg_olx1+8))))
        wmg_sizesel = 5;
    else if (((xx <= wmg_olx1) && (yy <= (wmg_oly1+8))) ||
         ((yy <= wmg_oly1) && (xx <= (wmg_olx1+8))))
        wmg_sizesel = 7;

    /* check if should grab edge */

    else if (yy <= wmg_oly1) {
        wmg_sizesel = 0;
    } else if (xx >= wmg_olx2)
        wmg_sizesel = 2;
    else if (yy >= wmg_oly2)
        wmg_sizesel = 4;
    else if (xx <= wmg_olx1)
        wmg_sizesel = 6;

    if (wmg_sizesel >= 0) {
        TUTORset_cursor(cursorFont0,4);
        pd_state[wmg_select] = 4; /* set to perform re-size */
        pd_menumouse(event); /* recurrsive call to handle this move */
    }
    break;

    /* 4 = window re-size operation in progress */

    case 4:
    wmg_outline(wmg_olx1,wmg_oly1,wmg_olx2,wmg_oly2,4);
    xx = event->x+wmg_xo[wmg_select]; /* convert to absolute */
    yy = event->y+wmg_yo[wmg_select]+pd_barheight;

    /* keep window on screen */

    if (xx < 0)
        xx = 0;
    if (xx >= wmg_px)
        xx = wmg_px-1;
    if (yy < 0)
        yy = 0;
    if (yy >= wmg_py)
        yy = wmg_py-1;

    if (event->type == EVENT_DOWNMOVE) {
        switch (wmg_sizesel) {

        case 0: /* upper edge */
        if (yy < (wmg_oly2-60)) {
            wmg_oly1 = yy;
            if (xx < wmg_olx1) /* switch to upper left corner */
            wmg_sizesel = 7;
            if (xx > wmg_olx2) /* switch to upper right corner */
            wmg_sizesel = 1;
        } else
        wmg_oly1 = wmg_oly2-60;
        break;

        case 1: /* upper right corner */
        if (yy < (wmg_oly2-60))
            wmg_oly1 = yy;
        else
        wmg_oly1 = wmg_oly2-60;
        case 2: /* right edge */
        if (xx > (wmg_olx1+60)) {
            wmg_olx2 = xx;
            if (yy < wmg_oly1) /* switch to upper right corner */
            wmg_sizesel = 1;
            if (yy > wmg_oly2) /* switch to lower right corner */
            wmg_sizesel = 3;
        } else
        wmg_olx2 = wmg_olx1+60;
        break;

        case 3: /* lower right corner */
        if (xx > (wmg_olx1+60))
            wmg_olx2 = xx;
        else
        wmg_olx2 = wmg_olx1+60;
        case 4: /* lower edge */
        if (yy > (wmg_oly1+60)) {
            wmg_oly2 = yy;
            if (xx < wmg_olx1) /* switch to lower left corner */
            wmg_sizesel = 5;
            if (xx > wmg_olx2) /* switch to upper right corner */
            wmg_sizesel = 3;
        } else
        wmg_oly2 = wmg_oly1+60;
        break;

        case 5: /* lower left corner */
        if (yy > (wmg_oly1+60))
            wmg_oly2 = yy;
        else
        wmg_oly2 = wmg_oly1+60;
        case 6: /* left edge */
        if (xx < (wmg_olx2-60)) {
            wmg_olx1 = xx;
            if (yy < wmg_oly1) /* switch to upper left corner */
            wmg_sizesel = 7;
            if (yy > wmg_oly2) /* switch to lower left corner */
            wmg_sizesel = 5;
        } else
        wmg_olx1 = wmg_olx2-60;
        break;

        case 7: /* upper left corner */
        if ((xx < (wmg_olx2-60)) && (yy < (wmg_oly2-60))) {
            wmg_olx1 = xx;
            wmg_oly1 = yy;
    } else {
        if (xx < (wmg_olx2-60))
        wmg_olx1 = wmg_olx2-60;
        if (yy < (wmg_oly2-60))
        wmg_oly1 = wmg_oly2-60;
    }
        break;

        } /* switch */

        if (wmg_sizesel < 0) {
        pd_state[wmg_select] = 3; /* re-select edge/corner */
        TUTORset_cursor(cursorFont0,5);
        }
        wmg_outline(wmg_olx1,wmg_oly1,wmg_olx2,wmg_oly2,4);
        return(TRUE); /* window-related event */
    } else {
        TUTORresume_cursor();
        wmg_xo[wmg_select] = wmg_olx1+2;
        wmg_yo[wmg_select] = wmg_oly1+2;
        wmg_xs[wmg_select] = wmg_olx2-wmg_olx1+1-4;
        wmg_ys[wmg_select] = wmg_oly2-wmg_oly1+1-4;

        /* save current size for size toggle */

        wmg_sxo[wmg_select] = wmg_xo[wmg_select];
        wmg_syo[wmg_select] = wmg_yo[wmg_select];
        wmg_sxs[wmg_select] = wmg_xs[wmg_select];
        wmg_sys[wmg_select] = wmg_ys[wmg_select];

        winalt = TRUE;
        break;
    } /* event type else */
    } /* pd_state switch */

    /* re-draw all windows if move/resize */

    if (winalt) {
    wmg_layout();
    pd_state[ww] = 0;
    wmg_select = -1;
    return(TRUE); /* window-related event */
    } /* winalt if */

    return(FALSE); /* not menu/window-related */

} /* pd_menumouse */

/* ******************************************************************* */

pd_menukey(event)   /* check for and process menu keyboard event */
            /* removes key from event if menu related */
struct tutorevent *event;

{   int ww; /* index of window */
    int keyi;   /* index of key */
    int key;    /* current key code */
    int card;   /* index of card within bar */
    int item;   /* index of item within card */
    int ismenu; /* TRUE if menu-related key */
    int i;
    struct tutorevent nev;
    Memh barh;  /* handle on menu bar */
    TutorMenuBar FAR *bar; /* pointer to menu bar structure */

    if (event->type != EVENT_KEY && event->type != EVENT_FKEY)
        return(0);
    if (modalW != -1)
        return(0); /* not menu if dialog box up */

    ww = event->window;
    if ((ww < 0) || (event->nkeys <= 0))
        return(0);

    /* loop thru all keys - process and swallow menu related keys */

    for (keyi=0; keyi<event->nkeys; keyi++) {
        key = (event->type == EVENT_KEY) ? event->keys[keyi] : event->value;
        ismenu = FALSE; /* pre-set not menu related */

        switch (pd_state[ww]) {

        /* 0 = normal execution - no menu/window action in progress */

        case 0:
            if ((key == 3)) { /* ctrl+m mapped to ctrl+c */

                /* begin menu selection */

                pd_cardpos = pd_itempos = 0;
                if ((ww == pd_lastwin) && (pd_lastcard >= 0))
                     pd_cardpos = pd_lastcard;   /* use last card selected */
                card = pd_find_itemdn(ww,MENUCARD,-1,pd_cardpos);
                if (card < 0) {
                    pd_cardpos = pd_lastcard = 0; /* try 1st card */
                    card = pd_find_itemdn(ww,MENUCARD,-1,pd_cardpos);
                }
                if (card >= 0) {
                    pd_state[ww] = 1; /* processing menu */
                    ismenu = TRUE;
                    pd_selectcard(ww,card); /* select first card */
                    pd_itempos = 0;
                    pd_selectitem(ww,card,0); /* select first item */
                } /* card */
            } /* esc+m if */
            break;

    /* 1 = menu operation in progress */

    case 1:
        ismenu = TRUE; /* state 1 always menu related */

        /* ctrl+m (mapped to ctrl+c) - stop menu operation */

        if ((key == 3))
        pd_cardpos = -1; /* cancel menu select */

        else if (key == KLEFT) { /* left arrow, move to previous card */
       
        /* wrap to rightmost card if on leftmost card */

        if (pd_cardpos == 0) {
            while ((pd_find_itemdn(ww,MENUCARD,-1,pd_cardpos)) >= 0)
            pd_cardpos++; /* search for last card */
        } /* cardpos if */
        pd_cardpos--; /* back-up to previous card */

        /* select card, highlight item */

        card = pd_find_itemdn(ww,MENUCARD,-1,pd_cardpos);
        if (card >= 0) {
            pd_selectcard(ww,card); /* select next card */
            pd_itempos = 0;
            pd_selectitem(ww,card,0); /* select first item */
        } else
            pd_cardpos = -1; /* cancel menu select */
        } /* left arrow if */

        else if (key == KRIGHT) { /* right arrow, move to next card */
        pd_cardpos++;
        card = pd_find_itemdn(ww,MENUCARD,-1,pd_cardpos);
        if (card < 0) { /* wrap to first card */
            pd_cardpos = 0;
            card = pd_find_itemdn(ww,MENUCARD,-1,pd_cardpos);
        }
        if (card >= 0) {
            pd_selectcard(ww,card); /* select next card */
            pd_itempos = 0;
            pd_selectitem(ww,card,0); /* select first item */
        } /* card */
        } /* right arrow if */

        else if (key == KUP) { /* up arrow, move to previous item */
        if (pd_itempos)
            pd_itempos--;
        else {
            barh = windowsP[ww].menus;
            bar = (TutorMenuBar FAR *) GetPtr(barh);
            pd_itempos = bar->items[pd_cardsel].nitems-1;
            ReleasePtr(barh);
        }
        pd_selectitem(ww,pd_cardsel,pd_itempos);
        } /* up arrow if */

        else if (key == KDOWN) { /* down arrow, move to next item */
        pd_itempos++;
        item = pd_selectitem(ww,pd_cardsel,pd_itempos);
        if (item < 0) {
            pd_itempos = 0;
            item = pd_selectitem(ww,pd_cardsel,pd_itempos);
            if (item < 0)
            pd_cardpos = -1; /* cancel menu select */
        } /* item if */
        } /* down arrow if */

        /* return = select current menu item */

        else if ((key == NEWLINE) && (pd_itemsel >= 0)) {

        /* if window not top, first bring forward */

        TUTORforward_window(ww);

        /* generate menu event */

        nev.window = ww;
        nev.view = FARNULL;
        nev.eDataP = FARNULL;
        nev.value = pd_itemsel;
        barh = windowsP[ww].menus;
        bar = (TutorMenuBar FAR *) GetPtr(barh);
        nev.type = bar->items[nev.value].eventType;
        nev.a1 = bar->items[nev.value].type;
        nev.a2 = bar->items[nev.value].unit;
        nev.a3 = bar->items[nev.value].unitArg;
        nev.a4 = barh;
        nev.timestamp = TUTORinq_msec_clock();
        eventque[nevents++] = nev;
        ReleasePtr(barh);

        pd_lastwin = ww; /* remember window, card */
        pd_lastcard = pd_cardpos;
        pd_cardpos = -1; /* cancel menu select */
        } /* RETURN if */

        /* clear menu select if no card */

        if (pd_cardpos < 0) {
        pd_selectcard(ww,-1);
        pd_state[ww] = 0; /* not processing menu */
        } /* cardpos if */

        break;

    /* n = window operation in progress */

    default:
        ismenu = TRUE; /* ignore keys if window move/resize */
        break;
    } /* switch */

    /* swallow key if menu related */

    if (ismenu) {
        for (i=keyi; i<(event->nkeys-1); i++) {
        event->keys[i] = event->keys[i+1]; /* shove keys down */
        } /* for */
        keyi--; /* back-up loop index */
        event->nkeys--;
    } /* ismenu if */

    } /* for */

} /* pd_menukey */

/* ******************************************************************* */

pd_menuredraw(event)
struct tutorevent *event;

{   int ww; /* index of window */
    int menuw; /* menu window */
    int cardsel; /* menu card currently selected */

    ww = event->window;
	if ((ww < 0) || (windowsP[ww].wp == FARNULL))
		return; /* nothing to do */
    menuw = pd_mw; /* window of menu operation if any */
    cardsel = pd_cardsel; /* card currently selected if any */
    pd_display_bar(ww); /* display menu bar */
    if (ww == menuw) {
        pd_mw = pd_cardsel = -1; /* re-set to no menu activity */
        if (cardsel >= 0) {
            pd_selectcard(ww,cardsel); /* re-select card */
            pd_state[ww] = 1;
        } /* cardsel if */
    } /* ww if */
    pd_menualt[ww] = TRUE;
    
} /* pd_menuredraw */

/* ******************************************************************* */

pd_selectcard(wix,card)   /* select (activate) specified menu card */
int wix; /* index of window */
int card; /* index of card */

{   int cx1,cy1; /* upper left  of card */
    int cx2,cy2; /* lower right of card */
    Memh barh;
    TutorMenuBar FAR *bar;
    TutorMenuItem FAR *mp;
    int ii;
    TRect tr;
  
    /* check if re-select of card already selected */

    if ((wix == pd_mw) && (card >= 0) && (card == pd_cardsel))
        return(0);
    pd_itemsel = -1; /* no item selected */

    /* restore background for previous card */

    if ((pd_mw >= 0) && pd_region_id) {
        pd_enter(pd_mw);
        pd_restore_region();
        pd_restore();
    }

    /* check if no menu card to activate */

    pd_enter(wix);
    pd_cardsel = card; /* card selected */
    if (card < 0) {
        pd_restore();
        machineflush();
        pd_mw = -1;
        return(0);
    }

    pd_mw = wix; /* menu operations on this window */
    barh = windowsP[pd_mw].menus;
    bar = (TutorMenuBar FAR *) GetPtr(barh);

    /* update if card has been altered */

    if (bar->items[card].altered) pd_item_change(pd_mw,card);
    bar->items[card].altered = FALSE;

    /* compute screen bounds of card */

    cx1 = bar->items[card].p1;
    cy1 = 0;
    cx2 = cx1+bar->items[card].width;
    cy2 = cy1+3+bar->items[card].nitems*pd_itemheight;
    if (cx2 > windowsP[pd_mw].wxsize-1) {
    ii = cx2-windowsP[pd_mw].wxsize;
    if ((cx1-ii) < 0) ii = cx1;
    cx1 -= ii;  /* move card to left */
    cx2 -= ii;
    } /* cx2 if */
    if (cy2 > windowsP[pd_mw].wysize-1)
    cy2 = windowsP[pd_mw].wysize;
    TUTORset_rect(&tr,cx1,cy1,cx2,cy2);
    TUTORset_abs_clip_rect((TRect FAR *) &tr);

    pd_cardx1 = cx1;  /* save origin of region */
    pd_cardy1 = cy1;
    pd_cardx2 = cx2;
    pd_cardy2 = cy2;
    ReleasePtr(barh); /* allow menubar table to move */

    /* save area of screen behind card */
  
    pd_save_region();

    /* draw new menu card */

    bar = (TutorMenuBar FAR *) GetPtr(barh);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr, PAT_WHITE);
    TUTORframe_abs_rect((TRect FAR *) &tr);

    for (ii=0; ii<bar->nItems; ii++) {
    mp = &bar->items[ii];
    if ((mp->cardI == card) && (mp->itemKind == MENUITEM)) {
             TUTORabs_move_to(cx1+pd_charwidth,mp->p1+pd_ascent);
         TUTORdraw_text((unsigned char FAR *) mp->name,(int)strlenf(mp->name));
    } /* card if */
    } /* for */
    ReleasePtr(barh);
    pd_restore();
    machineflush();

} /* pd_selectcard */

/* ********************************************************* */

pd_selectitem(ww,card,itempos) /* select (highlight) item */
int ww; /* window */
int card; /* index of card */
int itempos; /* position of item in card */

{   int item;   /* index of item */
    Memh barh; /* handle on menu bar */
    TutorMenuBar FAR *bar; /* pointer to menu bar structure */
    TutorMenuItem FAR *mp;
    TRect tr;

    if (pd_cardsel < 0) /* no item select if no card select */
    return(0);

    pd_enter(ww);
    TUTORset_comb_rule(SRC_XOR);  /* mode xor */
    TUTORset_rect(&tr,pd_cardx1+1,pd_cardy1+1,pd_cardx2-1,pd_cardy2-1);
    TUTORset_abs_clip_rect((TRect FAR *) &tr);

    /* remove previous item selection */

    if (pd_itemsel >= 0) {
    TUTORset_rect(&tr,pd_itemx1,pd_itemy1,pd_itemx2,pd_itemy2);
    TUTORframe_abs_rect((TRect FAR *) &tr);
    pd_itemsel = -1; /* no item selected */
    } /* pd_itemsel if */

    /* find position of this item */

    if (itempos < 0) {
    item = -1; /* no item to select */
    } else {
    barh = windowsP[ww].menus;
    bar = (TutorMenuBar FAR *) GetPtr(barh);
    item = pd_find_itemdn(ww,MENUITEM,card,itempos);
    if (item >= 0) {
        mp = &bar->items[item];
        pd_itemy1 = mp->p1;
    } /* item if */
    ReleasePtr(barh);
    } /* itempos else */

    if (item >= 0) {
    pd_itemx1 = pd_cardx1+pd_charwidth-2;
    pd_itemx2 = pd_cardx2-pd_charwidth+2;
    pd_itemy2 = pd_itemy1+pd_itemheight;
    if ((pd_itemx1 >= pd_itemx2) || (pd_itemy1 >= pd_itemy2))
        item = -1; /* no room for selection box */
    else
        {
        TUTORset_rect(&tr,pd_itemx1,pd_itemy1,pd_itemx2,pd_itemy2);
        TUTORframe_abs_rect((TRect FAR *) &tr);
        }
    }
    pd_itemsel = item; /* -1 or item selected */
    pd_restore();
    return(item);

} /* pd_selectitem */

/* ********************************************************* */

#ifdef IBMPC

int pd_in_menu(xx,yy) /* check if point in menu card */
/* returns window number if point in card, -1 if not */
int xx,yy; /* x/y co-ordinates of point */

{   int ww; /* index in window tables */
    int wx,wy;  /* x,y relative to window */

    for (ww=0; ww<WINDOWLIMIT; ww++) {
        wx = xx-wmg_xo[ww];
        wy = yy-wmg_yo[ww]-pd_barheight;
        if ((pd_state[ww] == 1) && (wx >= pd_cardx1) &&
           (wx <= pd_cardx2) && (wy >= pd_cardy1) &&
           (wy <= pd_cardy2))
            return(ww); /* return window number */
    } /* for */
    return(-1); /* not in menu bar or card */
    
} /* pd_in_menu */

#endif

/* ********************************************************* */

pd_display_bar(wx)
int wx; /* index of window */

{   int dindex; /* current display order index */
    int cpos; /* index of current card */
    int endx; /* ending x position of current card name */
    Memh barh; /* handle on menu bar */
    TutorMenuBar FAR *bar; /* pointer to menu bar structure */
    char FAR *cnm; /* pointer to card name */
    TRect tr;

    barh = windowsP[wx].menus;
    if (barh == 0) return(0);
    if (pd_font == 0) { /* force initialization */
        pd_enter(CurrentWindow);
        pd_restore();
    } /* pd_font if */

    bar = (TutorMenuBar FAR *) GetPtr(barh);
    pd_enter(wx);
    if (pd_menualt[wx])
        pd_menu_change(wx); /* compute card order/position */
    pd_menualt[wx] = FALSE;
    wmg_frame(wx);
    TUTORset_rect(&tr,0,-pd_barheight,10000,-1);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_WHITE);
    if (pd_wmctrlw) {
        TUTORset_rect(&tr,wmg_xs[wx]-pd_wmctrlw-2,
            2-pd_barheight,wmg_xs[wx]-2,-4);
        TUTORdraw_abs_solid_rect((TRect FAR *) &tr,PAT_BLACK);
    } /* pd_wmctrlw */
    TUTORabs_move_to(0,-1);
    TUTORabs_line_to(wmg_xs[wx]-1,-1);
    TUTORset_comb_rule(SRC_OR);  /* mode write */
    dindex = 0;
    if (pd_wmctrlw) endx = wmg_xs[wx]-pd_wmctrlw-2;
    else endx = wmg_xs[wx]-1;
    while ((cpos = pd_find_itemdn(wx,MENUCARD,-1,dindex)) >= 0) {
        if (bar->items[cpos].p2 < endx) {
        	cnm = bar->items[cpos].name;
        	TUTORabs_move_to(bar->items[cpos].p1,-pd_barheight+pd_ascent);
        	TUTORdraw_text((unsigned char FAR *) cnm,(int)strlenf(cnm));
        } /* p2 < endx if */
        dindex++;
    } /* while */
    pd_restore();
    ReleasePtr(barh);

} /* pd_display_bar */

/* ******************************************************* */

pd_enter(menw) /* save/initialize status for menu operation */
int menw;   /* index of window */

{   int ascent, descent, maxwidth, leading;
    TRect tr;

    machineflush();
    TUTORmouse_off(); /* hide cursor on IBM-PC */
    fontid = textFont; /* save current font */
    pd_swix = CurrentWindow;
    pd_sx = RealX; /* save x,y position */
    pd_sy = RealY;
    pd_fc = fgndColor.palette; /* save foreground, background colors */
    pd_bc = bgndColor.palette;
    pd_mode = CurrentMode;
    pd_cx = tgclipx; /* save clip region */
    pd_cy = tgclipy;
    pd_cw = tgclipw;
    pd_ch = tgcliph;
	pd_thick = lineThick;

    TUTORset_window(menw);
    wmg_on(); /* allow output even if window obscured */

    if (pd_font == 0) {
#ifdef IBMPC
        pd_font = TUTORget_zfont("system",10);
#else
        /* pd_font = textFont0; */
        pd_font = TUTORget_zfont("zserif",18);
#endif
        TUTORset_textfont(pd_font);
        TUTORinq_font_info(&pd_ascent,&descent,&maxwidth,&leading);
        pd_barheight = pd_itemheight = pd_ascent+descent;
        TUTORinq_abs_string_width((unsigned char FAR *) "n",1,&pd_charwidth);
    } else TUTORset_textfont(pd_font);

    tr.left = 0;
    tr.top = -pd_barheight;
    tr.right = tr.bottom = 10000;
    TUTORset_abs_clip_rect((TRect FAR *) &tr); /* unclip */
    TUTORset_comb_rule(SRC_OR);  /* mode write */
	lineThick = 0;
    CTset_foreground_color(color_defaultf);
    CTset_background_color(color_defaultb);

} /* pd_enter */

/* ******************************************************** */

pd_restore() /* restore status after menu operation */

{	TRect tr;
    
	if (pd_swix < 0)
		return(0); /* nothing to do */
	
    TUTORset_window(pd_swix); /* set window in case no view */
    if (pd_mode >= 0)
        TUTORset_comb_rule((int)pd_mode); /* restore mode */
    else TUTORset_comb_rule(SRC_OR);
    TUTORset_rect(&tr,pd_cx,pd_cy,pd_cx+pd_cw-1,pd_cy+pd_ch-1);
    TUTORset_abs_clip_rect((TRect FAR *) &tr); 
    TUTORabs_move_to(pd_sx,pd_sy);
    if (fontid < 0) 
	fontid = pd_font;
    TUTORset_textfont(fontid);
    CTset_foreground_color(pd_fc);
    CTset_background_color(pd_bc);
	TUTORline_thick(pd_thick);
    TUTORmouse_on(); /* restore cursor on IBM-PC */
    machineflush();

} /* pd_restore */

/* ********************************************************* */

static pd_menu_change(ww)
int ww; /* index of window */

{   int cpriority; /* current highest priority */
    int cpos; /* current card position */
    int dindex; /* display order index of current card */
    Memh barh; /* handle on menu bar */
    TutorMenuBar FAR *bar; /* pointer to menu bar structure */
    int xx; /* x position in menu bar */
    int twidth; /* width of title */
    int cp; /* current priority */
    int best; /* best match so far */

    barh = windowsP[ww].menus;
    bar = (TutorMenuBar FAR *) GetPtr(barh);
    xx = pd_charwidth; /* x position in menu bar */
    cpriority = 101; /* look for highest priority card */
    best = 0;
    dindex = 0;
    cpos = 0; /* starting position */
    while (cpriority >= 0) {

    /* find all cards at current highest level */

    cpos = best = 0;
    while ((cpos >= 0) &&
        ((cpos = pd_find_high_menu(ww,MENUCARD,-1,cpos,cpriority)) >= 0)) {
        cp = 100-bar->items[cpos].priority;
            if (cp >= best) {
        best = cp;
            bar->items[cpos].p1 = xx;
                TUTORinq_abs_string_width((unsigned char FAR *) bar->items[cpos].name,
                      (int)strlenf(bar->items[cpos].name),&twidth);
            bar->items[cpos].p2 = xx+twidth;
            bar->items[cpos].mindex = dindex++;
            xx = bar->items[cpos].p2+2*pd_charwidth;
            if (bar->items[cpos].altered) {
            pd_item_change(ww,cpos);
        }
            bar->items[cpos].altered = FALSE;
            cpos++;
        } else cpos = -1; /* no more at this priority */
        } /* cpos while */
        cpriority = best-1;
    } /* cpriority while */

    ReleasePtr(barh);

} /* pd_menu_change */

/* ****************************************************** */

static pd_item_change(ww,cardi)
int ww; /* index of window */
int cardi; /* index of card altered */

{   int ipriority; /* current ceiling priority */
    int best; /* current highest priority */
    int cp; /* current priority */
    int ipos; /* current item position */
    int dindex; /* display order index of current card */
    Memh barh; /* handle on menu bar */
    TutorMenuBar FAR *bar; /* pointer to menu bar structure */
    int yy; /* y position in menu card */
    int maxwidth; /* maximum width of menu item */
    int twidth; /* width of title */

    barh = windowsP[ww].menus;
    bar = (TutorMenuBar FAR *) GetPtr(barh);

    ipriority = 101; /* look for highest priority item */
    best = 0;
    dindex = 0;
    maxwidth = 0;
    yy = 0;
    while (ipriority >= 0) {

        /* find all items at current highest level */

        ipos = best = 0;
    while ((ipos >= 0) &&
        ((ipos = pd_find_high_menu(ww,MENUITEM,cardi,ipos,ipriority)) >= 0)) {
            cp = 100-bar->items[ipos].priority;
        if (cp >= best) {
            best = cp;
            bar->items[ipos].p1 = yy;
                TUTORinq_abs_string_width((unsigned char FAR *) bar->items[ipos].name,
              (int)strlenf(bar->items[ipos].name),&twidth);
            bar->items[ipos].p2 = twidth;
            if (bar->items[ipos].p2 > maxwidth)
            maxwidth = bar->items[ipos].p2;
            yy += pd_itemheight;
        bar->items[ipos].mindex = dindex++;
        ipos++;
        } else ipos = -1; /* no more at this priority */
        } /* ipos while */
        ipriority = best-1;
    } /* ipriority while */
    bar->items[cardi].width = maxwidth+2*pd_charwidth; /* width of menu card */
    bar->items[cardi].nitems = dindex; /* number of items on card */

    ReleasePtr(barh);

} /* pd_item_change */

/* ******************************************************* */

int pd_find_high_menu(ww,type,card,position,priority)
int ww; /* index of window */
int type; /* card/item type */
int card; /* card number if searching for item */
int position; /* starting position for search */
int priority; /* priority ceiling */

{   Memh barh; /* handle on menu bar */
    int find; /* position of menu card found */
    int best; /* best matching priority so FAR */
    int cp; /* current item priority */
    TutorMenuItem FAR *mp;
    TutorMenuBar FAR *bar;

    if (priority < 0) return(-1);
    barh = windowsP[ww].menus;
    bar = (TutorMenuBar FAR *) GetPtr(barh);
    if (type == MENUCARD) card = -1;

    find = -1; /* nothing found yet */
    best = -1;
    while (position < bar->nItems) {
    mp = &(bar->items[position]);
    cp = 100-mp->priority;
    if ((mp->itemKind == type) && (cp <= priority) &&
       ((card < 0) || (card == mp->cardI))) {
        if (cp > best) {
        best = cp;
        find = position;
        } /* best if */
    } /* priority if */
    position++;
    } /* position while */

    ReleasePtr(barh);
    return(find);

} /* pd_find_high_menu */

/* ****************************************************** */

int pd_find_itemdn(ww,type,cardi,n)
/* locate card/item by display order index */
int ww; /* index of window */
int type; /* card/item type */
int cardi; /* index of card if menu item */
int n; /* display order index */

{   Memh barh; /* handle on menu bar */
    int position; /* current card/item position */
    TutorMenuItem FAR *mp;
    TutorMenuBar FAR *bar;

    barh = windowsP[ww].menus;
    bar = (TutorMenuBar FAR *) GetPtr(barh);
    if (type == MENUCARD) cardi = -1;

    position = 0;
    while (position < bar->nItems) {
    mp = &(bar->items[position]);
    if ((mp->itemKind == type) && (mp->mindex == n) &&
        ((cardi < 0) || (mp->cardI == cardi))) {
        ReleasePtr(barh);
        return(position);
    } /* type if */
    position++;
    } /* position while */

    ReleasePtr(barh);
    return(-1);

} /* pd_find_itemdn */

/* ******************************************************* */

int pd_bar_hit(ww,mx,barpos)   /* determine which card has been hit */
int ww; /* index of window */
int mx; /* x position */
int *barpos; /* returned position of card in title bar */

{   int dindex; /* current display order index */
    int cpos; /* index of current card */
    Memh barh; /* handle on menu bar */
    TutorMenuBar FAR *bar; /* pointer to menu bar structure */

    barh = windowsP[ww].menus;
    bar = (TutorMenuBar FAR *) GetPtr(barh);

    dindex = 0;
    while ((cpos = pd_find_itemdn(ww,MENUCARD,-1,dindex)) >= 0) {
    if ((mx >= bar->items[cpos].p1) && (mx <= bar->items[cpos].p2)) {
        ReleasePtr(barh);
        *barpos = dindex;
        return(cpos);
    } /* mx if */
    dindex++;
    } /* while */

    ReleasePtr(barh);
    *barpos = -1;
    return(-1); /* not on any card */

} /* pd_bar_hit */

/* ******************************************************** */

pd_card_hit(ww,card,my,itempos)    /* determine which item has been hit */
int ww; /* index of window */
int card; /* card to search */
int my; /* y position */
int *itempos;  /* position of item within card */

{   int dindex; /* current display order index */
    int find; /* index of item hit */
    int ip;
    Memh barh; /* handle on menu bar */
    TutorMenuBar FAR *bar; /* pointer to menu bar structure */
    TutorMenuItem FAR *mp; /* pointer to menu item structure */

    barh = windowsP[ww].menus;
    bar = (TutorMenuBar FAR *) GetPtr(barh);

    find = ip = -1; /* pre-set not found */
    for (dindex=0; dindex<bar->nItems; dindex++) {
    mp = &bar->items[dindex];
    if ((mp->cardI == card) && (mp->itemKind == MENUITEM)) {
        if ((my >= mp->p1) && (my <= (mp->p1+pd_itemheight))) {
        find = dindex;
        ip = mp->mindex;
            }
    } /* card if */
    } /* for */

    ReleasePtr(barh);
    *itempos = ip;
    return(find);

} /* pd_card_hit */

/* ********************************************************* */

int TUTORinq_wmg_busy(window)
/* return TRUE if menu or window move/resize operation in */
/* progress which should suppress processing for specified */
/* window (-1 for all windows) */

int window;

{   int wi;

    if (window < 0) {
        if (wmg_select >= 0) return(TRUE);
        for(wi=0; wi<WINDOWLIMIT; wi++)
        if (pd_state[wi]) return(TRUE);
    } else {
        if (pd_state[window]) return(TRUE);
        if (wmg_select == window) return(TRUE);
    }
    return(FALSE);

} /* TUTORinq_wmg_busy */

/* ********************************************************* */

int TUTORinq_overlap(r1,r2) /* check if rectangles overlap */
TRect *r1;
TRect *r2;

{
    if (r1->left > r2->right) return(FALSE);
    if (r2->left > r1->right) return(FALSE);
    if (r1->top > r2->bottom) return(FALSE);
    if (r2->top > r1->bottom) return(FALSE);
    return(TRUE);

} /* TUTORinq_overlap */

/* ********************************************************* */

int  pd_save_region()

{

    pd_region_id = TUTORabs_save_region(pd_cardx1,pd_cardy1,
                pd_cardx2,pd_cardy2);

} /* pd_save_region */

/* ********************************************************* */

int  pd_restore_region()

{	long sav_inhibbits;

    if (!pd_region_id)
    	return; /* nothing to restore */

    TUTORabs_restore_region(pd_region_id,pd_cardx1,pd_cardy1);

    TUTORfree_region(pd_region_id);
    pd_region_id = 0;

} /* pd_restore_region */

/* ********************************************************* */
