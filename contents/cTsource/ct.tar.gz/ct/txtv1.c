
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "baseenv.h"
#include "txt.h"
#include "txtv.h"
#include "tutor.h"
#include "editor.h"
#include "kdefs.h"
#include "tutor.h"
#include "tglobals.h"
#include "kglobals.h"

#ifdef ctproto
extern int TUTORupmove_tview(Memh theV,TPoint where);  
extern int TellExecInt(void);
int  TUTORclick_tview(unsigned int  theV,struct  _tpoint where,int  extend);
extern int  HotAction(struct  _viewp FAR *tvp,int  inHot);
int  TUTORclick_drag_tview(unsigned int  theV,struct  _tpoint newWhere);
int  TUTORclick_done_tview(unsigned int  theV,struct  _sbarinf *vb);
extern int  MoveSelection(struct  _viewp FAR *tvp,struct  _ps *newA);
int  TUTORset_select_tview(unsigned int  theV,long  pos,long  len,struct  _sbarinf *vb);
extern int  _TUTORwhere_pos_tview(struct  _viewp FAR *tvp,struct  _tpoint where,struct  _ps FAR *post,struct  _ps *wordE,int  byWord,int  *inHot,int *onChar);
int  TUTORwhere_pix_tview(unsigned int  theV,struct  _ps FAR *posp);
int  _TUTORmeasure_text_tview(unsigned int  doc,long  pos,struct  _linelay FAR *liLay,int  newP,int  flag,int  info,int  *wUsed,int  *whichSide);
int  _TUTORhilite_select(unsigned int  theV,int  onoff);
int  _TUTORdraw_caret_tview(struct  _viewp FAR *tvp,int  mess);
int  _TUTORdraw_selr_tview(struct  _viewp FAR *tvp,struct  _ps FAR *p1,struct  _ps FAR *p2);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORpost_event(struct  tutorevent *event);
long  TUTORget_len_doc(unsigned int  doc);
unsigned char  FAR *GetHotstringTStyle(unsigned int  pd,int  id,long  *len,long  *spos,long  *slen,int  getS);
int  TUTORdouble_click(short  *hh,short  *vv);
int  TUTORpoint_in_rect(struct  _tpoint pt,struct  _trect *r);
int  _TUTORinfo_vbar_tview(struct  _viewp FAR *tvp,struct  _sbarinf *vb);
int  TUTORscroll_middleV(unsigned int  theV,long  pos);
long  _TUTORline_pos_tview(struct  _viewp FAR *tvp,int  lineN);
int  TUTORword_bounds2_doc(unsigned int  doc,long  pos,long  *wordSp,long  *wordEp,int  wSide);
int  TUTORinq_hot_doc(unsigned int  doc,long  pos,int  wSide);
int  _TUTORset_textfont_doc(struct  _ktd FAR *dp,short  *curStyles);
int  _TUTORsetup_layout(struct  _ktd FAR *dp,long  pos,long  len,int  *styleInd,struct  _pdt FAR * *styleP,short  *curStyles,struct  _paral *pLay,int  *stind,struct  _spt2 FAR * *stp,int  fillDef);
int  _TUTORload_buffer_doc(struct  _ktd FAR *dp,long  pos);
int  _TUTORline2_vv_tview(struct  _viewp FAR *tvp,int  nn);
unsigned char  FAR *TUTORscan_bytes(unsigned char  FAR *bp,unsigned char  FAR *be,unsigned char  *tp,int  nTab);
int  TUTORdump(char  *s);
int  TUTORinq_abs_string_width(unsigned char  FAR *s,int  lth,int  *dx);
int  _TUTORtab_width_doc(struct  _paral *pLay,int  curX);
int  TUTORmeasure_stext(struct  _stxt2 FAR *st1p,int  *asc,int  *desc,int  *lead);
int  _TUTORset_curstyles_doc(struct  _ktd FAR *dp,struct  _sty1 FAR *s1p,short  *curStyles);
int  TUTORhilite(int  x1,int  y1,int  x2,int  y2);
int  TUTORset_comb_rule(int  rule);
int  TUTORabs_line(int  hh,int  vv);
int  TUTORabs_move_to(int  x,int  y);
int  TUTORinq_comb_rule(void);
#endif /* ctproto */

#ifdef macproto
long  _TUTORscrollv_tview(unsigned int  theV,int  stype,long  arg);
extern int TUTORinq_select_styles_tview(Memh theV, short *styles, char *haveStyels);
extern int AtTStyle(Memh pd,long pos, short *styles);
extern int FindBlockTStyle(struct _pdt FAR *pp,long pos);
#endif

unsigned char FAR *GetHotstringTStyle();
extern unsigned char FAR *TUTORscan_bytes();
extern long _TUTORline_pos_tview();
extern char FAR *GetPtr();
extern long _TUTORscrollv_tview();
long TUTORget_len_doc();

extern char anyDown; /* refered to by tgraph... */

/* parameters for drawing caret on "virtual line" (line that is after all text) */
#define VLINEHEIGHT 10
#define VLINEASCENT 6

static int gInHot = 0; /* when > 0, do HotAction on mouse up */
int gUpHot = 0; /* last hot selection hit during up-move */

TUTORclick_tview(theV,where,extend) /* handle mouse clicks (set selection...) */
Memh theV;  /* the tview */
TPoint where;   /* click position, in local coordinates */
int extend; /* TRUE if click should be extended (shift key pressed, or right button click) */
/* returns TRUE if click changed insert position */
    {
    Position newClick;  /* the position of the click, in document terms */
    TPoint oldWhere;    /* position of first click of double click
                            (the current click being the second) */
    Position oldClick;  /* position of oldWhere, in document terms */
    Position wordE;     /* position of the end of the word clicked in */
    REGISTER TViewP tvp;    /* pointer to tview */
    TRect tempR;    /* copy of view rect */
    
    gUpHot = 0;
    tvp = (TViewP) GetPtr(theV);
    if (tvp->duringClick)
        {
        ReleasePtr(theV);
        KillPtr(tvp);
        return(FALSE);
        }

    tempR = tvp->viewRect;
    if (!TUTORpoint_in_rect(where,&tempR))
        { /* click isn't in view, ignore it */
        ReleasePtr(theV);
        KillPtr(tvp);
        return(FALSE);
        }

    tvp->byWord = FALSE;
    tvp->hotPos = tvp->hotLen = -1; /* clear hot text selection */
    if (!_TUTORwhere_pos_tview(tvp, where,(Position FAR *) &newClick,NEARNULL,FALSE,NEARNULL,NEARNULL)) 
        {
        ReleasePtr(theV);
        KillPtr(tvp);
        return(FALSE); /* return if in invisible (but used click) */
        }
    
    tvp->duringClick = TRUE; /* we are now working on a click */
#ifdef MACx
    anyDown = TRUE;
#endif
    
    if (!extend && (TUTORdouble_click(&oldWhere.hh,&oldWhere.vv) || tvp->singleSel))
        { 
        if (tvp->singleSel)
            oldWhere = where; /* treat as if double click */
        /* check to see if second of double click was in same spot as last up (which is in oldWhere) */
        if (_TUTORwhere_pos_tview(tvp,oldWhere,(Position FAR *) &oldClick,NEARNULL,FALSE,&gInHot,NEARNULL) && oldClick.pos == newClick.pos)
            { /* normal double-click, do selection by words */
            _TUTORhilite_select(theV,FALSE); /* turn off old selection */
            _TUTORwhere_pos_tview(tvp,oldWhere,&tvp->anchor,&wordE,TRUE,NEARNULL,NEARNULL);
            tvp->byWord = TRUE;
            tvp->selA = wordE;
            _TUTORhilite_select(theV,TRUE); /* turn on new selection */
            windowsP[CurrentWindow].ldowntime2 = 0;
            }
        }
    if (!tvp->byWord)
        if (!extend)
            { /* simplest case, a non-extended click */
            _TUTORhilite_select(theV,FALSE);
            tvp->anchor = tvp->selA = newClick;
            _TUTORdraw_caret_tview(tvp,2);
            }
        else
            {
            MoveSelection(tvp,&newClick);
            }
    
    ReleasePtr(theV);
    KillPtr(tvp);

    return(TRUE);
    }


TUTORupmove_tview(theV,where) /* handle mouse move, no buttons pressed */
Memh theV;  /* the tview */
TPoint where;   /* click position, in local coordinates */

    
{	Position newClick;  /* the position of the click, in document terms */
    TPoint oldWhere;    /* position of first click of double click
                            (the current click being the second) */
    Position oldClick;  /* position of oldWhere, in document terms */
    Position wordE;     /* position of the end of the word clicked in */
    REGISTER TViewP tvp;    /* pointer to tview */
    TRect tempR;    /* copy of view rect */
    
    tvp = (TViewP) GetPtr(theV);
    if (tvp->duringClick) {
    	gUpHot = 0;
        ReleasePtr(theV);
        KillPtr(tvp);
        return(FALSE);
    }

    tempR = tvp->viewRect;
    if (!TUTORpoint_in_rect(where,&tempR)) { /* move isn't in view, ignore it */
    	gUpHot = 0;
        ReleasePtr(theV);
        KillPtr(tvp);
        return(FALSE);
    }

    tvp->hotPos = tvp->hotLen = -1; /* clear hot text selection */
    if (!_TUTORwhere_pos_tview(tvp, where,(Position FAR *) &newClick,NEARNULL,FALSE,NEARNULL,NEARNULL)) {
        ReleasePtr(theV);
        KillPtr(tvp);
        return(FALSE); /* return if in invisible (but used click) */
    }
    
   
    if (_TUTORwhere_pos_tview(tvp,where,(Position FAR *) &oldClick,NEARNULL,FALSE,&gInHot,NEARNULL)) {
    	if (!gInHot) 
    		gUpHot = 0;
    	if (gInHot && (gInHot != gUpHot)) { /* take care of move over hot text */
        	HotAction(tvp,gInHot);
        	tvp->duringClick = FALSE; /* not doing a click */
        	gUpHot = gInHot;
        	gInHot = 0;
        }
    }
    
    ReleasePtr(theV);
    KillPtr(tvp);

    return(TRUE);
    
} /* TUTORupmove_tview */

extern int ExecWn;

static HotAction(tvp, inHot)    /* perform action when hot text is double-clicked */
TViewP tvp; /* pointer to tview */
int inHot;  /* the hot text style data (which is hot text id) */
    {
    struct tutorevent tempEv;   /* event we post when hot text is double-clicked */
    DocP dp;    /* pointer to document */
    long len;   /* length of hot text info string */
    long spos, slen;    /* region of doc that has this hot text style on it */
    
    dp = (DocP) GetPtr(tvp->doc);
    tempEv.eDataP = (char FAR *) GetHotstringTStyle(dp->styles,inHot,&len,&spos,&slen,TRUE);
    if ((spos >= 0) && (slen < 0))
        slen = TUTORget_len_doc(tvp->doc)-spos;
    tvp->idHot = inHot;
    tvp->hotPos = spos;
    tvp->hotLen = slen;
    if (tempEv.eDataP)
        {
        TellExecInt(); /* tell executor to interrupt */
        tempEv.type = EVENT_HOT;
        tempEv.value = inHot;
        tempEv.window = tvp->ownerV->window;
        tempEv.view = FARNULL;
        tempEv.timestamp = 0;
        tempEv.a5 = (long)tvp->ownerV;
        tempEv.a2 = tvp->ownerV->refc;
        tempEv.a4 = len;
        TUTORpost_event(&tempEv);
        }
    ReleasePtr(tvp->doc);
    KillPtr(dp);
    
    return(0);
    }

TUTORclick_drag_tview(theV,newWhere) /* to be called upon a mouse-move AFTER TUTORclick_tview */
Memh theV;  /* tview */
TPoint newWhere; /* the new position */
    {
    Position newClick;  /* position (in terms of doc) of newWhere */
    REGISTER TViewP tvp;    /* pointer to tview */
    int scrollFlag; /* 0: no scroll, 1: scroll down, -1 scroll up */
    TRect tempR;    /* copy of tview viewRect */
    
    tvp = (TViewP) GetPtr(theV);
    if (!tvp->duringClick)
        {
        ReleasePtr(theV);
        KillPtr(tvp);
        return(FALSE); /* we aren't working on a valid click */
        }

/* #ifdef MAC	*/
    /* autoscroll if drag goes past view boundaries */
    tempR = tvp->viewRect;
    if (TUTORpoint_in_rect(newWhere, &tempR))
        anyDown = FALSE;
    else
        {
        anyDown = TRUE; /* anyDown TRUE only when working on a kview click & outside view */
        scrollFlag = 0;
        if (newWhere.vv < tvp->viewRect.top)
            scrollFlag = -1;
        else if (newWhere.vv > tvp->viewRect.bottom)
            scrollFlag = 1;
        
        if (scrollFlag)
            { /* we want to scroll */
            ReleasePtr(theV); /* scroll may cause reallocation of theV */
            KillPtr(tvp);
            _TUTORscrollv_tview(theV,(scrollFlag == -1) ? sbLineUp : sbLineDown,0L);
            tvp = (TViewP) GetPtr(theV);
            }
        }
/* #endif  */

    if (_TUTORwhere_pos_tview(tvp, newWhere,(Position FAR *) &newClick,NEARNULL,tvp->byWord,NEARNULL,NEARNULL)
            && newClick.pos != tvp->selA.pos)
        {
        MoveSelection(tvp,&newClick);
        ReleasePtr(theV);
        KillPtr(tvp);
        /* if needed, scroll */
        }
    else
        {
        ReleasePtr(theV);
        KillPtr(tvp);
        }
    
    return(TRUE);
    }

TUTORclick_done_tview(theV,vb) /* mouse-up handler */
Memh theV;  /* tview */
SBarInfo *vb;   /* to be filled with vertical scroll bar info */
/* returns TRUE if click-up was valid */
    {
    REGISTER TViewP tvp;    /* pointer to tview */

#ifdef MAC
    anyDown = FALSE;
#endif

    tvp = (TViewP) GetPtr(theV);

    if (gInHot)
        { /* take care of click in hot text */
        HotAction(tvp,gInHot);
        tvp->duringClick = FALSE; /* because dialog has eaten mouse up */
        gInHot = 0;
        }

    if (!tvp->duringClick)
        {
        ReleasePtr(theV);
        KillPtr(tvp);
        return(FALSE);
        }
    tvp->duringClick = FALSE;

    _TUTORinfo_vbar_tview(tvp,vb);
    ReleasePtr(theV);
    KillPtr(tvp);

    return(TRUE);
    }

static MoveSelection(tvp,newA) /* change the selection */
register TViewP tvp;    /* pointer to tview */
Position *newA; /* new position of active end of selection */
    {
    if (tvp->anchor.pos == tvp->selA.pos)
        _TUTORdraw_caret_tview(tvp,1); /* erase caret */
    
    if ((!tvp->highSel) || (newA->pos == tvp->anchor.pos))
        { /* selection now at single position */
        _TUTORhilite_select(tvp->self,FALSE); /* turn off existing hilite */
        tvp->selA = *newA;
        _TUTORdraw_caret_tview(tvp,2);  /* draw caret */
        }
    else
        { /* change selection region */
        if (tvp->selA.pos < newA->pos)
            _TUTORdraw_selr_tview(tvp,&tvp->selA,(Position FAR *) newA);
        else
            _TUTORdraw_selr_tview(tvp,(Position FAR *) newA,&tvp->selA);
        tvp->selA = *newA;
        }
    tvp->caretState = TRUE; /* hilighting is on */
    
    return(0);
    }

TUTORset_select_tview(theV,pos,len,vb)  /* set the selection */
Memh theV;  /* tview */
register long pos,len;  /* the newly desired selection (in document terms) */
SBarInfo *vb;   /* to be set to new vertical scroll bar info */
/* returns TRUE if scrolled */
    {
    REGISTER TViewP tvp;    /* pointer to tview */
    int ii;
    long topPos;    /* position at start of top line */
    long botPos;    /* position after last character fully showing */
    int retVal;     /* TRUE if we scrolled */
    
    tvp = (TViewP) GetPtr(theV);
    if (pos == tvp->anchor.pos && pos+len == tvp->selA.pos)
        { /* we already have this selection */
        if (vb)
            _TUTORinfo_vbar_tview(tvp,vb);
        ReleasePtr(theV);
        KillPtr(tvp);
        return(FALSE);
        }
    
    _TUTORhilite_select(theV,FALSE);

    retVal = FALSE;
    topPos = _TUTORline_pos_tview(tvp,tvp->topLine);
    botPos = tvp->botPos;
    if (tvp->botV > tvp->viewRect.bottom)
        botPos -= tvp->ld[tvp->botLine].nc;
    if (((len == 0 && pos < topPos) || (len > 0 && pos+len <= topPos)) ||
            ((len == 0 && pos > botPos) || (len > 0 && pos >= botPos)))
        { /* selection isn't on screen, we'll have to scroll */
        ReleasePtr(theV);
        KillPtr(tvp);
        TUTORscroll_middleV(theV,pos);
        tvp = (TViewP) GetPtr(theV);
        retVal = TRUE;
        }
    
    /* set up selections */
    tvp->anchor.pos = pos;
    tvp->anchor.atEnd = FALSE;
    TUTORwhere_pix_tview(theV,&tvp->anchor);
    tvp->selA.pos = pos+len;
    tvp->selA.atEnd = TRUE;
    TUTORwhere_pix_tview(theV,&tvp->selA);

    _TUTORhilite_select(theV,TRUE);
    
    if (vb)
        _TUTORinfo_vbar_tview(tvp,vb);

    ReleasePtr(theV);
    KillPtr(tvp);

    return(retVal);
    }

#ifdef MAC
TUTORinq_select_styles_tview(theV,styles,haveStyles) /* get styles of selection region */
Memh theV;  /* tview */
short *styles;  /* if a unique style, sets to that style */
char *haveStyles; /* set to TRUE if there is a unique style in selection range */
    {
    REGISTER TViewP tvp;    /* pointer to tview */
    DocP dp;    /* pointer to document */
    register int ii;
    int ind;
    long pos1;
    long pos2;
    long tempL;
    StyleDatP sp;
    register Style1 SHUGE *s1p;
    Style1 SHUGE *s1End;
    
    /* we expect styles for everything */
    for (ii=0; ii<NSTYLES; ii++)
        haveStyles[ii] = TRUE;

    tvp = (TViewP) GetPtr(theV);
    dp = (DocP) GetPtr(tvp->doc);
    if (!dp->styles)
        { /* no styles - everything is default */
        for (ii=0; ii<NSTYLES; ii++)
            styles[ii] = DEFSTYLE;
        /* we only want actual justification for paragraph style */
        styles[PARASTYLE] = dp->defStyles[PARASTYLE] & JUSTMASK;
        }
    else
        {
        pos1 = tvp->anchor.pos;
        pos2 = tvp->selA.pos;
        if (pos1 > pos2)
            { /* swap positions so that pos1 <= pos2 always */
            tempL = pos1;
            pos1 = pos2;
            pos2 = tempL;
            }
        
        /* get styles at beginning */
        tempL = pos1;
        if (pos1 > 0 && pos1 == pos2)
            tempL--; /* look at previous position so we handle style changes properly */
        AtTStyle(dp->styles,tempL,styles);

        /* but we want paragraph style including changes AT pos1 */
        sp = (StyleDatP) GetPtr(dp->styles);
        ind = FindBlockTStyle(sp,pos1);
        s1p = ((Style1 SHUGE *) sp->styles);
        s1End = s1p + sp->sHead.dAnn;
        s1p += ind;
        while (s1p < s1End && s1p->pos <pos1)
            s1p++; /* skip over blocks before pos1 */
        while (s1p < s1End && s1p->pos == pos1)
            {
            if (s1p->type == PARASTYLE)
                styles[PARASTYLE] = s1p->dat; /* get change at pos1 */
            s1p++;
            }
        
        if (pos2 > pos1)
            { /* look thru range of positions to see if style changes in range */
            
            /* s1p should now be past pos1 */
            
            /* look over range */
            while (s1p < s1End && s1p->pos < pos2)
                {
                haveStyles[s1p->type] = FALSE; /* found a change */
                s1p++;
                }
            
            }
        
        ReleasePtr(dp->styles);
        KillPtr(sp);
        
        /* we only want actual justification for paragraph style */
        styles[PARASTYLE] = styles[PARASTYLE] & JUSTMASK;
        }
    ReleasePtr(tvp->doc);
    KillPtr(dp);
    
    ReleasePtr(theV);
    KillPtr(tvp);
    
    return(TRUE);
    }
#endif

int _TUTORwhere_pos_tview(tvp,where,post,wordE,byWord,inHot,onChar) /* given screen location, calculate character position */
register TViewP tvp;
TPoint where; /* screen location, in local coords */
Position FAR *post; /* calculated location of click (new active end of selection) */
Position *wordE; /* location of end of current word (set only if byWord TRUE) */
int byWord; /* TRUE: selection is being done by word, set wordE */
int *inHot; /* set to hot id if click was in hot style */
int *onChar; /* +2 = click was after entire line */
             /* +1 = click was after position returned */
             /* -1 = click was before position returned */
             /* -2 = click was before entire line */
/* returns TRUE if click in visible area, FALSE if in invisible area */
    {
    short lineN, usedW;
    long ncOld, wordSp,wordEp;
    int vBot;
    short uF; /* not used, dummy for NChars */
    long pos;
    int ii, wUsed;
    int wSide;  /* which side of pos was click actually on? */
    int onCharWk; /* working copy of onChar value */
    
    onCharWk = 0; /* not set yet */
    
    /* adjust where */
    where.vv -= tvp->viewRect.top;
    where.hh -= tvp->leftOff + tvp->viewRect.left;
    if (where.hh < 0) {
        where.hh = 0;   /* to left of viewRect */
        onCharWk = -2; /* before entire line */
    }

    if (inHot)
        *inHot = 0; /* default is not hot */
    
    /* now find which line we're in */

    if (where.vv < 0)
        { /* click is above viewRect */
        /* force into top line */
        lineN = tvp->topLine;
        vBot = tvp->ld[tvp->topLine].lineHeight;
        onCharWk = -2; /* before entire line */
        }
    else
        { /* click is below top of viewRect (normal case) */
        lineN = tvp->topLine;
        if (tvp->txtvH.dAnn > lineN && lineN >= 0)
            { /* there are some lines showing */
            vBot = (long) tvp->ld[lineN].lineHeight;
            while (where.vv >= vBot && lineN < tvp->botLine)
                {
                lineN++;
                vBot += (long) tvp->ld[lineN].lineHeight;
                }
            }
        else
            { /* there are no lines, fix it so we fall into "after end" code */
            vBot = -100;
            onCharWk = 2; /* after entire line */
            }
        
        if (lineN >= tvp->botLine && where.vv > vBot)
            { /* click is below last line showing */
            onCharWk = 2; /* click is after entire line */
            if (tvp->botPos >= tvp->bounds.pos + tvp->bounds.len)
                { /* there is no more after bottom, set position to view end */
                post->pos = tvp->bounds.pos + tvp->bounds.len;
                post->atEnd = TRUE;
                if (post->pos == 0)
                    post->atEnd = FALSE; /* a completely empty file */
                TUTORwhere_pix_tview(tvp->self,(Position FAR *) post);
                if (byWord)
                    {
                    TUTORword_bounds2_doc(tvp->doc,post->pos,&wordSp,&wordEp,1);
                    if (wordE)
                        *wordE = *post; /* since must be word end */
                    post->pos = wordSp;
                    post->atEnd = FALSE;
                    TUTORwhere_pix_tview(tvp->self,(Position FAR *) post);
                    }
                if (onChar)
                    *onChar = onCharWk;
                return(TRUE);
                }
            else
                { /* line after last line showing */
                /* force it into last line */
                lineN = tvp->botLine;
                }
            }
        } /* end of normal case of click vertical */
    
    post->nLine = lineN;
    if (tvp->ld[lineN].lineAsc == 0)
        { /* in an invisible line */
        if (onChar) 
            *onChar = 1; /* report click after position returned */
        return(FALSE);
        }
    
    pos = _TUTORline_pos_tview(tvp,lineN);
    ii = FALSE;
    if (lineN == tvp->topLine || tvp->ld[lineN-1].endNewline)
        ii = TRUE; /* previous line ended a paragraph */
    /* count # of chars we are into line */
    ii = _TUTORmeasure_text_tview(tvp->doc,pos,tvp->ld+lineN,ii,FALSE,where.hh,&wUsed,&wSide);
    if (!onCharWk)
        onCharWk = wSide;
    if (wSide < 0) wSide = -1; /* simplify - don't need before-line info */
    else if (wSide > 0) wSide = 1;
    post->atEnd = FALSE; /* since always at least 1 char in line */
    post->pos = pos + ii;
    
    if (inHot)
        { /* figure out whether position is hot */
        *inHot = TUTORinq_hot_doc(tvp->doc,post->pos,wSide);
        }
    
    if (byWord)
        { /* calculate bounds for selection by word */
        TUTORword_bounds2_doc(tvp->doc,post->pos,&wordSp,&wordEp,wSide);
        
        if (wordE)
            { /* want word bounds on both ends */       
            post->pos = wordSp;
            wordE->pos = wordEp;
            wordE->atEnd = TRUE;
            TUTORwhere_pix_tview(tvp->self,(Position FAR *) wordE);
            /* post done below */
            }
        else
            { /* only want new active end */
            if (wordSp >= tvp->anchor.pos)
                { /* active end is word end */
                post->pos = wordEp;
                post->atEnd = TRUE;
                }
            else
                { /* active end is word start */
                post->pos = wordSp;
                post->atEnd = FALSE;
                }
            }
        TUTORwhere_pix_tview(tvp->self,(Position FAR *) post);
        }
    else
        { /* normal selection */
        post->hh = wUsed + tvp->viewRect.left + tvp->leftOff;
        post->vv = vBot - (long) tvp->ld[lineN].lineHeight + (long) tvp->ld[lineN].lineAsc + tvp->viewRect.top;
        }
    if (onChar)
        *onChar = onCharWk;
    return(TRUE);
    }

TUTORwhere_pix_tview(theV,posp) /* calculate pixel position given char position */
Memh theV;
register Position FAR *posp; /* should have valid pos & atEnd fields */
    {
    REGISTER TViewP tvp;
    long pos;
    int ii;
    LineLayout tempLay;
    register LineLayout FAR *lp;
    
    tvp = (TViewP) GetPtr(theV);

    if (posp->pos < tvp->layoutTop)
        { /* position before our linestarts */
        posp->hh = tvp->viewRect.left;
        posp->vv = tvp->viewRect.top - 1000;
        posp->nLine = -1;
        }
    else if (posp->pos > tvp->layoutBottom)
        { /* position after our linestarts */
        posp->hh = tvp->viewRect.left;
        posp->vv = tvp->viewRect.bottom + 1000;
        posp->nLine = tvp->botLine + 2;
        }
    else if (posp->pos == tvp->bounds.pos + tvp->bounds.len && 
            (tvp->txtvH.dAnn == 0 || tvp->ld[tvp->botLine].endNewline))
        { /* at end of document on new line */
        tempLay.nc = 0;
        tempLay.lastTab = 0; /* so we don't look at stuff after "last tab" */
        ii = _TUTORmeasure_text_tview(tvp->doc,posp->pos,(LineLayout FAR *) &tempLay,
                TRUE,TRUE,0,NEARNULL,NEARNULL);
        posp->hh = tvp->viewRect.left + tvp->leftOff + ii;
        if ((tvp->botLine >= 0) && (tvp->layoutBottom > tvp->layoutTop))
            {
            ii = _TUTORline2_vv_tview(tvp,tvp->botLine);
            lp = ((LineLayout FAR *) tvp->ld) + tvp->botLine;
            ii += lp->lineHeight - lp->lineAsc;
            }
        else
            ii = tvp->viewRect.top;
        posp->vv = ii + VLINEASCENT;
        posp->nLine = tvp->botLine+1;
        }
    else
        { /* normal case, the only one which really makes sense */
        /* which line? */
        posp->nLine = 0;
        pos = tvp->layoutTop;
        lp = (LineLayout FAR *) tvp->ld;
        while (posp->pos > pos + lp->nc)
            {
            pos += lp->nc;
            posp->nLine++;
            lp++;
            }
        if (posp->pos == pos + lp->nc && (!posp->atEnd || lp->endNewline) &&
                posp->pos < tvp->layoutBottom)
            { /* advance to start of next line */
            pos += lp->nc;
            posp->nLine++;
            lp++;
            }
        
        posp->vv = _TUTORline2_vv_tview(tvp,posp->nLine);
        
        /* how many pixels into the line */
        ii = (pos == tvp->layoutTop || (lp-1)->endNewline) ? TRUE : FALSE;
        if (lp->lineAsc)    /* if visible */
            ii = _TUTORmeasure_text_tview(tvp->doc,pos,lp,ii,TRUE,
                (int) (posp->pos - pos),NEARNULL,NEARNULL);
        else
            ii = 10; /* offset for invisible line */
        posp->hh = tvp->viewRect.left + tvp->leftOff + ii;
        }
    
    ReleasePtr(theV);
    KillPtr(tvp);
    return(0);
    }

_TUTORmeasure_text_tview(doc,pos,liLay,newP,flag,info,wUsed,whichSide) /* do measurement of text in line */
Memh doc;   /* document where text is */
long pos;   /* position at start of line */
register LineLayout FAR *liLay; /* line layout of line */
int newP;   /* TRUE if this line is start of a paragraph */
int flag;   /* TRUE: convert # chars to pixels, FALSE: convert pixels to # chars */
int info;   /* depending on flag, either # of chars or pixels to be measured */
int *wUsed; /* if !flag, wUsed is set to actual space used */
int *whichSide; /* if !flag, set to side of position click was on */
                /* +2 = click was after entire line */
                /* +1 = click was after position returned */
                /* -1 = click was before position returned */
                /* -2 = click was before entire line */
/* returns (depending on flag) either # of chars or pixels */
    {
    ParagraphLayout pLay;   /* paragraph layout of line */
    short curStyles[NSTYLES];   /* styles at our current position */
    short iStyles[NSTYLES]; /* styles at begin of text */
    int styleInd;           /* current index in style structure (for our position) */
    StyleDatP sp;           /* pointer to styles */
    DocP dp;                /* pointer to doc */
    SpecialTP stp;          /* pointer to special text info */
    int stind;      /* current index in special text structure */
    int retVal;             /* the value to be returned (either # of chars or pixels) */
    int nBlanks;    /* when shimming, keeps track of # of blanks passed in this line */
    int lastBlankP; /* total # of pixels shimmed after previous blank */
    unsigned char FAR *tp;  /* pointer to current character */
    unsigned char FAR *t0;  /* pointer to "starting" character */
    unsigned char FAR *te;  /* pointer to ending character */
    Style1 SHUGE *s1p, SHUGE *s1End;    /* pointer to current & last style */
    SText FAR *st1p, FAR *st1End;   /* pointer to current & last special text */
    int justif;     /* the justification of the line */
    int width;      /* the total space used so far */
    long fracShim;  /* the shim for this line (fractional # of pixels per space) */
    long tabPos;    /* position of last tab in the line */
    int mFlag;      /* measurement type flag.  0: normal, 1: tab, 2: shimmed space, 3: special */
    long nextStylePos;  /* next position where style changes */
    long nextSTextPos;  /* next position where there is a special text */
    unsigned char scanS[2]; /* characters we may scan for */
    long curPos;    /* our current position (during character by character measurement) */
    long nextWordPos;   /* position of end of current character chunk */
    int setFont;    /* if TRUE, we need to reset the text font */
    int nc; /* # of characters to measure */
    int newW;   /* width of chunk of characters measured */
    int curX;   /* current position (in pixels, relative to left margin) in the line */
    int ii;
    
    /* this routine assummes that measurement begins at the start of the line */
    
    dp = (DocP) GetPtr(doc);
    if (!dp->shortText && (dp->buffEnd < pos + liLay->nDraw || dp->buffStart > pos))
        { /* we need to load buffer */
        _TUTORload_buffer_doc(dp,pos);
        }
    
    _TUTORsetup_layout(dp,pos,(long) liLay->nDraw,&styleInd,&sp,curStyles,&pLay,&stind,&stp,TRUE);
    for(ii=0; ii<NSTYLES; ii++) /* save styles at beginning */
        iStyles[ii] = curStyles[ii];
    _TUTORset_textfont_doc(dp,curStyles);
    justif = curStyles[PARASTYLE] & JUSTMASK;
    
    fracShim = 0;
    nBlanks = lastBlankP = 0;
    
    width = pLay.leftMar + (newP ? pLay.paraIndent : 0);    /* total space used so far */
    if (justif != LEFTJUST && liLay->lastTab == -1)
        { /* justification offset happens right away */
        width += liLay->justWidth;
        fracShim = liLay->fracShim;
        tabPos = pos-1; /* we've already passed tabs */
        }
    else
        tabPos = pos + liLay->lastTab;
    
    if ((flag && (info <= 0 || liLay->nDraw == 0)) || (!flag && info <= width))
        { /* we are already done */
        if (flag) /* there are no characters or we were asked to measure none */
            retVal = width;
        else /* we were asked to measure a number of pixels less than where 1st char plots */
            {
            retVal = 0;
            *wUsed = width;
            if (whichSide)
                *whichSide = -2;
            }
        if (sp)
            {
            ReleasePtr(dp->styles);
            KillPtr(sp);
            }
        if (stp)
            {
            ReleasePtr(dp->specialT);
            KillPtr(stp);
            }
        ReleasePtr(doc);
        KillPtr(dp);
        return(retVal);
        }
    
    /* we need to go thru the line, 1 character at a time, measuring until
        we have exhausted the number of things we are supposed to measure */
    
    tp = ((unsigned char FAR *) dp->text) + (pos-dp->buffStart);
    t0 = tp;
    te = tp + (flag ? info : liLay->nDraw);
    if (sp)
        {
        s1p = ((Style1 SHUGE *) sp->styles) + styleInd; /* next style */
        s1End = ((Style1 SHUGE *) sp->styles) + (sp->sHead.dAnn-1); /* last style */
        nextStylePos = (s1p <= s1End) ? s1p->pos : pos+liLay->nDraw+10;
        }
    else
        nextStylePos = pos+liLay->nDraw+10; /* never get to a style change */
    if (stp)
        {
        st1p = ((SText FAR *) stp->text) + stind; /* next special text */
        st1End = ((SText FAR *) stp->text) + (stp->head.dAnn-1); /* last special text */
        nextSTextPos = (st1p <= st1End) ? st1p->pos : pos+liLay->nDraw+10;
        }
    else
        nextSTextPos = pos+liLay->nDraw+10; /* never get to a special text */
    nextWordPos = curPos = pos;
    curX = width - pLay.leftMar; /* we start out at left edge + margin */
    
    scanS[0] = '\t';
    scanS[1] = ' ';
    retVal = -1; /* indicates that we haven't set it yet */
    
    if (flag && info > liLay->nDraw)
        info = liLay->nDraw; /* non-drawn characters have 0 width on screen */
    
    while (curPos < pos+liLay->nDraw)
        {
        if (curPos >= nextWordPos)
            { /* get next character chunk */
            /* figure out what kind of measurement we want */
            mFlag = 0;
            if (curPos >= nextSTextPos)
                { /* special text */
                mFlag = 3;
                tp += st1p->len;
                }
            else if (*tp == '\t')
                {
                mFlag = 1;
                tp++;
                }
            else if (fracShim && *tp == ' ')
                {
                mFlag = 2;
                tp++;
                }
            else
                { /* normal kind of measurement */
                if (!flag)
                    { /* when we are converting pixels to # chars we have to go 1 char at a time */
                    tp++;
                    }
                else
                    { /* when we are converting chars to pixels we can measure
                        a whole word (no spaces or tabs) at a time */
                    /* scan chars for next character chunk */
                    if (!fracShim)
                        { /* we aren't shimming, so spaces are normal.  Only tabs
                            break character chunks */
                        if (tabPos < curPos)
                            { /* we've passed last tab */
                            tp = te; /* the next chunk goes right to the end */
                            }
                        else
                            { /* we need to look for next tab */
                            tp = TUTORscan_bytes(tp,te-1,scanS,1);
                            if (!tp) /* didn't find tab */
                                tp = te;
                            }
                        }
                    else
                        { /* shimming, there must not be any more tabs - just look for spaces */
                        tp = TUTORscan_bytes(tp,te-1,scanS+1,1);
                        if (!tp) /* didn't find space */
                            tp = te;
                        }
                    } /* end of scan */
                } /* end of normal measurement */
            nextWordPos = (tp - t0) + pos;
            if (nextWordPos > pos + liLay->nDraw)
                { /* don't measure more chars than are drawable */
                nextWordPos = pos + liLay->nDraw;
                }
            if (stp && nextWordPos > nextSTextPos)
                { /* don't measure over special text */
                tp -= (nextWordPos - nextSTextPos);
                nextWordPos = nextSTextPos;
                }
            } /* end of nextWordPos calc */
        
        if (curPos == nextStylePos)
            { /* process all styles at this position */
            setFont = FALSE;
            while (s1p <= s1End && s1p->pos == nextStylePos)
                {
                setFont |= _TUTORset_curstyles_doc(dp,s1p,curStyles);
                s1p++;
                }
            nextStylePos = (s1p <= s1End) ? s1p->pos : pos+liLay->nDraw+10;
            if (setFont)
                _TUTORset_textfont_doc(dp,curStyles);
            }
        
        /* measure next piece */
        if (mFlag == 0)
            { /* normal character measurement */
            nc = ((nextStylePos > nextWordPos) ? nextWordPos : nextStylePos) - curPos;
            TUTORinq_abs_string_width(t0+(curPos-pos),nc,&newW);
            }
        else if (mFlag == 3)
            { /* special text */
            /* we always measure all of special! */
            /* this really only works for specials of length 1 */
            nc = st1p->len;
            newW = TUTORmeasure_stext(st1p,NEARNULL,NEARNULL,NEARNULL);
            st1p++;
            if (st1p <= st1End)
                nextSTextPos = st1p->pos;
            else
                nextSTextPos = pos + liLay->nDraw + 10;
            }
        else
            { /* tab or shimmed space */
            nc = 1;
            if (mFlag == 1)
                { /* measure a tab */
                newW = _TUTORtab_width_doc(&pLay,curX);
                if (tabPos == curPos && justif != LEFTJUST)
                    { /* this is last tab on justified line */
                    newW += liLay->justWidth;
                    fracShim = liLay->fracShim;
                    }
                }
            else
                { /* measure a shimmed space */
                TUTORinq_abs_string_width(tp-1,1,&newW); /* width of space */
                nBlanks++;
                ii = (fracShim * nBlanks)>>16;
                if (ii > lastBlankP)
                    { /* we need to do some shimming */
                    newW += (ii - lastBlankP);
                    lastBlankP = ii;
                    }
                }
            }
        curX += newW;
        width += newW;
        curPos += nc;
        
        if (flag && (curPos >= pos + info))
            { /* we've measured all the characters we need to */
            retVal = width;
            break; /* we're done */
            }

        if (!flag && (width > info))
            { /* we've filled up our space */
            /* round off to nearest character boundary */
            /* note that newW contains width of last character measured,
                which is the character that took us over our space */
            if (width - newW/2 > info)
                { /* in first half of char, make position be before character */
                retVal = curPos-1 - pos;
                *wUsed = width - newW;
                if (whichSide)
                    *whichSide = 1;
                }
            else
                { /* in last half of char, make position be after character */
                *wUsed = width;
                retVal = curPos - pos;
                if (whichSide) {
                    *whichSide = -1;
                    if (retVal >= liLay->nDraw)
                        *whichSide = -2;
                }
                }
            break;
            }
        } /* end of while (curPos < pos + liLay->nDraw) */
    
    if (retVal == -1)
        { /* retVal not set yet */
        if (flag)
	    TUTORdump("measure_text flag true");
        else
            {
            retVal = liLay->nDraw; /* all the characters in the line */
            *wUsed = width;
            if (whichSide)
                *whichSide = 2;
            }
        }
    
    if (sp)
        {
        ReleasePtr(dp->styles);
        KillPtr(sp);
        }
    if (stp)
        {
        ReleasePtr(dp->specialT);
        KillPtr(stp);
        }
    _TUTORset_textfont_doc(dp,iStyles); /* restore to status at beginning */
    ReleasePtr(doc);
    KillPtr(dp);
    
    return(retVal);
    }

_TUTORhilite_select(theV,onoff) /* turn selection (or caret) on or off */
Memh theV;  /* tview */
int onoff; /* if TRUE, turn hiliting on */
    {
    REGISTER TViewP tvp; /* pointer to tview */
    
    tvp = (TViewP) GetPtr(theV);
	if (!tvp->hiInactive) {
    	if (onoff && tvp->caretState || (!onoff && !tvp->caretState) || !tvp->vActive)
        	{
        	ReleasePtr(theV);
        	KillPtr(tvp);
        	return(0); /* nothing to do */
        	}
    }
#ifdef NoSuchz
    /* if (tvp->insetSelect)
        SpFrameKView(theV);
    else */ 
#endif
    
    if ((!tvp->highSel) ||(tvp->anchor.pos == tvp->selA.pos))
        _TUTORdraw_caret_tview(tvp,onoff ? 2 : 1);
    else
        {
        if (tvp->anchor.pos < tvp->selA.pos)
            _TUTORdraw_selr_tview(tvp,&tvp->anchor,&tvp->selA);
        else
            _TUTORdraw_selr_tview(tvp,&tvp->selA,&tvp->anchor);
        }
    tvp->caretState = onoff;
    
    ReleasePtr(theV);
    KillPtr(tvp);
    return(0);
    }

_TUTORdraw_caret_tview(tvp,mess)    /* draw, erase or toggle the textview caret */
register TViewP tvp;    /* pointer to tview */
int mess;   /* 0 - toggle, 1 - erase, 2 - draw, 3 - caret is gone (don't draw), 4 - caret is present (don't draw) */
/* messages 3 and 4 are so the client (who may know more than DrawCaret) can change the caret phase */
    {
    int oldCombRule;    /* to save & restore drawing mode */
    register int top;   /* vertical position of top of caret */
    register int height;    /* vertical height of caret */
    Position thePos;

    if (tvp->highSel && (tvp->anchor.pos != tvp->selA.pos || !tvp->vActive))
        return(0); /* no caret */
    
    if (tvp->duringClick && mess == 0)
        return(0); /* don't toggle caret during mouse movement */
    
    if (mess == 3 || mess == 4)
        { /* we just need to reset state */
        tvp->caretState = (mess == 4) ? TRUE : FALSE;
        return(0);
        }
    
    if (tvp->highSel)
        thePos = tvp->anchor;
    else
        thePos = tvp->selA;
    
    if ((mess == 1 && !tvp->caretState) || (mess == 2 && tvp->caretState) ||
            (thePos.pos < tvp->layoutTop) || (thePos.pos > tvp->botPos))
        return(0);
    
    if (thePos.nLine <= tvp->botLine)
        {
        top = thePos.vv - tvp->ld[thePos.nLine].lineAsc;
        height = tvp->ld[thePos.nLine].lineHeight - 1;
        }
    else
        { /* this must be a caret in a virtual line */
        top = thePos.vv - VLINEASCENT;
        height = VLINEHEIGHT;
        }
	if (!windowsP[CurrentWindow].iconified) {
		oldCombRule = TUTORinq_comb_rule();
		TUTORset_comb_rule(SRC_XOR);
		TUTORabs_move_to(thePos.hh,top);
		TUTORabs_line(0,height);
		TUTORset_comb_rule(oldCombRule); /* restore comb rule */
	}
	tvp->caretState = !tvp->caretState;
    return(0);
    }

_TUTORdraw_selr_tview(tvp,p1,p2)    /* draw textview selection */
register TViewP tvp;    /* pointer to tview */
Position FAR *p1;   /* start position */
Position FAR *p2;   /* end position */
    {
    short h1,h2;        /* horizontal bounds of selection */
    int t1,b1,t2,b2;    /* vertical bounds of selection */
    register LineLayout FAR *lp;    /* pointer to view line layouts */
    
    if (p1->pos >= tvp->layoutBottom || p2->pos <= tvp->layoutTop)
        return(0); /* selection is out of layout (and therefore not visible) */
    
    h1 = p1->hh;
    h2 = p2->hh-1;
    if (p2->nLine == p1->nLine && tvp->ld[p2->nLine].lineAsc == 0)
        h2 += 5; /* for invisible line highlight */

    if (p1->pos >= tvp->layoutTop)
        { /* start is within layout */
        lp = ((LineLayout FAR *) tvp->ld) + p1->nLine;
        t1 = p1->vv - lp->lineAsc;
        b1 = t1 + lp->lineHeight - 1;
        }
    else
        { /* above the top of visible */
        t1 = tvp->viewRect.top;
        b1 = tvp->viewRect.top-1;
        }

    if (p2->pos < tvp->layoutBottom || (p2->pos == tvp->layoutBottom && p2->nLine <= tvp->botLine))
        { /* within layout */
        lp = ((LineLayout FAR *) tvp->ld) + p2->nLine;
        t2 = p2->vv - lp->lineAsc;
        b2 = t2 + lp->lineHeight - 1;
        }
    else if (p2->pos == tvp->layoutBottom)
        { /* ends on virtual line at end of view */
        t2 = p2->vv - VLINEASCENT;
        b2 = t2 + VLINEHEIGHT - 1;
        }
    else
        { /* not visible */
        t2 = tvp->viewRect.bottom+1;
        b2 = tvp->viewRect.bottom;
        }
    
    if (t1 > tvp->viewRect.bottom || b2 < tvp->viewRect.top)
        { /* hilite completely off screen */
        return(0);
        }

    /* make sure hilighting doesn't extend beyond last visible line */
    if (b2 > tvp->botV)
        {
        b2 = tvp->botV;
        if (t2 > tvp->botV)
            t2 = tvp->botV+1;
        }

    /* at this point coords are correct on-pixel coordinates */

    if (p1->nLine == p2->nLine)
        { /* single line highlight */
        if (h1-1 != h2) /* if p1 & p2 in same place h2 = h1-1 */
            TUTORhilite(h1,t1,h2,b1);
        }
    else
        { /* multiple line highlight */
        if (t1 <= b1)
            TUTORhilite(h1,t1,tvp->viewRect.right,b1); /* first line */
        TUTORhilite(tvp->viewRect.left,b1+1,tvp->viewRect.right,t2-1); /* intervening lines */
        if (t2 <= b2)
            TUTORhilite(tvp->viewRect.left,t2,h2,b2); /* last line */
        }

    return(0);
    }
