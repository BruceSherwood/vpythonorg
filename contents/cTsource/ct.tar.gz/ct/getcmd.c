
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "ctutor.h"
#include "exprdefs.h"
#include "ecglobal.h"
#include "cglobals.h"
#include "tglobals.h"
#include "ct_ctype.h"

#ifdef ctproto
int  strlenf(char  FAR *aa);
extern int TUTORalert(int wn, char *msg);
extern int strncmpf(char FAR *aa,char FAR *bb,int nn);
int  StopProgram(char  *s);
extern void get_cmd_table(void);
extern Memh LoadTable(char *tableFile,int *tableSize);
int  getcmd(void);
int  cmdinput(void);
int  getcmd2(char  *inps);
int  SkipLine(void);
int  cmdlook(char  *s);
int  cmdlookn(char  *s);
int cmdlookp(char *s);
char FAR *cmdname(int  cmdn);
int  getcommand(void);
int  getrealcommand(void);
int  FillBuffer(unsigned int  readDoc,long  readPos,long  maxRead);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
char  FAR *GetPtr(unsigned int  mm);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
#endif /* ctproto */


extern long TUTORget_len_doc();

#define D 1  /* D for commands which allow blank tags, otherwise T */
#define T 2
#define B 3  /* B for commands which must have blank tags. */
#define C 4  /* C for those that end in a colon (e.g., float:) */
#define EQK 5  /* EQK for those that end in equals (e.g., keys=) */

struct command {
    char name[16];
    short term;
    short code;
}; /* command */

static Memh cmdtableH = HNULL;
static struct command FAR *cmdtable = FARNULL;
static int cmdsize; /* size of command table */

/* ******************************************************************* */

void get_cmd_table()

{
    if (!cmdtableH) {
		cmdtableH = LoadTable("commands.tab",&cmdsize);
		if (!cmdtableH) {
			TUTORalert(-1,"Can't find file commands.tab");
			StopProgram("");
		}
	}
    if (!cmdtable)
		cmdtable = (struct command FAR *)GetPtr(cmdtableH);

} /* get_cmd_table */

/* ******************************************************************* */

int getcmd() /* get next command */
/* source, srcPos = position in current source document */
/* cB, cI = current line */

{   int index, cnt;
    long savepos;
    char inps[20], *p, c;   /* input string */


    startgetcmd = srcPos;   /* save start of line */
    cnt = 0;
    p = inps;
    while ((CTisalpha(c = cmdinput()) || (c == '$')) && (++cnt < 15)) *(p++) = c;
    *p = '\0';
    srcPos = startgetcmd+cI;

    if (!(c == '\t' || c == NEWLINE)) {
        if (cnt == 0) {
            if (c == '*') {
                SkipLine();
                return(COMMENT);
            } 
            if (c == '.') {
                c = cmdinput();
                srcPos = startgetcmd+cI;
                if (c == '\t') return(INDENT);
                if (c == NEWLINE) {  /* .NEWLINE like .TAB */
                    SkipLine();    /* skip $$ comment if any */
                    srcPos--; /* back up before NEWLINE */
                    return(INDENT);
                }
            }
        }
        return(CMDERR);
    }
    if (cnt == 0) {
        if (c == NEWLINE) { /* blank line */
            if (srcPos > 0 && TUTORcharat_doc(source,srcPos-1)=='$') {
                SkipLine();
                return(COMMENT);
            }
            return(BLANK);
        }
        return(INDENT);  /* an initial TAB */
    }
    return(getcmd2(inps));
    
} /* getcmd */

/* ******************************************************************* */

int cmdinput()  /* read next character, skipping spaces */

{   register char   c;
    
    do {
        c = cB[cI++];
    } while (c == ' ');
    return (c);

} /* cmdinput */

/* ******************************************************************* */

int getcmd2(inps) /* given "clean" command string, get command # */
char *inps; /* string containing command */

{   int index;
    long savepos;
    char c;

    index = cmdlook(inps); /* look up command name */
    if (index>=0)
        return(cmdtable[index].code);
    return(CMDERR);

} /* getcmd2 */

/* ******************************************************************* */

SkipLine() /* skip rest of line */
/* source, srcPos = position in current source document */

{   if ( (srcPos != 0) && (TUTORcharat_doc(source,srcPos-1) == NEWLINE) ) 
        return(0);
    while ( TUTORcharat_doc(source,srcPos) != NEWLINE )
        srcPos++;
    srcPos++; /* move past the newline */

} /* SkipLine */

/* ******************************************************************* */

static int cmdlook(s) /* binary chop search for command name */
                /* return = -1 or index in cmdtable */
                /* assumes command names do not exceed 8 chars */
char *s;            /* pointer to command name string */

{   int low;    /* low index for search */
    int high;   /* high index for search */
    int ix; /* index of current item in table */
    int cmpr;   /* result of string compare */

    low = 0;
    high = (cmdsize/sizeof(struct command))-1;
    while (high>(low+1)) {
        ix = (low+high)/2;
		cmpr = strncmpf(cmdtable[ix].name,(char FAR *)s,8);
        if (cmpr>0) high = ix;
        else if (cmpr<0) low = ix;
        else return(ix);
    } /* while */
    return(-1); /* command not found */

} /* cmdlook */

/* ******************************************************************* */

static int cmdlookn(s) /* look up command, return command number */
char *s;    /* pointer to command name string */

{   int i;  /* index in command table */

    i = cmdlook(s); /* search for command */
    if (i>=0) return(cmdtable[i].code);
    return(CMDERR);

} /* cmdlookn */

/* ******************************************************************* */

int cmdlookp(s) /* check for partial match with command name */
char *s; /* string possibly starting with command name */

{	int len; /* length of command table */
	int cii; /* index in commands */
	int cnl; /* length of command name */
	
	len = cmdsize/sizeof(struct command);
	for(cii=0; cii<len; cii++) {
		cnl = strlenf(cmdtable[cii].name);
		if (strncmpf((char FAR *)s,cmdtable[cii].name,cnl) == 0) 
			return(cmdtable[cii].code);
	} /* for */
	return(-1);

} /* cmdlookp */
	
/* ******************************************************************* */

char FAR *cmdname(cmdn) /* given command #, return name */
int cmdn;
    
{   register struct command FAR *cp;

    /* linear search thru command table */
    cp = cmdtable + 1;
    while (cp->code){
        if (cp->code == cmdn)
            return(cp->name);
        cp++;
    } /* while */
    return(" ");

} /* cmdname */

/* ******************************************************************* */

getcommand() /* skip comments */
/* source, srcPos = position in current soruce document */

{   int command;
  
    while ((command = getrealcommand()) == COMMENT) ;
    return(command);

} /* getcommand */

/* ******************************************************************* */

getrealcommand() /* return command no. for comments */
/* source, srcPos = position in current source document */

{ int cmd;

    FillBuffer(source,srcPos,TUTORget_len_doc(source)-srcPos);
    cI = 0;
    cmd = getcmd();

    return(cmd);

} /* getrealcommand */

/* ******************************************************************* */
