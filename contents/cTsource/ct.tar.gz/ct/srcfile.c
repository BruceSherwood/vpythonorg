
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* Routines associated with authoring. */

#include <stdio.h>
#include "baseenv.h"
#include "tutor.h"
#ifdef ANDREW
/* #include <sys/file.h> */
#endif
#include "tglobals.h"
#include "edglobal.h"
#include "ecglobal.h"
#include "editor.h"
#include "txt.h"
#include "compute.h"
#include "commands.h"

#ifdef ctproto
extern int TUTORflush_file(int fii);
int TUTORset_dir(FileRef FAR  *path);
extern int killptr(char FAR * FAR *pp);
int  TUTORcopy_fileref_dir(struct  _fref FAR *dirname,struct  _fref FAR *fullname);
int  TUTORcopy_fileref(struct  _fref FAR *fDest,struct  _fref FAR *fSource);
extern int TUTORcopy_fileref_name(FileRef FAR *fRef, char FAR *name);
int TUTORdelete_file(FileRef FAR *fRef);
int TUTORcrlf_file(FileRef FAR *inRef,FileRef FAR *outRef);
unsigned int  TUTORnew_doc(int  string,int  honorP);
int  readdoc(unsigned int  doc,struct  _fref FAR *fRef,int  *iswrite);
int  writedoc(unsigned int  kdocp,struct  _fref FAR *filen,int mode);
int  insertversion(void);
int  clearsrc(int  domkall);
int  initsourcet(int  i);
int  TUTORclose_all_markers(unsigned int  doc);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
char  FAR *GetPtr(unsigned int  mm);
int  ReleasePtr(unsigned int  mm);
int  TUTORfree_handle(unsigned int  mm);
char  FAR *TUTORrealloc(char  FAR *ptr,long  oldsize,long  newsize,int  abort);
int  TUTORclose_doc(unsigned int  doc);
int  setbasesrc(void);
int  TUTORinsert_string_doc(unsigned int  doc,long  pos,unsigned char  FAR *ss,long  sLen);
int  TUTORclose(int  findx);
int  TUTORfwrite_doc(unsigned int  doc,long  pos,long  len,int  fInd,int  nativeF);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORset_file_type(struct  _fref FAR *fRef,int  findx,int  type,int  xx,int  yy);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
int  TUTORdump(char  *s);
int  TUTORget_fileref_name(struct  _fref FAR *fRef,char  FAR *name);
int  TUTORfread_doc(unsigned int  doc,long  len,int  docKind,int  fInd);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
int  TUTORclear_doc(unsigned int  doc);
int  _TUTORinternal_marker(struct  markvar FAR *mp,unsigned int  stackH,long  rloc);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
#ifndef THINKC5
#ifndef WERKS
extern char *strcpy(char *aa, char *bb);
extern  int sprintf(char *, char *, ...);
#endif
#endif
#endif


extern long TUTORget_len_doc();
extern char *machinename();
extern char FAR *ReadFileKView();
extern long TUTORwrite();
extern long TUTORread();
extern long bin_write();
extern long bin_read();
extern long TUTORinq_file_pos();
extern char *strf2n();
extern int RestoreBinaryStub();

#ifdef ANDREW
extern long getpid();
#endif

char *nxtkword();	

/* ******************************************************************* */

/* note that there is another "readdoc()" in ctconfig for the executor */
/* only version ... */

int readdoc(doc,inRef,iswrite) /* read styled document */
Memh doc;	/* document to read into */
FileRef FAR *inRef;
int *iswrite;	/* returned TRUE if document writeable */

{   int findx; /* index in file table for source file */
    FileRef fRef;
    char cs[CTPATHLEN+40];	/* message buffer */
    int wrtf; /* TRUE if writeable file */
    long smtime; /* time source file last modified */
    int i;	/* work variables */
    long FileL; /* length of file */
    char cvtf; /* CR/LF conversion flag */
    int tmpF; /* TRUE if temporary file created */
    int errf; /* error flag */
    FileRef saveRef;
    char ctavers[10]; /* .cta file version */
    char *c;

    tmpF = wrtf = FALSE; /* preset no temp file, read-only */
    TUTORclear_doc(doc);

    TUTORcopy_fileref((FileRef FAR *)&fRef,inRef);
#ifdef IBMPCx
    /* optimization for PCs */
    /* 0x0d+0x0a terminated files will work on any platform without */
    /* this call as the datastream code also does the conversion */
    tmpF = TUTORcrlf_file(inRef,(FileRef FAR *)&fRef); /* cr+lf conversion */
#endif

	/* attempt to open source file */

	findx = TUTORopen((FileRef FAR *)&fRef,TRUE,FALSE,FALSE);
	if (findx) 
		TUTORinq_file_info((FileRef FAR *)&fRef,&wrtf,&FileL,&smtime,NEARNULL,NEARNULL);
	*iswrite = wrtf;
	if ((findx == 0) || (FileL <= 0)) {
		if (findx) TUTORclose(findx); /* close source file */
		*iswrite = TRUE; /* new file can be written */
		return(FALSE);
	} /* findx if */

	/* set up styled text document */

	saveRef = *currentDirP; /* save current working directory */
	/* reset working directory so can find icons, etc */
	TUTORcopy_fileref_dir((FileRef FAR *) currentDirP,(FileRef FAR *)&fRef);
	TUTORset_dir(currentDirP);
	i = TUTORfread_doc(doc,-1L,-1,findx);
	TUTORclose(findx); /* close source file */
	*currentDirP = saveRef; /* restore working directory */
	TUTORset_dir(currentDirP);
	if (i == FALSE) {
		TUTORclear_doc(doc);
	}
    if (tmpF)
	TUTORdelete_file((FileRef FAR *)&fRef); /* clean up temp file */
	return(TRUE);
	
} /* readdoc */

/* ******************************************************************* */

int writedoc(kdocH,filen,mode) /* write BE-II document to file */
/* return TRUE if write ok */
Memh kdocH;	/* handle to document structure */
FileRef FAR *filen;
int mode; /* = 0 = write cT datastream */
          /* = 1 = write cT datastream if styled */
          /* = 2 = write native */

{   int findx; /* index in file table */
	int fret;
    int wSuccess;	/* write, close error flags */
    long len;
    int fileX, fileY;
    int nativeF;
	DocP dp;
	int txtMemN; /* current text/memory error count */

	fileX = fileY = -10000; /* let system shell set file location */
	findx = TUTORopen(filen,FALSE,TRUE,FALSE);
	
	/* tell system that this is a CT source file */
	TUTORset_file_type(filen,findx,1,fileX, fileY); 
 
	if (!findx) {
		return(FALSE);
	}

	txtMemN = TxtMemErr;
	len = TUTORget_len_doc(kdocH);
	
	switch (mode) {
	
	case 0:
		nativeF = FALSE; /* always write cT datastream */
		break;
		
	case 1:
		nativeF = TRUE; /* write cT datastream if styled */
		dp = (DocP) GetPtr(kdocH);
		if (dp->styles || dp->specialT)
			nativeF = FALSE;
		ReleasePtr(kdocH);
		KillPtr(dp);
		break;
		
	case 2:
		nativeF = TRUE; /* always write native, not cT datastream */
		break;
		
	} /* switch */
	
#ifdef CTEDIT
	nativeF = TRUE; /* always write native if ctedit */
#endif

	wSuccess = TUTORfwrite_doc(kdocH,0L,len,findx, nativeF);
	fret = TUTORflush_file(findx);
	if (!fret) wSuccess = FALSE; /* something went wrong */
    TUTORclose(findx);

	if (txtMemN != TxtMemErr)
		wSuccess = FALSE;
    return(wSuccess);

} /* writedoc */

/* ******************************************************************* */

insertversion() 

{	int cv;
	char vstr[20];

	ctutv = CURRENTV;	/* always use current version */
	/* adjust for $version/$syntax - $syntaxlevel 1.0 = $version 2.0 */
	cv = ctutv-19;
	vstr[0] = '\0';
	sprintf(vstr,"$syntaxlevel %d%s",cv,NEWLINES);
	TUTORinsert_string_doc(source,0L,(unsigned char FAR *) vstr,(long)(strlen(vstr)));

} /* insertversion */

/* ******************************************************************* */

clearsrc(domkall)	/* clear main source file status */
int domkall; /* if TRUE, recreate mkall */

{	int i;	/* work variable */
	struct markvar mtemp;

	setbasesrc(); /* make sure 'source' and related variables refer to base doc */

	/* clear existing tables */
	for(i=0; i<sourcemalloc; i++) {
		if ((i > 0) && sourcetable[i].doc) {
			TUTORclose_all_markers(sourcetable[i].doc);
			if (sourcetable[i].editI == -1) 
				TUTORclose_doc(((Memh )(sourcetable[i].doc)));
		} /* i if */
		initsourcet(i);
	} /* for */
	sourcetable = (struct sourcefile FAR *)
		       TUTORrealloc((char FAR *)sourcetable,
	               (long)(sourcemalloc*sizeof(struct sourcefile)),
	               (long)(sizeof(struct sourcefile)),TRUE);
	sourcemalloc = 1;

	/* empty descriptors table */

	if (descP) { /* release handle if neccessary */
		ReleasePtr(descH);
		descP = NULL;
	}
	/* down-size handle */
	TUTORset_hsize(descH,0L,TRUE); 

	/* empty current unit table */

	for(i=0; i<unitmalloc; i++) {
		unittab[i].beginfile = 0;
		unittab[i].descp = 0;
		unittab[i].descl = 0;
		unittab[i].nrefs = 0;
		if (unittab[i].pcodeAlphaH)
			TUTORfree_handle(unittab[i].pcodeAlphaH);
		unittab[i].pcodeAlphaH = HNULL;
		if (unittab[i].pcodeBetaH)
			TUTORfree_handle(unittab[i].pcodeBetaH);
		unittab[i].pcodeBetaH = HNULL;
		if (unittab[i].srcmapAlphaH)
			TUTORfree_handle(unittab[i].srcmapAlphaH);
		if (unittab[i].srcmapBetaH)
			TUTORfree_handle(unittab[i].srcmapBetaH);
		unittab[i].srcmapAlphaH = unittab[i].srcmapBetaH = HNULL;
		unittab[i].nmap = 0;
		unittab[i].pcodeBetaL = unittab[i].pcodeAlphaL = 0;
		unittab[i].textp = 0;
		unittab[i].textl = 0;
		unittab[i].marki = -1;
	} /* for */
	ReleasePtr(unittabH);
	TUTORset_hsize(unittabH,(long)(10L*sizeof(struct unitinfo)),TRUE);
	unittab = (struct unitinfo FAR *) GetPtr(unittabH);
	TUTORset_hsize(unitNames,(long)sizeof(struct unitdat)*10L,FALSE);
	unitmalloc = 10;

	if (sourcetable[0].doc) {
		TUTORclose_all_markers(sourcetable[0].doc); /* get rid of all markers on source document */
		if (domkall) { /* recreate mkall */
			mtemp.doc = sourcetable[0].doc;
			mtemp.pos = 0L;
			mtemp.len = TUTORget_len_doc(sourcetable[0].doc);
			mtemp.alteredF = 0x10; /* sticky */
			mkall = _TUTORinternal_marker((struct markvar SHUGE *) &mtemp,HNULL,0L);
		}
		
	} /* sourcetable if */
	if (textpool) {
		TUTORclose_doc(textpool); /* dump document */
		textpool = TUTORnew_doc(TRUE,FALSE); /* text/string literals */
	}
	nunits = -1; /* force unit setup */
	
	if (EditWn[0] >= 0)
		sourcetable[0].editI = 0; /* file 0 always with editor 0 */

} /* clearsrc */

/* ******************************************************************* */

initsourcet(i)	/* initialize source table entry */
int i; /* index in table */

{	register struct sourcefile FAR *sp;

	sp = sourcetable+i;
	if (i == 0) {
		sp->doc = source;	/* pointer to source document */
		sp->valid = TRUE;	/* source file read correctly */
		sp->programpart = TRUE;	/* code is in use */
		sp->ctutv = ctutv;	/* cmututor version */
	} else {
		sp->doc = HNULL;
		sp->valid = FALSE;	
		sp->programpart = FALSE;	
		sp->ctutv = 0;	 
		sp->writeable = 0;
		sp->mtime = 0;
	} /* else */
	sp->outeruse = 0;
	sp->userdefsetH = 0;
	sp->firstunit = 0;
	sp->lastunit = 0;
	sp->editI = -1;

} /* initsourcet */

/* ******************************************************************* */
