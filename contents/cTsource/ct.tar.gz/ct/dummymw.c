
extern int TUTORdump(char *str);
int TUTORinq_slider_busy() { return(0); }
int TUTORupdate_menu_bar(void) { return(0); }
int TutorShowCard(void) { return(0); }

int wmg_font() { return(0); }
procdialogw() { return(0); }
ESTextSelect() { return(0); }

procdialog() { return(0); }
OpenFileDialog() { return(0); }
drawscrollbar() { return(0); }
wmg_wipe() { return(0); }
TUTORstop_sound() { return(0); }

long pc_ega_rescale() { return(0); }
TUTORcvt_native_chars() { return(0); }
TUTORmouse_on() { return(0); }
TUTORcvt_ct_chars() { return(0); }

TUTORwindow_init() { return(0); }
TUTORtrace_n() { return(0); }
TUTORframe_window() { return(0); }
wmg_obscured() { return(0); }
wmg_inq_current_font() { return(0); }
TUTORcvt_toascii_chars() { return(0); }
int pd_menualt;
TUTORoptimize_rect() { return(0); }
TUTORread_dir() { return(0); }
crash_checkpt() { return(0); }
TUTORdispose_dir() { return(0); }
UnlockMemoryTable() { return(0); }
TUTORinq_abs_string_width16() { return(0); }
SetHiliteColor() { return(0); }
LockMemoryTable() { return(0); }
