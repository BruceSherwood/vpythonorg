
/* Windows FNT font resource to Windows FON font converter */
/* fntfon font1.fnt font2.fnt .. fontn.fnt font.fon */

/* builds a font family from several sizes of the same font */

/* ******************************************************************* */

#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <signal.h>
#include <bios.h>
#include <dos.h>
#include <malloc.h>
#include <string.h>
#include <sys\types.h>
#include <sys\timeb.h>
#include <sys\stat.h>

/* ******************************************************************* */

extern long l_read(char far *ptr,int pSize,long count,FILE *fp);
extern long l_write(char far *ptr,int pSize,long count,FILE *fp);
extern int l_block_move(char far *p1,char far *p2,long len);
extern int l_zero(char far *ptr,long len);
extern char far *l_alloc(long size);
extern int l_free(char far *ptr);
extern char *strf2n(char far *str);
extern char *strnf2n(char far *str,int len);
extern int strlenf(char far *str);
extern char far *strcpyf(char far *s1,char far *s2);
extern char far *strcatf(char far *s1,char far *s2);
extern int strcmpf(char far *s1,char far *s2);
extern char far *strncpyf(char far *s1,char far *s2,int len);
extern char far *strncatf(char far *s1,char far *s2,int len);
extern int strncmpf(char far *s1,char far *s2,int len);

/* ******************************************************************* */

#define MAX_SIZES 32    /* maximum number font sizes in family */

struct segEntry { /* segment table entry */
    unsigned short offset; /* offset to segment data */
    unsigned short length; /* length of segment */
    unsigned short flags; /* segment flags */
    unsigned short minalloc; /* minimum allocation size */
}; /* segEntry */

struct newExeHdr {
    unsigned char version[4]; /* signature and linker version */
    unsigned short entryOffset; /* offset to entry table */
    unsigned short entryLength; /* length of entry table */
    long uursv1; /* reserved */
    unsigned short exeFlags1; /* executeable file flags */
    unsigned short autoSeg; /* automatic data segment number */
    unsigned short heapSize; /* initial size of local heap */
    unsigned short stackSize; /* initial size of stack */
    long CSIPreg; /* CS:IP register contents */
    long SSSPreg; /* SS:SP register contents */
    unsigned short numSegs; /* number entries in segment table */
    unsigned short numModule; /* number entries in module ref table */
    unsigned short nonresSize; /* size of nonresident name table */
    unsigned short segOffset; /* offset to segment table */
    unsigned short resourOffset; /* offset to resource table */
    unsigned short resnamOffset; /* offset to resident name table */
    unsigned short modrefOffset; /* offset to module reference table */
    unsigned short impnamOffset; /* offset to imported names table */
    long nonresOffset; /* offset to nonresident name table */
    unsigned short numMovEnt; /* number moveable entry points */
    unsigned short logsecShift; /* logical sector align shift */
    unsigned short numResSeg; /* number resource segments */
    unsigned short exeFlags2; /* executeable file flags */
    unsigned short fstlOffset; /* offset to fast-load area */
    unsigned short fstlSize; /* size of fast-load area */
    unsigned short uursv2; /* reserved */
    unsigned short winVer; /* expected Windows version */
    struct segEntry segTab; /* segment table */
    unsigned short rscAlignShift; /* alignment for resource data */
}; /* newExeHdr */

struct nameEntry { /* resource name table entry */
    unsigned short offset; /* offset to resource data */
    unsigned short length; /* length of resource */
    unsigned short flags; /* resource flags */
    unsigned short id; /* resource identifier */
    short uursv1; /* reserved */
    short uursv2; /* reserved */
}; /* nameEntry */

struct fontInfo {
    short dfVersion;	     /* version (0x200 or 0x300) */
    long dfSize;	   /* file size in bytes */
    char dfCopyright[60];   /* copyright string */
    short dfType;	     /* type of font file */
    short dfPoints;	     /* nominal point size */
    short dfVertRes;	     /* nominal vertical   resolution (dots/inch) */
    short dfHorizRes;	     /* nominal horizontal resolution (dots/inch) */
    short dfAscent;	     /* ascent */
    short dfInternalLeading; /* leading within dfPixHeight */
    short dfExternalLeading; /* leading between rows */
    unsigned char dfItalic;	     /* low-order bit set if italic */
    unsigned char dfUnderline;	     /* low-order bit set if underline */
    unsigned char dfStrikeOut;	     /* low-order bit set if strike-out font */
    short dfWeight;	     /* weight, 1-1000 range */
    unsigned char dfCharset;	     /* character set */
    short dfPixWidth;	     /* 0 = variable width, else character width */
    short dfPixHeight;	     /* character height */
    unsigned char dfPitchAndFamily;  /* low order bit = 1 = variable pitch */
			    /* FF_DONTCARE */
			    /* FF_ROMAN */
			    /* FF_SWISS */
			    /* FF_MODERN */
			    /* FF_SCRIPT */
			    /* FF_DECORATIVE */
    short dfAvgWidth;	     /* for variable pitch, width of 'X' */
    short dfMaxWidth;	     /* maximum character width of font */
    unsigned char dfFirstChar;	     /* first character in font */
    unsigned char dfLastChar;	     /* last character in font */
    unsigned char dfDefaultChar;     /* character used for empty slots */
    unsigned char dfBreakChar;	     /* character used to break word wrap */
    short dfWidthBytes;      /* bytes/row in bitmap */
    long dfDevice;	   /* offset to device name */
    long dfFace;	   /* offset to face name */
    long dfBitsPointer;    /* (GDI) pointer to bits */
    long dfBitsOffset;	   /* offset to bits within file */
    unsigned char dfReserved;	     /* unused */
    long dfFlags;	   /* bit flags for glyph format */
    short dfAspace;	     /* global A space */
    short dfBspace;	     /* global B space */
    short dfCspace;	     /* global C space */
    short dfColorPointer;    /* offset to color table */
    long dfReserved1;	   /* unused */
    unsigned char dfReserved2[14];   /* ??? conform to observed reality */
}; /* fontInfo */

struct dirEntry { /* font directory entry */
    short ordinal;	     /* ordinal of this font in file */
    short dfVersion;	     /* version (0x200 or 0x300) */
    long dfSize;	   /* file size in bytes */
    char dfCopyright[60];   /* copyright string */
    short dfType;	     /* type of font file */
    short dfPoints;	     /* nominal point size */
    short dfVertRes;	     /* nominal vertical   resolution (dots/inch) */
    short dfHorizRes;	     /* nominal horizontal resolution (dots/inch) */
    short dfAscent;	     /* ascent */
    short dfInternalLeading; /* leading within dfPixHeight */
    short dfExternalLeading; /* leading between rows */
    unsigned char dfItalic;	     /* low-order bit set if italic */
    unsigned char dfUnderline;	     /* low-order bit set if underline */
    unsigned char dfStrikeOut;	     /* low-order bit set if strike-out font */
    short dfWeight;	     /* weight, 1-1000 range */
    unsigned char dfCharset;	     /* character set */
    short dfPixWidth;	     /* 0 = variable width, else character width */
    short dfPixHeight;	     /* character height */
    unsigned char dfPitchAndFamily;  /* low order bit = 1 = variable pitch */
			    /* FF_DONTCARE */
			    /* FF_ROMAN */
			    /* FF_SWISS */
			    /* FF_MODERN */
			    /* FF_SCRIPT */
			    /* FF_DECORATIVE */
    short dfAvgWidth;	     /* for variable pitch, width of 'X' */
    short dfMaxWidth;	     /* maximum character width of font */
    unsigned char dfFirstChar;	     /* first character in font */
    unsigned char dfLastChar;	     /* last character in font */
    unsigned char dfDefaultChar;     /* character used for empty slots */
    unsigned char dfBreakChar;	     /* character used to break word wrap */
    short dfWidthBytes;      /* bytes/row in bitmap */
    long dfDevice;	   /* offset to device name */
    long dfFace;	   /* offset to face name */
    long dfReserved;	   /* unused */
    unsigned char  dfPad;	     /* pad so name on word boundary? */
}; /* dirEntry */

/* ******************************************************************* */

static unsigned char oldExeHdr[0x400] = {
        0x4d,0x5a,0x71,0x00,0x03,0x00,0x00,0x00,0x20,0x00,0x00,0x00,0xff,0xff,0x07,0x00,
        0x00,0x01,0x65,0x40,0x00,0x00,0x00,0x00,0x40,0x00,0x00,0x00,0x01,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x04,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0xe8,0x53,0x00,0x54,0x68,0x69,0x73,0x20,0x70,0x72,0x6f,0x67,0x72,0x61,0x6d,0x20,
        0x72,0x65,0x71,0x75,0x69,0x72,0x65,0x73,0x20,0x4d,0x69,0x63,0x72,0x6f,0x73,0x6f,
        0x66,0x74,0x20,0x57,0x69,0x6e,0x64,0x6f,0x77,0x73,0x2e,0x0d,0x0a,0x24,0x20,0x20,
        0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,
        0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,
        0x20,0x20,0x20,0x20,0x20,0x20,0x5a,0x0e,0x1f,0xb4,0x09,0xcd,0x21,0xb8,0x01,0x4c,
        0xcd,0x21,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
    };

/* ******************************************************************* */

main(argn,args)
int argn;
char **args;

{   int nin; /* number input files to process */
    int fi; /* index in input files */
    FILE *ifile; /* current input file */
    FILE *ofile; /* output file */
    struct stat ifst; /* input file status block */
    unsigned char huge *nExeBlock; /* block containing new executeable header */
    unsigned char huge *fHdrBlock; /* block containing font header */
    long inputL[MAX_SIZES]; /* size of each input file */
    int fontSize[MAX_SIZES]; /* logical size of each font */
    long toRead,toWrite; /* number bytes to read/write */
    long nRead,nWrote; /* amount actually read/written */
    int dirEntrySize; /* size of each entry in font directory */
    int dirFamNameSize; /* size of family name in font dir entry */
    struct fontInfo far *fHdrP; /* font resource header */
    long dirSize; /* total size of font directory */
    struct newExeHdr far *nExeP; /* pointer to new executeable header */
    char far *dirBP; /* pointer to base of font directory */
    struct dirEntry far *dirEP; /* pointer to directory entry */
    char huge *famP; /* pointer to font family name */
    char huge *cfamP; /* pointer to copy of family name */
    struct nameEntry far *nameEP; /* pointer in names entry table */
    unsigned char huge *rawP; /* pointer in exe header */
    unsigned int cumOffset; /* cumulative offset in file */
    unsigned int thisLength; /* length of current file (0x200 blocks) */
    char huge *fileBlock; /* block containing current file */
    long fileBlockSize; /* size of current file block */
    char strBuf[80]; /* working string */

    if (argn < 3) {
        printf("format is: fntfon input1.fnt..inputn.fnt output.fon\n");
        exit(1);
    }

    nin = argn-2; /* number input files */
    nExeBlock = l_alloc(0x400L); /* allocate memory for new executeable hdr */
    fHdrBlock = l_alloc(0x400L); /* allocate memory for first font header */
    if ((!nExeBlock) || (!fHdrBlock)) {
	printf("not enough memory\n");
	exit(1);
    }
    for(fi=0; fi<MAX_SIZES; fi++) {
        inputL[fi] = 0; /* don't know file size yet */
        fontSize[fi] = 0; /* don't know font size yet */
    } /* fi for */
    l_zero(nExeBlock,0x400L);
    l_zero(fHdrBlock,0x400L);
    nExeP = (struct newExeHdr far *)nExeBlock;
    fHdrP = (struct fontInfo far *)fHdrBlock;
    dirBP = NULL;
    dirFamNameSize = 0; /* don't know family name size yet */

    /* open output file */

    ofile = fopen(args[argn-1],"wb"); /* open output file */
    if (!ofile) {
        printf("cant open output file: %s\n",args[argn-1]);
        exit(1);
    } /* ofile */

    /* write DOS *.exe header to output file */

    nWrote = l_write(oldExeHdr,1,0x400L,ofile);
    if (nWrote != 0x400L) {
        printf("cant write output file: %s\n",args[argn-1]);
        exit(1);
    }

    /* loop thru input files obtaining headers */

    for(fi=0; fi<nin; fi++) {

	/* open next file, determine size */

        printf("reading file: %s\n",args[fi+1]);
        ifile = fopen(args[fi+1],"rb");
        if (!ifile) {
            printf("cant open input file: %s\n",args[fi+1]);
            exit(1);
        } /* ifile if */
        stat(args[fi+1],&ifst);
	inputL[fi] = ifst.st_size;

	/* read font header to local buffer */

	toRead = 0x400L; /* default size, whole block */
	if (inputL[fi] < toRead)
	    toRead = inputL[fi];
	nRead = l_read(fHdrBlock,1,toRead,ifile);
	if (nRead != toRead) {
	    printf("read of input file failed %s\n",args[fi+1]);
	    exit(1);
	}
	if (dirFamNameSize == 0) {
	    fclose(ifile); /* close already opened file */
	    fileBlock = l_alloc(inputL[fi]);
	    if (!fileBlock) {
		printf("not enough memory\n");
		exit(1);
	    }
	    ifile = fopen(args[fi+1],"rb");
	    if (!ifile) {
		printf("cant open input file: %s\n",args[fi+1]);
		exit(1);
	    } /* ifile if */
	    nRead = l_read(fileBlock,1,inputL[fi],ifile);
	    if (nRead != inputL[fi]) {
		printf("cant read input file: %s\n",args[fi+1]);
		exit(1);
	    }
	    famP = fileBlock+fHdrP->dfFace;
	    dirFamNameSize = strlenf(famP)+1;
	    dirEntrySize = sizeof(struct dirEntry)+dirFamNameSize;
	    dirSize = 2+(nin*dirEntrySize);
	    dirSize = ((dirSize+0x3ffL) >> 10) << 10;
	    dirBP = l_alloc(dirSize);
	    if (!dirBP) {
		printf("not enough memory\n");
		exit(1);
	    }
	    l_zero(dirBP,dirSize);
	    *dirBP = nin; /* number fonts */
	    dirEP = (struct dirEntry far *)(dirBP+2);
	    cfamP = ((char far *)(dirEP))+sizeof(struct dirEntry);
	    strcpyf(cfamP,famP); /* pre-copy name */
	    famP = cfamP; /* point to name at end of first entry */
	    l_free(fileBlock); /* release memory */
	} /* dirFamNameSize if */

	/* set up directory entry for this font */

	dirEP->ordinal = fi+1; /* ordinal of this font */
	dirEP->dfVersion = fHdrP->dfVersion;
	dirEP->dfSize = fHdrP->dfSize;
	dirEP->dfType = fHdrP->dfType;
	dirEP->dfPoints = fHdrP->dfPoints;
	dirEP->dfVertRes = fHdrP->dfVertRes;
	dirEP->dfHorizRes = fHdrP->dfHorizRes;
	dirEP->dfAscent = fHdrP->dfAscent;
	dirEP->dfInternalLeading = fHdrP->dfInternalLeading;
	dirEP->dfExternalLeading = fHdrP->dfExternalLeading;
	dirEP->dfItalic = fHdrP->dfItalic;
	dirEP->dfUnderline = fHdrP->dfUnderline;
	dirEP->dfStrikeOut = fHdrP->dfStrikeOut;
	dirEP->dfWeight = fHdrP->dfWeight;
	dirEP->dfCharset = fHdrP->dfCharset;
	dirEP->dfPixWidth = fHdrP->dfPixWidth;
	dirEP->dfPixHeight = fHdrP->dfPixHeight;
	dirEP->dfPitchAndFamily = fHdrP->dfPitchAndFamily;
	dirEP->dfAvgWidth = fHdrP->dfAvgWidth;
	dirEP->dfMaxWidth = fHdrP->dfMaxWidth;
	dirEP->dfFirstChar = fHdrP->dfFirstChar;
	dirEP->dfLastChar = fHdrP->dfLastChar;
	dirEP->dfDefaultChar = fHdrP->dfDefaultChar;
	dirEP->dfBreakChar = fHdrP->dfBreakChar;
	dirEP->dfWidthBytes = fHdrP->dfWidthBytes;
	dirEP->dfFace = fHdrP->dfFace;
	cfamP = ((char far *)(dirEP))+sizeof(struct dirEntry);
	l_block_move(famP,cfamP,(long)dirFamNameSize);
	cfamP += dirFamNameSize;
	dirEP = (struct dirEntry far *)cfamP; /* advance directory pointer */
        fclose(ifile); /* close this input file */
    } /* for */

    /* build new executeable header */

    nExeP->version[0] = 'N';
    nExeP->version[1] = 'E';
    nExeP->version[2] = 0x05;
    nExeP->version[3] = 0x1e;
    nExeP->exeFlags1 = 0x8300;
    nExeP->numSegs = 1;
    nExeP->nonresSize = 0x1d;
    nExeP->segOffset = 0x40;
    nExeP->resourOffset = 0x48;
    nExeP->resnamOffset = 0x70+(nin*sizeof(struct nameEntry));
    nExeP->modrefOffset = 0x7b+(nin*sizeof(struct nameEntry));
    nExeP->impnamOffset = nExeP->modrefOffset;
    nExeP->nonresOffset = 0x400+0x7c+(nin*sizeof(struct nameEntry));
    if (nExeP->nonresOffset & 1)
	nExeP->nonresOffset++; /* on word boundary */
    nExeP->entryOffset = (int)(nExeP->nonresOffset-0x401L);
    nExeP->entryLength = 1;
    nExeP->logsecShift = 9;
    nExeP->exeFlags2 = 0x0802;
    nExeP->fstlOffset = 0x03;
    nExeP->fstlSize = 0x03;
    nExeP->winVer = 0x030a;
    nExeP->segTab.flags = 0x0c00;
    nExeP->segTab.minalloc = 1;
    nExeP->rscAlignShift = 9;
    rawP = nExeBlock+sizeof(struct newExeHdr);
    *rawP++ = 0x07; /* font directory type id */
    *rawP++ = 0x80; /* font directory type id */
    *rawP++ = 0x01; /* resource count (1 font directory) */
    *rawP++ = 0x00; /* resource count */
    rawP += 4;
    nameEP = (struct nameEntry far *)(rawP);
    nameEP->offset = 0x04;
    nameEP->length = 1;
    nameEP->flags = 0x0c50;
    nameEP->id = 0x20+(nin*sizeof(struct nameEntry));
    rawP += sizeof(struct nameEntry);
    *rawP++ = 0x08; /* font type id */
    *rawP++ = 0x80; /* font type id */
    *rawP++ = nin;  /* resource count (number font resources) */
    *rawP++ = 0;    /* resource count */
    rawP += 4;
    nameEP = (struct nameEntry far *)(rawP);
    cumOffset = 0x06; /* starting offset for font resources */
    for(fi=0; fi<nin; fi++) {
	thisLength = (int)((inputL[fi]+0x1ffL) >> 9);
	nameEP->offset = cumOffset;
	nameEP->length = thisLength;
	nameEP->flags = 0x1c30;
	nameEP->id = 0x8001+fi;
	nameEP++;
	cumOffset += thisLength;
    } /* fi for */
    rawP += nin*sizeof(struct nameEntry);
    *rawP++ = 0; /* end of table */
    *rawP++ = 0; /* end of table */
    strcpy(strBuf,"\007FONTDIR\007FONTRES");
    l_block_move((char far *)strBuf,rawP,(long)strlen(strBuf));
    rawP = nExeBlock+(nExeP->nonresOffset-0x400L);
    strcpy(strBuf,"_FONTRES 100,96,96 : ");
    strcatf((char far *)strBuf,famP); /* attach family name */
    strcpyf(rawP,(char far *)strBuf);
    *rawP = strlen(strBuf)-1; /* set length of string */

    /* write new executeable header to output file */

    nWrote = l_write(nExeBlock,1,0x400L,ofile);
    if (nWrote != 0x400L) {
        printf("cant write output file: %s\n",args[argn-1]);
        exit(1);
    }

    /* write font directory */

    toWrite = dirSize;
    nWrote = l_write(dirBP,1,toWrite,ofile);
    if (nWrote != toWrite) {
	printf("cant write output file: %s\n",args[argn-1]);
	exit(1);
    }

    /* release memory used to build header+directory */

    l_free(nExeBlock);
    l_free(fHdrBlock);
    l_free(dirBP);

    /* copy individual font resource files */

    for(fi=0; fi<nin; fi++) {

	/* allocate memory for next file */

	fileBlockSize = ((inputL[fi]+0x1ffL) >> 9) << 9;
	fileBlock = l_alloc(fileBlockSize);
	if (!fileBlock) {
	    printf("not enough memory\n");
	    exit(1);
	}
	l_zero(fileBlock,fileBlockSize);

	/* open and copy next file */

	printf("copying file: %s\n",args[fi+1]);
        ifile = fopen(args[fi+1],"rb");
        if (!ifile) {
            printf("cant open input file: %s\n",args[fi+1]);
            exit(1);
	} /* ifile if */
	toRead = inputL[fi];
	nRead = l_read(fileBlock,1,toRead,ifile);
	if (nRead != toRead) {
	    printf("cant read input file: %s\n",args[fi+1]);
	    exit(1);
	}
	toWrite = fileBlockSize;
	nWrote = l_write(fileBlock,1,toWrite,ofile);
	if (nWrote != toWrite) {
	    printf("cant write output file: %s\n",args[argn-1]);
	    exit(1);
	}
	l_free(fileBlock); /* release memory */
	fclose(ifile); /* close input file */
    } /* for */

    fclose(ofile); /* close output file */

    exit(0);
    return(0);

} /* main */

/* ******************************************************************* */
