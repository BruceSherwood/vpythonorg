
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>
#include "baseenv.h"
#include "kdefs.h"
#include "tglobals.h"
#include "kglobals.h"
#include "editor.h"
#include "execdefs.h"

struct pcscroll { /* data required for scrollbar */
    struct tutorview FAR *sviewn;   /* view number of scrollbar */
    struct tutorview FAR *ownerV;   /* view pointer to owner */
    Memh ebshdrH; /* handle on cT object header (if any) */
    int ebsref; /* reference count on cT object header */
    TRect rr;   /* scrollbar rectangle */
    TRect relRect;  /* to position scroll in window */
        char textF;     /* TRUE if attached to text view */
        char unitF; /* non-zero if cT unit to invoke */
                        /* = 0 = no unit */
                        /* = 1 = unit, no arguments */
                        /* = 2 = unit + value argument */
    char type;  /* vertical/horizontal type */
    char posInfo;   /* positioning flags */
    int candraw;    /* TRUE if big enough window for scrollbar */
    int candrag;    /* TRUE if left-down in draggable area */
    int drag;   /* TRUE if dragging scrollbar */
    double minVal;  /* minimum value os scroll bar */
    double maxVal;  /* maximum value of scroll bar */
    double curVal;  /* current value */
    double pageInc; /* pageup/pagedown increment */
    double lineInc; /* lineup/linedown increment */
    char killErase; /* TRUE if we erase when scroll bar is closed */
    int ecolor; /* color to erase with */
    int bh;     /* end zone button height or width */
    int bw;     /* end zone button width or height */
    int bch;    /* button character */
    int thumbsize;  /* thumb size in pixels */
    int downOff;    /* at down-click, offset from click to top of thumb */
    int tbartop;    /* top (or left) of text rectangle */
    int tbarbottom; /* bottom (or right) of text rectangle */
    int seltop; /* top (for vert scroll bar) of selection region */
    int selbottom;  /* bottom (for vert scroll bar) of selection region */
    int unitN;  /* unit to invoke */
    double unitarg; /* argument of unit */
    double selectStart, selectEnd;  /* range of selection display, in scroll units */
    double (*ScrollProc)();     /* proc for scrolling */
    int ScrollIconFont; /* font index for icons */
    int ScrollPatFont; /* font index for background pattern */
    int ScrollCont; /* continuous scrolling type */
                    /* = -1 = continuous scroll halted */
                    /*    0 = not continuous scroll */
                    /*   +n = type of continuous scroll */
    double ScrollContN; /* continuous scroll value */
    double ScrollContE; /* end value for continuous scroll */
}; /* scroll */

#ifdef ctproto
extern int get_slider_ref(Memh sH);
TUTORset_cont_scroll(int window,struct tutorview FAR *view,int type,double sn); 
int  TUTORset_abs_clip_rect(struct  _trect FAR *cr);
extern int TUTORset_slider_value(Memh sbi,double value);
unsigned int  MakeScrollBar(struct  tutorview FAR *ovp,int  ew,unsigned int  ebshdrH,int ebsref,int  textF,int  sbType,int  info,struct  _trect *relRect,double  (*scrollProc)(),int  erase);
struct  tutorview FAR *TUTORinq_view_sbar(unsigned int  theSBar);
int  TUTORclose_sbar(unsigned int  theSBar);
int  procscroll(unsigned int  theSbar,struct  tutorevent *event);
int  TUTORreset_text_sbar(unsigned int  sbi,struct  _sbarinf *sinf,int  doDraw);
int  TUTORreset_values_sbar(unsigned int  sbi,double  value,double  minim,double  maxim,double pinc,double linc,int  unitf,int  unitn,double  unitarg,int  doDraw);
double  TUTORinq_slider_value(unsigned int  sbi);
int  drawscrollbar(unsigned int  theSbar);
extern int  updatescrollbar(struct  pcscroll FAR *ss);
double  SliderScroll(struct  tutorview FAR *tview,int  hv,double  fn,int  type);
char  FAR *GetPtr(unsigned int  mm);
int  TUTORset_view(struct  tutorview FAR *vp);
int  TUTORclose_view(struct  tutorview FAR *vp);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
struct  tutorview FAR *TUTORinq_view(void);
int  CTset_window_color(int  cn);
int  CTset_background_color(int  color);
int  CTset_foreground_color(int  color);
int  TUTORset_abs_view_rect(int  x1,int  y1,int  w,int  h);
int  TUTORuse_rel_rect(struct  _trect FAR *rRect,int  inf,struct  tutorview FAR *viewP,struct  _trect *sRect);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
struct  tutorview FAR *TUTORinit_view(int  sW,unsigned int  vDat,int  (*vProc)());
int  procscrollstub(unsigned int  scrH,struct  tutorevent *event);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
int  TUTORclip_window(int  wid);
int  TUTORflush(void);
int  TUTORfree_handle(unsigned int  mm);
int  TUTORpost_event(struct  tutorevent *event);
int  procexecwstub(unsigned int  wh,struct  tutorevent *event);
int  TUTORfill_abs_rect(struct  _trect FAR *tr,int  pattInd,int  pattC);
int  TUTORmove_rect(struct  _trect FAR *rr,int  xx,int  yy);
int  TUTORabs_line_to(int  x,int  y);
int  TUTORabs_move_to(int  x,int  y);
int  TUTORget_zfont(char  *famS,int  size);
int  TUTORset_comb_rule(int  rule);
int  TUTORframe_abs_rect(struct  _trect FAR *tr);
int  TUTORdump(char  *s);
#endif /* ctproto */

extern int procscrollstub();
extern int procexecwstub();
extern  struct tutorview FAR *TUTORinit_view();
extern  Memh MakeScrollBar();
extern struct tutorview FAR *TUTORinq_view();
extern struct tutorview FAR *TUTORinq_view_sbar();
extern double SliderScroll();

#ifdef ANDREW
extern int X11_server_bug;
#endif

#ifdef SYSV
extern int X11_server_bug;
#endif

#define SCROLLICONFONT "zicons"
#define SCROLLPATFONT "zpatterns"
#define BACKGNDCHh 4
#define BACKGNDCHv 4
#define BUTTONCH 2

/* ******************************************************************* */

Memh MakeScrollBar(ovp,ew,ebshdrH,ebsref,textF,sbType,info,relRect,scrollProc,erase)
struct tutorview FAR *ovp; /* owning view */
int ew; /* window index */
Memh ebshdrH; /* handle on cT object header (if any) */
int ebsref; /* reference count on cT object header */
int textF; /* TRUE if scroll bar owner is text view */
int sbType; /* type of scrollbar (horiz/vert) */
int info;
TRect *relRect;
double (*scrollProc)(); /* procedure to run scrolling */
int erase; /* TRUE if should erase on close */

{   register struct pcscroll FAR *scP;
    register struct tutorview FAR *vp, FAR *cv;
    int procscrollstub();
    struct tutorview FAR *scrollView;
    Memh theSbar;
    TRect tempR;
    int siz,hdim,tdim; /* size, head dim, tail dim */

    scrollView = TUTORinit_view(ew,HNULL,procscrollstub);
    if (!scrollView) return(0); /* failure to create new view */
    
    theSbar = TUTORhandle("scroll  ",(long) sizeof(struct pcscroll),TRUE);
    if (!theSbar) return(0);
    scP = (struct pcscroll FAR *) GetPtr(theSbar);
    
    scP->textF = textF;
    scP->ebshdrH = ebshdrH; /* handle on cT object header */
    scP->ebsref = ebsref;
    scP->unitF = 0; /* no unit yet */
    scP->type = sbType;
    scP->sviewn = scrollView;
    scP->ownerV = ovp;
    scP->candraw = FALSE;   /* cant generate display yet */
    scP->candrag = FALSE;   /* cant drag yet */
    scP->drag = FALSE;
    scP->ScrollCont = 0; /* no continuous scrolling yet */
    *tempFarR = *relRect;
    TUTORuse_rel_rect(tempFarR,info,scrollView,&tempR);
    scP->rr = tempR;

    /* compute edge button and thumb dimensions */
    if (sbType == SBVERT) { 
        siz = scP->rr.bottom-scP->rr.top;
        scP->bw = hdim = scP->rr.right-scP->rr.left;
        scP->bh = tdim = siz/4;
    } else { 
        siz = scP->rr.right-scP->rr.left;
        scP->bw = tdim = scP->rr.bottom-scP->rr.top;
        scP->bh = hdim = siz/4;
    }

    /* find useable-sized icon */
    scP->bch = 0; /* no arrows in edge buttons */
    if ((hdim >= 15) && (tdim >= 13)) {
        scP->bch = 85;
        if (tdim > 15) tdim = 15;
    } else if ((hdim >= 9) && (tdim >= 9)) {
        scP->bch = 89;
        if (tdim > 10) tdim = 10;
    } else if ((hdim >= 5) && (tdim >= 7)) {
        scP->bch = 93;
        if (tdim > 9) tdim = 9;
    }
    scP->bh = scP->thumbsize = tdim;

    scP->ScrollPatFont = scP->ScrollIconFont = -1; /* not set yet */
    scP->relRect = *relRect;
    scP->posInfo = info;
    scP->curVal = scP->maxVal =  scP->minVal = 0.0;
    scP->pageInc = scP->lineInc = 0.0;
    scP->tbarbottom = scP->tbartop = -1; /* no thumb yet */
    scP->selectStart = -1; /* no selection yet */
    scP->ScrollProc = scrollProc;
    scP->killErase = erase;
    scP->ecolor = winColor.palette;

    vp = scrollView;
    cv = TUTORinq_view();
    TUTORset_view(vp);
    vp->vh = theSbar;
    TUTORset_abs_view_rect(scP->rr.left,scP->rr.top,scP->rr.right-scP->rr.left+1,
            scP->rr.bottom-scP->rr.top+1);
    if (cv) {
        CTset_foreground_color(cv->fgndColor.palette); /* set to parent's colors */
        CTset_background_color(cv->bgndColor.palette);
        CTset_window_color(cv->winColor.palette);
    }
    ReleasePtr(theSbar);
    TUTORset_view(cv);

    return(theSbar);

} /* MakeScrollBar */

/* ******************************************************************* */

struct tutorview FAR *TUTORinq_slider_view(theSBar)
Memh theSBar;
    
{   struct pcscroll FAR *ss;
    struct tutorview FAR *vv;
    
    ss = (struct pcscroll FAR *) GetPtr(theSBar);
    vv = ss->sviewn;
    ReleasePtr(theSBar);
    KillPtr(ss);

    return(vv);

} /* TUTORinq_slider_view */

/* ******************************************************************* */

TUTORclose_sbar(theSBar)
Memh theSBar;
    
{   struct pcscroll FAR *ss;
    struct tutorview FAR *vv, FAR *cv;
    TRect rr;
    int doErase,svcolor,ecolor;
    
    if (!theSBar)
        return(0);
    cv = TUTORinq_view(); /* remember existing view for restoration */
    ss = (struct pcscroll FAR *) GetPtr(theSBar);
    vv = ss->sviewn; /* the scroll bar's view */
    ecolor = ss->ecolor;
    doErase = ss->killErase; /* find out whether we want to erase */
    ReleasePtr(theSBar);
    KillPtr(ss);
    
    if (doErase) { /* erase the scroll bar */
        TUTORset_view(vv);
    rr = vv->rr;
    svcolor = bgndColor.palette; /* save current background color */
    CTset_background_color(ecolor);
    TUTORdraw_abs_solid_rect(&rr, PAT_WHITE);
    CTset_background_color(svcolor);
    }
    
    TUTORclose_view(vv);
    TUTORset_view(cv); /* restore view */

} /* TUTORclose_sbar */

/* ******************************************************************* */

procscroll(theSbar,event) /* event processor for scroll bar  */
Memh theSbar;
struct tutorevent *event; /* event to process */

{   struct pcscroll FAR *ss;
    TRect tempR;
    int scrollType;  /* parameters for call to ScrollProc */
    double scrollN;
    int vhtype; /* vertical/horizontal flag */
    struct tutorview FAR *spv; /* view/info passed to ScrollProc */
    int downp;  /* click position (without regard to x or y) */
    int ybase;
    int ysize;
    int sendHit; /* TRUE if should send message to unit */
    int contf; /* continuous scroll type */
    double oldV; /* previous value of slider */
    struct tutorevent cev; /* event to send to executor */
    struct tutorevent csv; /* continuous scrolling start event */

    ss = (struct pcscroll FAR *) GetPtr(theSbar);
    vhtype = (ss->type == SBHORIZ); /* TRUE if horizontal */
    if (ss->textF) spv = ss->ownerV;
    else spv = (struct tutorview FAR *)ss;
    sendHit = FALSE;
    oldV = ss->curVal;
    scrollType = 0; /* no scroll type yet */
    scrollN = 0;

    switch (event->type) {

    case EVENT_REDRAW:
        TUTORuse_rel_rect(&ss->relRect,ss->posInfo,ss->sviewn,&tempR);  /* set up scrollbar rectangle */
        ss->rr = tempR;
        TUTORset_abs_view_rect(ss->rr.left,ss->rr.top,ss->rr.right-ss->rr.left+1,ss->rr.bottom-ss->rr.top+1);
        TUTORclip_window(event->window);
        drawscrollbar(theSbar);
        break;

    case EVENT_VFOCUS:
        if (event->value)
            { /* set focus to owner's view */
            TUTORset_key_focus(ss->ownerV->window,ss->ownerV,FALSE);
            }
        /* we don't care when we lose focus */
        break;
    
    case EVENT_LEFTDOWN:
    case EVENT_RIGHTDOWN:
        ss->ScrollCont = 0; /* no continuous scroll yet */
        if (ss->type == SBVERT) downp = event->y;
        else downp = event->x;
        if ((downp >= ss->tbartop) && (downp <= ss->tbarbottom)) { 
            /* in thumb */
            ss->candrag = TRUE;
            ss->downOff = downp - ss->tbartop;
        } else if ((ss->type == SBVERT && event->y < ss->rr.top+ss->bh) || 
                  (ss->type == SBHORIZ && event->x < ss->rr.left+ss->bh)) {
            /* process click in top button */
            scrollType = sbLineUp;
        } else if ((ss->type == SBVERT && event->y > ss->rr.bottom-ss->bh) || 
                  (ss->type == SBHORIZ && event->x > ss->rr.right-ss->bh)) {
            /* process click in bottom button */
            scrollType = sbLineDown;
        } else { /* process simple click in scroll bar */
            ss->candrag = FALSE;
            if (ss->type == SBVERT) {
                downp = event->y;
                ysize = (ss->rr.bottom-ss->rr.top)-2*ss->bh;
                ybase = ss->rr.top+ss->bh;
            } else {
                downp = event->x;
                ysize = (ss->rr.right-ss->rr.left)-2*ss->bh;
                ybase = ss->rr.left+ss->bh;
            }
            if (downp < ss->tbartop)
                scrollType = sbPageUp;
            else if (downp > ss->tbarbottom)
                scrollType = sbPageDown;
            downp -= ybase;
            ss->ScrollContE = ((double) downp 
                 * (ss->maxVal-ss->minVal))/(double) ysize;
            ss->ScrollContE += ss->minVal;
            if (ss->ScrollContE < ss->minVal)
                ss->ScrollContE = ss->minVal;
            else if (ss->ScrollContE > ss->maxVal)
                ss->ScrollContE = ss->maxVal;
        }
        if (scrollType) { /* activate continuous scroll */
            ss->ScrollCont = scrollType;
            ss->ScrollContN = scrollN;
            csv.type = EVENT_TIME;
            csv.window = event->window;
            csv.view = event->view;
            csv.eDataP = FARNULL;
            csv.value = 0;
            csv.timestamp = 500L; /* start in 500 msec */
            TUTORpost_event((struct tutorevent *)&csv);
        }
        break;

    case EVENT_LEFTUP:
    case EVENT_RIGHTUP:
        TUTORset_cont_scroll(-1,FARNULL,0,0.0);
        contf = ss->ScrollCont;
        ss->ScrollCont = 0;
		if (event->window == ExecWn) {
			windowsP[ExecWn].MouseFocus = ss->ownerV;
		}
        if (ss->drag) {  /* process end of scrollbar drag */
            scrollN = ss->curVal;
            scrollType = sbToPos;
        } else if ((ss->type == SBVERT && event->y < ss->rr.top+ss->bh) ||
                (ss->type == SBHORIZ && event->x < ss->rr.left+ss->bh))
            {  /* process click in top button */
            scrollN = 0;
            scrollType = sbLineUp;
        }
        else if ((ss->type == SBVERT && event->y > ss->rr.bottom-ss->bh) ||
                (ss->type == SBHORIZ && event->x > ss->rr.right-ss->bh))
            { /* process click in bottom button */
            scrollN = 0;
            scrollType = sbLineDown;
            } /* bottom button else-if */
        else {  /* process simple click in scroll bar */
            scrollN = 0;
            if (ss->type == SBVERT) 
                downp = event->y;
            else downp = event->x;
            if (downp < ss->tbartop)
                scrollType = sbPageUp;
            else if (downp > ss->tbarbottom)
                scrollType = sbPageDown;
        }
        ss->candrag = ss->drag = FALSE;
        if ((scrollType == 0) || (contf < 0))
            break; /* nothing to do */
        ss->curVal = (*ss->ScrollProc)
                             (spv,vhtype,scrollN,scrollType);
        if (ss->curVal < ss->minVal)
            ss->curVal = ss->minVal;
        else if (ss->curVal > ss->maxVal)
            ss->curVal = ss->maxVal;
        drawscrollbar(theSbar);
        sendHit = TRUE;
        break;


    case EVENT_DOWNMOVE:
        if ((!event->leftdown) || (!ss->candrag)) break;

        if (!ss->drag) {
            /* we haven't started dragging yet, has mouse moved enough? */
            downp = ((ss->type == SBVERT) ? event->y : event->x)- ss->tbartop;
            if (downp < ss->downOff + 2 && downp > ss->downOff - 2)
                break; /* not enough of a move */
        }

        ss->drag = TRUE;    /* dragging in progress */

        /* compute new value */
        if (ss->type == SBVERT) {
            ysize = ss->rr.bottom - ss->rr.top - 2*ss->bh;
            downp = event->y - ss->rr.top - ss->bh - ss->downOff;
        } else {
            ysize = ss->rr.right - ss->rr.left - 2*ss->bh;
            downp = event->x - ss->rr.left - ss->bh - ss->downOff;
        }
        if (downp < 0)
            downp = 0; /* dragged too far left */
        ss->curVal = ((double) downp * (ss->maxVal-ss->minVal))/(double) ysize;
        ss->curVal += ss->minVal;
        if (ss->curVal < ss->minVal)
            ss->curVal = ss->minVal;
        else if (ss->curVal > ss->maxVal)
            ss->curVal = ss->maxVal;
        updatescrollbar(ss);
        sendHit = TRUE;
        break;

    case EVENT_DESTROY:
        break; /* only thing needed to be done is to free handle.  Done below */

    case EVENT_TIME:
        if (ss->ScrollCont <= 0) 
            break; /* scroll terminated */
        scrollType = event->value;
        if (scrollType == 0) { /* activate continuous scroll */
            TUTORset_cont_scroll(event->window,event->view,ss->ScrollCont,ss->ScrollContN);
            break;
        }
        scrollN = event->a3;
        ss->curVal = (*ss->ScrollProc)
                             (spv,vhtype,scrollN,scrollType);
        if (ss->curVal < ss->minVal)
            ss->curVal = ss->minVal;
        else if (ss->curVal > ss->maxVal)
            ss->curVal = ss->maxVal;
        if (((scrollType == sbPageUp) && (ss->curVal <= ss->ScrollContE)) ||
            ((scrollType == sbPageDown) && (ss->curVal >= ss->ScrollContE))) {
            /* reached endpoint, stop scroll */
            TUTORset_cont_scroll(-1,FARNULL,0,0.0);
            ss->ScrollCont = -1;
            ss->curVal = ss->ScrollContE;
        }
        drawscrollbar(theSbar);
        ss->candrag = ss->drag = FALSE;
        sendHit = TRUE;
        break;

    } /* switch */

    if (ss->unitF && sendHit && (oldV != ss->curVal)) {

        /* do unit if value has changed */

		TUTORzero((char FAR *)&cev,(long)sizeof(struct tutorevent));
        cev.type = EVENT_SIGNAL;
        cev.window = -1; /* not sent to a window */
        cev.a5 = windowsP[ExecWn].wH;
        cev.timestamp = 0;
        cev.eDataP = FARNULL;
        cev.vproc = procexecwstub;
        if (ss->unitF == 1)
            cev.a1 = BUTTONSIGNAL;
        else cev.a1 = BUTTONSIGNALA;
        cev.a2 = ss->ebshdrH;
		cev.a6 = ss->ebsref;
        cev.a3 = ss->unitarg;
        cev.value = ss->unitN;
        TUTORpost_event(&cev);
    } /* unitF if */

    ReleasePtr(theSbar);
    if (event->type == EVENT_DESTROY)
        TUTORfree_handle(theSbar);
    TUTORflush();

} /* procscroll */

/* ******************************************************************* */

TUTORreset_text_sbar(sbi,sinf,doDraw)
Memh sbi;
SBarInfo *sinf;
int doDraw; /* TRUE if we want to draw here */
    
{   struct pcscroll FAR *sp;
    long myMax;

    sp = (struct pcscroll FAR *) GetPtr(sbi);
    if (!sp->textF) {
        ReleasePtr(sbi);
        return(0);
    }
    
    /* adjust horizontal so that right edge of text never goes past */
    /* right edge of view */
    if (sp->type == SBHORIZ)
        myMax = sinf->maxPos - sinf->rangeLen;
    else
        myMax = sinf->maxPos;
    
    /* set everything explicitly & draw */
    sp->maxVal = myMax;
    sp->curVal = sinf->curPos;
    if (sp->type == SBVERT) {
        sp->selectStart = sinf->selPos;
        sp->selectEnd = sinf->selPos + sinf->selLen;
    }
    
    if (doDraw)
        updatescrollbar(sp);

    ReleasePtr(sbi);

    return(0);

} /* TUTORreset_text_sbar */

/* ******************************************************************* */

TUTORreset_values_sbar(sbi,value,minim,maxim,pinc,linc,unitf,unitn,unitarg,doDraw)
Memh sbi;
double value, minim, maxim, pinc, linc;
int unitf; /* = 0 = no associated unit */
           /*   1 = unit, no arguments */
           /*   2 = unit with single value argument */
int unitn; /* unit number */
double unitarg; /* unit value argument */
int doDraw; /* TRUE if we want to draw here */
    
{   struct pcscroll FAR *sp;
    long myMax;
    double dist;

    sp = (struct pcscroll FAR *) GetPtr(sbi);
    
    /* set everything explicitly & draw */
    sp->maxVal = maxim;
    sp->minVal = minim;
    sp->unitF = unitf;
    sp->unitN = unitn;
    sp->unitarg = unitarg;
    sp->pageInc = pinc;
    sp->lineInc = linc;
    if ((!sp->textF) && (sp->type == SBVERT)) {
        /* invert value for vertical scroll bar */
        dist = value-sp->minVal;
        value = sp->maxVal-dist;
    }
    sp->curVal = value;
    if (sp->curVal < sp->minVal)
        sp->curVal = sp->minVal;
    else if (sp->curVal > sp->maxVal)
        sp->curVal = sp->maxVal;
    
    if (doDraw) {
        updatescrollbar(sp);
    }

    ReleasePtr(sbi);

    return(0);

} /* TUTORreset_values_sbar */

/* ******************************************************************* */

TUTORset_slider_value(sbi,value)
Memh sbi;
double value;
    
{   struct pcscroll FAR *sp;
    long myMax;
    double dist;

    sp = (struct pcscroll FAR *) GetPtr(sbi);

    if ((!sp->textF) && (sp->type == SBVERT)) {
        /* invert value for vertical scroll bar */
        dist = value-sp->minVal;
        value = sp->maxVal-dist;
    }
    if (value >sp->maxVal) value = sp->maxVal;
    if (value < sp->minVal) value = sp->minVal;
    sp->curVal = value;
    updatescrollbar(sp);
    ReleasePtr(sbi);

    return(0);

} /* TUTORset_slider_value */

/* ******************************************************************* */

double TUTORinq_slider_value(sbi)
Memh sbi;

{   struct pcscroll FAR *sp;
    double value,dist;

    sp = (struct pcscroll FAR *) GetPtr(sbi);
    value = sp->curVal;
    if ((!sp->textF) && (sp->type == SBVERT)) {
        /* invert value for vertical scroll bar */
        dist = value-sp->minVal;
        value = sp->maxVal-dist;
    }
    ReleasePtr(sbi);
    return(value);

} /* TUTORinq_slider_value */

/* ******************************************************************* */

drawscrollbar(theSbar) /* plot scrollbar display */
Memh theSbar;

{   int xsize,ysize;    /* x/y sizes of scrollbar rectangle */
    long viewstart;     /* starting character displayed */
    long viewlth;       /* number characters displayed */
    long selstart;      /* starting character of selection */
    long sellth;        /* number characters in selection region */
    struct pcscroll FAR *ss;    /* pointer to scrollbar info */
    int ii;
    int savcolor;       /* saved foreground color */
    struct tutorview FAR *cv;
    TRect tr;

    if (!theSbar) return(0);
    ss = (struct pcscroll FAR *) GetPtr(theSbar);
    cv = TUTORinq_view();
    TUTORset_view(ss->sviewn); /* set to scroll view */
    TUTORset_comb_rule(SRC_COPY);
    savcolor = fgndColor.palette;

    /* check if window big enough for scroll bar */

    ss->candraw = TRUE; /* assume display big enough */
    xsize = ss->rr.right-ss->rr.left; /* dimensions of scrollbar */
    ysize = ss->rr.bottom-ss->rr.top;
    if (ss->type == SBHORIZ) {
        ii = xsize; /* exchange if horizontal */
        xsize = ysize;
        ysize = ii;
    }
    if (xsize < 6) {
        ss->candraw = FALSE;
        TUTORset_view(cv);
        ReleasePtr(theSbar);
        return(0); /* area too small */
    } /* xsize if */
    if (ysize < (3*ss->bh)) { /* very crushed scrollbar */
        ss->candraw = FALSE;
        if (ysize <= 1)  { /* way too small */
            TUTORset_view(cv);
            return(0);
        }
        /* no scroll bar, just line */
        if (ss->type == SBVERT) {
            TUTORabs_move_to(ss->rr.right,ss->rr.top); 
            TUTORabs_line_to(ss->rr.right,ss->rr.bottom);
        } else {
            TUTORabs_move_to(ss->rr.left,ss->rr.top);
            TUTORabs_line_to(ss->rr.right,ss->rr.top);
        } /* ss->type if */
        ReleasePtr(theSbar);
        TUTORset_view(cv);
        return(0);
    } /* ysize if */

    /* initialize fonts */

    if (ss->ScrollPatFont < 0) {
        ss->ScrollIconFont = TUTORget_zfont(SCROLLICONFONT,-1);
        ss->ScrollPatFont = TUTORget_zfont(SCROLLPATFONT,-1);
    }

    /* build display */

#ifdef ANDREW
    if (!isx11) /* wm needs to preclear the area */
        TUTORdraw_abs_solid_rect(&ss->rr,PAT_WHITE);
#endif

    if (ss->type == SBVERT) {

        /* outline */
        TUTORabs_move_to(ss->rr.right,ss->rr.top);
        TUTORabs_line_to(ss->rr.right,ss->rr.bottom);
        TUTORabs_line_to(ss->rr.left,ss->rr.bottom);
        
        /* buttons */
        draw_scroll_buttons(ss);

        /* background */
        tr.left = ss->rr.left;
        tr.right = ss->rr.right-1;
        tr.top = ss->rr.top+ss->bh;
        tr.bottom = ss->rr.bottom-ss->bh;
        TUTORfill_abs_rect(&tr , ss->ScrollPatFont, BACKGNDCHv);
    } else {

        /* outline */
        TUTORabs_move_to(ss->rr.left,ss->rr.bottom);
        TUTORabs_line_to(ss->rr.left,ss->rr.top);
        TUTORabs_line_to(ss->rr.right,ss->rr.top);

        /* buttons */
        draw_scroll_buttons(ss);

        /* background */
        tr.top = ss->rr.top+1;
        tr.bottom = ss->rr.bottom;
        tr.left = ss->rr.left + ss->bh;
        tr.right = ss->rr.right-ss->bh;
        TUTORfill_abs_rect(&tr, ss->ScrollPatFont, BACKGNDCHh);
    } /* type if */

    ss->tbartop = ss->tbarbottom = -1; /* no previous to erase */
    updatescrollbar(ss);

    ReleasePtr(theSbar);

    TUTORset_view(cv);
    return(0);

} /* drawscrollbar */

/* ******************************************************************* */

static int draw_scroll_buttons(ss)
struct pcscroll FAR *ss;

{   TRect tr1,tr2; /* rectangle for buttons */
    TRect savclip; /* clip rectangle */
    int ix1,iy1,ix2,iy2; /* origin for icons */
    int iconn; /* icon number */
    char sc[2]; /* character to plot */

    if (ss->type == SBVERT) {
        tr1.left = tr2.left = ss->rr.left;
        tr1.right = tr2.right = ss->rr.right-1;
        tr1.top = ss->rr.top;
        tr1.bottom = ss->rr.top+ss->bh-1;
        tr2.top = (ss->rr.bottom-ss->bh)+1;
        tr2.bottom = ss->rr.bottom;
        ix1 = ix2 = tr1.left+(ss->bw/2);
        iy1 = tr1.bottom;
        iy2 = tr2.top;
        iconn = ss->bch;
    } else {
        tr1.top = tr2.top = ss->rr.top+1;
        tr1.bottom = tr2.bottom = ss->rr.bottom;
        tr1.left = ss->rr.left;
        tr1.right = ss->rr.left+ss->bh-1;
        tr2.right = ss->rr.right;
        tr2.left = (ss->rr.right-ss->bh)+1;
        iy1 = iy2 = tr1.bottom-(ss->bw/2);
        ix1 = tr1.right;
        ix2 = tr2.left;
        iconn = ss->bch+2;
    } /* sbvert else */

    /* draw button background */

    TUTORset_comb_rule(SRC_COPY);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr1,PAT_BLACK);
    TUTORdraw_abs_solid_rect((TRect FAR *) &tr2,PAT_BLACK);

    /* draw arrow icons */

    if (ss->bch == 0) 
        return(0); /* exit if no icon */

    savclip = tgclipR; /* save clip rectangle */
    TUTORset_comb_rule(NOT_SRC_COPY);
    sc[0] = iconn;
    sc[1] = 0;
    TUTORset_abs_clip_rect((TRect FAR *)&tr1);
    TUTORabs_move_to(ix1,iy1);
#ifdef IBMPC
    TUTORdraw_graphic_icons(ss->ScrollIconFont,sc,1); 
#else
/* kludge - draw icons with lines to get around broken X server */
/* pmax X11 server of 3/23/92 won't clip icon properly */
/* dma 3/23/92 */
    if (!X11_server_bug) {
        TUTORdraw_graphic_icons(ss->ScrollIconFont,sc,1); 
    } else if (ss->type == SBVERT) {
        TUTORabs_line_to(ix1,tr1.top+2);
        TUTORabs_line_to(ix1+3,tr1.top+5);
        TUTORabs_move_to(ix1,tr1.top+2);
        TUTORabs_line_to(ix1-3,tr1.top+5);
    } else {
        TUTORabs_line_to(tr1.left+2,iy1);
        TUTORabs_line_to(tr1.left+5,iy1+3);
        TUTORabs_move_to(tr1.left+2,iy1);
        TUTORabs_line_to(tr1.left+5,iy1-3);
    }
#endif
    sc[0] = iconn+1;
    TUTORset_abs_clip_rect((TRect FAR *)&tr2);
    TUTORabs_move_to(ix2,iy2);
#ifdef IBMPC
    TUTORdraw_graphic_icons(ss->ScrollIconFont,sc,1); 
#else
/* kludge dma 3/23/92 */
    if (!X11_server_bug) {
        TUTORdraw_graphic_icons(ss->ScrollIconFont,sc,1); 
    } else if (ss->type == SBVERT) {
        TUTORabs_line_to(ix1,tr2.bottom-2);
        TUTORabs_line_to(ix1+3,tr2.bottom-5);
        TUTORabs_move_to(ix1,tr2.bottom-2);
        TUTORabs_line_to(ix1-3,tr2.bottom-5);
    } else {
        TUTORabs_line_to(tr2.right-2,iy1);
        TUTORabs_line_to(tr2.right-5,iy1+3);
        TUTORabs_move_to(tr2.right-2,iy1);
        TUTORabs_line_to(tr2.right-5,iy1-3);
    }
#endif
    TUTORset_abs_clip_rect((TRect FAR *)&savclip);
    TUTORset_comb_rule(SRC_COPY); /* restore mode */
    return(0);

} /* draw_scroll_buttons */

/* ******************************************************************* */

static updatescrollbar(ss) /* update changeable part of scroll bar */
struct pcscroll FAR *ss; /* pointer to scrollbar info */

{   TRect tbar;     /* text bar rectangle */
    TRect erasure;      /* erase after moving scrollbar */
    int ysize;      /* y size of scrollbar rectangle */
    long vbegin,vlth;   /* displayed lines */
    long sbegin,slth;   /* selected lines */
    short musterase;    /* true if must erase old rect. */
    struct tutorview FAR *cv;
    double range; /* slider range */
    double fPos; /* thumb position (0-1.0) */

    if (ss == NULL) return(0);
    if (ss->candraw == FALSE) return(0);
    if (ss->maxVal <= ss->minVal) return(0);
    cv = TUTORinq_view();
    TUTORset_view(ss->sviewn); /* set to scroll view */
    TUTORset_comb_rule(SRC_COPY);
    musterase = (ss->tbartop >= 0);

   /* Note that in wm, TUTORfill_abs_rect does NOT alter the background */

    if (ss->type == SBVERT) 
        ysize = (ss->rr.bottom-ss->rr.top)-(2*ss->bh);
    else
        ysize = (ss->rr.right-ss->rr.left)-(2*ss->bh); /* really h size */
    range = ss->maxVal-ss->minVal;
    fPos = (ss->curVal-ss->minVal)/(range);

    if (ss->type == SBVERT) {
        tbar.left = ss->rr.left+1;
        tbar.right = ss->rr.right-1;
        tbar.top = fPos*(double)ysize;
        tbar.top += ss->rr.top+ss->bh-(ss->thumbsize/2);
        tbar.bottom = tbar.top+ss->thumbsize;
        if (tbar.top < (ss->rr.top+ss->bh)) {
            /* keep below top button */
            tbar.top = ss->rr.top+ss->bh;
        }
        if (tbar.bottom > (ss->rr.bottom-ss->bh)) {
            /* keep above bottom button */
            tbar.top = ss->rr.bottom-ss->bh-ss->thumbsize;
        }
        tbar.bottom = tbar.top+ss->thumbsize;
    } else { /* horizontal */
        tbar.top = ss->rr.top+1;
        tbar.bottom = ss->rr.bottom-1;
        tbar.left = (fPos*(double)ysize);
        tbar.left += ss->rr.left + ss->bh - (ss->thumbsize/2);
        tbar.right = tbar.left+ss->thumbsize;
        if (tbar.left < (ss->rr.left+ss->bh)) {
            /* keep right of left button */
            tbar.left = ss->rr.left+ss->bh;
        }
        if (tbar.right > (ss->rr.right-ss->bh)) {
            /* keep left of right button */
            tbar.left = ss->rr.right-ss->bh-ss->thumbsize;
        }
        tbar.right = tbar.left+ss->thumbsize;
    }

    if (ss->type == SBVERT) {
        erasure.left = ss->rr.left+1;
        erasure.right = ss->rr.right-1;
        erasure.top = tbar.bottom+1; /* assume going up */
        erasure.bottom = ss->tbarbottom;
        if (tbar.top > ss->tbartop) { /* going down */
            erasure.top = ss->tbartop;
            erasure.bottom = tbar.top-1;
        }
        ss->tbartop = tbar.top;
        ss->tbarbottom = tbar.bottom;
    } else {
        erasure.left = tbar.right+1; /* assume going left */
        erasure.right = ss->tbarbottom;
        erasure.top = ss->rr.top+1;
        erasure.bottom = ss->rr.bottom;
        if (tbar.left > ss->tbartop) { /* going right */
            erasure.left = ss->tbartop;
            erasure.right = tbar.left-1;
        }
        ss->tbartop = tbar.left;
        ss->tbarbottom = tbar.right;
    }

    TUTORdraw_abs_solid_rect((TRect FAR *) &tbar,PAT_WHITE);

    if (musterase) {
#ifdef ANDREW
        if (!isx11) /* wm needs to preclear */
            TUTORdraw_abs_solid_rect((TRect FAR *) &erasure,PAT_WHITE);
#endif
        TUTORfill_abs_rect(&erasure,ss->ScrollPatFont,BACKGNDCHv);
        
    }
    TUTORframe_abs_rect((TRect FAR *)&ss->rr);
    TUTORframe_abs_rect((TRect FAR *) &tbar);

    if (ss->type == SBHORIZ || ss->selectStart == -1) {
        /* don't draw selected area for horizontal scrollbar, or when no selected area */
        TUTORset_view(cv);
        return(0);
    }

    TUTORset_view(cv);
    return(0);

} /* updatescrollbar */

/* ******************************************************************* */

double  SliderScroll(tview,hv,fn,type)
struct  tutorview FAR *tview;
int  hv;
double  fn;
int  type;

{   long nn;
    struct pcscroll FAR *scp;
    double retv; /* returned value */

    scp = (struct pcscroll FAR *)tview; /*  actually pointer to scroll */
    nn = fn; 
    retv = scp->curVal;

    switch (type) {

        case sbToPos:
            break;

        case sbPageUp:
            retv = scp->curVal-scp->pageInc;
            if ((scp->ScrollCont > 0) && (retv <= scp->ScrollContE))
        retv = scp->ScrollContE;
            break;

        case sbPageDown:
            retv = scp->curVal+scp->pageInc;
            if ((scp->ScrollCont > 0) && (retv >= scp->ScrollContE))
                retv = scp->ScrollContE;
            break;

        case sbVDown: /* andrew-style left click */
        case sbVUp: /* andrew-style right click */
            break;

        case sbLineUp:
            retv = scp->curVal-scp->lineInc;
            break;

        case sbLineDown:
            retv = scp->curVal+scp->lineInc;
            break;

        case sbToTop:
            retv = scp->minVal;
            break;

        case sbToBot: /* to end of view */
            retv = scp->maxVal;
            break;

        default:
            break;

    } /* switch */
    return(retv);

} /* SliderScroll */

/* ******************************************************************* */

TUTORinq_slider_busy()
	
{
    return(FALSE);
}

/* ******************************************************************* */

int get_slider_ref(objH) /* get slider object reference count */
Memh objH; /* handle on cT object */

{   struct ebshdr FAR *objP; /* pointer to cT object */
    Memh sH; /* handle on slider info */
    struct pcscroll FAR *sp; /* pointer to slider info */
    int refcnt;
    
    if (!objH) return(0);
    objP = (struct ebshdr FAR *)GetPtr(objH);
    sH = objP->objectH; /* handle on slider info */
    ReleasePtr(objH);
    sp = (struct pcscroll FAR *)GetPtr(sH);
    refcnt = sp->ebsref; /* get reference count */
    ReleasePtr(sH);
    return(refcnt);

} /* get_slider_ref */

/* ******************************************************************* */
