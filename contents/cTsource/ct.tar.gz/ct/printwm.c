
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include <stdio.h>

#include "baseenv.h"
#include "tutor.h"
#include "kdefs.h"
#include "editor.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "edglobal.h"
#include "kglobals.h"
#include "txt.h"
#include "txtv.h"

#ifdef ctproto
int  printdoc(struct  _tvdat FAR *et,char  *dName);
int  editormsg(char  *ss,int  aFlag);
/* extern int86x(); */
/* extern segread(); */
/* extern int86(); */
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
int  tdoc_getstyles(unsigned int  theD,long  pos,short  *styles);
int  _TUTORinq_state_internal_marker(int  ind,long  *pos,long  *len,int  *altered);
int  assoc_name(struct  _fref FAR *fn,struct  _fref FAR *bfilen,char  *extnNew);
int  FindUnits(void);
#ifdef IBMPROTO
int _CDECL fclose(FILE *);
size_t _CDECL fwrite(const void *, size_t, size_t, FILE *);
FILE * _CDECL fopen(const char *, const char *);
#endif /* IBMPROTO */
#endif /* ctproto */

/* ******************************************************************** */

PrintEditDoc(et,dName) /* print source document */
TextVDat FAR *et; /* text view */
char *dName; /* name of document */

{   int uIndex; /* index in unit table */
    long up,ul; /* position, length of unit */
    long firstp; /* position of 1st char in unit */
    long nextp; /* position of next line in unit */
    int lineL; /* length of current line */
    int ci; /* index in print buffer */
    int nTotalLines; /* total number of lines to print */
    int fwl,errf; /* error flags */
    FileRef pfilen; /* listing file name */
    short styles[NSTYLES]; /* style flags */
    FILE *pfile; /* listing file */
    long pBuffL; /* length of data in print buffer */
    char pBuff[1002]; /* print buffer */
    char *cP; /* pointer in buffer */
    int cL; /* length in buffer */
    int toDo; /* number of units to do */

    /* locate units, open list file */

#ifdef CTEDIT
    toDo = 1;
#else
    FindUnits();
    if (nunits<0)
        return; /* unit setup failed */
    toDo = nunits+1;
#endif
    assoc_name(&sourcetable[0].fRef,(FileRef FAR *) &pfilen, ".lst");
    pfile = fopen(&pfilen.path[pfilen.nameInd],"w");
    if (pfile == NULL)
		return(FALSE); /* failed to open listing file */

    /* output to list file, unit-by-unit */

    errf = FALSE; /* no error yet */
    pBuffL = 1000;
    for(uIndex=0; (uIndex<toDo) && (!errf); uIndex++) {
        /* print only units in main file */
#ifdef CTEDIT
	up = 0;
	ul = TUTORget_len_doc(source);
	if (TRUE) {
#else
	if ((unittab[uIndex].beginfile == 0) && (unittab[uIndex].marki >= 0)) {
	    	_TUTORinq_state_internal_marker(unittab[uIndex].marki,&up,&ul,NEARNULL);
#endif

            /* determine if unit hidden */

	    	lineL = get_line_doc(source,up,pBuff,(int)pBuffL,&firstp);
	    	if (tdoc_getstyles(source,firstp,styles)) {
				if (styles[PARASTYLE] & VISMASK) {
		    		fwl = fwrite(pBuff,1,lineL,pfile); /* print unit command */
		    		if (!fwl) errf = TRUE;
		    		fwl = fwrite(" -------\n",1,9,pfile);
		    		if (!fwl) errf = TRUE;
		    		ul = -1; /* skip rest of unit */
				} /* styles if */
	    	} /* getstyles if */

	    	/* output body of unit */

            while ((ul > 0) && !errf) {
				lineL = get_line_doc(source,up,pBuff,(int)pBuffL,&nextp);
				fwl = fwrite(pBuff,1,lineL,pfile);
				if (!fwl) errf = TRUE;
				ul -= nextp-up; /* decrement length */
				up = nextp;
            } /* ul while */
        } /* beginfile if */
    } /* uIndex for */
    fprintf(pfile,"\n");
    nTotalLines++;
    fclose(pfile); /* close listing file */

	strcpy(pBuff,pprntr); /* copy print command */
	strcat(pBuff,&pfilen.path[pfilen.nameInd]); /* append file name */
	TUTORtrace(pBuff);
    system2(pBuff,TRUE);

} /* PrintEditDoc */

/* ******************************************************************* */

int get_line_doc(Doc,Pos,Buff,BuffL,endPos) /* get next line, convert tabs  */
Memh Doc; /* handle on source document */
long Pos; /* starting position */
char *Buff; /* buffer to fill */
int BuffL; /* maximum length */
long *endPos; /* ending position */

{   int cc; /* current character */
    int len; /* length read */
    int nextTab; /* position of next tab stop */

    nextTab = prfP->nTabs;
    len = 0;
    do {
		if (len == nextTab)
	    	nextTab += prfP->nTabs;
		cc = TUTORcharat_doc(Doc,Pos++);
		if (cc == '\t') {
	    	while ((len < nextTab) && (len < (BuffL-1)))
			Buff[len++] = ' ';
		} else {
	    	Buff[len++] = cc;
		}
    } while ((len < BuffL-1) && (cc != NEWLINE));
    Buff[len] = 0;
    *endPos = Pos;
    return(len);

} /* get_line_doc */

/* ******************************************************************* */

int PrintDoc(doc,pos,len)
Memh doc; /* document to print from */
long pos; /* starting position */
long len; /* length */

{
	return(FILENOTSUP);
	
} /* PrintDoc */

/* ******************************************************************* */

int TUTORprint_dialog(wix,type)
int wix; /* window index */
int type; /* 0 = page setup, 1 = print dialog */

{
	return(-1);
	
} /* TUTORprint_dialog */

/* ******************************************************************* */
