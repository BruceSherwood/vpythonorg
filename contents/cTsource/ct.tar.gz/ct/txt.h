
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#ifndef _txth
#define _txth

#include "tutor.h"

#ifdef CTDEBUG
/* #define DOCVERIFY */
#endif

#define DOCVERIFY

/* paragraph layout structure */

typedef struct _paral
	{
	/* all these elements are measured in pixels */
	short tabSize;	/* size of tab */
	short leftMar;	/* left margin (offset from view left to text left) */
	short rightMar;	/* right margin */
	short paraIndent;	/* indent given to first line of paragraph */
	short extraLine;	/* not used (always 0) but used for double-spacing, etc. */
	} ParagraphLayout;
/* Note that the tab origin is at the leftMargin, not at the left edge of paragraph layout */


/* variables that should be in a global file, but are in txt0: */
extern ParagraphLayout defaultLayout;



/* we guarantee alignment on all these structures by ending them with a long */

/* text block structure.  There is one of these per text block in a document */
typedef struct _tblk
	{
	long tLen;		/* length of text */
	Memh text;		/* actual text */
	long tExtra;		/* extra bytes in text handle */
	} TextBlock;

/* style types */
#define FONTSTYLE 0
#define SIZESTYLE 1
#define FACESTYLE 2
#define PARASTYLE 3
#define COLORSTYLE 4
#define HOTSTYLE 5
/* NSTYLES is defined in basic.h */

/* the amount of size change that is a "Bigger" */
#define BIGGERSIZE 20

/* justifications */
#define LEFTJUST 0
#define CENTERJUST 2
#define RIGHTJUST 4
#define FULLJUST 6

/* special face styles */
#define SUPERSTYLE 64
#define SUBSTYLE 32

/* We store an array of style CHANGES.  Note that the style structure should
	always have a Style1 block for every style at pos == 0 */

typedef struct _sty1
	{
	short dat;	/* the actual style.  contents depends on the style type */
	char type;	/* type of style, one of FONTSTYLE, SIZESTYLE, etc */
	char unused;
	long pos;	/* position (in doc) of this style change */
	} Style1;

typedef struct _pdt
	{
	unsigned short prevBlock;	/* index most recently accessed block */
	unsigned short nStyles[NSTYLES]; /* count of # of blocks for each style */
	unsigned short unused;
	Memh hotList;	/* handle to hot text info */
	long nArrays;	/* dynamic array stuff */
	long offsets;
	long totalSize;
	DArrayHeader sHead;		/* header for styles darray */
	Style1 styles[NSTYLES]; /* variable length array of style blocks */
	} StyleDat;

typedef StyleDat SHUGE *StyleDatP;
/* offset for darray operations: */
#define STYLEOFFSET ((NSTYLES+2)*sizeof(unsigned short) + sizeof(Memh))

typedef struct _ktd
	{
	/* associated objects */
	Memh self;		/* handle of self (so can get handle from pointer) */
	Memh styles;	/* text styles */
	Memh specialT;	/* special text (insets, etc.) */
	Memh editPanel;	/* head of edit panel chain */
	
	short defStyles[NSTYLES]; /* the document's default styles */

	/* flags */
	char changed;	/* TRUE if this document has been changed */
	char honorP;	/* honor paragraph boundaries on paragr styles (normally TRUE) */
	char updateM;	/* update markers */
	char unused1;	/* if TRUE bigger/smaller is done the old way */
	char shortText;	/* TRUE if all text is in text darray */
	char unused2;	/* fill for alignment */
	
	/* start & ending positions (relative to doc) of text that is currently in
		the text[] array.  For short documents buffStart will == 0, buffEnd
		will be == totLen */
	long buffStart, buffEnd;

	/* marker machinery */
	long nUsers;		/* number permanent marker variables on this doc */
	Memh prevd;			/* previous document in referenced list */
	Memh nextd;			/* next document in referenced list */
	long headM;			/* relative loc (in stack) of head of marker chain */
	Memh nextHandle;	/* handle containing head marker */
	Memh unitMark;		/* handle on array of markers on units */
	
	long totLen;		/*  total length of text */
	
	/* header for all darrays */
	long nArrays;		/* should always be 2 */
	long offsets[2];	/* offsets (in bytes) from begin of handle to header of each darray */
	long totalSize;		/* total size of the handle */
	
	/* text darray, the text that can be quickly accessed */
	DArrayHeader txtH;
	unsigned char text[100];		/* initial allocation */
	
	/* text block darray, for large documents, the text stored in seperate handles */
	DArrayHeader tBlockH;
	TextBlock tBlocks[1]; /* initial allocation */	
	} Document;

typedef Document FAR *DocP;

/* offset used for dynamic array calls */
extern int DOCOFFSET; /* DOCOFFSET ought to be a #define */

/* darray indices */
#define DOCTEXT 0
#define DOCTBLOCK 1

/* maximum length of string doc: */
#define MAXSTRINGLEN 15000
#define TBUFFLEN 1000

/* maximum length of a compare/search alias */
#define MAXALIASLEN 254

/* some style defines */
#define DEFSTYLE ((short) 0x8000)
#define VISMASK 1
#define JUSTMASK 6
#define PARALMASK 32760
#define PARADEFAULT 0x4000
#define ABSSIZE -32000

/* ---------------  special text definitions ---------------  */

/* there is one SText for every special text item */
typedef struct _stxt2
	{
	Memh dat;		/* data for special text */
	unsigned char type;		/* what kind of special character */
	char unused;
	long pos,len;	/* location of special text */
	} SText;

/* the special text (specialT field in doc) is a handle of SpecialT, which is mostly
	a dynamic array of SText */
typedef struct _spt2
	{
	Memh self;
	long nArrays;
	long offsets;
	long totalSize;
	DArrayHeader head;		/* header for styles darray */
	SText text[1]; /* variable length array */
	} SpecialT;
typedef SpecialT FAR *SpecialTP;
#define STOFFSET (sizeof(Memh))

/* special text types */
/* entries in mac2ct and ct2mac tables also needed */

#define BITMAPSPECIAL 134
#define PIXMAPSPECIAL 135
#define ICONSPECIAL 136
#define EQUATIONSPECIAL 137 /* followind are not implemented */
#define JAPANESESPECIAL 138
#define CHINESESPECIAL 139

/* data for laying out a line to draw it */
typedef struct _linelay
	{
	long nc;	/* # of characters in line */
	short nDraw;	/* # of characters to be drawn in line */
	short lastTab;	/* index of last tab (or -1 if none) */
	short justWidth;	/* amount to move pen for justification */
	short lineHeight;	/* height of full line */
	short lineAsc;		/* ascent for full line */
	char endNewline;	/* TRUE if this line ends in a newline */
	char justif;		/* justification of this line */
	short paraN;		/* ParagraphLayout index of this line */
	long fracShim;	/* fractional shim of line, 0 if not full justified */
	} LineLayout;

/* maximum # of lines we will lay out at once (also limit to # of lines of -text-, -write-, etc */
#define MAXLAYOUTLINES 200

/* hot list definitions */

/* structure (used as dynamic array) storing the information for each hot text item */
typedef struct _hot1
	{
	long pos;	/* location of special text in doc */
	short len;	/* length of the hot text info */
	short id;	/* unique id (for this document) */
	} HotL1;

typedef struct _hotlist
	{
	short nextid;	/* next id to assign */
	short unused;
	/* dynamic array stuff */
	long nArrays;
	long offsets[2];
	long totalSize;
	DArrayHeader listhead;		/* header for styles darray */
	HotL1 list[1];		/* variable length array */
	DArrayHeader texthead;
	unsigned char text[20];	/* all the hot text info strings */
	} HotList;

#define HOTOFFSET (2*sizeof(short))

/* dynamic array of paragraph layouts */
typedef struct _playa
	{
	long nArrays;
	long offsets;
	long totalSize;
	DArrayHeader pHead;
	ParagraphLayout layouts[1];
	} PLayoutTable;
#define LAYOUTOFFSET 0

/* variables (all declared in txt0) */
extern int DOCOFFSET; /* ought to be #define */
extern Memh plTable;	/* global paragraph layout table */
extern ParagraphLayout defaultLayout; /* can be seen outside!! */
extern int TxtMemErr; /* non-zero if out of memory in doc processing */

#endif
