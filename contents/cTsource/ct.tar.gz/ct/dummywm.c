
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#include "baseenv.h"

#ifdef X11
#define NOVIDEO
#endif

#ifndef WM
int winout;
int wm_CurrentFunction;
struct font *CurFont;
wmx11_dummy() { return(0); }
wm_FillTrapezoid() { return(0); }
#endif

#ifdef NOVIDEO
int movieInhibitF = 0;
int vid_kind = -1;
int movieCtrlH = 16;

int MovieControlRange() { return(0); }
int MovieLoop() { return(0); }
int MoviePaletteUse() { return(0); }
int MovieSupport() { return(0); }
int MovieStep() { return(0); }
int MovieShow() { return(0); }
int cmd_dma() { return(0); }
#endif

int pWinPos = 0;

int get_dde_ref() { return(0); }
int get_zddetext() { return(0); }
int TUTORclose_dde() { return(0); }
int set_last_dde() { return(0); }
int dde_event() { return(0); }
int cmd_dde() { return(0); }

long TUTORinq_sys_color() { return(0); }
TUTORload_palette() { return(0); }

initial_palette() { return(0); }
immediatePalette() { return(0); }
TUTORget_rgb_region() { return(0); }
CTuse_pix_palette() { return(0); }





