
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University. */

#include "execdefs.h"
#include "eglobals.h"
#include "tglobals.h"
/* #include "txt.h" */
#include "exprdefs.h"
#include "yacc.h"
#include "fkeys.h"
#include "editor.h"
#include "txtv.h"
#include "ct_ctype.h"
#include "commands.h"
 
/* ******************************************************************* */

#ifdef ctproto
extern int DebugAfterStep(int token);
long  TUTORget_len_doc(unsigned int  doc);
int  TUTORclear_doc(unsigned int  doc);
long TUTORfrom_clip_doc(Memh doc, long pos, long len, long mpos, long mlen, long *extraPos, int saveDo);
extern int TUTORto_clip_doc(Memh doc, long pos, long len, int doCut, long *extraPos); 
char FAR *cmdname(int  cmdn);
extern  Coord DivCoord(long xx,long yy);
extern int TUTORinq_mouse_xy(long *xx,long *yy);
extern char *TUTORget_user(void);
extern double MovieGetTime(void);
extern int TstIndefinite(double value);
extern int MovieInfo(int *ww,int *hh,double *ll,int *isplay);
extern int TUTORis_foreground(int wix);
extern double TUTORjdate(void);
extern char *TUTORdate(void);
extern char *TUTORtime(void);
extern double TUTORdouble_click_time(void);
extern int TUTORset_sub_new(int sub,int new);
extern int FullHalt(void);
char  FAR *strcatf(char  FAR *aa,char  FAR *bb);
int mvar_empty(void);
int  mvar_append(struct  markvar SHUGE *mx,struct  markvar SHUGE *my);
int  executor(void);
int  set_exec_pt(unsigned int  uloc);
long  get_exec_pt(void);
int  ex_val(void);
int  ex_ftoc(void);
int  ex_itoc(void);
int  ex_iliteral(void);
int  ex_fliteral(void);
int  ex_mliteral(void);
int  exs_mliteral(void);
int  ex_mlitc(void);
int  exs_mlitc(void);
int  ex_globalval(void);
int  ex_iglobalval(void);
int  ex_bglobalval(void);
int  ex_mglobalval(void);
int  exs_mglobalval(void);
int  exs_xglobalval(void);
int  ex_globaladdr(void);
int  ex_garrayval(void);
int  exs_garrayval(void);
int  ex_igarrayval(void);
int  exs_igarrayval(void);
int  ex_bgarrayval(void);
int  exs_bgarrayval(void);
int  ex_mgarrayval(void);
int  exs_mgarrayval(void);
int  ex_garrayaddr(void);
int  exs_garrayaddr(void);
int  ex_igarrayaddr(void);
int  exs_igarrayaddr(void);
int  ex_bgarrayaddr(void);
int  exs_bgarrayaddr(void);
int  ex_mgarrayaddr(void);
int  exs_mgarrayaddr(void);
int  ex_localval(void);
int  ex_ilocalval(void);
int  ex_blocalval(void);
int  ex_mlocalval(void);
int  exs_mlocalval(void);
int  exs_xlocalval(void);
int  ex_localaddr(void);
int  ex_larrayval(void);
int  exs_larrayval(void);
int  ex_ilarrayval(void);
int  exs_ilarrayval(void);
int  ex_blarrayval(void);
int  exs_blarrayval(void);
int  ex_mlarrayval(void);
int  exs_mlarrayval(void);
int  ex_larrayaddr(void);
int  exs_larrayaddr(void);
int  ex_ilarrayaddr(void);
int  exs_ilarrayaddr(void);
int  ex_blarrayaddr(void);
int  exs_blarrayaddr(void);
int  ex_mlarrayaddr(void);
int  exs_mlarrayaddr(void);
int  ex_passval(void);
int  ex_ipassval(void);
int  ex_bpassval(void);
int  ex_mpassval(void);
int  exs_mpassval(void);
int  exs_xpassval(void);
int  ex_passaddr(void);
int  ex_ipassaddr(void);
int  ex_bpassaddr(void);
int  ex_mpassaddr(void);
int  exs_mpassaddr(void);
int  ex_parrayval(void);
int  exs_parrayval(void);
int  ex_iparrayval(void);
int  exs_iparrayval(void);
int  ex_bparrayval(void);
int  exs_bparrayval(void);
int  ex_mparrayval(void);
int  exs_mparrayval(void);
int  ex_parrayaddr(void);
int  exs_parrayaddr(void);
int  ex_iparrayaddr(void);
int  exs_iparrayaddr(void);
int  ex_bparrayaddr(void);
int  ex_mparrayaddr(void);
int  exs_mparrayaddr(void);
int  ex_garray(void);
int  ex_larray(void);
int  ex_parray(void);
int  ex_iparray(void);
int  ex_bparray(void);
int  ex_mparray(void);
int  ex_xparray(void);
int  ex_assign(void);
int  ex_iassign(void);
int  ex_bassign(void);
int  ex_massign(void);
int  ex_plus(void);
int  ex_minus(void);
int  ex_uminus(void);
int  ex_iplus(void);
int  ex_iminus(void);
int  ex_iuminus(void);
int  ex_iinc(void);
int  ex_idec(void);
int  ex_times(void);
int  ex_itimes(void);
int  ex_divide(void);
int  ex_idivr(void);
int  ex_idivt(void);
int  ex_lunion(void);
int  ex_lmask(void);
int  ex_ldiff(void);
int  ex_lshift(void);
int  ex_rshift(void);
int  ex_itof(void);
int  ex_ftoi(void);
int  ex_munit(void);
int  ex_not(void);
int  ex_and(void);
int  ex_or(void);
int  ex_mod(void);
int  ex_exponic(void);
int  exs_exponic(void);
int  ex_exponent(void);
int  ex_arctan(void);
int  ex_arctan2(void);
int  ex_int(void);
int  ex_frac(void);
int  ex_round(void);
int  ex_sign(void);
int  ex_isign(void);
int  ex_comp(void);
int  ex_cot(void);
int  ex_csc(void);
int  ex_sec(void);
int  ex_arcsin(void);
int  ex_arccos(void);
int  ex_sqrt(void);
int  ex_log(void);
int  ex_ln(void);
int  ex_abs(void);
int  ex_exp(void);
int  ex_alog(void);
int  ex_sin(void);
int  ex_cos(void);
int  ex_tan(void);
int  ex_arccsc(void);
int  ex_arcsec(void);
int  ex_arccot(void);
int  ex_sinh(void);
int  ex_cosh(void);
int  ex_tanh(void);
int  ex_zlengthm(void);
int  ex_zposition(void);
int  ex_mcat(void);
int  ex_zcode(void);
int  ex_zchar(void);
int  ex_zfirst(void);
int  ex_zlast(void);
int  ex_zbase(void);
int  ex_znext(void);
int  ex_zprevious(void);
int  ex_zstart(void);
int  ex_zend(void);
int  ex_zcopy(void);
int  ex_zaltered(void);
int  ex_zextent(void);
int  ex_zsamemark(void);
int  ex_zsetmark(void);
int  ex_zprecede(void);
int  ex_ztextsel(void);
int  ex_ztextvis(void);
int  ex_zeditbase(void);
int  ex_zhotsel(void);
int  arg_ztextmarker(int  arg);
int  ex_zhotinfo(void);
int  ex_zvalueb(void);
int  ex_zvalues(void);
int  ex_zks(void);
int  ex_lt(void);
int  ex_gt(void);
int  ex_le(void);
int  ex_ge(void);
int  ex_eq(void);
int  ex_ne(void);
int  ex_splt(void);
int  exs_splt(void);
int  ex_spgt(void);
int  exs_spgt(void);
int  ex_sple(void);
int  exs_sple(void);
int  ex_spge(void);
int  exs_spge(void);
int  ex_speq(void);
int  exs_speq(void);
int  ex_spne(void);
int  exs_spne(void);
int  ex_ilt(void);
int  ex_igt(void);
int  ex_ile(void);
int  ex_ige(void);
int  ex_ieq(void);
int  ex_ine(void);
int  ex_txeq(void);
int  ex_txne(void);
int  ex_ispeq(void);
int  exs_ispeq(void);
int  ex_ispne(void);
int  exs_ispne(void);
int  ex_isplt(void);
int  exs_isplt(void);
int  ex_ispgt(void);
int  exs_ispgt(void);
int  ex_isple(void);
int  exs_isple(void);
int  ex_ispge(void);
int  exs_ispge(void);
int  ex_mlt(void);
int  ex_mgt(void);
int  ex_mle(void);
int  ex_mge(void);
int  ex_meq(void);
int  ex_mne(void);
int  ex_msplt(void);
int  exs_msplt(void);
int  ex_mspgt(void);
int  exs_mspgt(void);
int  ex_msple(void);
int  exs_msple(void);
int  ex_mspge(void);
int  exs_mspge(void);
int  ex_mspeq(void);
int  exs_mspeq(void);
int  ex_mspne(void);
int  exs_mspne(void);
int  ex_ibrancht(void);
int  ex_ibranchf(void);
int  ex_cbrancht(void);
int  ex_cbranchf(void);
int  ex_ubranch(void);
int  ex_sysvar(void);
int  exs_sysvar(void);
int  ex_msysvar(void);
int  exs_msysvar(void);
int  ex_msysvara(void);
int  exs_msysvara(void);
int  ex_efunct(void);
int  exs_efunct(void);
int  ex_storinf(void);
int  exs_storinf(void);
int  exs_floatinit(void);
int  ex_tkeyword(void);
int  ex_textarg(void);
int  ex_textarg1(void);
int  ex_ulocaddr(void);
int  exs_storeaddr(void);
int  ex_arrayerr(void);
extern long  array_index(long  idescp);
extern int  global_array_inf(void);
extern int  local_array_inf(void);
extern int  pass_array_inf(void);
extern int  exs_pass_array_inf(void);
long  l_bin(void);
double  f_bin(void);
long  l_read(char  FAR *addr);
double  f_read(char  FAR *addr);
int  n_follow(int  branchtype);
extern int  mvar_stack(long  addr);
int  mvar_init(struct  markvar SHUGE *mp);
int  mvar_zero(struct  markvar SHUGE *mp);
int  mvar_assign(struct markvar SHUGE *vaddr,struct  markvar SHUGE *mx);
int  mvar_compare(struct  markvar SHUGE *ma,struct  markvar SHUGE *mb,int  exact);
double  lcfexpon(double  y,double  x);
long  IntToCoord(int  xx);
int  RoundCoord(long  xx);
int  TUTORdump(char  *s);
int  TUTORtrace(char  *s);
int  flush(void);
int  TUTORflush(void);
int  ReleaseStack(void);
int  mvar_temp_cleanup(void);
int  killptr(char  FAR * FAR *ptr);
int  ReleasePtr(unsigned int  mm);
int  TUTORset_view(struct  tutorview FAR *vp);
int  InsureUnit(int  unitn);
unsigned char  SHUGE *LockStack(void);
int  InsertString(unsigned int  theD,long  pos,char  FAR *sP,long  sLen);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
long  FloatToCoord(double  zz);
int  execerr(char  *msgstr);
int  matherror(int  errnum,char  *s);
int  MatchUnitName(unsigned char  *name);
long  lcftoi(double  dv);
double  lcitof(long  iv);
extern double floor(double x);
extern double atan2(double x, double y);
extern double atan(double x);
extern double log10(double x);
extern double sqrt(double x);
int  fuzzyeq(double  x,double  y);
extern double acos(double x);
extern double fabs(double x);
extern double asin(double x);
extern double cos(double x);
extern double sin(double x);
extern double tan(double x);
extern double tanh(double x);
extern double cosh(double x);
extern double sinh(double x);
extern double pow(double x,double y);
extern double exp(double x);
extern double log(double x);
int  mvar_get_inf(unsigned int  docH,long  *len,long  *users,long  *head);
int  TUTORinsert_string_doc(unsigned int  doc,long  pos,unsigned char  FAR *ss,long  sLen);
int  scoderr(void);
int  TUTORcharat_doc(unsigned int  doc,long  pos);
unsigned int  mvar_new(int  ref);
int  _TUTORload_buffer_doc(struct  _ktd FAR *dp,long  pos);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
char  FAR *GetPtr(unsigned int  mm);
int  _TUTORinfo_vbar_tview(struct  _viewp FAR *tvp,struct  _sbarinf *vb);
int  TUTORinq_select_tview(unsigned int  theV,long  *pos,long  *len);
int  TUTORdealloc(char  FAR *ptr);
int  strlenf(char  FAR *aa);
char  FAR *CTzks(int  code,char  *tempS);
unsigned char  FAR *GetHotstringTStyle(unsigned int  pd,int  id,long  *len,long  *spos,long  *slen,int  getS);
int  fuzzyle(double  x,double  y);
int  fuzzygt(double  x,double  y);
int  fuzzylt(double  x,double  y);
int  fuzzyge(double  x,double  y);
int  fuzzyne(double  x,double  y);

int  TUTORtrace_n(char  *s,long  nn);
double  CoordToFloat(long  xx);
long  TUTORinq_msec_clock(void);
int  GetUnitName(int  unitn,unsigned char  *name);
extern char *TUTORgetenv(char *varname);

int  TUTORshowt(double  value,int  nBefore,int  nAfter,int  showperiod,char  *s);
int  TUTORshow(int type,double  value,int  sigfig,char  *ss);
int  shouldint(void);
int  mvar_attach_doc(struct  markvar SHUGE *mvarP,unsigned int  docH,unsigned char  SHUGE *stackP);
int  mvar_detach_doc(struct  markvar SHUGE *mvarP,unsigned int  docH,unsigned char  SHUGE *stackP);
extern int TUTORzero(char SHUGE *ptr,long lth);
int  TUTORfree_handle(unsigned int  mm);
int  _TUTORcmp_doc(struct  _ktd FAR *dp,long  pos0,long  dLen0,long  *docUsed,unsigned char  FAR *ss,long  ssGood,long  *cLen0,unsigned int  strSpecial,long  strSOff,unsigned char  FAR *cTable,int  exactF);
#ifdef IBMPROTO
int _CDECL sprintf(char *, const char *, ...);
#endif /* IBMPROTO */
#endif /* ctproto */

#ifdef macproto
extern int MacFilePath(FileRef *fR,char *str,int len);
extern int sprintf(char *ss, char *form,...);
extern int printf(char *form,...);
#endif

#ifndef WERKS
extern double atan2();
extern double sin(), cos(), tan(), asin(), acos(), atan();
extern double fabs(), sqrt(), exp(), pow(), log10(), log();
extern double alog(), sinh(), cosh(), tanh();
#endif

extern double TUTORdouble_click_time();
extern double TUTORjdate();
extern char FAR *TUTORalloc();
extern char FAR *CTzks();
extern long l_bin();
extern long l_read();
extern double f_bin();
extern double f_read();
extern long array_index();
extern double CoordToFloat();
extern long pass_addr();
extern Coord IntToCoord();
extern Coord FloatToCoord();
extern int TUTORcharat_doc();
extern long array_index();
extern long lcftoi();
extern double lcitof();
extern double floor();
extern  double lcfexpon();
extern double atan();
extern double fabs();
extern Memh mvar_new();
extern char *TUTORgetenv();
extern double MovieGetTime();
extern char *TUTORget_user();

/* ******************************************************************* */

#ifndef long_align
#define long_bin (*((long FAR *)(ex_binP)))
#define long_read(addr) (*(long SHUGE *)(addr))
#define flt_bin (*((double FAR *)(ex_binP)))
#define flt_read(addr) (*(double SHUGE *)(addr))
#else
#define long_bin (l_bin())
#define long_read(addr) (l_read(addr))
#define flt_bin (f_bin())
#define flt_read(addr) (f_read(addr))
#endif

#define IHUGE 0x7fffffff
#define abstolerance 0.000000001
#define reltolerance 0.00000000001
#define onep 1.0

extern int moviePlayingF;

/* ******************************************************************* */

int logcmd = 0;
long execInter = 0;
  
executor()

{   int token; /* current command / operator */
	
#ifdef THINKC5
    int (*funcp)(void);
#else
    register int (FAR *funcp)();
#endif
    
    if (pcodeh) {
        ReleasePtr(pcodeh);
        KillPtr(pcodep);
    }
    pcodeh = 0;
    if (runflag == halt) return(0);
	if (modalW != -1)
		TUTORdump("executor invoked during dialog");
    LockStack(); /* insure stack pinned */
    InsureUnit(exS.execunit); /* insure unit is in memory */

    TUTORset_view(exS.baseView);

    /* main execution loop */

    execrun = TRUE;
    exS.docounter = exS.loopcounter =  
    exS.shouldint = exS.outcnt = 0;

    iresP = istack; /* set up pointers in int, float, mark stacks */
    fresP = fstack;
    markP = markstack;
    ex_binP = (short FAR *)(&pcodep[exS.uloc]);
    do {
#ifdef NOSUCH
        if (logcmd) {
	    	sprintf(msg,"code: %d ",*ex_binP);
	    	GetUnitName(exS.execunit,(unsigned char *)(msg+strlen(msg)));
	    	strcat(msg," ");
	    	strcatf((char FAR *)msg,cmdname(*ex_binP));
            TUTORtrace(msg);
        }
#endif

		/* execute next command or function */
	
		token = *ex_binP++;
        funcp = exs_addr[token];
        (*funcp)();
    	if (exS.stepMode) {
    		if (token >= C_MIN) {
    			DebugAfterStep(token);
    		}
    	}        
    } while (execrun);
execInter++;
    exS.uloc = ((unsigned char FAR *)(ex_binP))-pcodep;
    if (pcodeh) { /* release current unit */
        ReleasePtr(pcodeh);
        KillPtr(pcodep);    
    }
    pcodeh = 0;
    mvar_temp_cleanup(); /* release any temporary markers */
    ReleaseStack(); /* un-pin stack */
    TUTORflush();
    flush();
    TUTORset_sub_new(-1,0);

	/* check if quit running menu has been selected */
	
	if (exS.ExecQuit) {
		if ((TUTORinq_msec_clock()-exS.ExecQuitTime) > 1000L)
			FullHalt();
	}
	
} /* executor */

/* ------------------------------------------------------------------- */

set_exec_pt(uloc) /* set execution point (relative and absolute) */
unsigned int uloc; /* relative execution address */

{
    exS.uloc = uloc; /* set relative position */
    ex_binP = (short FAR *)(&pcodep[uloc]); /* set absolute */

} /* set_exec_pt */

/* ------------------------------------------------------------------- */

long get_exec_pt() /* return current execution point (relative) */

{
    return(((unsigned char FAR *)(ex_binP))-pcodep);

} /* get_exec_pt */

/* ------------------------------------------------------------------- */

ex_val() /* return code as integer value */

{
    *iresP++ = *(ex_binP-1);

} /* ex_val */

/* ------------------------------------------------------------------- */

ex_ftoc() /* floating-to-coordinate conversion */

{
    *iresP++ = FloatToCoord(*(--fresP));

} /* ex_ftoc */

/* ------------------------------------------------------------------- */

ex_itoc() /* integer-to-coordinate conversion */

{
    *(iresP-1) = IntToCoord((int)(*(iresP-1)));

} /* ex_itoc */

/* ------------------------------------------------------------------- */

ex_iliteral() /* integer literal */

{   
    *iresP++ = long_bin;  
    ex_binP += 2;

} /* ex_iliteral */

/* ------------------------------------------------------------------- */

ex_fliteral() /* floating literal */

{ 
    *fresP++ = flt_bin;
    ex_binP += sizeof(double)/sizeof(short);

} /* ex_fliteral */

/* ------------------------------------------------------------------- */

ex_mliteral() /* string literal */

{   
    *iresP++ = long_bin; /* get relative addr of text */
    ex_binP += 2;
    exs_mliteral();

} /* ex_mliteral */
    
/* ------------------------------------------------------------------- */

exs_mliteral() /* string literal */
               /* compiled code callable form */

{   register long textix; /* index of text in text pool */
    register long sl; /* length of string */
    long extraDumm;
    unsigned char ss[4];

    textix = *(--iresP)+unittab[exS.execunit].textp;
    TUTORget_string_doc(textpool,textix,2L,ss);
    sl = ss[0]-' ';
    sl = (sl << 6)+(ss[1]-' ');
    textix += 2;

    mvar_init(markP); /* initialize new temp marker */

    /* extract text from text pool to marker document */

    TUTORchange_doc_doc(markP->doc,0L,0L,0L,0L,textpool,textix,sl,&extraDumm,FALSE);
    markP->pos = 0L;
    markP->len = markP->doclen = sl;
    markP++; /* advance marker stack */

} /* exs_mliteral */

/* ------------------------------------------------------------------- */

ex_mlitc() /* optimized (unstyled) string literal */

{   long slen;
    char FAR *cp;

    slen = *ex_binP++; /* get length of string */
    *iresP++ = (long)ex_binP; /* set address of string */
    *iresP++ = slen; /* set length of string */
    if (slen & 1) slen++; /* round to word boundary */
    cp = ((char FAR *)ex_binP)+slen;
    ex_binP = (short FAR *)cp; /* update binary ptr */
    exs_mlitc(); /* set up string literal */

} /* ex_mlitc */

/* ------------------------------------------------------------------- */

exs_mlitc() /* optimized (unstyled) string literal */
            /* compiled code callable form */

{   long slen; /* length of string */
    char FAR *strp;

    slen = *(--iresP); /* get length of string */
    strp = (char FAR *)(*--iresP); /* get address of string */

    mvar_init(markP); /* initialize new temp marker */
    InsertString(markP->doc,0L,strp,slen);
    markP->pos = 0; /* wrap marker around string */
    markP->len = markP->doclen = slen;
    markP++; /* advance marker stack */

} /* exs_mlitc */

/* ------------------------------------------------------------------- */

ex_globalval() /* process floating global variable value */

{
    *fresP++ = flt_read(exS.stackP+long_bin);
    ex_binP += 2;

} /* ex_globalval */

/* ------------------------------------------------------------------- */

ex_iglobalval() /* process integer global variable value */

{
    *iresP++ = *(long FAR *)(exS.stackP+long_bin);
    ex_binP += 2;

} /* ex_iglobalval */

/* ------------------------------------------------------------------- */

ex_bglobalval() /* byte global variable value */

{
    *iresP++ = *(exS.stackP+long_bin);
    ex_binP += 2;

} /* ex_bglobalval */

/* ------------------------------------------------------------------- */

ex_mglobalval() /* marker global variable */

{
    store_addr = (long)(exS.stackP+long_bin);
    ex_binP += 2;
    mvar_stack(store_addr);

} /* ex_mglobalval */

/* ------------------------------------------------------------------- */

exs_mglobalval() /* marker global variable */
                 /* compiled code call-able version */

{
    store_addr = (long)(exS.stackP+*(--iresP));
    mvar_stack(store_addr);

} /* exs_mglobalval */

/* ------------------------------------------------------------------- */

exs_xglobalval() /* file,bitmap, etc global variable */
                 /* compiled code call-able version */
                 
{
    store_addr = (long)(exS.stackP+*(--iresP));
    *iresP++ = *(long FAR *)(store_addr);
    
} /* exs_xglobalval */
           
/* ------------------------------------------------------------------- */

ex_globaladdr() /* address of floating global variable */

{   
    *iresP++ = (long)(exS.stackP+long_bin);
    ex_binP += 2;

} /* ex_globaladdr */

/* ------------------------------------------------------------------- */

ex_garrayval() /* value of floating global array item */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_garrayval();

} /* ex_garrayval */

/* ------------------------------------------------------------------- */

exs_garrayval() /* value of floating global array item */
                /* compiled code call-able version */

{   register long rel;

    rel = *(--iresP);
    store_addr = array_index(rel);
    *fresP++ = flt_read(store_addr);

} /* exs_garrayval */

/* ------------------------------------------------------------------- */

ex_igarrayval() /* value of integer global array item */

{   
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_igarrayval();

} /* ex_igarrayval */

/* ------------------------------------------------------------------- */

exs_igarrayval() /* value of integer global array item */
                 /* compiled code call-able version */

{   register long rel;

    rel = *(--iresP);
    store_addr = array_index(rel);
    *iresP++ = long_read(store_addr);

} /* exs_igarrayval */

/* ------------------------------------------------------------------- */

ex_bgarrayval() /* value of byte global array item */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_bgarrayval();

} /* ex_bgarrayval */

/* ------------------------------------------------------------------- */

exs_bgarrayval() /* value of byte global array item */
                 /* compiled code call-able version */

{   register long rel;

    rel = *(--iresP);
    store_addr = array_index(rel);
    *iresP++ = *(unsigned char FAR *)(store_addr);

} /* exs_bgarrayval */

/* ------------------------------------------------------------------- */

ex_mgarrayval() /* value of marker global array item */

{   
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_mgarrayval();

} /* ex_mgarrayval */

/* ------------------------------------------------------------------- */

exs_mgarrayval() /* value of marker global array item */
                 /* compiled code call-able version */
{   register long rel;

    rel = *(--iresP); /* relative address of array */
    store_addr = array_index(rel);
    mvar_stack(store_addr);

} /* exs_mgarrayval */

/* ------------------------------------------------------------------- */

ex_garrayaddr() /* address of floating global array item */

{   
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_garrayaddr();
        
} /* ex_garrayaddr */

/* ------------------------------------------------------------------- */

exs_garrayaddr() /* address of floating global array item */
                 /* compiled code call-able form */

{   register long rel; /* relative address */
    
    rel = *(--iresP);
    store_addr = array_index(rel);
    *iresP++ = store_addr; /* push addr to assign into */
        
} /* exs_garrayaddr */

/* ------------------------------------------------------------------- */

ex_igarrayaddr() /* address of integer global array item */

{   
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_igarrayaddr();
        
} /* ex_igarrayaddr */

/* ------------------------------------------------------------------- */

exs_igarrayaddr() /* address of integer global array item */
                  /* compiled code call-able version */

{   register long rel; /* relative address */
    register long vv; /* value to be assigned */

    rel = *(--iresP);
    vv = *(--iresP); /* pop value to be assigned */
    store_addr = array_index(rel);
    *iresP++ = vv; /* restore value to be assigned */
    *iresP++ = store_addr; /* push addr to assign into */
        
} /* exs_igarrayaddr */

/* ------------------------------------------------------------------- */

ex_bgarrayaddr() /* address of byte global array item */

{   
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_bgarrayaddr();
        
} /* ex_bgarrayaddr */

/* ------------------------------------------------------------------- */

exs_bgarrayaddr() /* address of byte global array item */

{   register long rel; /* relative address */
    register long vv; /* value to be assigned */

    rel = *(--iresP); /* relative address */
    vv = *(--iresP); /* pop value to be assigned */
    store_addr = array_index(rel);
    *iresP++ = vv; /* restore value to be assigned */
    *iresP++ = store_addr; /* push addr to assign into */
        
} /* exs_bgarrayaddr */

/* ------------------------------------------------------------------- */

ex_mgarrayaddr() /* address of byte global array item */

{   
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_mgarrayaddr();
        
} /* ex_mgarrayaddr */

/* ------------------------------------------------------------------- */

exs_mgarrayaddr() /* address of byte global array item */

{   register long rel;

    rel = *(--iresP);
    store_addr = array_index(rel);
    *iresP++ = store_addr; /* push addr to assign into */
        
} /* exs_mgarrayaddr */

/* ------------------------------------------------------------------- */

ex_localval() /* floating local variable value */

{
    store_addr = (long)(exS.stackP+exS.lvars+long_bin);
    ex_binP += 2;
    *fresP++ = flt_read(store_addr);

} /* ex_localval */


/* ------------------------------------------------------------------- */

ex_ilocalval() /* integer local variable value */

{
    *iresP++ = *(long FAR *)((long)(exS.stackP+exS.lvars+long_bin));
    ex_binP += 2;

} /* ex_ilocalval */

/* ------------------------------------------------------------------- */

ex_blocalval() /* byte local variable value */

{
    *iresP++ = *(exS.lvarP+long_bin);
    ex_binP += 2;

} /* ex_blocalval */

/* ------------------------------------------------------------------- */

ex_mlocalval() /* marker local variable value */

{   
    /* address of marker variable */
    store_addr = (long)(exS.stackP+exS.lvars+long_bin);
    ex_binP += 2;
    mvar_stack(store_addr);

} /* ex_mlocalval */

/* ------------------------------------------------------------------- */

exs_mlocalval() /* marker local variable value */
                /* compiled code call-able version */

{   
    /* address of marker variable */
    store_addr = (long)(exS.stackP+exS.lvars+*(--iresP));
    mvar_stack(store_addr);

} /* exs_mlocalval */

/* ------------------------------------------------------------------- */

exs_xlocalval() /* file, bitmap, etc local variable value */
                /* compiled code call-able version */
                
{
    store_addr = (long)(exS.stackP+exS.lvars+*(--iresP));
    *iresP++ = *(long FAR *)(store_addr);
    
} /* exs_xlocalval */
             
/* ------------------------------------------------------------------- */

ex_localaddr() /* address of floating local variable */

{
    *iresP++ = store_addr = (long)(exS.stackP+exS.lvars+long_bin);
    ex_binP += 2;

} /* ex_localaddr */

/* ------------------------------------------------------------------- */

ex_larrayval() /* value of floating local array item */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_larrayval();

} /* ex_larrayval */

/* ------------------------------------------------------------------- */

exs_larrayval() /* value of floating local array item */
                /* compiled code call-able version */

{   register long rel;

    rel = *(--iresP);
    store_addr = array_index(exS.lvars+rel);
    *fresP++ = flt_read(store_addr);

} /* exs_larrayval */

/* ------------------------------------------------------------------- */

ex_ilarrayval() /* value of integer local array item */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_ilarrayval();

} /* ex_ilarrayval */

/* ------------------------------------------------------------------- */

exs_ilarrayval() /* value of integer local array item */
                 /* compiled code call-able version */
{   register long rel;

    rel = *(--iresP);
    store_addr = array_index(exS.lvars+rel);
    *iresP++ = long_read(store_addr);

} /* exs_ilarrayval */

/* ------------------------------------------------------------------ */

ex_blarrayval() /* value of byte local array item */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_blarrayval();

} /* ex_blarrayval */

/* ------------------------------------------------------------------ */

exs_blarrayval() /* value of byte local array item */
                 /* compiled code call-able version */

{   register long rel;

    rel = *(--iresP);
    store_addr = array_index(exS.lvars+rel);
    *iresP++ = *(unsigned char FAR *)(store_addr);

} /* exs_blarrayval */

/* ------------------------------------------------------------------- */

ex_mlarrayval() /* value of marker local array item */

{
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_mlarrayval();

} /* ex_mlarrayval */

/* ------------------------------------------------------------------- */

exs_mlarrayval() /* value of marker local array item */
                 /* compiled code call-able version */
{   register long rel;

    rel = *(--iresP);
    store_addr = array_index(exS.lvars+rel);
    mvar_stack(store_addr);

} /* exs_mlarrayval */

/* ------------------------------------------------------------------- */

ex_larrayaddr() /* address of floating local array item */

{   
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_larrayaddr();
        
} /* ex_larrayaddr */

/* ------------------------------------------------------------------- */

exs_larrayaddr() /* address of floating local array item */
                 /* compiled code call-able version */
{   register long rel;
    
    rel = *(--iresP);
    store_addr = array_index(exS.lvars+rel);
    *iresP++ = store_addr; /* push addr to assign into */
        
} /* exs_larrayaddr */

/* ------------------------------------------------------------------- */

ex_ilarrayaddr() /* address of integer local array item */

{   
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_ilarrayaddr();
    
} /* ex_ilarrayaddr */

/* ------------------------------------------------------------------- */

exs_ilarrayaddr() /* address of integer local array item */
                  /* compiled code call-able version */

{   register long rel; /* relative address */
    register long vv; /* value to be assigned */

    rel = *(--iresP);
    vv = *(--iresP); /* pop value to be assigned */
    store_addr = array_index(exS.lvars+rel);
    *iresP++ = vv; /* restore value to be assigned */
    *iresP++ = store_addr; /* push addr to assign into */
        
} /* exs_ilarrayaddr */

/* ------------------------------------------------------------------- */

ex_blarrayaddr() /* address of byte local array item */

{   
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_blarrayaddr();
        
} /* ex_blarrayaddr */

/* ------------------------------------------------------------------- */

exs_blarrayaddr() /* address of byte local array item */
                  /* compiled code call-able version */

{   register long rel; /* relative address */
    register long vv; /* value to be assigned */

    rel = *(--iresP);
    vv = *(--iresP); /* pop value to be assigned */
    store_addr = array_index(exS.lvars+rel);
    *iresP++ = vv; /* restore value to be assigned */
    *iresP++ = store_addr; /* push addr to assign into */
        
} /* exs_blarrayaddr */

/* ------------------------------------------------------------------- */

ex_mlarrayaddr() /* address of marker local array item */

{   
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_mlarrayaddr();
        
} /* ex_mlarrayaddr */

/* ------------------------------------------------------------------- */

exs_mlarrayaddr() /* address of marker local array item */

{   register long rel;

    rel = *(--iresP);
    store_addr = array_index(exS.lvars+rel);
    *iresP++ = store_addr; /* push addr to assign into */
        
} /* exs_mlarrayaddr */

/* ------------------------------------------------------------------- */

ex_passval() /* floating pass-by-address value */

{
    store_addr = *(long SHUGE *)(exS.lvarP+long_bin);
    ex_binP += 2;
    store_addr = (long)(exS.stackP+store_addr);
    *fresP++ = flt_read(store_addr);

} /* ex_passval */

/* ------------------------------------------------------------------- */

ex_ipassval() /* integer pass-by-address value */

{   
    store_addr = *(long SHUGE *)(exS.lvarP+long_bin);
    ex_binP += 2;
    store_addr = (long)(exS.stackP+store_addr);
    *iresP++ = *(long FAR *)(store_addr);

} /* ex_ipassval */

/* ------------------------------------------------------------------- */

ex_bpassval() /* byte pass-by-address value */

{
    store_addr = *(long SHUGE *)(exS.lvarP+long_bin);
    ex_binP += 2;
    store_addr = (long)(exS.stackP+store_addr);
    *iresP++ = *(unsigned char FAR *)(store_addr);

} /* ex_passval */

/* ------------------------------------------------------------------- */

ex_mpassval() /* marker pass-by-address value */

{
    store_addr = *(long SHUGE *)(exS.lvarP+long_bin);
    ex_binP += 2;
    store_addr = (long)(exS.stackP+store_addr);
    mvar_stack(store_addr);

} /* ex_mpassval */

/* ------------------------------------------------------------------- */

exs_mpassval() /* marker pass-by-address value */
               /* compiled code call-able version */
{   register long rel;

    rel = *(--iresP); /* pop relative address */
    store_addr = *(long SHUGE *)(exS.lvarP+rel);
    store_addr = (long)(exS.stackP+store_addr);
    mvar_stack(store_addr);

} /* exs_mpassval */

/* ------------------------------------------------------------------- */

exs_xpassval() /* file, bitmap, etc pass-by-address value */
               /* compiled code call-able version */
               
{   long rel;

    rel = *(--iresP); /* pop relative address */
    store_addr = *(long SHUGE *)(exS.lvarP+rel);
    store_addr = (long)(exS.stackP+store_addr);
    *(iresP++) = *(long SHUGE *)(store_addr);
    
} /* exs_xpassval */
    
/* ------------------------------------------------------------------- */

ex_passaddr() /* address of floating pass-by-address variable */

{   register long vi;

    vi = long_bin;
    ex_binP += 2;
    *iresP++ = store_addr = (long)(exS.stackP+long_read(exS.lvarP+vi));

} /* ex_passaddr */

/* ------------------------------------------------------------------- */

ex_ipassaddr() /* address of integer pass-by-address variable */

{   register long vi;

    vi = long_bin;
    ex_binP += 2;
    *iresP++ = store_addr = (long)(exS.stackP+long_read(exS.lvarP+vi));

} /* ex_ipassaddr */

/* ------------------------------------------------------------------- */

ex_bpassaddr() /* address of byte pass-by-address variable */

{   register long vi;

    vi = long_bin;
    ex_binP += 2;
    *iresP++ = store_addr = (long)(exS.stackP+long_read(exS.lvarP+vi));

} /* ex_bpassaddr */

/* ------------------------------------------------------------------- */

ex_mpassaddr() /* address of marker pass-by-address variable */

{   register long vi;

    vi = long_bin;
    ex_binP += 2;
    *iresP++ = store_addr = (long)(exS.stackP+long_read(exS.lvarP+vi));

} /* ex_mpassaddr */

/* ------------------------------------------------------------------- */

exs_mpassaddr() /* address of marker pass-by-address variable */
                /* compiled code call-able version */
{   register long vi;

    vi = *(--iresP);
    *iresP++ = store_addr = (long)(exS.stackP+long_read(exS.lvarP+vi));

} /* exs_mpassaddr */

/* ------------------------------------------------------------------- */

ex_parrayval() /* floating pass-by-address array value */

{   
    *iresP++ = long_bin;
    ex_binP += 3;   
    exs_parrayval();

} /* ex_parrayval */

/* ------------------------------------------------------------------- */

exs_parrayval() /* floating pass-by-address array value */
                /* compiled code call-able version */
{   register long vi;

    vi = *(--iresP);
    store_addr = array_index(long_read(exS.lvarP+vi));
    *fresP++ = flt_read(store_addr);

} /* exs_parrayval */

/* ------------------------------------------------------------------- */

ex_iparrayval() /* integer pass-by-address array value */

{   
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_iparrayval();

} /* ex_iparrayval */

/* ------------------------------------------------------------------- */

exs_iparrayval() /* integer pass-by-address array value */
                 /* compiled code call-able version */
{   register long vi;

    vi = *(--iresP);
    store_addr = array_index(long_read(exS.lvarP+vi));
    *iresP++ = long_read(store_addr);

} /* exs_iparrayval */

/* ------------------------------------------------------------------- */

ex_bparrayval() /* byte pass-by-address array value */
        
{   
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_bparrayval();
        
} /* ex_bparrayval */

/* ------------------------------------------------------------------- */

exs_bparrayval() /* byte pass-by-address array value */
                 /* compiled code call-able version */
{   register long vi;

    vi = *(--iresP);
    store_addr = array_index(long_read(exS.lvarP+vi));
    *iresP++ = *(unsigned char SHUGE *)(store_addr);
        
} /* exs_bparrayval */

/* ------------------------------------------------------------------- */

ex_mparrayval() /* marker pass-by-address array value */

{   
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_mparrayval();
        
} /* ex_mparrayval */

/* ------------------------------------------------------------------- */

exs_mparrayval() /* marker pass-by-address array value */
                 /* compiled code call-able version */
{   register long vi;

    vi = *(--iresP);
    store_addr = array_index(long_read(exS.lvarP+vi));
    mvar_stack(store_addr);
        
} /* exs_mparrayval */

/* ------------------------------------------------------------------- */

ex_parrayaddr() /* floating pass-by-address array address */

{   
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_parrayaddr();
    
} /* ex_parrayaddr */

/* ------------------------------------------------------------------- */

exs_parrayaddr() /* floating pass-by-address array address */
                 /* compiled code call-able version */
{   register long vi;

    vi = *(--iresP); /* pop descriptor addr */
    store_addr = array_index(long_read(exS.lvarP+vi));
    *iresP++ = store_addr; /* push addr to assign into */
    
} /* exs_parrayaddr */

/* ------------------------------------------------------------------- */

ex_iparrayaddr() /* integer pass-by-address array address */

{   
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_iparrayaddr();
        
} /* ex_iparrayaddr */

/* ------------------------------------------------------------------- */

exs_iparrayaddr() /* integer pass-by-address array address */
                  /* compiled code call-able version */
{   register long ix; /* value to be assigned */
    register long vi;

    vi = *(--iresP); /* pop descriptor addr */
    ix = *(--iresP); /* pop value to be assigned */
    store_addr = array_index(long_read(exS.lvarP+vi));
    *iresP++ = ix; /* restore value to be assigned */
    *iresP++ = store_addr; /* push addr to assign into */
        
} /* exs_iparrayaddr */

/* ------------------------------------------------------------------- */

ex_bparrayaddr() /* byte pass-by-address array address */

{   
    ex_iparrayaddr();

} /* ex_bparrayaddr */

/* ------------------------------------------------------------------- */

ex_mparrayaddr() /* marker pass-by-address array address */

{   
    *iresP++ = long_bin;
    ex_binP += 3;
    exs_mparrayaddr();

} /* ex_mparrayaddr */

/* ------------------------------------------------------------------- */

exs_mparrayaddr() /* marker pass-by-address array address */
                  /* compiled code call-able version */
                  
{   register long vi;

    vi = *(--iresP);
    store_addr = array_index(long_read(exS.lvarP+vi));
    *iresP++ = store_addr; /* push addr to assign into */

} /* exs_mparrayaddr */

/* ------------------------------------------------------------------- */

ex_garray() /* entire floating global array */

{
    global_array_inf();

} /* ex_garray */

/* ------------------------------------------------------------------- */

ex_larray() /* entire floating local array */

{
    local_array_inf(); 

} /* ex_larray */

/* ------------------------------------------------------------------- */

ex_parray() /* entire floating pass-by-address array */

{   
    pass_array_inf();

} /* ex_parray */

/* ------------------------------------------------------------------- */

ex_iparray() /* entire integer pass-by-address array */

{
    pass_array_inf();

} /* ex_iparray */

/* ------------------------------------------------------------------- */

ex_bparray() /* entire byte pass-by-address array */

{
    pass_array_inf();

} /* ex_bparray */

/* ------------------------------------------------------------------- */

ex_mparray() /* entire marker pass-by-address array */

{
    pass_array_inf();

} /* ex_mparray */

/* ------------------------------------------------------------------- */

ex_xparray() /* entire integer pass-by-address array */

{
    pass_array_inf();

} /* ex_xparray */

/* ------------------------------------------------------------------- */

ex_assign() /* assign to floating variable */

{
    *((double FAR *)(*(--iresP))) = *(fresP-1);

} /* ex_assign */

/* ------------------------------------------------------------------- */

ex_iassign() /* assign to integer variable */

{
    iresP--;
    *((long FAR *)(*iresP)) = *(iresP-1);

} /* ex_iassign */

/* ------------------------------------------------------------------- */

ex_bassign() /* assign to byte variable */

{
    iresP--;
    *((unsigned char FAR *)(*iresP)) = *(iresP-1);

} /* ex_bassign */

/* ------------------------------------------------------------------- */

ex_massign() /* assign to marker variable */

{   struct markvar SHUGE *vaddr;
    register struct markvar SHUGE *mv;
    long extraPos;

    vaddr = (struct markvar SHUGE *)(*(--iresP)); /* variable */
    mv = (markP-1); /* marker to assign */
    mvar_assign(vaddr,mv);
    /* clear altered, compute and unit bits */
    vaddr->alteredF = vaddr->alteredF & (~7);
    if ((long)(vaddr) == (long)(exS.stackP)+2*sizeof(struct markvar)) { /* ZCLIPBOARD */
    	if (mv->doc) 
    		TUTORto_clip_doc(mv->doc,mv->pos,mv->len,0L,&extraPos); 
    }

} /* ex_massign */


/* ------------------------------------------------------------------- */

ex_plus() /* floating add */

{
    fresP--;
    *(fresP-1) += *fresP;

} /* ex_plus */

/* ------------------------------------------------------------------- */

ex_minus() /* floating subtract */

{
    fresP--;
    *(fresP-1) -= *fresP;

} /* ex_minus */

/* ------------------------------------------------------------------- */

ex_uminus() /* floating unary minus */

{
    *(fresP-1) = -(*(fresP-1));

} /* ex_uminus */

/* ------------------------------------------------------------------- */

ex_iplus() /* integer add */

{
    iresP--;
    *(iresP-1) += *iresP;

} /* ex_iplus */

/* ------------------------------------------------------------------- */

ex_iminus() /* integer subtract */

{
    iresP--;
    *(iresP-1) -= *iresP;

} /* ex_iminus */

/* ------------------------------------------------------------------- */

ex_iuminus() /* integer unary minus */

{
    *(iresP-1) = -(*(iresP-1));

} /* ex_iuminus */

/* ------------------------------------------------------------------- */

ex_iinc() /* increment by 1 */

{
    (*(iresP-1))++;

} /* ex_iinc */

/* ------------------------------------------------------------------- */

ex_idec() /* decrement by 1 */

{
    (*(iresP-1))--;

} /* ex_idec */

/* ------------------------------------------------------------------- */

ex_times() /* floating multiply */

{
    fresP--;
    *(fresP-1) *= *fresP;

} /* ex_times */

/* ------------------------------------------------------------------- */

ex_itimes() /* integer multiply */

{
    iresP--;
    *(iresP-1) *= *iresP;

} /* ex_times */

/* ------------------------------------------------------------------- */

ex_divide() /* floating divide */

{
    fresP--;
    if (*fresP == 0.0) {
        if (*(fresP-1) == 0.0)
            *(fresP-1) = Indefinite;
        else
            *(fresP-1) = Infinite; 
    } else *(fresP-1) /= *fresP;

} /* ex_divide */

/* ------------------------------------------------------------------- */

ex_idivr() /* integer divide, round */

{   double x,y;

    iresP--;
    if (*iresP == 0) /* divide by zero */
        *iresP = IHUGE;
    else {
        y = *iresP;
        x = *(iresP-1);
        *(iresP-1) = round(x/y);
    } /* else */

} /* ex_idivr */

/* ------------------------------------------------------------------- */

ex_idivt() /* integer divide, truncate */

{
    iresP--;
    if (*iresP == 0) /* divide by zero */
        *(iresP-1) = IHUGE;
    else *(iresP-1) /= *iresP;

} /* ex_idivt */

/* ------------------------------------------------------------------- */

ex_lunion() /* logical or */

{
    iresP--;
    *(iresP-1) |= *iresP;

} /* ex_lunion */

/* ------------------------------------------------------------------- */

ex_lmask() /* logical and */

{
    iresP--;
    *(iresP-1) &= *iresP;

} /* ex_lmask */

/* ------------------------------------------------------------------- */

ex_ldiff() /* exclusive or */

{
    iresP--;
    *(iresP-1) ^= *iresP;

} /* ex_ldiff */

/* ------------------------------------------------------------------- */

ex_lshift() /* left shift */

{
    iresP--;
    *(iresP-1) <<= (*iresP & 0x1f);
        
} /* ex_lshift */

/* ------------------------------------------------------------------- */

ex_rshift() /* right shift */

{
    iresP--;
    *(iresP-1) >>= *iresP & 0x1f;
        
} /* ex_rshift */

/* ------------------------------------------------------------------- */

ex_itof() /* integer-to-floating */

{	
	
	*fresP++ = lcitof(*(--iresP));

} /* ex_itof */

/* ------------------------------------------------------------------- */

ex_ftoi() /* floating-to-integer */

{   double x;
    register long ix;

#ifdef ibm032
    x = *(--fresP);
    if (x>=0.0) ix=(x+0.5); else ix=(x-0.5);
    *iresP++ = ix;
#else
    *iresP++ = lcftoi(*(--fresP));
#endif


} /* ex_ftoi */

/* ------------------------------------------------------------------- */

ex_munit()  /* convert marker to unit number */
    {
    register struct markvar SHUGE *mx;
    register struct markvar SHUGE *mv;
    unsigned char unitname[NAMEL+1];
    register int unitN;
    
    unitN = -1; /* assume some problem */
    mx = --markP;
    if (mx->alteredF & 4)
        { /* unit bit is set, just use unit number we already know */
        unitN = mx->unitNum;
        }
    else
        { /* we need to look up unit number */
        if (mx->len && mx->len <= NAMEL)
            {
            TUTORget_string_doc(mx->doc,mx->pos,mx->len,(unsigned char FAR *) unitname);
            if (unitname[0] != '*') /* we don't want to match "*ieu" */
                unitN = MatchUnitName(unitname);
            }
        
        if (unitN < 1)
            execerr("marker expression does not match unit name");
        
        /* put unit number in real marker variable */
        if ((long)(mx->vaddr) >= 0)
            {
            if (mx->vaddr > exS.stackmalloc)
                TUTORdump("bad marker address");
            mv = (struct markvar SHUGE *)(exS.stackP+mx->vaddr);
            mv->unitNum = unitN;
            mv->alteredF |= 4; /* set unit number flag */
            }
        }
    
    *iresP++ = unitN;
    }

/* ------------------------------------------------------------------- */

ex_not() /* logical not */

{

    *(iresP-1) = (*(iresP-1) < 0) ? 0 : -1;

} /* ex_not */

/* ------------------------------------------------------------------- */

ex_and() /* logical and */

{
    iresP--;
    *(iresP-1) = (*(iresP-1) < 0 && *iresP < 0) ? -1 : 0;
 
} /* ex_and */

/* ------------------------------------------------------------------- */

ex_or() /* logical or */

{
    iresP--;
    *(iresP-1) = (*(iresP-1) < 0 || *iresP < 0) ? -1 : 0;

} /* ex_or */

/* ------------------------------------------------------------------- */

ex_mod() /* floating modulo function: mod(x,y) = y*frac(x/y) */

{   double x,y;

    fresP--;
    y = *fresP;
    x = *(fresP-1);
    if ( y == 0.0) matherror(USERERR, "Division by zero in mod function.");
    x = x/y;
    *(fresP-1) = (x>=0) ? 
        y*(x -floor(x+abstolerance)) :
        y*(x -floor(x-abstolerance)-onep );

} /* ex_mod */

/* ------------------------------------------------------------------- */

ex_exponic() /* exponentiation to small integer power */

{
    *iresP++ = *ex_binP++; /* stack power */
    exs_exponic();
    
} /* ex_exponic */

/* ------------------------------------------------------------------- */ 

exs_exponic() /* exponentiation to small integer power */
              /* compiled code call-able version */
{   register int pwr; 
    double x;

    pwr = *(--iresP); 
    x = *(fresP-1);
        
    switch (pwr) {
    case 2:
        x = x*x;
        break;
    case 3:
        x = x*x*x;
        break;
    case 4:
        x = x*x*x*x;
        break;
        
    } /* switch */
    *(fresP-1) = x;
        
} /* exs_exponic */

/* ------------------------------------------------------------------- */

ex_exponent() /* general exponentiation */

{   double x,y;

    fresP--;
    y = *fresP; 
    x = *(fresP-1);
    x = lcfexpon(y,x);
    *(fresP-1) = x;

} /* ex_exponent */

/* ------------------------------------------------------------------- */

ex_arctan() /* arctangent */

{
    *(fresP-1) = atan(*(fresP-1));

} /* ex_arctan */

/* ------------------------------------------------------------------- */

ex_arctan2() /* two-argument arctangent */

{	double aa,bb,rr;

	fresP--;
	aa = *fresP;
	bb = *(fresP-1);
	if ((aa == 0.0) && (bb == 0.0)) { /* atan2 on Mac returns 0 */
		rr = Indefinite;
	} else {
		rr = atan2(bb,aa);
	}
    *(fresP-1) = rr;

} /* ex_arctan2 */

/* ------------------------------------------------------------------- */

ex_int() /* integer part of floating value */

{   double x;

    x = *(fresP-1); 
    *(fresP-1) = ( (x>=0) ? floor(x+abstolerance) :
        floor(x-abstolerance)+onep );

} /* ex_int */

/* ------------------------------------------------------------------- */

ex_frac() /* fractional part of floating value */

{   double x;

    x = *(fresP-1);
    *(fresP-1) = (x>=0) ? x-floor(x+abstolerance) : 
        x-floor(x-abstolerance)-onep;

} /* ex_frac */

/* ------------------------------------------------------------------- */

ex_round() /* round floating value to integer */

{
    *iresP++ = round(*(--fresP));

} /* ex_round */

/* ------------------------------------------------------------------- */

ex_sign() /* sign function - convert value to +1.0, -1.0 or 0.0 */

{   double fx;

    fx = *(fresP-1);
    if (fx > 0.0)
        fx = 1.0;
    else if (fx <0.0)
        fx = -1.0;
    *(fresP-1) = fx;

} /* ex_sign */

/* ------------------------------------------------------------------- */

ex_isign() /* sign function - convert value to +1, -1 or 0 */

{   register long ix;

    ix = *(iresP-1);
    if (ix > 0)
        ix = 1;
    else if (ix<0)
        ix = -1;
    *(iresP-1) = ix;

} /* ex_isign */

/* ------------------------------------------------------------------- */

ex_comp() /* complement */

{
    *(iresP-1) = ~(*(iresP-1));

} /* ex_comp */

/* ------------------------------------------------------------------- */

ex_cot() 

{   double x;

    x = tan(*(fresP-1));
    if (x == 0.0) x = Infinite;
    else x = onep/x;
    *(fresP-1) = x; 

} /* ex_cot */

/* ------------------------------------------------------------------- */

ex_csc()

{   double x;
    
    x = sin(*(fresP-1));
    if (x == 0.0) x = Infinite;
    else x = onep/x;
    *(fresP-1) = x;

} /* ex_csc */

/* ------------------------------------------------------------------- */

ex_sec()

{   double x;

    x = cos(*(fresP-1));
    if (x == 0.0) x = Infinite;
    else x = onep/x;
    *(fresP-1) = x; 

} /* ex_sec */

/* ------------------------------------------------------------------- */

ex_arcsin() 

{ 
    if ( fabs(*(fresP-1)) > 1.0)
        matherror(USERERR, "Argument of arcsin must be between -1 and +1.");
    *(fresP-1) = asin(*(fresP-1)); 

} /* ex_arcsin */

/* ------------------------------------------------------------------- */

ex_arccos() 

{ 
    if ( fabs(*(fresP-1)) > 1.0) 
        matherror(USERERR, "Argument of arccos must be between -1 and +1.");
    *(fresP-1) = acos(*(fresP-1)); 

} /* ex_arccos */

/* ------------------------------------------------------------------- */

ex_sqrt() 

{   double av;

    av = *(fresP-1);
    if (av < 0.0) {
        if (TstIndefinite(av))
        	matherror(USERERR,"Indefinite sqrt argument");
        if (fuzzyeq(av,0.0)) return(0.0);
         matherror(USERERR, "Negative sqrt argument.");
    } /* av if */
    *(fresP-1) = sqrt(av); 

} /* ex_sqrt */

/* ------------------------------------------------------------------- */

ex_log() 

{   
    if (*(fresP-1) <= 0.0) 
        matherror(USERERR,"Argument of log must be positive.");
    *(fresP-1) = log10(*(fresP-1));
 
} /* ex_log */

/* ------------------------------------------------------------------- */

ex_ln() 

{ 
    if (*(fresP-1) <= 0.0) 
        matherror(USERERR, "Argument of ln must be positive.");
    *(fresP-1) = log(*(fresP-1)); 

} /* ex_ln */

/* ------------------------------------------------------------------- */

ex_abs() { *(fresP-1) = fabs(*(fresP-1)); }
ex_exp() { *(fresP-1) = exp(*(fresP-1)); }
ex_alog() { *(fresP-1) = pow(10.0,*(fresP-1)); }
ex_sin() { *(fresP-1) = sin(*(fresP-1)); }  
ex_cos() { *(fresP-1) = cos(*(fresP-1)); }  
ex_tan() { *(fresP-1) = tan(*(fresP-1)); }
ex_arccsc() { *(fresP-1) = asin(onep/(*(fresP-1))); }
ex_arcsec() { *(fresP-1) = acos(onep/(*(fresP-1))); }
ex_arccot() { *(fresP-1) = atan(onep/(*(fresP-1))); }
ex_sinh() { *(fresP-1) = sinh(*(fresP-1)); }
ex_cosh() { *(fresP-1) = cosh(*(fresP-1)); }
ex_tanh() { *(fresP-1) = tanh(*(fresP-1)); }

/* ------------------------------------------------------------------- */

ex_zlengthm() /* return length of marked string */

{   
    *iresP++ = (--markP)->len;

} /* ex_zlengthm */

/* ------------------------------------------------------------------- */

ex_zposition() /* position of marked string */

{   
    *iresP++ = (--markP)->pos;  
        
} /* ex_zposition */
    
/* ------------------------------------------------------------------- */

ex_mcat() /* concatenate two mmarked strings */

{   struct markvar SHUGE *mx;
    struct markvar SHUGE *my;
    struct markvar mz;
    long extraDumm;

    my = --markP;
    mx = markP-1; 

    /* set up new temporary marker/doc */

    mz.doc = mvar_new(TRUE); /* get a scratch document */
    mz.nextm = mz.prevm = mz.vaddr = -1;
    mz.attached = FALSE; /* not attached to update chain */
    mz.ctvar = TRUE; /* marker variable, not internal */
    mz.pos = mz.len = 0;
    
    /* copy 1st string to temporary */
    
    mvar_append((struct markvar SHUGE *)&mz,mx); /* copy 1st to temp */
    mz.len = mx->len;
    
    /* append 2nd string */
    
    mvar_append((struct markvar SHUGE *)&mz,my); /* append 2nd to first */
    mz.len += my->len;
    
    mz.alteredF = 0;
    *mx = mz;

} /* ex_mcat */

/* ------------------------------------------------------------------- */

ex_zcode() /* convert character to integer */

{   
    if ((--markP)->len == 0) {
        *iresP++ = -1;
        return;
    }
    *iresP++ = TUTORcharat_doc(markP->doc,markP->pos);
  
} /* ex_zcode */

/* ------------------------------------------------------------------- */

ex_zchar() /* convert integer to character */

{   unsigned char cc[2];
    long val;

    val = *(--iresP);
    if ((val < 0) || (val > 255))
        scoderr();
    cc[0] = val;
    if (cc[0] > 0xff) 
        mvar_empty();
    else if ((cc[0] > 0x7f) && (cc[0] < 0xa0)) 
        mvar_empty(); 
    else {
        cc[1] = '\0';
        mvar_init(markP); /* set up new temp marker */
        TUTORinsert_string_doc(markP->doc,0L,(unsigned char FAR *)&cc[0],1L);
        markP->doclen = 1;
        (markP++)->len = 1;
    } /* else */

} /* ex_zchar */

/* ------------------------------------------------------------------- */

int mvar_empty() /* return empty marker variable */

{
    mvar_init(markP); /* initialize new temp marker */
    markP->pos = 0; 
    markP->len = markP->doclen = 0;
    markP++; /* advance marker stack */
    return(0);

} /* mvar_empty */

/* ------------------------------------------------------------------- */

ex_zfirst() /* return marker on 1st character of region */

{
    if ((markP-1)->len) (markP-1)->len = 1;

} /* ex_zfirst */

/* ------------------------------------------------------------------- */

ex_zlast() /* return marker on last character of region */

{   register struct markvar SHUGE *mx;

    mx = markP-1;
    if (mx->len) {
        mx->pos += mx->len-1;
        mx->len = 1;
    }

} /* ex_zlast */

/* ------------------------------------------------------------------- */

ex_zbase() /* return marker on entire document */

{   long len;
    register struct markvar SHUGE *mx;

    mx = markP-1;
    mvar_get_inf(mx->doc,&len,NEARNULL,NEARNULL);
    mx->pos = 0;
    mx->len = len;
    
} /* ex_zbase */

/* ------------------------------------------------------------------- */

ex_znext() /* return marker on next character */

{   register struct markvar SHUGE *mx;
    register long npos;

    mx = markP-1;
    npos = mx->pos+mx->len;
    if (npos >= mx->doclen) {
        mx->pos = mx->doclen; /* zero lth, at end */
        mx->len = 0;
    } else {
        mx->pos = npos;
        mx->len = 1;
    } /* else */

} /* ex_znext */

/* ------------------------------------------------------------------- */

ex_zprevious() /* return marker on previous character */

{   register struct markvar SHUGE *mx;

    mx = markP-1;
    if ((--mx->pos) < 0) {
        mx->pos = mx->len = 0; /* zero lth, at begin */
    } else mx->len = 1;

} /* ex_zprevious */

/* ------------------------------------------------------------------- */

ex_zstart() /* return 0 lth marker at begin of marked area */

{   
    (markP-1)->len = 0;
        
} /* ex_zstart */

/* ------------------------------------------------------------------- */

ex_zend() /* return 0 lth marker at end of marked region */

{   
    (markP-1)->pos += (markP-1)->len;
    (markP-1)->len = 0;

} /* ex_zend */

/* ------------------------------------------------------------------- */

ex_zcopy() /* return copy of marked region */

{   struct markvar mz;
    long extraDumm;

    mz = *(--markP);
    
    /* set up new temporary marker/doc */

    markP->doc = mvar_new(TRUE); /* get a scratch document */
    markP->nextm = markP->prevm = markP->vaddr = -1;
    markP->attached = FALSE; /* not attached to update chain */
    markP->ctvar = TRUE; /* not internal marker */

    /* copy string to temporary */
    markP->pos = 0L;
    TUTORchange_doc_doc(markP->doc,0L,0L,0L,0L,mz.doc,mz.pos,mz.len,&extraDumm,FALSE);
    markP->len = markP->doclen = mz.len;
    
    markP->alteredF = 0;
    markP++;

} /* ex_zcopy */

/* ------------------------------------------------------------------- */

ex_zaltered() /* return TRUE if marked region modified */

{   register struct markvar SHUGE *mx; /* temp marker */
    register struct markvar SHUGE *mv; /* original marker variable */
    register int alteredf; /* altered flag */

    mx = --markP;
    alteredf = 0; /* not altered */
    if (mx->vaddr >= 0) {
        mv = (struct markvar SHUGE *)(exS.stackP+mx->vaddr);
        if (mv->alteredF & 1) {
            alteredf = -1; /* was altered */
            mv->alteredF &= (~1); /* clear alterede bit */
        } /* mv->altered if */
    } /* addr if */
    *iresP++ = alteredf;

} /* ex_zaltered */

/* ------------------------------------------------------------------- */

ex_zextent() /* mark area enclosed by two marked areas */

{   register struct markvar SHUGE *mx;
    register struct markvar SHUGE *my;
    register struct markvar SHUGE *swapm;
    struct markvar mz;
    register long mpos1, mpos2;

    mx = --markP;
    my = --markP; 
    if (mx->doc != my->doc) 
        matherror(USERERR,"zextent markers not on same document. "); 
    if (mx->pos > my->pos) {
        swapm = mx; /* exchange so mx has low position */
        mx = my;
        my = swapm;
    } /* pos if */
    mz = *mx;
    mpos2 = my->pos+my->len;
    mpos1 = mx->pos+mx->len;
    if (mpos1>mpos2) mpos2 = mpos1; /* maximum extent */
    mz.pos = mx->pos;
    mz.len = mpos2-mz.pos;
    *(markP++) = mz;

} /* ex_zextent */

/* ------------------------------------------------------------------- */

ex_zsamemark() /* check if two markers are identical */

{   register struct markvar SHUGE *mx;
    register struct markvar SHUGE *my;

    mx = --markP;
    my = --markP;
    if (mx->doc != my->doc) 
        matherror(USERERR,"zsamemark markers not on same document. "); 
    if ((mx->pos == my->pos) && (mx->len == my->len))
        *iresP++ = -1;
    else *iresP++ = 0;

} /* ex_zsamemark */

/* ------------------------------------------------------------------- */

ex_zsetmark() /* mark area specified by position, length */

{   register struct markvar SHUGE *mx;
    register long pos;
    register long len;

    len = *(--iresP); /* length */
    pos = *(--iresP); /* position */
    mx = markP-1; 
    if ((pos<0) || (len<0) || ((pos+len)>mx->len))
        matherror(USERERR,"ZSETMARK illegal position/length"); 
    mx->pos = mx->pos+pos;
    mx->len = len;

} /* ex_zsetmark */

/* ------------------------------------------------------------------- */

ex_zprecede() /* check if one marker begins before another */

{   register struct markvar SHUGE *mx;
    register struct markvar SHUGE *my;

    mx = --markP;
    my = --markP;

    if (mx->doc != my->doc) 
        matherror(USERERR,"zprecede markers not on same document. "); 
    if (my->pos < mx->pos) *iresP++ = -1;
    else  *iresP++ = 0;

} /* ex_zprecede */

/* ------------------------------------------------------------------- */

ex_zks() /* convert key code to key name */

{   int code;
    char FAR *str; /* pointer to key name string */
    long strl; /* length of key name string */
    char tempS[40]; /* space for CTzks to construct string */

    code = *(--iresP);

    str = CTzks(code,tempS);

    mvar_init(markP); /* set up new temp marker */
    strl = strlenf(str);
    TUTORinsert_string_doc(markP->doc,0L,(unsigned char FAR *)str,strl);
    markP->doclen = strl;
    (markP++)->len = strl;

} /* ex_zks */

/* ------------------------------------------------------------------- */

ex_lt() /* less than */

{   
    *iresP++ = fuzzylt(*(fresP-2),*(fresP-1)) ? -1 : 0;
    fresP -= 2;

} /* ex_lt */

/* ------------------------------------------------------------------- */

ex_gt() /* greater than */

{   
    *iresP++ = fuzzygt(*(fresP-2),*(fresP-1)) ? -1 : 0;
    fresP -= 2;

} /* ex_gt */

/* ------------------------------------------------------------------- */

ex_le() /* less than or equal to */

{
    *iresP++ = fuzzyle(*(fresP-2),*(fresP-1)) ? -1 : 0;
    fresP -= 2;

} /* ex_le */

/* ------------------------------------------------------------------- */

ex_ge() /* greater than or equal to */

{
    *iresP++ = fuzzyge(*(fresP-2),*(fresP-1)) ? -1 : 0;
    fresP -= 2;

} /* ex_ge */

/* ------------------------------------------------------------------- */

ex_eq() /* equal to */

{
    *iresP++ = fuzzyeq(*(fresP-2),*(fresP-1)) ? -1 : 0;
    fresP -= 2;

} /* ex_eq */

/* ------------------------------------------------------------------- */

ex_ne() /* not equal */

{
    *iresP++ = fuzzyeq(*(fresP-2),*(fresP-1)) ? 0 : -1;
    fresP -= 2;

} /* ex_ne */

/* ------------------------------------------------------------------- */

ex_splt() /* less than (trinary component) */

{
    if (exs_splt()) ex_binP += 2; /* skip over BRANCHF and its address */
    else n_follow(IBRANCHF); 

} /* ex_splt */

/* ------------------------------------------------------------------- */

int exs_splt() /* less than (trinary component) */
               /* compiled code call-able version */
{
    fresP--;
    if (fuzzylt(*(fresP-1),*fresP)) {
        *(fresP-1) = *fresP;
        return(TRUE); /* return C TRUE */
    } else { 
        *iresP++ = 0;
        fresP--;
        return(FALSE); /* return C FALSE */
    }  

} /* exs_splt */

/* ------------------------------------------------------------------- */

ex_spgt() /* greater than (trinary component) */

{
    if (exs_spgt()) ex_binP += 2; /* skip over BRANCHF and address */
    else n_follow(IBRANCHF);
        
} /* ex_spgt */

/* ------------------------------------------------------------------- */

int exs_spgt() /* greater than (trinary component) */
               /* compiled code call-able version */
{
    fresP--;
    if (fuzzygt(*(fresP-1),*fresP)) { 
        *(fresP-1) = *fresP;
        return(TRUE); /* return C TRUE */
    } else { 
        *iresP++ = 0; 
        fresP--;
        return(FALSE); /* return C FALSE */
    }  
        
} /* exs_spgt */

/* ------------------------------------------------------------------- */

ex_sple() /* less than or equal to (trinary component) */

{
    if (exs_sple()) ex_binP += 2; /* skip over BRANCHF and its address */
    else n_follow(IBRANCHF);
        
} /* ex_sple */

/* ------------------------------------------------------------------- */

int exs_sple() /* less than or equal to (trinary component) */
               /* compiled code call-able version */
{
    fresP--;
    if (fuzzyle(*(fresP-1),*fresP)) { 
        *(fresP-1) = *fresP;
        return(TRUE); /* return C TRUE */
    } else { 
        *iresP++ = 0; 
        fresP--;
        return(FALSE); /* return C FALSE */
    } 
        
} /* exs_sple */

/* ------------------------------------------------------------------- */

ex_spge() /* greater than or equal to (trinary component) */
        
{
    if (exs_spge()) ex_binP += 2; /* skip over BRANCHF and its address */
    else n_follow(IBRANCHF);

} /* ex_spge */

/* ------------------------------------------------------------------- */

int exs_spge() /* greater than or equal to (trinary component) */
               /* compiled code call-able version */        
{
    fresP--;
    if (fuzzyge(*(fresP-1),*fresP)) {
        *(fresP-1) = *fresP;
        return(TRUE); /* return C TRUE */
    } else { 
        *iresP++ = 0; 
        fresP--;
        return(FALSE); /* return C FALSE */
    } 

} /* exs_spge */

/* ------------------------------------------------------------------- */

ex_speq() /* equal to (trinary component) */
        
{   
    if (exs_speq()) ex_binP += 2;  /* skip over IBRANCHF and its address */
    else n_follow(IBRANCHF);

} /* ex_speq */

/* ------------------------------------------------------------------- */

int exs_speq() /* equal to (trinary component) */
               /* compiled code call-able version */
               
{   
    fresP--;
    if (fuzzyeq(*(fresP-1),*fresP)) {
        *(fresP-1) = *fresP;
        return(TRUE); /* return C TRUE */
    } else { 
        *iresP++ = 0; 
        fresP--;
        return(FALSE); /* return C FALSE */
    } 

} /* exs_speq */
       
/* ------------------------------------------------------------------- */

ex_spne() /* not equal (trinary component) */

{
    if (exs_spne()) ex_binP += 2; /* skip over IBRANCHF and its address */
    else n_follow(IBRANCHF);

} /* ex_spne */

/* ------------------------------------------------------------------- */

exs_spne() /* not equal (trinary component) */

{
    fresP--;
    if (fuzzyne(*(fresP-1),*fresP)) {
        *(fresP-1) = *fresP;
        return(TRUE); /* return C TRUE */
    } else { 
        *iresP++ = 0;
        fresP--; 
        return(FALSE); /* return C FALSE */
    }

} /* exs_spne */

/* ------------------------------------------------------------------- */ 

ex_ilt() /* integer less than */

{
    iresP--;
    *(iresP-1) = (*(iresP-1) < *iresP) ? -1 : 0;

} /* ex_ilt */

/* ------------------------------------------------------------------- */

ex_igt() /* integer greater than */

{
    iresP--;
    *(iresP-1) = (*(iresP-1) > *iresP) ? -1 : 0;
 
} /* ex_igt */

/* ------------------------------------------------------------------- */  

ex_ile() /* integer less than or equal */

{
    iresP--;
    *(iresP-1) = (*(iresP-1) <= *iresP) ? -1 : 0;
        
} /* ex_ile */
  
/* ------------------------------------------------------------------- */

ex_ige() /* integer greater than or equal */

{
    iresP--;
    *(iresP-1) = (*(iresP-1) >= *iresP) ? -1 : 0;

} /* ex_ige */

/* ------------------------------------------------------------------- */

ex_ieq() /* integer equal to */

{
    iresP--;
    *(iresP-1) = (*(iresP-1) == *iresP) ? -1 : 0;

} /* ex_ieq */

/* ------------------------------------------------------------------- */

ex_ine() /* integer not equal */

{
    iresP--;
    *(iresP-1) = (*(iresP-1) != *iresP) ? -1 : 0;

} /* ex_ine */
/* ------------------------------------------------------------------- */

ex_txeq() /* TXTYPE equal to */

{
    iresP--;
    if ((*(iresP-1) == 0) || (*(iresP) == 0))
    	*(iresP-1) = 0;
    else
    	*(iresP-1) = (*(iresP-1) == *iresP) ? -1 : 0;

} /* ex_ieq */

/* ------------------------------------------------------------------- */

ex_txne() /* TXTYPE not equal */

{
    iresP--;
    if ((*(iresP-1) == 0) || (*(iresP) == 0))
    	*(iresP-1) = -1;
    else 
    	*(iresP-1) = (*(iresP-1) != *iresP) ? -1 : 0;

} /* ex_ine */
/* ------------------------------------------------------------------- */

ex_ispeq() /* integer equals (trinary component) */

{
    if (exs_ispeq()) ex_binP += 2; /* skip over BRANCHF and its addr */
    else n_follow(IBRANCHF); /* branch false */ 
        
} /* ex_ispeq */

/* ------------------------------------------------------------------- */

exs_ispeq() /* integer equals (trinary component) */
            /* compiled code call-able version */

{   register long ix,iy;

    iy = *(--iresP);
    ix = *(iresP-1);
    if (ix == iy) {
        *(iresP-1) = iy;
        return(TRUE);
    } else { 
        *(iresP-1) = 0; 
        return(FALSE);
    }
        
} /* exs_ispeq */

/* ------------------------------------------------------------------- */

ex_ispne() /* integer not equal (trinary component) */

{
    if (exs_ispne()) ex_binP += 2; /* skip over BRANCHF and its addr */
    else n_follow(IBRANCHF); /* branch false */ 

} /* ex_ispne */

/* ------------------------------------------------------------------- */

exs_ispne() /* integer not equal (trinary component) */
            /* compiled code call-able version */

{   register long ix,iy;

    iy = *(--iresP);
    ix = *(iresP-1);
    if (ix != iy) {
        *(iresP-1) = iy;
        return(TRUE);
    } else { 
        *(iresP-1) = 0; 
        return(FALSE);
    }

} /* exs_ispne */
  
/* ------------------------------------------------------------------- */

ex_isplt() /* integer less than (trinary component) */

{
    if (exs_isplt()) ex_binP += 2; /* skip over BRANCHF and its addr */
    else n_follow(IBRANCHF); /* branch false */ 

} /* ex_isplt */

/* ------------------------------------------------------------------- */

exs_isplt() /* integer less than (trinary component) */
            /* compiled code call-able version */

{   register long ix,iy;

    iy = *(--iresP);
    ix = *(iresP-1);
    if (ix < iy) {
        *(iresP-1) = iy;
        return(TRUE);
    } else { 
        *(iresP-1) = 0; 
        return(FALSE); 
    }
        
} /* exs_isplt */

/* ------------------------------------------------------------------- */

ex_ispgt() /* integer greater than (trinary component) */

{
    if (exs_ispgt()) ex_binP += 2; /* skip over BRANCHF and its addr */
    else n_follow(IBRANCHF); /* branch false */ 

} /* ex_ispgt */

/* ------------------------------------------------------------------- */

exs_ispgt() /* integer greater than (trinary component) */
            /* compiled code call-able version */

{   register long ix,iy;

    iy = *(--iresP);
    ix = *(iresP-1);
    if (ix > iy) {
        *(iresP-1) = iy;
        return(TRUE);
    } else { 
        *(iresP-1) = 0; 
        return(FALSE);
    }
    
} /* exs_ispgt */

/* ------------------------------------------------------------------- */

ex_isple() /* integer less than or equal to (trinary component) */

{
    if (exs_isple()) ex_binP += 2; /* skip over BRANCHF and its addr */
    else n_follow(IBRANCHF); /* branch false */ 

} /* ex_isple */

/* ------------------------------------------------------------------- */

exs_isple() /* integer less than or equal to (trinary component) */
            /* compiled code call-able version */

{   register long ix,iy;

    iy = *(--iresP);
    ix = *(iresP-1);
    if (ix <= iy) {
        *(iresP-1) = iy;
        return(TRUE);
    } else { 
        *(iresP-1) = 0; 
        return(FALSE);
    }
    
} /* exs_isple */

/* ------------------------------------------------------------------- */

ex_ispge() /* integer greater than or equal to (trinary component) */

{
    if (exs_isple()) ex_binP += 2; /* skip over BRANCHF and its addr */
    else n_follow(IBRANCHF); /* branch false */ 

} /* ex_ispge */

/* ------------------------------------------------------------------- */

exs_ispge() /* integer greater than or equal to (trinary component) */
            /* compiled code call-able version */
    
{   register long ix,iy;

    iy = *(--iresP);
    ix = *(iresP-1);

    if (ix >= iy) {
        *(iresP-1) = iy;
        return(TRUE);
    } else { 
        *(iresP-1) = 0; 
        return(FALSE);
    }
    
} /* exs_ispge */

/* ------------------------------------------------------------------- */

ex_mlt() /* marker less than */

{   register struct markvar SHUGE *mx;
    register struct markvar SHUGE *my;

    my = --markP;
    mx = --markP;
    *iresP++ = (mvar_compare(mx,my,FALSE)<0) ? -1 : 0;
        
} /* ex_mlt */

/* ------------------------------------------------------------------- */

ex_mgt() /* marker greater than */

{   register struct markvar SHUGE *mx;
    register struct markvar SHUGE *my;

    my = --markP;
    mx = --markP;
    *iresP++ = (mvar_compare(mx,my,FALSE)>0) ? -1 : 0;
        
} /* ex_mgt */

/* ------------------------------------------------------------------- */

ex_mle() /* marker less than or equal */

{   register struct markvar SHUGE *mx;
    register struct markvar SHUGE *my;

    my = --markP;
    mx = --markP;
    *iresP++ = (mvar_compare(mx,my,FALSE) <= 0) ? -1 : 0;
    
} /* ex_mle */

/* ------------------------------------------------------------------- */

ex_mge() /* marker greater than or equal */

{   register struct markvar SHUGE *mx;
    register struct markvar SHUGE *my;

    my = --markP;
    mx = --markP;
    *iresP++ = (mvar_compare(mx,my,FALSE) >= 0) ? -1 : 0;
    
} /* ex_mge */

/* ------------------------------------------------------------------- */

ex_meq() /* marker equal */

{   register struct markvar SHUGE *mx;
    register struct markvar SHUGE *my;
    int ca,cb;

    my = --markP;
    mx = --markP;
    if (exS.exactMatch) {
        if (mx->len != my->len) {
            *iresP++ = 0; /* different lengths && no aliases, not equal */
            return;
        }
        if (mx->len == 1) {
            ca = TUTORcharat_doc(mx->doc,mx->pos);
            cb = TUTORcharat_doc(my->doc,my->pos);
            *iresP++ = ((ca == cb) ? -1 : 0);
            return;
        }
    } /* exS.exactMatch if */
    *iresP++ = (mvar_compare(mx,my,TRUE) == 0) ? -1 : 0;

} /* ex_meq */      

/* ------------------------------------------------------------------- */

ex_mne() /* marker not equal */

{   register struct markvar SHUGE *mx;
    register struct markvar SHUGE *my;
        
    ex_meq(); /* check if equal */
    if (*(iresP-1)) { /* reverse result */
        *(iresP-1) = 0;
    } else {
        *(iresP-1) = -1;
    }

} /* ex_mne */

/* ------------------------------------------------------------------- */

ex_msplt() /* marker less than (trinary component) */

{   
    if (exs_msplt()) ex_binP += 2; /* skip over BRANCHF and address */
    else n_follow(IBRANCHF);

} /* ex_msplt */

/* ------------------------------------------------------------------- */

int exs_msplt() /* marker less than (trinary component) */
                /* compiled code call-able version */
                
{   register struct markvar SHUGE *mx;
    register struct markvar SHUGE *my;

    my = --markP;
    mx = --markP;
    if (mvar_compare(mx,my,FALSE) < 0) {
        *(markP++) = *my;
        return(TRUE); /* return C TRUE */
    } else { 
        *iresP++ = 0; 
        return(FALSE); /* return C FALSE */
    }

} /* exs_msplt */

/* ------------------------------------------------------------------- */

ex_mspgt() /* marker greater than (trinary component) */

{
    if (exs_mspgt()) ex_binP += 2; /* skip over BRANCHF and address */
    else n_follow(IBRANCHF); /* branch false */ 

} /* ex_mspgt */

/* ------------------------------------------------------------------- */

int exs_mspgt() /* marker greater than (trinary component) */
                /* compiled code call-able version */
                
{   register struct markvar SHUGE *mx;
    register struct markvar SHUGE *my;

    my = --markP;
    mx = --markP;
    if (mvar_compare(mx,my,FALSE) > 0) {
        *(markP++) = *my;
        return(TRUE); /* return C TRUE */
    } else { 
        *iresP++ = 0; 
        return(FALSE); /* return C FALSE */
    }

} /* exs_mspgt */

/* ------------------------------------------------------------------- */

ex_msple() /* marker less than or equal (trinary component) */

{   
    if (exs_msple()) ex_binP += 2; /* skip BRANCHF and address */
    else n_follow(IBRANCHF); /* branch false */ 
        
} /* ex_msple */

/* ------------------------------------------------------------------- */

int exs_msple() /* marker less than or equal (trinary component) */
                /* compiled code call-able version */
                
{   register struct markvar SHUGE *mx;
    register struct markvar SHUGE *my;

    my = --markP;
    mx = --markP;
    if (mvar_compare(mx,my,FALSE)  <= 0) {
        *(markP++) = *my;
        return(TRUE); /* return C TRUE */
    } else { 
        *iresP++ = 0; 
        return(FALSE); /* return C FALSE */
    }
        
} /* exs_msple */

/* ------------------------------------------------------------------- */

ex_mspge() /* marker greater than or equal (trinary component) */
        
{   
    if (exs_mspge()) ex_binP += 2; /* skip BRANCHF and address */
    else n_follow(IBRANCHF); /* branch false */ 
    
} /* ex_mspge */

/* ------------------------------------------------------------------- */

int exs_mspge() /* marker greater than or equal (trinary component) */
                /* compiled code call-able version */
                        
{   register struct markvar SHUGE *mx;
    register struct markvar SHUGE *my;

    my = --markP;
    mx = --markP;
    if (mvar_compare(mx,my,FALSE) >= 0) {
        *(markP++) = *my;
        return(TRUE); /* return C TRUE */
    } else { 
        *iresP++ = 0; 
        return(FALSE); /* return C FALSE */
    }
    
} /* exs_mspge */

/* ------------------------------------------------------------------- */

ex_mspeq() /* marker equal (trinary component) */

{   
    if (exs_mspeq()) ex_binP += 2; /* skip BRANCHF and address */
    else n_follow(IBRANCHF); /* branch false */ 
    
} /* ex_mspeq */

/* ------------------------------------------------------------------- */

int exs_mspeq() /* marker equal (trinary component) */
                /* compiled code call-able version */
                
{   register struct markvar SHUGE *mx;
    register struct markvar SHUGE *my;

    my = --markP;
    mx = --markP;
    if ((my->len != mx->len && exS.exactMatch) ||
            mvar_compare(mx,my,TRUE) != 0)
    { /* not equal */
        *iresP++ = 0; 
        return(FALSE); /* return C FALSE */
    } else { /* equal */
        *(markP++) = *my;
        return(TRUE); /* return C TRUE */
    }
} /* exs_mspeq */

/* ------------------------------------------------------------------- */

ex_mspne() /* marker not equal (trinary component) */

{   
    if (exs_mspne()) ex_binP += 2; /* skip BRANCHF and address */
    else n_follow(IBRANCHF); /* branch false */ 

} /* ex_mspne */

/* ------------------------------------------------------------------- */

int exs_mspne() /* marker not equal (trinary component) */
                /* compiled code call-able version */
                
{   register struct markvar SHUGE *mx;
    register struct markvar SHUGE *my;

    my = --markP;
    mx = --markP;
    if ((my->len != mx->len && exS.exactMatch) ||
            mvar_compare(mx,my,TRUE) != 0) {
        *(markP++) = *my;
        return(TRUE); /* return C TRUE */
    } else { 
        *iresP++ = 0; 
        return(FALSE); /* return C FALSE */
    }

} /* exs_mspne */

/* ------------------------------------------------------------------- */

ex_ibrancht() /* branch if condition true */

{   register long ix;
    
    ix = *(iresP-1) = (*(iresP-1) < 0 ? -1: 0);
    if (ix < 0) {
        ex_binP--; /* back up to IBRANCHT code */
        n_follow(IBRANCHT); 
    } else ex_binP++; /* skip past branch address */

} /* ex_ibrancht */

/* ------------------------------------------------------------------- */

ex_ibranchf() /* branch if condition false */

{   register long ix;

    ix = *(iresP-1) = ((*(iresP-1) < 0) ? -1 : 0);
    if (ix >= 0) {
        ex_binP--; /* back up to IBRANCHF code */
        n_follow(IBRANCHF); 
    } else ex_binP++;
    
} /* ex_ibranchf */

/* ------------------------------------------------------------------- */

#ifdef NOSUCH

ex_cbrancht() /* conditional branch on true */

{   int branch;

    branch = *(ex_binP++);
    if (*(--iresP) < 0) {
        ex_binP = (short FAR *)(pcodep+branch);
                
        /* check if should interrupt */

    	if ((++exS.loopcounter > 50) || exS.outcnt || exS.shouldint) { 
			exS.loopcounter = 0;
			exS.uloc = branch; /* set relative address */
			if (shouldint() || (exS.outcnt > 10)) {
				execrun = FALSE; /* return from executor */
	    		waitflag = atinterrupt;
			}
    	} /* loopcounter if */
    }

} /* ex_cbrancht */

/* ------------------------------------------------------------------- */

ex_cbranchf() /* conditional branch on false */

{   int branch;

    branch = *(ex_binP++);
    if (*(--iresP) >= 0) {
        ex_binP = (short FAR *)(pcodep+branch);
        
        /* check if should interrupt */

    	if ((++exS.loopcounter > 50) || exS.outcnt || exS.shouldint) { 
			exS.loopcounter = 0;
			exS.uloc = branch; /* set relative address */
			if (shouldint() || (exS.outcnt > 10)) {
				execrun = FALSE; /* return from executor */
	    		waitflag = atinterrupt;
			}
    	} /* loopcounter if */
    }
    
} /* ex_cbranchf */


/* ------------------------------------------------------------------- */

ex_ubranch() /* unconditional branch */

{   register int branch;

    branch = *(ex_binP);
    ex_binP = (short FAR *)(pcodep+branch);

    /* check if should interrupt */

    if ((++exS.loopcounter > 50) || exS.outcnt || exS.shouldint) { 
		exS.loopcounter = 0;
		exS.uloc = branch; /* set relative address */
		if (shouldint() || (exS.outcnt > 10)) {
			execrun = FALSE; /* return from executor */
	    	waitflag = atinterrupt;
		}
    }

} /* ex_ubranch */

#endif

/* ------------------------------------------------------------------- */

ex_sysvar() /* floating reserverd word */

{   
    *iresP++ = *ex_binP++;
    exs_sysvar();

} /* ex_sysvar */

/* ------------------------------------------------------------------- */

exs_sysvar() /* floating reserved word */
             /* compiled code call-able version */

{   int swi;    /* integer for switch */
    int fc,bc,wc;
    double rv; /* result value */
    long lv; /* integer result value */

    swi = *(--iresP);
    switch (swi) {
    case ZXMIN: 
        rv = CoordToFloat(exS.RegionXmin); 
        break;
    case ZYMIN: 
        rv = CoordToFloat(exS.RegionYmin); 
        break;
    case ZXMAX: 
        rv = CoordToFloat(exS.RegionXmax);
        break;
    case ZYMAX: 
        rv = CoordToFloat(exS.RegionYmax);
        break;
    case ZCLOCK: 
        rv = (double)TUTORinq_msec_clock()/1000.0; 
        break;
    case ZDAY: 
        rv = TUTORjdate();
        break;
    case ZTOUCHX: 
        rv = CoordToFloat(exS.ztouchx); 
        break;
    case ZTOUCHY: 
        rv = CoordToFloat(exS.ztouchy); 
        break;
    case ZGTOUCHX: 
        rv = exS.zgtouchx;
        break; 
    case ZGTOUCHY: 
        rv = exS.zgtouchy;
        break;
    case ZRTOUCHX: 
        rv = exS.zrtouchx; 
        break;
    case ZRTOUCHY: 
        rv = exS.zrtouchy; 
        break;
    case ZWHEREX: 
        rv = CoordToFloat(exS.ScreenX); 
        break;
    case ZWHEREY: 
        rv = CoordToFloat(exS.ScreenY); 
        break;
    case ZMOUSEX:
    	TUTORinq_mouse_xy(&lv,NEARNULL);
    	rv = CoordToFloat(DivCoord(IntToCoord(lv - exS.OffsetX), exS.ScaleX) + exS.RegionXmin);
    	break;
    case ZMOUSEY:
    	TUTORinq_mouse_xy(NEARNULL,&lv);
    	rv = CoordToFloat(DivCoord(IntToCoord(lv - exS.OffsetY), exS.ScaleY) + exS.RegionYmin);
    	break;
    case ZDBLCLICK:
    	rv = TUTORdouble_click_time()/1000.0;
    	break;
    case ZFORWARD:
    	rv = TUTORis_foreground(ExecWn);
    	if (rv) rv = -1;
    	break;
    case ZVTIME:
        rv = MovieGetTime();
        break;
    case ZVPLAYING:
		MovieInfo(NEARNULL,NEARNULL,NEARNULL,&fc);
		if (fc) rv = -1;
		else rv = 0;
    	break;
    case ZVLENGTH:
	MovieInfo(NEARNULL,NEARNULL,&rv,NEARNULL);
	break;
    case ZMODE:
    	rv = exS.mode;
    	break;
    default:
	break;
    }  /* switch */
    *fresP++ = rv;

} /* exs_sysvar */

/* ------------------------------------------------------------------- */

ex_msysvar() /* marker reserved word */

{
    *iresP++ = *ex_binP++;
    exs_msysvar();
    
} /* ex_msysvar */

/* ------------------------------------------------------------------- */

exs_msysvar() /* marker reserved word */
             /* compiled code call-able version */
             
{   int sysvn; /* index of reserved word */
    int slen; /* length of string */
    register char *strp; /* reserved word string */
    unsigned char ustring[CTPATHLEN+2]; /* file/unit name string */
    struct markvar SHUGE *mx;
    long mpos,mlen; /* marker position */
    struct arrows *arrp;
    TextVDat FAR *tp; /* pointer to text panel */

    sysvn = *(--iresP); /* index of reserved word */
    switch (sysvn) {
    case ZARROWM: /* global marker at stack+0 */
        store_addr = (long)(exS.stackP);
        mvar_stack(store_addr);
        return(0); 
    case ZHOMEDIR:
        strp = TUTORgetenv("HOME"); /* get home directory name */
        break;
    case ZUSER: 
        strp = TUTORget_user(); /* get user name */
        break;
    case ZSANS:
        strp = "zsans";
        break;
    case ZSERIF:
        strp = "zserif";
        break;
    case ZFIXED:
        strp = "zfixed";
        break;
    case ZSYMBOL:
        strp = "zsymbol";
        break;
    case ZPATTERNS:
        strp = "zpatterns";
        break;
    case ZICONS:
        strp = "zicons";
        break;
    case ZCURSORS:
        strp = "zcursors";
        break;

    case ZMACHINE:
        strp = "unrecognized";
#ifdef vax
        strp = "vax";
#endif

#ifdef mips
        strp = "pmax";
#endif

#ifdef hp700
		strp = "hp";
#endif

#ifdef sparc
        strp = "sparc";
#endif

#ifdef sunV3
#ifdef mc68020
        strp = "sun3";
#else
        strp = "sun2";
#endif
#endif

#ifdef ibm032
        strp = "rt";
#endif

#ifdef DOSPC
        strp = "pc";
#endif

#ifdef WINPC
		strp = "windows";
#endif

#ifdef MAC
        strp = "macintosh";
#endif

#ifdef LINUX
	strp = "linuxpc";
#endif
        break;

    case ZMAINU:
        GetUnitName(exS.mainunit,ustring);
        strp = (char *)ustring;
        break;

    case ZCURRENTU:
        GetUnitName(exS.execunit,ustring);
        strp = (char *)ustring;
        break;
        
    case ZARROWSEL:
        mvar_stack((long)exS.stackP); /* stack zarrowm */
        mx = markP-1; /* point to stacked copy */
        arrp = &exS.arr;
        if (arrp->aPanel) {
            tp = (TextVDat FAR *)GetPtr(arrp->aPanel); /* pointer to text panel */
            TUTORinq_select_tview(tp->textv,&mpos,&mlen);
            ReleasePtr(arrp->aPanel);
            KillPtr(tp);
            mx->pos = mpos;
            mx->len = mlen;
        }       
        store_addr = (long)(exS.stackP+sizeof(struct markvar));
        mvar_assign((struct markvar SHUGE *)store_addr,mx); /* assign stacked copy to zarrowsel */
        return(0);

	case ZCLIPBOARD:
	    store_addr = (long)(exS.stackP)+2*sizeof(struct markvar);
	    mx = (struct markvar SHUGE *)store_addr;
		TUTORclear_doc(mx->doc); /* dump current contents of document */
		mx->pos = mx->len = 0;	    
		TUTORfrom_clip_doc(mx->doc,0L,0L,0L,0L,&mlen,FALSE);
		mx->len = mx->doclen = TUTORget_len_doc(mx->doc);
        mvar_stack(store_addr);
        return(0);
		
	case ZFROMPROG:
		ustring[0] = 0;
		strp = (char *)ustring;
#ifdef MAC
		if (exS.fromRef.path[0]) {
        	MacFilePath(&exS.fromRef,(char *)ustring,CTPATHLEN);  
        	strcatf((char FAR *)ustring,exS.fromRef.path);
        }
#else
#ifdef IBMPC
		if (exS.fromRef.path[0]) {
        	ustring[0] = exS.fromRef.drive+'a'-1; /* attach drive specifier */
        	ustring[1] = ':';
        	ustring[2] = 0;
		}
#endif
        strcatf((char FAR *)strp,exS.fromRef.path);
#endif /* MAC */
#ifdef IBMPC
        uplow((char FAR *)strp); /* convert to lower case */
#endif
		break;

	case ZDATE:
		strp = (char *)ustring;
		strcpy(strp,TUTORdate());
		break;
		
	case ZTIME:
		strp = (char *)ustring;
		strcpy(strp,TUTORtime());
		break;

    case ZCURRENTDIR:
    	strp = (char *)&ustring[0];
#ifdef MAC
		MacFilePath(currentDirP,strp,CTPATHLEN);     
#else
#ifdef IBMPC
        strp[0] = currentDirP->drive+'a'-1; /* attach drive specifier */
        strp[1] = ':';
        strp[2] = '\0';
#endif
        strcatf((char FAR *)strp,currentDirP->path);
#endif
        break;
        		
    default:
	break;

    }  /* switch */

    mvar_init(markP); /* initialize new temp marker */
    slen = 0;
    if (strp != NULL) {
        slen = strlen(strp);
        InsertString(markP->doc,0L,(char FAR *)strp,(long)slen);
    }
    markP->pos = 0; /* wrap marker around reserved string */
    markP->len = markP->doclen = slen;
    markP++; /* advance marker stack */

} /* exs_msysvar */

/* ------------------------------------------------------------------- */

ex_msysvara() /* storeable marker reserved word */
              /* compiled code call-able version */
              
{
    *iresP++ = *ex_binP++;
    exs_msysvara();
    
} /* ex_msysvara */

/* ------------------------------------------------------------------- */

exs_msysvara() /* storeable marker reserved word */
               /* compiled code call-able version */
               
{   register int sysvn; /* index of reserved word */

    sysvn = *(--iresP);
    switch (sysvn) {
    case ZARROWM: 
        store_kind = TMARK; /* set up for store-ability */
        store_addr = (long)(exS.stackP);
        *iresP++ = store_addr;
        break;
    case ZCLIPBOARD: 
        store_kind = TMARK; /* set up for store-ability */
        store_addr = (long)(exS.stackP)+2*sizeof(struct markvar);
        *iresP++ = store_addr;
        break;
    default:
        break;
    }  /* switch */

} /* exs_msysvara */

/* ------------------------------------------------------------------- */ 

ex_efunct() /* process marker embedded show operations */

{
    *iresP++ = *ex_binP++; /* index of function to execute */
    exs_efunct();
    
} /* ex_efunct */

/* ------------------------------------------------------------------- */

exs_efunct() /* process marker embedded show operations */

{   int a,b; /* integer/char operands */
    double x, y, z; /* floating operands */
    register long ix,iy; /* integer operands */
    long sl; /* string length */
    int stype; /* type of show 0 = s, 1 = z, 2 = e */
    int i;
    char str[68]; /* numeric string */

    str[0] = '\0';
    i = *(--iresP); /* index of function to execute */
    switch (i) {

    case 1:     /* show  v */
    case 2:     /* show  v,s */
    case 3:     /* show  v,s,m */
    case 16:    /* showz v */
    case 17:    /* showz v,s */
    case 19:    /* showe v */
    case 20:    /* showe v,s */
        if (i >= 19) stype = 2; /* showe */
        else if (i >= 16) stype = 1; /* showz */
        else stype = 0; /* show */
        y = 1.0E-9; /* default minimum */
        ix = 4; /* default size */
        if (i == 3) {
            y = *(--fresP);  /* minimum */
            ix = *(--fresP); /* size */
        } else if ((i == 2) || (i == 17) || (i == 20)) {
            ix = *(--fresP); /* size */
        } /* two argument else-if */
        x = *(--fresP);
        if (ix > 40) ix = 40;
        if (ix < 0) ix = 0;
        if ((i <= 3) && (fabs(x) < (y))) x = 0.0;
        TUTORshow(stype,x,(int) ix,str);
        break;

    case 4:     /* showt v */
    case 5:     /* showt v,l */
    case 6:     /* showt v,l,r */
        ix = 4; /* default left */
        iy = 3; /* default right */
        if (i == 6) {
            iy = *(--fresP); /* right */
            ix = *(--fresP); /* left */
        } else if (i == 5) {
            ix = *(--fresP); /* left */
            iy = 0; /* re-set right */
        }
        x = *(--fresP);
        a = 0; /* showperiod */
        if (iy) a++; /* adjust for decimal point */
        TUTORshowt(x,(int) ix,(int) iy,a,str);
        break;

    case 7:     /* showb v */
    case 8:     /* showb v,s */
        b = ((store_kind == TBYTE) ? 8: 32); /* default size */
        if (i == 8) b = *(--fresP);
        ix = *(--fresP);
        if (b > 32) b = 32;
        for(a=1; a<=b; a++)
            str[a-1] = ((ix & (1L << (b-a))) ? '1': '0');
        str[b] = '\0';
        break;

    case 10:    /* showo v */
    case 11:    /* showo v,s */
        b = ((store_kind == TBYTE) ? 3: 11); /* default size */
        if (i == 11) b = *(--fresP);
        ix = *(--fresP);
        if (b > 11) b = 11;
        if (b < 0) b = 0;
        sprintf(str,"%0*lo",b,ix);
        break;

    case 13:    /* showh v */
    case 14:    /* showh v,s */
        b = ((store_kind == TBYTE) ? 2: 8); /* default size */
        if (i == 14) b = *(--fresP);
        ix = *(--fresP);
        if (b > 8) b = 8;
        if (b < 0) b = 0;
        sprintf(str,"%0*lx",b,ix);
        break;

    case 22:    /* show  m */
        break;  /* do nothing - marker on stack */
            
    } /* switch */

    /* process numeric value */

    if (i != 22) {
        sl = strlen(str);
        mvar_init(markP); /* set up new marker on stack */
        InsertString(markP->doc,0L,(char FAR *)str,(long)(sl));
        markP->pos = 0;
        markP->len = markP->doclen = sl;    
        markP++;
    } /* numeric if */
        
} /* exs_efunct */

/* ------------------------------------------------------------------- */

ex_storinf() /* return storeable variable info */

/* individual cases: */
/* a.  not storeable, need type information */
/* b.  simple variable, 1 item only */
/* c.  array indexed by constants, need number items */
/* d.  array indexed by variable */
/* e.  for non-integer result, need dummy entry on integer stack */

{   register int globalf; /* global/local flag */
    long skind; /* variable kind (int/float/mark) */
    int istackf; /* TRUE if result on integer stack */
    int storef; /* TRUE if store-able */
    register long saddr; /* address of variable */
    register long sitems; /* number array items */

    globalf = *ex_binP++; /* global/local flag */
    skind = long_bin; /* int/float/mark variable kind */
    ex_binP += 2;
    istackf = *ex_binP++; /* integer stack flag */
    storef = *ex_binP++; /* store-able flag */
    saddr = long_bin; /* relative address of variable */
    ex_binP += 2;
    sitems = long_bin; /* number array items */
    ex_binP += 2;

    if (!istackf) *iresP++ = 0; /* dummy result on int stack */
    
    *iresP++ = skind;
    *iresP++ = saddr;
    *iresP++ = sitems;
    *iresP++ = globalf;
    *iresP++ = storef;
    exs_storinf();

} /* ex_storinf */

/* ------------------------------------------------------------------- */

exs_storinf() /* return storeable variable info */
              /* compiled code callable version */

{   int globalf; /* global/local flag */
    long skind; /* variable kind (int/float/mark) */
    register int storef; /* TRUE if store-able */
    register long saddr; /* address of variable */
    register long sitems; /* number array items */

    storef = *(--iresP);
    globalf = *(--iresP);
    sitems = *(--iresP);
    saddr = *(--iresP);
    skind = *(--iresP);

    if (storef) { /* if store-able  */
        if (saddr >= 0) {
            if (globalf) saddr = (long)(exS.stackP+saddr);
            else saddr = (long)(exS.stackP+exS.lvars+saddr);
        } else {
            saddr = store_addr;
            if (sitems < 0) sitems = store_items;
        }
    } else { /* not store-able */
        saddr = -1;
        sitems = 1;
    } /* else */
    
    *iresP++ = skind;
    *iresP++ = saddr; 
    *iresP++ = sitems;  
    
} /* exs_storinf */

/* ------------------------------------------------------------------- */

int exs_floatinit() 

{
    return(0); /* dummy, except on Macintosh (lcfinita) */
    
} /* exs_floatinit */

/* ------------------------------------------------------------------- */

ex_tkeyword() /* return keyword value (16-bit value) */

{   
    *iresP++ = *(short FAR *)(ex_binP++);  

} /* ex_tkeyword */

/* ------------------------------------------------------------------- */

ex_textarg() /* return text position+length */

{   
    *iresP++ = long_bin; /* position */
    ex_binP += 2;
    *iresP++ = long_bin; /* length */
    ex_binP += 2;

} /* ex_textarg */

/* ------------------------------------------------------------------- */

ex_textarg1() /* return text position+length */

{   register int len;
    
    len = *ex_binP++; /* length of text */
    *iresP++ = (long)(ex_binP); /* address of text */ 
    *iresP++ = len; /* length of text */
    if (len & 1) len++;
    ex_binP += (len >> 1); /* advance past following text */

} /* ex_textarg1 */

/* ------------------------------------------------------------------- */

ex_ulocaddr() /* return relative address within unit */

{
    *iresP++ = *ex_binP++;  

} /* ex_ulocaddr */

/* ------------------------------------------------------------------- */

exs_storeaddr() /* return last variable address from store_addr */
                /* compiled code call-able */
{
    *iresP++ = store_addr;
    
} /* exs_storeaddr */

/* ------------------------------------------------------------------- */

ex_arrayerr() /* process array bounds error */

{
    matherror(USERERR, "Array index out of bounds.");
    
} /* ex_arrayerr */

/* ******************************************************************* */

static long array_index(idescp) /* index into array, return address */
long idescp; /* stack addr of index of descriptor */

{   register long i, n;
    register int dim;
    unsigned char SHUGE *base;
    unsigned char SHUGE *retP;
    register struct array_desc FAR *pda; /* pointer to array description */
    register struct dim_desc FAR *pdd; /* pointer to dimension description */

#ifdef long_align
if (idescp & 3) 
    TUTORdump("unaligned array descriptor 1");
#endif
    base = exS.stackP+idescp;
    pda = (struct array_desc FAR *)(descP+*(long SHUGE *)(base)); 
    dim = pda->ndim; /* number dimensions */
    pdd = (struct dim_desc FAR *)(pda+1); /* bias to base of dimensions */

if (pda->dtype != 1)
    TUTORdump("bad array descriptor ");

    if (dim == 1) { /* one-dimensional array */
        n = *(--iresP)-pdd->lower; 
        if (n < 0 || n >= pdd->length) 
            ex_arrayerr();
    } else {
        n = 0; /* cumulative index */
        pdd += dim-1; /* bias to last dimension */
        while ((--dim) >= 0) { /* peel off indices in reverse order */
            i = *(--iresP)-pdd->lower; 
            if (i < 0 || i >= pdd->length) 
                ex_arrayerr();
            n += i*((pdd--)->multiplier);
        } /* dim while */
    } /* dim else */    
    store_items = pda->length-n;
    retP = base+ARRAYHDR+(n*pda->size); /* compute address */
    return((long)retP);

} /* array_index */

/* ------------------------------------------------------------------- */

static global_array_inf() /* stack info for unsubscripted (entire) global array */

{   
    *iresP++ = 0; /* no result */
    *iresP++ = long_bin; /* expression type */
    ex_binP += 2;
    *iresP++ = (long)(exS.stackP+long_bin); 
    ex_binP += 2;
    *iresP++ = long_bin; 
    ex_binP += 2;

} /* global_array_inf */

/* ------------------------------------------------------------------- */

static local_array_inf() /* stack info for unsubscripted local array */

{
    *iresP++ = 0; /* no result */
    *iresP++ = long_bin; /* expression type */
    ex_binP += 2;
    *iresP++ = (long)(exS.stackP+exS.lvars+long_bin); 
    ex_binP += 2;
    *iresP++ = long_bin; 
    ex_binP += 2;

} /* local_array_inf */

/* ------------------------------------------------------------------- */

static pass_array_inf() /* stack info for entire pass-by-address array */

{   register long addr; /* address of array */
    register long passd; /* index in descriptors */
    register struct array_desc FAR *adsc; /* pointer to array description */

    *iresP++ = 0; /* no result */
    *iresP++ = long_bin; /* expression type */
    ex_binP += 2;
    *iresP++ = addr = (long)(exS.stackP+
                      long_read(exS.lvarP+long_bin));
    ex_binP += 4; /* skip over array addr+length fields */
    passd = long_read(addr); /* index in descriptors */
    adsc = (struct array_desc FAR *)(descP+passd);
    if (adsc->length <= 0)
        ex_arrayerr();
    *iresP++ = store_items = adsc->length; /* length of array */

} /* pass_array_inf */

/* ------------------------------------------------------------------- */

exs_pass_array_inf() /* stack info for entire pass-by-address array */

{   int type; /* float,int,mark type */
	long addr; /* address of array */
	long passd; /* index in descriptors */
	struct array_desc FAR *adsc; /* pointer to array description */
	long SHUGE *llp; /* pointer to array info on stack */
	char SHUGE *arrayP; /* pointer to array data */
	Memh arrayH; /* handle on array */

    addr = *(--iresP);
    type = *(--iresP);
    *iresP++ = 0; /* no result */
    *iresP++ = type; /* expression type */
    *iresP++ = addr = (long)(exS.stackP+
                      long_read(exS.lvarP+addr));
    llp = (long SHUGE *)addr;
    arrayH = *(llp+2); /* handle on array */
    arrayP = (char SHUGE *)(*(llp+1)); /* pointer to array */
    passd = long_read(addr); /* index in descriptors */
    adsc = (struct array_desc FAR *)(descP+passd);
    if (adsc->length <= 0)
        ex_arrayerr();
    if (!arrayP) {
        arrayP = GetPtr(arrayH); /* lock handle */
        *(llp+1) = (long)arrayP; /* set pointer to array */
        exS.dynLocked++;
    }
    *iresP++ = store_items = adsc->length; /* length of array */

} /* exs_pass_array_inf */

/* ******************************************************************* */

long l_bin() /* read long (4-byte) integer from pcodes */

{   long result;
    register short *rp;

    rp = (short *)(&result); /* pointer in result long */
    *rp++ = *ex_binP; /* transfer 4 bytes */
    *rp++ = *(ex_binP+1);
    return(result);

} /* l_bin */

/* ******************************************************************* */

double f_bin() /* read floating (double) value from pcodes */

{   double result;
    register short *rp;

    rp = (short *)(&result); /* pointer in result long */
    *rp++ = *ex_binP; /* transfer 8 bytes */
    *rp++ = *(ex_binP+1);
    *rp++ = *(ex_binP+2);
    *rp++ = *(ex_binP+3);
#ifdef MAC
    *rp++ = *(ex_binP+4); /* transfer 10 bytes */
#endif
    return(result);

} /* f_bin */

/* ******************************************************************* */

long l_read(addr) /* read long (4-byte) integer from address */
char FAR *addr;

{   long result;
    register short *rp; /* pointer in result */
    register short SHUGE *vp; /* pointer in value */

    rp = (short *)(&result); /* pointer in result long */
    vp = (short SHUGE *)(addr);
    *rp++ = *(vp)++; /* transfer 4 bytes */
    *rp++ = *(vp)++;
    return(result);

} /* l_read */

/* ******************************************************************* */

double f_read(addr) /* read double (8-byte) value from address */
char FAR *addr;

{   double result;
    register short *rp; /* pointer in result */
    register short SHUGE *vp; /* pointer in value */

    rp = (short *)(&result); /* pointer in result long */
    vp = (short SHUGE *)(addr);
    *rp++ = *(vp)++; /* transfer 8 bytes */
    *rp++ = *(vp)++;
    *rp++ = *(vp)++;
    *rp++ = *(vp)++;
    return(result);

} /* f_read */

/* ******************************************************************* */

n_follow(branchtype) /* chain thru branches on same condition */
register int branchtype; /* branch op code */

{   register int branch;

    while ((*ex_binP) == branchtype) {
        branch = *(ex_binP+1);
        ex_binP = (short FAR *)(pcodep+branch);
    } /* while */

} /* n_follow */

/* ******************************************************************* */

static mvar_stack(addr) /* read and stack marker variable */
register long addr; /* address of marker variable */

{   register struct markvar SHUGE *mv;

    mv = (struct markvar SHUGE *)(addr);  
if ((addr == 0) || (addr == -1))
 execerr("mvar_stack bad address");
    if (mv->doc == HNULL) {
        mv->ctvar = TRUE;
        mv->doc = mvar_new(FALSE); /* get a scratch document */
        mv->pos = mv->len = mv->alteredF = mv->attached = 0;
        /* attach m-variable to document update chain */
        mvar_attach_doc(mv,mv->doc,exS.stackP);
    }
    mv->vaddr = (unsigned char SHUGE *)(addr)-exS.stackP;
    *markP = *mv; /* copy marker to temp stack */
    markP->nextm = markP->prevm = -1;
    markP->attached = FALSE; /* not attached to update chain */
    markP++; /* advance marker stack */

} /* mvar_stack */

/* ------------------------------------------------------------------- */

mvar_init(mp) /* initialize temp marker */
register struct markvar SHUGE *mp; /* pointer to marker to initialize */
    
{
    mvar_zero(mp);
    mp->doc = mvar_new(TRUE); /* get a scratch document */
}

/* ------------------------------------------------------------------- */

mvar_zero(mp) /* clear temp marker */
register struct markvar SHUGE *mp; /* pointer to marker to clear */

{
    TUTORzero((char SHUGE *) mp,(long) sizeof(struct markvar));
    mp->nextm = mp->prevm = -1;
    mp->ctvar = TRUE; /* ct marker variable, not internal marker */
    mp->vaddr = -1; /* no variable address */

} /* mvar_zero */

/* ------------------------------------------------------------------- */

mvar_assign(vaddr,mx) /* assign to marker variable */
struct markvar SHUGE *vaddr; /* address of marker variable */
register struct markvar SHUGE *mx; /* pointer to marker to assign */

{   struct markvar SHUGE *mxvar;

    mxvar = vaddr; /* marker variable */

    /* optimize when marker still on same document */

    if (mx && (mxvar->doc == mx->doc)) {
        mxvar->pos = mx->pos;
        mxvar->len = mx->len;
        return(0);
    } /* mx/mxvar if */

    /* pre-clear marker variable being assigned to */

    if (mxvar->doc) { /* pre-clear var to assign to */
        mvar_detach_doc(mxvar,mxvar->doc,exS.stackP);
    } /* doc if */

    if (mx == NULL) {
        mxvar->doc = HNULL;
        mxvar->pos = mxvar->len = -1;
        mxvar->nextm = mxvar->prevm = -1;
        mxvar->attached = FALSE; /* not attached to update chain */
        return(0);
    } /* mx if */

    /* assign new marker to marker variable */

    *mxvar = *mx;
    mvar_attach_doc(mxvar,mxvar->doc,exS.stackP);

} /* mvar_assign */

/* ------------------------------------------------------------------- */

int mvar_compare(ma,mb,exact) /* compare two marked strings */
/* return = -1 = a<b */
/*                0 = a=b */
/*                1 = a>b */
register struct markvar SHUGE *ma; /* pointer to 1st marker */
register struct markvar SHUGE *mb; /* pointer to 2nd marker */
int exact;  /* TRUE if we only care about equal/not equal */
    {
    int retVal;
    DocP dpa;
    REGISTER DocP dpb;
    unsigned char FAR *ss;
    long sLen, tempL;
    unsigned char tempS[MAXALIASLEN+31];
    long curPosa, curPosb, lenA, lenB, docUsed, cmpLen;
    unsigned char FAR *cTable;  /* sort table to use */
    int aliasLen;
    
    if (!ma->len) {
        if (!mb->len)
            return(0); /* both empty */
        return(-1); /* first empty */
    } else if (!mb->len)
        return(1);
    
    /* get alias table */
    if (!exS.exactMatch)
        cTable = exS.sortTable ? (unsigned char FAR *) GetPtr(exS.sortTable) :
                    (unsigned char FAR *) -1L;
    else
        cTable = FARNULL;
    
    /* calculate maximum alias length */
    if (cTable)
        aliasLen = cTable[257];
    else
        aliasLen = 1;

    dpa = (DocP) GetPtr(ma->doc);
    dpb = (DocP) GetPtr(mb->doc);
    
    lenA = ma->len;
    lenB = mb->len;
    curPosa = ma->pos;
    curPosb = mb->pos;
    while (lenA && lenB)
        {
        if (!dpb->shortText && ma->doc == mb->doc)
            { /* don't want to overuse buffer */
            tempL = (lenB <= MAXALIASLEN+30) ? lenB : MAXALIASLEN+30;
            TUTORget_string_doc(mb->doc,curPosb,tempL,(unsigned char FAR *) tempS);
            ss = (unsigned char FAR *) tempS;
            sLen = tempL;
            }
        else if (!dpb->shortText && (curPosb + lenB > dpb->buffEnd || curPosb >= dpb->buffStart))
            { /* load buffer */
            _TUTORload_buffer_doc(dpb,curPosb);
            ss = dpb->text + (curPosb - dpb->buffStart);
            sLen = dpb->buffEnd - curPosb; /* # of characters available */
            if (sLen > lenB)
                sLen = lenB;
            }
        else
            { /* target text is all in buffer */
            ss = dpb->text + curPosb - dpb->buffStart;
            sLen = lenB;
            }
        /* calculate how many characters to compare out of ss */
        if (sLen >= lenB)
            cmpLen = lenB; /* compare them all */
        else
            cmpLen = sLen - aliasLen + 1; /* compare up to possibility of an alias */
                                                      /* that extends past end of our chars */

        retVal = _TUTORcmp_doc(dpa,curPosa,lenA,&docUsed,ss,sLen,&cmpLen,
                            dpb->specialT,mb->pos,cTable,exact);
        
        if (retVal)
            break; /* we're done */
        
        lenA -= docUsed;
        curPosa += docUsed;
        lenB -= cmpLen;
        curPosb += cmpLen;
        }
    
    ReleasePtr(ma->doc);
    KillPtr(dpa);
    ReleasePtr(mb->doc);
    KillPtr(dpb);

    if (!exS.exactMatch && exS.sortTable)
        TUTORfree_handle(exS.sortTable);
    
    if (!retVal)
        { /* strings matched thru shorter length, check lengths */
        if (lenB) /* b was longer */
            retVal = -1;
        else if (lenA) /* a was longer */
            retVal = 1;
        }
    
    return(retVal);
    } /* mvar_compare */

/* ******************************************************************* */

double lcfexpon(y,x) /* exponentiation */
double x,y;

{   double z, result;
    register int n;

    z = floor(y+0.5);   /* round exponent to nearest integer */
    if (fabs(y-z) > abstolerance) { /* non-integer power */
        if (x >= 0.0) { return( pow(x,y) ); }
        else {
            if (fuzzyeq(x, 0.0)) return(0.0);
            else matherror(USERERR,"Negative number raised to non-integer power."); 
        }  /* x>0 else */
    } else { /* integer power */
        n = fabs(z);
        switch (n) {
        case 0: result = 1.0; break;
        case 1: result = x; break;
        case 2: result = x*x; break;
        case 3: result = x*x*x; break;
        case 4: result = x*x*x*x; break;
        case 5: result = x*x*x*x*x; break;
        default:
            if (x >= 0.0) { result = pow(x,fabs(y)); }
            else {
                result = pow(fabs(x),fabs(y));
                if (n%2 != 0) result = -result; 
            } /* else */
            break;
        } /* switch */
        return(z < 0.0 ? 1.0/result : result);
    } /* integer power else */

} /* lcfexpon */


/* ******************************************************************* */
