/* *********************************************************************** */
/*            COMMUNICATION WITH CODE OTHER THEN ANSWER JUDGING            */
/* *********************************************************************** */
/* Module  : answer.c                                                      */
/* Author  : Peter Kornelisse                                              */
/* Place   : Delft University of Technology                                */
/*                                                                         */
/* Last update : April 19th 1989                                           */
/* *********************************************************************** */
/* (c) Copyright Carnegie Mellon University, 1989. May be used and copied  */
/* freely for educational purposes, but may not be sold without the        */
/* written consent of Carnegie Mellon University.                          */
/* *********************************************************************** */
/*
Interface between cT sourcecode and replacement of the old module
answer.c.
*/

#include <stdio.h>
#include "baseenv.h"

#ifdef ctproto
void  clear_index_tag(void);
void  clear_tag(void);
void  clear_index_user(void);
void  clear_index_answer(void);
void  free_tag(void);
void  free_user(void);
void  free_answer(void);
void  init_user(void);
void  init_tag(void);
void  init_answer(void);
struct  sline FAR *n_pm(char  FAR *student_input,char  FAR *answer_tag);
char  FAR *GetPtr(unsigned int  mm);
int  ReleasePtr(unsigned int  mm);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  TUTORdealloc(char  FAR *ptr);
int  TUTORtrace(char  *s);
void  check_wordorder(void);
void  clear_index_expr_machine(struct  tmp_expr_node FAR *node);
void  clear_index_machine(void);
void  clear_index_punct_machine(void);
void  clear_index_tag_tokens_twin(void);
void  clear_machine(void);
void  concept_response(int  index_source,int  index_target);
void  create_machine(void);
void  free_expr_machine(struct  tmp_expr_node FAR *node);
void  free_machine(void);
void  free_punct_machine(void);
void  free_twins_tag(void);
void  free_twins_user_input(void);
void  init_expr_machine(void);
void  init_info_blocks(void);
void  init_output_text(void);
void  init_punct_machine(void);
void  init_twin_tag(void);
void  init_twin_user(void);
void  link_twins(void);
int  nr_tag_tokens(void);
int  nr_user_tokens(void);
void  parse_answer(void);
void  parse_user_input(void);
void  put_tag(char  FAR *answer_tag);
void  put_user_input(char  FAR *student_input);
void  read_vocab(void);
void  show_output(void);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
char  *strf2n(char  FAR *strp);
struct  tmp_expr_node FAR *top_expr_node(void);
#endif /* ctproto */

extern char *strf2n();

#ifdef PROTO
#include <conio.h>
#include <process.h>
#endif

#include "judge.h"

unsigned char dummy[64];
int idummy;
unsigned char FAR *error_msg;
int stop_answer;

int machine_handle;

unsigned char FAR *vocab_text;
char empty_string[] = "";

int nr_mandatory;

int nomark   = FALSE,
    nookno   = TRUE,
    noops    = TRUE,
    nospell  = FALSE,
    okcaps   = FALSE,
    okextra  = FALSE,
    okorder  = FALSE,
    okspell  = FALSE,
    punc     = TRUE,
    novars   = TRUE,
    okassign = FALSE;

int cyclus;

extern Tword ui_word;
extern Tword tag_word;

#define ESC 0x1b


struct sline FAR *match;
unsigned char FAR *output_cT;
int output_index;


int wait_key();
void free_tag();



/* *********************************************************************** */
/* Remove all information captured in connection with the user-input, but  */
/* keep all tag information                                                */
/*                                                                         */
/* Execute this routine after a comparison of a tag and a user-input has   */
/* been done.                                                              */
/* *********************************************************************** */
void clear_index_tag()
{
    clear_index_tag_tokens_twin();
    clear_index_machine();
    clear_index_expr_machine(top_expr_node());
    clear_index_punct_machine();
}
/* clear_index_tag */



/* *********************************************************************** */
/* Remove all information concerning a tag from memory                     */
/* *********************************************************************** */
void clear_tag()
{
    clear_machine();
    free_punct_machine();
    free_expr_machine(top_expr_node());
    free_twins_tag();
}
/* clear_tag */


/* *********************************************************************** */
void clear_index_user()
{
}
/* clear_index_user */


/* *********************************************************************** */
void clear_index_answer()
{
    clear_index_tag();
    clear_index_user();
}
/* clear_index_answer */


/* *********************************************************************** */
void free_tag()
{
    free_twins_tag();
}
/* free_tag */


/* *********************************************************************** */
void free_user()
{
    free_twins_user_input();

    TUTORdealloc((char FAR *)ui_word.letters);
    TUTORdealloc((char FAR *)tag_word.letters);
}
/* free_user */



/* *********************************************************************** */
void free_answer()
{
    free_machine();
    free_expr_machine(top_expr_node());
    free_punct_machine();
}
/* free_answer */


/* *********************************************************************** */
void init_user()
{
    nomark   = FALSE;
    nookno   = TRUE;
    noops    = TRUE;
    nospell  = FALSE;
    okcaps   = FALSE;
    okextra  = FALSE;
    okorder  = FALSE;
    okspell  = FALSE;
    punc     = TRUE;
    novars   = TRUE;
    okassign = FALSE;

    /* output parameters */


    init_twin_user();
    init_output_text();

}
/* init_user */


/* *********************************************************************** */
void init_tag()
{
    nr_mandatory = 0;
    init_twin_tag();
}
/* init_tag */


/* *********************************************************************** */
void init_answer()
{
    /* error message will need some change for use within cT */
    error_msg = (unsigned char FAR *)TUTORalloc((long)(sizeof(unsigned char)*80), TRUE, "anserror");
    strcpyf((char FAR *) error_msg, (char FAR *) empty_string);
    
    init_info_blocks();
    init_punct_machine();
    init_expr_machine();
    create_machine();

    read_vocab();
}
/* init_answer */





/* *********************************************************************** */
/* pm = 'pattern matching' (sorry for the short name, it comes from the    */
/* old version of the answer judger).                                      */
/*                                                                         */
/* The input consists of the student-input and the tag of and -answer- or  */
/* -wrong- command. The ouput consists of updated judging parameters and   */
/* the markup information.                                                 */
/* *********************************************************************** */
struct sline FAR *n_pm(student_input, answer_tag)
char FAR *student_input;
char FAR *answer_tag;
{   
    machine = (Tstate FAR *)GetPtr(machine_handle);  /* Recover WordBox */
    match = (struct sline FAR *)TUTORalloc((long)(sizeof(struct sline)),TRUE,"ansmatch");
    
    TUTORtrace("start answer");
    init_tag();
    put_tag(answer_tag);
    parse_answer();
    
    /* Handle Student-Input */
    init_user();
    put_user_input(student_input);
    parse_user_input();
    
    link_twins();
    
    if (!stop_answer)
    {
        check_wordorder ();
        concept_response(nr_user_tokens(),nr_tag_tokens());
        show_output();
    }
    else
    {
        TUTORtrace("ERROR: ");
        TUTORtrace(strf2n((char FAR *) error_msg));
    };
    
    free_user();
    clear_tag();
    
    ReleasePtr(machine_handle);
    
    TUTORtrace("end answer");
    return(match);
}
/* main */
