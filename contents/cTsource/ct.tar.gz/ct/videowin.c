/* Video For Windows and QuickTime support */

#include <windows.h>
#include <vfw.h>
#include <mmsystem.h>
#include <digitalv.h>
#include <string.h>

#include "execdefs.h"
#include "eglobals.h"
#include "tglobals.h"
#include "tfiledef.h"
#include "exprdefs.h"
#include "kglobals.h"
#include "video.h"
  
extern long qtProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam);
extern int qtMovieOpen(char *moviePath);
extern int qtMovieClose(int type);
extern int qtMovieSound(double value);
extern int qtMovieInfo(int *width,int *height,double *length,int *isplay); 
extern int qtMovieRectangle(int modeF,int x1,int y1,int x2,int y2,int cx1,int cy1,int cx2,int cy2,int cVis);
extern int qtMovieLoop(int doLoop);
extern int qtMoviePaletteUse(int useIt);
extern int qtMovieHalt(void);
extern int qtMovieShow(double showTime);
extern int qtMoviePlay(double fromTime,double toTime);
extern int qtMovieStep(long nSteps);
extern double qtMovieGetTime(void);
            
extern void cTReleaseDC(HWND hWnd,HDC hDC);
extern HDC cTGetDC(HWND hWnd);
extern int MoviePalette(void);
int RealizeCTPalette(Memh pal,int newF);
extern long TUTORinq_msec_clock(void);
extern int TUTORpoll_events(int block);
extern unsigned int TUTORhandle(char  *name,long  size,int  purgewmrm);
extern int ReleasePtr(unsigned int  mm);
extern char FAR *GetPtr(unsigned int  mm);
extern int TUTORfree_handle(Memh mm);
extern int TUTORzero(char FAR *ptr,long lth);
extern int TUTORsound(struct  _fref FAR *fRef,long  soundid);
extern char FAR *strcpyf(char FAR *s1,char FAR *s2);
extern int  marker_file_name(struct  markvar FAR *mx,struct  _fref FAR *fullRef,int  symbolic);
extern int  ReleasePtr(unsigned int  mm);
extern char  FAR *GetPtr(unsigned int  mm);
extern int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
extern int  TUTORfile_exists(struct  _fref FAR *fRef);
extern char *CtoPstr(char *ss);
extern char *PtoCstr(char *ss);
extern int TUTORclose(int findx);
extern int  lclocy(long  q);
extern int  lclocx(long  q);
extern HPALETTE cvtLogPal(Memh paletteH);

BOOL initAVI(void);
int termAVI(void);
int MovieSupport(void);
int MovieOpen(FileRef *fRef);
int MovieClose(int type);
int MovieHalt(void);
int MovieShow(double mTime);
int MovieStep(long nSteps);
int MovieRectangle(int mode,int x1,int y1,int x2,int y2,
       int cx1,int cy1,int cx2,int cy2,int cVis);
double MovieGetTime(void);
int MoviePlay(double from,double to);
int MovieInfo(int *width,int *height,double *length,int *isplay);
int MovieSound(double volume);
int MovieLoop(int loopV);
int MovieController(HWND hWnd,RECT rcControl);
int moveThumb(HWND hWnd,long newPos);
long vControlProc(HWND hWnd,UINT message,WPARAM wParam,LPARAM lParam);
int displayButton(HWND hWnd);

/* ------------------------------------------------------------------- */

extern HWND FirstWinH; /* handle on first window created */
extern HANDLE hcTInst; /* current instance of cT */
extern Memh thePaletteH; /* logical palette */
extern LPLOGPALETTE thePaletteP; /* pointer to logical palette */
extern HDC CurrentDC; /* current window's device context */
extern HWND CurrentWinH; /* handle on current window */
extern int HaveDC; /* TRUE if have device context */

extern int leftDown;  /* TRUE if left button currently down */
extern int rightDown; /* TRUE if right button currently down */
extern int lastMouseX; /* current mouse position */
extern int lastMouseY;
extern int MillionsColor; /* TRUE if TrueColor */

extern int qtMovieOpenF; /* TRUE if QuickTime movie open */

/* ------------------------------------------------------------------- */

typedef DWORD (FAR PASCAL *VFWVERS)(void);
typedef HWND (FAR _cdecl _loadds *VFWWND)(HWND hwndParent, HINSTANCE hInstance,
		      DWORD dwStyle,LPSTR szFile);

int movieCtrlH = 18; /* height of movie controller */
int vid_kind = -1;
BOOL fMovieOpen = 0; /* 0 = nothing open, 1 = movie open, 2 = sound open */
BOOL fMovieControl = 0; /* TRUE if movie controller present */
HWND hwndMovie = NULL; /* window handle of the movie */
BOOL movieInhibitF = 0; /* TRUE if movie controller object inhibited */
BOOL moviePaletteUseF = 0; /* TRUE if should use movie palette */
BOOL mControllerHasPalette = 0; /* TRUE if controller has control of palette */
double movieSoundV = -1.0; /* movie sound volume */
int fMoviePlaying = 0; /* TRUE if play in progress */

static MCIDEVICEID wMCIDeviceID; /* MCI Device ID */
static RECT rcMovie; /* the rect where the movie is positioned */
static RECT valRect; /* rectangle to validate */
static BOOL fDriver = FALSE; /* AVI driver flag: TRUE = driver opened */
static BOOL fMovieSound = TRUE; /* current desired sound state */
static BOOL fSoundSet = TRUE; /* last movie sound state actually set */
static BOOL fMovieRect = FALSE; /* TRUE if movie rectangle set up */
static BOOL fMovieLoop = FALSE; /* TRUE if movie automatically loops */
static HANDLE hDynLib = NULL; /* handle on msvideo dynamic link lib */
static long movieStartMsec; /* msec time movie started */
static double lastTime; /* last time reached in movie */
static double movieDuration; /* length of movie */
static double nativeVolume = 100.0; /* movie native sound volume level */
static RECT nativeRect; /* native size of movie */
static Memh movieNameH = HNULL; /* handle on movie file name */
static double moviePlayBegin; /* time at which current play begins */
static double moviePlayEnd; /* time at which current play ends */
static long lastUpdate = 0; /* last time controller updated */

static RECT rcCtrl; /* rectangle for entire controller */
static RECT rcPlay; /* rectangle for play button */
static RECT rcTrack; /* rectangle for thumb track */
static RECT rcBack; /* rectangle for back button */
static RECT rcFwd; /* rectangle for forward button */
static HBITMAP Thumb1 = NULL; /* bitmap of thumb (normal) */
static HBITMAP Thumb2 = NULL; /* bitmap of thumb (selected) */
static HBITMAP Track1 = NULL; /* bitmap of track (left) */
static HBITMAP Track2 = NULL; /* bitmap of track (center) */
static HBITMAP Track3 = NULL; /* bitmap of track (right) */

static long thumbPos; /* current controller thumb position */
static int thumbX; /* current controller x co-ordinate */
static char downInPlay; /* TRUE if left-down in play button */
static char downInThumb; /* TRUE if left-down in thumb */
static char downInTrack; /* TRUE if left-down in track */
static char downInBack; /* TRUE if left-down in back button */
static char downInFwd; /* TRUE if left-down in forward button */

/* ------------------------------------------------------------------- */

int MovieOpen(fRef) /* open movie file for play */
FileRef *fRef; /* movie file */

{   int fileid; /* cT index of movie file */
    struct tutorfile FAR *fP; /* pointer to file table entry */
    char namestr[CTPATHLEN]; /* full path to file */
    char FAR *movieNameP; /* pointer to movie file name string */
    HWND hWnd; /* handle on executor window */
    MCI_DGV_OPEN_PARMS mciOpen;
    MCI_DGV_RECT_PARMS mciRect;
    MCI_DGV_SET_PARMS mciSet;
    MCI_DGV_STATUS_PARMS mciStatus;
    int ii;
    int isMOV; /* TRUE if QuickTime movie */

    MovieClose(1); /* close current movie */

    /* open movie file */

    fileid = TUTORopen((FileRef FAR *)fRef,TRUE,FALSE,FALSE);
    if (fileid <= 0) 
        return(FILEMISSING);
    fP = fileid+(struct tutorfile FAR *)GetPtr(filesopen);
    namestr[0] = fRef->drive+'A'-1;
    namestr[1] = ':';
    strcpyf((char FAR *)&namestr[2],fP->fRef.path);
    ReleasePtr(filesopen);
    TUTORclose(fileid);

    /* save movie file name */

    movieNameH = TUTORhandle("movie",(long)CTPATHLEN,TRUE);
    if (!movieNameH)
		return(FILEMEM);
    movieNameP = GetPtr(movieNameH);
    strcpyf(movieNameP,(char FAR *)&namestr[0]);
    ReleasePtr(movieNameH);

    isMOV = FALSE;
    ii = strlen(namestr);
    if (ii > 4) {
		ii -= 4;
		if ((strcmp(&namestr[ii],".mov") == 0) ||
			(strcmp(&namestr[ii],".MOV") == 0))
			isMOV = TRUE;
    }

	/* transfer to QuickTime if *.mov file */

	if (isMOV)
		return(qtMovieOpen(namestr));

    hwndMovie = NULL;
    initAVI();
    if (!fDriver)
		return(FILENOTSUP); /* cant set up VfW */

    /* set up open command */

    TUTORzero((char FAR *)&mciOpen,(long)sizeof(MCI_DGV_OPEN_PARMS));
    hWnd = (HWND)windowsP[ExecWn].wp;
    mciOpen.dwCallback = (DWORD)NULL;
    mciOpen.wDeviceID = 0;
    mciOpen.lpstrDeviceType = NULL;
	if (isMOV)
		mciOpen.lpstrDeviceType = "QTWVideo"; 
    mciOpen.lpstrElementName = namestr;
    mciOpen.lpstrAlias = NULL;
    mciOpen.dwStyle = WS_CHILD;
    mciOpen.hWndParent = hWnd;

    /* try to open the file via AVI */
	
    if (mciSendCommand(0, MCI_OPEN,(DWORD)(MCI_OPEN_ELEMENT |
	                   MCI_DGV_OPEN_PARENT | MCI_DGV_OPEN_WS),
	                  (DWORD)(LPMCI_DGV_OPEN_PARMS)&mciOpen) == 0){
		wMCIDeviceID = mciOpen.wDeviceID; /* pick up device ID */
    } else
		return(FILEMISSING); /* didn't work */

    /* set to work in milliseconds */

    mciSet.dwTimeFormat = MCI_FORMAT_MILLISECONDS;
    mciSendCommand(wMCIDeviceID,MCI_SET,(DWORD)MCI_SET_TIME_FORMAT,
		  (DWORD)(LPMCI_DGV_SET_PARMS)&mciSet);

    /* get duration of movie */

    mciStatus.dwItem = MCI_STATUS_LENGTH;
    mciSendCommand(wMCIDeviceID,MCI_STATUS,(DWORD)MCI_STATUS_ITEM,
		  (DWORD)(LPMCI_DGV_STATUS_PARMS)&mciStatus);
    movieDuration = mciStatus.dwReturn/1000.0;

    /* get native size */
	  
    mciSendCommand(wMCIDeviceID, MCI_WHERE,
                  (DWORD)(MCI_DGV_WHERE_SOURCE), 
		  (DWORD)(LPMCI_DGV_RECT_PARMS) &mciRect);
    nativeRect = mciRect.rc;

    fMovieOpen = 1;
    lastTime = 0.0;
    moviePlayBegin = 0.0;
    fMovieRect = FALSE; /* no rectangle yet */

    MovieLoop(FALSE);

    return(-1); /* all ok */

} /* MovieOpen */

/* ------------------------------------------------------------------- */

int MovieClose(type) /* close current movie */
int type; /* 0 = close driver */ 
          /* 1 = close movie file */

{   MCI_GENERIC_PARMS  mciGeneric;
    HWND hWnd; /* handle on executor window */

    MovieHalt(); /* halt movie if playing */

    if (movieNameH)
		TUTORfree_handle(movieNameH);
    movieNameH = HNULL;

	if (qtMovieOpenF)
		return(qtMovieClose(type));

    if (Track1)
		DeleteObject(Track1);
	if (Track2)
		DeleteObject(Track2);
	if (Track3)
		DeleteObject(Track3);
    if (Thumb1)
		DeleteObject(Thumb1);
	if (Thumb2)
		DeleteObject(Thumb2);
    Track1 = Track2 = Track3 = Thumb1 = Thumb2 = NULL;

    if (fMovieOpen) {
		TUTORzero((char FAR *)&mciGeneric,(long)sizeof(MCI_GENERIC_PARMS));
		mciSendCommand(wMCIDeviceID,MCI_CLOSE,0L,
                 (DWORD)(LPMCI_GENERIC_PARMS)&mciGeneric);
		fMovieOpen = 0;
		wMCIDeviceID = 0;
		hwndMovie = NULL;
		if (fMovieRect) {
			hWnd = (HWND)windowsP[ExecWn].wp;
			ValidateRect(hWnd,(RECT FAR *)&valRect);
		} /* fMovieRect */
    }
    if (mControllerHasPalette) /* restore cT's palette */
		RealizeCTPalette((Memh)windowsP[ExecWn].paletteH,TRUE);
    mControllerHasPalette = 0;

    if (type == 0)
		termAVI(); /* close device driver */
    fMovieControl = 0;

    return(-1);

} /* MovieClose */

/* ------------------------------------------------------------------- */

int MovieHalt(void) /* halt currently playing movie */

{   MCI_GENERIC_PARMS  mciGeneric;
    HWND hWnd; /* handle on executor window */

	if (qtMovieOpenF)
		return(qtMovieHalt());

    fMoviePlaying = FALSE;
    if (fMovieOpen == 1) { /* movie */
		TUTORzero((char FAR *)&mciGeneric,(long)sizeof(MCI_GENERIC_PARMS));
		mciSendCommand(wMCIDeviceID,MCI_STOP /* | MCI_WAIT */,0L,
		 (DWORD)(LPMCI_GENERIC_PARMS)&mciGeneric);
		MovieGetTime(); 
		if (fMovieRect) {
			hWnd = (HWND)windowsP[ExecWn].wp;
			ValidateRect(hWnd,(RECT FAR *)&valRect);
		}
		SetTimer(FirstWinH,1,55,(TIMERPROC)FARNULL); /* restore timer */
    }

    return(-1);
	
} /* MovieHalt */

/* ------------------------------------------------------------------- */

int MovieRectangle(mode,x1,y1,x2,y2,cx1,cy1,cx2,cy2,cVis) /* set up rectangle for movie play */
int mode; /* 0 = clip, 1 = scale, 2 = center */
int x1,y1; /* upper left of rectangle */
int x2,y2; /* lower right of rectangle */
int cx1,cy1; /* upper left of controller rectangle */
int cx2,cy2; /* lower left of controller rectangle */
int cVis;

{   RECT rcKludge, rcMovieBounds;
    MCI_DGV_RECT_PARMS mciRect;
    HWND hWnd; /* handle on executor window */
    MCI_DGV_WINDOW_PARMS mciWindow;
    MCI_DGV_STATUS_PARMS mciStatus;
    MCI_OVLY_RECT_PARMS mciPut;
    DWORD dwFlags;
    DWORD mciRet; /* command return */
    int mwidth,mheight; /* movie width, height */
    int swidth,sheight; /* screen width, height */

	if (qtMovieOpenF)
		return(qtMovieRectangle(mode,x1,y1,x2,y2,cx1,cy1,cx2,cy2,cVis));

    if (!fMovieOpen)
       return(FILEMISSING);

    if (fMovieRect)
		return(FILEDUP);

    if ((x1 > x2) || (y1 > y2)) /* allow zero width,height */
		return(FILEREGION);

    MoviePalette();

    exS.vidX1 = x1; /* remember video rectangle */
    exS.vidY1 = y1;
    exS.vidX2 = x2;
    exS.vidY2 = y2;
    exS.vidMode = mode;

    hWnd = (HWND)windowsP[ExecWn].wp; /* get executor window */
    GetClientRect(hWnd, &rcKludge);	/* get the parent windows rect */

    if (!hwndMovie) {
	  
		/* show the playback window */
        
		mciWindow.dwCallback = (DWORD)NULL;
		mciWindow.hWnd = NULL;
		mciWindow.nCmdShow = SW_SHOW;
		mciWindow.lpstrText = (LPSTR)NULL;
		mciRet = mciSendCommand(wMCIDeviceID, MCI_WINDOW,
			   (DWORD)MCI_DGV_WINDOW_STATE,
	                   (DWORD)(LPMCI_DGV_WINDOW_PARMS)&mciWindow);

		/* get the window handle */
		
		if (mciRet == 0) {
			mciStatus.dwItem = MCI_DGV_STATUS_HWND;
			mciRet = mciSendCommand(wMCIDeviceID,MCI_STATUS,(DWORD)MCI_STATUS_ITEM,
				   (DWORD)(LPMCI_STATUS_PARMS)&mciStatus);
			if (mciRet == 0)
			hwndMovie = (HWND)mciStatus.dwReturn;
		}
    } /* !hwndMovie if */

    if (!hwndMovie)
		return(FILEMISSING); /* something went wrong */
		
    /* get the original size of the movie */

    mciRet = mciSendCommand(wMCIDeviceID, MCI_WHERE, 
                  (DWORD)(MCI_DGV_WHERE_SOURCE), 
                  (DWORD)(LPMCI_DGV_RECT_PARMS)&mciRect);
    if (mciRet)
		return(FILEMISSING); /* something went wrong */
		
    rcMovieBounds = mciRect.rc;	/* get the movie bounds rect */
    mwidth = rcMovieBounds.right;
    mheight = rcMovieBounds.bottom;
    swidth = x2-x1;
    sheight = y2-y1;

    /* preset rectangle */

    rcMovie.left = x1;
    rcMovie.top = y1;
    rcMovie.right = x2;
    rcMovie.bottom = y2;

    if (mode == 0) { /* clip */
		if (swidth > mwidth) rcMovie.right = x1+mwidth;
		if (sheight > mheight) rcMovie.bottom = y1+mheight;
    } else if (mode == 1) { /* scale */
		; /* rectangle already set */
    } else if (mode == 2) { /* center */
		if (swidth >= mwidth) {
			rcMovie.left = x1+(((x2-x1)-mwidth)/2);
			rcMovie.right = rcMovie.left+rcMovieBounds.right;
		}
		if (sheight >= mheight) {
			rcMovie.top = y1+(((y2-y1)-mheight)/2);
			rcMovie.bottom = rcMovie.top+rcMovieBounds.bottom;
		}
    }
 
    /* reposition the playback (child) window */

	valRect = rcMovie;
	valRect.left -= 1;
	if (valRect.left < 0) valRect.left = 0;
	valRect.top -= 1;
	if (valRect.top < 0) valRect.top = 0;
	valRect.right += 1;
	valRect.bottom += 1;
    MoveWindow(hwndMovie, rcMovie.left, rcMovie.top,
               rcMovie.right-rcMovie.left, rcMovie.bottom-rcMovie.top, TRUE);
    if ((mode == 0) || (mode == 2)) { /* clip or center */
		if ((swidth < mwidth) || (sheight < mheight)) {
			mciPut.dwCallback = (DWORD)NULL;
			mciPut.rc.left = mciPut.rc.top = 0;
			if (mode == 2) {
				if (swidth < mwidth)
					mciPut.rc.left += (mwidth-swidth)/2;
				if (sheight < mheight)
					mciPut.rc.top += (mheight-sheight)/2;
			} /* mode == 2 */
			mciPut.rc.right = mciPut.rc.left+swidth;
			mciPut.rc.bottom = mciPut.rc.top+sheight;
			dwFlags = MCI_DGV_RECT | MCI_DGV_PUT_SOURCE | MCI_WAIT;
			mciSendCommand(wMCIDeviceID, MCI_PUT, dwFlags,
            	  (DWORD)(LPMCI_OVLY_RECT_PARMS)&mciPut);
			ValidateRect(hWnd,(RECT FAR *)&mciPut.rc);
		} /* width if */
    } /* mode if */
    ValidateRect(hWnd,(RECT FAR *)&valRect);
    ValidateRect(hWnd,(RECT FAR *)&mciRect.rc);

	/* horrible kludge - validate everything */
	rcKludge.right = rcKludge.left = 0;
	rcKludge.right = windowsP[ExecWn].wxsize-1;
	rcKludge.bottom = windowsP[ExecWn].wysize-1;
	ValidateRect(hWnd,(RECT FAR *)&rcKludge); 

    fMovieRect = TRUE;

    if (cVis) {
		rcCtrl.left = cx1; /* rectangle for entire controller */
		rcCtrl.top = cy1;
		rcCtrl.right = cx2;
		rcCtrl.bottom = cy2;
		MovieController(hWnd,rcCtrl);
    }

    return(-1);

} /* MovieRectangle */

/* ------------------------------------------------------------------- */

MovieLoop(vv)
int vv;

{
	if (qtMovieOpenF)
		return(qtMovieLoop(vv));

    fMovieLoop = vv;
    return(0);

} /* MovieLoop */

/* ------------------------------------------------------------------- */

int MoviePaletteUse(useIt) /* set to use / not use movie palette */
int useIt;

{
	if (qtMovieOpenF)
		return(qtMoviePaletteUse(useIt));

    if (MillionsColor)
		useIt = FALSE; /* no need if TrueColor */
    moviePaletteUseF = useIt;
    return(-1);
	
} /* MoviePaletteUse */

/* ------------------------------------------------------------------- */

int MovieInfo(width,height,length,isplay) /* return info on current movie */
int *width; /* native width of movie (pixels) */
int *height; /* native height of movie (pixels) */
double *length; /* length of movie (seconds) */
int *isplay; /* TRUE if movie is playing */

{   MCI_DGV_STATUS_PARMS mciStatus;

	if (qtMovieOpenF)
		return(qtMovieInfo(width,height,length,isplay));

    if (width)
		*width = nativeRect.right-nativeRect.left;
    if (height)
		*height = nativeRect.bottom-nativeRect.top;
    if (length)
		*length = movieDuration;
    if (isplay) {
		*isplay = 0; /* pre-set not playing */
		mciStatus.dwItem = MCI_STATUS_MODE;
		mciSendCommand(wMCIDeviceID,MCI_STATUS,(DWORD)MCI_STATUS_ITEM,
		  (DWORD)(LPMCI_DGV_STATUS_PARMS)&mciStatus);
		if ((mciStatus.dwReturn == MCI_MODE_PLAY) ||
			(mciStatus.dwReturn == MCI_MODE_SEEK))
			*isplay = TRUE;
    } /* isplay if */
    return(0);

} /* MovieInfo */

/* ------------------------------------------------------------------- */

int MoviePlay(ffrom,fto) /* play specified section of movie */
double ffrom; /* starting time, -1 = start from current position */
double fto; /* ending time, -1 = play to end of movie */

{   long from; /* starting position (milliseconds) */
    long to; /* ending position (milliseconds) */
    long duration; /* play duration (milliseconds) */
    int wholeMovie; /* TRUE if playing whole movie */
    MCI_DGV_PLAY_PARMS mciPlay;
    DWORD dwFlags;
    DWORD mciRet; /* mciSendCommand return */
    HWND hWnd;

	if (qtMovieOpenF)
		return(qtMoviePlay(ffrom,fto));

    if (fMovieOpen != 1)
		return(FILEMISSING); /* can't play if no movie */
    if (!fMovieRect)
		return(FILEPARAMETER); /* can't play if no rectangle */

    MovieHalt(); /* stop currently playing movie */
    wholeMovie = ((ffrom <= 0.0) && ((fto < 0.0) || (fto > movieDuration)));

    /* convert to/from to movie times */
	
    if (ffrom < 0) /* limit to movie range */
		ffrom = MovieGetTime();
    if (ffrom > movieDuration)
		ffrom = movieDuration;
    if (fto < 0.0)
		fto = movieDuration;
    if (fto > movieDuration)
		fto = movieDuration;
    from = round(ffrom*1000.0); /* convert to milliseconds */
    to = round(fto*1000.0); /* convert to milliseconds */
    duration = to-from;

    MovieSound(movieSoundV); /* set volume level */
    movieStartMsec = TUTORinq_msec_clock();
    moviePlayBegin = (double)(from)/1000.0;
    moviePlayEnd = (double)(to)/1000.0;

    hWnd = (HWND)windowsP[CurrentWindow].wp;
    mciPlay.dwCallback = MAKELONG(hWnd,0);
    dwFlags = MCI_NOTIFY;
    if (wholeMovie) {
		mciPlay.dwFrom = mciPlay.dwTo = 0;
    } else {
		mciPlay.dwFrom = from;
		mciPlay.dwTo = to;
		dwFlags |= MCI_FROM | MCI_TO;
    }
    mciRet = mciSendCommand(wMCIDeviceID, MCI_PLAY, dwFlags,
	      (DWORD)(LPMCI_DGV_PLAY_PARMS)&mciPlay);
    fMoviePlaying = TRUE;
    SetTimer(FirstWinH,1,200,(TIMERPROC)FARNULL); /* slow down timer */

    return(-1);

} /* MoviePlay */

/* ------------------------------------------------------------------- */

int MovieStep(nSteps) /* step forwards or backwards n frames */
long nSteps;

{   int direction; /* + = step forward, - = step backwards */
    MCI_SET_PARMS mciSet;
    MCI_DGV_STEP_PARMS mciStep;

	if (qtMovieOpenF)
		return(qtMovieStep(nSteps));

    if (fMovieOpen != 1)
		return(FILEMISSING); /* can't play if no movie */
    if (!fMovieRect)
		return(FILEPARAMETER); /* can't play if no rectangle */

    MovieHalt(); /* stop movie if currently playing */
    if (nSteps == 0)
		return(-1); /* done if no frame count */

    if (nSteps > 0) {
		direction = 1;
    } else {
		direction = -1;
		nSteps = -nSteps;
    }

    /* set time format to work in frames */
	
    mciSet.dwTimeFormat = MCI_FORMAT_FRAMES;
    mciSendCommand(wMCIDeviceID,MCI_SET,(DWORD)MCI_SET_TIME_FORMAT,
		   (DWORD)(LPMCI_SET_PARMS)&mciSet);

    while (nSteps) {
		mciStep.dwFrames = 1L;
		if (direction > 0)
			mciSendCommand(wMCIDeviceID, MCI_STEP, MCI_DGV_STEP_FRAMES,
		   (DWORD)(LPMCI_DGV_STEP_PARMS)&mciStep);
		else
			mciSendCommand(wMCIDeviceID, MCI_STEP, 
		   MCI_DGV_STEP_FRAMES|MCI_DGV_STEP_REVERSE,
		   (DWORD)(LPMCI_DGV_STEP_PARMS)&mciStep);
		nSteps--;
    } /* nSteps while */

    /* set time format to work in milliseconds */
	
    mciSet.dwTimeFormat = MCI_FORMAT_MILLISECONDS;
    mciSendCommand(wMCIDeviceID,MCI_SET,(DWORD)MCI_SET_TIME_FORMAT,
		   (DWORD)(LPMCI_SET_PARMS)&mciSet);
    return(-1);

} /* MovieStep */

/* ------------------------------------------------------------------- */

int MovieShow(showTime) /* show single still frame */
double showTime; /* time of frame to show */

{   double soundSetting; /* current sound setting */

	if (qtMovieOpenF)
		return(qtMovieShow(showTime));

    if (fMovieOpen != 1)
		return(FILEMISSING); /* can't play if no movie */
    if (!fMovieRect)
		return(FILEPARAMETER); /* can't play if no rectangle */

    soundSetting = movieSoundV;
    MovieSound(0.0); /* turn off sound */
    MovieHalt(); /* stop currently playing movie */

    if (showTime > movieDuration)
		showTime = movieDuration;
    if (showTime < 0.0)
		showTime = 0.0;

    MoviePlay(showTime,showTime); /* display the frame */

    MovieSound(soundSetting); /* restore sound volume */

    fMoviePlaying = FALSE; /* not really playing */
    return(-1);

} /* MovieShow */

/* ------------------------------------------------------------------- */

int MovieSound(volume) /* set movie sound level */
double volume; /* -1 = default, 0 = off, 100 = max */

{   int iVolume;
    MCI_DGV_SETAUDIO_PARMS mciAudio;

	qtMovieSound(volume);

    if (volume < 0.0)
		volume = nativeVolume;
    if (volume > 100.0)
		volume = 100.0;
    movieSoundV = volume;

    if (fMovieOpen) {
		iVolume = (int)(volume*10.0); /* convert 0-100 to 0-1000 */
		mciAudio.dwItem = MCI_DGV_SETAUDIO_VOLUME;
		mciAudio.dwValue = iVolume;
		mciSendCommand(wMCIDeviceID,MCI_SETAUDIO,(DWORD)MCI_DGV_SETAUDIO_ITEM,
		  (DWORD)(LPMCI_DGV_SET_PARMS)&mciAudio);
    }
    return(-1);

} /* MovieSound */

/* ------------------------------------------------------------------- */

double MovieGetTime(void) /* return current position of movie */

{   DWORD mciRet;
    long elapsed; /* elapsed time */
    MCI_DGV_STATUS_PARMS mciStatus;

	if (qtMovieOpenF)
		return(qtMovieGetTime());

    if (!fMovieOpen)
		return(lastTime);

    if (fMovieOpen) {
	mciStatus.dwItem = MCI_STATUS_POSITION;
	mciSendCommand(wMCIDeviceID,MCI_STATUS,(DWORD)MCI_STATUS_ITEM,
		  (DWORD)(LPMCI_DGV_STATUS_PARMS)&mciStatus);
	mciRet = mciStatus.dwReturn;
    }
    if (mciRet & 0xf0000000L)
	mciRet = 0; /* ? sometimes get junk, 1st time */
    lastTime = (double)(mciRet)/1000.0;
    /* final position is sometimes at least 3 msec off */
    /* observed on QuickTime for Windows */
    if (lastTime >= (movieDuration-0.009))
	lastTime = movieDuration;

    if (lastTime < 0.0) {
	elapsed = TUTORinq_msec_clock()-movieStartMsec;
	lastTime = moviePlayBegin+(elapsed/1000.0);
    }

    return(lastTime);

} /* MovieGetTime */

/* ------------------------------------------------------------------- */

int MoviePalette()

{   MCI_GENERIC_PARMS mciReq;

    if (!moviePaletteUseF || (fMovieOpen != 1)) return(0);

    mControllerHasPalette = TRUE;
    mciSendCommand(wMCIDeviceID,MCI_REALIZE,(DWORD)MCI_DGV_REALIZE_NORM,
		  (DWORD)(LPMCI_DGV_STATUS_PARMS)&mciReq);

    return(0);

} /* MoviePalette */

/* ------------------------------------------------------------------- */

int MovieSupport(void) /* video service routine */

{   long curMsec;
    int inPlay; /* TRUE if movie playing */

    if (fMovieOpen != 1)
	return(0);

    curMsec = TUTORinq_msec_clock();
    if ((curMsec-lastUpdate) < 200L)
	return(0);

    MovieInfo(NEARNULL,NEARNULL,NEARNULL,&inPlay);
    if (!inPlay) {
	SetTimer(FirstWinH,1,55,(TIMERPROC)FARNULL); /* restore timer */
    }
    return(0);

} /* MovieSupport */

/* ******************************************************************* */

BOOL initAVI(void) /* initialize AVI driver */

{   MCI_DGV_OPEN_PARMS mciOpen; /* driver open command */
    DWORD openF;
    UINT winVer; /* windows version */

    if (fDriver)
		return(0); /* already open */

#ifdef NOSUCH /* win 32 now */
    VFWVERS lpProcVers; /* dll function VideoForWindowsVersion */


    /* check if we have VfW 1.1 or better */

    if (!hDynLib)
		hDynLib = LoadLibrary("msvideo.dll");
    if (hDynLib < 32) {
		hDynLib = NULL;
		return(FILENOTSUP); /* library load failed */
    }

    lpProcVers = (VFWVERS)GetProcAddress(hDynLib,MAKEINTRESOURCE(2));
    wVer = HIWORD(lpProcVers());
    FreeLibrary(hDynLib);
    hDynLib = NULL;

    if (wVer < 0x10a) {
		return(FILENOTSUP);
    }
#endif

    /* set up the open parameters */

    TUTORzero((char FAR *)&mciOpen,(long)sizeof(MCI_DGV_OPEN_PARMS));
    mciOpen.dwCallback = (DWORD)NULL;
    mciOpen.wDeviceID = 0;
    mciOpen.lpstrDeviceType = "avivideo";
    mciOpen.lpstrElementName = NULL;
    mciOpen.lpstrAlias = NULL;
    mciOpen.dwStyle = 0;
    mciOpen.hWndParent = NULL;
		 
    /* try to open the driver */
    openF = mciSendCommand(0, MCI_OPEN, (DWORD)(MCI_OPEN_TYPE), 
                          (DWORD)(LPMCI_DGV_OPEN_PARMS)&mciOpen);
    if (openF == 0)
	fDriver = TRUE;

    winVer = LOWORD(GetVersion());
    winVer = (((WORD)(LOBYTE(winVer))) << 8)|(WORD)HIBYTE(winVer);

    return(0);

} /* initAVI */

/* ------------------------------------------------------------------- */

int termAVI(void) /* close AVI driver */

{   WORD wID;
    MCI_GENERIC_PARMS mciClose;

    if (!fDriver) return(0); /* driver not opened */

    wID = mciGetDeviceID("avivideo");
    mciSendCommand(wID,MCI_CLOSE,0L,
		   (DWORD)(LPMCI_GENERIC_PARMS)&mciClose);
    fDriver = FALSE;
    return(0);

} /* termAVI */

/* ------------------------------------------------------------ */

int MovieController(hWnd,rcControl)
HWND hWnd; /* parent window of controller */
RECT rcControl; /* rectangle for controller */

{   HDC hdc; /* device context */
    HDC memDC; /* memory device context */
    HBITMAP origBmp; /* original bitmap */
    HBITMAP Play1; /* play button bitmap */
	HBITMAP Back1; /* back button bitmap */
	HBITMAP Fwd1; /* forward button bitmap */
    BITMAP bm; /* bitmap description */
    int xx; /* x position */

    fMovieControl = TRUE;
    movieInhibitF = 0; /* new controller isn't inhibited */
    downInPlay = downInThumb = downInTrack = downInBack = downInFwd = 0;
    rcControl.bottom = rcControl.top+movieCtrlH-1; /* fixed height */

    hdc = cTGetDC(hWnd);
    memDC = CreateCompatibleDC(hdc);
    if (!Track1)
		Track1 = LoadBitmap(hcTInst,"Track1");
	if (!Track2)
		Track2 = LoadBitmap(hcTInst,"Track2");
	if (!Track3)
		Track3 = LoadBitmap(hcTInst,"Track3");
    if (!Thumb1)
		Thumb1 = LoadBitmap(hcTInst,"Thumb1");
	if (!Thumb2)
		Thumb2 = LoadBitmap(hcTInst,"Thumb2");
    Play1 = LoadBitmap(hcTInst,"Play1");
	Back1 = LoadBitmap(hcTInst,"Back1");
	Fwd1 = LoadBitmap(hcTInst,"Fwd1");
	if (!Track1 || !Track2 || !Track3 || !Thumb1 || !Thumb2
		|| !Play1 || !Back1 || !Fwd1)
		return(0);

    /* draw play button */

    rcPlay.left = rcControl.left;
    rcPlay.right = rcPlay.left+18-1;
    rcPlay.top = rcControl.top;
    rcPlay.bottom = rcPlay.top+18-1;
    origBmp = SelectObject(memDC,Play1);
    GetObject(Play1,sizeof(BITMAP),&bm);
    BitBlt(hdc,rcPlay.left,rcPlay.top,bm.bmWidth,bm.bmHeight,memDC,0,0,SRCCOPY);

    /* draw left of thumb track */

    SelectObject(memDC,Track1);
    GetObject(Track1,sizeof(BITMAP),&bm);
    rcTrack.left = xx = rcPlay.right+1;
    rcTrack.right = rcControl.right-18-18-1;
    rcTrack.top = rcPlay.top;
    rcTrack.bottom = rcTrack.top+bm.bmHeight;
	BitBlt(hdc,xx,rcTrack.top,bm.bmWidth,bm.bmHeight,memDC,0,0,SRCCOPY);
	xx += bm.bmWidth;

	/* draw body of thumb track */

	SelectObject(memDC,Track2);
    while ((xx+bm.bmWidth) <= rcTrack.right) {
		BitBlt(hdc,xx,rcTrack.top,bm.bmWidth,bm.bmHeight,memDC,0,0,SRCCOPY);
		xx += bm.bmWidth;
    }

	/* draw right of thumb track */

	SelectObject(memDC,Track3);
	BitBlt(hdc,rcTrack.right-bm.bmWidth+1,rcTrack.top,bm.bmWidth,bm.bmHeight,memDC,0,0,SRCCOPY);
	xx += bm.bmWidth;

	/* draw back button */

    SelectObject(memDC,Back1);
    GetObject(Back1,sizeof(BITMAP),&bm);
	rcBack.left = rcTrack.right+1;
    rcBack.right = rcBack.left+bm.bmWidth-1;
    rcBack.top = rcControl.top;
    rcBack.bottom = rcBack.top+bm.bmHeight-1;
    BitBlt(hdc,rcBack.left,rcBack.top,bm.bmWidth,bm.bmHeight,memDC,0,0,SRCCOPY);

	/* draw forward button */

    SelectObject(memDC,Fwd1);
    GetObject(Fwd1,sizeof(BITMAP),&bm);
	rcFwd.left = rcBack.right+1;
    rcFwd.right = rcFwd.left+bm.bmWidth-1;
    rcFwd.top = rcControl.top;
    rcFwd.bottom = rcFwd.top+bm.bmHeight-1;
    BitBlt(hdc,rcFwd.left,rcFwd.top,bm.bmWidth,bm.bmHeight,memDC,0,0,SRCCOPY);

    /* draw the thumb */

    SelectObject(memDC,Thumb1);
    GetObject(Thumb1,sizeof(BITMAP),&bm);
    BitBlt(hdc,rcTrack.left,rcTrack.top,bm.bmWidth,bm.bmHeight,memDC,0,0,SRCCOPY);
    thumbPos = 0; /* initialize position */
    thumbX = rcTrack.left;

    SelectObject(memDC,origBmp); /* restore original bitmap */
    DeleteObject(Play1); /* delete play button bitmap */
    DeleteDC(memDC);

    cTReleaseDC(hWnd,hdc);

    MovieShow(0.0); /* initial display */

    return(0);

} /* MovieController */

/* ------------------------------------------------------------ */

long vControlProc(hWnd,message,wParam,lParam)
HWND hWnd; /* window handle */
UINT message; /* type of message */
WPARAM wParam; /* additional message-specific information */
LPARAM lParam; /* additional message-specific information */

{   int didEvent; /* TRUE if processed event here */
    POINT mPt; /* current mouse position */
    RECT tRect; /* target rectangle for thumb, track check */
    BITMAP bm; /* bitmap header */
    MCI_DGV_PLAY_PARMS mciPlay;
    MCI_SEEK_PARMS mciSeek;
    DWORD dwFlags;
    double curPos; /* -1, or current position in play */
    int xPos;
      
    if ((ExecWn < 0) || (!windowsP)) 
    	return(0); /* no executor */

    if (message == WM_TIMER) {
		/* timer message goes to edit window, but we need it too */
		if (windowsP[ExecWn].wp)
	    	hWnd = (HWND)windowsP[ExecWn].wp;
    }

    if (hWnd != (HWND)windowsP[ExecWn].wp)
		return(0);

    if (HaveDC) { /* release device context */
		cTReleaseDC(CurrentWinH,CurrentDC);
		HaveDC = FALSE;
    }

    mPt.x = lastMouseX; /* current mouse position */
    mPt.y = lastMouseY;
    curPos = -1.0;
    didEvent = FALSE; /* preset not our event */

    switch (message) {

    case WM_LBUTTONDOWN:
    	if (!fMovieControl) 
			break;    
			
		/* check for hit on play/stop button */

		if (PtInRect((RECT FAR *)&rcPlay,mPt)) {
	    	downInPlay = didEvent = TRUE; /* start of click on play button */
	    	break;
		}

		/* check for hit on back button */

		if (PtInRect((RECT FAR *)&rcBack,mPt)) {
	    	downInBack = didEvent = TRUE; /* start of click on back button */
			MovieStep(-1L);
			displayButton(hWnd); /* update play/stop button */
			curPos = MovieGetTime();
	    	break;
		}

		/* check for hit on forward button */

		if (PtInRect((RECT FAR *)&rcFwd,mPt)) {
	    	downInFwd = didEvent = TRUE; /* start of click on forward button */
			MovieStep(1L);
			displayButton(hWnd); /* update play/stop button */
			curPos = MovieGetTime();
	    	break;
		}

		/* check for hit on thumb */

		GetObject(Thumb1,sizeof(BITMAP),&bm);
		tRect.left = thumbX;
		tRect.top = rcTrack.top;
		tRect.right = thumbX+bm.bmWidth-1;
		tRect.bottom = rcTrack.bottom;
		if (PtInRect((RECT FAR *)&tRect,mPt)) {
	    	downInThumb = didEvent = TRUE; /* start of click in thumb */
	    	break;
		}

		/* check for hit on track */

		if (PtInRect((RECT FAR *)&rcTrack,mPt)) {
	    	downInTrack = didEvent = TRUE;
		}
		break;

    case WM_LBUTTONUP: 
     	if (!fMovieControl) 
			break;    
		if (downInPlay) {

	    	/* hit on play or stop button */

	    	didEvent = TRUE;
	    	if (PtInRect((RECT FAR *)&rcPlay,mPt)) {
				if (!fMoviePlaying) {

		    		/* send MCI command to play, notify when done */
;
					MoviePlay(-1.0,movieDuration);
#ifdef NOSUCH
		    		mciPlay.dwCallback = MAKELONG(hWnd,0);
		    		dwFlags = MCI_NOTIFY | MCI_TO;
		    		if (MovieGetTime() >= movieDuration)
						dwFlags |= MCI_FROM;
					mciPlay.dwFrom = 0;
					mciPlay.dwTo = round(movieDuration*1000.0); /* convert to milliseconds */
					mciSendCommand(wMCIDeviceID, MCI_PLAY, dwFlags,
					(DWORD)(LPMCI_DGV_PLAY_PARMS)&mciPlay);
					fMoviePlaying = TRUE;
#endif
					/* display stop button */

					displayButton(hWnd);
				} else {
					MovieHalt();
					curPos = MovieGetTime();

					/* display play button */

					displayButton(hWnd);
				} /* fMoviePlaying else */
			} /* PtInRect if */
		} else if ((downInBack) || (downInFwd)) {
			didEvent = TRUE;
		} else if (downInThumb || downInTrack) {

			/* hit on thumb or track - move to indicated position */

			didEvent = TRUE;
			xPos = mPt.x;
			if (xPos <= rcTrack.left)
				xPos = rcTrack.left;
			else if (xPos >= rcTrack.right)
				xPos = rcTrack.right;
			curPos = ((double)(xPos-rcTrack.left)/(rcTrack.right-rcTrack.left))*movieDuration;
			MovieShow(curPos);
		}
		downInPlay = downInThumb = downInTrack = downInBack = downInFwd = FALSE;
		break;

    case WM_MOUSEMOVE:  
		if (!fMovieControl)
    		break;
		if (downInThumb) {
			xPos = mPt.x;
			if (xPos <= rcTrack.left)
				xPos = rcTrack.left;
			else if (xPos >= rcTrack.right)
				xPos = rcTrack.right;
			curPos = ((double)(xPos-rcTrack.left)/(rcTrack.right-rcTrack.left))*movieDuration;
			MovieShow(curPos);
		}
		if (downInThumb || downInTrack || downInPlay)
			didEvent = TRUE;
		break;

	case WM_TIMER: /* timer has fired */
		if (!fMovieControl)
			break; /* nothing to do */
		if (downInBack)
			MovieStep(-1L);
		if (downInFwd)
			MovieStep(1L);
		if (fMoviePlaying || downInBack || downInFwd)
			curPos = MovieGetTime();
		break;

    case MM_MCINOTIFY:
		if (wParam == MCI_NOTIFY_SUCCESSFUL) {
			curPos = MovieGetTime();
			if (fMovieLoop && fMoviePlaying) {
				mciSeek.dwTo = 0;
				mciSendCommand(wMCIDeviceID, MCI_SEEK,
			       MCI_SEEK_TO_START,
			       (DWORD)(LPVOID)&mciSeek);
				mciPlay.dwCallback = MAKELONG(hWnd,0);
				dwFlags = MCI_NOTIFY | MCI_TO;
				mciPlay.dwFrom = 0;
				mciPlay.dwTo = round(movieDuration*1000.0); /* convert to milliseconds */
				mciSendCommand(wMCIDeviceID, MCI_PLAY, dwFlags,
			       (DWORD)(LPMCI_DGV_PLAY_PARMS)&mciPlay);
				fMoviePlaying = TRUE;
			} else {
				fMoviePlaying = FALSE; 
				if (fMovieControl)
					displayButton(hWnd);
			} /* fMovieLoop else */
		}
		didEvent = TRUE;
		break;

    } /* switch */

    if (fMovieControl && (curPos >= 0))
		moveThumb(hWnd,(long)(curPos*1000.0)); /* update controller thumb */

    return(didEvent);

} /* vControlProc */

/* ------------------------------------------------------------ */

static int displayButton(hWnd) /* display play/stop button */
HWND hWnd; /* window handle */

{   BITMAP bm; /* bitmap header */
    HDC hdc; /* device context */
    HDC memDC; /* memory device context */
    HBITMAP origBmp; /* original bitmap */
    HBITMAP spBmp; /* bitmap for stop/play button */

	if (!fMovieControl)
		return(0); /* nothing to do */
    hdc = cTGetDC(hWnd);
    memDC = CreateCompatibleDC(hdc);
    if (!fMoviePlaying) spBmp = LoadBitmap(hcTInst,"Play1");
    else spBmp = LoadBitmap(hcTInst,"Stop1");
    if (spBmp) {
		origBmp = SelectObject(memDC,spBmp);
		GetObject(spBmp,sizeof(BITMAP),&bm);
		BitBlt(hdc,rcPlay.left,rcPlay.top,bm.bmWidth,bm.bmHeight,memDC,0,0,SRCCOPY);
		SelectObject(memDC,origBmp);
		DeleteObject(spBmp);
    }
    DeleteDC(memDC); /* dump memory device context */
    cTReleaseDC(hWnd,hdc); /* release device context */
    return(0);

} /* displayButton */

/* ------------------------------------------------------------ */

static int moveThumb(hWnd,newPos)
HWND hWnd; /* handle on parent window */
long newPos; /* position to move to */

{   int ntX; /* new thumb X position */
    long maxPos; /* limit of range (0-maxPos) */
    int range; /* range (0 - max x thumb pos) of thumb track */
    HDC hdc;
    HDC memDC;
    HBITMAP origBmp; /* original bitmap */
    BITMAP bm;
	HBITMAP doThumb; /* Thumb1 or Thumb2 */

    if (!Track1 || !Track2 || !Track3 || !Thumb1 || !Thumb2)
		return(0); /* ? */

	doThumb = (downInThumb ? Thumb2 : Thumb1);

    hdc = cTGetDC(hWnd);
    memDC = CreateCompatibleDC(hdc);
    maxPos = (long)(movieDuration*1000.0);

    /* draw track behind thumb (at old position) */

    origBmp = SelectObject(memDC,Track2);
	GetObject(Track2,sizeof(BITMAP),&bm);	
    BitBlt(hdc,thumbX,rcTrack.top,bm.bmWidth,bm.bmHeight,memDC,0,0,SRCCOPY);
	if (thumbX < rcTrack.left+bm.bmWidth) { /* restore right */
		SelectObject(memDC,Track1);
		BitBlt(hdc,rcTrack.left,rcTrack.top,bm.bmWidth,bm.bmHeight,memDC,0,0,SRCCOPY);
	}
	if (thumbX > rcTrack.right-bm.bmWidth) { /* restore left */
		SelectObject(memDC,Track3);
		BitBlt(hdc,rcTrack.right-bm.bmWidth+1,rcTrack.top,bm.bmWidth,bm.bmHeight,memDC,0,0,SRCCOPY);
	}

    /* compute new position for thumb */

    GetObject(doThumb,sizeof(BITMAP),&bm);
    range = (rcTrack.right-rcTrack.left)-bm.bmWidth+1;
    ntX = rcTrack.left+(int)(((double)newPos/(double)maxPos)*(double)range);
    if (newPos <= 0)
		ntX = rcTrack.left;
    else if (newPos >= maxPos)
		ntX = rcTrack.right-bm.bmWidth+1;

    /* draw thumb */

    SelectObject(memDC,doThumb);
    BitBlt(hdc,ntX,rcTrack.top,bm.bmWidth,bm.bmHeight,memDC,0,0,SRCCOPY);

    /* clean up */

    SelectObject(memDC,origBmp); /* restore original bitmap */
    DeleteDC(memDC);
    cTReleaseDC(hWnd,hdc);

    thumbPos = newPos; /* update position */
    thumbX = ntX;
    return(0);

} /* moveThumb */

/* ------------------------------------------------------------------- */

int TUTORsound(fRef,soundid) /* play sound file */
struct	_fref FAR *fRef;
long  soundid;
/* returns 0 = ok, else zreturn value */

{   int fileid; /* index of sound file */
    struct tutorfile FAR *fP; /* pointer to file entry */
    char namestr[CTPATHLEN]; /* full path to file */
    MCI_DGV_OPEN_PARMS mciOpen;
    MCI_DGV_SET_PARMS mciSet;
    MCI_DGV_STATUS_PARMS mciStatus;
    MCI_DGV_PLAY_PARMS mciPlay;
    HWND hWnd; /* current window */
    int fii; /* index in file name */
    char *extP; /* pointer to file name extension */

    MovieClose(1); /* close current VfW file */

    /* open movie file */

    fileid = TUTORopen((FileRef FAR *)fRef,TRUE,FALSE,FALSE);
    if (fileid <= 0) 
        return(FILEMISSING);
    fP = fileid+(struct tutorfile FAR *)GetPtr(filesopen);
    namestr[0] = fRef->drive+'A'-1;
    namestr[1] = ':';
    strcpyf((char FAR *)&namestr[2],fP->fRef.path);
    ReleasePtr(filesopen);
    TUTORclose(fileid);

    /* identify file type from extension */

    fii = strlen(namestr)-1;
    extP = NULL;
    while (fii) {
	if (namestr[fii] == '.') {
	    extP = namestr+fii+1;
	    break;
	}
	fii--;
    }

    /* set up MCI open parameters */
 
    TUTORzero((char FAR *)&mciOpen,(long)sizeof(MCI_DGV_OPEN_PARMS));
    hWnd = (HWND)windowsP[CurrentWindow].wp;
    mciOpen.lpstrDeviceType = "waveaudio"; /* pre-set for *.WAV */
    if (extP) {
	if ((strcmp(extP,"mid") == 0) || (strcmp(extP,"MID") == 0) ||
	   (strcmp(extP,"rmi") == 0) || (strcmp(extP,"rmi") == 0))
	    mciOpen.lpstrDeviceType = "sequencer";
    } /* extP if */
    mciOpen.dwCallback = (DWORD)NULL;
    mciOpen.wDeviceID = 0;
    mciOpen.lpstrElementName = namestr;
    mciOpen.lpstrAlias = NULL;
    mciOpen.dwStyle = WS_CHILD;
    mciOpen.hWndParent = hWnd;

    /* try to open the file via MCI */

    if (mciSendCommand(0,MCI_OPEN,(DWORD)(MCI_OPEN_ELEMENT),
       (DWORD)(LPMCI_DGV_OPEN_PARMS)&mciOpen) != 0)
	return(FILEIMPROPERTYPE); /* ? don't really know */

    wMCIDeviceID = mciOpen.wDeviceID; /* save ID */
    fMovieOpen = 2; /* sound opened */
    nativeRect.right = nativeRect.left = nativeRect.top = nativeRect.bottom = 0;

    /* set to work in milliseconds */

    mciSet.dwTimeFormat = MCI_FORMAT_MILLISECONDS;
    mciSendCommand(wMCIDeviceID,MCI_SET,(DWORD)MCI_SET_TIME_FORMAT,
		  (DWORD)(LPMCI_DGV_SET_PARMS)&mciSet);

    /* get duration of sound */

    mciStatus.dwItem = MCI_STATUS_LENGTH;
    mciSendCommand(wMCIDeviceID,MCI_STATUS,(DWORD)MCI_STATUS_ITEM,
		  (DWORD)(LPMCI_DGV_STATUS_PARMS)&mciStatus);
    movieDuration = mciStatus.dwReturn/1000.0;

    /* play sound */

    mciPlay.dwCallback = 0;
    mciPlay.dwFrom = mciPlay.dwTo = 0;
    mciSendCommand(wMCIDeviceID,MCI_PLAY,(DWORD)0,
		  (DWORD)(LPMCI_DGV_PLAY_PARMS)&mciPlay);
    moviePlayBegin = 0.0;
    return(0);

} /* TUTORsound */

/* ******************************************************************* */

int CloseMMotionVideo() { return(0); }
int CloseExternalVideo() { return(0); }

/* ******************************************************************* */
