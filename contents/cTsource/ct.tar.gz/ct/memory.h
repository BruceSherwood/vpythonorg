
/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.  */

#ifndef memory_hh
#define memory_hh

#include "baseenv.h"

#ifdef WINPC
#include <windows.h>
#endif

/* maximum entries to purge */
#define NOLDFIND 20

/* (TUTORexpand_swap) number table entries to add */
#define SWAPINC NOLDFIND+180


/* ******************************************************************* */

#ifdef ANDREW
#define UNIXMEM
#endif

#ifdef X11
#define UNIXMEM
#endif

#ifdef UNIXMEM
#define CTSWAP
#define MEMVERIFY
#endif

/* ******************************************************************* */

#ifdef MAC
#define SYSHANDLE
#define CTSWAP
#define MEMVERIFY
#endif

/* ******************************************************************* */

#ifdef WINPC
#define Handle HANDLE
#define NMEMSTART 100
#define NMEMADD 50
#define MEMMASK 0x4000
#define MEMVERIFY
#endif

/* ******************************************************************* */

#ifdef DOSPC

#define CTSWAP
#define MEMVERIFY
#define MEMLABEL 1
#define NMEMSTART 100
#define NMEMADD 50
#define MEMMASK 0x4000

struct memhdr {
    /* assembly language routines assumme this structure! */
    long length;    /* length of this memory area */
    unsigned char used; /* TRUE if memory area in use */
    unsigned char dddd;
    int handle; /* zero or handle */
#ifdef MEMLABEL
    char label[8]; /* descriptive label */
#endif
}; /* memhdr */

extern long hmalloc; /* number handles allocated */
extern struct htab FAR *htabp; /* pointer to table of handles */
extern short mLowest; /* index to start looking for empty slot */
extern long origmem;
extern struct memhdr FAR *basememp; /* pointer to begin of working memory */
extern long membase[4];

extern char FAR *lastptr;
extern long lastsize;
extern char FAR *lastlabel;

#endif


/* ******************************************************************* */

#ifdef UNIXMEM

typedef struct htab {
#ifdef MEMVERIFY
    char label[8];
#endif

#ifdef SYSHANDLE
    Handle theH;
#else
    char FAR *area; /* pointer to memory area */
#endif
#ifdef WINPC
    char FAR *area; /* pointer to (fixed) memory area */
#endif
    long size; /* logical size of handle (even when purged) */
    char lockcount;
#ifdef CTSWAP
    unsigned char purge;    /* bits 0-4 are purge types */
    /* 0 = not purgeable at all */
    /* 1 = restore by reallocating */
    /* 2 = restore by calling position as a function */
    /* 3 = Write Once Read Many from swap file */
    /* 4 = Write Many Read Many from swap file */
    /* 5 = purgeable, handle not in use */
    /* 6 = handle not in memory, needs restoring */
    /* 7 = unused */
#ifdef MEMVERIFY
    int swapSum;    /* checksum of swapped out memory */
#endif
    long position; /* position in swap file or procedure to call to restore handle */
    int rarg; /* argument passed to position procedure */
    long lastref; /* time of last reference */
#endif  
} MemEntry;

#endif /* UNIXMEM */

/* ******************************************************************* */

#ifdef MAC

typedef struct htab {
#ifdef MEMVERIFY
    char label[8];
#endif

#ifdef SYSHANDLE
    Handle theH;
#else
    char FAR *area; /* pointer to memory area */
#endif
#ifdef WINPC
    char FAR *area; /* pointer to (fixed) memory area */
#endif
    long size; /* logical size of handle (even when purged) */
    char lockcount;
#ifdef CTSWAP
    unsigned char purge;    /* bits 0-4 are purge types */
    /* 0 = not purgeable at all */
    /* 1 = restore by reallocating */
    /* 2 = restore by calling position as a function */
    /* 3 = Write Once Read Many from swap file */
    /* 4 = Write Many Read Many from swap file */
    /* 5 = purgeable, handle not in use */
    /* 6 = handle not in memory, needs restoring */
    /* 7 = unused */
	unsigned char flags;   /* bit 0 is MultiFinder memory flag */
    unsigned char dddu;
#ifdef MEMVERIFY
    int swapSum;    /* checksum of swapped out memory */
#endif
    long position; /* position in swap file or procedure to call to restore handle */
    int rarg; /* argument passed to position procedure */
    long lastref; /* time of last reference */
#endif  
} MemEntry;

#endif /* mac */

/* ******************************************************************* */

#ifdef DOSPC

typedef struct htab {
#ifdef MEMVERIFY
    char label[8];
#endif

#ifdef SYSHANDLE
    Handle theH;
#else
    char FAR *area; /* pointer to memory area */
#endif
    long size; /* logical size of handle (even when purged) */
    char lockcount;
#ifdef CTSWAP
    unsigned char purge;    /* bits 0-4 are purge types */
    /* 0 = not purgeable at all */
    /* 1 = restore by reallocating */
    /* 2 = restore by calling position as a function */
    /* 3 = Write Once Read Many from swap file */
    /* 4 = Write Many Read Many from swap file */
    /* 5 = purgeable, handle not in use */
    /* 6 = handle not in memory, needs restoring */
    /* 7 = unused */
#ifdef MEMVERIFY
    int swapSum;    /* checksum of swapped out memory */
#endif
    long position; /* position in swap file or procedure to call to restore handle */
    int rarg; /* argument passed to position procedure */
    long lastref; /* time of last reference */
#endif
} MemEntry;

#endif /* DOSPC */

/* ******************************************************************* */

#ifdef WINPC

typedef struct htab {
#ifdef MEMVERIFY
    char label[16]; /* brings length to 32 bytes */
#endif
    Handle theH; /* windows handle */
    char FAR *area; /* pointer to memory area */
    long size; /* logical size of handle */
    unsigned int offset; /* offset within suballocated handle */
    unsigned int realsize; /* real size of suballocated handle */
    char lockcount; /* number times cT handle locked */
    char suballoc; /* TRUE if suballocated */
} MemEntry;

typedef struct subfree {
    HANDLE theH; /* windows handle */
    unsigned int offset; /* offset to free area */
    unsigned int size; /* size of free area */
    char uu1,uu2; /* fill structure to 8 bytes */
} SubEntry;

#endif /* WINPC */

/* ******************************************************************* */

#define DEFDEL_POINTER 1
#define DEFDEL_HANDLE 2

extern int MemOutCount; /* number times memory manager went looking */

#endif


