
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University. */

/* independent cT objects */

#include <stdio.h>
#include "execdefs.h"
#include "yacc.h"
#include "eglobals.h"
#include "tglobals.h"
#include "tfiledef.h"
#include "exprdefs.h"
#include "fkeys.h"
#include "kglobals.h"
#include "editor.h"
#include "kdefs.h"
#include "txtv.h"
#include "commands.h"

/* ******************************************************************* */

#ifdef ctproto
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,
 int ebsref,struct  _trect *theR,int  relInfo,int  mintw,int  wrap,
 unsigned int  doc,long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),
 int  ro,int  corner,int  erase,int  frame,int tabsz,int lm,int rm,int inhss,int type);
struct tutorview FAR *TUTORinq_button_view(Memh bH);
struct tutorview FAR *TUTORinq_slider_view(Memh sH);
struct tutorview FAR *TUTORinq_touch_view(Memh tH);
int  TUTORset_event_mask(int  eventc,int  value);
extern long TUTORcopy_region(long regid);
unsigned int  TUTORcopy_handle(unsigned int  mm);
int  TUTORfind_stext(struct  _spt2 FAR *stp,long  pos);
extern int plotText(Memh doc,long start,long end);
int  TUTORclose_doc(unsigned int  doc);
int  TUTORset_textfont(int  jj);
int  TUTORchange_doc_doc(unsigned int  docD,long  pos,long  len,long  mpos,long  mlen,unsigned int  docS,long  posS,long  lenS,long  *extraPos,int  eupFlag);
unsigned int  TUTORnew_doc(int  string,int  honorP);
extern int TUTORfile_region(FileRef FAR *fRef,long regionID);
int  AllowHandlePurge(unsigned int  mm);
int  TUTORpurge_info(unsigned int  mm,int  ptype,int  (FAR *restoreproc)(),int  restorearg);
int  TUTORfree_handle(unsigned int  mm);
long  TUTORget_hsize(unsigned int  mm);
int  sizetv(int  opc);
extern long TUTORmem_to_region(int type,int width,int height,Memh palH,unsigned char SHUGE *bP);
static Memh alloc_bitmap(int width,int height);
int *bR; /* returned bytes/row */
extern int arraybnds(void);
extern int TUTORset_sub_new(int sub,int new);
extern int  marker_file_name(struct  markvar SHUGE *mx,struct  _fref FAR *fullRef,
    int  symbolic);
extern long TUTORload_region(FileRef FAR *fRef);
extern int TUTORnew_touch(int wn,Memh objH,int objR,struct _trect *rr);
extern int TUTORset_touch_unit(Memh tH,int index,int unitF,int unitN,double unitA);
extern int TUTORset_touch_priority(Memh tH,int prior);
extern int argtouch(int type);
long  IntToCoord(int  xx);
extern int check_eq_rect(TRect *r1,TRect *r2);
extern int reset_button(int type);
extern int reset_slider(int type);
extern int reset_edit(int type);
extern unsigned int find_free_object(int type);
extern int TUTORreset_text_sbar(Memh sbi, SBarInfo *sinf, int doDraw);
extern int TUTORset_slider_value(Memh sH,double value);
struct  tutorview FAR *TUTORinq_view(void);
int  _TUTORinfo_vbar_tview(struct  _viewp FAR *tvp,struct  _sbarinf *vb);
long  _TUTORscrollv_tview(unsigned int  theV,int  stype,long  arg);
int  RefreshPanel(struct  _tvdat FAR *vp,long  pos,long  len,long  cpos,long  clen,long  newC,long  selStart,long  selLen,int  scroll,int force);
int  SetSelectPanel(struct  _tvdat FAR *vp,long  pos,long  len);
int  cmd_get(void);
int  cmd_rget(void);
int  cmd_gget(void);
extern int  argget(int  type);
int  cmd_put(void);
int  cmd_rput(void);
int  cmd_gput(void);
extern int  argput(int  type);
int  cmd_edit(void);
int  cmd_redit(void);
int  cmd_gedit(void);
extern int  argedit(int  type);
extern int cmd_cancel(void);
int  cmd_button(void);
int  cmd_rbutton(void);
int  cmd_gbutton(void);
extern int  argbutton(int  type);
int  cmd_slider(void);
int  cmd_rslider(void);
int  cmd_gslider(void);
int  argslider(int  type);
int  cmd_editr(void);
int  cmd_reditr(void);
int  cmd_geditr(void);
extern int  argeditr(int  type);
int  cmd_buttonr(void);
int  cmd_rbuttonr(void);
int  cmd_gbuttonr(void);
extern int  argbuttonr(int  type);
int  cmd_sliderr(void);
int  cmd_rsliderr(void);
int  cmd_gsliderr(void);
int  cmd_rtouch(void);
int  cmd_gtouch(void);
int  cmd_touch(void);
int  cmd_focus(void);
int  cmd_null(void);
int  axes(void);
int  graph_to_fine(double  gx,double  gy,long  *cx,long  *cy);
int  execerr(char  *msgstr);
int  relative_to_fine(double  rx,double  ry,long  *cx,long  *cy);
long  TUTORabs_save_region(int  x1,int  y1,int  x2,int  y2);
int  lclocy(long  q);
int  lclocx(long  q);
int  TUTORfree_region(long  id);
int  TUTORset_view(struct  tutorview FAR *vp);
int  TUTORclose_panel(unsigned int  theV);
int  object_var_close(long  SHUGE *vaddr);
int  TUTORabs_restore_region(long  id,int  x1,int  y1);
int  TUTORclose_button(unsigned int  bH);
int  mvar_temp_cleanup(void);
int  ReleasePtr(unsigned int  mm);
char  FAR *GetPtr(unsigned int  mm);
int  DrawPanel(unsigned int  edH);
int  TUTORdraw_abs_solid_rect(struct  _trect FAR *tr,int  color);
unsigned int  MakeTextPanel(int  wn,long  owner,unsigned int  ebshdrH,int ebsref,
 struct  _trect *theR,int  relInfo,int  mintw,int  wrap,unsigned int  doc,
 long  pos,long  len,int  wantV,int  wantH,int  (*KeyF)(),int  ro,int  corner,int  erase,
 int  frame,int tabsz,int lm,int rm,int inhss,int type);
int  TUTORdefault_styles_font_doc(int  font,unsigned int  doc);
int  AllowHandlePurge(unsigned int  mm);
unsigned int  TUTORhandle(char  *name,long  size,int  purgewmrm);
int  TUTORintersect_rect(struct  _trect FAR *r1,struct  _trect FAR *r2,struct  _trect FAR *rdest);
int  TUTORreset_button(unsigned int  bH,int  value,int  aFlag,int  eraseF);
int  killptr(char  FAR * FAR *ptr);
unsigned int  TUTORnew_button(int  wn,unsigned int  owner,unsigned int	objH,
int objR,struct  _trect *tr,int  kind,int  thick,int  bFont,char  *title,
Memh titleD,unsigned int  destH,int  (*DestProc)(),int	destMsg,
int  destMsg1,double  destMsg2,int erase);
int  procexecwstub(unsigned int  wh,struct  tutorevent *event);
int  TUTORget_string_doc(unsigned int  doc,long  pos,long  len,unsigned char  FAR *destS);
int  TUTORclose_sbar(unsigned int  theSBar);
int  TUTORset_key_focus(int  wid,struct  tutorview FAR *vp,int  fromClick);
int  drawscrollbar(unsigned int  theSbar);
int  TUTORreset_values_sbar(unsigned int  sbi,double  value,double  minim,double  maxim,double pinc,double linc,int  unitf,int  unitn,double  unitarg,int  doDraw);
unsigned int  MakeScrollBar(struct  tutorview FAR *ovp,int  ew,unsigned int  ebshdrH,int ebsref,int  textF,int  sbType,int  info,struct  _trect *relRect,double  (*scrollProc)(),int  erase);
double  SliderScrollstub(struct  tutorview FAR *tview,int  hv,double  nn,int  type);
int  TUTORmake_rel_rect(struct  tutorview FAR *viewP,struct  _trect *theR,int  inf,struct  _trect *relR);
int cmd_axes(void);
int cmd_bounds(void);
#endif /* ctproto */

#ifdef macproto
extern int MarkStyleMenus(TextVDat FAR *vp, int flag);
#endif

extern long l_bin();
extern long l_read();
extern double f_bin();
extern double f_read();
extern long array_addr();
extern  double lcfsysv();
extern  long lcmsysa();
extern  long lcbitcnt();
extern double CoordToFloat();
extern long pass_addr();
extern long get_exec_pt();
extern  int TimedPauseStub();
extern double evalduser();
extern Memh darrowv(); /* handle on arrow text */
extern Memh dtextv();   /* handle on displayed text */
extern  long InsertKDoc();
extern Memh TUTORhandle();
extern Memh TUTORnew_button();
extern int  procexecwstub();
extern Memh MakeTextPanel();
extern Memh TUTORcopy_handle();
extern double ReadArr();
extern double PanelScrollstub();
extern double SliderScrollstub();
extern long TUTORabs_save_region();
extern struct  tutorview FAR *TUTORinq_view();
extern Memh find_free_object();
extern Memh alloc_bitmap();
extern long TUTORinq_msec_clock();

/* ******************************************************************* */

#ifndef long_align
#define long_read(addr) (*(long SHUGE *)(addr))
#define flt_read(addr) (*(double SHUGE *)(addr))
#else
#define long_read(addr) (l_read(addr))
#define flt_read(addr) (f_read(addr))
#endif

/* ******************************************************************* */

extern int execrun; /* executor run/return flag */
extern unsigned char txt_buffer[];

/* ------------------------------------------------------------------- */

/* zreturn error values for button, slider, edit, get, put */

#define OBJ_MEM 1
#define OBJ_RECT 2
#define OBJ_INACTIVE 3
#define OBJ_FILE 4

/* ------------------------------------------------------------------- */

cmd_get() { argget(0); }  /* -get-  command */
cmd_rget() { argget(1); } /* -rget- command */
cmd_gget() { argget(2); } /* -gget- command */

static int argget(type) /* get, rget, gget commands */
int type; /* 0 = absolute, 1 = relative, 2 = graphing */

{   int nn,nf;
    int format; /* 0 = blank tag, 1 = co-ordinates, 2 = file */
    long regionID; /* id of region */
    Coord x1,y1,x2,y2; /* region */
    long templ;
    FileRef fRef; /* file description */
    int width,height; /* width, height of image */
    long itemsRqd; /* number array items required */
    Memh bH; /* handle on r,g,b bitmap */
	unsigned char FAR *bP; /* pointer to r,g,b bitmap */
	unsigned char FAR *pixelP; /* pointer in bitmap */
	int pxx,pyy; /* indexes in bitmap */
	int pii; /* index in palette */
	int arrayElemSize; /* size of item in array */
	long SHUGE *arrayLongP; /* pointer in integer array */
	unsigned char SHUGE *arrayByteP; /* pointer in byte array */
	Memh paletteH; /* handle on palette */
	struct CTcolorentry FAR *paletteP; /* pointer to palette */
	int paletteSize; /* size of palette */
	struct CTcolorentry FAR *colorP; /* pointer to individual color */
	int rr,gg,bb; /* red,green,blue color components */
	int dataType; /* 1 = 8-bit palettized, 2 = 24-bit r,g,b */
	long pos,len; /* in-line image */
	DocP dp; /* pointer to special text document */
	SpecialTP stp; /* pointer to special text table */
	int stextN; /* index in special text table */
	
    nn = iresP-istack;
    nf = fresP-fstack;
    iresP = istack; /* void stacks */
    fresP = fstack;
    markP = markstack;

    regionID = istack[0];
    format = istack[4];
    exS.zreturn = -1; /* pre-set, worked */

    /* close current region, if any */

    if (regionID) /* close current region */
        TUTORfree_region(regionID);
    *(long FAR *)istack[2] = 0L;
    
    switch (format) { 
    
    /* blank tag form */
    
    case 0:
        return(0); /* done if closing region */
    
    /* screen rectangle form */
    
    case 1:
        if (type == 0) { /* get rectangle */
            x1 = istack[5];
            y1 = istack[6];
            x2 = istack[7];
            y2 = istack[8];
        } else if (type == 1) {
            relative_to_fine(fstack[0],fstack[1],&x1,&y1);
            relative_to_fine(fstack[2],fstack[3],&x2,&y2);
            if (exS.RAngle != 0) 
                execerr("-rget- cannot rotate region.");
        } else if (type == 2) {
            graph_to_fine(fstack[0],fstack[1],&x1,&y1);
            graph_to_fine(fstack[2],fstack[3],&x2,&y2);
        } /* type else */

        x1 = exS.OffsetX+lclocx(x1);
        y1 = exS.OffsetY+lclocy(y1);
        x2 = exS.OffsetX+lclocx(x2);
        y2 = exS.OffsetY+lclocy(y2);

        /* normalize rectangle */

        if (x2 < x1) {
            templ = x2;
            x2 = x1;
            x1 = templ;
        }
        if (y2 < y1) {
            templ = y2;
            y2 = y1;
            y1 = templ;
        }
        if (((x2-x1) < 0) || ((y2-y1) < 0)) 
            return(0);

        /* save screen rectangle */

        regionID = TUTORabs_save_region((int)x1,(int)y1,(int)x2,(int)y2);
        *(long FAR *)istack[2] = regionID;
        if (regionID == 0) exS.zreturn = OBJ_MEM;
        break;
        
    /* file form */
    
    case 2:
    
        /* evaluate file name expression */

        marker_file_name(markP,(FileRef FAR *) &fRef,TRUE); 
        regionID = TUTORload_region((FileRef FAR *)&fRef);
        if (regionID > 0) {
            *(long FAR *)istack[2] = regionID;
        } else {
            if (regionID == -2) exS.zreturn = OBJ_MEM;
            exS.zreturn = OBJ_FILE;
        }
        break;
        
    /* array form */
    
    case 3:
    
    	/* get width, height of bitmap */
    	
    	width = istack[7];
    	height = istack[8];
    	if ((width <= 0) || (height <= 0))
    		return(0); /* nothing to do */

		/* get size, address of array */

		dataType = 2; /* pre-set r,g,b */
    	arrayElemSize = sizetv((int)istack[10]); 
    	arrayByteP = (unsigned char SHUGE *)istack[11];
    	if (istack[13] == 1)  { /* array */
    		arrayByteP += ARRAYHDR; /* skip past array header */
    	} else if (istack[13] == 2) { /* dynamic array */
    		if (istack[12] <= 0)
    			arraybnds(); /* array has no length */
    		arrayLongP = ((long SHUGE *)istack[11])+1;
    		arrayByteP = (unsigned char SHUGE *)(*arrayLongP);
    	}
    	
    	bH = HNULL;
    	bP = FARNULL;
    	
    	if (istack[5] == 1) {
    	
    		/* palette form */
    		
    		if (istack[6] != 8)
    			execerr("Palette indexes must be 8 bits");
    		itemsRqd = (long)width*(long)height;
    		if (itemsRqd > istack[12])
    			arraybnds();
    			    		
    		/* allocate memory for bitmap */
    		
    		bH = alloc_bitmap(width,height);
    		if (!bH) {
    			exS.zreturn = OBJ_MEM;
    			return(0); /* no memory */
    		}
    		bP = (unsigned char FAR *)GetPtr(bH);
    		pixelP = bP;
    			
    		/* get palette */
    	
    		paletteH = windowsP[ExecWn].paletteH;
    		if (!paletteH)
    			paletteH = defaultPalette;
    		paletteSize = TUTORget_hsize(paletteH)/sizeof(struct CTcolorentry);
    		paletteP = (struct CTcolorentry FAR *)GetPtr(paletteH);
    		
    		/* loop thru array data */
#ifdef X11    		
		dataType = 1; /* X11 can handle palettized data */
#endif
#ifdef MAC
		dataType = 1; /* Mac can handle palettized data */
#endif
#ifdef WINPC
		dataType = 1; /* Windows can handle palettized data */
#endif
    		for(pyy=0; pyy<height; pyy++) {
    			for(pxx=0; pxx<width; pxx++) {
    				if (arrayElemSize == 1) { /* byte array */
    					pii = *arrayByteP; /* index in palette */
    				} else { /* integer array */
    					pii = *(long SHUGE *)arrayByteP;
    				}
    				
    				/* look up color of next pixel */
    				
    				if (pii < 0) pii = 0;
    				else if (pii >= paletteSize) pii = paletteSize-1;
    				if (dataType == 1)
						*pixelP++ = pii;
					else {
						rr = paletteP[pii].red >> 8;
						gg = paletteP[pii].green >> 8;
						bb = paletteP[pii].blue >> 8;
						*pixelP++ = rr;
						*pixelP++ = gg;
						*pixelP++ = bb;
					}
    				arrayByteP += arrayElemSize;
    			} /* pxx for */
    		} /* pyy for */
    		ReleasePtr(paletteH);
    		KillPtr(paletteP);
    	} else {
    	
    		/* rgb form */
    		
    		if (istack[6] != 24)
    			execerr("RGB values must be 24 bits");
    		itemsRqd = 3L*(long)width*(long)height;
    		if (itemsRqd > istack[12])
    			arraybnds();
    			
    		if (arrayElemSize == 1) { /* byte array */
    			bP = arrayByteP; /* data already in correct form */
    		} else { /* integer array */
    		    		
    			/* allocate memory for bitmap */
    		
    			bH = alloc_bitmap(width,height);
    			if (!bH) {
    				exS.zreturn = OBJ_MEM;
    				return(0); /* no memory */
    			}
    			bP = (unsigned char FAR *)GetPtr(bH);
    			pixelP = bP;
    			
    			/* loop thru array data */
    			
    			arrayLongP = (long SHUGE *)arrayByteP;
    			for(pyy=0; pyy<height; pyy++) {
    				for(pxx=0; pxx<width; pxx++) {
    					*pixelP++ = *arrayLongP++;
    					*pixelP++ = *arrayLongP++;
    					*pixelP++ = *arrayLongP++;
    				} /* pxx for */
    			} /* pyy for */
    		} /* arrayElemSize else */
    	} /* rgb else */
    	regionID = TUTORmem_to_region(dataType,width,height,HNULL,bP);
    	*(long FAR *)istack[2] = regionID;
        if (regionID == 0) exS.zreturn = OBJ_MEM;
        
    	/* release memory */
    	
    	if (bH) {
    		ReleasePtr(bH);
    		KillPtr(bP);
    		TUTORfree_handle(bH);
    	}
    	break;
    	
    case 4: /* in-line image */
    	exS.zreturn = OBJ_MEM; /* pre-set for error */
    	
       /* plot text with embedded image */
    		
		pos = istack[5]+unittab[exS.execunit].textp;
		len = istack[6];
    	dp = (DocP)GetPtr(textpool);
    	if (!dp->specialT) {
    		ReleasePtr(textpool);
    		KillPtr(dp);
    		break;
    	}
  		stp = (SpecialTP)GetPtr(dp->specialT); /* pointer to stext table */
    	stextN = TUTORfind_stext(stp,pos); /* index in stext table */
		if (stextN < 0) {
			ReleasePtr(dp->specialT);
			KillPtr(stp);
			ReleasePtr(textpool);
			KillPtr(dp);
			break;
		}
		regionID = TUTORcopy_region((long)stp->text[stextN].dat);
		ReleasePtr(dp->specialT);
		KillPtr(stp);
		ReleasePtr(textpool);
		KillPtr(dp);
     	*(long FAR *)istack[2] = regionID;
        if (regionID) exS.zreturn = -1;
    	break;
    	
    } /* switch */

    return(0);

} /* argget */

/* ------------------------------------------------------------------- */

static Memh alloc_bitmap(width,height) /* allocate space for color bitmap */
int width; /* width in pixels */
int height; /* height in pixels */

{	int rowBytes; /* bytes/row */
	long size; /* total size of pixels */
	Memh bH; /* handle on bitmap pixels */

	rowBytes = 3*width;
	size = (long)(rowBytes)*(long)(height);
	bH = TUTORhandle("pixels",size,TRUE);
	TUTORpurge_info(bH,M_WORM,FARNULL,0);
	AllowHandlePurge(bH);
	return(bH);	

} /* alloc_bitmap */

/* ------------------------------------------------------------------- */

cmd_put() { argput(0); }  /* -put-  command */
cmd_rput() { argput(1); } /* -rput- command */
cmd_gput() { argput(2); } /* -gput- command */

static int argput(type) /* put, rput, gput commands */
int type; /* 0 = absolute, 1 = relative, 2 = graphing */

{   long regionID; /* id of region */
    Coord x1,y1; /* screen position */
    int pType; /* 1 = screen, 2 = file */
	FileRef fRef; /* file description */
	int retf; /* file operation return */
	
    iresP = istack; /* void stacks */
    fresP = fstack;
	markP = markstack;

	exS.zreturn = -1;
    regionID = istack[0];
    if (!regionID) {
    	exS.zreturn = OBJ_INACTIVE;
        return(0);
    }
        
    pType = istack[4]; /* get screen/file type */
    if (pType == 1) { /* screen */

    	/* get screen location */

    	if (type == 0) {
        	x1 = istack[5];
        	y1 = istack[6];
    	} else if (type == 1) {
        	relative_to_fine(fstack[0],fstack[1],&x1,&y1);
        	if (exS.RAngle != 0) 
            	execerr("-rput- cannot rotate region.");
    	} else if (type == 2) {
        	graph_to_fine(fstack[0],fstack[1],&x1,&y1);
    	} /* type else */

    	x1 = exS.OffsetX+lclocx(x1);
    	y1 = exS.OffsetY+lclocy(y1);

    	/* plot screen rectangle */

    	TUTORabs_restore_region(regionID,x1,y1);
    } else if (pType == 2) { /* file */
       
        /* evaluate file name expression */

        marker_file_name(markP,(FileRef FAR *) &fRef,TRUE);  
        retf = TUTORfile_region((FileRef FAR *)&fRef,regionID);
		if (!retf) 
			exS.zreturn = OBJ_FILE;
		execrun = FALSE; /* return from executor */
		waitflag = atgetkey;
    }

    return(0);

} /* argput */

/* ------------------------------------------------------------------- */

cmd_edit() { argedit(0); }  /* -edit- command */
cmd_redit() { argedit(1); } /* -redit- command */
cmd_gedit() { argedit(2); } /* -gedit- command */

static argedit(type) /* edit, redit, gedit */
int type; /* 0 = absolute, 1 = relative, 2 = graphing */
    
{   int nn,nm,nf;
    struct markvar SHUGE *mtxt;
    struct markvar SHUGE *mx;
    int hscroll, vscroll, editable, corner, frame, erase; /* flags */
    int layoutw,wrap; /* word wrap and layout size */
    Coord x1,y1,x2,y2; /* region */
    int hotunitF; /* hot unit/argument flag */
    int hotunitN; /* hot-text unit number */
    double hotunitA; /* hot-text unit argument */
    int eventunitF[12]; /* event unit present flags */
    int eventunitN[12]; /* event unit numbers */
    double eventunitA[12]; /* event unit arguments */
    int euI; /* index in event unit tables */
    int ii,fi,mi; /* indexes in integer, floating, marker stacks */
    int boolf; /* boolean tag */
    long vpos,vlen,spos,slen; /* visible, selection regions */
    TRect theR; /* where on screen */
    TRect destr; /* intersection with clip */
    int intsf; /* TRUE if intersection with clip rectangle */
    int sizex,sizey; /* x/y size of rectangle */
    Memh ObjH; /* handle on object header */
    struct ebshdr FAR *ObjP; /* pointer to object header */
    Memh newT; /* handle on text panel */
    TextVDat FAR *tpp; /* pointer to text panel */
    TViewP tvp; /* pointer to text view */
    struct  _sbarinf sbv; /* scrollbar info */
    struct tutorview FAR *cv; /* current view */
    int frameset; /* TRUE if frame specifically set/unset */
    int tabsz; /* pixels/tab or -1 for default */
    int leftmar; /* left margin or -1 for default */
    int rightmar; /* right margin or -1 for default */
    Coord tx1,ty1; /* for tab pixel conversion */
    double ftx; /* for tab pixel conversion */
    int opt; /* current command option code */
    int focusClk; /* TRUE if first click only moves focus (absorbed) */
    int highlightSel; /* TRUE if should highlight selection */
    int singleSel; /* TRUE if single click should select (acts like double click) */
    int upHot; /* TRUE if should process hot text while mouse button up */
    int newlineH; /* default newline height */
    int supsubH; /* default superscript/subscript height */
	int supsubAdj; /* TRUE if should adjust layout for sup/sub */
    long tmpl;

    nn = iresP-istack;
    nm = markP-markstack;
    nf = fresP-fstack;
    markP = markstack;
    iresP = istack;
    fresP = fstack;

    mi = 0; /* index in marker stack */
    exS.zreturn = -1; /* pre-set all ok */

    if ((nm == 0) || istack[0]) { /* destroying or re-cycling edit */
        ObjH = istack[0]; /* handle on object header */
        if (ObjH) {
            if (exS.last_edit == ObjH) 
               exS.last_edit = HNULL;
            object_var_close((long SHUGE *)istack[2]);
            if (istack[0])
                TUTORset_view(ExecVp); /* insure set to exec view */
        }
        if (nm == 0) 
            return(0); /* done if closing edit */
    }
    
    /* set up defaults */

    vlen = slen = -1; /* no visible/selection region set */
    tabsz = leftmar = rightmar = -1; /* default tab/margin sizes */
    hotunitF = hotunitN = 0;
    hotunitA = 0.0;
    for(ii=0; ii<12; ii++) {
        eventunitF[ii] = eventunitN[ii] = 0;
        eventunitA[ii] = 0.0;
    }
    hscroll = FALSE;
    vscroll = FALSE;
    editable = FALSE;
    corner = FALSE;
    erase = FALSE;
    upHot = FALSE;
    frame = frameset = FALSE;
    focusClk = TRUE; /* default is to absorb first click for focus change */
    highlightSel = TRUE; /* default is to highlight selection */
    singleSel = FALSE; /* default is not to select on single click */
	supsubAdj = TRUE; /* default is to adjust layout for sup/sub */
    layoutw = 0; /* indicates word wrap */
    newlineH = exS.newLine;
    supsubH = exS.SupSub;

    /* get rectangle */

    if (type == 0) {
        x1 = istack[4];
        y1 = istack[5];
        x2 = istack[6];
        y2 = istack[7];
        ii = 8; /* start of additional arguments */
        fi = 0;
    } else if (type == 1) {
        relative_to_fine(fstack[0],fstack[1],&x1,&y1);
        relative_to_fine(fstack[2],fstack[3],&x2,&y2);
        ii = 4; /* start of additional arguments */
        fi = 4;
        if (exS.RAngle != 0) 
            execerr("-redit- cannot rotate text.");
    } else if (type == 2) {
        graph_to_fine(fstack[0],fstack[1],&x1,&y1);
        graph_to_fine(fstack[2],fstack[3],&x2,&y2);
        ii = 4; /* start of additional arguments */
        fi = 4;
    } /* type else */
    
    theR.left = exS.OffsetX + lclocx(x1);
    theR.top = exS.OffsetY + lclocy(y1);
    theR.right = exS.OffsetX + lclocx(x2);
    theR.bottom = exS.OffsetY + lclocy(y2);

    /* normalize rectangle */

    if (theR.left > theR.right) { /* normalize x */
        tmpl = theR.left;
        theR.left = theR.right;
        theR.right = tmpl;
    }
    if (theR.top > theR.bottom) { /* normalize y */
        tmpl = theR.top;
        theR.top = theR.bottom;
        theR.bottom = tmpl;
    }

    /* get hot-text unit info */

    hotunitN = istack[ii++]; /* get unit number */
    if (hotunitN == UNITX) {
        /* dont bother to set up hot unit */
        hotunitF = hotunitN = 0; 
        ii++; /* skip unit argument flag */
    } else {
        if (istack[ii++]) { /* if argument present */
            hotunitF = 2;
            hotunitA = fstack[fi++]; /* get argument */
        } else hotunitF = 1; /* unit, no argument */
    } /* UNITX else */

    mtxt = markstack+mi++; /* get text marker */
    
    /* process additional arguments */

    while (ii < nn) {
        boolf = (istack[ii+1] < 0); /* possible boolean flag */
        switch (opt = istack[ii]) {

        case KW_EDITABLE: /* text can be altered by user */
            editable = boolf;
            ii += 2;
            break;

        case KW_CORNER: /* reserve lower-right corner (mac resize) */
            corner = boolf;
            ii += 2;
            break;

        case KW_ERASE: /* erase text panel on destroy */
            erase = boolf;
            ii += 2;
            break;

        case KW_DEFMENU:
        case KW_FACEMENU:
        case KW_FONTMENU:
        case KW_SIZEMENU:
        case KW_COLORMENU:
        case KW_JUSTMENU:
            ii += 2;
            break;

        case KW_HSCROLL: /* add horizontal scroll bar */
            hscroll = boolf;
            ii += 2;
            break;

        case KW_VSCROLL:
            vscroll = boolf;
            ii += 2;
            break;

        case KW_FRAME:
            frame = boolf;
            frameset = TRUE;
            ii += 2;
            break;

        case KW_SELECT:
            mx = markstack+mi++;  
            if (mx->doc != mtxt->doc)
                execerr("marker not on -edit- document "); 
            spos = mx->pos;
            slen = mx->len;
            ii++;
            break;

        case KW_VISIBLE:
            mx = markstack+mi++;  
            if (mx->doc != mtxt->doc)
                execerr("marker not on -edit- document "); 
            vpos = mx->pos;
            vlen = mx->len;
            ii++;
            break;  

        case KW_TAB:
        case KW_LEFTMAR:
        case KW_RIGHTMAR:
            ftx = fstack[fi++]; /* get tab/margin size from floating stack */
            if (type == 0) { /* absolute */
                tx1 = ftx;
                tx1 = IntToCoord(tx1);
            } else if (type == 1) { /* relative */
                relative_to_fine(ftx,0.0,&tx1,&ty1);
            } else if (type == 2) { /* graphing */
                graph_to_fine(ftx,0.0,&tx1,&ty1);
            }
            tx1 = lclocx(tx1);
            if (opt == KW_TAB) {
                tabsz = tx1;
                if ((tabsz < 0) || (tabsz > 4095))
		    execerr("Illegal panel size or tab size");
            } else {
                if (opt == KW_LEFTMAR)
                    leftmar = tx1;
                else
                    rightmar = tx1;
                if (tx1 < 0) execerr("Illegal margin");
            }
            ii++;
            break;   
            
        case KW_BEFORE:
            euI = (istack[ii+1]-1)*2; /*  0 = before key */
                                      /*  2 = before left-down */
                                      /*  4 = before left-up */
                                      /*  6 = before right-down */
                                      /*  8 = before right-up */
                                      /* 10 = before down-move */
            eventunitN[euI] = istack[ii+2]; /* get unit number */
            if (istack[ii+3]) { /* if argument present */
                eventunitF[euI] = 2;
                eventunitA[euI] = fstack[fi++]; /* get argument */
            } else eventunitF[euI] = 1; /* unit, no argument */
            ii += 4;
            break;   
    
        case KW_AFTER:
            euI = ((istack[ii+1]-1)*2)+1; /*  1 = after key */
                                          /*  3 = after left-down */
                                          /*  5 = after left-up */
                                          /*  7 = after right-down */
                                          /*  9 = after right-up */
                                          /* 11 = after down-move */
            eventunitN[euI] = istack[ii+2]; /* get unit number */
            if (istack[ii+3]) { /* if argument present */
                eventunitF[euI] = 2;
                eventunitA[euI] = fstack[fi++]; /* get argument */
            } else eventunitF[euI] = 1; /* unit, no argument */
            ii += 4;
            break;
            
        case KW_FOCUSCLK:
            focusClk = boolf;
            ii += 2;
            break;
            
        case KW_HIGHLIGHT:
            highlightSel = boolf;
            ii += 2;
            break;
            
        case KW_UPHOT:
        	upHot = boolf;
        	ii += 2;
        	break;
            
        case KW_SINGLESEL:
            singleSel = boolf;
            ii += 2;
            break;
           
        case KW_NEWLINEH:
        case KW_SUPSUB:
            ftx = fstack[fi++]; /* get sub/newline size from floating stack */
            if (type == 0) { /* absolute */
                ty1 = ftx;
                ty1 = IntToCoord(ty1);
            } else if (type == 1) { /* relative */
                relative_to_fine(0.0,ftx,&tx1,&ty1);
            } else if (type == 2) { /* graphing */
                graph_to_fine(0.0,ftx,&tx1,&ty1);
            }
            ty1 = lclocy(ty1+exS.RegionYmin);
            if (opt == KW_NEWLINEH) newlineH = ty1;
            else supsubH = ty1;
            ii++;
        	break;

        case KW_SUPSUBADJ:
            supsubAdj = boolf;
            ii += 2;
            break;  

        } /* end of KW_ switch */
        
    } /* end of while (ii < nn) */  

    /* check if rectangle clipped */

    intsf = TUTORintersect_rect(&theR,&tgclipR,&destr);
    if (intsf == 0) { /* button is totally clipped */
        exS.zreturn = OBJ_RECT;
        return(0);
    } /* intsf if */
    
    /* for now, can't partially clip */
    
    if (!check_eq_rect(&theR,&destr)) {
        exS.zreturn = OBJ_RECT;
        return(0);
    }

    /* check if rectangle size reasonable */

    sizex = destr.right-destr.left;
    sizey = destr.bottom-destr.top;
    if (((vscroll || hscroll) && ((sizey < 20) || (sizex < 20))) ||
        (sizex < 10) || (sizey < 10)) {
        exS.zreturn = OBJ_RECT;
        return(0);
    }
    
    /* create text view */

    wrap = TRUE;
    if (hscroll) {
        wrap = FALSE;
    }
    if (!frameset && (hscroll || vscroll))
        frame = TRUE; /* default is frame if scrollbar */
    
    /* create object header */

    ObjH = find_free_object(TXEDIT);
    ObjP = (struct ebshdr FAR *)GetPtr(ObjH);

    /* create text panel */

    TUTORdraw_abs_solid_rect((TRect FAR *)&destr,PAT_BACKGROUND);
    /* make sure doc is set up with correct default styles */
    TUTORdefault_styles_font_doc(exS.baseFont, mtxt->doc);
    TUTORset_sub_new(supsubH,newlineH); /* set to inherit */
    newT = MakeTextPanel(ExecWn,0L,ObjH,ObjP->refcnt,&destr,3,layoutw,wrap, 
                       mtxt->doc,mtxt->pos,mtxt->len,vscroll,hscroll,
                       FARNULL,!editable,corner,erase,frame,tabsz,leftmar,rightmar,!supsubAdj,1);
    ObjP->objectH = newT; /* handle on new text panel */
    if (newT) {
        tpp = (TextVDat FAR *)GetPtr(newT); 
        ObjP->viewP = tpp->view; /* set text view in header */
        ReleasePtr(newT);
    }
    ReleasePtr(ObjH);
    KillPtr(ObjP);
    *(long FAR *)istack[2] = (long)ObjH;
	TUTORset_sub_new(exS.SupSub,exS.newLine); /* restore */
	
    if (newT == 0) {
        exS.zreturn = OBJ_MEM;
        return(0);
    }

    /* set text panel parameters */
    
    if (upHot)
    	TUTORset_event_mask(EVENT_UPMOVE,TRUE);
    tpp = (TextVDat FAR *)GetPtr(newT); 
    tpp->absorbFClick = focusClk; /* TRUE if first click absorbed (focus) */
    tpp->highSel = highlightSel; /* TRUE if should highlight selection */
    tpp->singleSel = singleSel; /* TRUE if should select on single click */
    tpp->upHot = upHot; /* TRUE if should highlight hot text on up move */
    tvp = (TViewP) GetPtr(tpp->textv);
    tvp->singleSel = singleSel; /* TRUE if should select on single click */
    tvp->highSel = highlightSel; /* TRUE if should highlight selection */
    tvp->upHot = upHot; /* TRUE if should highlight hot text on up move */
	tvp->inhSupSub = (!supsubAdj); /* TRUE if should NOT adjust layout for sup/sub */
    ReleasePtr(tpp->textv);
    KillPtr(tvp);
    
    /* display the text panel */
    
    DrawPanel(newT);

    /* set up units to handle events */

    if (hotunitF) {
        tpp->hotunitF = hotunitF; /* unit/argument flag */
        tpp->hotunitN = hotunitN; /* unit number */
        tpp->hotunitA = hotunitA; /* argument */
    } /* hotunitF if */
    for(euI=0; euI<12; euI++) {
        if (eventunitF[euI]) {
            tpp->eventunitF[euI] = eventunitF[euI]; /* unit/argument flag */
            tpp->eventunitN[euI] = eventunitN[euI]; /* unit number */
            tpp->eventunitA[euI] = eventunitA[euI]; /* argument */
        }
    } /* for */
    
    cv = TUTORinq_view(); /* save current view */
    TUTORset_view(tpp->view); /* set to text view */

    /* set selection region, if specified */
  
    if (slen >= 0)
        SetSelectPanel(tpp,spos,slen);

    /* set view region, if specified */

    if (vlen >= 0) {
        _TUTORscrollv_tview(tpp->textv,sbToPos,vpos);
        if (tpp->scrollv) {
            tvp = (TViewP)GetPtr(tpp->textv);
            _TUTORinfo_vbar_tview(tvp,&sbv);
            ReleasePtr(tpp->textv);
            KillPtr(tvp);
            TUTORreset_text_sbar(tpp->scrollv,&sbv,TRUE);
        } /* scrollv if */
#ifdef MAC
        MarkStyleMenus(tpp,0);
#endif
    } /* vlen if */
    
    /* set marker to track changes */
    
    if (editable && mtxt->vaddr >= 0) {
        mx = (struct markvar SHUGE *)(exS.stackP+mtxt->vaddr);
        mx->alteredF |= 16; /* make marker sticky */
    } /* addr if */
    
    TUTORset_view(cv); /* restore current view */
    ReleasePtr(newT);
    KillPtr(tpp);
    exS.nobjects++; /* increment number active objects */
    mvar_temp_cleanup();
    
    if (editable && mtxt->vaddr < 0)
		execerr("Marker must be changeable.");
    return(0);

} /* argedit */

/* ------------------------------------------------------------------- */

static int check_eq_rect(r1,r2) /* check if rectangles are identical */
TRect *r1; /* rectangles to compare */
TRect *r2;

{    
    if ((r1->left == r2->left) && (r1->top == r2->top) && 
        (r1->right == r2->right) && (r1->bottom == r2->bottom))
        return(TRUE);
    else
        return(FALSE);
        
} /* check_eq_rect */

/* ------------------------------------------------------------------- */

cmd_editr() { reset_edit(0); }  /* -edit- reset command */
cmd_reditr() { reset_edit(1); } /* -redit- reset command */
cmd_geditr() { reset_edit(2); } /* -gedit- reset command */
        
static reset_edit(type) /* edit/redit/gedit reset */
int type; /* 0 = absolute, 1 = relative, 2 = graphing */
    
{   int nn,nm,nf;
    struct markvar SHUGE *mtxt;
    struct markvar SHUGE *mx;
    int ii,fi,mi; /* indexes in integer, floating, marker stacks */
    int boolf; /* boolean tag */
    int wrong_doc; /* wrong document error flag */
    long vpos,vlen,spos,slen; /* visible, selection regions */
    Memh ObjH; /* handle on object header */
    struct ebshdr FAR *ObjP; /* pointer to object header */
    Memh textH; /* handle on text panel */
    TextVDat FAR *tpp; /* pointer to text panel */
    TViewP tvp; /* pointer to text view */
    struct  _sbarinf sbv; /* scrollbar info */
    struct tutorview FAR *cv; /* current view */
    int focusClk,highlightSel,singleSel;
    int upHot; /* TRUE if should process hot text while mouse button up */
    int editable;
    int hotunitF; /* hot unit/argument flag */
    int hotunitN; /* hot-text unit number */
    double hotunitA; /* hot-text unit argument */
    int euI; /* index in event unit tables */
    int eventunitF[12]; /* event unit present flags */
    int eventunitN[12]; /* event unit numbers */
    double eventunitA[12]; /* event unit arguments */
    
    nn = iresP-istack;
    nm = markP-markstack;
    nf = fresP-fstack;
    markP = markstack;
    iresP = istack;
    fresP = fstack;
    
    hotunitF = hotunitN = 0;
    hotunitA = 0.0;
    for(ii=0; ii<12; ii++) {
        eventunitF[ii] = eventunitN[ii] = 0;
        eventunitA[ii] = 0.0;
    }
    
    ii = 1; /* index in integer stack */
    mi = 0; /* index in marker stack */
    fi = 0; /* index in floating stack */
    exS.zreturn = -1; /* pre-set all ok */
    vlen = slen = -1; /* no visible/selection region set */
    focusClk = highlightSel = singleSel = editable =  upHot = -1; /* other options not set */
    textH = 0; /* no text panel handle yet */
    wrong_doc = 0; /* no error yet */
    
    ObjH = istack[0]; /* handle on object header */
    if (ObjH == 0) {
        exS.zreturn = OBJ_INACTIVE;
    } else {
        ObjP = (struct ebshdr FAR *)GetPtr(ObjH);
        textH = ObjP->objectH; /* handle on text panel */
        if (!textH)
            exS.zreturn = OBJ_INACTIVE;
        ReleasePtr(ObjH);
        KillPtr(ObjP);
    }
    if (exS.zreturn >= 0) 
        return(0); /* exit if panel not active */
      
    /* get marker on edit document */

    tpp = (TextVDat FAR *)GetPtr(textH);    
    tvp = (TViewP)GetPtr(tpp->textv); 
    mtxt = &tvp->bounds; /* edit base marker */
    
    /* process additional arguments */

    while (ii < nn) {
        boolf = (istack[ii+1] < 0); /* possible boolean flag */
        switch (istack[ii]) {

        case KW_SELECT:
            mx = markstack+mi++;  
            if (mx->doc != mtxt->doc) {
                wrong_doc = TRUE; /* set error flag */
            } else {
                spos = mx->pos;
                slen = mx->len;
            } 
            ii++;
            break;

        case KW_VISIBLE:
            mx = markstack+mi++;  
            if (mx->doc != mtxt->doc) {
                wrong_doc = TRUE; /* set error flag */
            } else {
                vpos = mx->pos;
                vlen = mx->len;
            }
            ii++;
            break;    
            
        case KW_FOCUSCLK:
            focusClk = boolf;
            ii += 2;
            break;
            
        case KW_HIGHLIGHT:
            highlightSel = boolf;
            ii += 2;
            break;
            
        case KW_SINGLESEL:
            singleSel = boolf;
            ii += 2;
            break;
            
		case KW_EDITABLE:
			editable = boolf;
			ii += 2;
			break;
			
		case KW_HOTUNIT:
		    hotunitN = istack[ii+1]; /* get unit number */
            if (istack[ii+2]) { /* if argument present */
                hotunitF = 2;
                hotunitA = fstack[fi++]; /* get argument */
            } else hotunitF = 1; /* unit, no argument */
            ii += 3;
            break;
            
        case KW_BEFORE:
            euI = (istack[ii+1]-1)*2; /*  0 = before key */
                                      /*  2 = before left-down */
                                      /*  4 = before left-up */
                                      /*  6 = before right-down */
                                      /*  8 = before right-up */
                                      /* 10 = before down-move */
            eventunitN[euI] = istack[ii+2]; /* get unit number */
            if (istack[ii+3]) { /* if argument present */
                eventunitF[euI] = 2;
                eventunitA[euI] = fstack[fi++]; /* get argument */
            } else eventunitF[euI] = 1; /* unit, no argument */
            ii += 4;
            break;   
    
        case KW_AFTER:
            euI = ((istack[ii+1]-1)*2)+1; /*  1 = after key */
                                          /*  3 = after left-down */
                                          /*  5 = after left-up */
                                          /*  7 = after right-down */
                                          /*  9 = after right-up */
                                          /* 11 = after down-move */
            eventunitN[euI] = istack[ii+2]; /* get unit number */
            if (istack[ii+3]) { /* if argument present */
                eventunitF[euI] = 2;
                eventunitA[euI] = fstack[fi++]; /* get argument */
            } else eventunitF[euI] = 1; /* unit, no argument */
            ii += 4;
            break;
                      
		case KW_UPHOT:
		    upHot = boolf;
        	ii += 2;
			break;
			  
        } /* end of switch */
    } /* end of while (ii < nn) */  

    mtxt = NULL; /* done with ptr to marker */
    cv = TUTORinq_view(); /* save current view */
    TUTORset_view(tpp->view); /* set to text view */

    /* set selection region, if specified */

    if (slen >= 0) {
        ReleasePtr(tpp->textv); /* release view */
        SetSelectPanel(tpp,spos,slen);
        tvp = (TViewP)GetPtr(tpp->textv); /* reaquire pointer */
    }

    /* set view region, if specified */

    if (vlen >= 0) {
        ReleasePtr(tpp->textv); /* release view */
        _TUTORscrollv_tview(tpp->textv,sbToPos,vpos);
        tvp = (TViewP)GetPtr(tpp->textv); /* reaquire pointer */
        if (tpp->scrollv) {
            _TUTORinfo_vbar_tview(tvp,&sbv);
            TUTORreset_text_sbar(tpp->scrollv,&sbv,TRUE);
        } /* scrollv if */
#ifdef MAC
        MarkStyleMenus(tpp,0);
#endif
    } /* vlen if */

    /* set text panel parameters */
    
    if (editable != -1)
    	tpp->readOnly = !editable;
    if (focusClk != -1)
        tpp->absorbFClick = focusClk; /* TRUE if first click absorbed (focus) */
    if (highlightSel != -1) {
        tpp->highSel = highlightSel; /* TRUE if should highlight selection */
        tvp->highSel = highlightSel; /* TRUE if should highlight selection */
    }
    if (singleSel != -1) {
        tpp->singleSel = singleSel; /* TRUE if should select on single click */
        tvp->singleSel = singleSel; /* TRUE if should select on single click */
    }
    if (upHot != -1) { 
    	tpp->upHot = upHot; /* TRUE if should highlight hot text on up move */
    	tvp->upHot = upHot; /* TRUE if should highlight hot text on up move */
    	TUTORset_event_mask(EVENT_UPMOVE,upHot);   
    }
    	
    /* set up units to handle events */
    
    if (hotunitF) {
        tpp->hotunitF = hotunitF; /* unit/argument flag */
        tpp->hotunitN = hotunitN; /* unit number */
        tpp->hotunitA = hotunitA; /* argument */
    } /* hotunitF if */    
    for(euI=0; euI<12; euI++) {
        if (eventunitF[euI]) {
            tpp->eventunitF[euI] = eventunitF[euI]; /* unit/argument flag */
            tpp->eventunitN[euI] = eventunitN[euI]; /* unit number */
            tpp->eventunitA[euI] = eventunitA[euI]; /* argument */
        }
    } /* for */
    
    TUTORset_view(cv); /* restore current view */
    ReleasePtr(tpp->textv);
    ReleasePtr(textH);
    mvar_temp_cleanup();

    if (wrong_doc)
        execerr("marker not on -edit- document "); 

    return(0);

} /* reset_edit */

/* ------------------------------------------------------------------- */

cmd_cancel() /* -cancel- cancel -edit- command event */

{
    exS.hold_event.type = -1;
    
} /* cmd_cancel */

/* ------------------------------------------------------------------- */

cmd_button() { argbutton(0); } /* -button-  command */
cmd_rbutton() { argbutton(1);} /* -rbutton- command */
cmd_gbutton() { argbutton(2);} /* -gbutton- command */

static argbutton(type) /* button, rbutton, gbutton */
int type; /* 0 = absolute, 1 = relative, 2 = graph */
    
{   int nn; /* # of integer args */
    int ii,fi; /* indexes in interger, float stacks */
    int buttonType, value, activeF, eraseF;
    Memh bH; /* handle on button */
    int unitN;
    Coord x1,y1,x2,y2; /* region */
    long tmpl;
    TRect tr; /* button rectangle */
    TRect destr; /* intersection with clip rectangle */
    int intsf; /* clip intersect flag */
    struct markvar SHUGE *mv;
    Memh textH; /* handle on (styled) button text document */
    double unitarg; /* argument to unit (if any) */
    int signalv; /* signal value for button */
    Memh objH; /* handle on object header */
    struct ebshdr FAR *objP; /* pointer to object header */
    int bFont; /* font to use for button text */
    long extraPos;
    
    nn = iresP - istack;
    markP = markstack;
    iresP = istack;
    fresP = fstack;

    /* set defaults */

    activeF = value = exS.zreturn = -1;
    eraseF = 0;
    unitarg = 0.0;
    signalv = BUTTONSIGNAL;
    buttonType = 0; /* rounded box */
    textH = HNULL;

    if ((nn == 4) || istack[0]) { /* destroying or re-cycling button */
        if (istack[0]) {
            if (exS.last_button == istack[0]) 
                exS.last_button = HNULL;
            object_var_close((long SHUGE *)istack[2]);
            if (istack[0])
                TUTORset_view(ExecVp); /* insure set to execute view */
        }
        if (nn == 4) 
            return(0); /* done if closing button */
    } /* nn/istack if */

    /* get rectangle */

    if (type == 0) {
        x1 = istack[4];
        y1 = istack[5];
        x2 = istack[6];
        y2 = istack[7];
        ii = 8; /* start of additional integer arguments */
        fi = 0; /* start of additional floating arguments */
    } else if (type == 1) {
        relative_to_fine(fstack[0],fstack[1],&x1,&y1);
        relative_to_fine(fstack[2],fstack[3],&x2,&y2);
        ii = 4; /* start of additional integer arguments */
        fi = 4; /* start of additional floating arguments */
        if (exS.RAngle != 0) 
            execerr("-rbutton- cannot rotate text.");
    } else if (type == 2) {
        graph_to_fine(fstack[0],fstack[1],&x1,&y1);
        graph_to_fine(fstack[2],fstack[3],&x2,&y2);
        ii = 4; /* start of additional integer arguments */
        fi = 4; /* start of additional floating arguments */
    } /* type else */
    tr.left = exS.OffsetX + lclocx(x1);
    tr.top = exS.OffsetY + lclocy(y1);
    tr.right = exS.OffsetX + lclocx(x2);
    tr.bottom = exS.OffsetY + lclocy(y2);

    /* normalize rectangle */

    if (tr.left > tr.right) { /* normalize x */
        tmpl = tr.left;
        tr.left = tr.right;
        tr.right = tmpl;
    }
    if (tr.top > tr.bottom) { /* normalize y */
        tmpl = tr.top;
        tr.top = tr.bottom;
        tr.bottom = tmpl;
    }

    /* check if button clipped */

    intsf = TUTORintersect_rect(&tr,&tgclipR,&destr);
    if (intsf == 0) { /* button is totally clipped */
        exS.zreturn = OBJ_RECT;
        return(0);
    } /* intsf if */
    if (!check_eq_rect(&tr,&destr)) {
        exS.zreturn = OBJ_RECT;
        return(0);
    } 


    /* check if button size reasonable */

    if ((destr.right-destr.left < 4) ||
        (destr.bottom-destr.top < 4)) {
        exS.zreturn = OBJ_RECT;
        return(0);
    }
  
    /* get button text */

    mv = markP; /* get text marker */
	if (checkbit(exS.inhibbits,INHBFONT)) {
		textH = TUTORnew_doc(TRUE,TRUE);
		TUTORdefault_styles_font_doc(exS.baseFont,textH);
    	TUTORchange_doc_doc(textH,0L,0L,0L,0L,
                        mv->doc,mv->pos,mv->len,&extraPos,TRUE);
	}
    tmpl = mv->len; /* length of text */
    if (tmpl > WRT_TXT_LTH)
        tmpl = WRT_TXT_LTH;
    if (tmpl)
    	TUTORget_string_doc(mv->doc,mv->pos,tmpl,(unsigned char FAR *)&txt_buffer[0]);
    else txt_buffer[0] = 0;

    unitN = istack[ii++]; /* get unit number */

    if (istack[ii++]) { /* unit has argument */
        unitarg = fstack[fi++];
        signalv = BUTTONSIGNALA;
    } /* istack if */

    while (ii < nn) {

        switch (istack[ii]) {

        case KW_ROUNDBOX: /* rounded box button */
            buttonType = 0;
            ii++;
            break;

        case KW_CHECK:
            buttonType = 1;
            ii++;
            break;

        case KW_RADIO:
            buttonType = 2;
            ii++;
            break;

        case KW_THREED: /* changed 6/3/91 BJM */
            buttonType = 3;
            ii++;
            break;

        case KW_ACTIVE:
            activeF = (istack[ii+1] < 0); /* button active */
            ii += 2;
            break;

        case KW_ERASE:
            eraseF = (istack[ii+1] < 0); /* erase on destroy */
            ii += 2;
            break;

        case KW_VALUE:
            value = (fstack[fi++] < 0.0); /* initial value of button */
            ii++;
            break;

        default:
            execerr("unrecognized option on button");

        } /* switch */

    } /* while */

    /* create object header */

    objH = find_free_object(TXBUTTON);
    objP = (struct ebshdr FAR *)GetPtr(objH);

    /* create the button */

	if (checkbit(exS.inhibbits,INHBFONT)) 
		bFont = exS.baseFont; /* textFont ? */
	else 
		bFont = -1; /* use system font */
    bH = TUTORnew_button(ExecWn,HNULL,objH,objP->refcnt,&destr,buttonType,1,bFont,
                         (char *) &txt_buffer[0],textH,windowsP[ExecWn].wH,
                         procexecwstub,signalv,unitN,unitarg,eraseF);
    objP->objectH = bH;
    objP->viewP = TUTORinq_button_view(bH);
    ReleasePtr(objH);
    KillPtr(objP);
    *(long FAR *)istack[2] = (long)objH;

    if (bH == 0) {
        exS.zreturn = OBJ_MEM;
        return(0);
    }

    TUTORreset_button(bH,value,activeF,eraseF);
    exS.nobjects++; /* increment number active objects */
    mvar_temp_cleanup();

    return(0);

} /* argbutton */

/* ------------------------------------------------------------------- */

cmd_buttonr() { reset_button(0); } /* -button-  reset command */
cmd_rbuttonr() { reset_button(1);} /* -rbutton- reset command */
cmd_gbuttonr() { reset_button(2);} /* -gbutton- reset command */

static reset_button(type) /* button/rbutton/gbutton reset */
int type;
    
{   int nn;
    Memh bH; /* handle on button */
    int curV; /* new button value */
    int ii,fi; /* indexes in integer, floating stacks */
    Memh ObjH; /* handle on object header */
    struct ebshdr FAR *ObjP; /* pointer to object header */

    nn = iresP-istack;
    iresP = istack;
    fresP = fstack;
    ii = 1; /* index on integer stack */
    fi = 0; /* index on floating stack */
    exS.zreturn = -1; /* pre-set all ok */
    
    ObjH = istack[0]; /* handle on object header */
    if (ObjH == 0) {
        exS.zreturn = OBJ_INACTIVE;
    } else {
        ObjP = (struct ebshdr FAR *)GetPtr(ObjH);
        bH = ObjP->objectH; /* handle on button */
        if (!bH)
            exS.zreturn = OBJ_INACTIVE;
        ReleasePtr(ObjH);
        KillPtr(ObjP);
    }
    if (exS.zreturn >= 0) 
        return(0); /* exit if slider not active */
      
    while (ii < nn) {

        switch (istack[ii]) {

        case KW_VALUE:
            curV = (fstack[fi++] < 0.0); /* new value of button */
            TUTORreset_button(bH,curV,-1,-1);
            ii++;
            break;

        default:
            execerr("unrecognized option on button");

        } /* switch */

    } /* while */

    return(0);
    
} /* reset_button */

/* ------------------------------------------------------------------- */

cmd_slider() { argslider(0); }  /* -slider-  command */
cmd_rslider() { argslider(1); } /* -rslider- command */
cmd_gslider() { argslider(2); } /* -gslider- command */

argslider(type) /* slider, rslider, gslider */
int type;
    
{   int nn;
    long tmpl;
    int eraseF; /* TRUE if should erase slider on destroy */
    int unitF; /* unit argument flag */
    int unitN; /* unit number */
    Coord x1,y1,x2,y2; /* region */
    int info;
    int hvf; /* horizontal/vertical flag */
    Memh sH; /* handle on scroll bar */
    double minV,maxV,curV,pageInc,lineInc;
    int ii,fi; /* indexes in integer, floating stacks */
    TRect tr; /* absolute slider rectangle */
    TRect tempRel; /* relative slider rectangle */
    TRect destr; /* intersection of slider, clip */
    int intsf; /* clip rectangle intersect flag */
    double unitarg; /* unit (value) argument */
    Memh objH; /* handle on object header */
    struct ebshdr FAR *objP; /* pointer to object header */

    nn = iresP-istack;
    iresP = istack;
    fresP = fstack;
    exS.zreturn = -1; /* pre-set all ok */
    if ((nn == 4) || istack[0]) { /* destroying or re-cycling slider */
        if (istack[0]) {
            if (exS.last_slider == istack[0]) 
                exS.last_slider = HNULL;
            object_var_close((long SHUGE *)istack[2]);
            TUTORset_view(ExecVp); /* insure set to exec view */
        }
        if (nn == 4) 
            return(0); /* done if closing button */
    }

    /* get rectangle */

    if (type == 0) {
        x1 = istack[4];
        y1 = istack[5];
        x2 = istack[6];
        y2 = istack[7];
        ii = 8; /* start of additional integer arguments */
        fi = 0; /* start of additional floating arguments */
    } else if (type == 1) {
        relative_to_fine(fstack[0],fstack[1],&x1,&y1);
        relative_to_fine(fstack[2],fstack[3],&x2,&y2);
        ii = 4; /* start of additional integer arguments */
        fi = 4; /* start of additional floating arguments */
        if (exS.RAngle != 0) 
            execerr("-rbutton- cannot rotate text.");
    } else if (type == 2) {
        graph_to_fine(fstack[0],fstack[1],&x1,&y1);
        graph_to_fine(fstack[2],fstack[3],&x2,&y2);
        ii = 4; /* start of additional integer arguments */
        fi = 4; /* start of additional floating arguments */
    } /* type else */
    tr.left = exS.OffsetX + lclocx(x1);
    tr.top = exS.OffsetY + lclocy(y1);
    tr.right = exS.OffsetX + lclocx(x2);
    tr.bottom = exS.OffsetY + lclocy(y2);

    /* normalize rectangle */

    if (tr.left > tr.right) { /* normalize x */
        tmpl = tr.left;
        tr.left = tr.right;
        tr.right = tmpl;
    }
    if (tr.top > tr.bottom) { /* normalize y */
        tmpl = tr.top;
        tr.top = tr.bottom;
        tr.bottom = tmpl;
    }

    unitN = istack[ii++]; /* unit number */
    unitF = 1; /* assume no argument */
    eraseF = FALSE;
    minV = 0.0;
    maxV = 100.0;
    curV = 50.0;
    pageInc = 10.0;
    lineInc = 1.0;
    info = TOPSTICK+RIGHTSTICK;
    hvf = SBVERT;

    if (istack[ii++]) { /* unit has argument */
        unitarg = fstack[fi++];
        unitF = 2; /* unit has argument */
    } /* istack if */

    while (ii < nn) {

        switch (istack[ii]) {

        case KW_ERASE:
            eraseF = istack[ii+1]; /* erase on destroy */
            ii += 2;
            break;

        case KW_VALUE:
            curV = fstack[fi++]; /* initial value of slider */
            ii++;
            break;

        case KW_PAGE:
            pageInc = fstack[fi++]; /* page increment */
            ii++;
            break;

        case KW_LINE:
            lineInc = fstack[fi++]; /* line increment */
            ii++;
            break;

        case KW_RANGE:
            minV = fstack[fi++]; /* minimum value of slider */
            maxV = fstack[fi++]; /* maximum value of slider */
            if (maxV <= minV)
                execerr("Maximum value must be greater than minimum");
            ii++;
            break;

        case KW_HSCROLL:
            if (istack[ii+1] < 0)
                hvf = SBHORIZ;
            ii += 2;
            break;

        default:
            execerr("unrecognized option on slider");

        } /* switch */

    } /* while */

    if (curV < minV) curV = minV;
    if (curV > maxV) curV = maxV;

    /* check if slider clipped */

    intsf = TUTORintersect_rect(&tr,&tgclipR,&destr);
    if (intsf == 0) { /* slider is totally clipped */
        exS.zreturn = OBJ_RECT;
        return(0);
    } /* intsf if */
    if (!check_eq_rect(&tr,&destr)) {
        exS.zreturn = OBJ_RECT;
        return(0);
    } 


    /* check if slider size reasonable */

    if (hvf == SBVERT) { /* vertical */
        if ((destr.right-destr.left < 6) ||
            (destr.bottom-destr.top < 20)) {
            exS.zreturn = OBJ_RECT;
            return(0);
        }
    } else { /* horizontal */
        if ((destr.right-destr.left < 20) ||
            (destr.bottom-destr.top < 6)) {
            exS.zreturn = OBJ_RECT;
            return(0);
        }
    }

    /* create object header */

    objH = find_free_object(TXSLIDER);
    objP = (struct ebshdr FAR *)GetPtr(objH);

    /* create slider */

    TUTORmake_rel_rect(ExecVp,&destr,info,&tempRel);
    sH = MakeScrollBar(ExecVp,ExecWn,objH,objP->refcnt,FALSE,hvf,info,&tempRel,
                       SliderScrollstub,eraseF);
    objP->objectH = sH;
    objP->viewP = TUTORinq_slider_view(sH);
    ReleasePtr(objH);
    KillPtr(objP);
    *(long FAR *)istack[2] = (long)objH;

    if (sH == 0) { /* exit if slider not created */
    exS.zreturn = OBJ_MEM;
        return(0);
    } /* sH if */

    TUTORreset_values_sbar(sH,curV,minV,maxV,pageInc,lineInc,
                           unitF,unitN,unitarg,FALSE);
    drawscrollbar(sH);
    exS.nobjects++; /* increment number active objects */
    return(0);
    
} /* argslider */

/* ------------------------------------------------------------------- */

cmd_sliderr() { reset_slider(0); }  /* -slider-  reset command */
cmd_rsliderr() { reset_slider(1); } /* -rslider- reset command */
cmd_gsliderr() { reset_slider(2); } /* -gslider- reset command */

static reset_slider(type) /* slider/rslider/gslider reset */
int type;
    
{   int nn;
    Memh sH; /* handle on scroll bar */
    double curV;
    int ii,fi; /* indexes in integer, floating stacks */
    Memh ObjH; /* handle on object header */
    struct ebshdr FAR *ObjP; /* pointer to object header */

    nn = iresP-istack;
    iresP = istack;
    fresP = fstack;
    ii = 1; /* index on integer stack */
    fi = 0; /* index on floating stack */
    exS.zreturn = -1; /* pre-set all ok */
    
    ObjH = istack[0]; /* handle on object header */
    if (ObjH == 0) {
        exS.zreturn = OBJ_INACTIVE;
    } else {
        ObjP = (struct ebshdr FAR *)GetPtr(ObjH);
        sH = ObjP->objectH; /* handle on slider panel */
        if (!sH)
            exS.zreturn = OBJ_INACTIVE;
        ReleasePtr(ObjH);
        KillPtr(ObjP);
    }
    if (exS.zreturn >= 0) 
        return(0); /* exit if slider not active */
      
    while (ii < nn) {

        switch (istack[ii]) {

        case KW_VALUE:
            curV = fstack[fi++]; /* new value of slider */
            TUTORset_slider_value(sH,curV);
            ii++;
            break;

        default:
            execerr("unrecognized option on slider");

        } /* switch */

    } /* while */

    return(0);
    
} /* reset_slider */

/* ------------------------------------------------------------------- */

cmd_touch()  { argtouch(0); } /* -touch- command */
cmd_rtouch() { argtouch(1); } /* -rtouch- command */
cmd_gtouch() { argtouch(2); } /* -gtouch- command */

argtouch(type) /* touch, rtouch, gtouch commands */
int type; /* 0 = touch, 1 = rtouch, 2 = gtouch */

{   int nn;
    int ii; /* index in integer arguments */
    int fi; /* index in floating arguments */
    Coord x1,y1,x2,y2; /* touch region */
    TRect tr; /* touch region */
    Memh objH; /* handle on touch object header */
    struct ebshdr FAR *objP; /* pointer to object header */
    Memh tH; /* handle on touch region data */
    long touchBits; /* touch option bits */
    int bI; /* index in touch bits */
    int Index; /* index in touch region unit arrays */
    int unitN; /* unit to invoke */
    int unitF; /* unit argument flag */
    double unitArg; /* argument to pass to unit */
    int priority; /* priority (front/back) ordering */
    int xMin,xMax,yMin,yMax; /* useable screen area */
    long tmpl;
    
    nn = iresP-istack;
    markP = markstack;
    iresP = istack;
    fresP = fstack;
   
    exS.zreturn = -1;
    touchBits = 0; /* no touch options set yet */
    
    if ((nn == 4) || istack[0]) { /* destroying or re-cycling touch area */
        if (istack[0]) {
            if (exS.last_touch == istack[0]) 
                exS.last_touch = HNULL;
            object_var_close((long SHUGE *)istack[2]);
            if (istack[0])
                TUTORset_view(ExecVp); /* insure set to execute view */
        }
        if (nn == 4) 
            return(0); /* done if closing touch area */
    } /* nn/istack if */

    /* get rectangle */

    if (type == 0) {
        x1 = istack[4];
        y1 = istack[5];
        x2 = istack[6];
        y2 = istack[7];
        ii = 8; /* start of additional integer arguments */
        fi = 0; /* start of additional floating arguments */
    } else if (type == 1) {
        relative_to_fine(fstack[0],fstack[1],&x1,&y1);
        relative_to_fine(fstack[2],fstack[3],&x2,&y2);
        ii = 4; /* start of additional integer arguments */
        fi = 4; /* start of additional floating arguments */
    } else if (type == 2) {
        graph_to_fine(fstack[0],fstack[1],&x1,&y1);
        graph_to_fine(fstack[2],fstack[3],&x2,&y2);
        ii = 4; /* start of additional integer arguments */
        fi = 4; /* start of additional floating arguments */
    } /* type else */
    
    if (ii >= nn)
        return(0); /* pathological case - nothing to do */
        
    tr.left = exS.OffsetX + lclocx(x1);
    tr.top = exS.OffsetY + lclocy(y1);
    tr.right = exS.OffsetX + lclocx(x2);
    tr.bottom = exS.OffsetY + lclocy(y2);

    /* normalize rectangle */

    if (tr.left > tr.right) { /* normalize x */
        tmpl = tr.left;
        tr.left = tr.right;
        tr.right = tmpl;
    }
    if (tr.top > tr.bottom) { /* normalize y */
        tmpl = tr.top;
        tr.top = tr.bottom;
        tr.bottom = tmpl;
    }
    xMin = exS.OffsetX+lclocx(exS.RegionXmin);
    yMin = exS.OffsetY+lclocy(exS.RegionYmin);
    xMax = exS.OffsetX+lclocx(exS.RegionXmax);
    yMax = exS.OffsetY+lclocy(exS.RegionYmax);
    if ((tr.left > xMax) || (tr.top > yMax) ||
        (tr.right < xMin) || (tr.bottom < yMin))
        return(0); /* completely off screen */
    if (tr.left < xMin) tr.left = xMin;
    if (tr.right > xMax) tr.right = xMax;
    if (tr.top < yMin) tr.top = yMin;
    if (tr.bottom > yMax) tr.bottom = yMax;
     
    /* create object header */

    objH = find_free_object(TXTOUCH);
    objP = (struct ebshdr FAR *)GetPtr(objH);

    /* create touch-sensitive region */;
                         
    tH = TUTORnew_touch(ExecWn,objH,objP->refcnt,&tr);
    objP->objectH = tH;
    objP->viewP = TUTORinq_touch_view(tH);
    ReleasePtr(objH);
    KillPtr(objP);
    *(long FAR *)istack[2] = (long)objH;
    
    /* process additional arguments */
    
    while (ii < nn) {

        switch (istack[ii++]) {

        case KW_TOUCH:
            touchBits |= istack[ii++]; /* pick up touch option bits */
            break;

        case KW_TUNIT: 
        
            /* get unit number and possible argument */
            
            unitN = istack[ii++]; /* unit number */
            unitF = 1; /* assume no argument */
            unitArg = 0.0;
            if (istack[ii++]) { /* unit has argument */
                unitArg = fstack[fi++];
                unitF = 2; /* unit has argument */
            } /* istack if */
            if (unitN == UNITX) unitF = 0; /* unit x can't have argument */
            
            /* set touch unit as specified by touch option bits */
            
            for(bI=0; bI<16; bI++) {
                switch (bI) {
                case TLDOWN:
                    Index = TR_LDOWN;
                    break;
                case TLUP:
                    Index = TR_LUP;
                    break;
                case TLMOVE:
                    Index = TR_LMOVE;
                    break;
                case TRDOWN:
                    Index = TR_RDOWN;
                    break;
                case TRUP:
                    Index = TR_RUP;
                    break;
                case TRMOVE:
                    Index = TR_RMOVE;
                    break;
                case TLDOUBLE:
                    Index = TR_LDOUBLE;
                    break;
                case TRDOUBLE:
                    Index = TR_RDOUBLE;
                    break;
                case TUPMOVE:
                	Index = TR_UPMOVE;
                	break;
                default:
                    Index = -1;
                    break;
                } /* switch */
                if ((Index >= 0) && (touchBits & (1 << bI))) {
                	if (Index == TR_UPMOVE) {
                    	exS.enabled |= 128;
                		TUTORset_event_mask(EVENT_UPMOVE,TRUE);
					}
                    TUTORset_touch_unit(tH,Index,unitF,unitN,unitArg);
                }
            } /* bI for */
            touchBits = 0; /* clear touch option bits */
            break;
            
        case KW_TPRIORITY:
            priority = istack[ii++];
            TUTORset_touch_priority(tH,priority);
            break;
            
        default:
            execerr("unrecognized option on touch");

        } /* switch */

    } /* while */
   
    return(0);
    
} /* argtouch */

/* ------------------------------------------------------------------- */

cmd_focus() /* -focus- */
    
{   int nn;
    Memh ObjH; /* handle on object header */
    struct ebshdr FAR *ObjP; /* pointer to object header */
    Memh panelh; /* handle on text panel */
    TextVDat FAR *tpp;
    struct tutorview FAR *tviewp;

    nn = iresP-istack;
    iresP = istack;

    /* if no tag, or no edit panel, set to executor view */

    ObjH = istack[0]; /* handle on object header */
    if ((nn == 0) || (ObjH == 0)) { 
        TUTORset_key_focus(ExecWn,ExecVp,FALSE);
        return;
    }

    /* get handle on text panel */

    ObjP = (struct ebshdr FAR *)GetPtr(ObjH);
    panelh = ObjP->objectH; /* get handle on text panel */
    ReleasePtr(ObjH);
    KillPtr(ObjP);
   
    /* set to specified view */

    if (panelh == 0) return;
    tpp = (TextVDat FAR *) GetPtr(panelh);
    tviewp = tpp->view;
    ReleasePtr(panelh);
    TUTORset_key_focus(ExecWn,tviewp,FALSE);

    /* interrupt to process events */

    execrun = FALSE; /* return from executor */
    waitflag = atinterrupt;
    return;

} /* cmd_focus */

/* ------------------------------------------------------------------- */

cmd_axes() /* -axes- command execution */

{   register int nn;

    nn = iresP-istack; /* number items on stack */

    if (nn) cmd_bounds(); /* set up graph bounds first */
    axes(); /* draw the axes */
    
    exS.ScreenX = exS.GXorigin;
    exS.ScreenY = exS.GYorigin;

} /* cmd_axes */

/* ------------------------------------------------------------------- */

cmd_bounds() /* -bounds- command execution */

{   register int nn;
    double angle;

    nn = iresP-istack; /* number items on stack */
    iresP = istack; /* pop stack */
   
    if (nn == 2) {
        exS.DXplus = istack[0];
        exS.DYplus = istack[1]; 
        exS.DXneg = exS.DYneg = 0; 
    } else {
        exS.DXneg = istack[0];  
        exS.DYneg = istack[1]; 
        exS.DXplus = istack[2];
        exS.DYplus = istack[3]; 
    } /* else */

    /* check for validity */

    if (nn == 2) {   /* two-tag form */
        if (exS.DXplus < 0) {
            exS.DXneg = exS.DXplus; 
            exS.DXplus = 0; 
        }
        if (exS.DYplus < 0) {
            exS.DYneg = exS.DYplus; 
            exS.DYplus = 0; 
        }
    } else {
        if(exS.DXneg > 0 || exS.DYneg > 0)
            execerr("Negative side of axis must have negative sign."); 
        if(exS.DXplus < 0 || exS.DYplus < 0)
            execerr("Positive side of axis must have positive sign."); 
    } /* nn else */
      
    exS.ScreenX = exS.GXorigin;
    exS.ScreenY = exS.GYorigin;

} /* cmd_bounds */

/* ------------------------------------------------------------------- */

cmd_null() { return(0); } /* dummy cmd */

/* ------------------------------------------------------------------- */
