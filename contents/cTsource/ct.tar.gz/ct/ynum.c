
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/


/* ynum input file output file [ -n starting value] */

/* copies input text file to output text file modifying yacc %token, %right and 
    %left statements to assign integer values to yacc tokens */

/* ******************************************************************* */

#include <stdio.h>
#include <strings.h>
#include <ctype.h>

#define linel 100
#define TRUE 1
#define FALSE 0

main (argc,argv)

int argc;		/* argument count */
char *argv[ ];	/* pointers to arguments */

 
{ /* main */

int ivalue;		/* initial token value */
int tvalue;		/* current token value */
FILE *ip, *op;	/* input and output file pointers */
char iline[linel];		/* input  line */
char oline[linel];	/* output line */
char *ic, *oc;		/* pointers in input and output lines */
char nstr[linel], *nc;		/* yacc definition name */
int indef;		/* TRUE if in definition section of yacc input */
int intok;		/* TRUE if in %token, %left, %right statement */
int incom;		/* TRUE if in comment */
int i;			/* work variable */
char c,pr;		/* work variable */

/* check if plausible number of arguments */

if (argc<3) {
	fprintf(stderr,"missing argument(s)\n");
	fprintf(stderr,"ynum input file output file [-n starting value]\n");
	exit(0); 
} else if (argc>5) {
	fprintf(stderr,"too many arguments\n");
	fprintf(stderr,"ynum input file output file [-n starting value]\n");
	exit(0);
} /* else */

/* process input, output and (optional) value arguments */

ivalue = 1;	/* default - begin token values = 1 */
i=0;		/* initialize index in arguments */
ip = NULL;
op = NULL;
while ((++i)<argc) { /* process arguments */
	if (strcmp(argv[i],"-n") == 0) {
		i ++;		/* advance to next argument */
		ivalue = atoi(argv[i]);	/* set integer value */
	} else {
		if (ip == NULL) ip=fopen(argv[i],"r");
		else op=fopen(argv[i],"w");
	} /* else */
} /* while */

/* copy input file to output file, assigning values */

indef = TRUE;		/* flag in definition section */
incom = FALSE;	/* not in comment */
tvalue = ivalue;

while (!feof(ip)) {
	intok = FALSE;	/* flag not in %token, %left, %right */
	iline[0] = '\0';
	fgets(iline,linel-2,ip);	/* read next line of input file  */
	ic = iline;	/* pointer in input line */
	oc = oline;	/* pointer in output line */
	c = '*';
        while ( *ic != '\0') {
		pr = c; c = *ic;
		*oc++ = *ic++;	/* copy to output line */

		/* identify comment */

		if ((pr == '/') && (c == '*')) incom = TRUE;
		if ((pr =='*') && (c == '/')) incom = FALSE;

		/* identify %%, %token, %left, %right */

		if ((c == '%') && indef && (!incom))  {
			intok = FALSE;
			if (*ic == '%') indef = FALSE;
			else {
				nc = nstr;		/* build name */
				while ((isascii(*ic)) && (isalpha(*ic)))
					{ pr = c; c = *ic; *nc++ = c; *oc++ = *ic++;}  

				/* process %token, %left, %right */

				if ((strncmp(nstr,"token",5) == 0) || 
			  	 (strncmp(nstr,"left",4) == 0) || (strncmp(nstr,"right",5) == 0)) {
					intok = TRUE;
					while (*ic == ' ')  { *oc++ = *ic++; }
					pr = '*';	/* don't insert value after yacc directive */
				} /* strncmp if */
			} /* % else */
		} /* % indef if */

		/* assign value to token */

		if (intok && ((*ic == ' ') || (*ic == '\0') || (*ic == '\n') || (*ic == '\t')) 
			&& (isascii(c)) && (isalnum(c))  && (!incom)) {
			sprintf(nstr," %d",tvalue);		/* convert to alpha */
			tvalue++;
			nc = nstr;
			while (*nc != '\0') *oc++ = *nc++; 	/* copy to output */
			c = '*';
		} /* intok if */
	} /* input line while */

	*oc++ = '\0';		/* append newline */
	fputs(oline,op);		/* write line to output file */

} /* input file while */

fclose(ip);
fclose(op);

/* main */ }