
/* A component of the cT (TM) programming environment.  */
/* (c) Copyright 1989 Carnegie Mellon University. */
/* cT is a trademark of Carnegie Mellon University. */
/* All rights reserved. */
/* May not be copied without the written consent */
/* of Carnegie Mellon University.  */


/* C routines specific to MicroSoft Windows version */
    
#include <windows.h>  
#include <mmsystem.h>

#include "baseenv.h"
/* #include <bios.h> */
#include <time.h>
#include <dos.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#ifndef TURBOC
#include <direct.h>
#endif
#include <sys\timeb.h>
#include "time.h"


#include "baseenv.h"
#include "tglobals.h"     
#include "kglobals.h"
#include "compute.h"

#ifdef ctproto
int  breakpt(void);
int  breakpt1(void);
int  breakpt2(int aa);
int  cmdbreakpt(void);
long  TUTORinq_msec_clock(void);
int  FileExists(struct  _fref FAR *fRef);
int  fork(void);
double  gamma(double  a);
long  TUTOR_random(void);
int  TUTORovl_log(int  overlay,int  callret);
int  TUTORlog(char  *str);
int  setfptr(int  FAR *aptr,unsigned int  seg,unsigned int  adr);
char  *strf2n(char  FAR *strp);
char  *strnf2n(char  FAR *strp,int  nn);
int  strlenf(char  FAR *aa);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
char  FAR *strcatf(char  FAR *aa,char  FAR *bb);
int  strcmpf(char  FAR *aa,char  FAR *bb);
int  strcmpnw(char  FAR *aa,char  FAR *bb);
char  FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
char  FAR *strncatf(char  FAR *aa,char  FAR *bb,int  nn);
int  strncmpf(char  FAR *aa,char  FAR *bb,int  nn);
extern char *skip_white(char *sptr);
extern int rand(void);
int  TUTORinq_file_info(struct  _fref FAR *fRef,int  *waccess,long  *length,long  *modtim,int  *posx,int  *posy);
int  execerr(char  *msgstr);
extern int strlen(char *str);
int  TUTORdump(char  *s);
/* extern ftime(); */
#ifdef IBMPROTO
int _CDECL fclose(FILE *);
int _CDECL fprintf(FILE *, const char *, ...);
FILE * _CDECL fopen(const char *, const char *);
#endif /* IBMPROTO */
#endif /* ctproto */

/* ******************************************************************* */

breakpt()
{        

if ((CurrentWindow != ExecWn) && (runflag != halt))
breakpt1();
    return(0);
}

breakpt1()
{
    return(0);
}

breakpt2(barg)
int barg;
{
    return(0);
}

cmdbreakpt()

{
    return(0);
}

/* ******************************************************************* */
         
static int haveTime = 0;
static unsigned long timebase = 0; 
unsigned long lastmsec = 0;

long TUTORinq_msec_clock()  /* return millisecond clock */

{   unsigned long curTime;
#ifdef NOSUCH
	struct timeb timev;
    long secs;  
#endif 
   
   	if (!haveTime) {
   		timebase = timeGetTime(); /* get starting time */   
   		haveTime = TRUE;
   	}  
   	curTime = timeGetTime();
   	if (curTime < timebase) { /* clock has wrapped */
   		lastmsec = curTime+(0xffffffff-timebase);
   	} else lastmsec = curTime-timebase;
 #ifdef NOSUCH
    ftime(&timev);  /* get time structure */
    if (timebase == 0) {
        timebase = timev.time;
    } /* timebase if */
    secs = timev.time-timebase;
    lastmsec = secs*1000L+(long)timev.millitm;   
#endif
    return(lastmsec);

} /* TUTORinq_msec_clock */

/* ******************************************************************* */

char dateStr[10];

static int D0099(val,str) /* convert 2-digit decimal to alpha */
int val; /* value to convert */
char *str; /* result string */

{
    if (val < 10)
	    *str++ = '0';
    sprintf(str,"%d",val);
    return(val);

} /* D0099 */

/* ******************************************************************* */

char *TUTORdate()

{   time_t dateRec;
    struct tm *timeP;

    time(&dateRec);
    timeP = localtime(&dateRec);

    D0099(timeP->tm_mon,dateStr);
    dateStr[2] = '/';
    D0099(timeP->tm_mday,&dateStr[3]);
    dateStr[5] = '/';
    timeP->tm_year += 1900;
    if (timeP->tm_year > 2000)
	    timeP->tm_year -= 2000;
    else
	    timeP->tm_year -= 1900;
    D0099(timeP->tm_year,&dateStr[6]);
    dateStr[8] = 0;
    return(dateStr);

} /* TUTORdate */

/* ******************************************************************* */

char *TUTORtime()

{   time_t dateRec;
    struct tm *timeP;

    time(&dateRec);
    timeP = localtime(&dateRec);
 
    D0099(timeP->tm_hour,dateStr);
    dateStr[2] = ':';
    D0099(timeP->tm_min,&dateStr[3]);
    dateStr[5] = ':';
    D0099(timeP->tm_sec,&dateStr[6]);
    dateStr[8] = 0;
    return(dateStr);

} /* TUTORtime */

/* ******************************************************************* */

double TUTORjdate()

{   time_t timeV;
    double timeD;

    time(&timeV);
    timeD = timeV;
    timeD -= 25568.0*60*60*24; /* center on 0, Jan 1, 1970 */
    timeD -= 3.0*60*60;
    return((double)timeD);

} /* TUTORjdate */

/* ******************************************************************* */

TUTORcvt_path(ssx,fRef,baseRef,isFile) /* convert file string to fRef */
char *ssx; /* a file name, possibly partial */
FileRef FAR *fRef; /* complete file reference, to be created */
FileRef FAR *baseRef; /* directory to work from */
int isFile; /* TRUE if includes file name, false if path only */
/* returns TRUE if ssx is valid path, FALSE otherwise */
    
{   char *ss, buffer[CTPATHLEN];
    int mlen;
    char FAR *pp;
    int fullF; /* TRUE if presumed full path */

    fRef->path[0] = '\0';
    fRef->nameInd = 0;
    if (baseRef)
        fRef->drive = baseRef->drive;
    else if (ctDirP)
		fRef->drive = ctDirP->drive;   
	else fRef->drive = _getdrive();

    /* we don't want leading spaces */
    while (*ssx == ' ')
        ssx++;

    /* strip trailing spaces */
    mlen = strlen(ssx);
    /* strip trailing spaces */
    while (mlen > 0 && ssx[mlen-1] == ' ')
        mlen--;

    if (mlen == 0)
        return(FALSE); /* no file name */

    strcpy(buffer,ssx); /* make copy of path (so we don't modify the original) */
    buffer[mlen] = '\0';
    ss = buffer;
    /* conversion to lower case done only on full path so as */
    /* not to convert font names (Arial) */
    fullF = ((buffer[1] == ':') || (buffer[0] == '/') || (buffer[0] == '\\'));

    while (*ss) {
        if (*ss == '/') {
            *ss = '\\'; /* convert slash to backslash */
        } else if (fullF && (*ss >= 'A') && (*ss <= 'Z')) /* convert to lower case */
        	*ss = (*ss -'A')+'a';   
		ss++;
    } /* while */

    if (buffer[1] == ':') { /* already a full path, with drive */
        if (buffer[0] < 'a' || buffer[0] > 'z')
            return(FALSE); 
        fRef->drive = buffer[0] - 'a' + 1;
        strcpyf(fRef->path,(char FAR *) buffer + 2);
        pp = fRef->path+strlenf(fRef->path)-1;
        while (*pp != '\\')
            pp--; /* scan backwards for beginning of file name */
        fRef->nameInd = (pp-(char FAR *)fRef->path)+1;
        return(TRUE);
    } else if (buffer[0] == '\\') {
		strcpyf(fRef->path,(char FAR *)buffer);
		if (isFile) {
			pp = fRef->path+strlenf(fRef->path);
			while (*pp != '\\')
				pp--; /* scan backwards for beginning of file name */
			fRef->nameInd = (pp-(char FAR *)fRef->path)+1;
		} /* isFile */
		return(TRUE);
    } /* buffer[0] */
   
    ss = buffer;
    if (ss[0] == '~'){  
        /* user name reference */
        while (*ss && *ss != '\\')
            ss++; /* we want to scan past the user name token */
    } else if (ss[0] == '.' && ss[1] == '\\') {
        /* reference to current working directory (baseRef) */
        ss += 2; /* skip the ./ */
		if (baseRef) {
			strncpyf(fRef->path,baseRef->path,baseRef->nameInd);
			fRef->path[baseRef->nameInd] = '\0';
		}
    } else if (ss[0] == '\\') {
        /* full path (without drive) */
        fRef->path[0] = '\0';
    } else {
        /* not a full path, must be in working directory */
		if (baseRef) {
			strncpyf(fRef->path,baseRef->path,baseRef->nameInd);
			fRef->path[baseRef->nameInd] = '\0';
		}
    }

    if (strlenf(fRef->path) + strlen(buffer) > FILEL)
	return(FALSE);

    strcatf(fRef->path,(char FAR *) ss);
    pp = fRef->path + strlenf(fRef->path) - 1;
    while ((*pp != '\\') && (*pp != ':') && (pp > fRef->path))
	pp--; /* scan for beginning of file name */
    if ((*pp == '\\') || (*pp == ':'))
	fRef->nameInd = (pp - (char FAR *)fRef->path) + 1;

    return(TRUE); /* we always concoct a full path name */

} /* TUTORcvt_path */

/* ******************************************************************* */

FileExists(fRef) /* return TRUE if file "s" exists */
FileRef FAR *fRef;

{   long length;

    if (fRef->path[0] == 0)
        return(FALSE);
    TUTORinq_file_info(fRef,NEARNULL,&length,NEARNULL,NEARNULL,NEARNULL);
    if (length >= 0)
        return(TRUE);
    else return(FALSE);

} /* FileExists */

/* ******************************************************************* */

int fork() /* UNIX fork */

{
    return(0); /* 0 = process did not fork */

} /* fork */

/* ******************************************************************* */

double gamma(a)
double a;

{
    return(a);

} /* gamma */

/* ******************************************************************* */

long TUTOR_random()

{
    return(rand());

} /* TUTOR_random */

/* ******************************************************************* */

static int rwf = 0;

TUTORlog(str)   /* write to log file */
char *str;      /* pointer to string to write */

{   FILE *logfp;
    char fileStr[80];

    fileStr[0] = 0;
    if (ctDirP) { /* if cT directory set up */
	fileStr[0] = ctDirP->drive+'A'-1;
	fileStr[1] = ':';
	strcpyf((char FAR *)fileStr+2,ctDirP->path);
	fileStr[ctDirP->nameInd+2] = 0;
    }
    strcat(fileStr,"ct.log");
    if (rwf == 0) {
	logfp = fopen(fileStr,"w");
        rwf = 1;
    } else {
	logfp = fopen(fileStr,"a");
    } /* else */

    if (logfp == NULL) return(0);
    fprintf(logfp,"%s",str);
    if (str[strlen(str)-1] != '\n')
        fprintf(logfp,"\n");
    fclose(logfp);

} /* TUTORlog */

/* ******************************************************************* */

static char localstr[MAXNEARLEN+8]; /* local copy of string */

char *strf2n(strp)    /* convert far string to near */
char FAR *strp;

{   char *nstrp; /* far pointer to near string */

    localstr[MAXNEARLEN] = '*';
    nstrp = localstr;
    while (*nstrp++ = *strp++);
    if (localstr[MAXNEARLEN] != '*') 
		TUTORdump("strf2n");
    return(localstr);

} /* strf2n */

/* ******************************************************************* */

char *strnf2n(strp,nn)  /* convert far string to near */
char FAR *strp;
int nn;

{   char *nstr;

    nstr = localstr;
    localstr[MAXNEARLEN] = '*';
    while ((nn > 0) && (*nstr++ = *strp++)) {
        nn--;
        if (localstr[MAXNEARLEN] != '*') TUTORdump("strnf2n");
    }
    return(localstr);

} /* strnf2n */

/* ******************************************************************* */

int strlenf(aa)
char FAR *aa;

{   long count;

    count = 0;
    while (*aa++) count++;
    return(count);

} /* strlenf */


/* ******************************************************************* */

char FAR *strcpyf(aa,bb)  /* copy two far character strings */
char FAR *aa;
char FAR *bb;

{
    while (*aa++ = *bb++);

} /* strcpyf */

/* ******************************************************************* */

char FAR *strcatf(aa,bb)  /* concatenate two far character strings */
char FAR *aa;
char FAR *bb;

{
    while (*aa) aa++;
    while (*aa++ = *bb++);

} /* strcatf */

/* ******************************************************************* */

int strcmpf(aa,bb) /* compare two far character strings */
char FAR *aa;
char FAR *bb;

{
    while(TRUE) {
        if (*aa != *bb) {
            if (*aa > *bb) return(1);
            else return(-1);
        } /* if */
        if (!(*aa)) 
            return(0);
        aa++;
        bb++;
    } /* while */

} /* strcmpf */

/* ******************************************************************* */

char FAR *strncpyf(aa,bb,nn) /* copy two far character strings */
char FAR *aa;
char FAR *bb;
int nn;

{
    while ((nn > 0) && (*aa++ = *bb++)) nn--;

} /* strncpyf */

/* ******************************************************************* */

char FAR *strncatf(aa,bb,nn)  /* concatenate two far character strings */
char FAR *aa;
char FAR *bb;
int nn;

{
    while (*aa) aa++;
    while ((nn > 0) && (*aa++ = *bb++)) nn--;

} /* strcatf */

/* ******************************************************************* */

int strncmpf(aa,bb,nn) /* compare two far character strings */
char FAR *aa;
char FAR *bb;
int nn;

{
    while (nn > 0) {
        nn--;
        if (*aa != *bb) {
            if (*aa > *bb) return(1);
            else return(-1);
        } /* if */
        if (!(*aa)) 
            return(0);
        aa++;
        bb++;
    } /* while */
    return(0);

} /* strncmpf */

/* ******************************************************************* */

char *skip_white(sptr) /* skip over white space */
char *sptr; /* pointer to characters to examine */

{
    while ((*sptr == ' ') || (*sptr == '\t'))
	sptr++;
    return(sptr);

} /* skip_white */

/* ******************************************************************* */

TUTORblock_move(sp,dp,nMove) /* move bytes from one place to another */
char FAR *sp; /* source pointer */
char FAR *dp; /* dest pointer */
long nMove; /* # of bytes to move */

{   char SHUGE *spH; /* source */
    char SHUGE *dpH; /* destination */
    long spl, dpl;

    if (nMove <= 0) 
        return(0); /* nothing to do */
    spH = sp; /* use huge pointers so arithmetic correct */
    dpH = dp;
	spl = spH; /* get source      offset */
	dpl = dpH; /* get destination offset */

	if (spl > dpl) while (nMove--) *dpH++ = *spH++;
	else {
	    spH += (nMove-1);
	    dpH += (nMove-1);
	    while (nMove--) *dpH-- = *spH--;
	} /* else */
	return(0);

} /* TUTORblock_move */

/* ******************************************************************* */

TUTORzero(ptr,len) /* zero block of memory */
register char FAR *ptr; /* address of block */
register long len; /* length of block */

{   char SHUGE *ptrH; /* huge pointer so arithmetic correct */

    if (len <= 0)
        return(0); /* nothing to do */
    ptrH = ptr;
	while(len-- > 0)
		*ptrH++ = 0;
	return(0);
		
} /* TUTORzero */

/* ******************************************************************* */
