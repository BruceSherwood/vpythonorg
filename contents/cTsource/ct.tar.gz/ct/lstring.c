
/* ******************************************************************* */

#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <signal.h>
#include <bios.h>
#include <dos.h>
#include <malloc.h>
#include <string.h>

/* ******************************************************************* */

extern char *strf2n(char far *str);
extern char *strnf2n(char far *str,int len);
extern int strlenf(char far *str);
extern char far *strcpyf(char far *s1,char far *s2);
extern char far *strcatf(char far *s1,char far *s2);
extern int strcmpf(char far *s1,char far *s2);
extern char far *strncpyf(char far *s1,char far *s2,int len);
extern char far *strncatf(char far *s1,char far *s2,int len);
extern int strncmpf(char far *s1,char far *s2,int len);

/* ******************************************************************* */

#define TRUE 1
#define FALSE 0
#define MAXNEARLEN 1024

static char localstr[MAXNEARLEN+8]; /* local copy of string */

/* ******************************************************************* */

char *strf2n(strp)    /* convert far string to near */
char far *strp;

{   char *nstrp; /* far pointer to near string */

    localstr[MAXNEARLEN] = '*';
    nstrp = localstr;
    while (*nstrp++ = *strp++);
    if (localstr[MAXNEARLEN] != '*') 
	while (TRUE); /* hang */
    return(localstr);

} /* strf2n */

/* ******************************************************************* */

char *strnf2n(strp,nn)  /* convert far string to near */
char far *strp;
int nn;

{   char *nstr;

    nstr = localstr;
    localstr[MAXNEARLEN] = '*';
    while ((nn > 0) && (*nstr++ = *strp++)) {
        nn--;
	if (localstr[MAXNEARLEN] != '*') while(TRUE); /* hang */
    }
    return(localstr);

} /* strnf2n */

/* ******************************************************************* */

int strlenf(aa)
char far *aa;

{   long count;

    count = 0;
    while (*aa++) count++;
    return((int)count);

} /* strlenf */

/* ******************************************************************* */

char far *strcpyf(aa,bb)  /* copy two far character strings */
char far *aa;
char far *bb;

{
    while (*aa++ = *bb++);
    return(aa);

} /* strcpyf */

/* ******************************************************************* */

char far *strcatf(aa,bb)  /* concatenate two far character strings */
char far *aa;
char far *bb;

{
    while (*aa) aa++;
    while (*aa++ = *bb++);
    return(aa);

} /* strcatf */

/* ******************************************************************* */

int strcmpf(aa,bb) /* compare two far character strings */
char far *aa;
char far *bb;

{
    while(TRUE) {
        if (*aa != *bb) {
            if (*aa > *bb) return(1);
            else return(-1);
        } /* if */
        if (!(*aa)) 
            return(0);
        aa++;
        bb++;
    } /* while */
    return(0);

} /* strcmpf */

/* ******************************************************************* */

char far *strncpyf(aa,bb,nn) /* copy two far character strings */
char far *aa;
char far *bb;
int nn;

{
    while ((nn > 0) && (*aa++ = *bb++)) nn--;
    return(aa);

} /* strncpyf */

/* ******************************************************************* */

char far *strncatf(aa,bb,nn)  /* concatenate two far character strings */
char far *aa;
char far *bb;
int nn;

{
    while (*aa) aa++;
    while ((nn > 0) && (*aa++ = *bb++)) nn--;
    return(aa);

} /* strcatf */

/* ******************************************************************* */

int strncmpf(aa,bb,nn) /* compare two far character strings */
char far *aa;
char far *bb;
int nn;

{
    while (nn > 0) {
        nn--;
        if (*aa != *bb) {
            if (*aa > *bb) return(1);
            else return(-1);
        } /* if */
        if (!(*aa)) 
            return(0);
        aa++;
        bb++;
    } /* while */
    return(0);

} /* strncmpf */

/* ******************************************************************* */
