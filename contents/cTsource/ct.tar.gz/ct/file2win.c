
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989, 1992 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* ******************************************************************* */

#include <io.h>
#include <stdio.h>
#include <dos.h>

#define STRICT
#include <windows.h>

#include "baseenv.h"
#include "compute.h"
#include "ecglobal.h"
#include "tfiledef.h"
#include "tglobals.h"
#include "kglobals.h"

/* ******************************************************************* */

extern int uplow(char FAR *str);
extern int TUTORdump(char *msg);  
extern int TUTORzero(char SHUGE *bb,long len);
extern __cdecl _chdir(const char *ss);
int TUTORdelete_file(FileRef FAR *fRef);
extern int TUTORset_dir(FileRef FAR *path);
extern int TUTORset_file_dir(FileRef FAR *path);
int  TUTORcvt_path(char  *ssx,struct  _fref FAR *fRef,struct  _fref FAR *baseRef,int fileF);
int  TUTORopen_serial(int  port,int  baud,int  datab,int  parity,double  stopb);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
char  FAR *GetPtr(unsigned int  mm);
int  ReleasePtr(unsigned int  mm);
int  TUTORset_hsize(unsigned int  mm,long  newsize,int  abort);
char  *strf2n(char  FAR *strp);
char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
int  killptr(char  FAR * FAR *ptr);
extern TUTORblock_move(char FAR *sp, char FAR *dp, long lth);
char  FAR *strncpyf(char  FAR *aa,char  FAR *bb,int  nn);
int  strlenf(char  FAR *aa);
int  strcmpf(char  FAR *aa,char  FAR *bb);
long  TUTORwrite_socket(int  ss,char  FAR *buf,long  len);
long  TUTORread_socket(int  ss,char  FAR *buf,long  maxLen);
int TUTORcopy_fileref(FileRef FAR *fDest,FileRef FAR *fSource);
int TUTORcmp_fileref(FileRef FAR *f1,FileRef FAR *f2);
int TUTORcopy_fileref_name(FileRef FAR *fRef,char FAR *name); 
int TUTORcopy_fileref_dir(FileRef FAR *dirname,FileRef FAR *fullname);
int TUTORinq_fref(int findx,FileRef FAR *fref);
int TUTORsymbolic_fileref(FileRef FAR *fRef,char FAR *syms); 
int TUTORget_fileref_name(FileRef FAR *fRef,char FAR *name);
int TUTORopen(FileRef FAR *fRef,int rf,int wf,int af);
int file_slot(void);
int TUTORclose(int findx);
int TUTORflush_file(int findx);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
long  TUTORwrite(char  FAR *ptr,int  pSize,long  count,int  findx);
long  flrdwr(char  FAR *ptr,int  pSize,long  count,int  findx,int  rwFlag);
int TUTORfile_at_eof(int findx);
int TUTORfile_exists(FileRef FAR *fRef);
int TUTORstat(FileRef FAR *fRef,struct stat *buff);
long TUTORinq_file_pos(int findx); 
int TUTORinq_file_err(int findx);
int TUTORset_file_type(FileRef FAR *fRef,int findx,int type,int xx,int yy);
int TUTORreset_file(int findx,int option); 
int TUTORtemp_file_name(FileRef FAR *baseN,FileRef FAR *tempN); 
int TUTORungetc(int findx,int cc);
int TUTORget_char(int findx,int tryHard);
int TUTORread_char(unsigned char *cc,int findx);
int TUTORread_string(unsigned char *str,int length,int findx); 
int TUTORread_short(short *ss,int findx);
int TUTORread_int(int *ii,int findx);

/* ******************************************************************* */

int TUTORrename_file(fOld,fNew) /* rename file, return TRUE if worked */
FileRef FAR *fOld, FAR *fNew;

{   int rret;
    char tempS[FILEL+1];
	FileRef svRef;

    if (fOld->drive != fNew->drive)
    TUTORdump("Attempt to change drives in TUTORrename_file");

	svRef = *currentDirP; /* save current directory */
	TUTORset_file_dir(fNew);
    strcpyf((char FAR *) tempS,fNew->path);
    rret = rename(strf2n(fOld->path),tempS);
    TUTORset_dir((FileRef FAR *)&svRef);
    return(rret == 0);

} /* TUTORrename_file */

/* ******************************************************************* */

int TUTORdelete_file(fRef) /* delete file, return TRUE if worked */
FileRef FAR *fRef;

{   int dret;
	FileRef svRef;

	svRef = *currentDirP; /* save current directory */
	TUTORset_dir(fRef); 
    dret = _unlink(strf2n(fRef->path));
    TUTORset_dir((FileRef FAR *)&svRef); /* restore directory */
    return(dret == 0);

} /* TUTORdelete_file */

/* ******************************************************************* */

int TUTORopen_serial(port,baud,datab,parity,stopb)
int port; /* 1 = com1, 2 = com2, etc */
int baud; /* baud rate (300,1200,etc) */
int datab; /* number of data bits (5,6,7,8) */
int parity; /* 0 = even parity, 1 = odd parity, else no parity */
double stopb; /* number of stop bits (1.0, 1.5 or 2.0) */

{   return(0);
#ifdef NOSUCH
{   struct tutorfile FAR *tfp; /* pointer to file table entry */
    int fIndx; /* index in file table */
    int comID; /* OpenComm reply */
    int comRet;
    char wBuff[32]; /* work space for device/mode string */
    char cBuff[32]; /* device control string */
    DCB devControl; /* device control block */

    tfilerr = FILENOTOPEN; /* pre-set for error */
    if ((port < 1) || (port > 9))
	return(0);

    /* open comm port */

    sprintf(wBuff,"COM%d",port);
    comID = OpenComm((LPCSTR)wBuff,512,512);
    if (comID < 0)
	return(0);

    /* build control string ala mode command */

    strcpy(cBuff,wBuff); /* COMn string */
    sprintf(wBuff,":%d,",baud); /* baud rate */
    strcat(cBuff,wBuff); /* COM1:9600, */
    if (parity == 0) wBuff[0] = 'e'; /* even parity */
    else if (parity == 1) wBuff[0] = 'o'; /* odd parity */
    else wBuff[0] = 'n'; /* no parity */
    wBuff[1] = 0;
    strcat(cBuff,wBuff); /* COM1:9600,e */
    sprintf(wBuff,",%d,",datab);
    strcat(cBuff,wBuff); /* COM1:9600,e,7, */
    if (stopb < 1.1) strcpy(wBuff,"1");
    else if (stopb > 1.9) strcpy(wBuff,"2");
    else strcpy(wBuff,"1.5");
    strcat(cBuff,wBuff); /* COM1:9600,e,7,1 */

    /* set comm state */

    comRet = BuildCommDCB((LPCSTR)cBuff,(DCB FAR *)&devControl);
    if (comRet)
	return(0); /* something went wrong */
    comRet = SetCommState((DCB FAR *)&devControl);
    if (comRet)
	return(0); /* something went wrong */

    /* set up file table entry */

    fIndx = file_slot(); /* locate free file table slot */
    tfp = fIndx+(struct tutorfile FAR *) GetPtr(filesopen);
    TUTORzero((char FAR *)&tfp->fRef,(long)sizeof(FileRef));
    tfp->inuse = TRUE; /* mark file table entry in use */
    tfp->lastop = fop_open; /* no operations yet */
    tfp->ro = FALSE; /* set read-only flag */
    tfp->styles_allowed = FALSE;
    tfp->format = -1;
    tfp->crKind = -1;
    tfp->kind = 1; /* serial port */
    tfp->stream = comID; /* ID of port in use */
    ReleasePtr(filesopen);
    tfilerr = -1; /* exit happy */
    return(fIndx);
#endif

} /* TUTORopen_serial */

/* ******************************************************************* */

int TUTORset_file_dir(path) /* set directory from file path */
FileRef FAR *path; /* partial or complete path, including file name */

{	int ret;
	FileRef fRef; /* full path to file */

	ret = TUTORcvt_path(strf2n(path->path),(FileRef FAR *)&fRef,currentDirP,TRUE);
	if (!ret) return(FILEMISSING);
	uplow(fRef.path); /* all lower case */
	ret = TUTORset_dir(&fRef); /* set working directory */
	return(ret);

} /* TUTORset_file_dir */

/* ******************************************************************* */

int TUTORset_dir(path) /* set current working directory */
FileRef FAR *path; /* directory path */

{   FileRef fRef;
	FileRef baseRef;
    int ret,ii;
    char pathStr[CTPATHLEN];
	
	if (strlenf(path->path) == 0)
		return(FILEMISSING);

	/* normalize file path + name */

	baseRef = *currentDirP;
	strcpyf((char FAR *)pathStr,path->path);
    ret = TUTORcvt_path(pathStr,(FileRef FAR *)&fRef,
		                (FileRef FAR *)&baseRef,FALSE);

	/* handle case of drive change */

	if (ret && (fRef.drive != baseRef.drive) && 
		(fRef.drive > 0) && (fRef.path[1] != ':')) { /* don't have drive + full path */
		pathStr[0] = fRef.drive+'a'-1;
		pathStr[1] = ':';
		pathStr[2] = 0;
		if (fRef.path[0] != '\\') {
			strcat(pathStr,"\\");
		}
		strcat(pathStr,fRef.path);
		ii = strlen(pathStr);
		while (ii && (pathStr[ii] != '\\'))
			ii--;
		if (ii) pathStr[ii] = 0;
	} else strcpy(pathStr,fRef.path); /* just copy path */

	if (!ret) return(FILEMISSING); /* invalid path */

	SetCurrentDirectory(pathStr);
    *currentDirP = fRef;
    if (ret) return(-1);
    else return(FILEMISSING);
	
} /* TUTORset_dir */

/* ******************************************************************* */

TUTORflush_file(findx) /* flush file buffer */
int findx; /* index in file table (returned by TUTORopen) */

{   struct tutorfile FAR *tfp;    
    FILE *ffp;
	int retF; /* return value */

    if (findx <= 0)
		return(FALSE);

	retF = TRUE; /* pre-set worked */
    tfp = findx+(struct tutorfile FAR *)GetPtr(filesopen);
    ffp = tfp->fp;

    switch (tfp->kind) {
    case 0: /* normal file */
        if (ffp) {
			retF = fflush(ffp);
			retF = (retF ? FALSE: TRUE); /* FALSE if error */
			if (retF) 
				if (ferror(ffp)) retF = FALSE;
		}
        break;
    case 1: /* serial port */
        break;
    case 2: /* socket */
        break;
    case 4: /* EMS */
        break;
    case 5: /* XMS */
        break;
    } /* switch */

    ReleasePtr(filesopen); 
    return(retF);

} /* TUTORclose */

/* ******************************************************************* */
 
