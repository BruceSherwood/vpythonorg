
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/*
Definitions for cglobals.
KSW 9/88

*/
#ifndef _cglobalsh
#define _cglobalsh

#ifndef setjmp_d
#include "setjmp.h"
#define setjmp_d
#endif

typedef union {
  int ival;
  long lval;
  double dval;
  long defloc; 
} YYSTYPE;

/* from ecglobal */
extern long curvbytes; /* number bytes (global or local) var storage allocated */
extern struct xtoken FAR *xtokd; /* pointer to expression analyzer destination stack */
extern int ntokd; /* number tokens in destination stack */
extern int xtokmalloc; /* current size of expression analyzer stacks */
/* input preprocessor variables */
#define CBUFFSIZE 1000
extern unsigned char cB[CBUFFSIZE+2]; /* input buffer */
extern char buffFull; /* TRUE if buffer filled without finishing line */
extern char refillBuff; /* TRUE if need to refill buffer to finish compiling command */
extern char continFlag; /* TRUE if command is a continuation */
extern int nBuffChars; /* # of characters in buffer */
extern int cI; /* current position in buffer */
extern int ciStart; /* start of current line in buffer */
extern char nocliptext; /* TRUE if old scheme of not clipping at bottom margin */
extern char oldfontsize; /* TRUE if old font size meaning top of Y to bottom of y */
extern char wrapwrite;	/* TRUE if -write- commands (& show family) should wrap */
extern char oldcolor; /* TRUE if old -rgb- and color scheme */
extern char nostylemarkf; /* TRUE if no styles in markers */
extern char allowcoarse; /* TRUE if coarse grid co-ordinates allowed */
extern long srcEnd; /* end position of current compile (usually unit end) */

extern Memh condTh;
extern short condTalloc;
extern int nCondTag;

extern Memh xrefH; /* handle on cross-reference table for this unit */
extern struct locref FAR *xrefP; /* address of reference table */
extern int xrefL; /* current length of reference table */

extern Memh srbimapH; /* handle on source/binary map for this unit */
extern struct srbimap FAR *srbimapP; /* pointer to map */
extern int srbimapL; /* length of source/binary map */

extern int nconvert;	/* number of times conversion attempted */


/* regular variables */
extern int pgen;	/* TRUE if should generate p-code */
extern unsigned int cstartcommand; /* start of conditional command binary */
extern unsigned int cstartcommand; /* start of conditional command binary */
extern int condref1; /* index of address of end of command */
extern int condref2; /* index of address of table */
extern unsigned int condref3; /* address of maximum integer value */

extern int condcount; /* number of tags in conditional command */

extern int global_def_fin; /* TRUE if compile of global defines completed */
extern int local_def_fin; /* TRUE if compile of local defines completed */
extern int npass_by_value; /* number pass-by-value arguments of this unit */
extern int npass_by_addr; /* number pass-by_address arguments of this unit */
extern Memh uargH; /* handle on unit arguments table */
extern struct argdef FAR *uargP; /* pointer to unit arguments */

extern struct expra *exa; /* ptr to expr analyzer input/output params */
extern struct expra defexp; /* default expr analyzer params */

extern long startofline; /* start of source line */
extern long startcommand; /* pcode loc of command */
extern int newcmd; /* current command being compiled */
extern int addcmd; /* command code to add to pcodes */
extern int lastcmd;
extern int chkeol; /* TRUE should check for NEWLINE at end of command */
extern long countloc;
extern int argcount;
extern char condFlag; /* on a command, 0: not conditional, 1: started, 2: expression, 3: tags */

extern struct indenter indent[MAXINDENTS];
extern struct caseopt caseod[MAXINDENTS]; /* -case- command optimization */

extern int indentlevel;
extern int breaklevel; /* indent level of OUTLOOP, RELOOP, OUTIF, OUTCASE */

extern jmp_buf CompileLineenv;		/* saved enviornment for longjmp */

extern long prevend;	/* index of end of previous expression */
extern unsigned char appendok;	/* TRUE if ok to append to previous expression */
extern long loopexit;	/* index of -loop- exit code */
extern int topw;	/* index of current top of working stack */
extern int endopc;	/* ENDF/ENDI/ENDM code */
extern long narrayi;	/* number items in store-able array */
extern int multei;	/* index of multiple expression */
extern long multeic[NMULTE];	/* index to p-code type byte of multiple expression */

extern int parencnt;  /* no. of left parens minus right parens */
extern int embedcnt;  /* no. of left embeds minus right embeds */
extern int ibranf;	/* internal branch(es) present flag */
extern int indexcnt;  /* number of indices in an array */

extern int oldcmd; /* previous command */
extern int thislevel;  /* indent level of this command */
extern int cmd; /* command found by lex */
extern long cmdsourceloc; /* start of source statement */
extern long currentkind; /* current -define- type (TFLOAT, TBYTE, etc.) */
extern int haslocalfiles; /* TRUE if setfile/addfile local file */
extern long startgetcmd;	/* position at start of command line */
extern int keyword_counter; /* count of keywords processed in this command */

extern YYSTYPE yylval;
extern int previous;	/* previous state */

#endif  /* _cglobalsh */
