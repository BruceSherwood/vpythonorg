
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* definitions common to all environments */

#ifndef _basich
#define _basich

#ifndef NIL
#define NIL 0L
#endif
#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif
#ifndef pi
#define pi 3.1415926535897932
#endif

#ifdef MAC
#include <string.h>
#endif

typedef long Coord; /* type of coordinate variable */
extern int RoundCoord();
extern double CoordToFloat();
extern Coord IntToCoord(), FloatToCoord(), MulCoord(), DivCoord();
extern Coord HalveCoord(), AbsCoord();

#define NAMEL 31  /* max unit name length is 30 (plus 0) */
#define NMULTE 10	/* max number multiple expressions */
#define CTPATHLEN 1024  /* max file pathname length */
#define STRINGLEN 80	/* a medium size string length */

#ifndef SYMANTECH
char FAR *GetPtr(); /* handle dereferencer */
#endif

typedef unsigned int Memh;

/* defines for memory manager functions */
#define M_NOPURGE		0x01
#define M_REALLOC		0x02
#define M_RPROC		0x04
#define M_WORM			0x08
#define M_WMRM			0x010
#define M_PURGEABLE	0x020
#define M_NOTINMEM		0x040
#define M_TYPEMASK		(M_NOPURGE | M_REALLOC | M_RPROC | M_WORM | M_WMRM)

#ifdef CTDEBUG
#define PTRDEBUG
#endif

#ifdef PTRDEBUG

#define KillPtr(p) (killptr((char FAR * FAR *)(&p)))
#define REGISTER
#ifdef ctproto
#ifndef MAC /* mac doesn't like multiple prototypes */
extern int killptr(char FAR * FAR *pp);
#endif /* MAC */
#endif /* ctproto */

#else /* PTRDEBUG */

#define KillPtr(p)
#define REGISTER register
#endif /* PTRDEBUG */

extern Memh TUTORhandle();
extern long TUTORget_hsize();
extern char FAR *TUTORalloc();
extern char FAR *TUTORrealloc();

typedef struct _tpoint
	{
	short vv,hh;
	} TPoint;

typedef struct _trect
	{
	short top,left,bottom,right;
	} TRect;

struct markvar { /* ct marker variable */
	unsigned short doc; /* handle on base document */
	short alteredF; /* flags */
	             /* 0:lowest bit = document altered flag */
	             /* 1:           = -compute- flag */
	             /* 2:           = indirect unit flag */
	             /* 3:           = view flag */
	             /* 4:           = sticky flag */
	short ctvar; /* TRUE if cT marker variable, FALSE if internal */
	short attached; /* TRUE if attached to document update chain */
	short unitNum;	/* number of unit this marker references (or 0) */
	unsigned short nextstack;	/* stack of next marker on this doc */
	unsigned short prevstack;	/* stack of previous marker on this doc */
	short dddu; /* fill for mac */
	long nextm; /* relative loc of next marker on this doc */
	long prevm; /* relative loc of previous marker */
	long pos; /* position of marked region */
	long len; /* length of marked region */
	long doclen; /* length of base document */ 
	long vaddr; /* address of marker variable */
#ifdef IBMPC
    short fildum[12]; /* fill structure out to 64 bytes */
#endif
}; /* markvar */

/* number of different kind of text styles (see txt.h) */
#define NSTYLES 6

/* simple-model color definitions */

#define color_defaultf -1
#define color_defaultb -2
#define color_rgb -3
#define color_black 0
#define color_white 1

/* menu definitions */

#ifndef MAC
#define MENUNAMEL 64
#ifndef WINPC
#define MPULLDOWN
#endif
#else
#define MENUNAMEL 1
#endif

/* Menu definitions */

typedef struct _tmi { /* definition of single item (either menu item or card header) */
	char name[MENUNAMEL]; /* wm only */
	unsigned char state;
	unsigned char itemKind;
	unsigned char isAuthor; /* for cards, true only if ALL items are author items */
	short type; /* for items only */
	short cardI; /* item: index of card header, card(MAC): system id for card */
	short priority;
	short nnth; /* this item is nnth in its list (card or menubar) */
	short unit; /* items only */
	double unitArg; /* items only */
	short eventType; /* items only - kind of event generated */
#ifdef WINPC
    int nItems; /* number items on card */
    long menuitemH; /* handle on menu item */
    long menuidN;   /* identifier for this menu item */
#endif
#ifdef MPULLDOWN
	int nitems; /* number items on card */
	int mindex; /* display order index of card/item */
	int width; /* display width of card */
	int p1; /* starting x/y position of card/item */
	int p2; /* ending x/y position of card/item */
	int altered; /* card/item altered flag */
#endif
} TutorMenuItem;

typedef struct _tmb {/* definition of menu bar */
#ifdef WINPC
    long menubarH; /* handle on menu bar */
#endif
	long theBar; /*MAC: handle to menubar, wm: T/F flag indicating whether this bar is showing */
	short nItems;
	TutorMenuItem items[1]; /* variable length array */
} TutorMenuBar;

/* dynamic arrays */
typedef struct _dah
	{
	long dAnn;		/* # of items in array */
	long dAnAlloc;	/* # of items in use */
	unsigned short nBuff;	/* # of items extra we want around */
	unsigned short itemSize;	/* size (in bytes) of each item */
	} DArrayHeader;

/* null Memh handle: */
#define HNULL ((Memh) 0)

char FAR *AskUser();
extern unsigned char CharAt();

#endif  /* _basich */
