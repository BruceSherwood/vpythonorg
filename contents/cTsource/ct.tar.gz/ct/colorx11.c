
/*
A component of the cT (TM) programming environment.
(c) Copyright 1991 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University. */


#include <X11/Xatom.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xresource.h>
#include <X11/cursorfont.h>
#include <X11/keysym.h>


#include "baseenv.h"
#include "tutor.h"
#include "kglobals.h"
#include "tglobals.h"

#include "wmx11.h"

/* ******************************************************** */

#ifdef ctproto
extern int TUTORpalettize_rgb(int type,unsigned char FAR *pixelsP,long inRow,
	   unsigned char FAR *outP,long outRow,Memh paletteH,int width,int height);
extern int  TUTORabs_restore_region(long  id,int  x1,int  y1);
extern int TUTORfree_region(long id);
extern long  TUTORabs_save_region(int  x1,int  y1,int  x2,int  y2);
extern long TUTORmem_to_region(int type,int width,int height,Memh palH,unsigned char SHUGE *bP);
int  CTcount_colors(int oldF);
extern char *GetPtr(Memh mm);
extern int ReleasePtr(Memh mm);
int CTmap_default_color(int cn);
int CTmap_color(int wn, int cn, int foreFlag);
int CTchange_palette(int wn, Memh newPal, int sizeWanted, int *pSet, int allNew);
int CTinit_color(void);
int CTset_foreground_color(int cn);
int CTset_background_color(int cn);
int CTanimate_color(int cn, unsigned int red, unsigned int green, unsigned int blue);
int CTinq_rgb_system(int cn, double *red, double *green, double *blue);
#endif /* ctproto */

extern long TUTORabs_save_image();
extern long TUTORabs_save_region();
extern long TUTORload_region_ppm();
extern long TUTORmem_to_region();
extern unsigned long GetX11PixelValue();
extern Memh TUTORget_default_rgb();
extern XColor FAR *lookBestColor();
extern long TUTORinq_msec_clock();

/* ******************************************************** */

extern Display *display;
extern int screen;
extern XColor whiteX, blackX;
extern int currentXwindow;
extern Visual *visual; /* default visual */
extern int pd_barheight; /* pull-down menu bar height */
extern XGCValues gcv;
extern GC gc, gcpatt;
extern Drawable drawwindow; /* the window to draw into */

static int fixedColor; /* TRUE if color look-up only */

Colormap X11defMap; /* X11 default color map */
Colormap cTdefMap; /* cT's default color map */
long colorsAvail = 2; /* hardware colors available */
int MillionsColor = FALSE; /* TRUE if truecolor display */
int ReadOnlyColor = FALSE; /* TRUE if static color */

static int colorsSet = FALSE; /* TRUE if colors set up */
static int gDoMap = FALSE; /* TRUE if need to read colormap */
static XColor EditColors[8]; /* colors for edit window */
static XColor ExecColors[256]; /* colors for execute window */
static char ExecAlloc[256]; /* TRUE if color cell allocated */
static char ExecRO[256]; /* TRUE if colormap slot ever used */
static XColor pixelValues[256]; /* current pixel values */
static int sysNColors = 0; /* number colors set in system palette */
static XColor systemColors[256]; /* current system palette */

/* ******************************************************** */

CTinit_color()
	
{	long colorDepth; /* number color planes */
	int pii; /* index in colors */
	int allocF; /* TRUE if allocated color cells */
	unsigned long pixelV[8]; /* pixel values */

	if (currentXwindow < 0)
		TUTORdump("no window, cant init color");
	
	TUTORzero((char FAR *)EditColors,(long)(8*sizeof(XColor)));
	TUTORzero((char FAR *)ExecColors,(long)(256*sizeof(XColor)));
	TUTORzero((char FAR *)pixelValues,(long)(256*sizeof(XColor)));
	TUTORzero((char FAR *)ExecAlloc,(long)(256*sizeof(char)));
	TUTORzero((char FAR *)ExecRO,(long)(256*sizeof(char)));
	
	visual = DefaultVisual(display,screen);
	if (visual->class == TrueColor) {
		colorsAvail = SysColors = 0x7fffffffL;
		MillionsColor = TRUE;
		SysPal = 0;
	} else {
		colorDepth = DisplayPlanes(display,screen);
		if (colorDepth <= 1)
			colorsAvail = 0; /* black+white */
		else if (colorDepth >= 8)
			colorsAvail = 256;
		else
			colorsAvail = 1 << colorDepth;
		SysColors = SysPal = colorsAvail;
	}
	X11defMap = DefaultColormap(display,screen);
	cTdefMap = X11defMap;
	
	/* check if can create our cells in default color map */
#ifdef Nosuchz	
	allocF = XAllocColorCells(display,cTdefMap,False,NULL,0,
			           pixelV,8);
	if (allocF) {
		for(pii=0; pii<8; pii++) { /* set up for colors allocated */
			ExecAlloc[pii] = TRUE; /* got a cell */
			ExecColors[pii].pixel = pixelV[pii]; /* set pixel value */
		} /* for */
	} else {
	
		/* create a new color map if can't get any slots */
		
		cTdefMap = XCreateColormap(display,RootWindow(display,screen),visual,AllocNone);
		if (!cTdefMap)
			cTdefMap = X11defMap; /* fall back to something */ 
	}
#endif
	CTinit_default_palette();
	CTinit_old_default_palette();
	CTcount_colors(FALSE);
	
} /* CTinit_color */

/* ******************************************************** */

CTcount_colors(oldF)
int oldF; /* TRUE if this if for $oldcolor */
	
{
	return(colorsAvail); 
}

/* ******************************************************** */

CTchange_palette(wn, newPal, sizeWanted, pSet, allNew)
int wn;        /* window we are changing palette for */
Memh newPal;    /* the new palette (if HNULL, use system palette) */
int sizeWanted;    /* size of cT palette */
int *pSet;    /* set to TRUE if we use the new palette */
int allNew;    /* TRUE if entire palette is changing */
/* returns the # of colors that are really drawable in cT palette */

{	int pii; /* index in palette */
	int resF; /* TRUE if this palette slot should be reserved */
	int allocF; /* TRUE if color slot successfully allocated */
	int redC,greenC,blueC; /* color components */
	XColor thisColor; /* X11 color we're working with */
	int nFound; /* number colors found */

	*pSet = FALSE; /* pre-set haven't done anything */
    if (wn < 0)
        return(0); /* no window, can'd do anything */
    if (newPal == HNULL)
        newPal = defaultPalette;

    /* attach cT palette to window */

    if (windowsP[wn].paletteH && (windowsP[wn].paletteH != newPal) &&
	    (windowsP[wn].paletteH != defaultPalette) &&
		(windowsP[wn].paletteH != oldDefaultPalette)) 
        TUTORfree_handle((Memh)windowsP[wn].paletteH);
    windowsP[wn].paletteH = newPal;
    windowsP[wn].paletteSize = sizeWanted;

    if (windowsP[wn].type != EXECW) {
		SetX11PixelValues(wn); /* set pixel values */
        return(sizeWanted); /* only execute window gets real palette */
	}

	if (!colorsSet) SetX11PixelValues(wn); /* initial setup */
	if (!colorsSet)
		return(sizeWanted); /* not ready yet */
	
	/* free up any read-only color cells we're attached to */
	
	for(pii=8; pii<256; pii++) {
		if (ExecRO[pii] && !ExecAlloc[pii]) {
			if ((ExecColors[pii].pixel != blackX.pixel) && 
			    (ExecColors[pii].pixel != whiteX.pixel))
				XFreeColors(display,cTdefMap,&ExecColors[pii].pixel,1,0L);
			ExecRO[pii] = FALSE;
		}
	} /* pii for */
	
	/* allocate or match colors */
	
	gDoMap = TRUE; /* may need fresh colormap */
	nFound = 0;
	for(pii=0; pii<sizeWanted; pii++) {
		resF = extract_palette_color(pii,&redC,&greenC,&blueC); /* get cT color */
		allocF = X11AllocColor(pii,&thisColor);
		if (allocF == 1) {
			ExecAlloc[pii] = TRUE; /* color cell allocated */
			nFound++;
		} else if (allocF == 2) {
			if (!resF) nFound++;
			ExecRO[pii] = TRUE; /* read-only color allocated */
		} 
		
		/* set execute color */
			
		TUTORblock_move((char FAR *)&thisColor,
			            (char FAR *)&ExecColors[pii],
			            (long)sizeof(XColor));
			
		/* set edit color */
		
		if (pii < 8) {			
			TUTORblock_move((char FAR *)&thisColor,
			            (char FAR *)&EditColors[pii],
			            (long)sizeof(XColor));
		}
	} /* pii for */

    /* set up X11 pixel values */

	XSetWindowColormap(display,(Window)windowsP[wn].wp,cTdefMap);
	SetX11PixelValues(wn);

    *pSet = TRUE;
	return(nFound); 

} /* CTchange_palette */

/* ******************************************************************* */

int SetX11PixelValues(wn) /* set pixel values for this window */
int wn; /* index of window to set for */

{	int pii; /* index in palette */
	XColor thisColor; /* next color to look up/set */
	int allocF; /* TRUE if allocated color cell for execute */
	int nCopy; /* number colors to copy */
	XColor *xcP; /* pointer to appropriate color table */
	
	if ((!colorsSet) && ((wn < 0) || (CurrentWindow < 0) || (!defaultPalette))) 
		return(0); /* can't set up yet */
	if (!colorsSet) { /* initial setup */
	
		/* initial setup - set initial colors for edit/exec */
		
		gDoMap = TRUE; /* need fresh color map */
		for(pii=0; pii<8; pii++) {
			allocF = X11AllocColor(pii,&thisColor);
			if (allocF == 1)
				ExecAlloc[pii] = TRUE; /* color cell allocated */
			else if (allocF == 2)		
				ExecRO[pii] = TRUE; /* read-only color allocated */
		
			/* set edit/execute colors */
			
			TUTORblock_move((char FAR *)&thisColor,
			                (char FAR *)&EditColors[pii],
			                (long)sizeof(XColor));
			TUTORblock_move((char FAR *)&thisColor,
			               (char FAR *)&ExecColors[pii],
			               (long)sizeof(XColor));
		} /* pii for */
		colorsSet = TRUE;
	} /* colorsSet if */
		
	if (windowsP[wn].type == EXECW) { /* execute window */
		nCopy = 256;
		xcP = ExecColors;
	} else {
		nCopy = 8;
		xcP = EditColors;
	}
	TUTORblock_move((char FAR *)xcP,
		            (char FAR *)pixelValues,
		            (long)(nCopy*sizeof(XColor)));
	
} /* SetX11PixelValues */

/* ******************************************************************* */

static int X11AllocColor(pii,retColor) /* allocate color */
/* return = 1 = color cell allocated */
/*          2 = color allocated thru XAllocColor() */
/*          3 = pixel value determined by search of default colormap */
int pii; /* index of color in cT palette */
XColor *retColor; /* X11 color value returned */

/* if gDoMap is TRUE, and a color must be looked up in the default */
/* color map, a new copy of the map will be read, and gDoMap will be */
/* reset to FALSE */

{	XColor thisColor; /* color we're working on */
	unsigned int redC,greenC,blueC; /* color components */
	int thisComponent; /* color component */
	int resF; /* TRUE if animated palette slot */
	int allocF; /* TRUE if allocated color cell */
	unsigned long pixelV; /* X11 pixel value */
	int cmii; /* index in color components */
	int pF,aF; /* parse, alloc returns */
	XColor FAR *bestColor; /* best color found */
	int retVal; /* return value */
	char cSpec[10];
	char asciiNyb[4];
	
	TUTORzero((char FAR *)&thisColor,(long)sizeof(XColor));
	resF = extract_palette_color(pii,&redC,&greenC,&blueC); /* get cT color */
	thisColor.red = redC << 8;
	if (thisColor.red == 0xff00) thisColor.red = 0xffff;
	thisColor.green = greenC << 8;
	if (thisColor.green == 0xff00) thisColor.green = 0xffff;
	thisColor.blue = blueC << 8;
	if (thisColor.blue == 0xff00) thisColor.blue = 0xffff;
	thisColor.flags = DoRed | DoGreen | DoBlue;			
	
	/* attempt to allocate color cell for exec, if needed */
			
	allocF = FALSE;
	if (ExecAlloc[pii]) { /* already have cell */
		pixelV = ExecColors[pii].pixel;
		allocF = TRUE;
	} else if (resF) {
		allocF = XAllocColorCells(display,cTdefMap,False,NULL,0,&pixelV,1);
	}
	if (allocF) { 
	
		/* have cell, simply set color */
		
		thisColor.pixel = pixelV;
		XStoreColor(display,cTdefMap,&thisColor);	
		gDoMap = TRUE; /* we've changed the color map */
		retVal = 1;
	} else { 
	
		/* attempt to look up nearest color via XAllocColor() */
				
		strcpy(cSpec,"#");
		for(cmii=0; cmii<3; cmii++) {
			if (cmii == 0) thisComponent = redC;
			else if (cmii == 1) thisComponent = greenC;
			else thisComponent = blueC;
			if (thisComponent < 16)
				sprintf(asciiNyb,"0%x",thisComponent);
			else
				sprintf(asciiNyb,"%x",thisComponent);
			strcat(cSpec,asciiNyb);
		} /* for */
		pF = XParseColor(display,cTdefMap,cSpec,&thisColor);
		aF = XAllocColor(display,cTdefMap,&thisColor);
		if (aF && pF) gDoMap = TRUE; /* we've changed the color map */
		retVal = 2;
		if ((!aF) || (!pF)) {
			
			/* attempt to look up color by searching default colormap */
			
			bestColor = lookBestColor(&thisColor,gDoMap);
			gDoMap = FALSE; /* assume won't need to look up map */
			thisColor.pixel = bestColor->pixel;
			retVal = 3;
		} /* af/pf if */
	} /* allocF else */
	
				
	TUTORblock_move((char FAR *)&thisColor,(char FAR *)retColor,
	                (long)sizeof(XColor));
	return(retVal); /* 1 = color cell, 2 = XAlloc, 3 = search */
	
} /* X11AllocColor */

/* ******************************************************************* */

XColor FAR *lookBestColor(thisColor,doMap) /* look up best match to color */
XColor FAR *thisColor; /* color to look up */
int doMap; /* TRUE if should read color map */

{	int pjj; /* index in colors */
	XColor FAR *searchP; /* pointer for color search */
	long bestSlot,bestDist,dist,curDist; /* for search */
	
	/* look up color by searching default colormap */
				
	if (!sysNColors) {
		sysNColors = DisplayCells(display,screen);
		if (sysNColors > 256) 
			sysNColors = 256;
		doMap = TRUE; /* get colormap */
	} /* !sysNColors if */
			
	if (doMap) {
			
		/* get X11 color cell values */
	
		for(pjj=0; pjj<sysNColors; pjj++)
			systemColors[pjj].pixel = pjj; /* set pixel values */
		XQueryColors(display,X11defMap,systemColors,sysNColors);
	}
			
	/* find closest match */
				
	searchP = systemColors;
	bestSlot = -1;
	bestDist = 0x7fffffffL;
	for(pjj=0; pjj<sysNColors; pjj++) {
 		curDist = (long)thisColor->red-(long)searchP->red;
 		if (curDist < 0) curDist = -curDist;
		dist = (long)thisColor->green-(long)searchP->green;
		if (dist < 0) dist = -dist;
		curDist += dist;
		dist = (long)thisColor->blue-(long)searchP->blue; 
		if (dist < 0) dist = -dist;
		curDist += dist;
		if (curDist < bestDist) {
			bestDist = curDist; /* best match so far */
			bestSlot = pjj;
			if ((curDist == 0) && (thisColor->red == searchP->red) &&
			    (thisColor->green == searchP->green) && (thisColor->blue == searchP->blue))
				break; /* perfect match */
		} /* if */
		searchP++;
	} /* for */
	if (bestSlot >= 0) 
		return(systemColors+bestSlot);
	else
		return(&blackX);
				
} /* lookBestColor */

/* ******************************************************************* */

unsigned long GetX11PixelValue(colorI)
int colorI; /* index of color */

{
	colorI = CTmap_default_color(colorI);
	if (colorI < 0) colorI = 0;
	if (colorI > 255) colorI = 255;
	return(pixelValues[colorI].pixel);
	
} /* GetX11PixelValue */

/* ******************************************************************* */

int extract_palette_color(cIndex,rC,gC,bC) /* get color from palette */ 
/* returns TRUE if palette slot reserved */
int cIndex; /* index of desired color in palette */
int *rC; /* red component */
int *gC; /* green component */
int *bC; /* blue component */

{   Memh paletteH; /* handle on cT palette */
    struct CTcolorentry FAR *paletteP; /* pointer to cT palette */
    int paletteSize;
    int reserveF;

    *rC = 255; /* pre-set for white */
    *gC = 255;
    *bC = 255;
    if ((CurrentWindow < 0) || (defaultPalette == HNULL))
        return(0); /* not initialized yet */

    /* get RGB color from cT palette */

    cIndex = CTmap_default_color(cIndex);
    paletteH = windowsP[CurrentWindow].paletteH;
    if (paletteH == HNULL)
        paletteH = defaultPalette;
    paletteSize = TUTORget_hsize(paletteH)/sizeof(struct CTcolorentry);
    if (cIndex < 0) 
        cIndex = 0;
    if (cIndex >= paletteSize) 
        cIndex = paletteSize-1;
    paletteP = cIndex+((struct CTcolorentry FAR *)GetPtr(paletteH));
    *rC = paletteP->red >> 8;
    *gC = paletteP->green >> 8;
    *bC = paletteP->blue >> 8;
    reserveF = paletteP->reserved;
    ReleasePtr(paletteH);

    return(reserveF); 

} /* extract_palette_color */

/* ******************************************************************* */

CTmap_default_color(cn) /* map default colors to actual indices */
register int cn;
	
{
	if (cn == color_defaultb)
		cn = color_white;
	else if (cn == color_defaultf)
		cn = color_black;
	if (cn < 0) cn = 0;
	return(cn);
	
} /* CTmap_default_color */

/* ******************************************************** */

CTset_foreground_color(cn)
int cn;
	
{	int icn;

    if (cn == color_rgb) { /* assume rgb set up */
	    TUTORset_color_rgb(0,0,fgndColor.red,fgndColor.green,fgndColor.blue);
		return(0);
    }

	if (cn == fgndColor.palette)
		return(0); 
	
	/* map color to good index */

	icn = cn;
	fgndColor.palette = cn = CTmap_color(CurrentWindow,cn,TRUE);
	/* set foreground color to cn: */
	TUTORset_comb_rule(CurrentMode); /* establish new color */
	
} /* CTset_foreground_color */

/* ******************************************************** */

CTset_background_color(cn)
int cn;
	
{

    if (cn == color_rgb) { /* assume rgb set up */
	    TUTORset_color_rgb(1,0,bgndColor.red,bgndColor.green,bgndColor.blue);
		return(0);
    }

 	if (cn == bgndColor.palette)
		return(0); 
	
	/* map color to good index */

	bgndColor.palette = cn = CTmap_color(CurrentWindow,cn,FALSE);
	
	/* set background color to cn: */
	TUTORset_comb_rule(CurrentMode); /* establish new color */
	
} /* CTset_background_color */

/* ******************************************************************* */

TUTORset_color_rgb(select,SysOrPal,red,green,blue)
int select; /* 0 = foreground, 1 = background, 2 = window */
int SysOrPal; /* 0 = use system palette, 1 = search cT palette */
double red; /* 0.0 - 100.0 red component */
double green; /* 0.0 - 100.0 green component */
double blue; /* 0.0 - 100.0 blue component */

{   Memh paletteH; /* handle on cT palette */
    struct CTcolorentry FAR *paletteP; /* pointer to palette */
    unsigned int redC,greenC,blueC;
    int bestSlot; /* best slot found so far */
    struct tutorColor *cP; /* pointer to color to set */
    
    /* convert floating colors to int */
    
    redC = (red/100.0)*(double)(0xffffL);
    greenC = (green/100.0)*(double)(0xffffL);
    blueC = (blue/100.0)*(double)(0xffffL);

    switch (select) {
    case 0: /* foreground */
        cP = &fgndColor; 
        break;
    case 1: /* background */
        cP = &bgndColor;
        break;
    case 2: /* window */
        cP = &winColor;
        break;
    default:
        cP = &fgndColor;
        break;
    } /* switch */

    cP->palette = color_rgb;
    cP->red = red;
    cP->green = green;
    cP->blue = blue;

    if (MillionsColor || ReadOnlyColor) {
		return(0);
    }

    /* handle palette-based display */

    paletteH = windowsP[CurrentWindow].paletteH;
    if (paletteH == HNULL) /* default palette */
	paletteH = defaultPalette;
    paletteP = (struct CTcolorentry FAR *) GetPtr(paletteH);
    bestSlot = PaletteMatch(paletteP,256,redC,greenC,blueC);
    ReleasePtr(paletteH);
        
    /* drive palette-based functions to set color */
        
    switch (select) {
        case 0:
            CTset_foreground_color(bestSlot);
            break;
        case 1:
            CTset_background_color(bestSlot);
            break;
        case 2:
     /*     CTset_window_color(bestSlot);  nothing to do */
            break;
    } /* switch */
    
    return(0);
        
} /* TUTORset_color_rgb */

/* ******************************************************** */

#ifdef NOSUCH
	
TUTORset_color_rgb(select,SysOrPal,red,green,blue)
int select; /* 0 = foreground, 1 = background, 2 = window */
int SysOrPal; /* 0 = use system palette, 1 = search cT palette */
double red; /* 0.0 - 100.0 red component */
double green; /* 0.0 - 100.0 green component */
double blue; /* 0.0 - 100.0 blue component */
	
{	unsigned long setcolor; /* color to set to */
	unsigned int redC,greenC,blueC;
	struct tutorColor *cP; /* pointer to color to set */
	XColor thisColor; /* color to match */
	XColor FAR *bestColor; /* best match found */
	unsigned long pixelV; /* pixel value */
	
	if (colorsAvail <= 2)
		return(0);
	
	/* convert floating colors to int */
	
	redC = (red/100.0)*(double)(0xffffL);
	greenC = (green/100.0)*(double)(0xffffL);
	blueC = (blue/100.0)*(double)(0xffffL);
	
	switch (select) {
	case 0: /* foreground */
		cP = &fgndColor; 
		break;
	case 1: /* background */
		cP = &bgndColor;
		break;
	case 2: /* window */
		cP = &winColor;
		break;
	default:
		cP = &fgndColor;
		break;
	} /* switch */
	
	TUTORzero((char FAR *)&thisColor,(long)sizeof(XColor));
	thisColor.red = redC;
	thisColor.green = greenC;
	thisColor.blue = blueC;
	
	/* handle TrueColor display */
	
	if (MillionsColor || (SysOrPal == 0)) {
		cP->palette = color_rgb;
		cP->red = red;
		cP->green = green; 
		cP->blue = blue;
		if (select == 0) fgndColor = *cP;
		bestColor = lookBestColor(&thisColor,gDoMap);
		cP->value = bestColor->pixel;
	} else {
	
		/* handle palette-based display */
			
		bestColor = lookBestColor(&thisColor,gDoMap);
		
		/* reset color values to correspond to actual match */
		
		red = 100.0*(double)(bestColor->red)/65535.0;
		green = 100.0*(double)(bestColor->green)/65535.0;
		blue = 100.0*(double)(bestColor->blue)/65535.0;
		pixelV = bestColor->pixel;
		
		/* set color directly */
		
		cP->palette = color_rgb;
		cP->red = red;
		cP->green = green;
		cP->blue = blue;
		cP->value = pixelV;
	} /* MillionsColor else */
	
	TUTORset_comb_rule(CurrentMode); /* establish new color */
	return(0);
	
} /* TUTORset_color_rgb */

#endif

/* ******************************************************** */

CTanimate_color(cn,red,green,blue)
int cn;
unsigned int red,green,blue;
	
{	int wn; /* window index */
	Memh paletteH; /* handle on current palette */
	int cIndex; /* index of color */
	XColor thisColor;
	struct CTcolorentry FAR *paletteP;
	int resF; /* TRUE if animated color cell */
	int allocF; /* TRUE if allocated color cell */
	unsigned long pixelV; /* pixel value */
	
    /* check window, index legal */

    wn = CurrentWindow;
    if (wn < 0) return(FALSE); /* can't do anything */
	if (windowsP[wn].type != EXECW)
		return(FALSE); /* executor window only */
    paletteH = windowsP[wn].paletteH;
    if (!paletteH)
        return(FALSE); /* can't do anything */
    cIndex = CTmap_default_color(cn);
    if ((cIndex < 0) || (cIndex >= windowsP[wn].paletteSize))
        return(FALSE);

    /* update cT palette */

    paletteP = cIndex+((struct CTcolorentry FAR *)GetPtr(paletteH));
    paletteP->red = red;
    paletteP->green = green;
    paletteP->blue = blue;
	resF = paletteP->reserved;
    ReleasePtr(paletteH); 

	/* check have color cell for this slot */
	
	if (resF && (!ExecAlloc[cIndex])) {
		if (ExecRO[cIndex])
			XFreeColors(display,cTdefMap,&ExecColors[cIndex].pixel,1,0);
		ExecRO[cIndex] = FALSE;
		allocF = XAllocColorCells(display,cTdefMap,False,NULL,0,
			         &pixelV,1);
		if (allocF) {
			ExecAlloc[cIndex] = TRUE;
			ExecColors[cIndex].pixel = pixelV;
		} /* allocF if */
	} /* ExecAlloc if */
	if (!ExecAlloc[cIndex])
		return(FALSE); /* no go */
		
	/* we have color cell for this slot, simply set color */

	thisColor.pixel = ExecColors[cIndex].pixel; /* get pixel value */
	thisColor.red = red;
	thisColor.green = green;
	thisColor.blue = blue;
	thisColor.flags = DoRed | DoGreen | DoBlue;
	XStoreColor(display,cTdefMap,&thisColor);
	TUTORblock_move((char FAR *)&thisColor,
	               (char FAR *)&ExecColors[cIndex],
	               (long)sizeof(XColor));	
	gDoMap = TRUE; /* we've changed color map */
	SetX11PixelValues(wn);
	return(TRUE);
	
} /* CTanimate_color */

/* ******************************************************************* */

CTinq_rgb_system(cn,red,green,blue)
int cn;
double *red, *green, *blue;
	
{
	return(FALSE); /* indicates that system doesn't know about colors */

} /* CTinq_rgb_system */

/* ******************************************************************* */

Memh TUTORget_default_rgb() /* return table of default RGB values */

{	int nColors; /* number default RGB values */
	long tableSize; /* size of cT palette */
	XColor FAR *colorP; /* pointer to X11 color values */
	XColor FAR *xcP; /* pointer in X11 color values */
	Memh rgbH; /* handle on (cT) RGB table values */
	double FAR *rgbBaseP; /* pointer to (cT) RGB table */
	double FAR *rgbP; /* pointer to (cT) RGB table values */
	int cii,cjj; /* index in colors */
	char preSet[256]; /* flags for our default palette */
	
	/* figure out number of default colors */
	
	nColors = DisplayCells(display,screen);
	if (nColors > 256) 
		nColors = 256;
		
	/* get current color cell values */
	
	tableSize = (long)(nColors*sizeof(XColor));
	colorP = systemColors;
	TUTORzero((char FAR *)colorP,tableSize);
	for(cii=0; cii<nColors; cii++)
		colorP[cii].pixel = cii; /* set pixel values */
	XQueryColors(display,X11defMap,colorP,nColors);
	
	/* allocate handle for cT palette to contain default RGB values */
	
	tableSize = (long)(nColors)*(long)(3*sizeof(double));
	rgbH = TUTORhandle("colors",tableSize,TRUE);
	if (!rgbH)
		return(HNULL);
	rgbBaseP = (double FAR *)GetPtr(rgbH);
	rgbP = rgbBaseP;
	TUTORzero((char FAR *)rgbP,tableSize);
	
	/* locate colors in our palette */
	
	TUTORzero((char FAR *)&preSet[0],(long)256*sizeof(char));
	for(cii=0; cii<windowsP[CurrentWindow].paletteSize; cii++) {
		xcP = colorP; /* pointer in X11 colors */
		for(cjj=0; cjj<nColors; cjj++) {
			if (!preSet[cjj] && (xcP->pixel == pixelValues[cii].pixel)) {
				preSet[cjj] = TRUE;
				*rgbP++ = 100.0*(double)(xcP->red)/65535.0;
				*rgbP++ = 100.0*(double)(xcP->green)/65535.0;
				*rgbP++ = 100.0*(double)(xcP->blue)/65535.0;
			} /* if */
			xcP++; /* advance pointer in X11 colors */
		} /* for */
	} /* for */
	
	/* set remaining X11 color values in table */
	
	for(cii=0; cii<nColors; cii++) {
		if (!preSet[cii]) {
			*rgbP++ = 100.0*(double)(colorP[cii].red)/65535.0;
			*rgbP++ = 100.0*(double)(colorP[cii].green)/65535.0;
			*rgbP++ = 100.0*(double)(colorP[cii].blue)/65535.0;
		}
	} /* for */	
	ReleasePtr(rgbH);
	
	return(rgbH); 
	
} /* TUTORget_default_rgb */

/* ********************************************************* */

static long wm_id = 0;

/* ********************************************************* */

long TUTORabs_save_region(x1, y1, x2, y2)
int x1, y1, x2, y2;

{	
	return(TUTORabs_save_image(x1,y1,x2,y2)); 
	
#ifdef NOSUCH
	XRectangle rectangle;
	Pixmap svregion;
	Memh rpH; /* handle on saved region info */
	struct saved_region FAR *rpP; /* pointer to saved region info */
	int swapv;
	int xws,yws; /* x/y window size */
	int offsetX, offsetY;	/* offsets from origin to image */
	long org_function; /* saved GC function */

	xws = windowsP[CurrentWindow].wxsize;
	yws = windowsP[CurrentWindow].wysize;

	/* normalize rectangle */

	if (x2 < x1) {
		swapv = x1;
		x1 = x2;
		x2 = swapv;
	}
	if (y2 < y1) {
		swapv = y1;
		y1 = y2;
		y2 = swapv;
	}
	
	offsetX = offsetY = 0;
	if (x1 < 0) {
		offsetX = -x1;
		x1 = 0;
	}
	if (y1 < 0) {
		offsetY = -y1;
		y1 = 0;
	}
	if (x1 >= xws || x1 > x2) return(0);
	if (y1 >= yws || y1 > y2) return(0);
	if (x2 >= xws)
		x2 = xws - 1;
	if (y2 >= yws)
		y2 = yws - 1;

	/* allocate handle for region info */

	rpH = TUTORhandle("region",(long)sizeof(struct saved_region),TRUE);
	rpP = (struct saved_region FAR *)GetPtr(rpH);
	TUTORzero((char FAR *)rpP,(long)sizeof(struct saved_region));
	TUTORpurge_info(rpH,M_WORM,FARNULL,0);
	AllowHandlePurge(rpH);

	/* set up region info */

	rpP->format = 0; /* native format */
	rpP->width = x2-x1+1;
	rpP->height = y2-y1+1;
	rpP->offsetX = offsetX;
	rpP->offsetY = offsetY;

	rectangle.x = 0;
	rectangle.y = 0;
	rectangle.width = xws;
	rectangle.height = yws + pd_barheight;
	XSetClipRectangles(display, gc, 0, 0, &rectangle, 1, YSorted);
	svregion = XCreatePixmap(display, drawwindow, (1 + x2 - x1), (1 + y2 - y1),
					 DisplayPlanes(display, screen));
					
	org_function = gcv.function;
	gcv.function = GXcopy;
	XChangeGC(display, gc, GCFunction, &gcv);
	XCopyArea(display, drawwindow, svregion, gc, x1, y1 + pd_barheight, 1 + x2 - x1, 1 + y2 - y1, 0, 0);
	gcv.function = org_function;
	XChangeGC(display, gc, GCFunction, &gcv);
	rpP->PixID = (long)svregion; /* save x11 id of region */
	rectangle.width = tgclipw;
	rectangle.height = tgcliph;
	XSetClipRectangles(display, gc, tgclipx, tgclipy + pd_barheight,
				   &rectangle, 1, YSorted);
	ReleasePtr(rpH); 
	return(rpH);
	
#endif

} /* TUTORabs_save_region */

/* ********************************************************* */

TUTORabs_restore_region(id, x1, y1)
long id; /* handle on saved region */
int x1, y1;

{	struct saved_region FAR *rpP; /* pointer to region info */
	XRectangle rectangle;
	int x2,y2;
	long res_id; /* x11/wm resource id */
	long org_function;
	int width,height; /* width, height of image */
	int rowExtra; /* extra bytes at end of row */
	int bytesRow; /* bytes per row in image */
	unsigned char FAR *pixelP; /* pointer to X11 image pixel data */
	unsigned char FAR *imP; /* pointer in intermediate pixel data */
	unsigned char FAR *pxP; /* pointer in X11 data */
	long dataSize; /* size of pixel data */
	XColor thisColor; /* color to look up */
	XColor *bestColor; /* best match found */
	struct CTcolorentry FAR *paletteP; /* pointer to cT palette */
	int pI; /* index in cT palette */
	int rowI; /* index in rows */
	int pixelI; /* index in pixels within rows */
	int depth; /* depth of display */
	Window win; /* current window */
	unsigned char pixLook[256]; /* TRUE if pixel already looked up */
	unsigned long pixV[256]; /* pixel values already available */

	if (id == 0) return; /* exit if no region to restore */
	rpP = (struct saved_region FAR *)GetPtr((Memh)id);

	if (rpP->format == 0) { 
	
		/* saved screen area */
		
		x1 += rpP->offsetX; /* adjust for image offset */
		y1 += rpP->offsetY;
		x2 = x1+rpP->width-1;
		y2 = y1+rpP->height-1;
		res_id = rpP->PixID;

		if (isx11) {
			if (x1 < 0 || y1 + pd_barheight < 0) {
				ReleasePtr((Memh)id);
				return;
			}
			if (x2 > windowsP[currentXwindow].wxsize)
				x2 = windowsP[currentXwindow].wxsize;
			if (y2 > windowsP[currentXwindow].wysize)
				y2 = windowsP[currentXwindow].wysize;
			org_function = gcv.function;
			gcv.function = GXcopy;
			XChangeGC(display, gc, GCFunction, &gcv);
			XCopyArea(display, (Pixmap) res_id, drawwindow, gc, 0, 0,
				  1 + x2 - x1, 1 + y2 - y1, x1, y1 + pd_barheight);
			gcv.function = org_function;
			XChangeGC(display, gc, GCFunction, &gcv);
		} else {
			;
#ifdef WM
			wm_SetFunction(f_copy);
			wm_RestoreRegion(res_id, x1, y1);
			TUTORset_comb_rule(CurrentMode);
#endif
		}
	} else if (rpP->format == 1) {
	
		/* color image */
		
		if (rpP->nativePal) { /* install image palette */
			CTuse_pix_palette(rpP->nativePal);
		}
		
		/* create XImage if not alreay created */
		
		width = rpP->width;
		height = rpP->height;
		win = (Window)windowsP[CurrentWindow].wp;
		if ((!rpP->wExec) && (windowsP[CurrentWindow].type == EXECW)) {
			/* destroy and recreate image if not set up for execute window */
			if (rpP->imageP)
				XDestroyImage((XImage *)rpP->imageP);
			rpP->imageP = FARNULL;
		}
		if (!rpP->imageP) { /* no image yet */
		
			/* set type of window image set up for */
			
			rpP->wExec = (windowsP[CurrentWindow].type == EXECW);
		
			/* set up, allocate memory for image */
			
			rowExtra = ((4-(width % 4)) & 3); /* adjust for padding */
			bytesRow = width+rowExtra;
			dataSize = (long)bytesRow*(long)height;
			pixelP = (unsigned char FAR *)TUTORalloc(dataSize,TRUE,"pix");
			if ((!pixelP) || (!rpP->palDataH) || (!rpP->nativePal)) { /* something wrong */
				ReleasePtr((Memh)id);
				return;
			}
			TUTORzero(pixelP,dataSize);
			
			/* convert pixel values */
			
			imP = (unsigned char FAR *)GetPtr(rpP->palDataH); /* ptr to intermediate data */
			paletteP = (struct CTcolorentry FAR *)GetPtr(rpP->nativePal);
			TUTORzero((char FAR *)&thisColor,(long)sizeof(XColor));
			TUTORzero(pixLook,(long)(256*sizeof(char)));
			lookBestColor(&thisColor,TRUE); /* get colormap */
			for(rowI=0; rowI<height; rowI++) {
				pxP = pixelP+rowI*bytesRow; /* point to start of row */
				for(pixelI=0; pixelI<width; pixelI++) {
					pI = (*imP++) & 0xff; /* get next cT palette index */
					if (pixLook[pI]) {
						*pxP++ = pixV[pI];
					} else {
						thisColor.red = paletteP[pI].red;
						thisColor.green = paletteP[pI].green;
						thisColor.blue = paletteP[pI].blue;
						bestColor = lookBestColor(&thisColor,FALSE);
						pixLook[pI] = TRUE;
						pixV[pI] = bestColor->pixel;
						*pxP++ = bestColor->pixel;
					}
				} /* pixelI for */
			} /* rowI for */
			ReleasePtr(rpP->palDataH);
			ReleasePtr(rpP->nativePal);
			
			depth = DisplayPlanes(display,screen);
			rpP->imageP = (char FAR *)XCreateImage(display,visual,depth,
			                    ZPixmap,0,pixelP,width,height,32,bytesRow);

dmp_image(rpP->imageP );
		} /* imageP if */
		
		/* display the image */
		
		if (rpP->imageP) {
			XPutImage(display,win,gc,rpP->imageP,0,0,x1,y1+pd_barheight,width,height);
		}
	}
	ReleasePtr((Memh)id);

} /* TUTORabs_restore_region */

/* ******************************************************************* */

TUTORfree_region(id) /* free saved screen region */
long id; /* handle on region */

{   Memh rhdrH; /* handle on region header */
    struct saved_region FAR *rhdrP; /* pointer to header */
    Memh pieceH; /* handle on region piece */
    long res_id; /* x11/wm resource id */

    if (!id) return; /* exit if nothing to free */
    rhdrH = (Memh)id;
    rhdrP = (struct saved_region FAR *)GetPtr(rhdrH);
	if (rhdrP->format == 0) { /* saved screen */
    		res_id = rhdrP->PixID;
    		if (isx11) {
		/*	if (res_id) */
        			XFreePixmap(display, (Pixmap)res_id);
		}   else { ;
#ifdef WM
        		wm_ForgetRegion(res_id);
#endif
		}
	} else if (rhdrP->format == 1) { /* color image */
		if (rhdrP->imageP) /* release X11 image */
			XDestroyImage((XImage *)rhdrP->imageP);
		rhdrP->imageP = FARNULL;
		if (rhdrP->nativePal) /* release palette memory */
			TUTORfree_palette(rhdrP->nativePal);
		if (rhdrP->palDataH) /* release pixel data */
			TUTORfree_handle(rhdrP->palDataH);
		if (rhdrP->rgbDataH)
			TUTORfree_handle(rhdrP->rgbDataH);
	}
    ReleasePtr(rhdrH);
    TUTORfree_handle((long)rhdrH);

} /* TUTORfree_region */

/* ********************************************************* */

static long TUTORabs_save_image(x1, y1, x2, y2)
int x1, y1, x2, y2;

{	Memh rpH; /* handle on saved region info */
	struct saved_region FAR *rpP; /* pointer to saved region info */
	int swapv;
	int xws,yws; /* x/y window size */
	int width,height; /* width,height of image */
	Window win; /* current window */
	XImage *ximP; /* pointer to XImage structure */
	Memh pixBuffH; /* handle on pixel data */
	unsigned char FAR *pixBuffP; /* pointer to pixel data */
	unsigned char FAR *inP; /* input pointer in pixels */
	unsigned char FAR *outP; /* output pointer in pixels */
	Memh paletteH; /* handle on palette */
	struct CTcolorentry FAR *paletteP; /* pointer to palette */
	struct CTcolorentry FAR *palP; /* pointer in palette */
	int cii; /* index in colors */
	XColor thisColor;
	long rowExtra; /* extra bytes at end of X11 row */
	long bytesRow; /* bytes/row in X11 image */
	int rowI,colI; /* index in pixels */
	long tmpSize;
	int havePalData; /* TRUE if have data in palettized form */

	if (!isx11)
		return(0L); /* only under x11 */
/*	if (windowsP[CurrentWindow].type != EXECW)
		return(0L); */ /* only for exec window */
		
	havePalData = FALSE;
	xws = windowsP[CurrentWindow].wxsize;
	yws = windowsP[CurrentWindow].wysize;

	/* normalize rectangle */

	if (x2 < x1) {
		swapv = x1;
		x1 = x2;
		x2 = swapv;
	}
	if (y2 < y1) {
		swapv = y1;
		y1 = y2;
		y2 = swapv;
	}
	
	if (x1 >= xws || x1 > x2) return(0);
	if (y1 >= yws || y1 > y2) return(0);
	if (x2 >= xws)
		x2 = xws - 1;
	if (y2 >= yws)
		y2 = yws - 1;
	width = x2-x1+1;
	height = y2-y1+1;

	/* get current system colormap */
	
	TUTORzero((char FAR *)&thisColor,(long)sizeof(XColor));
	lookBestColor(&thisColor,TRUE);
	
	/* get XImage */
	
	win = (Window)windowsP[CurrentWindow].wp;
	ximP = XGetImage(display,win,x1,y1+pd_barheight,width,height,AllPlanes,ZPixmap);
	if (!ximP)
		return(0L); /* can't do it */
dmp_image(ximP);
	if (ximP->bits_per_pixel == 8)
		havePalData = TRUE; /* have data in palettized form */
		
    /* set up storage for pixels */
    
	tmpSize = width*height;
	pixBuffH = TUTORhandle("pixmap",tmpSize,TRUE);
    if (!pixBuffH) {
		XDestroyImage(ximP);
        return(0L); /* couldn't get enough memory */
	}
    TUTORpurge_info(pixBuffH,M_WORM,FARNULL,0);
    AllowHandlePurge(pixBuffH);
    	
	/* transfer pixel data */

	pixBuffP = (unsigned char FAR *)GetPtr(pixBuffH);
	TUTORzero((char FAR *)pixBuffP,tmpSize);
	outP = pixBuffP;
	bytesRow = ximP->bytes_per_line;
	rowExtra = bytesRow-width; /* amount of padding */
	for(rowI=0; rowI<height; rowI++) {
		inP = (unsigned char FAR *)ximP->data+rowI*bytesRow; /* point to start of row */
		for(colI=0; colI<width; colI++) {
			*outP++ = *inP++;
		} /* colI for */
	} /* rowI for */
	ReleasePtr(pixBuffH);

	/* create new palette */
    
    tmpSize = 256*sizeof(struct CTcolorentry);
    paletteH = TUTORhandle("palette",tmpSize,TRUE);
    if (!paletteH) {
		XDestroyImage(ximP);
		TUTORfree_handle(pixBuffH);
        return(0L);
	}
    paletteP = palP = (struct CTcolorentry FAR *)GetPtr(paletteH);
    TUTORzero((char SHUGE *) paletteP,tmpSize);
	for(cii=0; cii<256; cii++) {
		palP->red = systemColors[cii].red;
		palP->green = systemColors[cii].green;
		palP->blue = systemColors[cii].blue;
		palP++;
	}
	ReleasePtr(paletteH);
	
	/* allocate handle for region info */

	rpH = TUTORhandle("region",(long)sizeof(struct saved_region),TRUE);
	if (!rpH) {
		XDestroyImage(ximP);
		TUTORfree_handle(pixBuffH);
		TUTORfree_handle(paletteH);
		return(0L);
	}
	rpP = (struct saved_region FAR *)GetPtr(rpH);
	TUTORzero((char FAR *)rpP,(long)sizeof(struct saved_region));
	TUTORpurge_info(rpH,M_WORM,FARNULL,0);
	AllowHandlePurge(rpH);

	/* set up region info */

	rpP->format = 1; /* XImage format */
	rpP->wExec = windowsP[CurrentWindow].type == EXECW; 
	rpP->width = x2-x1+1;
	rpP->height = y2-y1+1;
	rpP->imageP = (char FAR *)ximP;
	rpP->nativePal = paletteH;
	if (havePalData) {
		rpP->palDataH = pixBuffH;
	} else {
		TUTORfree_handle(pixBuffH);
	}
	ReleasePtr(rpH); 
	
	x11_get_pal_region(rpH); /* force data into palettized form */
	
	return(rpH);

} /* TUTORabs_save_image */

/* ******************************************************************* */

long TUTORmem_to_region(type,width,height,ipalH,bP) /* build image from data */
int type; /* = 1 = 8-bit palettized, 2 = 3-byte r,g,b, 3 = native r,g,b */
int width; /* width of image */
int height; /* height of image */
Memh ipalH; /* pre-built palette, or HNULL */
unsigned char FAR *bP; /* pointer to raw r,g,b data */

{	Memh headerH; /* handle on region header */
    struct saved_region FAR *headerP; /* pointer to region header */
	Memh paletteH; /* handle on cT palette */
	struct CTcolorentry FAR *paletteP; /* pointer to cT palette */
	struct CTcolorentry FAR *rgbP; /* pointer in cT palette */
	int nColors; /* size of palette */
	int cii; /* index in colors */
	Memh pixBuffH; /* handle on pixel data */
	unsigned char FAR *pixBuffP; /* pointer to pixel data */
	unsigned char FAR *pixelsP; /* pointer in pixel data */
	long tmpSize; 
	
    /* set up storage for pixels */
    
	tmpSize = 3L*(long)width*(long)height;
	pixBuffH = TUTORhandle("pixmap",tmpSize,TRUE);
    if (!pixBuffH) {
        return(0L); /* couldn't get enough memory */
    }
    TUTORpurge_info(pixBuffH,M_WORM,FARNULL,0);
    AllowHandlePurge(pixBuffH);
    
    /* set up cT handle for header */
    
    headerH = TUTORhandle("region",(long)sizeof(struct saved_region),TRUE);
    if (!headerH) {
        TUTORfree_handle(pixBuffH);
        return(0L); /* couldn't get enough memory */
    }
    headerP = (struct saved_region FAR *)GetPtr(headerH);
    TUTORzero((char FAR *)headerP,(long)sizeof(struct saved_region));
	headerP->format = 1; /* XImage */
	headerP->width = width;
	headerP->height = height;
	headerP->palDataH = pixBuffH; /* handle on intermediate data */

	if (type == 1) {
		paletteH = TUTORcopy_handle(windowsP[CurrentWindow].paletteH);
	} else {
	
   		/* build cT palette from raw r,g,b pixels */

		if (windowsP[CurrentWindow].paletteH)
		    paletteH = TUTORcopy_handle(windowsP[CurrentWindow].paletteH);
		else
		    paletteH = TUTORcopy_handle(defaultPalette);
 /*  		paletteH = TUTORmake_pix_palette(1,bP,width,height); */
	}
	headerP->nativePal = paletteH;
	ReleasePtr(headerH); /* done with header */
	if (!paletteH) { /* not enough memory */
		TUTORfree_handle(pixBuffH);
		TUTORfree_handle(headerH);
		return(0L);
	}

	/* convert R,G,B pixels to indexes in cT palette */
	
	pixBuffP = (unsigned char FAR *)GetPtr(pixBuffH);
    	pixelsP = pixBuffP;
	if (type == 1) {
		TUTORblock_move(bP,pixelsP,(long)height*(long)width);
	} else {
		cii = TUTORpalettize_rgb((type-1),bP,width*3L,pixelsP,(long)(width),paletteH,width,height); /* convert rgb->palette */
		if (!cii) {
			ReleasePtr(pixBuffH);
			TUTORfree_handle(pixBuffH);
			TUTORfree_handle(paletteH);
			TUTORfree_handle(headerH);
			return(0L);
		} /* !cii if */
	} /* type else */
	ReleasePtr(pixBuffH);
	
	return(headerH);
	
} /* TUTORmem_to_region */

/* ******************************************************************* */

long TUTORcopy_region(regionID) /* make another copy of an image */
long regionID; /* handle on region header */

{	struct saved_region FAR *regionP; /* pointer to region header */
	Memh newH; /* handle on new region header */
	struct saved_region FAR *newP; /* pointer to new region header */
	
	if (!regionID) return(0L); /* nothing to copy */
	newH = TUTORcopy_handle((Memh)regionID);
	if (!newH) return(0L);
	newP = (struct saved_region FAR *)GetPtr(newH);
	newP->imageP = FARNULL; /* will re-create image */    
	newP->wExec = FALSE;
	regionP = (struct saved_region FAR *)GetPtr((Memh)regionID);
	if (regionP->format != 1) { /* don't know how to copy */
		ReleasePtr((Memh)regionID);
		ReleasePtr(newH);
		TUTORfree_handle(newH);
		return(0L);
	}
	newP->nativePal = TUTORcopy_handle(regionP->nativePal); /* copy palette */
	newP->palDataH = TUTORcopy_handle(regionP->palDataH); /* copy pixels */
	TUTORpurge_info(newH,M_WORM,FARNULL,0);
    AllowHandlePurge(newH);
	if (newP->nativePal) {
		TUTORpurge_info(newP->nativePal,M_WORM,FARNULL,0);
		AllowHandlePurge(newP->nativePal);
	}
	if (newP->palDataH) {
		TUTORpurge_info(newP->palDataH,M_WORM,FARNULL,0);
		AllowHandlePurge(newP->palDataH);
	}
	ReleasePtr((Memh)regionID);
	ReleasePtr(newH);
	return(newH);
	
} /* TUTORcopy_region */

/* ******************************************************************* */

long TUTORload_region(fRef) /* load image from file */
FileRef FAR *fRef;

{
	return(TUTORload_region_ppm(fRef)); /* always ppm on unix */
	
} /* TUTORload_region */

/* ******************************************************************* */

int x11_get_pal_region(regionID) /* get region in palettized format */
long regionID;

{	Memh headerH; /* handle on region header */
	struct saved_region FAR *headerP; /* pointer to region header */
	Memh buffH; /* handle on palettized data */
	XImage *imageP; /* pointer to X11 image */
	int width,height; /* width, height of image */
	int rowI,colI; /* index in pixels */
	int bitI; /* index in pixel bits */
	int pixelV; /* current pixel */
	int bytesRow; /* bytes per pixel row */
	int rowExtra; /* extra bytes at end of row */
	int bytesToDo; /* bytes to process in row */
	int bitsToDo; /* bits to process in byte */
	Memh pixBuffH; /* handle on palettized pixel data */
	unsigned char FAR *pixBuffP; /* pointer in pixel data */
	long pixSize; /* size of pixel data buffer */
	unsigned char FAR *inP; /* pointer in input pixels */
	unsigned char FAR *outP; /* pointer in output pixels */
	
	headerH = regionID;
	headerP = (struct saved_region FAR *)GetPtr(headerH);
	buffH = headerP->palDataH; /* handle on palettized data, if any */
	width = headerP->width;
	height = headerP->height;
	imageP = (XImage *)headerP->imageP;
	ReleasePtr(headerH);
	if (buffH)
		return(buffH); /* all done */
	
	/* set up storage for pixels */
   
	pixSize = width*height;
	pixBuffH = buffH = TUTORhandle("pixmap",pixSize,TRUE);
    if (!pixBuffH) 
        return(0L); /* couldn't get enough memory */
    TUTORpurge_info(pixBuffH,M_WORM,FARNULL,0);
    AllowHandlePurge(pixBuffH);
    	
	/* transfer pixel data */

	pixBuffP = (unsigned char FAR *)GetPtr(pixBuffH);
	TUTORzero((char FAR *)pixBuffP,pixSize);
	outP = pixBuffP;
	bytesRow = imageP->bytes_per_line;
	if (imageP->bits_per_pixel == 1) {
		bytesToDo = (width+7) >> 3;
		rowExtra = bytesRow-bytesToDo; /* amount of padding */
		for(rowI=0; rowI<height; rowI++) {
			inP = (unsigned char FAR *)imageP->data+(long)rowI*(long)bytesRow; 
			for(colI=0; colI<bytesToDo; colI++) {
				pixelV = *inP++; /* get next pixels byte */
				if (colI == (bytesToDo-1)) {
					bitsToDo = width & 7;
					if (bitsToDo == 0) bitsToDo = 8;
				} else bitsToDo = 8;
				for(bitI=0; bitI<bitsToDo; bitI++) {
					if (pixelV & (0x80 >> bitI)) *outP++ = color_black;
					else *outP++ = color_white;
				} /* bitI for */
			} /* colI for */
		} /* rowI for */
	} else if (imageP->bits_per_pixel == 8) {
		rowExtra = bytesRow-width; /* amount of padding */
		for(rowI=0; rowI<height; rowI++) {
			inP = (unsigned char FAR *)imageP->data+(long)rowI*(long)bytesRow; 
			for(colI=0; colI<width; colI++) {
				*outP++ = *inP++;
			} /* colI for */
		} /* rowI for */
	} /* bits_per_pixel else-if */
	ReleasePtr(pixBuffH);
		
	headerP = (struct saved_region FAR *)GetPtr(headerH);
	headerP->palDataH = pixBuffH;
	ReleasePtr(headerH);
	return(buffH);
	
} /* x11_get_pal_region */

/* ******************************************************************* */

dmp_image(imageP)
XImage *imageP;

{
return;
	printf("width %d height %d \n",imageP->width,imageP->height);
	if (imageP->format == XYBitmap) printf("XYBitmap\n");
	else if (imageP->format == XYPixmap) printf("XYPixmap\n");
	else printf("ZPixmap\n");
	if (imageP->byte_order == MSBFirst) printf("byte_order MSBFirst\n");
	else printf("byte_order LSBFirst\n");
	if (imageP->bitmap_bit_order == MSBFirst) printf("bit_order MSBFirst\n");
	else printf("bit_order LSBFirst\n");
	printf("depth %d bits_per_pixel %d bitmap_unit %d\n",imageP->depth,
	        imageP->bits_per_pixel,imageP->bitmap_unit);
	printf("bytes_per_line %d bitmap_pad %d\n",imageP->bytes_per_line,
	        imageP->bitmap_pad); 
} /* dmp_image */

/* ******************************************************************* */

int TUTORfile_region(fRef,regionID) /* save region to file */
FileRef FAR *fRef; /* pointer to file description */
long regionID; /* handle on saved region */

{ 
	return(TUTORfile_region_ppm(fRef,regionID));
	
} /* TUTORfile_region */

/* ******************************************************************* */

#ifdef NOSUCH

int TUTORload_palette(fRef)
FileRef FAR *fRef; /* palette file */

{   int fileid; /* index of file */
    long fileSize; /* total size of file */
    long readSize; /* amount of file to read */
    long readL; /* amount read */
    Memh palH; /* handle on new palette */
    struct CTcolorentry FAR *palP; /* pointer in new palette */
    char FAR *tmpP; /* buffer for palette file contents */
    int retV; /* return value */
    int nColors; /* number colors in palette */
    int pii,pjj; /* indexes in palette */
    unsigned int rr,gg,bb; /* color components */
    LOGPALETTE *logP; /* pointer to logical palette */
    PALETTEENTRY *wPalP; /* pointer to logical palette entry */
    HPALETTE hPalette;

    palH = HNULL;
    tmpP = FARNULL;
    palP = FARNULL;
    nColors = 0;
    if (!thePaletteH)
		return(-FILENOTSUP);

    /* open file, get length */
	
    fileid = TUTORopen((FileRef FAR *)fRef,TRUE,FALSE,FALSE);
    if (fileid <= 0)
        return(-FILEMISSING);
    TUTORinq_file_info(fRef,NEARNULL,&fileSize,NEARNULL,NEARNULL,NEARNULL);
    
    /* allocate memory and read file */
    
    readSize = ((fileSize > 4096L) ? 4096L: fileSize);
    tmpP = TUTORalloc(readSize,FALSE,"tp");
    if (!tmpP) {
		retV = -FILEMEM;
		goto eexit;
    }
    readL = TUTORread(tmpP,1,readSize,fileid);
    if (readL != readSize) {
		retV = -FILERANGE;
		goto eexit;
    }
    TUTORclose(fileid);
    fileid = 0;

    /* allocate new palette */
	
    palH = initial_palette(); /* copy original system palette */
    if (!palH) {
		retV = -FILEMEM;
		goto eexit;
    }
    palP = (struct CTcolorentry FAR *)GetPtr(palH);

    /* determine file type */
	
    if (strncmpf((char FAR *)"RIFF",tmpP,4) == 0) {
	
		/* handle RIFF format file */
		
		if (strncmpf((char FAR *)"PAL data",tmpP+8,8) != 0) {
	    	retV = -FILEIMPROPERTYPE;
	    	goto eexit;
		}
		logP = (LOGPALETTE FAR *)(tmpP+0x14); /* skip RIFF header */
		wPalP = &logP->palPalEntry[0];
		if (logP->palNumEntries > 256) {
	    	retV = -FILEIMPROPERTYPE;
	    		goto eexit;
		}

		nColors = logP->palNumEntries;
		if (nColors > 256)
	    		nColors = 256;
		for(pii=0; pii<nColors; pii++) {
	    	rr = ((wPalP+pii)->peRed) << 8;
	    	gg = ((wPalP+pii)->peGreen) << 8;
	    	bb = ((wPalP+pii)->peBlue) << 8;
	    	if (rr == 0xff00) rr = 0xffff;
	    	if (gg == 0xff00) gg = 0xffff;
	    	if (bb == 0xff00) bb = 0xffff;
	    	CTset_color_entry(palP+pii,rr,gg,bb,0,0,FALSE);
	    		(palP+pii)->realV = pii;
    } else {
		retV = -FILEIMPROPERTYPE;
		goto eexit;
    }
    TUTORdealloc(tmpP); /* release temp memory */

    /* reorder cT palette to try to fix up zred, etc */

    cTOrderPalette(palP);
    ReleasePtr(palH);
    palP = FARNULL;

    /* install the palette */

    immediatePalette(palH);

    return(nColors);
	
eexit: /* error exit */
    if (palP)
	ReleasePtr(palH);
    if (palH)
	TUTORfree_palette(palH);
    if (tmpP)
	TUTORdealloc(tmpP);
    if (fileid)
	TUTORclose(fileid);
    return(retV);
		
} /* TUTORload_palette */

#endif

/* ******************************************************************* */

