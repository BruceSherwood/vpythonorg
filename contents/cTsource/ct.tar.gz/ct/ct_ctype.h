/*
A component of the cT (TM) programming environment.
(c) Copyright 1990 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

#ifndef _ct_ctypeh_
#define _ct_ctypeh_

extern char _ct_ctype[]; /* in ctypewm, or in stdio (mac) */

#define _alpha_ 1
#define _digit_ 2
#define _punct_ 4
#define _space_	8

#define	CTisalnum(c) (_ct_ctype[c] & (_alpha_|_digit_))
#define	CTisalpha(c) (_ct_ctype[c] & _alpha_)
#define CTisdigit(c) (_ct_ctype[c] & _digit_)
#define	CTisspace(c) (_ct_ctype[c] & _space_)
#define CTispunct(c) (_ct_ctype[c] & _punct_)

#endif
