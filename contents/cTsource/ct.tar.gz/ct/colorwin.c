
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989,1992 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/

/* ******************************************************************* */

#define STRICT
#include <windows.h>
#include <string.h>
#include <direct.h>  
#include <stdlib.h>

#include "baseenv.h"
#include "ctmsw.h"
#include "tglobals.h"
#include "kglobals.h"
#include "txt.h"
#include "kdefs.h"
#include "ct_ctype.h"
#include "compute.h"
#include "eglobals.h"
#include "ecglobal.h"
#include "chardef.h"
 
/* ******************************************************************* */
       
extern HDC cTGetDC(HWND ww);
extern void cTReleaseDC(HWND ww,HDC dc);
extern int RealizeCTPalette(Memh newH,int allNew);
extern int TUTORblock_move(char SHUGE *ff,char SHUGE *tt,long len);
static int LookupPaletteSlot(struct CTcolorentry FAR *theColor);
int  TUTORrgb_to_hsv(double  red,double  green,double  blue,double  *hue,double  *saturation,double  *value);
extern Memh initial_palette(void);
extern int  CTset_color_entry(struct  CTcolorentry FAR *cep,unsigned int  rr,unsigned int  gg,unsigned int  bb,int  ff,int  bf,int  res);
extern int TUTORset_color_rgb(int sel,int pp,double rr,double gg,double bb);
extern int CTmap_color(int ww,int cc,int ff);
extern int set_win_color(int type,int index);
extern int pen_fix(void);
extern int AllowHandlePurge(Memh hh);
extern int win_adapt_region(long id);
extern int TUTORfree_handle(Memh mm);
extern int strlenf(char FAR *str);             
extern int TUTORfile_region_ppm(FileRef FAR *fRef,long regionID);
int map_default_color(int cIndex);  
extern int extract_palette_color(int indx,int *rr,int *gg,int *bb);
extern double floor(double xx); 
int  TUTORhsv_to_rgb(double  hue,double  saturation,double  value,double  *red,double  *green,double  *blue);
extern Memh build_8bit_dib(int width,int height,Memh palH);
extern int extract_pal_data(long regionID);
extern int PaletteMatch(struct CTcolorentry FAR *paletteP,int nColors,
           unsigned int redC,unsigned int greenC,unsigned int blueC);
static int CountDIBColors(Memh dibH);
extern int cTOrderPalette(struct CTcolorentry FAR *cTPaletteP);
extern int extract_palette_from_dib(unsigned char FAR *dibP,struct CTcolorentry FAR *palP);
static int add_to_pal(struct CTcolorentry FAR *pp,int rr,int gg,int bb);
extern int strncmpf(char FAR *aa,char FAR *bb,int nn);
long  TUTORread(char  FAR *ptr,int  pSize,long  count,int  findx);
int  TUTORclose(int  findx);
int  TUTORopen(struct  _fref FAR *fRef,int  rf,int  wf,int  af);
char  FAR *TUTORalloc(long  size,int  abort,char  *label);
int  TUTORdealloc(char  FAR *ptr);
extern  int TUTORinq_file_info(FileRef FAR *fname,int *waccess,long *length,long *modtim,int *posx,int *posy);
int  TUTORstat(struct  _fref FAR *fRef,struct  stat *buff);
extern int TUTORload_palette(FileRef FAR *fRef);
extern int win_palettize_region(long id);
extern int TUTORpalettize_rgb(int type,unsigned char SHUGE *pixelsP,
	   long inRow,unsigned char SHUGE *outPixP,long outRow,Memh paletteH,
	   int width,int height);
extern Memh TUTORget_rgb_region(long regionID);
extern HPALETTE cvtLogPal(Memh paletteH);
extern int TUTORfree_palette(Memh palH);
extern Memh TUTORalloc_palette(int pSlots);
int  CTinq_rgb_system(int  cn,double  *red,double  *green,double  *blue);
extern void TUTORset_color(int select,int sp,struct tutorColor FAR *newColor);
extern Memh win_convert_region(long regionID);
int invert_dib(unsigned char SHUGE *pixelsP,int width,int height);
static HANDLE FAR BitmapToDIB(HBITMAP hBitmap,HPALETTE hPal);
HPALETTE ConvertcTPalette(Memh paletteH,int paletteSize);
extern HGLOBAL get_sys_palette(void);
extern WORD FAR DIBNumColors(LPSTR lpDIB);
extern WORD FAR PaletteBytes(LPSTR lpDIB);
extern int TUTORfile_region(FileRef FAR *fRef,long regionID);
extern long TUTORmem_to_region(int type,int width,int height,Memh palH,unsigned char SHUGE *bP);
extern long TUTORmem_to_region_rgb(int type,int width,int height,Memh palH,unsigned char SHUGE *bP);
extern long TUTORmem_to_region_pal(int type,int width,int height,Memh palH,unsigned char SHUGE *bP);
extern int TUTORinq_sys_color(int ci,double *rr,double *gg,double *bb);
extern Memh TUTORcopy_handle(Memh src);
extern long TUTORcopy_region(long region);
extern int TUTORinq_icon_size(int fontid,int iconN,int *dx,int *dasc,int *ddes);
extern int TUTORzero(char FAR *ptr,long len);
extern int interact(int block);
extern HBRUSH fpc_brush(int pattF,int pattC,int invertF);
extern  long TUTORget_hsize(Memh mm);
extern int strncmpf(char FAR *aa,char FAR *bb,int nn);
extern int strcmpf(char FAR *aa,char FAR *bb);
extern char SHUGE *fpc_char(struct pcfont FAR *fpcP,long charI,
              struct pccharl *charDef);
extern int fpc_draw_char(Memh ftH,struct pcfont FAR *ftP,int cc);
extern int fpc_add_bitmap_cache(Memh ftH,int charI,int type,HBITMAP mapH,struct pccharl *pDef);
extern int fpc_find_bitmap_cache(Memh fontH,int cc,int type);
extern HDC fpc_mem_dc(int type);
extern char  FAR *strcpyf(char  FAR *aa,char  FAR *bb);
extern char  FAR *strcatf(char  FAR *aa,char  FAR *bb);
extern int TUTORchecksum(char FAR *addr,long length);
extern int TutorDeleteCard(Memh barh,int cardI);
extern int MenuNames(unsigned int mbar,int item,char *cardName,char *itemName);
extern int cTRegisterWindow(HWND hWnd,int cTtype,int cTindex,int cmdN,Memh infH);
extern int TUTORset_hsize(unsigned int  mm,long newsize,int abort);
extern unsigned int TUTORhandle(char *name,long size,int purgewmrm);
extern int TUTORdone_startup(void);
extern int TUTORstart_menubar(unsigned int  barh);
extern int TUTORforward_window(int wix);
extern long TUTORadd_ffamily(struct  _fref *famName,int  isSys,int  isSwitch);
extern int TUTORparse_font_family(struct  _fref *fontTag,struct  _fref *familyName,int  isFont,int  oneTag,int  *fontSize);
extern int TUTORinq_abs_string_width(unsigned char  FAR *s,int  lth,int  *dx);
extern int TUTORtrace(char *str);
extern int TUTORset_abs_clip_rectangle(int x1,int y1,int x2,int y2);
extern int TUTORdraw_abs_solid_rect(TRect FAR *tr,int color);
extern int TUTORinq_abs_screen_size(int *x,int *y,int *dx,int *dy);
extern int TUTORinq_abs_pen_pos(int *x,int *y);
extern int TUTORabs_line_to(int xx,int yy);
extern int TUTORdump(char *s);
extern int  TUTORpost_event(struct  tutorevent *event);
extern int TUTORpoll_events(int block);
extern int TUTORdealloc(char  FAR *ptr);
extern int start_executor(void);
extern int  ReleasePtr(unsigned int  mm);
extern char  FAR *GetPtr(unsigned int  mm);
extern int TUTORcopy_fileref(FileRef FAR *fDest,FileRef FAR *fSource);
extern int TUTORcmp_fileref(FileRef FAR *f1,FileRef FAR *f2);
extern int TUTORcopy_fileref_name(FileRef FAR *fRef,char FAR *name);
extern int TUTORcopy_fileref_dir(FileRef FAR *dirname,FileRef FAR *fullname);
extern char  *strf2n(char  FAR *strp);
extern char  *strnf2n(char  FAR *strp,int  nn);
extern int TUTORstartup(int argc,char **argv,FileRef FAR *filenameR);
 
/* ******************************************************************* */

/* third argument is actually a procedure pointer, but we don't use it */
int  TUTORpurge_info(unsigned int  mm,int  ptype,char FAR *restoreproc,int  restorearg);

extern long TUTORread();
extern long TUTORwrite();
extern long TUTORload_region();
extern long TUTORload_region_bmp();
extern long TUTORload_region_ppm();
extern HPALETTE InstallcTPalette(int wn,Memh pal,int size);

/* ******************************************************************* */

extern HDC CurrentDC; /* current window's device context */
extern int HaveDC; /* TRUE if have device context */
extern long polltime; /* time of last poll */
extern Memh cTwinInfH; /* handle on cT window (cTwinInf) table */
extern int cTwinInfN; /* number entries in cT window table */
extern int havePalette; /* TRUE if palette-based display */
extern int paletteNcolors; /* size of color palette */
extern int paletteNresv; /* number colors reserved by system */
extern int wColorSet; /* window colors set for */
extern int frrC,frbC,frgC; /* foreground color as r,g,b */
extern int bkrC,bkbC,bkgC; /* background color as r,g,b */
extern COLORREF frRef; /* foreground color */
extern COLORREF bkRef; /* background color */
extern int colorInvert; /* TRUE if must invert frRef/bkRef */
extern int MillionsColor; /* TRUE if TrueColor */
extern int ReadOnlyColor; /* TRUE if static palette */
extern int mControllerHasPalette; /* TRUE if should use palette from movie */
extern int inPrint; /* TRUE if output to printer */
extern int pageX,pageY; /* printer page dimensions */

/* ******************************************************************* */

#pragma check_stack(on)

#define CUSE_SYSTEM 1	/* color used by Windows system */
#define CUSE_ANIM 2	/* color annimated by cT */
#define CUSE_CT 4	/* ordinary color use by cT */
#define CUSE_RGB 8	/* RGB color use by cT */

Memh sysLogPalH = 0; /* default Windows start-up palette */
Memh thePaletteH = 0; /* logical palette */
LPLOGPALETTE thePaletteP = (LPLOGPALETTE)FARNULL; /* pointer to logical palette */
Memh paletteUseH = 0; /* palette slots usage table */
unsigned char FAR *paletteUseP = FARNULL; /* pointer to usage table */

/* ******************************************************************* */

int CTcount_colors(oldF) 
int oldF; /* not used on Windows */

{
    if (paletteNcolors)
        return(paletteNcolors);
    return(SysColors);

} /* CTcount_colors */

/* ******************************************************************* */

CTchange_palette(wn, newPal, sizeWanted, pSet, allNew)
int wn;        /* window we are changing palette for */
Memh newPal;    /* the new palette (if HNULL, use system palette) */
int sizeWanted;    /* size of cT palette */
int *pSet;    /* set to TRUE if we use the new palette */
int allNew;    /* TRUE if entire palette is changing */
/* returns the # of colors that are really drawable in cT palette */

{

    if (wn < 0)
		return(0); /* no window, can't do anything */
    if (!newPal)
		newPal = defaultPalette;
    if (!newPal)
		return(0);

    sizeWanted = (int)TUTORget_hsize(newPal)/sizeof(struct CTcolorentry);

    /* attach cT palette to window */

    if (windowsP[wn].paletteH && (windowsP[wn].paletteH != newPal) &&
    (windowsP[wn].paletteH != defaultPalette) &&
    (windowsP[wn].paletteH != oldDefaultPalette))
    	TUTORfree_palette((Memh)windowsP[wn].paletteH);
    windowsP[wn].paletteH = newPal;
    windowsP[wn].paletteSize = sizeWanted;

    /* create Windows palette from cT palette */

    sizeWanted = RealizeCTPalette(newPal,allNew);
    *pSet = TRUE;

    return(sizeWanted);

} /* CTchange_palette */

/* ******************************************************************* */

/* install cT palette as actual Windows palette */

int RealizeCTPalette(newH,allNew) /* returns # slots obtained */
Memh newH; /* handle on new palette */
int allNew; /* TRUE if entirely new palette */

{   int nCT; /* number slots in cT palette */
    struct CTcolorentry FAR *cTP; /* pointer in cT palette */
    LPLOGPALETTE sysLogPalP; /* pointer to original system palette */
    LPPALETTEENTRY wPalP; /* pointer to logical palette entry */
    int cii,pii;
    int Index;
    int nSlots; /* number slots found */
    long maxColor;
    HPALETTE hPalette;
    int useMask;
    double redD,greenD,blueD;
    double hue,saturation,value;

    if (!newH)
	return(0); /* don't know what to do */
    if ((!thePaletteH) || (!paletteUseH) || (!sysLogPalH))
	return(0); /* don't know what to do */
    useMask = CUSE_ANIM+CUSE_CT+CUSE_RGB;

    nCT = (int)TUTORget_hsize(newH)/sizeof(struct CTcolorentry); /* number slots */
    if (nCT > 256) nCT = 256;
    nSlots = 0;
	
    cTP = (struct CTcolorentry FAR *)GetPtr(newH);
    if (!paletteUseP)
	paletteUseP = (unsigned char FAR *)GetPtr(paletteUseH);
    if (!thePaletteP)
	thePaletteP = (LPLOGPALETTE)GetPtr(thePaletteH);

    /* check for change in animated colors */

    for(cii=0; cii<nCT; cii++) {
	if ((cTP+cii)->isSet && ((cTP+cii)->reserved)) {
	    if ((*(paletteUseP+cii) & CUSE_ANIM) == 0) {
		allNew = TRUE; /* start from scratch */
		break;
	    }
	}
    }

    /* clean out unused slots in cT palette */
	
    for(cii=0; cii<nCT; cii++) {
	if (!(cTP+cii)->isSet) {
	    (cTP+cii)->reserved = FALSE; /* not reserved if not set */
	    (cTP+cii)->red = (cTP+cii)->green = (cTP+cii)->blue = 0;
	    (cTP+cii)->cHue = 180*4;
	    (cTP+cii)->cSaturation = (cTP+cii)->cValue = 0;
	    (cTP+cii)->realV = 0; /* black */
	}
    } /* for */
	
    if (allNew) {
	
	/* reset for totally new palette */

	sysLogPalP = (LPLOGPALETTE)GetPtr(sysLogPalH);
	TUTORblock_move((char FAR *)sysLogPalP,(char FAR *)thePaletteP,
			(long)sizeof(LOGPALETTE)+(256*sizeof(PALETTEENTRY)));
	ReleasePtr(sysLogPalH);
	TUTORzero((char FAR *)paletteUseP,256L);
	for(cii=0; cii<10; cii++)
	    paletteUseP[cii] |= CUSE_SYSTEM;
	for(cii=246; cii<256; cii++)
	    paletteUseP[cii] |= CUSE_SYSTEM;
	for(cii=0; cii<nCT; cii++)
	    (cTP+cii)->realV = (unsigned long)-1; /* no assignments yet */
    } else {
	
	/* clean up usage table */
		
	for(cii=0; cii<256; cii++) {
	    if (paletteUseP[cii] & useMask) {
		Index = -1; /* haven't found this in cT palette yet */
		for(pii=0; pii<nCT; pii++) {
		    if ((cTP+pii)->isSet && ((cTP+pii)->realV == (unsigned long)cii)) {
			Index = pii; /* found in cT palette */
			break;
		    }
		}
		if (Index < 0) /* not referenced in cT palette */
		    paletteUseP[cii] = paletteUseP[cii] & CUSE_SYSTEM;
	    }
	} /* for */
    } /* allNew else */
	
    /* quick + dirty handling for 16 color or less */
	
    maxColor = CTcount_colors(FALSE);
    if (maxColor <= 16) {
	for(cii=0; cii<maxColor; cii++) {
	    if ((cTP+cii)->isSet) {
		wPalP = &thePaletteP->palPalEntry[cii];
		wPalP->peRed = (BYTE)((cTP+cii)->red >> 8);
		wPalP->peGreen = (BYTE)((cTP+cii)->green >> 8);
		wPalP->peBlue = (BYTE)((cTP+cii)->blue >> 8);
		wPalP->peFlags = 0;
		if (!(cTP+cii)->reserved) { /* no animated colors */
		    nSlots++;
		    (cTP+cii)->realV = cii;
		}
	    }
	} /* for */
	goto install;
    } /* 16 color if */
	
    /* map colors in cT palette to underlying system palette */

    for(cii=0; cii<nCT; cii++) {
	Index = LookupPaletteSlot(cTP+cii);
	if (Index >= 0) {
	    nSlots++;
	    (cTP+cii)->realV = Index; /* set color value */
	    *(paletteUseP+Index) |= CUSE_CT; /* mark slot used by cT */
	    wPalP = &thePaletteP->palPalEntry[Index];
	    wPalP->peRed = (BYTE)((cTP+cii)->red >> 8);
	    wPalP->peGreen = (BYTE)((cTP+cii)->green >> 8);
	    wPalP->peBlue = (BYTE)((cTP+cii)->blue >> 8);
	    wPalP->peFlags = 0;
	    if ((cTP+cii)->reserved) {
			*(paletteUseP+Index) |= CUSE_ANIM; /* mark animated */
			wPalP->peFlags = PC_RESERVED;
	    }
	} else {
	    (cTP+cii)->reserved = FALSE;
	    (cTP+cii)->realV = (unsigned long)-1; /* this color didn't make it */
	} /* Index else */
    } /* cii for */

    /* fill in unused slots with unused colors from system palette */
	
    Index = 0; /* index in system palette */
    for(cii=0; cii<nCT; cii++) {
	if ((cTP+cii)->isSet) {
	    (cTP+cii)->isSet = 1; /* clean up any junk */
	} else {
	    while (((*(paletteUseP+Index) & (CUSE_CT+CUSE_ANIM+CUSE_RGB)) != 0) &&
		   (Index < 255))
		Index++; /* advance to next unused color */
	    wPalP = &thePaletteP->palPalEntry[Index];
	    (cTP+cii)->red = wPalP->peRed << 8;
	    if ((cTP+cii)->red == 0xff00)
		(cTP+cii)->red = 0xffff;
	    (cTP+cii)->green = wPalP->peGreen << 8;
	    if ((cTP+cii)->green == 0xff00)
		(cTP+cii)->green = 0xffff;
	    (cTP+cii)->blue = wPalP->peBlue << 8;
	    if ((cTP+cii)->blue == 0xff00)
		(cTP+cii)->blue = 0xffff;
	    (cTP+cii)->realV = Index;
	    if (Index < 255)
		Index++; /* start search at next color */
	} /* isSet if */
    } /* cii for */
    for(cii=0; cii<nCT; cii++) {
	if ((cTP+cii)->isSet)
	    (cTP+cii)->isSet = 1;

	/* set HSV for this color */

	redD = ((cTP+cii)->red/65535.0)*100.0;
	greenD = ((cTP+cii)->green/65535.0)*100.0;
	blueD = ((cTP+cii)->blue/65535.0)*100.0;
	TUTORrgb_to_hsv(redD,greenD,blueD,&hue,&saturation,&value);
	(cTP+cii)->cHue = (unsigned short)(hue*4.0);
	(cTP+cii)->cSaturation = (unsigned short)(saturation*4.0);
	(cTP+cii)->cValue = (unsigned short)(value*4.0);
    }

install:

    if ((CurrentWindow != ExecWn) || (CurrentWindow < 0) || (!HaveDC) || mControllerHasPalette) {
		ReleasePtr(newH);
		ReleasePtr(paletteUseH);
		paletteUseP = FARNULL;
		return(nSlots);
    }
   
    wColorSet = -1; /* force reset */
    hPalette = cvtLogPal(thePaletteH);

    if (hPalette) {
		SelectPalette(CurrentDC,hPalette,0); /* select into device context */
		RealizePalette(CurrentDC);
		if (windowsP[CurrentWindow].winPalH)
	    	DeleteObject((HPALETTE)windowsP[CurrentWindow].winPalH);
		windowsP[CurrentWindow].winPalH = (long)(char FAR *)hPalette; /* set new palette */
    }
    ReleasePtr(paletteUseH);
    paletteUseP = FARNULL;
    ReleasePtr(thePaletteH);
    thePaletteP = (LPLOGPALETTE)FARNULL;
    ReleasePtr(newH);
    return(nSlots);
	
} /* RealizeCTPalette */

/* ******************************************************************* */

static int LookupPaletteSlot(theColor) /* look up palette slot for this color */
struct CTcolorentry FAR *theColor;

{   int bestFind; /* best slot found so far */
    int cii; /* index in palette */
    LPPALETTEENTRY wPalP; /* pointer to logical palette entry */
    long dist;
    long bestDist; /* distance of best slot */
    long curDist; /* distance of current slot */

    if (!paletteUseP)
	paletteUseP = (unsigned char FAR *)GetPtr(paletteUseH);
    bestFind = -1;

    if (!theColor->isSet)
	return(-1);

    if (!theColor->reserved) {
	if ((theColor->red == 0) && (theColor->green == 0) &&
	    (theColor->blue == 0))
	    bestFind = 0; /* black */
	else if ((theColor->red == 0xffff) && (theColor->green == 0xffff) &&
		 (theColor->blue == 0xffff))
	    bestFind = 255; /* white */
	else if ((theColor->realV >= 0) && ((*(paletteUseP+theColor->realV) & CUSE_ANIM) == 0)) {
	    wPalP = &thePaletteP->palPalEntry[theColor->realV];
	    if (((theColor->red >> 8) == wPalP->peRed) &&
		((theColor->green >> 8) == wPalP->peGreen) &&
		((theColor->blue >> 8) == wPalP->peBlue))
		bestFind = (int)theColor->realV; /* recycle old value */
	}
    } else { /* reserved */
	if ((theColor->realV >= 0) && (*(paletteUseP+theColor->realV) & CUSE_ANIM))
	    bestFind = (int)theColor->realV; /* recycle old value */
    } /* reserved else */
			
    /* try to find exact match with existing color */
		
    if ((bestFind < 0) && (!theColor->reserved)) {
	for(cii=0; cii<256; cii++) {
	    wPalP = &thePaletteP->palPalEntry[cii];
	    if (((theColor->red >> 8) == wPalP->peRed) &&
		((theColor->green >> 8) == wPalP->peGreen) &&
		((theColor->blue >> 8) == wPalP->peBlue) &&
		((*(paletteUseP+cii) & CUSE_ANIM) == 0)) {
		    bestFind = cii; /* exact match */
		    if (*(paletteUseP+cii) & CUSE_SYSTEM)
			break; /* best possible case */
	    }
	} /* for */
    } /* bestFind if */
		
    /* try to find best match with existing unused color */
			
    if (bestFind < 0) {
	bestDist = 0x7fffffffL;
	for(cii=0; cii<256; cii++) {
	    if ((*(paletteUseP+cii) == 0) || (*(paletteUseP+cii) == CUSE_SYSTEM)) {
		wPalP = &thePaletteP->palPalEntry[cii];
		curDist = (long)(theColor->red >> 8)-(long)(wPalP->peRed);
		if (curDist < 0) curDist = -curDist;
		dist = (long)(theColor->green >> 8)-(long)(wPalP->peGreen);
		if (dist < 0) dist = -dist;
		curDist += dist;
		dist = (long)(theColor->blue >> 8)-(long)(wPalP->peBlue);
		if (dist < 0) dist = -dist;
		curDist += dist;
		if (!((theColor->reserved) && (*(paletteUseP+cii)))) {
		    /* can't assign reserved color to system color */
		    if (curDist == 0) {
			bestFind = cii;
			break; /* exact match */
		    }
		    if (curDist < bestDist) {
			bestDist = curDist; /* best match so far */
			bestFind = cii;
		    } /* curDist if */
		} /* reserved if */
	    } /* paletteUseP if */
	} /* cii for */
    } /* bestFind if */

    return(bestFind);
	
} /* LookupPaletteSlot */

/* ******************************************************************* */

HPALETTE cvtLogPal(paletteH) /* convert logical palette to HPALETTE */
Memh paletteH; /* cT handle on logical palette */

{   HGLOBAL tmpPalH; /* handle on palette data */
    LOGPALETTE FAR *srcPalP; /* pointer to input palette data */
    LOGPALETTE FAR *tmpPalP; /* pointer to output palette data */
    DWORD tmpPalSize; /* size of palette data */
    HPALETTE winPalH; /* handle on Windows palette */

    if (!paletteH)
	return(0); /* no go */

    /* set up windows palette block */

    tmpPalSize = sizeof(LOGPALETTE)+256*sizeof(PALETTEENTRY);
    tmpPalH = GlobalAlloc(GPTR,tmpPalSize);
    if (!tmpPalH)
	return(0);
    tmpPalP = GlobalLock(tmpPalH); /* aquire pointer, pin block */
    srcPalP = (LOGPALETTE FAR *)GetPtr(paletteH);
    TUTORblock_move((char SHUGE *)srcPalP,(char SHUGE *)tmpPalP,tmpPalSize);
    ReleasePtr(paletteH);
    tmpPalP->palNumEntries = 256;
    tmpPalP->palVersion = 0x300;

    winPalH = CreatePalette(tmpPalP); /* create HPALETTE from logical palette */
    GlobalUnlock(tmpPalH); /* unlock before free */
    GlobalFree(tmpPalH); /* release temp copy of palette */
    return(winPalH);

} /* cvtLogPal */

/* ******************************************************************* */

immediatePalette(palH) /* install cT palette directly */
Memh palH; /* handle on cT palette */

{   struct CTcolorentry FAR *palP; /* pointer to palette */
    LPPALETTEENTRY wPalP; /* pointer to logical palette entry */
    HPALETTE hPalette;
    int pii,pjj;

    if (!palH)
	return(0); /* nothing to do */

    /* install the palette */

    palP = (struct CTcolorentry FAR *)GetPtr(palH);

    /* reset for totally new palette */

    if (!thePaletteP)
	thePaletteP = (LPLOGPALETTE)GetPtr(thePaletteH);
    for(pii=0; pii<256; pii++) {
	pjj = (int)((palP+pii)->realV);
	if (pjj < 0) pjj = pii;
	wPalP = &thePaletteP->palPalEntry[pjj];
	wPalP->peRed = (BYTE)((palP+pii)->red >> 8);
	wPalP->peGreen = (BYTE)((palP+pii)->green >> 8);
	wPalP->peBlue = (BYTE)((palP+pii)->blue >> 8);
	wPalP->peFlags = 0;
    } /* for */
    ReleasePtr(thePaletteH);
    thePaletteP = HNULL;

    /* reorder cT palette to try to fix up zred, etc */

    cTOrderPalette(palP);
    ReleasePtr(palH);

    /* attach cT palette to cT window data */

    if (windowsP[CurrentWindow].paletteH &&
	(windowsP[CurrentWindow].paletteH != palH) &&
	(windowsP[CurrentWindow].paletteH != defaultPalette) &&
	(windowsP[CurrentWindow].paletteH != oldDefaultPalette))
	TUTORfree_palette((Memh)windowsP[CurrentWindow].paletteH);
    windowsP[CurrentWindow].paletteH = palH;
    windowsP[CurrentWindow].paletteSize = 256;

    /* tell Windows about the new palette */

    wColorSet = -1; /* force reset */
    hPalette = cvtLogPal(thePaletteH);
    if (hPalette) {
		SelectPalette(CurrentDC,hPalette,0); /* select into device context */
		RealizePalette(CurrentDC);
		if (windowsP[CurrentWindow].winPalH)
	    	DeleteObject((HPALETTE)windowsP[CurrentWindow].winPalH);
		windowsP[CurrentWindow].winPalH = (long)(char FAR *)hPalette; /* set new palette */
    }

} /* immediatePalette */

/* ******************************************************************* */

int TUTORload_palette(fRef)
FileRef FAR *fRef; /* palette file */

{   int fileid; /* index of file */
    long fileSize; /* total size of file */
    long readSize; /* amount of file to read */
    long readL; /* amount read */
    Memh palH; /* handle on new palette */
    struct CTcolorentry FAR *palP; /* pointer in new palette */
    char FAR *buffP; /* buffer for palette file contents */ 
    char FAR *tP; /* pointer in buffer */
    int retV; /* return value */
    int nColors; /* number colors in palette */
    int pii,pjj; /* indexes in palette */
    unsigned int rr,gg,bb; /* color components */   
    double hhf,ssf,vvf,rrf,ggf,bbf;      
    double cyan,magenta,yellow,black;
    LPLOGPALETTE logP; /* pointer to logical palette */
    LPPALETTEENTRY wPalP; /* pointer to logical palette entry */

    palH = HNULL;
    buffP = FARNULL;
    palP = (struct CTcolorentry FAR *)FARNULL;
    nColors = 0;
    if (!thePaletteH)
		return(-FILENOTSUP);

    /* open file, get length */
	
    fileid = TUTORopen((FileRef FAR *)fRef,TRUE,FALSE,FALSE);
    if (fileid <= 0)
        return(-FILEMISSING);
    TUTORinq_file_info(fRef,NEARNULL,&fileSize,NEARNULL,NEARNULL,NEARNULL);
    
    /* allocate memory and read file */
    
    readSize = ((fileSize > 4096L) ? 4096L: fileSize);
    buffP = TUTORalloc(readSize,FALSE,"tp");
    if (!buffP) {
		retV = -FILEMEM;
		goto eexit;
    }
    readL = TUTORread(buffP,1,readSize,fileid);
    if (readL != readSize) {
		retV = -FILERANGE;
		goto eexit;
    }
    TUTORclose(fileid);
    fileid = 0;

    /* allocate new palette */
	
    palH = initial_palette(); /* copy original system palette */
    if (!palH) {
		retV = -FILEMEM;
		goto eexit;
    }
    palP = (struct CTcolorentry FAR *)GetPtr(palH);

    /* determine file type */
	                                  
	tP = buffP;
    if (strncmpf((char FAR *)"RIFF",tP,4) == 0) {
	
		/* handle RIFF format file */
		
		if (strncmpf((char FAR *)"PAL data",tP+8,8) != 0) {
	    	retV = -FILEIMPROPERTYPE;
	    	goto eexit;
		}
		logP = (LOGPALETTE FAR *)(tP+0x14); /* skip RIFF header */
		wPalP = &logP->palPalEntry[0];
		if (logP->palNumEntries > 256) {
	    	retV = -FILEIMPROPERTYPE;
	    	goto eexit;
		}

		nColors = logP->palNumEntries;
		if (nColors > 256)
	    	nColors = 256;
		for(pii=0; pii<nColors; pii++) {
	    	rr = ((wPalP+pii)->peRed) << 8;
	    	gg = ((wPalP+pii)->peGreen) << 8;
	    	bb = ((wPalP+pii)->peBlue) << 8;
	    	if (rr == 0xff00) rr = 0xffff;
	    	if (gg == 0xff00) gg = 0xffff;
	    	if (bb == 0xff00) bb = 0xffff;
	    	CTset_color_entry(palP+pii,rr,gg,bb,0,0,FALSE);
	    	(palP+pii)->realV = pii;
		}
    } else if (strncmpf((char FAR *)"BM",tP,2) == 0) { /* bitmap file */
		nColors = extract_palette_from_dib(tP,palP);  
	} else if (readSize == 768L) { /* red, green, blue triplets */  
		nColors = 256;
		for(pii=0; pii<256; pii++) {
			rr = (*tP++ & 0xff) << 8;
			gg = (*tP++ & 0xff) << 8;
			bb = (*tP++ & 0xff) << 8;    
			if (rr == 0xff00) rr = 0xffff;
	    	if (gg == 0xff00) gg = 0xffff;
	    	if (bb == 0xff00) bb = 0xffff;
			CTset_color_entry(palP+pii,rr,gg,bb,0,0,FALSE);
	    	(palP+pii)->realV = pii;
		} 
	} else if ((*tP == 0) && (*(tP+1) == 1)) { /* adobe palette, rgb color */   
	    nColors = (*(tP+2) & 0xff) << 8; 
	    nColors |= *(tP+3) & 0xff; 
	    if ((nColors <= 0) || (nColors > 256)) {
	    	retV = -FILEIMPROPERTYPE;
	    	goto eexit;
	    }
	    tP += 4; /* skip over header */
	    for(pii=0; pii<nColors; pii++) {
	    	pjj = (*tP++ & 0xff) << 8; 
	    	pjj |= *tP++ & 0xff;  
	    	if (pjj == 0) { /* rgb color */  
	    		rr = (*tP++ & 0xff) << 8; 
	    		rr |= *tP++ & 0xff;  
	    		gg = (*tP++ & 0xff) << 8; 
	    		gg |= *tP++ & 0xff;
	    		bb = (*tP++ & 0xff) << 8; 
	    		bb |= *tP++ & 0xff;
	        	tP += 2; /* skip over unused word */   
	        } else if (pjj == 1) { /* hsv color */
	        	rr = (*tP++ & 0xff) << 8; 
	    		rr |= *tP++ & 0xff;  
	    		gg = (*tP++ & 0xff) << 8; 
	    		gg |= *tP++ & 0xff;
	    		bb = (*tP++ & 0xff) << 8; 
	    		bb |= *tP++ & 0xff;
	        	hhf = 100.0*(((long)(rr)) & 0xffffL)/65535.0;
	        	ssf = 100.0*(((long)(gg)) & 0xffffL)/65535.0;
	        	vvf = 100.0*(((long)(bb)) & 0xffffL)/65535.0;
	        	tP += 2; /* skip over unused word */
	        	TUTORhsv_to_rgb(hhf,ssf,vvf,&rrf,&ggf,&bbf);
	        	rr = (unsigned int)(rrf*65535.0/100.0);
	        	gg = (unsigned int)(ggf*65535.0/100.0);
	        	bb = (unsigned int)(bbf*65535.0/100.0);    
	        } else if (pjj == 2) { /* cmyk color */
	          	rr = (*tP++ & 0xff) << 8; 
	    		rr |= *tP++ & 0xff;   
	    		cyan = (double)(rr)/65535.0;
	    		rr = (*tP++ & 0xff) << 8; 
	    		rr |= *tP++ & 0xff;     
	    		magenta = (double)(rr)/65535.0;
	          	rr = (*tP++ & 0xff) << 8; 
	    		rr |= *tP++ & 0xff;     
	    		yellow = (double)(rr)/65535.0;
	          	rr = (*tP++ & 0xff) << 8; 
	    		rr |= *tP++ & 0xff;  
                black = (double)(rr)/65535.0;    
                rr = (unsigned int)((1.0-__min(1.0,cyan*(1.0-black)+black))*65535.0);
                gg = (unsigned int)((1.0-__min(1.0,magenta*(1.0-black)+black))*65535.0);
                bb = (unsigned int)((1.0-__min(1.0,yellow*(1.0-black)+black))*65535.0);
	        } else if (pjj == 8) { /* greyscale */     
	        	rr = (*tP++ & 0xff) << 8; 
	    		rr |= *tP++ & 0xff;  
	        	vvf = (double)(rr)/10000.0;      
	        	tP += 6; /* skip over unused words */
	        	rr = gg = bb = (unsigned int)(vvf*65535.0);
	        } else { /* unrecognized color type */
	        	retV = -FILEIMPROPERTYPE;
				goto eexit;
	    	}
	    	CTset_color_entry(palP+pii,rr,gg,bb,0,0,FALSE);
	    	(palP+pii)->realV = pii;	        
	    }
    } else {
		retV = -FILEIMPROPERTYPE;
		goto eexit;
    }
    TUTORdealloc(buffP); /* release temp memory */

    /* reorder cT palette to try to fix up zred, etc */

    cTOrderPalette(palP);
    ReleasePtr(palH);
    palP = (struct CTcolorentry FAR *)FARNULL;

    /* install the palette */

    immediatePalette(palH);

    return(nColors);
	
eexit: /* error exit */
    if (palP)
	ReleasePtr(palH);
    if (palH)
	TUTORfree_palette(palH);
    if (buffP)
		TUTORdealloc(buffP);
    if (fileid)
		TUTORclose(fileid);
    return(retV);
		
} /* TUTORload_palette */

/* ******************************************************************* */

int extract_palette_from_dib(dibP,palP)
unsigned char FAR *dibP; /* pointer to bitmap */
struct CTcolorentry FAR *palP; /* pointer in new palette */

{   int nColors; /* number colors in palette */
    int pii; /* index in palette */
    unsigned int rr,gg,bb; /* color components */
    LPBITMAPINFO biP; /* pointer to DIB bitmap header */
    DWORD dwNumColors; /* number colors in DIB */
    WORD wBitCount; /* bits/pixel in DIB */
    LPRGBQUAD rgbP; /* pointer to DIB color table */

    biP = (LPBITMAPINFO)(dibP+sizeof(BITMAPFILEHEADER));
    wBitCount = biP->bmiHeader.biBitCount;

    /* figure out size of color table (if any) */

    dwNumColors = 0;
    if (biP->bmiHeader.biSize >= 36)
	dwNumColors = biP->bmiHeader.biClrUsed;
    if (dwNumColors == 0) {
	if (wBitCount != 24)
	    dwNumColors = 1L << wBitCount;
    } /* dwNumColors if */
    if (dwNumColors == 0) {
	return(0);
    }

    /* extract colors from table */

    nColors = (int)dwNumColors;
    if (dwNumColors > 256)
		nColors = 256;
    rgbP = (LPRGBQUAD)(dibP+sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER));
    for(pii=0; pii<nColors; pii++) {
	rr = ((rgbP+pii)->rgbRed) << 8;
	gg = ((rgbP+pii)->rgbGreen) << 8;
	bb = ((rgbP+pii)->rgbBlue) << 8;
	if (rr == 0xff00)
	    rr = 0xffff;
	if (gg == 0xff00)
	    gg = 0xffff;
	if (bb == 0xff00)
	    bb = 0xffff;
	CTset_color_entry(palP+pii,rr,gg,bb,0,0,FALSE);
	(palP+pii)->realV = pii;
    }
    return(nColors);

} /* extract_palette_from_dib */

/* ******************************************************************* */

static int add_to_pal(palP,rr,gg,bb)
struct CTcolorentry FAR *palP;
int rr,gg,bb;

{   int setI;

    setI = PaletteMatch(palP,256,rr,gg,bb);
    if (setI >= 0)
		CTset_color_entry(palP+setI,rr,gg,bb,0,0,FALSE);
	return(0);
		
} /* add_to_pal */

/* ******************************************************************* */

#ifdef NOSUCH

int dump_palette()

{   int pii;
    PALETTEENTRY theC;
    char msg[80];

    if (!thePaletteP)
	thePaletteP = (LPLOGPALETTE)GetPtr(thePaletteH);

    TUTORlog("logpal\n");
    for(pii=0; pii<256; pii++) {
	theC = thePaletteP->palPalEntry[pii];
	sprintf(msg,"%d %ld %ld %ld\n",pii,(long)((unsigned int)theC.peRed)
	       ,(long)((unsigned int )theC.peGreen),(long)((unsigned int)theC.peBlue));
	TUTORlog(msg);
    } /* for */
	
} /* dump_palette */

/* ******************************************************************* */

int dump_cT_palette(paletteP)
struct CTcolorentry FAR *paletteP;

{   int pii;
    struct CTcolorentry theC;
    char msg[80];

    if (!thePaletteP)
	thePaletteP = (LPLOGPALETTE)GetPtr(thePaletteH);

    TUTORlog("cT palette\n");
    for(pii=0; pii<256; pii++) {
	theC = *(paletteP+pii);
	sprintf(msg,"%d %ld %ld %ld %d\n",pii,(long)((unsigned int)theC.red >> 8)
	       ,(long)((unsigned int )theC.green >> 8)
	       ,(long)((unsigned int)theC.blue >> 8),theC.realV);
	TUTORlog(msg);
    } /* for */
	
} /* dump_palette */

/* ******************************************************************* */

int check_dup_palette()

{   int pii,pjj;
    PALETTEENTRY pA;
    PALETTEENTRY pB;

    if (!thePaletteP)
	thePaletteP = (LPLOGPALETTE)GetPtr(thePaletteH);

    for(pii=0; pii<255; pii++) {
	pA = thePaletteP->palPalEntry[pii];
	for(pjj=pii+1; pjj<256; pjj++) {
	    pB = thePaletteP->palPalEntry[pjj];
	    if ((pA.peRed == pB.peRed) && (pA.peGreen == pB.peGreen) &&
		(pA.peBlue == pB.peBlue) )
		TUTORlog("duplicate\n");
	}
    }
}

#endif

/* ******************************************************************* */

CTanimate_color(cn,red,green,blue) 
int cn; /* index in palette */
int red; /* red value */
int green; /* green value */
int blue; /* blue value */

{   int wn; /* window number */
    int cIndex; /* index in palette */
    Memh paletteH; /* handle on cT palette */
    struct CTcolorentry FAR *paletteP; /* pointer to cT palette */
    HPALETTE winPalH; /* handle on Windows palette */
    int redC,greenC,blueC; /* Windows color values */
    PALETTEENTRY palE; /* palette entry to change */
    int resF; /* palette slot reserved flag */
    int wIndex; /* index in Windows palette */
    double redD,greenD,blueD;
    double hue,saturation,value;

    /* check window, index legal */

    wn = CurrentWindow;
    if (wn < 0) return(FALSE); /* can't do anything */
    paletteH = windowsP[wn].paletteH;
    if (!paletteH)
	return(FALSE); /* can't do anything */
    if (windowsP[wn].winPalH)
	winPalH = (HPALETTE)windowsP[wn].winPalH;
    else winPalH = NULL;
    if (!winPalH)
	return(FALSE); /* can't do anything */

    wIndex = -1;
    cIndex = map_default_color(cn);
    if ((cIndex < 0) || (cIndex >= 256))
        return(0);

    /* update cT palette */

    paletteP = cIndex+((struct CTcolorentry FAR *)GetPtr(paletteH));
    if (resF = paletteP->reserved) {
		paletteP->red = red;
		paletteP->green = green;
		paletteP->blue = blue;
		redD = (red/65535.0)*100.0;
		greenD = (green/65535.0)*100.0;
		blueD = (blue/65535.0)*100.0;
		TUTORrgb_to_hsv(redD,greenD,blueD,&hue,&saturation,&value);
		paletteP->cHue = (unsigned short)(hue*4.0);
		paletteP->cSaturation = (unsigned short)(saturation*4.0);
		paletteP->cValue = (unsigned short)(value*4.0);
		wIndex = (int)paletteP->realV;
    }
    ReleasePtr(paletteH);
    if ((!resF) || (wIndex < 0))
	return(0);

    /* update Windows palette */

    redC = red >> 8;
    greenC = green >> 8;
    blueC = blue >> 8;
    palE.peFlags = PC_RESERVED;
    palE.peRed = redC;
    palE.peGreen = greenC;
    palE.peBlue = blueC;
    AnimatePalette(winPalH,wIndex,1,(PALETTEENTRY FAR *)&palE);

    return(TRUE); 

} /* CTanimate_color */

/* ******************************************************************* */

CTinq_rgb_system(cn,red,green,blue) 
int cn; /* palette slot */
double *red; /* returned with red value */
double *green; /* returned with green value */
double *blue; /* returned with blue value */

{   int rC,bC,gC; /* Windows color values */

    extract_palette_color(cn,&rC,&gC,&bC);
    *red = 100.0*((double)rC/255.0);
    *green = 100.0*((double)gC/255.0);
    *blue = 100.0*((double)bC/255.0);
    return(0); 

} /* CTinq_rgb_system */

/* ******************************************************************* */

CTmap_default_color(cn) /* map default colors to actual indices */
register int cn;
    
{
    if (cn == color_defaultf) {
        if (pcoldcolor && (CurrentWindow == ExecWn))
            cn = color_white;
        else
            cn = color_black;
    } else {
        if (pcoldcolor && (CurrentWindow == ExecWn))
            cn = color_black;
        else
            cn = color_white;
    }
    return(cn);

} /* CTmap_default_color */

/* ******************************************************************* */

int CTset_foreground_color(cIndex) 
int cIndex; /* index of desired color in palette */

{
    if (cIndex == color_rgb) {
	TUTORset_color_rgb(0,0,fgndColor.red,fgndColor.green,fgndColor.blue);
	return(0);
    }
    cIndex = CTmap_color(CurrentWindow,cIndex,TRUE);
    set_win_color(1,cIndex);
    return(0); 

} /* CTset_foreground_color */

/* ******************************************************************* */

int CTset_background_color(cIndex) 
int cIndex; /* index of desired color in palette */

{
    if (cIndex == color_rgb) {
	TUTORset_color_rgb(1,0,bgndColor.red,bgndColor.green,bgndColor.blue);
	return(0);
    }
    cIndex = CTmap_color(CurrentWindow,cIndex,FALSE);
    set_win_color(0,cIndex);
    return(0);

} /* CTset_background_color */

/* ******************************************************************* */

int set_win_color(fgndF,cIndex) 
int fgndF; /* TRUE if foreground color */
int cIndex; /* index of desired color in palette */

{   Memh paletteH; /* handle on current palette */
    struct CTcolorentry FAR *paletteP; /* pointer to palette slot */

    if (CurrentWindow < 0)
        return(0);

    if (cIndex == color_rgb) { /* assume rgb set up */
	if (fgndF)
	    TUTORset_color_rgb(0,0,fgndColor.red,fgndColor.green,fgndColor.blue);
	else
	    TUTORset_color_rgb(1,0,bgndColor.red,bgndColor.green,bgndColor.blue);
	return(0);
    }

    /* check if correct color already set */

    if (wColorSet == CurrentWindow) {
        if (fgndF) {
            if (fgndColor.palette == cIndex) return(0);
        } else {
            if (bgndColor.palette == cIndex) return(0);
        }
    } /* wColorSet if */

    /* handle default colors */
 
    cIndex = map_default_color(cIndex);
    if ((cIndex >= 256) || (cIndex < 0))
        cIndex = 0;
    
    /* set to specified color */

    paletteH = windowsP[CurrentWindow].paletteH;
    if (!paletteH)
	paletteH = defaultPalette;
    paletteP = cIndex+((struct CTcolorentry FAR *)GetPtr(paletteH));
    if (fgndF) {
	fgndColor.palette = cIndex;
	fgndColor.red = 100.0*(double)(paletteP->red)/32767.0;
	fgndColor.green = 100.0*(double)(paletteP->green)/32767.0;
	fgndColor.blue = 100.0*(double)(paletteP->blue)/32767.0;
    } else {
	bgndColor.palette = cIndex;
	bgndColor.red = 100.0*(double)(paletteP->red)/32767.0;
	bgndColor.green = 100.0*(double)(paletteP->green)/32767.0;
	bgndColor.blue = 100.0*(double)(paletteP->blue)/32767.0;
    }
    ReleasePtr(paletteH);

    wColorSet = -1; /* force reset */
    pen_fix(); /* establish pen color, etc */

    return(0); 

} /* set_win_color */

/* ******************************************************************* */

TUTORset_color_rgb(select,SysOrPal,red,green,blue)
int select; /* 0 = foreground, 1 = background, 2 = window */
int SysOrPal; /* 0 = use system palette, 1 = search cT palette */
double red; /* 0.0 - 100.0 red component */
double green; /* 0.0 - 100.0 green component */
double blue; /* 0.0 - 100.0 blue component */

{   Memh paletteH; /* handle on cT palette */
    struct CTcolorentry FAR *paletteP; /* pointer to palette */
    unsigned int redC,greenC,blueC;
    int bestSlot; /* best slot found so far */
    struct tutorColor *cP; /* pointer to color to set */
    
    /* convert floating colors to int */
    
    redC = (unsigned int)((red/100.0)*(double)(0xffffL));
    greenC = (unsigned int)((green/100.0)*(double)(0xffffL));
    blueC = (unsigned int)((blue/100.0)*(double)(0xffffL));

    switch (select) {
    case 0: /* foreground */
        cP = &fgndColor; 
        break;
    case 1: /* background */
        cP = &bgndColor;
        break;
    case 2: /* window */
        cP = &winColor;
        break;
    default:
        cP = &fgndColor;
        break;
    } /* switch */

    cP->palette = color_rgb;
    cP->red = red;
    cP->green = green;
    cP->blue = blue;
    wColorSet = -1; /* force reset */

    if (MillionsColor || ReadOnlyColor) {
	pen_fix();
	return(0);
    }

    /* handle palette-based display */

    paletteH = windowsP[CurrentWindow].paletteH;
    if (paletteH == HNULL) /* default palette */
	paletteH = defaultPalette;
    paletteP = (struct CTcolorentry FAR *) GetPtr(paletteH);
    bestSlot = PaletteMatch(paletteP,256,redC,greenC,blueC);
    ReleasePtr(paletteH);
        
    /* drive palette-based functions to set color */
        
    switch (select) {
        case 0:
            CTset_foreground_color(bestSlot);
            break;
        case 1:
            CTset_background_color(bestSlot);
            break;
        case 2:
     /*     CTset_window_color(bestSlot);  nothing to do */
            break;
    } /* switch */
    
    return(0);
        
} /* TUTORset_color_rgb */

/* ******************************************************************* */

int extract_palette_color(cIndex,rC,gC,bC) /* get color from palette */ 
/* returns TRUE if palette slot reserved */
int cIndex; /* index of desired color in palette */
int *rC; /* red component */
int *gC; /* green component */
int *bC; /* blue component */

{   Memh paletteH; /* handle on cT palette */
    struct CTcolorentry FAR *paletteP; /* pointer to cT palette */
    int paletteSize;
    int reserveF;

    *rC = 255; /* pre-set for white */
    *gC = 255;
    *bC = 255;
    if ((CurrentWindow < 0) || (defaultPalette == HNULL))
        return(0); /* not initialized yet */

    /* get RGB color from cT palette */

    cIndex = map_default_color(cIndex);
    paletteH = windowsP[CurrentWindow].paletteH;
    if (paletteH == HNULL)
        paletteH = defaultPalette;
    paletteSize = (int)TUTORget_hsize(paletteH)/sizeof(struct CTcolorentry);
    if (cIndex < 0) 
        cIndex = 0;
    if (cIndex >= paletteSize) 
        cIndex = paletteSize;
    paletteP = cIndex+((struct CTcolorentry FAR *)GetPtr(paletteH));
    *rC = paletteP->red >> 8;
    *gC = paletteP->green >> 8;
    *bC = paletteP->blue >> 8;
    reserveF = paletteP->reserved;
    ReleasePtr(paletteH);

    return(reserveF); 

} /* extract_palette_color */

/* ******************************************************************* */

int map_default_color(cIndex) /* convert default to legal index */
int cIndex; /* index in color palette */

{
    if (cIndex == color_defaultf) {
        if (pcoldcolor && (CurrentWindow == ExecWn))
            cIndex = color_white;
        else
            cIndex = color_black;
    } else if (cIndex == color_defaultb) {
        if (pcoldcolor && (CurrentWindow == ExecWn))
            cIndex = color_black;
        else 
            cIndex = color_white;
    }
    return(cIndex); /* return corrected value */

} /* map_default_color */

/* ******************************************************************* */

Memh TUTORget_default_rgb() /* return table of default RGB values */

{   long tableSize; /* size of color table required */
    Memh tableH; /* cT RGB values table handle */
    double FAR *tableP; /* pointer to RGB values table */
    long nColors; /* number colors in color table */
    int pii; /* index in palette */
    HGLOBAL tmpPalH; /* handle on palette data */
    LOGPALETTE FAR *tmpPalP; /* pointer to palette data */

    tmpPalH = get_sys_palette();
    if (!tmpPalH)
	return(HNULL);
    tmpPalP = GlobalLock(tmpPalH); /* aquire pointer, pin block */
    nColors = tmpPalP->palNumEntries;
    tableSize = (long)(nColors)*(long)(3*sizeof(double));
    tableH = TUTORhandle("colors",tableSize,TRUE);
    if (!tableH) {
	GlobalUnlock(tmpPalH); /* release memory */
	GlobalFree(tmpPalH);
	return(HNULL);
    }
    TUTORpurge_info(tableH,M_WORM,FARNULL,0);
    AllowHandlePurge(tableH);

    tableP = (double FAR *)GetPtr(tableH);
    for(pii=0; pii<nColors; pii++) {
    *tableP++ = ((double)(tmpPalP->palPalEntry[pii].peRed)/(255.0))*100.0;
    *tableP++ = ((double)(tmpPalP->palPalEntry[pii].peGreen)/(255.0))*100.0;
    *tableP++ = ((double)(tmpPalP->palPalEntry[pii].peBlue)/(255.0))*100.0;
    } /* for */
    GlobalUnlock(tmpPalH);
    GlobalFree(tmpPalH);
    ReleasePtr(tableH);

    return(tableH);
    
} /* TUTORget_default_rgb */

/* ******************************************************************* */

static HGLOBAL get_sys_palette() /* return contents of system default palette */

{   long nColors; /* number colors in color table */
    int pii; /* index in palette */
    HGLOBAL tmpPalH; /* handle on palette data */
    LOGPALETTE FAR *tmpPalP; /* pointer to palette data */
    DWORD tmpPalSize; /* size of palette data */
    HGLOBAL retPalH; /* handle on palette data */
    LOGPALETTE FAR *retPalP; /* pointer to palette data */
    HPALETTE logPalH; /* handle on logical palette */
    HPALETTE curPalH; /* handle on current pallete */
    COLORREF nextColor; /* next color to look up */
        
    nColors = SysColors;
    if (nColors < 2) nColors = 2;
    if (nColors > 256) nColors = 256;

    /* build logical palette from current hardware palette */
  
    tmpPalSize = sizeof(LOGPALETTE)+nColors*sizeof(PALETTEENTRY);
    tmpPalH = GlobalAlloc(GPTR,tmpPalSize);
    if (!tmpPalH)
    	return(NULL);
    tmpPalP = GlobalLock(tmpPalH); /* aquire pointer, pin block */
    tmpPalP->palNumEntries = (int)nColors;
    tmpPalP->palVersion = 0x300;

    /* handle monochrome palette */

    if (nColors == 2) {
    tmpPalP->palPalEntry[0].peFlags = 0;
    tmpPalP->palPalEntry[0].peRed = 0; /* black */
    tmpPalP->palPalEntry[0].peGreen = 0;
    tmpPalP->palPalEntry[0].peBlue = 0;
    tmpPalP->palPalEntry[1].peFlags = 0;
    tmpPalP->palPalEntry[1].peRed = 255; /* white */
    tmpPalP->palPalEntry[1].peGreen = 255;
    tmpPalP->palPalEntry[1].peBlue = 255;
    } else {

    /* handle color palette */

    for(pii=0; pii<nColors; pii++) { /* initialize palette entries */
        tmpPalP->palPalEntry[pii].peFlags = PC_EXPLICIT;
        tmpPalP->palPalEntry[pii].peRed = pii; /* palette index */
        tmpPalP->palPalEntry[pii].peGreen = 0;
        tmpPalP->palPalEntry[pii].peBlue = 0;
    } /* pii for */
    } /* nColors else */
    logPalH = CreatePalette(tmpPalP); /* create logical palette */
    GlobalUnlock(tmpPalH); /* unlock before free */
    GlobalFree(tmpPalH); /* release temp copy of palette */
    if (!logPalH)
    	return(NULL);
    curPalH = SelectPalette(CurrentDC,logPalH,0); /* select into device context */  
    RealizePalette(CurrentDC);

    retPalH = GlobalAlloc(GPTR,tmpPalSize);
    if (!retPalH) {
    SelectPalette(CurrentDC,curPalH,0); /* restore palette */
    RealizePalette(CurrentDC);
    DeleteObject(logPalH);
    GlobalUnlock(retPalH);
    return(NULL);
    }
    retPalP = GlobalLock(retPalH); /* aquire pointer, pin block */
    retPalP->palNumEntries = (int)nColors;
    retPalP->palVersion = 0x300;

    for(pii=0; pii<nColors; pii++) {
    nextColor = PALETTEINDEX(pii);
    nextColor = GetNearestColor(CurrentDC,nextColor);
    retPalP->palPalEntry[pii].peFlags = 0;
    retPalP->palPalEntry[pii].peRed = GetRValue(nextColor);
    retPalP->palPalEntry[pii].peGreen = GetGValue(nextColor);
    retPalP->palPalEntry[pii].peBlue = GetBValue(nextColor);
    } /* for */
    SelectPalette(CurrentDC,curPalH,0); /* restore palette */
    RealizePalette(CurrentDC);
    DeleteObject(logPalH);
    GlobalUnlock(retPalH);

    return(retPalH);
    
} /* get_sys_palette */

/* ******************************************************************* */

long TUTORabs_save_region(x1,y1,x2,y2) 
int x1,y1; /* left, top of region */
int x2,y2; /* bottom, right of region */

{   Memh headerH; /* handle on region header */
    struct saved_region FAR *headerP; /* pointer to region header */
    HDC hdc; /* handle on device context */
    HDC hMemDC; /* handle on memory device context */
    HBITMAP bitmapH; /* handle on bitmap containing screen region */
    HBITMAP oldDestH; /* saved handle for restore */
    int width; /* width of bitmap containing screen region */
    int height; /* height of bitmap containing screen region */
    int ii;

    /* normalize region */

    if (x1 > x2) {
        ii = x1;
        x1 = x2;
        x2 = ii;
    }
    if (y1 > y2) {
        ii = y1;
        y1 = y2;
        y2 = ii;
    }
    width = (x2-x1)+1;
    height = (y2-y1)+1;
    if ((width <= 0) || (height <= 0))
        return(0); /* can't create bitmap */

    /* create region header */

    headerH = TUTORhandle("region",(long)sizeof(struct saved_region),TRUE);
    if (!headerH)
		return(0); /* can't create header */
    TUTORpurge_info(headerH,M_WORM,FARNULL,0);
    AllowHandlePurge(headerH);

    /* BitBlt region to offscreen bitmap */

    hdc = CurrentDC; /* get handle on device context */
    hMemDC = CreateCompatibleDC(hdc); /* create memory context */
    bitmapH = CreateCompatibleBitmap(hdc,width,height);
    oldDestH = SelectObject(hMemDC,bitmapH); /* select bitmap into context */
    BitBlt(hMemDC,0,0,width,height,hdc,x1,y1,SRCCOPY);
    SelectObject(hMemDC,oldDestH);
    DeleteDC(hMemDC); /* delete memory device context */

    headerP = (struct saved_region FAR *)GetPtr(headerH);
    TUTORzero((char FAR *)headerP,(long)sizeof(struct saved_region));
    headerP->format = 0;
    headerP->bmapH = (long)(char FAR *)bitmapH;
    headerP->rgbdibH = HNULL;
    headerP->paldibH = HNULL;
    headerP->width = width;
    headerP->height = height;
    ReleasePtr(headerH);
    return((long)headerH);

} /* TUTORabs_save_region */

/* ******************************************************************* */

TUTORabs_restore_region(id,x1,y1) 
long id; /* id of saved region to restore */
int x1,y1; /* top, left for restore */

{   Memh headerH; /* handle on region header info */
    struct saved_region FAR *headerP; /* pointer to saved region header */
    int width,height;
    int format; /* 0 = screen bitmap, 1 = dib */
    HBITMAP regionH; /* handle on saved region bitmap */
    BITMAP bInf; /* info on saved region bitmap */
    HBITMAP oldSrcH; /* saved handle for restore */
    HDC hMemDC; /* handle on memory device context */
    Memh dibH; /* handle on DIB bitmap */
    char FAR *dibP; /* pointer to DIB bitmap */
    LPBITMAPINFO biP; /* pointer to DIB bitmap header */
    DWORD dwNumColors; /* number colors in DIB */
    DWORD dwColorTableSize; /* size of color table in DIB */
    WORD wBitCount; /* bits/pixel in DIB */
    BYTE SHUGE *lpDibBits; /* pointer to actuall DIB bits */
    int nColors; /* number colors available */
    int needScale; /* TRUE if need to scale output for printer */
    int uWidth,uHeight; /* useable printer width, height */
    int sWidth,sHeight; /* width, height to scale to */
    int xDpi,yDpi; /* x,y dots/inch */
    double scaleV; /* scale factor */
    int deviceAttr;

    nColors = CTcount_colors(FALSE);
    if ((nColors <= 256) && (!inPrint)) {
		win_palettize_region(id); /* convert rgb->palette, if needed */
		win_adapt_region(id); /* adapt to current palette, if needed */
    }

    headerH = (Memh)id;
    headerP = (struct saved_region FAR *)GetPtr(headerH);
    format = headerP->format; /* pick up type of image */
    regionH = (HBITMAP)headerP->bmapH; /* pick up handle on screen bitmap */
    dibH = HNULL;
    if (nColors <= 256) {
		dibH = headerP->paldibH; /* try for palettized version */
		if (!dibH)
	    	dibH = headerP->rgbdibH; /* fall back on rgb version */
    } else {
		dibH = headerP->rgbdibH; /* try for rgb version */
		if (!dibH)
	    	dibH = headerP->paldibH; /* fall back on palettized version */
    }
    ReleasePtr(headerH);

    if (format == 0) {
		GetObject(regionH,sizeof(BITMAP),(BITMAP FAR *)&bInf);
		width = bInf.bmWidth;
		height = bInf.bmHeight;
		hMemDC = CreateCompatibleDC(CurrentDC); /* create memory context */
		oldSrcH = SelectObject(hMemDC,regionH); /* select bitmap into context */
		BitBlt(CurrentDC,x1,y1,width,height,hMemDC,0,0,SRCCOPY);
		SelectObject(hMemDC,oldSrcH);
		DeleteDC(hMemDC); /* delete memory device context */
    } else if (format == 1) {
		dibP = GetPtr(dibH); /* get pointer to DIB data */
		biP = (LPBITMAPINFO)(dibP+sizeof(BITMAPFILEHEADER));

		/* get width, height and bits/pixel */
          
		width = (int)biP->bmiHeader.biWidth;
        height = (int)biP->bmiHeader.biHeight; 
		wBitCount = biP->bmiHeader.biBitCount;

		/* figure out size of color table (if any) */
        
		dwNumColors = CountDIBColors(dibH);
		dwColorTableSize = dwNumColors*sizeof(RGBQUAD);
        
		/* compute location of actual DIB bits */
            
		lpDibBits = ((unsigned char SHUGE *)(biP))+biP->bmiHeader.biSize+dwColorTableSize;

		/* display the image */

	needScale = deviceAttr = 0;
	if (inPrint)
	    deviceAttr = GetDeviceCaps(CurrentDC,RASTERCAPS);
	if (deviceAttr & RC_STRETCHDIB) {
	    needScale = TRUE;
	    uWidth = pageX-x1;
	    uHeight = pageY-y1;

	    /* adjust for printer dpi vs screen default ~72 dpi */

	    xDpi = GetDeviceCaps(CurrentDC,LOGPIXELSX);
	    yDpi = GetDeviceCaps(CurrentDC,LOGPIXELSY);
	    scaleV = (double)(xDpi)/72.0;
	    scaleV = floor(scaleV);
	    sWidth = (int)(scaleV*width);
	    sHeight = (int)(scaleV*height);

	    /* adjust for x dpi != y dpi */

	    if (xDpi != yDpi) {
		if (xDpi > yDpi) {
		    scaleV = (double)yDpi/(double)xDpi;
		    sHeight = (int)(scaleV*sHeight);
		} else if (yDpi > xDpi) {
		    scaleV = (double)xDpi/(double)yDpi;
		    sWidth = (int)(scaleV*sWidth);
		}
	    } /* Dpi if */

	    /* be sure image fits on page */

	    if (sHeight > uHeight) {
		scaleV = (double)uHeight/(double)sHeight;
			sWidth = (int)(scaleV*sWidth);
			sHeight = (int)(scaleV*sHeight);
	    }
	    if (sWidth > uWidth) {
			scaleV = (double)uWidth/(double)sWidth;
			sWidth = (int)(scaleV*sWidth);
			sHeight = (int)(scaleV*sHeight);
	    }
	} /* deviceAttr if */
	if (needScale) {
	    StretchDIBits(CurrentDC,x1,y1,sWidth,sHeight,0,0,width,height,
			(LPSTR)lpDibBits,biP,DIB_RGB_COLORS,SRCCOPY);
	} else {
	    SetDIBitsToDevice(CurrentDC,x1,y1,width,height,0,0,
			  0,height,(LPSTR)lpDibBits,biP,DIB_RGB_COLORS);
	}
	ReleasePtr(dibH);
    } /* format else-if */
    return(0); 

} /* TUTORabs_restore_region */

/* ******************************************************************* */

TUTORfree_region(id) 
long id; /* saved region id */

{   Memh headerH; /* handle on saved region header */
    struct saved_region FAR *headerP; /* pointer to saved region header */
    HBITMAP regionH; /* handle on saved region bitmap */
    Memh rgbdibH; /* handle on rgb DIB */
    Memh paldibH; /* handle on palettized DIB */
    Memh palDataH; /* handle on palettized data */
    Memh rgbDataH; /* handle on r,g,b data */
    Memh palH; /* handle on native palette */

    headerH = (Memh)id;
    headerP = (struct saved_region FAR *)GetPtr(headerH);
    regionH = (HBITMAP)headerP->bmapH; /* pick up handle on bitmap */
    rgbdibH = headerP->rgbdibH; /* pick up handle on rgb DIB */
    paldibH = headerP->paldibH; /* pick up handle on palettized DIB */
    rgbDataH = headerP->rgbDataH; /* pick up handle on r,g,b data */
    palDataH = headerP->palDataH; /* pick up handle on palettized data */
    palH = headerP->nativePal;
    ReleasePtr(headerH);
    TUTORfree_handle(headerH); /* release memory for header */
    if (rgbdibH)
	TUTORfree_handle(rgbdibH); /* release memory for dib */
    if (paldibH)
	TUTORfree_handle(paldibH); /* release memory for dib */
    if (regionH)
	DeleteObject(regionH);
    if (rgbDataH)
	TUTORfree_handle(rgbDataH);
    if (palDataH)
	TUTORfree_handle(palDataH);
    if (palH)
	TUTORfree_palette(palH);
    return(0);
    
} /* TUTORfree_region */

/* ******************************************************************* */

long TUTORload_region(fRef) /* load image from file */
FileRef FAR *fRef;
/* returns +n = region id */
/*         -1 = no file */
/*         -2 = no memory */
/*         -3 = no data */

{   int fIndx; /* index of file in cT table */
    long fileSize; /* size of BMP file */
    long nRead; /* number bytes actually read */
    Memh dataH; /* handle on image data */
    char FAR *dataP; /* pointer to image data */
    int errF; /* error flag */
    int bmpF; /* TRUE if bmp/dib format */
    Memh regionH; /* handle on region header */

    /* open image file, determine size */
    
    errF = dataH = bmpF = regionH = 0; /* no data, no error yet */
    fIndx = TUTORopen(fRef,TRUE,FALSE,FALSE);
    if (fIndx == 0)
	return(-1); /* -1 = can't open file */
    TUTORinq_file_info(fRef,NEARNULL,&fileSize,NEARNULL,NEARNULL,NEARNULL);
    if (fileSize < 4)
	errF = -3; /* must have at least minimum header */
        
    /* allocate memory for file contents, read file */
    
    if (!errF) {
	dataH = TUTORhandle("image",fileSize,TRUE);
	if (!dataH) {
	    errF = -2; /* no memory */
	} else {
	    TUTORpurge_info(dataH,M_WORM,FARNULL,0);
	    AllowHandlePurge(dataH);
	    dataP = (char FAR *)GetPtr(dataH); /* pointer to data area */
	    nRead = TUTORread(dataP,1,fileSize,fIndx);
	    if (nRead != fileSize) {
		errF = -3; /* can't read file contents */
	    }
	    if ((*dataP == 'B') && (*(dataP+1) == 'M') && (fileSize >= 0x1D))
		bmpF = TRUE; /* bmp/dib format file */
	    ReleasePtr(dataH);
	}
    } /* errF if */
    TUTORclose(fIndx); /* close image file */
    if (errF) {
	if (dataH)
	    TUTORfree_handle(dataH);
	return(errF); /* something went wrong */
    }
    
    if (bmpF) {
	regionH = (Memh)TUTORload_region_bmp(dataH);
    } else {
		if (dataH)
	    	TUTORfree_handle(dataH);
		regionH = (Memh)TUTORload_region_ppm(fRef); /* try to load as ppm format */
    }

    if (CTcount_colors(FALSE) <= 256)
	win_palettize_region((long)regionH); /* try to build palettized form */
    return(regionH);

} /* TUTORload_region */

/* ******************************************************************* */

static long TUTORload_region_bmp(fileH) 
Memh fileH; /* handle on file data */
/* returns +n = region id */
/*         -1 = no file */
/*         -2 = no memory */
/*         -3 = no data */

{   Memh headerH; /* handle on region header */
    struct saved_region FAR *headerP; /* pointer to region header */
    unsigned char FAR *dibP; /* pointer to actual image */
    LPBITMAPINFO biP; /* pointer to image header */
    int nDIBColor;

    /* allocate memory for header */
    
    headerH = TUTORhandle("region",(long)sizeof(struct saved_region),TRUE);
    if (!headerH) {
	TUTORfree_handle(fileH);
	return(-2); /* can't create header */
    }
   TUTORpurge_info(headerH,M_WORM,FARNULL,0);
   AllowHandlePurge(headerH);
        
    /* set up header */

    headerP = (struct saved_region FAR *)GetPtr(headerH);
    TUTORzero((char FAR *)headerP,(long)sizeof(struct saved_region));
    headerP->format = 1;
    headerP->bmapH = (long)NULL;
    nDIBColor = CountDIBColors(fileH);
    if ((nDIBColor > 0) && (nDIBColor <= 256))
	headerP->paldibH = fileH;
    else
	headerP->rgbdibH = fileH;
    dibP = GetPtr(fileH); /* get pointer to DIB data */
    biP = (LPBITMAPINFO)(dibP+sizeof(BITMAPFILEHEADER));
    headerP->width = (int)biP->bmiHeader.biWidth;
    headerP->height =(int)biP->bmiHeader.biHeight;

    ReleasePtr(fileH);
    ReleasePtr(headerH);
        
    return(headerH);

} /* TUTORload_region_bmp */

/* ******************************************************************* */

int TUTORfile_region(fRef,regionID)
FileRef FAR *fRef; /* file to write to */
long regionID; /* region to write to file */

{   Memh headerH; /* handle on region header */
    struct saved_region FAR *headerP; /* pointer to region header */
    Memh dibH; /* handle on DIB bitmap */
    char FAR *dibP; /* pointer to DIB data */
    long dibSize; /* size of DIB data */
    int fIndx; /* index of file */
    long nWrote; /* number bytes written to file */
    int sL; /* index in file name */

    /* convert bitmap to Device Independant Bitmap if neccessary */

    win_convert_region(regionID);

    /* determine if DIB or PPM format */

    sL = strlenf(fRef->path);
    if (sL > 4) {
    sL -= 4; /* possible extension at end of file name */
    if ((strcmpf(fRef->path+sL,".ppm") == 0) ||
        (strcmpf(fRef->path+sL,".PPM") == 0))
        return(TUTORfile_region_ppm(fRef,regionID));
    }

    headerH = (Memh)regionID;
    headerP = (struct saved_region FAR *)GetPtr(headerH);
    dibH = headerP->rgbdibH; /* pick up handle on rgb DIB */
    if (!dibH)
	dibH = headerP->paldibH;
    ReleasePtr(headerH);

    if (!dibH)
	return(FALSE); /* no data to write */

    /* open and write file */

    fIndx = TUTORopen(fRef,FALSE,TRUE,FALSE);
    if (!fIndx)
	return(FALSE);
    dibSize = TUTORget_hsize(dibH);
    dibP = GetPtr(dibH);  /* pointer to dib contents */
    nWrote = TUTORwrite(dibP,sizeof(char),dibSize,fIndx);
    ReleasePtr(dibH);
    TUTORclose(fIndx);

    return(nWrote == dibSize);

} /* TUTORfile_region */

/* ******************************************************************* */

static int CountDIBColors(dibH) /* return size of DIB color table */
Memh dibH;

{   char FAR *dibP; /* pointer to DIB bitmap */
    LPBITMAPINFO biP; /* pointer to DIB bitmap header */
    DWORD dwNumColors; /* number colors in DIB */
    WORD wBitCount; /* bits/pixel in DIB */

    dibP = GetPtr(dibH); /* get pointer to DIB data */
    biP = (LPBITMAPINFO)(dibP+sizeof(BITMAPFILEHEADER));
    dwNumColors = 0;
	wBitCount = biP->bmiHeader.biBitCount;
    if (biP->bmiHeader.biSize >= 36)
		dwNumColors = biP->bmiHeader.biClrUsed;
    if (dwNumColors == 0) {
		if (wBitCount != 24)
	    	dwNumColors = 1L << wBitCount;
    } /* dwNumColors if */
    ReleasePtr(dibH);
    return((int)dwNumColors);

} /* CountDIBColors */

/* ******************************************************************* */

int win_palettize_region(regionID)
long regionID;

{   Memh headerH; /* handle on region header info */
    struct saved_region FAR *headerP; /* pointer to saved region header */
    Memh newH; /* handle on new region header */
    struct saved_region FAR *newP; /* pointer to region header */
    Memh nativePalH; /* handle on image palette */
    struct CTcolorentry FAR *palP; /* pointer to image palette */
    int width,height;
    int format; /* 0 = screen bitmap, 1 = dib */
    int havePal; /* TRUE if already have palettized form */
    Memh palDataH; /* handle on palettized data */
    Memh dibH; /* handle on DIB */
    char FAR *dibP; /* pointer to DIB */
    LPBITMAPINFO biP; /* pointer to DIB header */
    DWORD dwNumColors; /* number colors in DIB */
    DWORD dwColorTableSize; /* size of color table in DIB */
    WORD wBitCount; /* bits/pixel in DIB */
    BYTE SHUGE *lpDibBits; /* pointer to actual DIB bits */

    if (!regionID)
	return(0); /* nothing to do */

    havePal = FALSE; /* don't know if have palettized form yet */
    headerH = (Memh)regionID;
    headerP = (struct saved_region FAR *)GetPtr(headerH);
    format = headerP->format; /* pick up type of image */
    nativePalH = headerP->nativePal; /* pick up image palette */
    palDataH = headerP->palDataH; /* handle on palettized data */
    dibH = headerP->paldibH; /* pick up handle on palettized DIB */
    if (dibH)
	havePal = TRUE;
    else
	dibH = headerP->rgbdibH; /* pick up handle on rgb DIB */
    ReleasePtr(headerH);

    if (format == 0)
	return(0);  /* don't convert if native screen format */

    if (havePal) { /* have palettized DIB */
	if (!palDataH)
	    extract_pal_data(regionID);
    }

    dibP = GetPtr(dibH); /* get pointer to DIB data */
    biP = (LPBITMAPINFO)(dibP+sizeof(BITMAPFILEHEADER));

    /* get width, height and bits/pixel */
          
    width = (int)biP->bmiHeader.biWidth;
    height = (int)biP->bmiHeader.biHeight;
    wBitCount = biP->bmiHeader.biBitCount;
    if (wBitCount <= 8) {
	if (!nativePalH) {

	    /* extract palette from image */

	    nativePalH = TUTORalloc_palette(256);
	    if (!nativePalH)
		return(0); /* no memory ? */
	    palP = (struct CTcolorentry FAR *)GetPtr(nativePalH);
	    extract_palette_from_dib(dibP,palP);
	    ReleasePtr(nativePalH);
	    headerP = (struct saved_region FAR *)GetPtr(headerH);
	    headerP->nativePal = nativePalH;
	    ReleasePtr(headerH);
	}
	ReleasePtr(dibH);
	return(0); /* no further conversion needed */
    }

    dwNumColors = CountDIBColors(dibH);
    dwColorTableSize = dwNumColors*sizeof(RGBQUAD);
        
    /* compute location of actual DIB bits */
            
    lpDibBits = ((unsigned char SHUGE *)(biP))+biP->bmiHeader.biSize+dwColorTableSize;

    /* build a new region in palettized form */

    newH = (Memh)TUTORmem_to_region_pal(3,width,height,nativePalH,lpDibBits);
    ReleasePtr(dibH);
    if (!newH)
	return(0);

    newP = (struct saved_region FAR *)GetPtr(newH);
    headerP = (struct saved_region FAR *)GetPtr(headerH);
    headerP->paldibH = newP->paldibH; /* set new palettized dib */
    newP->paldibH = HNULL; /* so free_region won't destroy this */
    ReleasePtr(newH);
    ReleasePtr(headerH);

    TUTORfree_region(newH); /* release temporary region */
    return(1);

} /* win_palettize_region */

/* ******************************************************************* */

int win_adapt_region(regionID)
long regionID;

{   Memh headerH; /* handle on region header info */
    struct saved_region FAR *headerP; /* pointer to saved region header */
    Memh nativePalH; /* handle on native palette */
    struct CTcolorentry FAR *nativePalP; /* pointer to native palette */
    Memh imagePalH; /* handle on image (ordered for pixels) palette */
    struct CTcolorentry FAR *imagePalP; /* pointer to image palette */
    Memh currentPalH; /* handle on current cT palette */
    struct CTcolorentry FAR *currentPalP; /* pointer to current palette */
    Memh activePalH; /* handle on active (ordered for pixels) palette */
    struct CTcolorentry FAR *activePalP; /* pointer to active palette */
    Memh palettizedData; /* handle on palettized pixel data */
    int width,height; /* image width, height */
    int format; /* 0 = screen bitmap, 1 = dib */
    int refCnt; /* palette reference count */
    int pii,pjj; /* indexes in palettes */
    int rowI,colI; /* indexes in pixels */
    int rr,gg,bb; /* color components */
    Memh dibH; /* handle on DIB */
    char FAR *dibP; /* pointer to DIB */
    LPBITMAPINFO biP; /* pointer to DIB header */
    DWORD dwNumColors; /* number colors in DIB */
    DWORD dwColorTableSize; /* size of color table in DIB */
    WORD wBitCount; /* bits/pixel in DIB */
    LPRGBQUAD rgbP; /* pointer to DIB color table */
    BYTE SHUGE *lpDibBits; /* pointer to actual DIB bits */
    int bytesRow; /* bytes/row in DIB */
    int tDiff;
    int cDiff; /* difference between colors */
    int nDiff; /* number of colors that differ between palettes */
    unsigned char SHUGE *inP; /* input pointer */
    unsigned char SHUGE *outP; /* output pointer */
    unsigned char lookupTab[256]; /* pixel conversion table */

    if (!regionID || (CurrentWindow < 0))
	return(0); /* nothing to do */

    /* extract info from region header */

    headerH = (Memh)regionID;
    headerP = (struct saved_region FAR *)GetPtr(headerH);
    format = headerP->format;
    nativePalH = headerP->nativePal;
    width = headerP->width;
    height = headerP->height;
    refCnt = headerP->palpixRef;
    dibH = headerP->paldibH;
    palettizedData = headerP->palDataH;
    ReleasePtr(headerH);
    if ((format != 1) || (!nativePalH) || (refCnt == paletteRef) ||
	(!dibH) || (!palettizedData))
	return(0);

    /* make reordered copies of image and installed palettes */
    /* new palettes are in actual pixel order, not cT order */

    imagePalH = TUTORalloc_palette(256);
    activePalH = TUTORalloc_palette(256);
    if (!imagePalH || !activePalH)
	return(0);
    currentPalH = windowsP[CurrentWindow].paletteH;
    if (!currentPalH)
	currentPalH = defaultPalette;
    currentPalP = (struct CTcolorentry FAR *)GetPtr(currentPalH);
    activePalP = (struct CTcolorentry FAR *)GetPtr(activePalH);
    nativePalP = (struct CTcolorentry FAR *)GetPtr(nativePalH);
    imagePalP = (struct CTcolorentry FAR *)GetPtr(imagePalH);
    for(pii=0; pii<256; pii++) {
	pjj = (int)((nativePalP+pii)->realV);
	if (pjj < 0) pjj = pii;
	*(imagePalP+pjj) = *(nativePalP+pii);
	(imagePalP+pjj)->realV = pjj;
	pjj = (int)((currentPalP+pii)->realV);
	if (pjj < 0) pjj = pii;
	*(activePalP+pjj) = *(currentPalP+pii);
	(activePalP+pjj)->realV = pjj;
    }

    /* check if palettes are nearly the same */

    nDiff = 0;
    for(pii=0; pii<256; pii++) {
	tDiff = ((imagePalP+pii)->red >> 8)-((activePalP+pii)->red >> 8);
	if (tDiff < 0) tDiff = -tDiff;
	cDiff = tDiff;
	tDiff = ((imagePalP+pii)->green >> 8)-((activePalP+pii)->green >> 8);
	if (tDiff < 0) tDiff = -tDiff;
	cDiff += tDiff;
	tDiff = ((imagePalP+pii)->blue >> 8)-((activePalP+pii)->blue >> 8);
	if (tDiff < 0) tDiff = -tDiff;
	cDiff += tDiff;
	if (cDiff)
	    nDiff++;
    }

    ReleasePtr(nativePalH);
    ReleasePtr(currentPalH);

    if (nDiff < 20) { /* allow 20 different colors (windows reserved?) */
	headerP = (struct saved_region FAR *)GetPtr(headerH);
	headerP->palpixRef = paletteRef;
	ReleasePtr(headerH);
	return(0); /* exit happy */
    }

    /* convert to 8-bit format if not already 8-bit */
    /* we palettize to a 256 color palette - must have */
    /* 8-bit pixels */

    dibP = GetPtr(dibH); /* get pointer to DIB data */
    biP = (LPBITMAPINFO)(dibP+sizeof(BITMAPFILEHEADER));
    wBitCount = biP->bmiHeader.biBitCount;
    ReleasePtr(dibH);
    if (wBitCount != 8) {
	dibH = build_8bit_dib(width,height,imagePalH);
	if (dibH) {
	    headerP = (struct saved_region FAR *)GetPtr(headerH);
	    TUTORfree_handle(headerP->paldibH); /* release old DIB */
	    headerP->paldibH = dibH; /* attach new DIB */
	    ReleasePtr(headerH);
	}
    }
    if (!dibH) {
	ReleasePtr(activePalH);
	ReleasePtr(imagePalH);
	TUTORfree_palette(activePalH);
	TUTORfree_palette(imagePalH);
	return(HNULL);
    }

    /* build pixel conversion table */

    for(pii=0; pii<256; pii++) {
	rr = (imagePalP+pii)->red;
	gg = (imagePalP+pii)->green;
	bb = (imagePalP+pii)->blue;
	lookupTab[pii] = PaletteMatch(activePalP,256,rr,gg,bb);
    }
    ReleasePtr(imagePalH);
    TUTORfree_palette(imagePalH);

    /* extract info from DIB header */

    dibP = GetPtr(dibH); /* get pointer to DIB data */
    biP = (LPBITMAPINFO)(dibP+sizeof(BITMAPFILEHEADER));
    dwNumColors = CountDIBColors(dibH);
    dwColorTableSize = dwNumColors*sizeof(RGBQUAD);
    lpDibBits = ((unsigned char SHUGE *)(biP))+biP->bmiHeader.biSize+dwColorTableSize;

    /* convert pixels */

    bytesRow = ((width+3) >> 2) << 2;
    inP = (unsigned char SHUGE *)GetPtr(palettizedData);
    for(rowI=height-1; rowI>=0; rowI--) {
	outP = lpDibBits+((long)rowI*(long)bytesRow);
	for(colI=0; colI<width; colI++) {
	    *outP++ = lookupTab[*inP++];
	} /* colI for */
    } /* rowI for */
    ReleasePtr(palettizedData);

    /* update DIB color table */

    rgbP = (LPRGBQUAD)(dibP+sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER));
    for(pii=0; pii<(int)dwNumColors; pii++) {
		(rgbP+pii)->rgbRed = (BYTE)((activePalP+pii)->red >> 8);
		(rgbP+pii)->rgbGreen = (BYTE)((activePalP+pii)->green >> 8);
		(rgbP+pii)->rgbBlue = (BYTE)((activePalP+pii)->blue >> 8);
    }

    ReleasePtr(activePalH);
    TUTORfree_palette(activePalH);

    ReleasePtr(dibH);

    /* update header for current palette */

    headerP = (struct saved_region FAR *)GetPtr(headerH);
    headerP->palpixRef = paletteRef;
    ReleasePtr(headerH);

    return((Memh)regionID);

} /* win_adapt_region */

/* ******************************************************************* */

static int extract_pal_data(regionID)
long regionID;

{   Memh headerH; /* handle on region header info */
    struct saved_region FAR *headerP; /* pointer to saved region header */
    Memh dibH; /* handle on palettized DIB */
    Memh palDataH; /* handle on palettized data */
    int width,height; /* width, height of image */
    char FAR *dibP; /* pointer to DIB bitmap */
    LPBITMAPINFO biP; /* pointer to DIB bitmap header */
    DWORD dwNumColors; /* number colors in DIB */
    DWORD dwColorTableSize; /* size of color table in DIB */
    WORD wBitCount; /* bits/pixel in DIB */
    BYTE SHUGE *lpDibBits; /* pointer to actuall DIB bits */
    int rowI,colI; /* row, column index in pixels */
    int rowBytes; /* bytes per row in DIB */
    unsigned char SHUGE *fromP;
    unsigned char SHUGE *toP;
    int nybble;

    /* get info from header */

    headerH = (Memh)regionID;
    headerP = (struct saved_region FAR *)GetPtr(headerH);
    width = headerP->width;
    height = headerP->height;
    palDataH = headerP->palDataH;
    dibH = headerP->paldibH;
    ReleasePtr(headerH);
    if (palDataH)
	return(0); /* nothing to do - already have palettized data */
    if (!dibH)
	return(0); /* nothing to work with */
    dwNumColors = CountDIBColors(dibH);
    if (dwNumColors > 256)
	return(0); /* palette too big */

    palDataH = TUTORhandle("pal",(long)width*(long)height,TRUE);
    if (!palDataH)
	return(0); /* can't get memory  */
    TUTORpurge_info(palDataH,M_WORM,FARNULL,0);
    AllowHandlePurge(palDataH);

    /* get info from DIB header */

    dibP = GetPtr(dibH); /* get pointer to DIB data */
    biP = (LPBITMAPINFO)(dibP+sizeof(BITMAPFILEHEADER));
    wBitCount = biP->bmiHeader.biBitCount;
    dwColorTableSize = dwNumColors*sizeof(RGBQUAD);
        
    /* compute location of actual DIB bits */
            
    lpDibBits = ((unsigned char SHUGE *)(biP))+biP->bmiHeader.biSize+dwColorTableSize;

    /* transfer pixels from DIB to logical array */

    toP = GetPtr(palDataH);
    if (wBitCount == 8) {
	rowBytes = (int)(((width+3L) >> 2) << 2); /* multiple of 32 bits */
	for(rowI=(height-1); rowI>=0; rowI--) {
	    fromP = lpDibBits+(long)rowI*(long)rowBytes;
	    for(colI=0; colI<width; colI++) {
	       *toP++ = *fromP++;
	    }
	} /* for */
    } else if (wBitCount == 4) {
	rowBytes = (int)((((width >> 1)+3L) >> 2) << 2); /* multiple of 32 bits */
	nybble = 0;
	for(rowI=(height-1); rowI>=0; rowI--) {
	    fromP = lpDibBits+(long)rowI*(long)rowBytes;
	    for(colI=0; colI<width; colI++) {
		if (nybble) {
		    *toP++ = (*fromP++) & 0xf;
		    nybble = 0;
		} else {
		    *toP++ = (*fromP >> 4) & 0xf;
		    nybble = 1;
		} /* nybble */
	    } /* for */
	} /* for */
    } else if (wBitCount == 1) {
	rowBytes = (int)((((width >> 3)+3L) >> 2) << 2); /* multiple of 32 bits */
	nybble = 0;
	for(rowI=(height-1); rowI>=0; rowI--) {
	    fromP = lpDibBits+(long)rowI*(long)rowBytes;
	    for(colI=0; colI<width; colI++) {
		*toP++ = ((*fromP) >> (7-nybble)) & 1;
		nybble++;
		if (nybble == 8) {
		    nybble = 0;
		    fromP++;
		}
	    } /* for */
	} /* for */
    }
    ReleasePtr(palDataH);
    ReleasePtr(dibH);

    /* attach data to header */

    headerP = (struct saved_region FAR *)GetPtr(headerH);
    headerP->palDataH = palDataH;
    ReleasePtr(headerH);

    return(1);

} /* extract_pal_data */

/* ******************************************************************* */

/* convert bitmap region to DIB */

Memh win_convert_region(regionID)
long regionID; /* region to convert */

{   Memh headerH; /* handle on region header */
    struct saved_region FAR *headerP; /* pointer to region header */
    int format; /* format of saved region */
    HBITMAP bmpH; /* handle on saved region bitmap */
    HANDLE wBitHdr; /* handle on DIB bitmap data */
    long wBitHdrSize; /* size of DIB bitmap data */
    LPBITMAPINFOHEADER wBitHdrP; /* pointer to bitmap header */
    LPBITMAPFILEHEADER wFileHdrP; /* pointer to file header */
    Memh dibH; /* handle on DIB bitmap */
    char FAR *dibP; /* pointer to DIB data */
    long dibSize; /* size of DIB data */
    HPALETTE wPalH; /* handle on Windows palette */

    headerH = (Memh)regionID;
    headerP = (struct saved_region FAR *)GetPtr(headerH);
    format = headerP->format; /* pick up type of image */
    bmpH = (HBITMAP)headerP->bmapH; /* pick up handle on screen bitmap */
    dibH = headerP->paldibH; /* pick up handle on DIB bitmap */
    if (!dibH)
	dibH = headerP->rgbdibH;
    ReleasePtr(headerH);

    if (format == 1) { /* already in DIB format */
	return(dibH);
    } /* format if */

    /* convert the bitmap */

    wPalH = (HPALETTE)windowsP[CurrentWindow].winPalH; /* pick up current palette */
    wBitHdr = BitmapToDIB(bmpH,wPalH);
    if (!wBitHdr)
	return(0);

    /* create cT handle for DIB */

    wBitHdrSize = GlobalSize(wBitHdr);
    dibSize = wBitHdrSize+sizeof(BITMAPFILEHEADER);
    dibH = TUTORhandle("image",dibSize,TRUE);
    if (!dibH) return(0);
    TUTORpurge_info(dibH,M_WORM,FARNULL,0);
    AllowHandlePurge(dibH);

    /* assemble BITMAPFILEHEADER, BITMAPINFOHEADER etc */

    dibP = GetPtr(dibH);
    TUTORzero(dibP,(long)sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER));
    wBitHdrP = GlobalLock(wBitHdr);
    TUTORblock_move((char FAR *)wBitHdrP,dibP+sizeof(BITMAPFILEHEADER),
            wBitHdrSize);
    wFileHdrP = (LPBITMAPFILEHEADER)dibP;
    *dibP = 'B';
    *(dibP+1) = 'M';
    wFileHdrP->bfSize = dibSize; /* total size of file */
    wFileHdrP->bfOffBits = sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);
    GlobalUnlock(wBitHdr);
    ReleasePtr(dibH);

    /* change region format */

    headerP = (struct saved_region FAR *)GetPtr(headerH);
    headerP->format = 1; /* change type of image */
    headerP->bmapH = 0; /* no screen bitmap */
    headerP->rgbdibH = dibH; /* handle on DIB bitmap */
    ReleasePtr(headerH);

    DeleteObject(bmpH); /* discard bitmap */

    return(dibH);

} /* win_convert_region */

/* ******************************************************************* */


#define IS_WIN30_DIB(lpbi)  ((*(LPDWORD)(lpbi)) == sizeof(BITMAPINFOHEADER))
#define WIDTHBYTES(bits)    (((bits) + 31) / 32 * 4)

/*************************************************************************
 *
 * BitmapToDIB()
 *
 * Parameters:
 *
 * HBITMAP hBitmap  - specifies the bitmap to convert
 *
 * HPALETTE hPal    - specifies the palette to use with the bitmap
 *
 * Return Value:
 *
 * HANDLE          - identifies the device-dependent bitmap
 *
 * Description:
 *
 * This function creates a DIB from a bitmap using the specified palette.
 *
 * History:   Date      Author               Reason
 *            6/01/91   Garrett McAuliffe    Created
 *            9/15/91   Patrick Schreiber    Added header and comments
 *            12/10/91  Patrick Schreiber    Added bits per pixel validation
 *                                           and check GetObject return value
 *
 ************************************************************************/

static HANDLE FAR BitmapToDIB(hBitmap,hPal)
HBITMAP hBitmap;
HPALETTE hPal;

{  BITMAP bm;            // bitmap structure
   BITMAPINFOHEADER bi;         // bitmap header
   BITMAPINFOHEADER FAR *lpbi;  // pointer to BITMAPINFOHEADER
   DWORD dwLen;                 // size of memory block
   HANDLE hDIB, h;              // handle to DIB, temp handle
   HDC hDC;                     // handle to DC
   WORD biBits;                 // bits per pixel

   /* check if bitmap handle is valid */

   if (!hBitmap)
      return NULL;

   /* fill in BITMAP structure, return NULL if it didn't work */
   if (!GetObject(hBitmap, sizeof(bm), (LPSTR)&bm))
      return NULL;

   /* if no palette is specified, use default palette */
   if (hPal == NULL)
      hPal = GetStockObject(DEFAULT_PALETTE);

   /* calculate bits per pixel */
   biBits = bm.bmPlanes * bm.bmBitsPixel;

   /* make sure bits per pixel is valid */

   if (biBits <= 8)
      biBits = 8;
   else /* if greater than 8-bit, force to 24-bit */
      biBits = 24;
   biBits = 24; /* always 24 bit */
   /* initialize BITMAPINFOHEADER */
   bi.biSize = sizeof(BITMAPINFOHEADER);
   bi.biWidth = bm.bmWidth;
   bi.biHeight = bm.bmHeight;
   bi.biPlanes = 1;
   bi.biBitCount = biBits;
   bi.biCompression = BI_RGB;
   bi.biSizeImage = 0;
   bi.biXPelsPerMeter = 0;
   bi.biYPelsPerMeter = 0;
   bi.biClrUsed = 0;
   bi.biClrImportant = 0;

   /* calculate size of memory block required to store BITMAPINFO */
   dwLen = bi.biSize + PaletteBytes((LPSTR)&bi);

   /* get a DC */
   hDC = cTGetDC(NULL);

   /* select and realize our palette */
   hPal = SelectPalette(hDC, hPal, FALSE);
   RealizePalette(hDC);

   /* alloc memory block to store our bitmap */
   hDIB = GlobalAlloc(GHND, dwLen);

   /* if we couldn't get memory block */
   if (!hDIB)
   {
      /* clean up and return NULL */
      SelectPalette(hDC, hPal, TRUE);
      RealizePalette(hDC);
      cTReleaseDC(NULL, hDC);
      return NULL;
   }

   /* lock memory and get pointer to it */
   lpbi = (VOID FAR *)GlobalLock(hDIB);

   /* use our bitmap info. to fill BITMAPINFOHEADER */
   *lpbi = bi;

   /*  call GetDIBits with a NULL lpBits param, so it will calculate the
    *  biSizeImage field for us
    */
   GetDIBits(hDC, hBitmap, 0, (WORD)bi.biHeight, NULL, (LPBITMAPINFO)lpbi,
         DIB_RGB_COLORS);

   /* get the info. returned by GetDIBits and unlock memory block */
   bi = *lpbi;
   GlobalUnlock(hDIB);

   /* if the driver did not fill in the biSizeImage field, make one up */
   if (bi.biSizeImage == 0)
      bi.biSizeImage = WIDTHBYTES((DWORD)bm.bmWidth * biBits) * bm.bmHeight;

   /* realloc the buffer big enough to hold all the bits */
   dwLen = bi.biSize + PaletteBytes((LPSTR)&bi) + bi.biSizeImage;
   if (h = GlobalReAlloc(hDIB, dwLen, 0))
      hDIB = h;
   else
   {
      /* clean up and return NULL */
      GlobalFree(hDIB);
      hDIB = NULL;
      SelectPalette(hDC, hPal, TRUE);
      RealizePalette(hDC);
      cTReleaseDC(NULL, hDC);
      return NULL;
   }

   /* lock memory block and get pointer to it */
   lpbi = (VOID FAR *)GlobalLock(hDIB);

   /*  call GetDIBits with a NON-NULL lpBits param, and actualy get the
    *  bits this time
    */
   if (GetDIBits(hDC, hBitmap, 0, (WORD)bi.biHeight, (LPSTR)lpbi + (WORD)lpbi
     ->biSize + PaletteBytes((LPSTR)lpbi), (LPBITMAPINFO)lpbi,
         DIB_RGB_COLORS) == 0)
   {
      /* clean up and return NULL */
      GlobalUnlock(hDIB);
      hDIB = NULL;
      SelectPalette(hDC, hPal, TRUE);
      RealizePalette(hDC);
      cTReleaseDC(NULL, hDC);
      return NULL;
   }
   bi = *lpbi;

   /* clean up */
   GlobalUnlock(hDIB);
   SelectPalette(hDC, hPal, TRUE);
   RealizePalette(hDC);
   cTReleaseDC(NULL, hDC);

   /* return handle to the DIB */
   return hDIB;
}

/*************************************************************************
 *
 * PaletteBytes()
 *
 * Parameter:
 *
 * LPSTR lpDIB      - pointer to packed-DIB memory block
 *
 * Return Value:
 *
 * WORD             - size of the color palette of the DIB
 *
 * Description:
 *
 * This function gets the size required to store the DIB's palette by
 * multiplying the number of colors by the size of an RGBQUAD (for a
 * Windows 3.0-style DIB) or by the size of an RGBTRIPLE (for an OS/2-
 * style DIB).
 *
 * History:   Date      Author             Reason
 *            6/01/91   Garrett McAuliffe  Created
 *            9/15/91   Patrick Schreiber  Added header and comments
 *
 ************************************************************************/

WORD FAR PaletteBytes(lpDIB)
LPSTR lpDIB;
{
   /* calculate the size required by the palette */
   if (IS_WIN30_DIB (lpDIB))
      return (DIBNumColors(lpDIB) * sizeof(RGBQUAD));
   else
      return (DIBNumColors(lpDIB) * sizeof(RGBTRIPLE));
}

/*************************************************************************
 *
 * DIBNumColors()
 *
 * Parameter:
 *
 * LPSTR lpDIB      - pointer to packed-DIB memory block
 *
 * Return Value:
 *
 * WORD             - number of colors in the color table
 *
 * Description:
 *
 * This function calculates the number of colors in the DIB's color table
 * by finding the bits per pixel for the DIB (whether Win3.0 or OS/2-style
 * DIB). If bits per pixel is 1: colors=2, if 4: colors=16, if 8: colors=256,
 * if 24, no colors in color table.
 *
 * History:   Date      Author               Reason
 *            6/01/91   Garrett McAuliffe    Created
 *            9/15/91   Patrick Schreiber    Added header and comments
 *
 ************************************************************************/


WORD FAR DIBNumColors(LPSTR lpDIB)
{
   WORD wBitCount;  // DIB bit count

   /*  If this is a Windows-style DIB, the number of colors in the
    *  color table can be less than the number of bits per pixel
    *  allows for (i.e. lpbi->biClrUsed can be set to some value).
    *  If this is the case, return the appropriate value.
    */

   if (IS_WIN30_DIB(lpDIB))
   {
      DWORD dwClrUsed;

      dwClrUsed = ((LPBITMAPINFOHEADER)lpDIB)->biClrUsed;
      if (dwClrUsed)
	 return (WORD)dwClrUsed;
   }

   /*  Calculate the number of colors in the color table based on
    *  the number of bits per pixel for the DIB.
    */
   if (IS_WIN30_DIB(lpDIB))
      wBitCount = ((LPBITMAPINFOHEADER)lpDIB)->biBitCount;
   else
      wBitCount = ((LPBITMAPCOREHEADER)lpDIB)->bcBitCount;

   /* return number of colors based on bits per pixel */
   switch (wBitCount)
      {
   case 1:
      return 2;

   case 4:
      return 16;

   case 8:
      return 256;

   default:
      return 0;
      }
}

/* ******************************************************************* */

long TUTORmem_to_region(type,width,height,inPalH,bP) /* convert array to image */
int type; /* input data type */
      /* 1 = 8-bit palettized */
      /* 2 = 3-byte r,g,b */
      /* 3 = native r,g,b */
int width; /* width of image in pixels */
int height; /* height of image in pixels */
Memh inPalH; /* palette to use for image */
unsigned char SHUGE *bP; /* pointer to input data */

{
    if (type == 1)
	return(TUTORmem_to_region_pal(type,width,height,inPalH,bP));
    return(TUTORmem_to_region_rgb(type,width,height,inPalH,bP));

} /* TUTORmem_to_region */

/* ******************************************************************* */

/* convert array to rgb image */

long TUTORmem_to_region_rgb(type,width,height,inPalH,bP)
int type; /* input data type */
      /* 1 = 8-bit palettized */
      /* 2 = 3-byte r,g,b */
      /* 3 = native r,g,b */
int width; /* width of image in pixels */
int height; /* height of image in pixels */
Memh inPalH; /* palette to use for image */
unsigned char SHUGE *bP; /* pointer to input data */

{   Memh headerH; /* handle on region header */
    struct saved_region FAR *headerP; /* pointer to region header */
    Memh dibH; /* handle on dib */
    Memh srcPalH; /* source palette for palettized data */
    int sizePixmap; /* bytes required for pixmap header */
    long sizeBits; /* bytes required for pixmap */
    long sizeH; /* size of cT handle */
    LPBITMAPFILEHEADER bFileP; /* pointer to dib file description */
    LPBITMAPINFOHEADER bInfoP; /* pointer to dib bitmap description */
    long relBits; /* relative location of bitmap */
    long InRowBytes; /* bytes per row in input data */
    long OutRowBytes; /* bytes per row in output pixmap */
    long InRowExtra; /* extra bytes required at end of input row */
    long OutRowExtra; /* extra bytes required at end of output row */
    long rowI; /* index in rows */
    long pixelI; /* index in pixels */
    int pixelV; /* current pixel value */
    unsigned char SHUGE *pixelsP; /* pointer to pixels */
    struct CTcolorentry FAR *palP; /* pointer in default palette */
    unsigned char SHUGE *cP;

    /* figure out row size and padding */

    if (type == 1) {
	InRowBytes = width;
	InRowExtra = 0; /* no pad in input */
    } else if (type == 2) {
	InRowBytes = width*3L;
	InRowExtra = 0; /* no pad in input */
    } else if (type == 3) {
	InRowBytes = width*3L; /* 3 bytes/pixel */
	InRowBytes = ((InRowBytes+3L) >> 2) << 2; /* multiple of 32 bits */
	InRowExtra = InRowBytes-(3L*width);
    }
    OutRowBytes = (((width*3)+3L) >> 2) << 2; /* multiple of 32 bits */
    OutRowExtra = OutRowBytes-(width*3L);

    /* get palette to use for palettized data */

    srcPalH = inPalH;
    if (!srcPalH) {
	srcPalH = windowsP[CurrentWindow].paletteH;
	if (!srcPalH) srcPalH = defaultPalette;
	if (!srcPalH)
	    return(0L);
    }

    /* set up cT handle for pixmap */

    sizePixmap = sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);
    sizeBits = OutRowBytes*height;
    sizeH = sizePixmap+sizeBits; /* total space */
    dibH = TUTORhandle("pixmap",sizeH,TRUE);
    if (!dibH)
        return(0L); /* couldn't get enough memory */
    TUTORpurge_info(dibH,M_WORM,FARNULL,0);
    AllowHandlePurge(dibH);
    cP = GetPtr(dibH);
    TUTORzero(cP,sizeH);
    bFileP = (LPBITMAPFILEHEADER)(cP);
    bInfoP = (LPBITMAPINFOHEADER)(cP+sizeof(BITMAPFILEHEADER)); /* ptr to dib */

    /* set up file header */

    *cP = 'B';
    *(cP+1) = 'M';
    bFileP->bfSize = sizeH; /* total size of file */
    bFileP->bfOffBits = sizePixmap;

    /* set up cT handle for header */
    
    headerH = TUTORhandle("region",(long)sizeof(struct saved_region),TRUE);
    if (!headerH) {
        ReleasePtr(dibH);
        TUTORfree_handle(dibH);
        return(0L); /* couldn't get enough memory */
    }
    TUTORpurge_info(headerH,M_WORM,FARNULL,0);
    AllowHandlePurge(headerH);

    headerP = (struct saved_region FAR *)GetPtr(headerH);
    TUTORzero((char FAR *)headerP,(long)sizeof(struct saved_region));
    headerP->format = 1; /* dib format */
    headerP->rgbdibH = dibH; /* handle on actual DIB data */
    headerP->width = width;
    headerP->height = height;
    ReleasePtr(headerH); /* done with header */
    
    /* build dib info header in cT handle */
    
    bInfoP->biSize = sizeof(BITMAPINFOHEADER); /* header size */
    bInfoP->biWidth = width; /* width of image in pixels */
    bInfoP->biHeight = height; /* height of image in pixels */
    bInfoP->biPlanes = 1; /* always 1 plane */
    bInfoP->biBitCount = 24; /* always 24 bits/pixel */
    bInfoP->biCompression = BI_RGB;
    bInfoP->biSizeImage = sizeBits;
    bInfoP->biClrUsed = 0;
    bInfoP->biClrImportant = 0;
    relBits = sizePixmap; /* relative location of pixels */
    
    pixelsP = cP+relBits;
    if (type == 1) { /* palette */
	palP = (struct CTcolorentry FAR *)GetPtr(srcPalH);
	for(rowI=0; rowI<height; rowI++) {
	    for(pixelI=0; pixelI<width; pixelI++) {
		pixelV = *bP++;
		*pixelsP++ = (int)((palP+pixelV)->red);
		*pixelsP++ = (int)((palP+pixelV)->green);
		*pixelsP++ = (int)((palP+pixelV)->blue);
	    } /* pixelI for */
	    pixelsP += OutRowExtra; /* advance to end of row */
	} /* rowI for */
	ReleasePtr(srcPalH);
    } else if ((type == 2) || (type == 3)) { /* array or native RGB */
	for(rowI=0; rowI<height; rowI++) {
	    for(pixelI=0; pixelI<width; pixelI++) {
		*pixelsP++ = *bP++;
		*pixelsP++ = *bP++;
		*pixelsP++ = *bP++;
	    } /* pixelI for */
	    bP += InRowExtra;
	    pixelsP += OutRowExtra; /* advance to end of row */
	} /* rowI for */
    } /* type else */

    if ((type == 1) || (type == 2)) {
	pixelsP = cP+relBits;
	invert_dib(pixelsP,(int)OutRowBytes,height);
    }
    ReleasePtr(dibH);

    return(headerH);

} /* TUTORmem_to_region_rgb */

/* ******************************************************************* */

/* convert array to palettized image */

long TUTORmem_to_region_pal(type,width,height,inPalH,bP)
int type; /* input data type */
	  /* 1 = 8-bit palettized */
	  /* 2 = 3-byte r,g,b */
	  /* 3 = native r,g,b */
int width; /* width of image in pixels */
int height; /* height of image in pixels */
Memh inPalH; /* palette to use for image */
unsigned char SHUGE *bP; /* pointer to r,g,b triplets */

{   Memh headerH; /* handle on region header */
    struct saved_region FAR *headerP; /* pointer to region header */
    Memh dibH; /* handle on dib */
    Memh srcPalH; /* palette to use */
    long sizeBits; /* bytes required for color bitmap */
    int sizePixmap; /* bytes required for pixmap header */
    long sizeH; /* size of cT handle */
    LPBITMAPFILEHEADER bFileP; /* pointer to dib file description */
    LPBITMAPINFOHEADER bInfoP; /* pointer to dib bitmap description */
    long relBits; /* relative location of bitmap */
    long InRowBytes; /* bytes per row in input pixmap */
    long OutRowBytes; /* bytes per row in output pixmap */
    long InRowExtra; /* extra bytes required at end of input row */
    long OutRowExtra; /* extra bytes required at end of output row */
    long rowI; /* index in rows */
    long pixelI; /* index in pixels */
    unsigned char SHUGE *pixelsP; /* pointer to pixels */
    struct CTcolorentry FAR *palP; /* pointer in default palette */
    LPRGBQUAD bColorP; /* pointer to dib's color table */
    LPRGBQUAD rgbP; /* pointer in dib's color table */
    long sizeColor; /* size of color table */
    int pixelV; /* pixel color value */
    unsigned char SHUGE *cP;

    /* figure out row size and padding */

    if (type == 1) {
	InRowBytes = width;
	InRowExtra = 0; /* no pad in input */
    } else if (type == 2) {
	InRowBytes = width*3L;
	InRowExtra = 0; /* no pad in input */
    } else if (type == 3) {
	InRowBytes = width*3L; /* 3 bytes/pixel */
	InRowBytes = ((InRowBytes+3L) >> 2) << 2; /* multiple of 32 bits */
	InRowExtra = InRowBytes-(3L*width);
    }
    OutRowBytes = ((width+3L) >> 2) << 2; /* multiple of 32 bits */
    OutRowExtra = OutRowBytes-width;

    /* get palette to use for palettized data */

    srcPalH = inPalH;
    if (!srcPalH) {
	srcPalH = windowsP[CurrentWindow].paletteH;
	if (!srcPalH) srcPalH = defaultPalette;
	if (!srcPalH)
	    return(0L);
    }

    sizeColor = 256*sizeof(RGBQUAD);
    sizePixmap = (int)(sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+sizeColor);
    sizeBits = OutRowBytes*height;
    sizeH = sizePixmap+sizeBits; /* total space */
    dibH = TUTORhandle("pixmap",sizeH,TRUE);
    if (!dibH)
        return(0L); /* couldn't get enough memory */
    TUTORpurge_info(dibH,M_WORM,FARNULL,0);
    AllowHandlePurge(dibH);
    cP = GetPtr(dibH);
    TUTORzero(cP,sizeH);
    bFileP = (LPBITMAPFILEHEADER)(cP);
    bInfoP = (LPBITMAPINFOHEADER)(cP+sizeof(BITMAPFILEHEADER)); /* ptr to dib */
    bColorP = (LPRGBQUAD)(cP+sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER));

    /* set up file header */

    *cP = 'B';
    *(cP+1) = 'M';
    bFileP->bfSize = sizeH; /* total size of file */
    bFileP->bfOffBits = sizePixmap;

    /* set up cT handle for header */
    
    headerH = TUTORhandle("region",(long)sizeof(struct saved_region),TRUE);
    if (!headerH) {
        ReleasePtr(dibH);
        TUTORfree_handle(dibH);
        return(0L); /* couldn't get enough memory */
    }
    TUTORpurge_info(headerH,M_WORM,FARNULL,0);
    AllowHandlePurge(headerH);

    headerP = (struct saved_region FAR *)GetPtr(headerH);
    TUTORzero((char FAR *)headerP,(long)sizeof(struct saved_region));
    headerP->format = 1; /* dib format */
    headerP->paldibH = dibH; /* handle on actual DIB data */
    headerP->width = width;
    headerP->height = height;
    ReleasePtr(headerH); /* done with header */
    
    /* build dib info header in cT handle */
    
    bInfoP->biSize = sizeof(BITMAPINFOHEADER); /* header size */
    bInfoP->biWidth = width; /* width of image in pixels */
    bInfoP->biHeight = height; /* height of image in pixels */
    bInfoP->biPlanes = 1; /* always 1 plane */
    bInfoP->biBitCount = 8; /* always 8 bits/pixel */
    bInfoP->biCompression = BI_RGB;
    bInfoP->biSizeImage = sizeBits;
    bInfoP->biClrUsed = 256; /* number colors in palette */
    bInfoP->biClrImportant = 256;
    relBits = sizePixmap; /* relative location of pixels */
    
    /* copy colors from palette */

    palP = (struct CTcolorentry FAR *)GetPtr(srcPalH);
    rgbP = bColorP; /* pointer in dib's color table */
    for(rowI=0; rowI<256; rowI++) {
	pixelV = (int)((palP+rowI)->realV);
	if (pixelV >= 0) {
	    (rgbP+pixelV)->rgbBlue = (int)((palP+rowI)->blue >> 8);
	    (rgbP+pixelV)->rgbGreen = (int)((palP+rowI)->green >> 8);
	    (rgbP+pixelV)->rgbRed = (int)((palP+rowI)->red >> 8);
	}
    }
    pixelsP = cP+relBits;
    if (type == 1) { /* palette */
	for(rowI=0; rowI<height; rowI++) {
	    for(pixelI=0; pixelI<width; pixelI++) {
		pixelV = *bP++;
		pixelV = (int)((palP+pixelV)->realV);
		*pixelsP++ = pixelV;
	    } /* pixelI for */
	    pixelsP += OutRowExtra; /* advance to end of row */
	} /* rowI for */
    } else if (type == 2) { /* array RGB */
	TUTORpalettize_rgb(1,bP,InRowBytes,pixelsP,OutRowBytes,srcPalH,width,height);
    } else if (type == 3) { /* native RGB */
	TUTORpalettize_rgb(2,bP,InRowBytes,pixelsP,OutRowBytes,srcPalH,width,height);
    } /* type else */
    ReleasePtr(srcPalH);

    if ((type == 1) || (type == 2)) {
	pixelsP = cP+relBits;
	invert_dib(pixelsP,(int)OutRowBytes,height);
    }
    ReleasePtr(dibH);
    return(headerH);

} /* TUTORmem_to_region_pal */

/* ******************************************************************* */

static Memh build_8bit_dib(width,height,palH)
int width; /* width of image in pixels */
int height; /* height of image in pixels */
Memh palH; /* palette (in pixel order, not cT order) */

{   Memh dibH; /* handle on dib */
    long sizeBits; /* bytes required for color bitmap */
    int sizePixmap; /* bytes required for pixmap header */
    long sizeH; /* size of cT handle */
    LPBITMAPFILEHEADER bFileP; /* pointer to dib file description */
    LPBITMAPINFOHEADER bInfoP; /* pointer to dib bitmap description */
    int rowBytes; /* bytes/row in DIB */
    long relBits; /* relative location of bitmap */
    struct CTcolorentry FAR *palP; /* pointer in palette */
    LPRGBQUAD bColorP; /* pointer to dib's color table */
    LPRGBQUAD rgbP; /* pointer in dib's color table */
    long sizeColor; /* size of color table */
    int cii; /* index in colors */
    unsigned char SHUGE *cP;

    rowBytes = (int)(((width+3L) >> 2) << 2); /* multiple of 32 bits */

    sizeColor = 256*sizeof(RGBQUAD);
    sizePixmap = (int)(sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+sizeColor);
    sizeBits = rowBytes*height;
    sizeH = sizePixmap+sizeBits; /* total space */
    dibH = TUTORhandle("pixmap",sizeH,TRUE);
    if (!dibH)
	return(HNULL); /* couldn't get enough memory */
    TUTORpurge_info(dibH,M_WORM,FARNULL,0);
    AllowHandlePurge(dibH);

    /* set up file header */

    cP = GetPtr(dibH);
    TUTORzero(cP,sizeH);
    bFileP = (LPBITMAPFILEHEADER)(cP);
    bInfoP = (LPBITMAPINFOHEADER)(cP+sizeof(BITMAPFILEHEADER)); /* ptr to dib */
    bColorP = (LPRGBQUAD)(cP+sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER));
    *cP = 'B';
    *(cP+1) = 'M';
    bFileP->bfSize = sizeH; /* total size of file */
    bFileP->bfOffBits = sizePixmap;
    
    /* build dib info header in cT handle */
    
    bInfoP->biSize = sizeof(BITMAPINFOHEADER); /* header size */
    bInfoP->biWidth = width; /* width of image in pixels */
    bInfoP->biHeight = height; /* height of image in pixels */
    bInfoP->biPlanes = 1; /* always 1 plane */
    bInfoP->biBitCount = 8; /* always 8 bits/pixel */
    bInfoP->biCompression = BI_RGB;
    bInfoP->biSizeImage = sizeBits;
    bInfoP->biClrUsed = 256; /* number colors in palette */
    bInfoP->biClrImportant = 256;
    relBits = sizePixmap; /* relative location of pixels */
    
    /* copy colors from palette */

    palP = (struct CTcolorentry FAR *)GetPtr(palH);
    rgbP = bColorP; /* pointer in dib's color table */
    for(cii=0; cii<256; cii++) {
	(rgbP+cii)->rgbBlue = (int)((palP+cii)->blue >> 8);
	(rgbP+cii)->rgbGreen = (int)((palP+cii)->green >> 8);
	(rgbP+cii)->rgbRed = (int)((palP+cii)->red >> 8);
    }
    ReleasePtr(palH);
    ReleasePtr(dibH);
    return(dibH);

} /* build_8bit_dib */

/* ******************************************************************* */

int invert_dib(pixelsP,bytesRow,nRows) /* invert dib image */
unsigned char SHUGE *pixelsP; /* pointer to pixels */
int bytesRow; /* width of row */
int nRows; /* number rows in image */

/* DIB images are stored upside down - bottom pixels at begin of pixmap */

{   int rowI; /* index of row */
    int pixelI; /* index within row */
    unsigned char SHUGE *pfwdP; /* forward pointer in pixels */
    unsigned char SHUGE *pbackP; /* backward pointer in pixels */
    long cmp1,cmp2; /* for pointer compare */
    int swap;

    if (nRows <= 1) return(0); /* nothing to do */
    nRows >> 1;
    pfwdP = pixelsP;

    for(rowI=0; rowI<nRows; rowI++) {
	pbackP = pixelsP+((long)nRows-rowI-1L)*bytesRow;
	cmp1 = (long)pfwdP;
	cmp2 = (long)pbackP;
	if (cmp2 <= cmp1)
	    break; /* exit for */
	for(pixelI=0; pixelI<bytesRow; pixelI++) {
	    swap = *pbackP;
	    *pbackP = *pfwdP;
	    *pfwdP = swap;
	    pfwdP++;
	    pbackP++;
	} /* pixelI for */
    } /* rowI for */
    return(0);

} /* invert_dib */

/* ******************************************************************* */

long TUTORcopy_region(srcH) /* make copy of saved region */
long srcH; /* region to copy */

{   struct saved_region FAR *srcP; /* pointer to source region header */
    Memh hdrH; /* handle on region header */
    struct saved_region FAR *hdrP; /* pointer to region header */

    if (!srcH)
	return(0L); /* nothing to do */

    win_convert_region(srcH);
    hdrH = TUTORcopy_handle((Memh)srcH);
    if (!hdrH)
	return(0L); /* no memory */

    srcP = (struct saved_region FAR *)GetPtr((Memh)srcH);
    if (srcP->format != 1) { /* don't understand format */
	ReleasePtr((Memh)srcH);
	return(0L);
    }
    hdrP = (struct saved_region FAR *)GetPtr(hdrH);
    hdrP->palpixRef = 0;
    if (srcP->rgbdibH) {
	hdrP->rgbdibH = TUTORcopy_handle(srcP->rgbdibH); /* copy actual DIB data */
	if (hdrP->rgbdibH) {
	    TUTORpurge_info(hdrP->rgbdibH,M_WORM,FARNULL,0);
	    AllowHandlePurge(hdrP->rgbdibH);
	}
    } /* hdrP->rgbdibH if */
    if (srcP->paldibH) {
	hdrP->paldibH = TUTORcopy_handle(srcP->paldibH); /* copy actual DIB data */
	if (hdrP->paldibH) {
	    TUTORpurge_info(hdrP->paldibH,M_WORM,FARNULL,0);
	    AllowHandlePurge(hdrP->paldibH);
	}
    } /* hdrP->paldibH if */

    if (srcP->palDataH)
	hdrP->palDataH = TUTORcopy_handle(srcP->palDataH);
    if (srcP->rgbDataH)
	srcP->rgbDataH = TUTORcopy_handle(srcP->rgbDataH);
    if (srcP->nativePal)
	hdrP->nativePal = TUTORcopy_handle(srcP->nativePal);
    ReleasePtr(hdrH);
    ReleasePtr((Memh)srcH);
    return(hdrH);

} /* TUTORcopy_region */

/* ******************************************************************* */

Memh TUTORget_rgb_region(regionID) /* extract r,g,b pixels from region */
long regionID; /* handle on region */

{   Memh headerH; /* handle on pixmap header */
    struct saved_region FAR *headerP; /* pointer to header */
    Memh dibH; /* handle on windows DIB */
    LPBITMAPINFOHEADER bInfoP; /* ptr to DIB bitmap description */
    LPRGBQUAD bColorP; /* pointer to dib's color table */
    long sizeColor; /* size of dib color table */
    long width,height; /* width,height of pixmap */
    long inBytesRow; /* bytes per row in input image */
    int bitsPixel; /* bits per pixel */
    int rowExtra; /* extra bytes at end of row */
    long rowI; /* index of current row */
    long pixelI; /* index of current pixel */
    long hSize;
    unsigned char SHUGE *pixBaseP; /* base of pixels */
    unsigned char SHUGE *rowBaseP; /* pointer to base of row */
    unsigned char SHUGE *pixelP; /* pointer to current pixel */
    long buffSize; /* size of temporary buffer */
    Memh buffH; /* handle on temporary buffer */
    unsigned char SHUGE *buffP; /* pointer in temporary buffer */
    int pixelV,pixV; /* current pixel value */
    char SHUGE *ccP;
    unsigned char SHUGE *outP; /* pointer in output line */

    /* convert bitmap to Device Independant Bitmap if neccessary */

    headerH = (Memh)regionID; /* pick up header handle */
    win_convert_region((long)headerH);

    headerP = (struct saved_region FAR *)GetPtr(headerH);
    dibH = headerP->rgbdibH;
    if (!dibH)
	dibH = headerP->paldibH;
    hSize = TUTORget_hsize(dibH); /* get total size of handle */
    ccP = GetPtr(dibH);
    bInfoP = (LPBITMAPINFOHEADER)(ccP+sizeof(BITMAPFILEHEADER));

    sizeColor = bInfoP->biClrUsed;
    bitsPixel = bInfoP->biBitCount;
    width = bInfoP->biWidth;
    height = bInfoP->biHeight;

    if (!sizeColor) {
	switch (bitsPixel) {
	case 1:
	    sizeColor = 2;
	    inBytesRow = (width+7) >> 3;
	    break;
        case 4:
	    sizeColor = 16;
	    inBytesRow = (width+1) >> 1;
	    break;
	case 8:
	    sizeColor = 256;
	    inBytesRow = width;
	    break;
        default:
	    sizeColor = 0;
	    inBytesRow = width*3L;
	    break;
	} /* switch */
    } /* sizeColor if */
    rowI = inBytesRow;
    inBytesRow = ((inBytesRow+3L) >> 2) << 2;
    rowExtra = (int)(inBytesRow-rowI);
    sizeColor *= sizeof(RGBQUAD); /* size of color table in bytes */

    bColorP = (LPRGBQUAD)(ccP+sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER));
    pixBaseP = ((unsigned char SHUGE *)bColorP)+sizeColor;
    buffSize = width*height*3L; /* size required for pixels */
    buffH = TUTORhandle("rgb",buffSize,FALSE);
    if (!buffH) {
	TxtMemErr++;
	ReleasePtr(dibH);
	ReleasePtr(headerH);
        return(0); /* no go */
    }
    TUTORpurge_info(buffH,M_WORM,FARNULL,0);
    AllowHandlePurge(buffH);

    /* copy to output buffer, one pixel (red,green,blue) at a time */
    
    rowBaseP = pixBaseP; /* start at base of pixels */
    buffP = (unsigned char FAR *)GetPtr(buffH);
    outP = buffP; /* pointer in output buffer */
    if (bitsPixel == 1) {
	for(rowI=height-1; rowI>=0; rowI--) {
	    pixelP = rowBaseP+(rowI*inBytesRow);
	    for(pixelI=0; pixelI<width; pixelI++) {
		if ((pixelI & 7) == 0)
		    pixelV = *pixelP++; /* pick up next byte of pixel values */
		pixV = (pixelV >> (7-(pixelI & 7))) & 1;
		*outP++ = bColorP[pixV].rgbRed;
		*outP++ = bColorP[pixV].rgbGreen;
		*outP++ = bColorP[pixV].rgbBlue;
	    } /* pixelI for */
	} /* rowI for */
    } else if (bitsPixel == 4) {
	for(rowI=height-1; rowI>=0; rowI--) {
	    pixelP = rowBaseP+(rowI*inBytesRow);
	    for(pixelI=0; pixelI<width; pixelI++) {
		if ((pixelI & 1) == 0) {
		    pixelV = *pixelP++; /* pick up next byte of pixel values */
		    *outP++ = bColorP[(pixelV >> 4) & 0xf].rgbRed;
		    *outP++ = bColorP[(pixelV >> 4) & 0xf].rgbGreen;
		    *outP++ = bColorP[(pixelV >> 4) & 0xf].rgbBlue;
		} else {
		    *outP++ = bColorP[pixelV & 0xf].rgbRed;
		    *outP++ = bColorP[pixelV & 0xf].rgbGreen;
		    *outP++ = bColorP[pixelV & 0xf].rgbBlue;
		}
	    } /* pixelI for */
	} /* rowI for */
    } else if (bitsPixel == 8) {
	for(rowI=height-1; rowI>=0; rowI--) {
	    pixelP = rowBaseP+(rowI*inBytesRow);
	    for(pixelI=0; pixelI<width; pixelI++) {
		pixelV = *pixelP++; /* pick up next pixel value */
		*outP++ = bColorP[pixelV].rgbRed;
		*outP++ = bColorP[pixelV].rgbGreen;
		*outP++ = bColorP[pixelV].rgbBlue;
	    } /* pixelI for */
	} /* rowI for */
    } else if (bitsPixel == 24) {
	for(rowI=height-1; rowI>=0; rowI--) {
	    pixelP = rowBaseP+(rowI*inBytesRow);
	    for(pixelI=0; pixelI<width; pixelI++) {
		*outP++ = *pixelP++;
		*outP++ = *pixelP++;
		*outP++ = *pixelP++;
	    } /* pixelI for */
	} /* rowI for */
    }

    ReleasePtr(dibH);
    ReleasePtr(buffH);
    headerP->rgbDataH = buffH; /* handle on r,g,b data */
    ReleasePtr(headerH);
    return(buffH);

} /* TUTORget_rgb_region */

/* ******************************************************************* */

int TUTORinq_sys_color(cI,rr,gg,bb) /* get system color */
int cI; /* index of color (0 = foreground, 1 = background) */
double *rr; /* red component */
double *gg; /* green component */
double *bb; /* blue component */

{   int ri,gi,bi;

    if (cI == 0) {
    ri = GetRValue(GetSysColor(COLOR_WINDOWTEXT));
    gi = GetGValue(GetSysColor(COLOR_WINDOWTEXT));
    bi = GetBValue(GetSysColor(COLOR_WINDOWTEXT));
    } else {
    ri = GetRValue(GetSysColor(COLOR_WINDOW));
    gi = GetGValue(GetSysColor(COLOR_WINDOW));
    bi = GetBValue(GetSysColor(COLOR_WINDOW));
    }
    *rr = 100.0*(double)(ri)/255.0;
    *gg = 100.0*(double)(gi)/255.0;
    *bb = 100.0*(double)(bi)/255.0;

    return(cI); /* 0 = black, 1 = white */

} /* TUTORinq_sys_color */

/* ******************************************************************* */

#ifdef NOSUCH

int WinSysColors() /* set to windows system colors */

{   double drr,dgg,dbb; /* 0.0-100.0 color values */
    unsigned int irr,igg,ibb; /* 0-0xffff color values */
    Memh palH; /* handle on current palette */
    int fbi; /* 0 = foreground, 1 = background */
    int pixelV; /* index of color in palette */
    struct CTcolorentry FAR *palP; /* pointer to palette */

    palH = windowsP[CurrentWindow].paletteH;
    if (!palH)
	palH = defaultPalette;
    if (!palH)
	return(0);
    palP = (struct CTcolorentry FAR *)GetPtr(palH);
    for(fbi=0; fbi<2; fbi++) {
	TUTORinq_sys_color(fbi,&drr,&dgg,&dbb);
	irr = drr*((double)(0xffff)/100.0);
	igg = dgg*((double)(0xffff)/100.0);
	ibb = dbb*((double)(0xffff)/100.0);
	pixelV = PaletteMatch(palP,256,irr,igg,ibb);
	if (fbi) pbcolor = pixelV;
	else pfcolor = pixelV;
    } /* for */
    ReleasePtr(palH);
    return(0);

} /* WinSysColors */

#endif

/* ******************************************************************* */
