
/*
A component of the cT (TM) programming environment.
(c) Copyright 1989 Carnegie Mellon University.
cT is a trademark of Carnegie Mellon University.
All rights reserved.
May not be copied without the written consent
of Carnegie Mellon University.
*/
#include "execdefs.h"
#include "yacc.h"
#include "eglobals.h"
#include "tglobals.h"
#include "exprdefs.h"

#ifdef IBMPC
#include <math.h>
#endif

#ifdef ctproto
int  fputvar(unsigned char SHUGE *vaddr,int  vkind,double  fvalue);
int  iputvar(unsigned char SHUGE *vaddr,int  vkind,long  ivalue);
int  smerr(void);
int  semptyerr(void);
int  scoderr(void);
int  matherror(int  errnum,char  *s);
int  myexit(void);
int  TUTORdump(char  *s);
double  lcitof(long  iv);
long  lcftoi(double  dv);
#endif /* ctproto */


/****************************************************
NOTE:  Changed July 1986 to use a local pointer "bin" to march
thru the pseudobinary.  This depends on the fact that the binary
document does not have an internal gap, due to the fact that the
last command (end-of-unit) is added last.
*****************************************************/

#ifdef ANDREW  /* gamma available on big machines */

extern int signgam; /* sign of gamma function */
#ifdef romp
#define ibm032 1
#endif
#ifdef ibm032
#define gamma lgamma /*name was changed in math library to reflect logarithmic value returned (log of gamma).*/
#endif

#endif

extern char *memStr;

/* ******************************************************************* */

fputvar(vaddr,vkind,fvalue)		/* assign floating value to variable */
unsigned char SHUGE *vaddr;		/* address of variable */
int vkind;			/* type of variable */
double fvalue;		/* value to assign */

{	long ivalue;

	switch(vkind) {

	case TFLOAT:
	case FARRAY:
		storeflt(vaddr,fvalue);
		break;

	case TINT:
	case IARRAY:
		ivalue = round(fvalue);
		storeint(vaddr,ivalue);
		break;

	case TBYTE:
	case BARRAY:
		ivalue = round(fvalue);
		*(unsigned char SHUGE *)(vaddr) = ivalue & 0xff;
		break;

	default: 
		TUTORdump("fputvar");
		break;

	} /* switch */
	return(0);

} /* fputvar */

/* ******************************************************************* */

iputvar(vaddr,vkind,ivalue)		/* assign integer value to variable */
unsigned char SHUGE *vaddr;		/* address of variable */
int vkind;			/* type of variable */
long ivalue;		/* value to assign */

{	double fvalue;

	switch (vkind) {

	case TFLOAT:
	case FARRAY:
		fvalue = lcitof(ivalue);
		storeflt(vaddr,fvalue);
		break;

	case TINT:
	case IARRAY:
		storeint(vaddr,ivalue);
		break;

	case TBYTE:
	case BARRAY:
		*(unsigned char SHUGE *)(vaddr) = ivalue & 0xff;
		break;


	default:
		TUTORdump("iputvar");
		break;

	} /* switch */
	return(0);

} /* iputvar */

/* ******************************************************************* */

smerr()	/* string memory overflow error */

{
	matherror(USERERR,"Insufficient memory for string. "); 
	TUTORdump(memStr);
	myexit();	/* must not return from error */

} /* smerr */

/* ******************************************************************* */

semptyerr()	/* illegal reference to empty string */

{
	matherror(USERERR,"Illegal reference to empty string. "); 
	

} /* semptyerr */

/* ******************************************************************* */

scoderr()		/* reference to illegal character code  */

{
	matherror(USERERR,"Illegal character code. "); 
	
} /* scoderr */

/* ******************************************************************* */

#ifdef IBMPC

int _matherr(except)
struct _exception *except;

{
    return(1);
}

#endif

/* ******************************************************************* */
