
/* ******************************************************************* */

#define STRICT
#include <windows.h>          
#include <float.h>
#include <ddeml.h>
#include "ctmsw.h"           

#include "baseenv.h"
#include "tutor.h"
#include "tglobals.h"
#include "ecglobal.h"
#include "kglobals.h"
#include "eglobals.h"
#include "editmenu.h"
#include "fkeys.h"

extern int PASCAL WinMain(HINSTANCE, HINSTANCE, LPSTR, int);
extern BOOL InitApplication(HANDLE);
extern BOOL InitInstance(HANDLE, int);
extern LRESULT CALLBACK MainWndProc(HWND hw,UINT msg,WPARAM wp,long lp);
extern HDDEDATA CALLBACK DDECallback(UINT wType,UINT wFmt,HCONV hConv,
                  HSZ hsz1,HSZ hsz2,HDDEDATA hDDEData,
                  DWORD dwData1,DWORD dwData2);
extern long ProcWndScroll(struct cTwinInf *wI,HWND hWnd,UINT message,
              WPARAM wP,LPARAM lP);
extern long OverlapProc(struct cTwinInf *wI,HWND hWnd,UINT message,
              WPARAM wP,LONG lP);
extern long vControlProc(HWND hWnd,UINT message,
			   WPARAM wParam,LPARAM lParam);
extern void RestoreUnderDialog(void);
extern long qtProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam); 
extern void cTReleaseDC(HWND hWnd,HDC hDC);
extern HDC cTGetDC(HWND hWnd);  
extern int MoviePalette(void);
extern int TUTORfiles_init(void);
extern int CTchange_palette(int wn,Memh newPal,int sizeWanted,int *pSet,int allNew);
void WinKeyFixup(struct tutorevent FAR *event);
extern void ConvertWM_CLOSE(struct tutorevent FAR *ev);
extern int TUTORinteract(int block);
extern int FullHalt(void);
extern char FAR *TUTORalloc(long len,int abort,char *label);
extern int TUTORzero(char FAR *ptr,long lth);
extern long TUTORinq_msec_clock(void);
extern int TUTORinstall_fonts(void);
extern TUTORblock_move(char SHUGE *sp, char SHUGE *dp, long lth);
extern int ctmain1(int    argc,char  * *argv);
extern int ctmain2(void);
extern int TUTORclose_swap(void);
extern int crash_checkpt(void);
extern int TUTORclear_screen(void);  
extern int TUTORnormal_cursor(void);
extern int TUTORwait_cursor(void);    
extern int TUTORset_window(int wix);
extern void RestoreExecCursor(void);
extern int myexit(void);
extern int start_executor(void);
extern int InitHandles(void);
extern int post_toedit(void);
extern int  ReleasePtr(unsigned int  mm);
extern int TUTORgraf_done(void);
extern int TUTORcolor_init(void);
extern int  strlenf(char  FAR *aa);
extern int TUTORchecksum(char FAR *addr,long length);
extern int dde_proc_unit(HCONV hConv,char FAR *dataP,long dataL); 
extern int qtMovieClose(int type);  

extern Memh cTwinInfH; /* handle on cT window (cTwinInf) table */
extern int cTwinInfN; /* number entries in cT window table */
extern HCURSOR SysCursor; /* current cursor if using system-defined cursor */
extern HCURSOR ExecCursor; /* executor created cursor */
extern HCURSOR ArrowCursor; /* arrow cursor */
extern HCURSOR WaitCursor; /* wait cursor */
extern BOOL fMovieOpen; /* non-zero if sound/movie currently open */
extern int qtMovieOpenF; /* TRUE if QuickTime movie currently open */
extern int mControllerHasPalette;
extern HDC CurrentDC; /* current window's device context */
extern HWND CurrentWinH; /* handle on current window */
extern int HaveDC; /* TRUE if have device context */
extern int movieInhibitF; /* TRUE if shouldn't process movie controller */
extern int qtSuppressPaint; /* non-zero if movie generated paint */
extern int inPrint; /* TRUE during a print */

HANDLE hcTInst ; /* current instance of cT */
HWND FirstWinH; /* handle on first window created */
HBRUSH hbrWhite; /* handle on stock white brush */
HBRUSH hbrBlack; /* handle on stock black brush */
DWORD dwDDEInst = 0; /* current DDE instance */
PFNCALLBACK pfnDDECallback; /* ptr to DDE callback routine */
jmp_buf mainenv; /* saved enviornment for longjmp */
int tDump; /* TRUE if crashed (TUTORdump called) */
int KeepRunning; /* TRUE till time to quit */

extern long TopTime; /* clock last time at top of (cT) program */

int execFocus = 0;
int inMenu = 0; /* TRUE while selecting menu */

#ifdef AUTHOR
char *classStr = "ctauth";
char *titleStr = "cT Authoring Environment";
#endif
#ifdef EXECUTE
char *classStr = "ctexec";
char *titleStr = "cT exec";
#endif
#ifdef CTEDIT
char *classStr = "ctedit";
char *titleStr = "cT edit";
#endif

static int halfDead = 0; /* TRUE if already did longjmp(mainenv,1) */
extern int moviePlayingF;   /* Play flag: TRUE == playing, FALSE == paused */
extern HWND hwndMovie; /* window handle of the movie */

extern int leftDown;  /* TRUE if left button currently down */
extern int rightDown; /* TRUE if right button currently down */
extern int lastMouseX; /* current mouse position */
extern int lastMouseY;
extern int mouseCapture; /* TRUE if have mouse during scroll */

extern int inDialog; /* TRUE while processing dialog box */
extern int dialogW; /* (parent) window dialog box is in */

static int oldMouseX = -1;
static int oldMouseY = -1;

/* ******************************************************************* */

int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HINSTANCE hInstance; /* current instance */
HINSTANCE hPrevInstance; /* previous instance */
LPSTR lpCmdLine; /* command line */
int nCmdShow; /* show-window type (open/icon) */

{   MSG msg; /* message */

    if (!hPrevInstance) /* if first instance of app */
    if (!InitApplication(hInstance)) /* Initialize shared things */
        return (FALSE);

    /* initialize this instance of application */

    if (!InitInstance(hInstance, nCmdShow))
        return(FALSE);

    if (setjmp(mainenv)) {    /* return here on final exit */
		halfDead = TRUE;      
		if (windowsP && (CurrentWindow >= 0))
        	TUTORclear_screen();
        if (tDump)  /* emergency checkpoint if crash */
            crash_checkpt();
        TUTORclose_swap(); /* release all swap file related stuff */
		KeepRunning = FALSE;
        PostQuitMessage(0); /* Windows will send WM_QUIT message */
    } /* setjmp if */

    /* loop till WM_QUIT */

    while (GetMessage(&msg,NULL,0,0)) {
		TranslateMessage(&msg); /* translate virtual key codes */

		switch (msg.message) {
		case WM_LBUTTONDOWN:
		case WM_LBUTTONUP:
		case WM_RBUTTONDOWN:
		case WM_RBUTTONUP:
		case WM_MOUSEMOVE:
			leftDown = ((msg.wParam & MK_LBUTTON)? TRUE: FALSE);
			rightDown = ((msg.wParam & MK_RBUTTON)? TRUE: FALSE);
			lastMouseX = LOWORD(msg.lParam);
			lastMouseY = HIWORD(msg.lParam);
			break;
		default:
			break;
		} /* switch */
		DispatchMessage(&msg); /* dispatches message to window */
    } /* GetMessage while */

	qtMovieClose(2); /* close QuickTime */
    TUTORgraf_done(); /* dump graphics objects */

    return (msg.wParam); /* return value from PostQuitMessage */

} /* WinMain */

/* ******************************************************************* */

BOOL InitApplication(hInstance)
HANDLE hInstance; /* current instance */

{   WNDCLASS  wc;

    /* initialize window class */

    wc.style = CS_OWNDC | CS_VREDRAW | CS_HREDRAW ;
    wc.lpfnWndProc = MainWndProc;
    wc.cbClsExtra = 0;			/* no extra data */
    wc.cbWndExtra = 0;			/* no extra data */
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(hInstance,classStr);
    wc.hCursor = NULL;
    wc.hbrBackground = NULL;
    wc.lpszMenuName =  NULL; /* No menu resource in .RC file. */
    wc.lpszClassName = classStr; /* window class name */

    /* register the main window class */

    if (!RegisterClass(&wc))
        return(FALSE);

    return(TRUE);

} /* InitApplication */

/* ******************************************************************* */

BOOL InitInstance(hInstance, nCmdShow)
HANDLE          hInstance;          /* Current instance identifier.       */
int             nCmdShow;           /* Param for first ShowWindow() call. */

{   HWND hWnd;
    DWORD windowStyles;
    unsigned int floatctrl; /* floating point control word */
    unsigned int floatclr; /* bits to clear in control word */

    hcTInst  = hInstance; /* save instance handle */
    KeepRunning = TRUE; /* TRUE till PostQuitMessage called */

    /* suppress floating point errors */

    _fpreset();
    _clear87();
    floatctrl = _control87(0,(unsigned int)(0xffff));
    floatclr = _EM_INVALID | _EM_DENORMAL | _EM_ZERODIVIDE;
    floatclr |= _EM_OVERFLOW | _EM_UNDERFLOW | _EM_INEXACT;
    floatclr |= _PC_64;
    _control87(floatclr,(unsigned int)(0xffff));

    /* Create a main window for this application instance.  */

    windowStyles = WS_OVERLAPPEDWINDOW;
#ifndef EXECUTE
    /* for editor and authoring evnironment, first window has scroll bars */
    windowStyles |= WS_VSCROLL | WS_HSCROLL;
#endif

    hWnd = CreateWindow(
		classStr, /* See RegisterClass() call */
		titleStr, /* window title */
		windowStyles, /* window style */
		CW_USEDEFAULT, /* Default horizontal position */
		40, /* Default vertical position */
		610, /* Default width */
		440, /* Default height */
		NULL, /* Overlapped windows have no parent */
		NULL, /* Use the window class menu */
		hInstance, /* This instance owns this window */
		NULL /* Pointer not needed */
    );
    FirstWinH = hWnd; /* save handle on first window */
    
    /* If window could not be created, return "failure" */

    if (!hWnd)
        return (FALSE);

    /* Make the window visible; update its client area; and return "success" */

    ShowWindow(hWnd, nCmdShow);  /* Show the window                        */
    UpdateWindow(hWnd);          /* Sends WM_PAINT message                 */

    /* initialize ddeml (DDE) library */

    pfnDDECallback = (PFNCALLBACK)MakeProcInstance((FARPROC)DDECallback,
                  hInstance);
    DdeInitialize(&dwDDEInst,pfnDDECallback,CBF_FAIL_ALLSVRXACTIONS,0L);

    /* set up timer to generate event every 60th second */

    if (SetTimer(FirstWinH,1,55,(TIMERPROC)FARNULL) == 0) {
        MessageBox(FirstWinH,(LPCSTR)"Too many clocks or timers.",
            (LPCSTR)"cT",MB_ICONEXCLAMATION | MB_OK);
        return(FALSE); /* didn't come up */
    }

    /* set up default brushes */

    hbrWhite = GetStockObject(WHITE_BRUSH);
    hbrBlack = GetStockObject(BLACK_BRUSH);

    /* send message to drive initializations */

    PostMessage(hWnd,CTM_INIT,0,0L);

    return (TRUE);  /* Returns the value from PostQuitMessage */

} /* InitInstance */

/* ******************************************************************* */

LRESULT CALLBACK MainWndProc(hWnd, message, wParam, lParam)
HWND hWnd;    /* window handle           */
UINT message;    /* type of message           */
WPARAM wParam;    /* additional information       */
LPARAM lParam;    /* additional information       */

{   struct cTwinInf FAR *cTwinInfP; /* pointer to cT window table */
    struct cTwinInf winEntry; /* entry found in table */
    int cwi; /* index in cTwinInf[] */

    /* check if AVI/QuickTime event */

    if ((!movieInhibitF) && vControlProc(hWnd,message,wParam,lParam))
		return(0);

    if ((!movieInhibitF) && qtProc(hWnd, message, wParam, lParam))
		return(0);

    /* identify window - main or button/scroll child */

    winEntry.type = 0; /* don't recognize window yet */
    winEntry.hWnd = hWnd;
    winEntry.index = -1;
    winEntry.infH = HNULL;
    if (cTwinInfH) { /* if table allocated */
        cTwinInfP = (struct cTwinInf FAR *)GetPtr(cTwinInfH);
        for (cwi=0; cwi<cTwinInfN; cwi++) {
            if (cTwinInfP[cwi].type && cTwinInfP[cwi].hWnd == hWnd) {
                winEntry = cTwinInfP[cwi];
                break; /* found the window */
            } /* if */
        } /* for */
        ReleasePtr(cTwinInfH);
    } /* cTwinInfH if */

    if (!winEntry.type) /* didn't identify window */
		return(OverlapProc(&winEntry,hWnd,message,wParam,lParam));

    switch (winEntry.type) {

    case cTw_Overlap:
        return(OverlapProc(&winEntry,hWnd,message,wParam,lParam));

    case cTw_Scroll:
    case cTw_Button:
    case cTw_Server:
        return(DefWindowProc(hWnd,message,wParam,lParam));

    default:
        return(DefWindowProc(hWnd,message,wParam,lParam));

    } /* switch */

} /* MainWndProc */

/* ******************************************************************* */

static long OverlapProc(winEntry, hWnd, message, wParam, lParam)
struct cTwinInf *winEntry; /* entry found in table */
HWND hWnd;    /* window handle           */
UINT message;    /* type of message           */
WPARAM wParam;    /* additional information       */
LPARAM lParam;    /* additional information       */

{   int wix; /* index of window in windows[] */
    struct tutorevent ev; /* event building */
    RECT wrect; /* window client area rectangle */
    PAINTSTRUCT ps; /* description of re-paint operation needed */
    int DefaultP; /* TRUE if should execute default windows procedure */
    int cTinteract; /* TRUE if should generate cT interact() message */
    TutorMenuBar FAR *mp; /* pointer to menu data */
    int mii; /* index in menus or windows */
    HWND scrollWnd; /* handle on scroll bar window */
    Memh scrollInfH; /* handle on scroll bar info */
    struct cTwinInf scrEntry; /* window table entry for scroll bar */
    struct cTwinInf FAR *cTwinInfP; /* pointer to cT window table */
    int cwi; /* index in cT window table */
    int buttonI; /* index of button child window in window table */
    HPALETTE stockPal; /* stock palette object */
    HDC hdc; /* device context */
    int palRet; /* RealizePalette return */
    long retV; /* return value */
    int realF; /* TRUE if real paint event */
    RECT uRect; /* update region rectangle */
    int fKey; /* special key value */
    int mKey; /* special (menu) key value */
    int fKeyShift; /* TRUE if special key shifted */
    int xx,yy; /* x/y position or size */
    HCURSOR curCursor; /* handle on current cursor */
   
    wix = winEntry->index;
    retV = 0; /* pre-set return */
    DefaultP = FALSE; /* assume no need to execute default Windows procedure */
    cTinteract = FALSE; /* assume no need to generate interact event */

    TUTORzero((char FAR *)&ev,(long)sizeof(struct tutorevent));
    ev.window = wix; /* set up event fields */
    ev.timestamp = TUTORinq_msec_clock(); /* time event received */
    ev.type = -1;

    switch (message) {

    case WM_COMMAND:           /* message: command from application menu */
    mii = -1; /* menu not found */
    if ((LOWORD(wParam) >= IDM_CT) && (LOWORD(wParam) < IDB_CT) &&
        (wix >= 0) && (winEntry->type == cTw_Overlap) && windowsP[wix].menus) { /* menu */

        /* search to find which menu selected */

        mp = (TutorMenuBar FAR *)GetPtr(windowsP[wix].menus);
        for (mii=0; mii<mp->nItems; mii++) {
            if (mp->items[mii].menuidN == (long)LOWORD(wParam))
                break; /* found the menu item */
        } /* for */
        if (mii < mp->nItems) { /* item found */

            /* set up menu event */

            ev.type = EVENT_MENU;
            ev.value = mii;
            ev.a1 = mp->items[mii].type;
            ev.a2 = mp->items[mii].unit;
            ev.a3 = mp->items[mii].unitArg;
            
            /* check for executor quit event */
            
            if ((ev.window == ExecWn) && (ev.a1 == exec_quit)) {
                exS.ExecQuit = TRUE;
                exS.ExecQuitTime = TUTORinq_msec_clock();
	    }

	    /* check for menus that convert to keys */

	    switch(ev.a1) {
            case edit_cut:
            case exec_cut:
		    mii = KCUT; break;
            case edit_copy:
            case exec_copy:
		    mii = KCOPY; break;
            case edit_paste:
            case exec_paste:
		    mii = KPASTE; break;
            case edit_undo:
		    mii = KUNDO; break;
            case edit_clear:
		    mii = -8; /* indicates key rather than fkey */
                break;
            default:
		mii = 0; /* really is a menu */
            }
            
	    if (mii) { /* convert to key */
		ev.type = (mii > 0) ? EVENT_FKEY : EVENT_KEY;
		ev.nkeys = 1;
		ev.value = mii;
		ev.keys[0] = -mii;
		ev.view = windowsP[ev.window].KeyFocus;
            }
        } /* mii if */
        ReleasePtr(windowsP[wix].menus);
    } else if ((wix >= 0) && (LOWORD(wParam) >= IDB_CT) && (LOWORD(wParam) < (IDB_CT+100))) {
    
        /* search to find which button pressed */

        buttonI = -1; /* don't know index yet */
        cTwinInfP = (struct cTwinInf FAR *)GetPtr(cTwinInfH);
        for (cwi=0; cwi<cTwinInfN; cwi++) {
            if (cTwinInfP[cwi].type == cTw_Button && 
                cTwinInfP[cwi].cmdN == (int)LOWORD(wParam)) {
                buttonI = cwi;
                break; /* found the window */
            } /* if */
        } /* for */
        ReleasePtr(cTwinInfH);

        /* send button event */

        if (buttonI) {
	 /* ProcButtonEvent(buttonI);	*/ ;
        }
    } /* wix if */
    inMenu = FALSE;
    break;

    case WM_CREATE: /* window created */
    if (wix >= 0) {
        GetClientRect(hWnd,(LPRECT)(&wrect));
        windowsP[wix].wxsize = wrect.right+1;
        windowsP[wix].wysize = wrect.bottom+1;
    } /* wix if */
    DefaultP = TRUE; /* execute default procedure */
    break;

    case WM_SIZE: /* window has been resized */
    if (wix >= 0) {
        GetClientRect(hWnd,(LPRECT)(&wrect));
		xx = wrect.right+1;
		yy = wrect.bottom+1;
		windowsP[wix].iconified = (wParam == SIZEICONIC);
		if ((xx != windowsP[wix].wWidth) ||
		   (yy != windowsP[wix].wHeight)) {
			windowsP[wix].wWidth = xx;
			windowsP[wix].wHeight = yy;
			windowsP[wix].winRedraw = cTinteract = TRUE;
			windowsP[wix].moved = TRUE;
		}
		if (windowsP[wix].iconified && ((wix == EditWn[0]) || (wix == ExecWn))) {
			/* if minimizing main edit or exec window, minimize other */
			/* windows also */
			for(mii=0; mii<WINDOWLIMIT; mii++) {
				if ((mii != wix) && windowsP[mii].wp) {
					ShowWindow((HWND)windowsP[mii].wp,SW_MINIMIZE);
				}
			} /* for */
		} /* iconified if */
    }
    DefaultP = TRUE; /* execute default procedure */
    break;

    case WM_MOVE: /* window has moved */
    if (wix >= 0) {
		xx = LOWORD(lParam);
		yy = HIWORD(lParam);
		if ((xx != windowsP[wix].wXpos) ||
		    (yy != windowsP[wix].wYpos)) {
			windowsP[wix].wXpos = xx;
			windowsP[wix].wYpos = yy;
			windowsP[wix].winRedraw = cTinteract = TRUE;
			windowsP[wix].moved = TRUE;
		}
    }
    DefaultP = TRUE; /* execute default procedure */
    break;

    case WM_ACTIVATE:
	ev.type = EVENT_FWD;
	ev.value = (wParam != WA_INACTIVE);
	if ((ExecWn >= 0) && (wix == ExecWn)) {
	    execFocus = ev.value;
	}
	break;

    case WM_TIMER:    /* message: timer has fired */
    if (KeepRunning) {
		if ((!inPrint) && (!inMenu))
	    	TUTORinteract(FALSE);
    }
    break;

    case WM_ERASEBKGND:    /* message: re-paint display */
    retV = 1;
    break;

    case WM_PAINT:    /* message: re-paint display */
    /* display is generated by interact() later */
    realF = GetUpdateRect(hWnd,&uRect,FALSE);
    xx = uRect.right-uRect.left;
    yy = uRect.bottom-uRect.top;
    BeginPaint(hWnd,(LPPAINTSTRUCT)&ps);
    EndPaint(hWnd,(LPPAINTSTRUCT)&ps);
	if ((wix == ExecWn) && qtSuppressPaint) {
		realF = FALSE;
		qtSuppressPaint--;
	}
	if (inDialog && (wix == dialogW)) {
		int scw; /* saved current window */

		scw = CurrentWindow; /* save current window */
		TUTORset_window(wix);
		RestoreUnderDialog();
		realF = FALSE; /* no further action needed */
		TUTORset_window(scw); /* restore window */
	}
    if (realF && (wix >= 0) && (xx > 0) && (yy > 0)) {
		windowsP[wix].winRedraw = cTinteract = TRUE;
		if (HaveDC && CurrentWinH) { /* release device context */
            cTReleaseDC(CurrentWinH,CurrentDC);
        }
    }
    break;

    case WM_KEYDOWN:
    fKey = mKey = 0; /* no special key value yet */
    fKeyShift = (GetKeyState(VK_SHIFT) < 0);

    switch (wParam) {

	case VK_TAB:
		if (fKeyShift) { /* backwards tab */
			fKey = KBACKTAB;
			fKeyShift = 0; /* forget shift */
		} else {
			ev.type = EVENT_KEY;
			ev.nkeys = 1;
			ev.keys[0] = 0x09; /* forwards tab */
			cTinteract = TRUE;
		}
		break;

	case VK_PRIOR:
		fKey = KPAGEUP;
		break;

	case VK_NEXT:
		fKey = KPAGEDOWN;
		break;

	case VK_HOME:
		fKey = KBEGLINE;
		if (GetKeyState(VK_CONTROL) < 0)
			fKey = KBEGPAGE;
	break;

	case VK_END:
		fKey = KENDLINE;
		if (GetKeyState(VK_CONTROL) < 0)
			fKey = KENDPAGE;
		break;

	case VK_LEFT:
		fKey = KLEFT;
		break;

	case VK_UP:
		fKey = KUP;
		break;

	case VK_RIGHT:
		fKey = KRIGHT;
		break;

	case VK_DOWN:
		fKey = KDOWN;
		break;

	case VK_F1:
		if ((wix >= 0) && (windowsP[wix].type == EDITW) && (!fKeyShift))
			fKey = KHELP;
		break;

	case VK_F3:
		if ((wix >= 0) && (windowsP[wix].type == EDITW) && (!fKeyShift))
			mKey = edit_searchd;
		break;

	case VK_F5:
		if ((wix >= 0) && (!fKeyShift)) {
			if ((windowsP[wix].type == EDITW) ||
				((wix == ExecWn) && (runflag == halt) && (EditWn[0] >= 0))) {
				mKey = edit_run;
				ev.window = EditWn[0];
			}
		}
		break;

	case VK_INSERT:
		fKey = KPASTE;
		if (fKeyShift) {
			fKey = KCOPY;
			fKeyShift = 0; /* forget shift */
		}
		break;

	case VK_DELETE:
		fKey = KFWDDEL;
		if (fKeyShift) {
			fKey = KCUT; /* translate to cut */
			fKeyShift = 0; /* forget shift */
		}
		break;

	default:
		retV = 1; /* did not process message */
		DefaultP = TRUE; /* pass to default Windows handler */
		break;

    } /* switch */

    if (fKey) {
		if (fKeyShift) fKey++; /* increment for shift */
		ev.type = EVENT_FKEY;
		ev.nkeys = 1;
		ev.value = fKey; /* set key value */
		cTinteract = TRUE;
    } /* fKey if */
    if (mKey) {
		ev.type = EVENT_MENU;
		ev.a1 = mKey;
		ev.a2 = 0;
    }
    break;

    case WM_CHAR:
    ev.type = EVENT_KEY;
    ev.nkeys = 1;
    ev.keys[0] = wParam;
    WinKeyFixup((struct tutorevent FAR *)&ev);
    cTinteract = TRUE;
    break;

    case WM_LBUTTONDOWN:
    case WM_LBUTTONUP:
    case WM_RBUTTONDOWN:
    case WM_RBUTTONUP:
    case WM_MOUSEMOVE:
    ev.type = -1;
    ev.leftdown = leftDown;
    ev.rightdown = rightDown;
    ev.x = lastMouseX;
    ev.y = lastMouseY;
    curCursor = GetCursor();
    if ((SysCursor && (curCursor != SysCursor)) ||
		(ExecCursor && (curCursor != ExecCursor))) {
		if (SysCursor == ArrowCursor)
			TUTORnormal_cursor();
		else if (SysCursor == WaitCursor)
			TUTORwait_cursor();
		else if (wix == ExecWn) {
			if (CurrentWindow != ExecWn)
				TUTORset_window(ExecWn);
			RestoreExecCursor();
		}
    }
    if (message == WM_MOUSEMOVE) {
	if ((lastMouseX != oldMouseX) || (lastMouseY != oldMouseY)) {
	    if (ev.leftdown || ev.rightdown) {
		ev.type = EVENT_DOWNMOVE;
	    } else if ((wix >= 0) && windowsP[wix].eventMask[EVENT_UPMOVE]) {
		ev.type = EVENT_UPMOVE;
	    }
	} /* lastMouse if */
	if (ev.type > 0) {
	    oldMouseX = lastMouseX;
	    oldMouseY = lastMouseY;
	}
    } else if (message == WM_LBUTTONDOWN) {
        ev.type = EVENT_LEFTDOWN;
        if (wix >= 0) {
	    windowsP[wix].ldowntime2 = windowsP[wix].ldowntime1;
	    windowsP[wix].ldowntime1 = TopTime = TUTORinq_msec_clock();
	    if (!mouseCapture) {
		SetCapture((HWND)windowsP[wix].wp);
		mouseCapture = TRUE;
	    }
        }
    } else if (message == WM_LBUTTONUP) {
	ev.type = EVENT_LEFTUP;
    } else if (message == WM_RBUTTONDOWN) {
        ev.type = EVENT_RIGHTDOWN;
        if (wix >= 0) {
	    windowsP[wix].rdowntime2 = windowsP[wix].rdowntime1;
	    windowsP[wix].rdowntime1 = TopTime = TUTORinq_msec_clock();
	    if (!mouseCapture) {
		SetCapture((HWND)windowsP[wix].wp);
		mouseCapture = TRUE;
	    }
        }
    } else if (message == WM_RBUTTONUP)
	ev.type = EVENT_RIGHTUP;
    cTinteract = TRUE;
    break;

    case WM_VSCROLL:
    case WM_HSCROLL:
    /* determine window scroll bar or control */
    scrEntry = *winEntry; /* pre-set for window scroll bar */
    scrollWnd = (HWND)(lParam);
    if (scrollWnd) {
        scrollInfH = GetWindowLong(scrollWnd,GWL_ID);
        if (scrollInfH && cTwinInfH) {
            cTwinInfP = (struct cTwinInf FAR *)GetPtr(cTwinInfH);
            for (cwi=0; cwi<cTwinInfN; cwi++) {
                if ((cTwinInfP[cwi].type == cTw_Scroll) &&
                    (cTwinInfP[cwi].infH == scrollInfH)) {
                    scrEntry = cTwinInfP[cwi];
                    break; /* found the window */
                } /* if */
            } /* for */
            ReleasePtr(cTwinInfH);
        } /* scrollInfH */
    } /* scrollWnd */
    ProcWndScroll(&scrEntry, hWnd, message, wParam, lParam);
    DefaultP = TRUE;
    break;

    case WM_PALETTECHANGED:
    if (((HWND)wParam == hWnd) || ((HWND)wParam == hwndMovie))
		break; /* talking to ourselves */
    case WM_QUERYNEWPALETTE:
    if (wix >= 0) {
	palRet = 0;
	if (fMovieOpen == 1) {
	    palRet = MoviePalette();
	} else if ((HPALETTE)(windowsP[wix].winPalH) && ((wix == ExecWn) || (runflag == halt))) {
	    stockPal = GetStockObject(DEFAULT_PALETTE);
	    hdc = cTGetDC(hWnd);
	    SelectPalette(hdc,(HPALETTE)windowsP[wix].winPalH,0);
	    palRet = RealizePalette(hdc);
	    SelectPalette(hdc,stockPal,1); /* use default as background */
	    RealizePalette(hdc);
	    cTReleaseDC(hWnd,hdc);
	}
        return(palRet);
    } /* wix if */
    DefaultP = TRUE; /* execute default procedure */
    break;

	case WM_ENTERIDLE:
	DefaultP = TRUE;
	if (wParam == MSGF_MENU)
		inMenu = TRUE; /* processing menu */
	break;

    case WM_INITMENU:
    DefaultP = TRUE;
	inMenu = TRUE;	/* processing menu */
    break;

    case WM_MENUSELECT:
    DefaultP = TRUE;
    if (((HIWORD(lParam) == 0) && ((int)(LOWORD(lParam)) == -1)) ||
		(lParam == 0))
		inMenu = FALSE; /* done selecting menu */
    break;

    case WM_DESTROY:
    case WM_CLOSE:
    if ((wix >= 0) && (!halfDead)) {
        ConvertWM_CLOSE((struct tutorevent FAR *)&ev);
    } else {
        DefaultP = TRUE; /* pass to default processor */
    } /* wix else */
    break;

    case CTM_INIT:  /* internal message: perform initializations */
    InitHandles(); /* initialize memory management */
    TUTORfiles_init(); /* initialize file table */
    TUTORcolor_init(); /* basic color initializations */
    TUTORinstall_fonts();

    ctmain1(0,NEARNULL);  /* initializations */
    ctmain2();

    if (setjmp(errjmpbuff)) {   /* handle compile/execution err */
        FullHalt();
        if (!ctedit)
	    myexit(); /* nothing else to do if no editor */
        post_toedit();
    } /* setjmp if */

    /* fire up executor if no editor */

    if (nosourcelayout)
        start_executor();

    cTinteract = TRUE; /* fire up interact() */
    break;

    case CTM_INTERACT: /* internal message: run */
    if (KeepRunning) {
		if ((!inPrint) && (!inMenu))
			TUTORinteract(FALSE);
    }
    break;

    default:
    DefaultP = TRUE; /* pass to default Windows handler */
    break;

    } /* switch */

    /* post any event generated */

    if (eventque && ev.type >= 0)
	eventque[nevents++] = ev; /* queue event */

    /* post message to drive interact() if neccessary */

    if (cTinteract && KeepRunning)
        PostMessage(hWnd,CTM_INTERACT,0,0L);

    /* call default Windows handler if neccessary */

    if (DefaultP)
        return(DefWindowProc(hWnd,message,wParam,lParam));

    return (retV);

} /* OverlapProc */

/* ******************************************************************* */

HDDEDATA CALLBACK DDECallback(wType,wFmt,hConv,hsz1,hsz2,hDDEData,dwData1,dwData2)
UINT wType; /* transaction type */
UINT wFmt; /* clipboard data format */
HCONV hConv; /* handle on conversation */
HSZ hsz1; /* message specific string */
HSZ hsz2; /* message specific string */
HDDEDATA hDDEData; /* handle on global memory object */
DWORD dwData1; /* message specific data */
DWORD dwData2; /* message specific data */

{   BYTE FAR *pData; /* pointer to data */
    DWORD dwLength; /* length of data */
    char FAR *dP; /* pointer to copy of data */

    switch (wType) {

    case XTYP_ADVDATA:
        pData = DdeAccessData(hDDEData, &dwLength);
    if (pData) {
        dwLength = strlenf(pData); /* assume text */
        dP = TUTORalloc(dwLength,FALSE,"dde");
        if (dP) {
        TUTORblock_move(pData,dP,dwLength);
        dde_proc_unit(hConv,dP,dwLength);
        } /* dP if */
        }
        DdeUnaccessData(hDDEData);
    return((HDDEDATA)DDE_FACK);

    case XTYP_XACT_COMPLETE:
    return((HDDEDATA)DDE_FACK);

    case XTYP_DISCONNECT:
    return((HDDEDATA)NULL);

    default:
    return(NULL);
    break;

    } /* switch */

} /* DDECallback */

/* ******************************************************************* */
