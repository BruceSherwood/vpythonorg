from fontTools.pens.basePen import BasePen


__all__ = ["CocoaPen"]


class CocoaPen(BasePen):

	def __init__(self, glyphSet, path=None):
		BasePen.__init__(self, glyphSet)
		if path is None:
			from AppKit import NSBezierPath
			path = NSBezierPath.bezierPath()
		self.path = path

	def _moveTo(self, xxx_todo_changeme):
		(x, y) = xxx_todo_changeme
		self.path.moveToPoint_((x, y))

	def _lineTo(self, xxx_todo_changeme1):
		(x, y) = xxx_todo_changeme1
		self.path.lineToPoint_((x, y))

	def _curveToOne(self, xxx_todo_changeme2, xxx_todo_changeme3, xxx_todo_changeme4):
		(x1, y1) = xxx_todo_changeme2
		(x2, y2) = xxx_todo_changeme3
		(x3, y3) = xxx_todo_changeme4
		self.path.curveToPoint_controlPoint1_controlPoint2_((x3, y3), (x1, y1), (x2, y2))

	def _closePath(self):
		self.path.closePath()
