version = ('5.32', 'release')

from . import cvisual
cvisual.init_numpy()
from .cvisual import (vector, dot, mag, mag2, norm, cross, rotate,
                       comp, proj, diff_angle, rate, waitclose)
from .primitives import (arrow, cylinder, cone, sphere, box, ring, label,
                               frame, pyramid, ellipsoid, curve, faces, convex, helix,
                               points, text, distant_light, local_light)
from .ui import display
scene = display() # a display needs to exist in order for an object reference to work
from . import crayola
color = crayola
from . import materials
from . import site_settings # need to study this
