1) Before making any changes to your current site-packages, make a copy of 

     site-packages/visual

2) Replace site-packages/visual with the visual folder in this package.

3) Add to site-packages the vis folder in this package.

4) From your saved copy of site-packages/visual, copy into the new vis folder

     cvisual.pyd (Windows) or
     cvisual.so (Mac)

5) On Windows, from your saved copy of site-packages/visual, 
   copy the doc and examples folders into the new visual folder.

After making these changes, you can still use "from visual import *"
if that is convenient, but if you want to import the visual objects
cleanly, import them from the new vis module. Two simple examples:

import vis
vis.box(color=vis.color.orange, material=vis.materials.wood)

from vis import (box, color, materials)
box(color=color.orange, material=materials.wood)

There are new clean modules vis.controls, vis.filedialog, and vis.graph
equivalent to the old modules visual.controls, visual.filedialog, and
visual.graph. The old modules execute "from visual import *" and are
retained because some programs expect that behavior when importing one
of these modules.
