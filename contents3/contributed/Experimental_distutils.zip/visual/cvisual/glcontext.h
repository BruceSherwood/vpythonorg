#ifndef GLCONTEXT_H
#define GLCONTEXT_H

#include "cvisual.h"

struct glFont {
  virtual double getWidth(const char* string) = 0;
    // returns the horizontal extent of the given string in
    //   viewport coordinates (0.0 to 1.0)

  virtual double ascent() = 0;
    // returns the maximum distance from the baseline to the top
    //   of a glyph (e.g. "M")

  virtual double descent() = 0;
    // returns the maximum distance from the baseline to the bottom
    //   of a glyph (e.g. "g")

  virtual void draw(const char* string) = 0;
    // draws string with the current glRasterPos at its left baseline

  virtual void release() = 0;
    // call once for each call to glContext::getFont()
};

struct glContext {
  public:
    virtual void lockMouse() = 0;
    virtual void unlockMouse() = 0;
    virtual int  getMouseButtons() = 0;
    virtual int  getMouseButtonsChanged() = 0;
    virtual int  getShiftKey() = 0;
    virtual int  getAltKey() = 0;
    virtual int  getCtrlKey() = 0;
    virtual Vector  getMouseDelta() = 0;
    virtual Vector  getMousePos() = 0;
    virtual string  getKeys() = 0;

    glContext() {};
    virtual ~glContext() {};

    virtual bool initWindow( const char* title, int x, int y, int width, int height ) = 0;
    virtual bool changeWindow( const char* title, int x, int y, int width, int height ) = 0;
    virtual bool isOpen() = 0;
    virtual void cleanup() = 0;
  
    virtual void makeCurrent() = 0;
    virtual void makeNotCurrent() = 0;
    virtual void swapBuffers() = 0;

    virtual Vector origin() = 0;   // of entire window (or, same as initWindow())
    virtual Vector corner() = 0;   // of entire window (or, same as initWindow())
    virtual int width() = 0;       // of GL area
    virtual int height() = 0;      // of GL area

    virtual string lastError() = 0;

    virtual glFont* getFont(const char* description, double size) = 0; 
      // xxx need to document parameters!
};

#endif
