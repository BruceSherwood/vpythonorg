#include "prim.h"
#include "sphmodel.h"
#include GL_INCLUDE    // see platform.h

class sphere : public Primitive {
  public:
    double radius;

    sphere() : radius(1) {}
    double getRadius() {
      return radius;
    }
    void setRadius(double r) {
      radius = r;
    }
    Vector getScale() {
      return Vector(radius,radius,radius);
    }

    virtual double rayIntersect(const Vector &camera, const Vector &ray) {
      if (degenerate) return 0.0;
      Vector delta(camera.x - mwt[0][3], camera.y - mwt[1][3], camera.z - mwt[2][3]);

      // quadratic formula
      //  A = |ray| = 1, since ray is normalized
      double B = 2 * ray.dot(delta);
      double C = delta.mag2() - scale.x*scale.x;

      double disc = B*B - 4*C;  // quadratic discriminant
      if (disc < 0.0) return 0.0;
      disc = sqrt(disc);

      // find the smaller positive root

      // disc is positive, so if this root is positive it
      //   is smallest
      double t = (-B - disc) * 0.5;  

      if (t<0)  // otherwise try this one
        t = (-B + disc) * 0.5;

      return t;
    }

    virtual void glRender(rView &view) {
      if (degenerate) return;

      view.ext_sphere( mwt * Vector(0,0,0), scale.x );

      lighting lt(view.lights, wlt);
      tmatrix mct(mwt, view.wct);

      // Level-of-detail heuristic.
      //   xxx Figure out how this should actually work!
      Vector a = mct*Vector(0,0,0) / mct.w(Vector(0,0,0));
      Vector b = mct*Vector(0.5,0,0) / mct.w(Vector(0.5,0,0));
      Vector c = mct*Vector(0,0.5,0) / mct.w(Vector(0,0.5,0));
      Vector d = mct*Vector(0,0,0.5) / mct.w(Vector(0,0,0.5));
      float size = sqrt((a-b).mag2() + (a-c).mag2() + (a-d).mag2());
      int n;
      if (size < 0.02) n = 0;
      else if (size < 0.125) n = 1;
      else n = 2;

      sph_model& model = sph_model::get(n);

      // Projection and lighting loop
      vertex *pr = model.proj;
      float *col = model.color;
      float *mv = model.verts;
      for(int v=0;v<model.nverts;v++) {
        double illum = lt.illuminate(mv[0], mv[1], mv[2]);

        col[0] = color.r*illum;
        col[1] = color.g*illum;
        col[2] = color.b*illum;
        col[3] = 1.0;
        col += 4;
        
        mct.project(mv, *pr++); mv += 3;
      }

      glEnableClientState(GL_VERTEX_ARRAY);
      glEnableClientState(GL_COLOR_ARRAY);
      glVertexPointer(4, GL_DOUBLE, sizeof(vertex), &model.proj[0].x);
      glColorPointer(4, GL_FLOAT, 4*sizeof(float), model.color);
      glShadeModel(GL_SMOOTH);

      glDrawElements(GL_TRIANGLES, model.ni, GL_UNSIGNED_INT, model.indices);
    }
};

Object create_sphere(const Tuple& args, const Dict& kwargs) {
  return init(new sphere,args,kwargs);
}
