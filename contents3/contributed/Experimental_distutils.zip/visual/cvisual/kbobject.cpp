#include "kbobject.h"

void kbObject::init_type() {
  behaviors().name("kb");
  behaviors().supportGetattr();
  add_varargs_method("getkey",&kbObject::py_getkey);
}

Object kbObject::getattr(const char *_attr) {
  string attr = _attr;
  if (attr == "keys")
    return Int((int)keys.size());
  return getattr_methods(_attr);
}

Object kbObject::py_getkey(const Tuple& args) {
  if (args.length()) throw TypeError("getkey() expects no arguments");
  
  while (1) {
    { mutex::lock L(mtx);
      if (keys.size()) {
        String s = keys[0];
        keys.erase(keys.begin());
        return s;
      }
    }
    threaded_sleep(0.01);
  }
}
