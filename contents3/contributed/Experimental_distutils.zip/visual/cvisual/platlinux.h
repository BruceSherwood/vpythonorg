#ifndef PLATLINUX_H
#define PLATLINUX_H

#include <glib.h>

class gMutex {
  int count;
  GMutex* mutex;
  
  public:
  typedef lock<gMutex> lock;
  
  gMutex(int spincount=0, int count=1);
  ~gMutex();
  
  inline void sync_lock() { g_mutex_lock(mutex); }
  inline void count_lock() { g_mutex_lock(mutex); count++; }
  inline void sync_unlock() { g_mutex_unlock(mutex); }
  inline int sync_count() { return count; }
  
  void clear() {
    sync_lock();
    count=0;
    sync_unlock();
  }
};

void _threaded_timer(double seconds, bool (*callback)(void*), void *data);

template <class T>
void threaded_timer(double seconds, bool (*callback)(T*), T* data) {
  _threaded_timer(seconds, (bool(*)(void*))callback, (void*)data);
}
  
#endif
