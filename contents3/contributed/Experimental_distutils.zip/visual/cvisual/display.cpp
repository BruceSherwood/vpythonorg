
#include "display.h"
#include <sstream>

/************* Display implementation *************/

Display* Display::selected = 0;
vector<Display*> Display::all;
mutex allLock;

void Display::init_type() {
  behaviors().name("Display");
  behaviors().supportGetattr();
  behaviors().supportSetattr();
  add_varargs_method("show",   &Display::py_show);
  add_varargs_method("hide",   &Display::py_hide);
  add_varargs_method("info",   &Display::py_info);
  add_varargs_method("select", &Display::py_select);
  add_keyword_method("project",&Display::py_project);
}

Object Display::py_info(const Tuple& t) {
  if (t.size()) throw TypeError("info() expects no arguments.");
  return String(device->info());
}

Object Display::py_select(const Tuple& t) {
  if (t.size()) throw TypeError("select() expects no arguments.");
  selected = this;
  return Nothing();
}

Object Display::py_project(const Tuple& t, const Dict& kw) {
  if (t.size()!=1) throw TypeError("project() takes a single vector.");
  Vector p( t[0] );

  tmatrix wct = device->get_wct();

  double w = wct.w(p);
  if (!w) return Nothing();

  p = (wct*p) / w;
  if (p.z <= 0)   // || p.x < -1 || p.y < -1 || p.x > 1 || p.y > 1 || p.z > 1
    return Nothing();

  return asImmutableVector(p);
}

Display::Display(Device& dev)
 : title("VPython"),
   center(0,0,0),
   forward(0,0,-1),
   scale(0.1,0.1,0.1),
   up(0,1,0),
   fov(60*pi/180),
   foreground(1,1,1),
   background(0,0,0),
   uniform(true), 
   autoscale_enabled(true),
   autocenter_enabled(false),
   region_valid(false),
   auto_show(true),
   title_changed(true),
   mouse(FromAPI(new mouseObject)),
   kb(FromAPI(new kbObject)),
   cursor(FromAPI(new cursorObject)),
   autoscale_max(1.0),
   autoscale_min(1.0),
   device(&dev),
   rotation_enabled(true),
   zoom_enabled(true)
{ mouseObject *m;
  Object(this).increment_reference_count();  // never die
                                             // xxx might be a bad idea
  m = this->mouse.extensionObject();
  m->buttons = 0;

  selected = this;
  device->display = this;
  device->onClose(true);

  mutex::lock A(allLock);
  displayID = all.size();
  all.push_back(this);
}

Display::~Display() {
  {
    mutex::lock A(allLock);
    all[displayID] = all.back();
    all[displayID]->displayID = displayID;
    all.pop_back();
  }
  if (device) delete(device);
  if (selected==this) selected=0;
}

void Display::shutdown() {
  vector<Display*> _all;
  {
    mutex::lock A(allLock);
    _all = all;
  }
  for( vector<Display*>::iterator i = _all.begin(); i != _all.end(); i++ ) {
    (*i)->device->hide();
    (*i)->device->join();
  }
}

void Display::waitclose() {
  vector<Display*> _all;
  {
    mutex::lock A(allLock);
    _all = all;
  }
  for( vector<Display*>::iterator i = _all.begin(); i != _all.end(); i++ ) {
    (*i)->device->join();
  }
} 

bool Display::allclosed() {
  vector<Display*> _all;
  {
    mutex::lock A(allLock);
    _all = all;
  }
  for( vector<Display*>::iterator i = _all.begin(); i != _all.end(); i++ ) {
    if (!(*i)->device->closed()) return false;
  }
  return true;
} 

void Display::addObject(DisplayObject*) {
  if (auto_show) show();
}

void Display::show() {
  auto_show = false;
  device->show();
};

void Display::hide() {
  auto_show = false;
  device->hide();
  device->join();
};

Object Display::py_show(const Tuple& args) {
  if (args.length()) {
  	ostringstream temp;
  	temp << "Function expects no arguments, but received " << args.length();
  	throw TypeError( temp.str());
  }
  show();

  return Nothing();
}

Object Display::py_hide(const Tuple& args) {
  if (args.length()) {
    ostringstream temp;
    temp << "Function expects no arguments, but received " << args.length();
    throw TypeError( temp.str());
  }
  hide();

  return Nothing();
}

double Display::get_tanfov() {
  return tan( fov*0.5 );
}

void Display::refreshCache() {
  if (region_valid) {
    Vector extent = region_max - center;
    Vector e2 = center - region_min;
    if (e2.x > extent.x) extent.x = e2.x;
    if (e2.y > extent.y) extent.y = e2.y;
    if (e2.z > extent.z) extent.z = e2.z;

    c_extent = extent;

    if (autocenter_enabled) {
      center = (region_min + region_max) * 0.5;
    }

    if (autoscale_enabled && !!extent) {
      if (uniform) {
        float mag = 1.0 / extent.mag();

        Vector smax = Vector(mag,mag,mag)*autoscale_max;
        Vector smin = Vector(mag,mag,mag)*autoscale_min;

        if (scale.mag() > smax.mag())
          scale = smax;
        if (scale.mag() < smin.mag())
          scale = smin;

        //scale = Vector( mag, mag, mag );
      } else {
        Vector s;
        s.x = extent.x ? 1.0 / extent.x : 0.0;
        s.y = extent.y ? 1.0 / extent.y : 0.0;
        s.z = extent.z ? 1.0 / extent.z : 0.0;

        if (scale.x > autoscale_max * s.x)
          scale.x = autoscale_max * s.x;
        if (scale.x < autoscale_min * s.x)
          scale.x = autoscale_min * s.x;
        if (scale.y > autoscale_max * s.y)
          scale.y = autoscale_max * s.y;
        if (scale.y < autoscale_min * s.y)
          scale.y = autoscale_min * s.y;
        if (scale.z > autoscale_max * s.z)
          scale.z = autoscale_max * s.z;
        if (scale.z < autoscale_min * s.z)
          scale.z = autoscale_min * s.z;
      }
    }
  }

  c_uniform = uniform;
  c_rotation_enabled = rotation_enabled;
  c_zoom_enabled = zoom_enabled;
  c_title = title;
  c_title_changed = title_changed;
  title_changed = false;
  tanfov = get_tanfov();
  bgcolor = background;
  region_valid = false;

  c_forward = forward;
  c_up = up;
  c_center = center;

  Vector Z = forward.norm();
  Vector X = Z.cross( up ).norm();
  iview.x_column(X);
  iview.y_column(X.cross( Z ));
  iview.z_column(Z*-1.0);
  iview.w_column(Z*-1.0/tanfov);
  iview.w_row();
  view.invert_ortho(iview);

  model.x_column(scale.x,0,0);
  model.y_column(0,scale.y,0);
  model.z_column(0,0,scale.z);
  model.w_column(center.scale(scale)*-1);
  model.w_row();
  
  imodel.x_column(1.0 / model[0][0], 0, 0);
  imodel.y_column(0, 1.0 / model[1][1], 0);
  imodel.z_column(0, 0, 1.0 / model[2][2]);
  imodel.w_column(center);
  imodel.w_row();
}

// kludge - break getattr into pieces to avoid spurious
// out of memory error on Mac

Object Display::getattr1( const char *_attr, int *didIt ) {
  string attr = _attr;

  *didIt = 1;
  if      (attr == "title")
    return String(title);
  else if (attr == "center") {
    return asImmutableVector(center);
  } else if (attr == "forward") {
    return asImmutableVector(forward);
  } else if (attr == "scale") {
    //if (autoscale_enabled) throw RuntimeError("Can't read scale when autoscale is on.");
    read_lock L(mtx);
    return asImmutableVector(scale);
  } else if (attr == "up") {
    return asImmutableVector(up);
  } else if (attr == "fov") {
    return Float(fov);
  } else if (attr == "uniform") {
    return Int(uniform);
  } else if (attr == "foreground") {
    return foreground.asTuple();
  } else if (attr == "background") {
    return background.asTuple();
  } else if (attr == "autoscale") {
    return Int(autoscale_enabled);
  } else if (attr == "autocenter") {
    return Int(autocenter_enabled);
  } else if (attr == "userzoom") {
    return Int(zoom_enabled);
  } else if (attr == "userspin") {
    return Int(rotation_enabled);
  } else if (attr == "range") {
    //if (autoscale_enabled) throw RuntimeError("Can't read range when autoscale is on.");
    read_lock L(mtx);
    Vector range( scale.x ? 1.0/scale.x : 0.0,
                       scale.y ? 1.0/scale.y : 0.0,
                       scale.z ? 1.0/scale.z : 0.0 );
    return asImmutableVector(range);
  }
  *didIt = 0;
  return Int(0);
}
  

 
Object Display::getattr( const char *_attr ) {
  string attr = _attr;
  Object retObj;
  int didIt;

  retObj = getattr1(_attr,&didIt);
  if (didIt)
  	return(retObj);
  if (attr == "extent") {
    Vector extent = region_max - center;
    Vector e2 = center - region_min;
    if (e2.x > extent.x) extent.x = e2.x;
    if (e2.y > extent.y) extent.y = e2.y;
    if (e2.z > extent.z) extent.z = e2.z;
    return asImmutableVector(extent);
  } else if (attr == "x") { 
    return Int(device->getX());
  } else if (attr == "y") {
    return Int(device->getY());
  } else if (attr == "width") {
    return Int(device->getWidth());
  } else if (attr == "height") {
    return Int(device->getHeight());
  } else if (attr == "selected") {
    return Int(selected == this);
  } else if (attr == "mouse") {
    if (auto_show) show();
    return mouse;
  } else if (attr == "kb") {
    if (auto_show) show();
    return kb;
  } else if (attr == "cursor") {
    return cursor;
  } else if (attr == "maxscale") {
    return Float(autoscale_max);
  } else if (attr == "minscale") {
    return Float(autoscale_min);
  } else if (attr == "visible") {
    return Int(!device->closed());
  } else if (attr == "objects") {
    List objs;
    DisplayListIterator p(objects());
    for(p++; p; p++) {
      Object o = p->getObject();
      if (!o.is(Py_None))
        objs.append(o);
    }
    return objs;
  } else if (attr == "ambient") {
    return Float(lights.ambient);
  } else if (attr == "lights") {
    List lts;
    for(int l=0;l<lights.n_lights;l++)
      lts.append( asImmutableVector( lights.L[l] ) );
    return lts;
  }
  /*} else if (attr=="camera") {
    Vector range( scale.x ? 1.0/scale.x : 0.0,
                  scale.y ? 1.0/scale.y : 0.0,
                  scale.z ? 1.0/scale.z : 0.0 );

    Vector v = center - forward.norm().scale(range) / get_tanfov();
    return asImmutableVector(v);*/

  return getattr_methods(_attr);
}

int Display::setattr( const char *_attr, const Object& value ) {
  string attr = _attr;

  if (attr == "autoscale") {
    if (Int(value)) {
      write_lock L(mtx);
      autoscale_enabled = true;
    } else if (autoscale_enabled) {
      if (!device->closed()) {  // never *create* a window this way 
        device->frame();
        device->frame();
      }

      write_lock L(mtx);
      autoscale_enabled = false;
    }
  } else if (attr == "autocenter") {
    if (Int(value)) {
      write_lock L(mtx);
      autocenter_enabled = true;
    } else if (autocenter_enabled) {
      if (!device->closed()) {  // never *create* a window this way 
        device->frame();
        device->frame();
      }

      write_lock L(mtx);
      autocenter_enabled = false;
    }
  } else if (attr == "visible") {
    if (Int(value)) show();
    else hide();
  } else {
    write_lock L(mtx);

    if (attr == "title") {
      title = String(value);
      title_changed = true;
    } else if (attr == "center") {
      center = Vector(value);
    } else if (attr == "scale") {
      autoscale_enabled = 0;
      scale = Vector(value);
    } else if (attr == "forward") {
      Vector tfwd(value);
      if (tfwd.x == up.x && tfwd.y == up.y && tfwd.z == up.z)
        throw ValueError("display.forward may not be the same as display.up");
      forward = tfwd;
    } else if (attr=="up") {
      Vector tup(value);
      if (tup.x==forward.x && tup.y == forward.y && tup.z == forward.z)
        throw ValueError("display.up may not be the same as display.forward");
      up = tup;  

    } else if (attr=="fov") {
      double f = Float(value);
      if (!f) 
        throw ValueError("Orthogonal projection (fov=0) is not yet supported, use a small fov.\n");
      if (f<0 || f>=pi) 
        throw ValueError("fov must be between 0 and pi\n");
      fov = f;
    } else if (attr=="foreground") {
      foreground = rgb(value);
    } else if (attr=="background") {
      background = rgb(value);
    } else if (attr=="uniform") {
      uniform = Int(value) ? true : false;
    } else if (attr=="userzoom") {
      zoom_enabled = Int(value) ? true : false;
    } else if (attr=="userspin") {
      rotation_enabled = Int(value) ? true : false;
    } else if (attr=="range") {
      autoscale_enabled = 0;
      try {
        Vector range(value);
        scale.x = range.x ? 1.0/range.x : 0.0;
        scale.y = range.y ? 1.0/range.y : 0.0;
        scale.z = range.z ? 1.0/range.z : 0.0;
      } catch (TypeError& e) {
        e.clear();
        double range = Float(value);
        scale.x = scale.y = scale.z = range ? 1.0/range : 0.0;
      }
    } else if (attr=="x") {
      device->setX(Int(value));
    } else if (attr=="y") {
      device->setY(Int(value));
    } else if (attr=="width") {
      device->setWidth( Int(value) );
    } else if (attr=="height") {
      device->setHeight( Int(value) );
    } else if (attr=="minscale") {
      autoscale_min = Float(value);
    } else if (attr=="maxscale") {
      autoscale_max = Float(value);
    } else if (attr == "exit") {
      if (Int(value)) device->onClose(true);
      else device->onClose(false);
    } else if (attr == "ambient") {
      lights.ambient = Float(value);
    } else if (attr == "lights") {
      List lts(value);
      lights.n_lights = lts.size();
      for(int i=0;i<lights.n_lights;i++)
        lights.L[i] = Vector(lts[i]);
    } else if (attr == "newzoom") {
      device->setNewmouse(Int(value) ? true: false);
    } else           
      throw AttributeError(attr);
  }

  return 0;
}

void Display::fromDictionary(Dict d) {
  List items = d.items();
  for(List::iterator i = items.begin(); i != items.end(); i++) {
    Tuple it = Object(*i);
    string attr = String(it[0]);
    if (attr != "visible")
      setattr(attr.c_str(),it[1]);
  }

  if (d.hasKey("visible")) setattr("visible", d["visible"]);
}
