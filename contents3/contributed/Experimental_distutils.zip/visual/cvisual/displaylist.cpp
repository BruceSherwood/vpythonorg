#include "displaylist.h"
#include "display.h"
#ifdef MAC
#undef assert
#endif
#include "assert.h"
#include GL_INCLUDE   // just for glGenLists() below

/************ rView implementation ***********/

rView::rView(const tmatrix& _wct, const lighting& _lights,
      const tmatrix& _fwt, glContext& _cx,
      const Vector& mine, const Vector& maxe)
  : wct(_wct), fwt(_fwt), cx(_cx), lights(_lights)
{
  ext_set(mine, maxe);
}

rView::~rView() {
  //for(int i=0; i < sortlists.size(); i++)
  //  glDeleteLists(sortlists[i],1);
}

int rView::createSortList() {
  sortlists.push_back( glGenLists(1) );
  return sortlists.back();
}

void rView::absorb_local(rView& local) {
  ext_set(local.min_extent, local.max_extent);
  
  for(int i=0;i<local.sortlists.size();i++)
    sortlists.push_back( local.sortlists[i] );
  local.sortlists.clear();
}

void rView::ext_set(const Vector& mine, const Vector& maxe) {
  min_extent[0] = mine.x; min_extent[1] = mine.y; min_extent[2] = mine.z;
  max_extent[0] = maxe.x; max_extent[1] = maxe.y; max_extent[2] = maxe.z;
}

void rView::ext_brect(const tmatrix& mwt, Vector bmin, Vector bmax) {
  double b[] = {bmin.x, bmin.y, bmin.z,
                bmax.x, bmax.y, bmax.z};
  ext_brect(mwt,b);
}

void rView::ext_brect(const tmatrix& mft, const double *b) {
  tmatrix mwt(mft, fwt);
  for(int r=0; r<3; r++) {
    min_extent[r] = max_extent[r] = mwt[r][3];
    for(int c=0; c<3; c++) {
      if (mwt[r][c] < 0) {
        min_extent[r] += mwt[r][c] * b[c];
        max_extent[r] += mwt[r][c] * b[c+3];
      } else {
        max_extent[r] += mwt[r][c] * b[c];
        min_extent[r] += mwt[r][c] * b[c+3];
      }
    }
  }
}

void rView::ext_point(Vector v) {
  v = fwt * v;
  if (v.x < min_extent[0]) min_extent[0] = v.x;
  if (v.y < min_extent[1]) min_extent[1] = v.y;
  if (v.z < min_extent[2]) min_extent[2] = v.z;
  if (v.x > max_extent[0]) max_extent[0] = v.x;
  if (v.y > max_extent[1]) max_extent[1] = v.y;
  if (v.z > max_extent[2]) max_extent[2] = v.z;
}

void rView::ext_sphere(Vector v, double size) {
  v = fwt * v;
  if (v.x-size < min_extent[0]) min_extent[0] = v.x-size;
  if (v.y-size < min_extent[1]) min_extent[1] = v.y-size;
  if (v.z-size < min_extent[2]) min_extent[2] = v.z-size;
  if (v.x+size > max_extent[0]) max_extent[0] = v.x+size;
  if (v.y+size > max_extent[1]) max_extent[1] = v.y+size;
  if (v.z+size > max_extent[2]) max_extent[2] = v.z+size;
}

void rView::ext_circle(Vector p, Vector n, double r) {
  p = fwt * p;
  n = fwt.times_v(n);

  Vector d( r*sqrt(1 - n.x*n.x),
            r*sqrt(1 - n.y*n.y),
            r*sqrt(1 - n.z*n.z) );
  if (p.x-d.x < min_extent[0]) min_extent[0] = p.x-d.x;
  if (p.y-d.y < min_extent[1]) min_extent[1] = p.y-d.y;
  if (p.z-d.z < min_extent[2]) min_extent[2] = p.z-d.z;
  if (p.x+d.x > max_extent[0]) max_extent[0] = p.x+d.x;
  if (p.y+d.y > max_extent[1]) max_extent[1] = p.y+d.y;
  if (p.z+d.z > max_extent[2]) max_extent[2] = p.z+d.z;
}

/************ DisplayObject implementation **************/

DisplayObject::DisplayObject()
 : visible(0),
   display( 0 ),
   next(0),
   prev(0),
   parent(0)
{
  setDisplay( Display::selected );
}
 
DisplayObject::~DisplayObject() {
  setDisplay(0);
}

void DisplayObject::setDisplay(Display* n) {
  if (n!=display) {
    if (display && visible) remove();
    display = n;
    if (display && visible) insert(display->objects());
  }
}

void DisplayObject::setVisible(bool v) {
  if (v && !visible && display) {
    insert(display->objects());
  } else if (!v && visible && display) {
    remove();
  }

  visible=v;
}

void DisplayObject::insert(DisplayObject *head) {
  assert (!prev && !next);
  getObject().increment_reference_count();
  prev = head;
  DisplayObject::read_lock P(prev->mtx);
  next = head->next;
  prev->next = this;
  if (next) {
    DisplayObject::read_lock N(next->mtx);
    next->prev = this;
  }
  display->addObject(this);
}

void DisplayObject::remove() {
  if (prev) {
    DisplayObject::read_lock P(prev->mtx);
    prev->next = next;
  }
  if (next) {
    DisplayObject::read_lock N(next->mtx);
    next->prev = prev;
  }
  prev = next = 0;
  getObject().decrement_reference_count();;
}

void DisplayObject::setParent(DisplayObject *d, Object obj) {

  if (d && display != d->display) {
    throw RuntimeError("Attempt to set parent to object on different display");
  }

  parent = d;

  while (d) {
    d = d->parent;
    if (d == parent) {
      parent = 0;
      parentObject = Nothing();
      throw RuntimeError("Attempt to create a cycle of reference frames");
    }
  };

  parentObject = obj;
}
