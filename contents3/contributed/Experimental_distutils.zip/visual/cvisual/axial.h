#ifndef AXIAL_H
#define AXIAL_H

#include "prim.h"

class axialSymmetry : public Primitive {
  // axialSymmetry primitives define the radius and length attributes,
  //   but not height or width.
  protected:
    double radius;

    axialSymmetry() : radius(1) {}

    double getRadius() {
      return radius;
    }
    void setRadius(double r) {
      radius = r;
    }

    double getLength() {return axis->mag(); }
    void setLength(double l) {
      if (!*axis) throw ZeroDivisionError("Degenerate primitive");
      *axis = *axis * (l / axis->mag());
    }
    Vector getScale() {
      return Vector(axis->mag()*0.5,radius,radius);
    }
};

#endif
