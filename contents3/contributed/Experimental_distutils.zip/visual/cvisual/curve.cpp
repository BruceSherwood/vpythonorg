#include "platform.h"
#include "arrprim.h"
#include "thickline.h"

#include GL_INCLUDE    // see platform.h

class curve : public ArrayPrimitive {
  protected:  
    Array pos_data, color_data;
    int allocated, count;
    double radius;
    bool antialias;

  public:
    curve()
     : allocated(0), count(0), radius(0), antialias(false)
    {
      allocate(128);
      double *p = (double*)pos_data.to_C();
      p[0] = 0;
      p[1] = 0;
      p[2] = 0;

      double *c = (double*)color_data.to_C();
	  rgb fg = display->fgcolor();
      c[0] = fg.r;
      c[1] = fg.g;
      c[2] = fg.b;

      setLength(0);
    }

    virtual void fromDictionary(Dict d) {
      if (d.hasKey("pos")) {
        setPos(d["pos"]);
      } else if (d.hasKey("x")) {
        setLength( Sequence( d["x"] ).length() );
      } else if (d.hasKey("y")) {
        setLength( Sequence( d["y"] ).length() );
      } else if (d.hasKey("z")) {
        setLength( Sequence( d["z"] ).length() );
      } else if (d.hasKey("antialias")) {
        antialias = Int(d["antialias"]) ? true : false;
      }

      List items = d.items();
      for(List::iterator i = items.begin(); i != items.end(); i++) {
        Tuple it = Object(*i);
        string attr = String(it[0]);
        if (attr != "visible" && attr != "pos")
          setattr(attr.c_str(),it[1]);
      }

      if (d.hasKey("visible")) 
        setattr("visible",d["visible"]);
      else
        setVisible(1);
      
    }

    virtual Object py_append(const Tuple& args, const Dict& kw) {
      if (args.length())
        throw TypeError("append() requires keyword arguments (name=value)");

      setLength(count + 1);

      double *np = (double*)pos.to_C() + (count-1)*3;
      double *nc = (double*)color.to_C() + (count-1)*3;
      try {
        if (kw.hasKey("pos")) {
          Vector v(kw["pos"]);
          np[0] = v.x;
          np[1] = v.y;
          np[2] = v.z;
        }

        List items = kw.items();
        for(List::iterator i = items.begin(); i != items.end(); i++) {
          Tuple it = Object(*i);
          string attr = String(it[0]);
          if (attr[0]>='x' && attr[0]<='z' && attr.length() == 1) {
            Float v(it[1]);
            np[attr[0]-'x'] = v;
          } else if (attr == "color") {
			  if (!(Object(it[1]).is(Nothing()))) {
				Vector v(it[1]);
				nc[0] = v.x;
				nc[1] = v.y;
				nc[2] = v.z;
			  } else {
				rgb fg = display->fgcolor();
				nc[0] = fg.r;
				nc[1] = fg.g;
				nc[2] = fg.b;
			  }
          } else if (attr == "red") {
            Float v(it[1]);
            nc[0] = v;
          } else if (attr == "green") {
            Float v(it[1]);
            nc[1] = v;
          } else if (attr == "blue") {
            Float v(it[1]);
            nc[2] = v;
          } else if (attr != "pos") {
            throw AttributeError(attr);
          }
        }
      } catch(...) {
        setLength(count-1);
        throw;
      }

      return Nothing();
    }

    bool allocate(int n) {
      if (n > allocated) {
        n = n*2;
        int shape[] = {n, 3};
        pos_data = Array( 2, shape );
        color_data = Array( 2, shape );
        allocated = n;

        return true;
      } else
        return false;
    }

    void setLength(int length) {
      int npoints = count;
      if (npoints > length) npoints = length;
      if (!npoints) npoints = 1;

      Array old_pos = pos_data;
      Array old_color = color_data;
      
      if (allocate( length )) {
        // we have moved the buffer, copy the old points over
        memcpy(pos_data.to_C(), old_pos.to_C(), npoints*3*sizeof(double));
        memcpy(color_data.to_C(), old_color.to_C(), npoints*3*sizeof(double));
      }

      // copy the last old point over each new point
      double *oldp = (double*)old_pos.to_C()    + (npoints-1)*3;
      double *oldc = (double*)old_color.to_C()  + (npoints-1)*3;
      double *p    = (double*)pos_data.to_C()   + npoints*3;
      double *c    = (double*)color_data.to_C() + npoints*3;
      for( int i = npoints; i < length; i++ )
        for( int j = 0; j < 3; j++ ) {
          *p++ = oldp[j];
          *c++ = oldc[j];
        }

      /* set pos   = pos_data[0:length]
             color = color_data[0:length]
             count = length */
      Object s = slice(Int(0), Int(length));
      pos = Mapping(*pos_data)[ s ];
      color = Mapping(*color_data)[ s ];     
      count = length;
    }

    virtual void setRadius(double value) {
      radius = value;
    }

    virtual double getRadius() {
      return radius;
    }

    virtual void setPos(Object value) {
      Array v = asArray(value);
      if (v.rank()==1 && !v.dimension(1)) {
        setLength(0);
      } else if (v.rank()==2 && v.dimension(2)==3) {
        setLength( v.dimension(1) );
        Mapping(*pos).setItem(colon(), value);
      } else if (v.rank()==2 && v.dimension(2)==2) {
        setLength( v.dimension(1) );
        Tuple s(2);
        s.setItem(0, ellipsis());
        s.setItem(1, slice(Int(0),Int(2)));
        Mapping(*pos).setItem(s, value);
      } else {
        throw TypeError("pos must be an (N x 3) array");
      }
    }

    virtual void setColor(Object value) {
      Array v = asArray(value, PyArray_DOUBLE);

      if (v.rank() == 1 && v.dimension(1)==3) {
        // A single color.  Broadcast across all points.  If the
        //   curve is empty, fill in the 0th point anyway (default color).
        int npoints = count ? count : 1;

        double *d = (double*)color.to_C();
        double *vd = (double*)v.to_C();
        for(int i=0; i < npoints; i++) {
          for(int j=0; j < 3; j++)
            d[j] = vd[j];
          d += 3;
        }
      } else if (v.rank() == 1 && v.dimension(1)==0 && !count) {
      } else if (v.rank() == 2 && v.dimension(2)==3) {
        if (v.dimension(1) != count)
          throw TypeError("color must be the same length as pos.");

        double *d = (double*)color.to_C();
        double *vd = (double*)v.to_C();
        for(int i=0; i < count; i++) {
          for(int j=0; j < 3; j++)
            d[j] = vd[j];
          vd += 3;
          d += 3;
        }
      } else
        throw TypeError("color must be an (N x 3) array");
    }

    virtual void glRender(rView& view) {
      if (count<2) return;

      if (radius) {
        // xxx Experimental: antialiasing.  We need sorting and
        //     and alpha buffer to do this right.
        if (antialias)
          glEnable(GL_POLYGON_SMOOTH);

        thick_line(view,
                   (double*)pos.to_C(), 
                   (double*)color.to_C(), 
                   radius,
                   count);

        if (antialias)
          glDisable(GL_POLYGON_SMOOTH);
      } else {
        thin_line(view,
                   (double*)pos.to_C(), 
                   (double*)color.to_C(), 
                   count);
      }
    }
};

Object create_curve(const Tuple& args, const Dict& kwargs) {
  return init(new curve,args,kwargs);
}


static int hexa_pos_shape[] = {2,2,2,3},
           hexa_col_shape[] = {2,2,2,3};

class hexahedron : public ArrayPrimitive {
  public:
    hexahedron()
    {
      pos = Array( 4, hexa_pos_shape );
      color = Array(4, hexa_col_shape );

      double *p = (double*)pos.to_C();
      double *c = (double*)color.to_C();
      for(int x=0;x<2;x++)
        for(int y=0;y<2;y++)
          for(int z=0;z<2;z++) {
            p[0] = x;
            p[1] = y;
            p[2] = z;
            c[0] = x;
            c[1] = y;
            c[2] = z;
            p += 3;
            c += 3;
          }
    }

    virtual void glRender(rView &view) {
      static vertex projected[8];
      static double col[8*3];
      static int s[6][4] = { {1,3,0,2},
                             {0,4,1,5},
                             {0,2,4,6},
                             {5,7,1,3},
                             {6,2,7,3},
                             {4,6,5,7} };

      double *v = (double*)pos.to_C();
      double *c = (double*)color.to_C();

      // Projection and rendering
      for(int corner=0; corner<8; corner++) {
        view.ext_point(v);
        view.wct.project(v, projected[corner]);
        v += 3;
      }
      v = (double*)pos.to_C();

      glEnableClientState(GL_VERTEX_ARRAY);
      glEnableClientState(GL_COLOR_ARRAY);
      glVertexPointer(4, GL_DOUBLE, sizeof(vertex), &projected[0].x);
      glColorPointer(3, GL_DOUBLE, 3*sizeof(double), col);
      glShadeModel(GL_SMOOTH);
      glEnable(GL_CULL_FACE);

      for(int wokko = -1; wokko <= 1; wokko+=2) { // you are now leaving the asylum
        if (wokko > 0) glCullFace(GL_BACK);
        else glCullFace(GL_FRONT);
        for(int side=0; side<6; side++) {
          int *p = s[side];

          int z=p[0]*3, a=p[1]*3, b=p[2]*3;
          Vector A( v[a]-v[z], v[a+1]-v[z+1], v[a+2]-v[z+2] ),
                 B( v[b]-v[z], v[b+1]-v[z+1], v[b+2]-v[z+2] );
          Vector n = A.cross(B).norm0();
          
          double illum = view.lights.illuminate( n*wokko );

          for(int v=0; v<4; v++) {
            int i = p[v] + p[v] + p[v];
            col[ i + 0 ] = illum * c[ i + 0 ];
            col[ i + 1 ] = illum * c[ i + 1 ];
            col[ i + 2 ] = illum * c[ i + 2 ];
          }
          glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_INT, p);
        }
      }

      glDisable(GL_CULL_FACE);
    }
};

Object create_hexahedron(const Tuple& args, const Dict& kwargs) {
  return init(new hexahedron,args,kwargs);
}
