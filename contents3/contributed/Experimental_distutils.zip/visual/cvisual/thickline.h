#ifndef THICKLINE_H
#define THICKLINE_H

#include GL_INCLUDE    // see platform.h

const int curve_around = 4;

int* curve_slice() {
  static int s[512];
  static int initialized=0;
  if (!initialized) {
    for(int i=0;i<128;i++) {
      s[i*2] = i*curve_around;
      s[i*2+1] = i*curve_around + 1;
      s[i*2 + 256] = i*curve_around + (curve_around - 1);
      s[i*2 + 257] = i*curve_around;
    }
    initialized=1;
  }
  return s;
}

float* curve_sc() {
  static float s[curve_around*2];
  static int initialized = 0;
  if (!initialized) {
    for(int i=0;i<curve_around;i++) {
      s[i]              = cos(i * 2 * pi / curve_around);
      s[i+curve_around] = sin(i * 2 * pi / curve_around);
    }
    initialized=1;
  }
  return s;
}

void thick_line( rView& view,
                 double* v, double* color, double radius, int count ) 
{
  static vertex projected[1024 * curve_around];
  static float light[1024 * curve_around * 3];
  vertex *pr = projected;
  float *lt = light;

  float *cost = curve_sc(),
        *sint = cost + curve_around;

  //Vector lastx(0,1,0), lasty(0,0,1);
  Vector x, y, lastx, lasty;

  int step = (count+1023)/1024;
  int npoints = 0;
  for(int corner=0; corner<count/step; corner++) {
    view.ext_point(v);

    if (corner && corner+1 < count/step) {
      /* To construct the circle of vertices around a point on the curve,
         I need an orthonormal basis of the plane of the circle.  A and B,
         normalized vectors pointing toward the next and from the previous
         points on the curve, are vectors in the plane of the *curve* at 
         this point.  The cross product and the difference of these vectors
         are orthogonal and lie in the appropriate plane. */
      
      Vector A( v[3]-v[0], v[4]-v[1], v[5]-v[2] );
      Vector B( v[0]-v[-3], v[1]-v[-2], v[2]-v[-1] );
      x = (A.norm0()-B.norm0()).norm0();
      y = A.cross(B).norm0();
      if (!x || !y) {
        x = lastx;
        y = lasty;
      }
    } else if (corner) {
      Vector A( v[0]-v[-3], v[1]-v[-2], v[2]-v[-1] );
      A = A.norm0();
      x = A.cross(Vector(0,0,1));
      if (!x) x = A.cross(Vector(1,0,0));
      x = x.norm0();
      y = A.cross(x);
    } else {
      Vector A( v[3]-v[0], v[4]-v[1], v[5]-v[2] );
      A = A.norm0();
      x = A.cross(Vector(0,0,1));
      if (!x) x = A.cross(Vector(1,0,0));
      x = x.norm0();
      y = A.cross(x);
    }

    // experimental: kink prevention
    if (x.dot(lastx) < 0) x = x * -1.0;
    if (y.dot(lasty) < 0) y = y * -1.0;
    lastx = x; lasty = y;

    float lx[2], ly[2];
    for(int li=0;li<view.lights.n_lights;li++) {
      lx[li] = view.lights.L[li].dot( x );
      ly[li] = view.lights.L[li].dot( y );
    }

    x = x * radius;
    y = y * radius;

    npoints++;
    for(int a=0; a<curve_around; a++) {
      float c = cost[a], s = sint[a];

      float illum = view.lights.ambient;
      for(int li=0; li<view.lights.n_lights; li++) { 
        float dot = c*lx[li] + s*ly[li];
        if (dot>0) illum += dot;
      }

      Vector p( v[0], v[1], v[2] );
      view.wct.project(p + x*c + y*s, *pr++);
      *(lt++) = illum * color[0];
      *(lt++) = illum * color[1];
      *(lt++) = illum * color[2];
    }

    v += 3*step;
    color += 3*step;
  }

  glEnableClientState(GL_VERTEX_ARRAY);
  glEnableClientState(GL_COLOR_ARRAY);
  glShadeModel(GL_SMOOTH);

  int *ind = curve_slice();
  for(int a=0;a<curve_around;a++) {
    int ai = a;
    if (a==curve_around-1) {
      ind += 256;
      ai = 0;
    }

    for(int i=0; i<npoints; i+=127) {
      glVertexPointer(4, GL_DOUBLE, sizeof(vertex), &projected[i*curve_around + ai].x);
      glColorPointer(3, GL_FLOAT, sizeof(float)*3, &light[(i*curve_around + ai)*3] );

      if (npoints-i < 128) 
        glDrawElements(GL_TRIANGLE_STRIP, 2*(npoints-i), GL_UNSIGNED_INT, ind);
      else
        glDrawElements(GL_TRIANGLE_STRIP, 256, GL_UNSIGNED_INT, ind);
    }
  }
};

void thin_line( rView& view,
                 double* v, double* color, int count ) 
{
  static vertex projected[1024];
  int step = (count+1023)/1024;
  for(int corner=0; corner<count/step; corner++) {
    view.ext_point(v);
    view.wct.project(v, projected[corner]);
    v += 3*step;
  }

  glEnableClientState(GL_VERTEX_ARRAY);
  glEnableClientState(GL_COLOR_ARRAY);
  glVertexPointer(4, GL_DOUBLE, sizeof(vertex), &projected[0].x);
  glColorPointer(3, GL_DOUBLE, 3*sizeof(double)*step, color);
  glShadeModel(GL_SMOOTH);

  glDrawArrays(GL_LINE_STRIP, 0, count/step);
}

#endif
