#ifndef PLATWIN_H
#define PLATWIN_H

#ifdef __GNUC__ 
// For MinGW.  Not strictly required, it just makes preprocessing go faster.
#define WIN32_LEAN_AND_MEAN
#endif

/* 2003-02-17 Jonathan Brandmeyer
 * We cannot #include windows.h in namespace win, because it implicitly
 * includes stdarg.h.  This causes conflicts in the Python headers due to 
 * an inability to correctly type va_list. (win::va_list works )
 * This problem has been demonstrated on MSVC6/SP5 and MinGW 2.0.0.  
 * I don't know how we got away with it before.
 */
#include <windows.h>


class winCritSec {
  int count;
  CRITICAL_SECTION sec;

  public:
  typedef lock<winCritSec> lock;

  winCritSec(int spincount=0, int count=1);
  ~winCritSec();

  inline void sync_lock() { EnterCriticalSection(&sec); }
  inline void count_lock() { EnterCriticalSection(&sec); count++; }
  inline void sync_unlock() { LeaveCriticalSection(&sec); }
  inline int  sync_count() { return count; }

  void clear() { 
    sync_lock();
    count=0;
    sync_unlock();
  }
};

void _threaded_timer(double seconds, bool (*callback)(void*), void *data);

template <class T>
void threaded_timer(double seconds, bool (*callback)(T*), T* data) {
  _threaded_timer(seconds, (bool(*)(void*))callback, (void*)data);
}
  
#endif
