// Xgl - GTK platform-specific GL and windowing code

#ifndef XGL_H
#define XGL_H

#include "pvector.h"

#include <gdk/gdk.h>
#include <gtk/gtk.h>
#include <gtkgl/gtkglarea.h>

using namespace Py;

#include <map>
#include <string>

using namespace std;

#include "platlinux.h"
#include "glcontext.h"
#include <GL/gl.h>
#include <GL/glu.h>

struct xglFont : glFont {
 public:
  //from glFont
  virtual double getWidth(const char *text);
  virtual double ascent();
  virtual double descent();
  virtual void draw(const char *text);
  virtual void release();
  
  //used by xglContext
  xglFont(struct xglContext& cx, 
	  const char *name, 
	  double size);
  void addref() {refcount++;};
  
 private:
  struct xglContext& cx;
  int listBase;
  GdkFont *font;
  int refcount;
};

struct xglContext : glContext {
  public:
    void lockMouse();
    void unlockMouse();
    void showMouse() { printf("xgl.h: Someone should write showMouse!\n"); }
    void hideMouse() { printf("xgl.h: Someone should write hideMouse!\n"); }
    int  getMouseButtons();
    int  getMouseButtonsChanged();
    Vector  getMouseDelta();
    Vector  getMousePos();
    string getKeys();
    int getShiftKey();
    int getAltKey();
    int getCtrlKey();

    xglContext();
    ~xglContext();

    bool initWindow( const char* title, int x, int y, int width, int height );
    bool changeWindow( const char* title, int x, int y, int width, int height );
    bool isOpen();
    void cleanup();
  
    void makeCurrent();
    void makeNotCurrent();
    void swapBuffers();

    Vector origin();
    Vector corner();
    int width();
    int height();

    string lastError() { return error_message; }
    
    glFont* getFont(const char* description, double size);

  private:
    GtkWidget *window;
    GtkWidget *area;
    int wwidth, wheight;
    string error_message;

    int buttonState, buttonsChanged;
    Vector mousePos, oldMousePos;
    bool mouseLocked;
    vector<string> keys;

    static gint configure_cb(GtkWidget *widget, GdkEventConfigure *event,
                             gpointer data);
    static gint motion_notify_cb(GtkWidget *widget, GdkEventMotion *event,
                                 gpointer data);
    static gint delete_cb(GtkWidget *widget, GdkEvent *event, gpointer data);
    static gint button_press_cb(GtkWidget *widget, GdkEventButton *event,
                                gpointer data);
    static gint button_release_cb(GtkWidget *widget, GdkEventButton *event,
                                  gpointer data);
    static gint key_press_cb(GtkWidget *widget, GdkEventKey *key, 
                             gpointer data); 
    static gint key_release_cb(GtkWidget *widget, GdkEventKey *key, 
                               gpointer data);
};

#endif
