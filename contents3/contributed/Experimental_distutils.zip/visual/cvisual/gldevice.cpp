#include "gldevice.h"
#include "prim.h"

/***************** GLDevice *******************/

GLDevice::GLDevice()
: active(false),
manual_scale(1.0),
initx(-1), inity(-1),
initw(430), inith(430),
newmouse_enabled(1),
oldButtons(0),
clickDelta(clickTolerance),
mouse_mode(INITIALIZE),
last_mouse_mode(NOBUTTONS),
quitOnClose(0),
last_wct( tmatrix() )
{
	tmatrix z; 
	z.x_column(0,0,0);
	z.y_column(0,0,0);
	z.z_column(0,0,0);
	z.w_column(0,0,0);
	z.w_row(0,0,0);
	last_wct = z;
}

GLDevice::~GLDevice() {
	hide();
	join();
}

bool GLDevice::show() {
	if (active && mode==DISPLAY) 
		return true;
	
	mode = SHOW;
	addCallback();
	join();
	if (mode == DISPLAY) {
		addCallback();
		return true;
	} else {
		PySys_WriteStderr("OpenGL initialization failed.\n"
			"  %s\n", error_message.c_str());
		return false;
	}
	
	return false;
}

string GLDevice::info() {
	if (closed()) {
		return string("Renderer inactive.\n");
	} else {
		std::string s;
		s += "OpenGL renderer active.\n  Vendor: "
		  + vendor
		  + "\n  Version: " + version
		  + "\n  Renderer: " + renderer
		  + "\n  Extensions: ";
		
		// TODO: there has got to be a cleaner way to do this parsing.
		for(int count=0, p=0; extensions[p] && count<25; count++) {
			int space = extensions.find(' ', p);
			if (space == string::npos) space = extensions.size();
			string token(extensions, p, space-p);
			// TODO: find out why an extension label is limited to 39 characters.
			s += token.substr( 0, 39) + '\n';
			if (extensions[space]!=' ') break;
			p = space + 1;
		}
		return s;
	}
}

void GLDevice::hide() {
	mode = HIDE;
}

bool GLDevice::closed() {
	return !active;
}

void GLDevice::join() {
	while (active) {
		threaded_sleep(0.100);
	}
}

void GLDevice::frame() {
	if (closed()) {
		show();
		return;
	}
	mode = FRAME;
	join();
	if (mode == DISPLAY)
		addCallback();
}

void GLDevice::addCallback() {
	active = true;
	threaded_timer( 0, &GLDevice::callback, this );
}

void GLDevice::setX(int v) {
	if (active) throw RuntimeError("Window attributes are not accessible once the window has been created.\n");
	initx = v;
}
void GLDevice::setY(int v) {
	if (active) throw RuntimeError("Window attributes are not accessible once the window has been created.\n");
	inity = v;
}
void GLDevice::setWidth(int v) {
	if (active) throw RuntimeError("Window attributes are not accessible once the window has been created.\n");
	initw = v;
}
void GLDevice::setHeight(int v) {
	if (active) throw RuntimeError("Window attributes are not accessible once the window has been created.\n");
	inith = v;
}
void GLDevice::setNewmouse(bool tf) {
	newmouse_enabled = tf;
}

int GLDevice::getX() {
	if (active) throw RuntimeError("Window attributes are not accessible once the window has been created.\n");
	return initx;
}
int GLDevice::getY() {
	if (active) throw RuntimeError("Window attributes are not accessible once the window has been created.\n");
	return inity;
}
int GLDevice::getWidth() {
	if (active) throw RuntimeError("Window attributes are not accessible once the window has been created.\n");
	return initw;
}
int GLDevice::getHeight() {
	if (active) throw RuntimeError("Window attributes are not accessible once the window has been created.\n");
	return inith;
}

/******* The following methods are called from a threaded_timer, potentially
in parallel with calls to the preceding methods. *******************/

void GLDevice::getProjection(tmatrix& wct, Vector& cam) {
	double hfov, vfov;
	double aspect = double(cx.height()) / cx.width();
	if (aspect < 1.0) {
		hfov = display->tanfov;
		vfov = hfov * aspect;
	} else {
		vfov = display->tanfov;
		hfov = vfov / aspect;
	}
	double cotfov = 1.0 / display->tanfov;
	double ext = manual_scale * display->model.times_v(display->c_extent).mag();
	if (!ext) ext=1;	// if the scene is a point, any depth range will do!
	double farclip = cotfov + ext,
		nearclip = cotfov - ext*1.5;
	if (nearclip < 0.01*farclip) nearclip = 0.01*farclip;
	
	//tmatrix proj, iproj;
	double R = nearclip*hfov,
		T = nearclip*vfov;
	frustum(proj,iproj,-R,R,-T,T,nearclip,farclip);
	
	if (display->c_uniform) {
		manual.x_column(manual_scale,0,0);
		manual.y_column(0,manual_scale,0);
		manual.z_column(0,0,manual_scale);
	} else if (cx.height() < cx.width()) {
		manual.x_column(manual_scale,0,0);
		manual.y_column(0,manual_scale * cx.height() / cx.width(), 0);
		manual.z_column(0,0,manual_scale * cx.height() / cx.width());
	} else {
		manual.x_column(manual_scale * cx.width() / cx.height(), 0);
		manual.y_column(0,manual_scale,0);
		manual.z_column(0,0,manual_scale);
	}
	manual.w_column();
	manual.w_row();
	
	// wct = display->model o manual o display->view o proj
	tmatrix model(display->model, manual);
	tmatrix modelview(model, display->view);
	wct = tmatrix( modelview, proj );
	
	// the camera is at [0 0 0 1] in view space, so we
	//	 calculate (model^-1) (manual^-1) (view^-1) [0 0 0 1]T
	Vector iscale(1.0/manual[0][0], 1.0/manual[1][1], 1.0/manual[2][2]);
	cam = display->imodel * ((display->iview * Vector(0,0,0)).scale(iscale));
}

Vector GLDevice::calcMousePos(Vector mpos) {
	Vector p(mpos.x*2-1, 1-mpos.y*2, 0.5);
	p = (iproj * p)/iproj.w(p);
	/* p is in view space.	The camera is at [0,0,0]; the
	center is at c=[0 0 -1/tanfov].  We scale p so that
	p.z == -1/tanfov, without changing its direction. */
	p = p * (-1/display->tanfov) / p.z;
	
	p = display->iview * p;
	p.x /= manual[0][0]; p.y /= manual[1][1]; p.z /= manual[2][2];
	p = display->imodel * p;
	
	return p;
}

void GLDevice::mouseControl(Vector pos, Vector cam, Vector ray, Object pick, Vector pickpos) {
	Vector delta = cx.getMouseDelta(); // mouse movement in pixels
	unsigned buttons = cx.getMouseButtons();
	unsigned changed = cx.getMouseButtonsChanged();
	bool mevent = false;
	bool extraPRESS = false;
	int winh = cx.height();
	int winw = cx.width();
	cursorObject *curs = display->cursor.extensionObject();
	int Mshift = cx.getShiftKey();
	int Malt = cx.getAltKey();
	int Mctrl = cx.getCtrlKey();
	
	if (curs->visible != curs->last_visible) {
		curs->last_visible = curs->visible;
		if (curs->visible) {
			cx.showMouse();
		} else {
			cx.hideMouse();
		}
	}
	
  {
	  mouseObject *m = display->mouse.extensionObject();
	  mutex::lock L(m->mtx);
		m->position = pos;
		m->pick = pick;
		m->pickpos = pickpos;
		m->cam = cam;
		m->ray = ray;
		m->buttons = buttons;
		m->shift = Mshift;
		m->alt = Malt;
		m->ctrl = Mctrl;
		if (mouse_mode == INITIALIZE) {
			m->clickCount = 0;
			mouse_mode = NOBUTTONS;
		}
  }
	
	// Buttons: left down=1, right down=2, left & right down=3, (Windows) wheel down=4.
	// If zooming or rotating, don't want either down or up events to come through.
	
	buttons = (buttons & 7);
	
	switch (mouse_mode) {
	case NOBUTTONS:
		if (changed) {
			mouse_mode = PRESS;
			clickDelta = clickTolerance;
			mevent = true;
      if (!buttons) { // buttons have already been released
				extraPRESS = true;
        mouse_mode = CLICK;
        oldButtons = changed; // simulate earlier PRESS
			}
		}
		break;
	case PRESS:
    if (buttons && changed) {
      mevent = true;
    }
		if (!buttons && clickDelta>=0) {
			mouse_mode = CLICK;
			mevent = true;
		} else if (buttons==oldButtons && clickDelta<0) {
			if (display->c_rotation_enabled && (buttons==2)) {
				mouse_mode = SPIN;
			} else if (display->c_zoom_enabled && 
				(newmouse_enabled && (buttons==3 || buttons==4)) || 
				(!newmouse_enabled && (buttons == 1))) {
				mouse_mode = ZOOM;
			} else {
				mouse_mode = DRAG;
				mevent = true;
			}
		}
		clickDelta -= delta.mag();
		break;
	case DRAG:
		if (!buttons) {
			mouse_mode = DROP;
			mevent = true;
		} else if (display->c_rotation_enabled && (buttons==2)) {
			mouse_mode = SPIN;
		} else if (display->c_zoom_enabled && 
			(newmouse_enabled && (buttons==3 || buttons==4)) || 
			(!newmouse_enabled && (buttons == 1))) {
			mouse_mode = ZOOM;
		}
		break;	 
	}
	
	switch (mouse_mode) {
	case SPIN:
		{
			Vector forward = display->c_forward, up = display->c_up;
			tmatrix m;
			cx.lockMouse();
			clickDelta -= delta.mag();
			rotation(m, (delta.x/winw)*-2, up.norm());
			forward = m * forward;
			
			double ya = -(delta.y/winh)*2;
			double limit = acos( norm_dot(up,forward) );
			if (ya < limit-pi+0.01) ya=limit-pi+0.01;
			if (ya > limit-0.01) ya=limit-0.01;
			
			rotation(m, ya, forward.cross(up).norm());
			forward = m * forward;
			display->setForward( forward );
		}
		if (buttons!=2) {
			if (buttons==0) {
				mouse_mode = NOBUTTONS;
				if (last_mouse_mode==DRAG) {
					mouse_mode = DROP;
					mevent = true;
				}
				cx.unlockMouse();
			} else if (buttons==3 || buttons==4) {
				mouse_mode = ZOOM;
			} else if (buttons==oldButtons) {
				mouse_mode = last_mouse_mode;
				cx.unlockMouse();
			} else { // must be new (buttons==1)
				mouse_mode = PRESS;
				clickDelta = clickTolerance;
				mevent = true;
				cx.unlockMouse();
			}
		}
		break;
	case ZOOM:
		cx.lockMouse();
		clickDelta -= delta.mag();
		manual_scale *= pow(10, -delta.y/winh);
		if (!(buttons==3 || buttons==4)) {
			if (buttons==0) {
				mouse_mode = NOBUTTONS;
				if (last_mouse_mode==DRAG) {
					mouse_mode = DROP;
					mevent = true;
				}
				cx.unlockMouse();
			} else if (buttons==2) {
				mouse_mode = SPIN;
			} else if (buttons==oldButtons) {
				mouse_mode = last_mouse_mode;
				cx.unlockMouse();
			} else { // must be new (buttons==1)
				mouse_mode = PRESS;
				clickDelta = clickTolerance;
				mevent = true;
				cx.unlockMouse();
			}
		}
		break;
	}

  		// Extra PRESS event, immediately preceding a CLICK event
		if (extraPRESS) {
			clickObject *c = new clickObject();
			bool clicked = false;
			c->position = pos;
			c->pick = pick;
			c->pickpos = pickpos;
			c->cam = cam;
			c->ray = ray;
			c->buttons = changed;
			c->press = changed;
			c->click = 0;
			c->drag = 0;
			c->drop = 0;
			c->release = 0;
			c->shift = Mshift;
			c->alt = Malt;
			c->ctrl = Mctrl;
      {
      mouseObject *m = display->mouse.extensionObject();
	    mutex::lock L(m->mtx);

			m->clicks.push_back(ExtensionObject<clickObject>(FromAPI(c)));
      m->clickList.push_back(0);
      }
      // A click event uses the info from the press event:
			lastEvent.position = pos;
			lastEvent.pick = pick;
			lastEvent.pickpos = pickpos;
			lastEvent.cam = cam;
			lastEvent.ray = ray;
		}
	
		// Real mouse event, not just zoom or rotate
		if (mevent) {
			clickObject *c = new clickObject();
			bool clicked = false;
			c->position = pos;
			c->pick = pick;
			c->pickpos = pickpos;
			c->cam = cam;
			c->ray = ray;
			c->buttons = buttons;
			c->press = 0;
			c->click = 0;
			c->drag = 0;
			c->drop = 0;
			c->release = 0;
			c->shift = Mshift;
			c->alt = Malt;
			c->ctrl = Mctrl;
			
			switch (mouse_mode) {
			case PRESS:
				c->press = buttons;
				lastEvent.position = pos;
				lastEvent.pick = pick;
				lastEvent.pickpos = pickpos;
				lastEvent.cam = cam;
				lastEvent.ray = ray;
				break;
			case CLICK:
				c->click = oldButtons;
				c->release = oldButtons;
				mouse_mode = NOBUTTONS;
				clicked = (oldButtons == 1);
				c->position = lastEvent.position; //report original press state
				c->pick = lastEvent.pick;
				c->pickpos = lastEvent.pickpos;
				c->cam = lastEvent.cam;
				c->ray = lastEvent.ray;
				break;
			case DRAG:
				c->drag = buttons;
				c->position = lastEvent.position; // report original press state
				c->pick = lastEvent.pick;
				c->pickpos = lastEvent.pickpos;
				c->cam = lastEvent.cam;
				c->ray = lastEvent.ray;
				break;
			case DROP:
				c->drop = oldButtons;
				c->release = oldButtons;
				mouse_mode = NOBUTTONS;
				break;
			}
			oldButtons = buttons;
			last_mouse_mode = mouse_mode;
      {
      mouseObject *m = display->mouse.extensionObject();
	    mutex::lock L(m->mtx);

			m->clicks.push_back(ExtensionObject<clickObject>(FromAPI(c)));
			if (clicked) {
				m->clickCount += 1;
			}
			m->clickList.push_back(clicked);
      }
		}
				
}

void GLDevice::kbControl() {
	kbObject *kb = display->kb.extensionObject();
	mutex::lock L(kb->mtx);
	while (1) {
		string s = cx.getKeys();
		if (s == "") break;
		kb->keys.push_back(s);
	}
}

int GLDevice::render() {
	if (mode == HIDE) {
		cx.cleanup();
		return -1;
	}
	
	{ DisplayObject::read_lock D(display->mtx);
	display->updateCache();
	}
	
	if (mode == SHOW) {
		if( !cx.initWindow(display->c_title.c_str(),initx,inity,initw,inith))
		{
			error_message = cx.lastError();
			return -1;
		}
		cx.makeCurrent();
		vendor = (const char*)glGetString(GL_VENDOR);
		version = (const char*)glGetString(GL_VERSION);
		renderer = (const char*)glGetString(GL_RENDERER);
		extensions = (const char*)glGetString(GL_EXTENSIONS);
		cx.makeNotCurrent();
		mode = DISPLAY;
		return -1;
	}
	
	if (!cx.isOpen()) {
		cx.cleanup();
		if (quitOnClose)
			threaded_exit(0);
		return -1;
	}
	
	if (display->c_title_changed)
		cx.changeWindow( display->c_title.c_str(), -1, -1, -1, -1 );
	
	cx.makeCurrent();
	glDepthMask(GL_TRUE);
	glViewport( 0, 0, cx.width(), cx.height() );
	glClearColor( display->bgcolor.r, display->bgcolor.g, display->bgcolor.b, 1 );
	glClearDepth( 1 );
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glEnable(GL_DEPTH_TEST);
	glDepthFunc( GL_LEQUAL );
	glDisable(GL_BLEND);
	
	tmatrix wct;
	Vector cam;
	getProjection(wct, cam);
	last_wct = wct;
	
	Vector mpos = calcMousePos(cx.getMousePos());
	Vector ray = (mpos - cam).norm0();
	double best_intersect = 1e300;
	Object pick;
	int i;
	Vector min_ext(display->c_center), max_ext(display->c_center);
	rView view(wct, display->lights, tmatrix::identity(), cx, min_ext, max_ext);
	
	DisplayListIterator p(display->objects());
	for(p++; p; p++) {
		p->updateCache();
    Vector local_cam = cam, local_ray = ray;
		
		DisplayObject* parent = p->getParent();
		if (parent) {
			tmatrix iframe, frame = parent->getChildTransform();
			iframe.invert_ortho(frame);
      local_cam = iframe * cam;
      local_ray = iframe.times_v( ray );
			rView local( tmatrix(frame, wct),
				lighting(view.lights, iframe),
				frame, cx,
				view.min_extent,
				view.max_extent );
			p->glRender( local );
			
			view.absorb_local( local );
			
		} else
			p->glRender( view );
		
		if (view.min_extent[0] < min_ext.x) min_ext.x = view.min_extent[0];
		if (view.min_extent[1] < min_ext.y) min_ext.y = view.min_extent[1];
		if (view.min_extent[2] < min_ext.z) min_ext.z = view.min_extent[2];
		if (view.max_extent[0] > max_ext.x) max_ext.x = view.max_extent[0];
		if (view.max_extent[1] > max_ext.y) max_ext.y = view.max_extent[1];
		if (view.max_extent[2] > max_ext.z) max_ext.z = view.max_extent[2];
		
		double dist = p->rayIntersect(local_cam, local_ray);
		if (dist>0.0 && dist < best_intersect) {
			best_intersect = dist;
			pick = p->getObject();
		}
	};
	
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glDepthMask(GL_FALSE);
	
	for(i=0;i<view.sortlists.size();i++)
		glCallList(view.sortlists[i]);
	for(i=0;i<view.sortlists.size();i++)
		glDeleteLists(view.sortlists[i],1);
	
	display->setRegion(min_ext, max_ext);
	
	//glColor4f(1,1,1,1);
	//glRasterPos2f( -1, -1 );
	//cx.glPrintf(cx.sysFont, "%d", cx.getMouseButtons());
	
	cx.swapBuffers();
	cx.makeNotCurrent();
	
	mouseControl(mpos, cam, ray, pick, cam + ray*best_intersect);
	kbControl();
	
	if (mode == FRAME) {
		mode = DISPLAY;
		return -1;
	}
	
	return 33;
}

bool GLDevice::callback( GLDevice *dev ) {
	if (dev->active) {
		try {
			int next = dev->render();
			if ( next >= 0 ) {
				threaded_timer( next*1e-3, &GLDevice::callback, dev );
			} else {
				dev->active = false;
			}
		} catch (...) {
			dev->active = false;
		}
	}
	
	return false;  // don't call me again
}
