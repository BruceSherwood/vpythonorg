#include "cvisual.h"
#include "display.h"
#include "mouseobject.h"
#include "kbobject.h"
#include "gldevice.h"
#include "prim.h"
#include "arrprim.h"
#include "label.h"
#include "rate.h"

const char * copyright = "Copyright 2000 David Scherer.  All Rights Reserved.";

Object create_sphere(const Tuple& args, const Dict& kwargs);
Object create_ring(const Tuple& args, const Dict& kwargs);
Object create_box(const Tuple& args, const Dict& kwargs);
Object create_cylinder(const Tuple& args, const Dict& kwargs);
Object create_cone(const Tuple& args, const Dict& kwargs);
Object create_arrow(const Tuple& args, const Dict& kwargs);
Object create_hexahedron(const Tuple& args, const Dict& kwargs);
Object create_curve(const Tuple& args, const Dict& kwargs);
Object create_convex(const Tuple& args, const Dict& kwargs);
Object create_frame(const Tuple& args, const Dict& kwargs);
Object create_label(const Tuple& args, const Dict& kwargs);
Object create_faces(const Tuple& args, const Dict& kwargs);

#define CALLF(what) Object what(const Tuple& args, const Dict& kwargs) {  \
      return ::what(args,kwargs); \
    }

#define CREATEF(what) CALLF(create_##what)

class cvisual_module : public ExtensionModule<cvisual_module> {
  public:
    cvisual_module();

    virtual ~cvisual_module() {}

  private:
    Object create_display(const Tuple& args, const Dict& kwargs) {
      Display *d = new Display(*new GLDevice());
      return init(d,args,kwargs);
    }

    Object handle_event(const Tuple& args, const Dict& kwargs) {
      return Int(::handle_event(*args[0]));
    }

    Object shutdown(const Tuple& args, const Dict& kwargs) {
      Display::shutdown();
      return Nothing();
    }

    Object waitclose(const Tuple& args, const Dict& kwargs) {
      Display::waitclose();
      return Nothing();
    }

    Object allclosed(const Tuple& args, const Dict& kwargs) {
      return Int( Display::allclosed() ? 1 : 0 );
    }

    Object rate(const Tuple& args, const Dict& kwargs) {
      if (args.length() != 1) throw TypeError("Incorrect number of arguments.");

      float freq = Float(args[0]);
      if (freq<=0.0) throw ValueError("Frequency must be positive.");
      
      static rate_timer *rt;
      if (!rt) rt = new rate_timer();

      rt->delay(1.0 / freq);

      return Nothing();
    }

    CREATEF(hexahedron);
    CREATEF(curve);
    CREATEF(convex);
    CREATEF(frame);
    CREATEF(label);
    CREATEF(box);
    CREATEF(sphere);
    CREATEF(ring);
    CREATEF(cylinder);
    CREATEF(cone);
    CREATEF(arrow);
    CREATEF(faces);
    CREATEF(vector);
    CREATEF(immutableVector);
    CALLF(vector_mag);
    CALLF(vector_mag2);
    CALLF(vector_norm);
    CALLF(vector_cross);
    CALLF(vector_rotate);
};

cvisual_module::cvisual_module() 
 : ExtensionModule<cvisual_module>("cvisual")
{
  init_platform();
  
  import_array();

  Vector::init_type();
  clickObject::init_type();
  mouseObject::init_type();
  kbObject::init_type();
  cursorObject::init_type();
  Display::init_type();
  Primitive::init_type();
  ArrayPrimitive::init_type();
  Label::init_type();

  add_keyword_method("vector", &cvisual_module::create_vector, "vector([x,y[,z]]) = [x,y,z]");
  add_keyword_method("constant_vector", &cvisual_module::create_immutableVector, "constant_vector([x,y[,z]]) = (x,y,z)");
  add_keyword_method("mag", &cvisual_module::vector_mag, "mag(v) = |v|");
  add_keyword_method("mag2", &cvisual_module::vector_mag2, "mag2(v) = |v|**2");
  add_keyword_method("norm", &cvisual_module::vector_norm, "norm(v) = v/|v|");
  add_keyword_method("cross", &cvisual_module::vector_cross, "cross(a,b) = a x b");
  add_keyword_method("rotate", &cvisual_module::vector_rotate, "rotate(v, angle=radians, axis=[0,0,1]) rotates v angle radians around axis");

  add_keyword_method("shutdown", &cvisual_module::shutdown, "");
  add_keyword_method("waitclose", &cvisual_module::waitclose, "");
  add_keyword_method("allclosed", &cvisual_module::allclosed, "");
  add_keyword_method("rate", &cvisual_module::rate, "");

  add_keyword_method("display", &cvisual_module::create_display, "");
  add_keyword_method("box", &cvisual_module::create_box, "");
  add_keyword_method("sphere", &cvisual_module::create_sphere, "");
  add_keyword_method("ring", &cvisual_module::create_ring, "");
  add_keyword_method("cylinder", &cvisual_module::create_cylinder, "");
  add_keyword_method("cone", &cvisual_module::create_cone, "");
  add_keyword_method("arrow", &cvisual_module::create_arrow, "");
  add_keyword_method("hexahedron", &cvisual_module::create_hexahedron, "");
  add_keyword_method("curve", &cvisual_module::create_curve, "");
  add_keyword_method("convex", &cvisual_module::create_convex, "");
  add_keyword_method("frame", &cvisual_module::create_frame, "");
  add_keyword_method("label", &cvisual_module::create_label, "");
  add_keyword_method("faces", &cvisual_module::create_faces, "");
  add_keyword_method("_handleevent", &cvisual_module::handle_event, "");

  initialize("cvisual module - visual implementation in C++");

  Dict d = moduleDictionary();
  d["VectorType"] = Type((PyObject*)Vector::type_object());
}

extern "C"
void cvisual_DLL initcvisual() {
  new cvisual_module();
}
