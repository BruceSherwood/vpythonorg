#ifndef PLATFORM_H
#define PLATFORM_H

// The following are platform-specific fixes for various
//   name conflicts and spurious warnings, that need to
//   be fixed at the very top of every file
#pragma warning( disable : 4786 )   // identifier truncated

#ifdef __MWERKS__
#include "mac.h"
#endif

#ifdef __GNUC__
  #include <iostream>
  #define lock thread_lock
#endif  

#include <string>
#include "vthread.h"

void init_platform();
  // Called when the module initializes.  It should only
  //   perform initialization that cannot safely be 
  //   deferred to another function such as threaded_timer,
  //   or which is very inexpensive.
  // Any required finalization should be performed by an
  //   atexit() handler.

void threaded_sleep(double seconds);   
  // Releases the Python interpreter lock and sleeps for
  //   seconds, then reacquires the lock.  Do not call this if
  //   you do not have the interpreter lock!
  // In a single-thread environment, this should permit
  //   other programs to run and handle callbacks.

void nothread_sleep(double seconds);  
  // Sleeps without doing anything with the interpreter
  //   lock.  This should generally only be called when
  //   you do not have the lock.
  // In a single-thread environment, this should at least
  //   allow other programs to run.

double sclock();
  // Returns a time value in seconds.  The origin is
  //   undefined.

template <class T>
void threaded_timer(double seconds, bool (*callback)(T*), T* data);
  // Calls callback(data) after seconds.  All callbacks are
  //   called from the same thread, but this need not be
  //   the calling thread.  threaded_timer() may be safely
  //   called from the main thread, and it may be safely
  //   called from a callback.

void threaded_exit(int status);
  // A callback may call this function to terminate the
  //   program.  It may terminate immediately, or it
  //   may return and terminate the program only after
  //   the callback has returned.

bool handle_event(struct _object* os_event);
  // Handle an event structure passed back from Python.  On
  //   platforms which do not use Python code to handle events,
  //   this function should do nothing.
  // If the event was handled, and should not be passed to further
  //   event handlers, return true.

// Per-platform 

#if _MSC_VER || _WIN32    // Microsoft Visual C++ 6.0 || MinGW
  #include "platwin.h"
  typedef winCritSec mutex;

  //#include "platnothread.h"
  //typedef noCritSec mutex;

  #define GL_INCLUDE "wgl.h"
  #define platform_glContext wglContext
  #define cvisual_DLL __declspec(dllexport)
#endif

#if __GNUC__ && !_WIN32 // GCC's other than MinGW or Cygwin.
  #include "platlinux.h"
  typedef gMutex mutex;

  #define GL_INCLUDE "xgl.h"
  #define platform_glContext xglContext
  #define cvisual_DLL
  #define LINUX
#endif

#ifdef MAC          // Macintosh (CodeWarrior)
  /*** Fix name collision with 'mutex' ***/
  #include <msl_mutex>
  #define mutex MUTEX
  /***************************************/

  #include "platnothread.h"
  typedef noCritSec mutex;

  #define GL_INCLUDE "aglcx.h"
  #define platform_glContext aglContext
  #define cvisual_DLL __declspec(dllexport)
#endif

#endif
