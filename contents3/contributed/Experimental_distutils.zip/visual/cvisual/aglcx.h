#ifndef AGL_H
#define AGL_H

#include "platform.h"
#include "glcontext.h"
#include "agl.h"


struct aglFont : glFont {
  public:
    // Documentation for these functions is in glFont, not here.
    virtual double getWidth(const char* string);
    virtual double ascent();
    virtual double descent();
    virtual void draw(const char* string);
    virtual void release();

    // For the use of aglContext only:
    aglFont( struct aglContext& cx,
             /* These parameters should specify the font: */
             int fontID, Style face, int size);
    void addref() {refcount++;}

  private:
    struct aglContext& cx;
    int listBase;
    int refcount;

    /* Specify the font: */
    int fontID;
    Style face;
    int size;

    /* XXX any extra information you need to store.  For example,
       you might precompute values for ascent and descent */
       
    int fAscent;
    int fDescent;
    int fWidth;
};


struct aglContext : glContext {
  public:
    virtual void lockMouse();
    virtual void unlockMouse();
    virtual void showMouse();
    virtual void hideMouse();
    virtual int  getMouseButtons();
    virtual int  getMouseButtonsChanged();
    virtual int getShiftKey();
    virtual int getAltKey();
    virtual int getCtrlKey();
    virtual Vector  getMouseDelta();
    virtual Vector  getMousePos();
    virtual string getKeys() { return string(""); }

    aglContext();
    virtual ~aglContext();

    virtual bool initWindow( const char* title, int x, int y, int width, int height );
    virtual bool changeWindow( const char* title, int x, int y, int width, int height );
    virtual bool isOpen();
    virtual void cleanup();
  
    virtual void makeCurrent();
    virtual void makeNotCurrent();
    virtual void swapBuffers();

    virtual Vector origin();   // of entire window (or, same as initWindow())
    virtual Vector corner();   // of entire window (or, same as initWindow())
    virtual int width();       // of GL area
    virtual int height();      // of GL area

    virtual string lastError();

    virtual glFont* getFont(const char* description, double size);
      // xxx need to document parameters!
      
    static bool handleEvent( struct EventRecord* event );
      // return true if the event has been handled (eaten), false if
      //   it should be passed on to other libraries

  private:
    int current;

    AGLContext context, last_context;
    AGLDrawable drawable, last_drawable;
    
    int buttonState, buttonChanged;
    int Kshift, Kalt, Kctrl; //true if down when mouse event happens
    Vector mousePos, mouseDelta;
    bool mouseLocked;
    vector<string> keys;

    bool handleMouseDown( struct EventRecord* event, int windowCode );
    bool handleMouseUp( struct EventRecord* event, int windowCode );
    bool handleUpdate( struct EventRecord* event );
    
    static map< AGLDrawable, aglContext* > windowMap;
    static aglContext* get( AGLDrawable d );  
    
    std::map< std::pair<string, double>, aglFont* > fontCache;
    friend struct aglFont;

};



#endif
