#ifndef CURVE_H
#define CURVE_H


#include "display.h"

class ArrayPrimitive : public PythonExtension<ArrayPrimitive>, public DisplayObject {
  public:
    ArrayPrimitive();

    virtual Object getattr( const char *attr );
    virtual int setattr( const char* attr, const Object& value );

    virtual void refreshCache();

    static void init_type();

    virtual void fromDictionary(Dict d);
      // Initializes attributes from the given dictionary.  May throw
      //   exceptions.

    virtual void setPos(Object value);
    virtual void setColor(Object value);
    virtual void setNormal(Object value);
    virtual Array getNormal();
    virtual void setRadius(double value);
    virtual double getRadius();
    virtual Object py_append(const Tuple& args, const Dict& kwargs); 

    virtual Object getObject() { return Object(this); }

  protected:
    Array pos;
    Array color;
    Dict  user;
};

#endif
