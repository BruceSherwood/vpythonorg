#ifndef NULLPLAT_H
#define NULLPLAT_H

class nullMutex {
  int count;

  public:
  typedef lock<nullMutex> lock;

  nullMutex(int spincount=0, int _count=1) : count(_count) {}

  ~nullMutex() {}

  inline void sync_lock() {}
  inline void count_lock() { count++; }
  inline void sync_unlock() {}
  inline int sync_count() { return count; }

  void clear() {
    count=0;
  }
};

#endif
