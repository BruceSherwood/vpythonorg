#ifndef MOUSEOBJECT_H
#define MOUSEOBJECT_H

#include "cvisual.h"

class clickObject : public PythonExtension<clickObject> {
  public:
    Vector position;
    Vector cam;
    Vector ray;
    Object pick;
    Vector pickpos;
  	int buttons;
    int press, release, click, drag, drop;
	int ctrl, alt, shift;

    clickObject();

    static void init_type();
    virtual Object getattr( const char * attr );

    Object py_project(const Tuple&, const Dict&);
};

class mouseObject : public PythonExtension<mouseObject> {
  public:
    mutex mtx;

    Vector position;
    Vector cam;
    Vector ray;
    Object pick;
    Vector pickpos;
  	int buttons;
    int press, release, click, drag, drop;
	int ctrl, alt, shift;
    
    vector< ExtensionObject<clickObject> > clicks;
    int clickCount; // number of queued events which are left clicks
    vector<bool> clickList;

    mouseObject();
    static void init_type();
    virtual Object getattr( const char * attr );
    virtual int setattr( const char * attr, const Object& value );
    
    Object py_getevent(const Tuple&);
    Object py_getclick(const Tuple&);
    Object py_project(const Tuple&, const Dict&);
};

class cursorObject : public PythonExtension<cursorObject> {
  public:
    mutex mtx;

    int visible; // whether cursor should be visible
    int last_visible; // previous state of cursor visibility

    cursorObject();
    static void init_type();
    virtual Object getattr( const char * attr );
    virtual int setattr( const char * attr, const Object& value );

};

#endif
