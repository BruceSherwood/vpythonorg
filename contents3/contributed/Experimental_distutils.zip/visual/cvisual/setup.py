#!/usr/bin/env python
# To use:
#       python setup.py install
#
import sys
if not hasattr(sys, 'version_info') or sys.version_info < (2,0,0,'alpha',0):
    raise SystemExit, "Python 2.0 or later required to build VPython."
import distutils
from distutils.core import setup, Extension
from popen2 import Popen3

p = Popen3("gtk-config --cflags gtk gthread")
p.wait()
if (p.childerr):
    err = p.childerr.read()
    if (err):
        raise ValueErr("Unexpected %s on gtk-config stderr",`err`)
gtkconfig = p.fromchild.read()
extra_compile_args = gtkconfig.split()
extra_compile_args.append("-w")

p = Popen3("gtk-config --libs gtk gthread")
p.wait()
if (p.childerr):
    err = p.childerr.read()
    if (err):
        raise ValueErr("Unexpected %s on gtk-config stderr",`err`)
gtkconfig = p.fromchild.read()
extra_link_args = gtkconfig.split()
extra_link_args.append("-fPIC")

setup (name = "visual",
         packages = ["visual"],
	 include_dirs = ["CXX/Include"],
         ext_modules = [Extension('cvisualmodule',
['cvisual.cpp',
'arrow.cpp',
'arrprim.cpp',
'box.cpp',
'color.cpp',
'cone.cpp',
'convex.cpp',
'curve.cpp',
'cylinder.cpp',
'display.cpp',
'displaylist.cpp',
'faceset.cpp',
'frame.cpp',
'gldevice.cpp',
'kbobject.cpp',
'label.cpp',
'light.cpp',
'mouseobject.cpp',
'platlinux.cpp',
'prim.cpp',
'pvector.cpp',
'rate.cpp',
'ring.cpp',
'sphere.cpp',
'tmatrix.cpp',
'vcache.cpp',
'xgl.cpp',
'CXX/Src/cxx_extensions.cxx',
'CXX/Src/cxxextensions.c',
'CXX/Src/cxxsupport.cxx'],
    extra_compile_args = extra_compile_args,
    extra_link_args = extra_link_args,
    libraries = ["GL","gtkgl"])
    
                     ]
       )


