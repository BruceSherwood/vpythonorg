#include "axial.h"
#include GL_INCLUDE    // see platform.h

class arrow : public axialSymmetry {
  double getRadius() {
    throw AttributeError("radius");
  }
  void setRadius(double r) {
    throw AttributeError("radius");
  }

  int fixedwidth;

  int getFixedWidth() {
	return fixedwidth;
  }
  void setFixedWidth(int fw) {
	fixedwidth = fw;
  }

  double getShaftWidth() {
    getScale();
    return eff_sw;
  }
  void setShaftWidth(double r) {
    radius = r;
  }

  double headwidth, headlength;
  double eff_sw, eff_hw, eff_hl;

  double getHeadWidth() {
    getScale();
    return eff_hw;
  }
  void setHeadWidth(double r) {
    headwidth = r;
  }

  double getHeadLength() {
    getScale();
    return eff_hl;
  }
  void setHeadLength(double r) {
    headlength = r;
  }

  public:
    arrow() : fixedwidth(0), headwidth(0), headlength(0) { radius = 0.0; }

    Vector getScale() {
      double length = axis->mag();

      // Rules:
      //   min_sw     <= shaftwidth/length    <= max_sw
      //   min_hw     <= headwidth/shaftwidth <= max_hw
      //   min_aspect <= headlength/headwidth <= max_aspect
      //                 headlength/length    <= max_hl
      double min_sw = 0.02,    default_sw = 0.1,   max_sw = 0.25;
      double min_hw = 1,       default_hw = 2,     max_hw = 10;
      double min_aspect = 0.2, default_aspect = 1.5, max_aspect = 10;
      double max_hl = 0.5;

      // shaftwidth is radius
      if (!radius)
        eff_sw = length * default_sw;
      /*else if (radius > length * max_sw)
        eff_sw = length * max_sw;
      else if (radius < length * min_sw)
        eff_sw = length * min_sw;*/
      else
        eff_sw = radius;

      if (!headwidth)
        eff_hw = eff_sw * default_hw;
      /*else if (headwidth > eff_sw * max_hw)
        eff_hw = eff_sw * max_hw;
      else if (headwidth < eff_sw * min_hw)
        eff_hw = eff_sw * min_hw;*/
      else
        eff_hw = headwidth;

      if (!headlength)
        eff_hl = eff_hw * default_aspect;
      /*else if (headlength > eff_hw * max_aspect)
        eff_hl = eff_hw * max_aspect;
      else if (headlength < eff_hw * min_aspect)
        eff_hl = eff_hw * min_aspect;*/
      else
        eff_hl = headlength;

      if (fixedwidth) {
		  if (eff_hl > max_hl*length) {
			  eff_hl = max_hl*length;
		  }
	  }
	  else {
		  if (eff_sw < length * min_sw) {
			  double r = length * min_sw / eff_sw;
			  eff_sw *= r;
			  eff_hw *= r;
			  eff_hl *= r;
		  }
		  if (eff_hl > length * max_hl) {
			  double r = length * max_hl / eff_hl;
			  eff_sw *= r;
			  eff_hw *= r;
			  eff_hl *= r;
		  }
	  }

      return Vector(length, eff_hw/2, eff_hw/2);
    }

    virtual void glRender(rView &view) {
      if (degenerate) return;

      static double brect[] = { 1.0,  1.0,  1.0,
                                0.0, -1.0, -1.0};
      view.ext_brect(mwt, brect);

      tmatrix mct(mwt,view.wct);

      float X = 1.0 - eff_hl/scale.x;

      float nr = 1.0 / sqrt(eff_hw*eff_hw/4 + eff_hl*eff_hl),
            nc = eff_hw/2 * nr,
            ns = eff_hl * nr;

      // Calculate the lighting on each face.
      float L[10];
      for(int i=0;i<10;i++) 
        L[i] = view.lights.ambient;
      for(int l=0;l<view.lights.n_lights;l++) {
        Vector lt = wlt * view.lights.L[l];

        // For the axis-aligned normals, the dot products are
        //   e.g. [1 0 0]T * lt = lt.x
        if (lt.x < 0)                  L[2]-=lt.x;
        if (lt.y > 0) L[3]+=lt.y; else L[1]-=lt.y;
        if (lt.z > 0) L[4]+=lt.z; else L[0]-=lt.z;

        // For the faces of the head, the normals 
        //   are [nc +/-ns 0]T or [nc 0 +/-ns].  The dot products
        //   degenerate accordingly:
        lt.x *= nc;
        lt.y *= ns;
        lt.z *= ns;
        if (lt.x >  lt.z) L[6] += lt.x - lt.z;
        if (lt.x >  lt.y) L[7] += lt.x - lt.y;
        if (lt.x > -lt.y) L[8] += lt.x + lt.y;
        if (lt.x > -lt.z) L[9] += lt.x + lt.z;
      }
      L[5] = L[2];

      static int s[10][4] = { {1,3,0,2},         // shaft
                              {0,4,1,5},
                              {0,2,4,6},
                              {6,2,7,3},
                              {4,6,5,7},
                              {10,11,8,9},       // back of head
                              {12,8,9,       -1},  // front of head (triangles)
                              {12,10,8,      -1},
                              {12,9,11,      -1},
                              {12,11,10,     -1} };

      static vertex projected[13];
      float shf = eff_sw / eff_hw;
      float v[13][3] = { { 0.0, -shf, -shf },  // shaft
                         {   X, -shf, -shf },
                         { 0.0,  shf, -shf },
                         {   X,  shf, -shf },
                         { 0.0, -shf,  shf },
                         {   X, -shf,  shf },
                         { 0.0,  shf,  shf },
                         {   X,  shf,  shf },

                         {   X, -1.0,  -1.0 },   // head
                         {   X,  1.0,  -1.0 },
                         {   X, -1.0,   1.0 },
                         {   X,  1.0,   1.0 },

                         { 1.0,  0.0,   0.0 }    // tip
                       };

      // Projection and rendering
      for(int corner=0; corner<13; corner++)
        mct.project(v[corner], projected[corner]);

      glEnableClientState(GL_VERTEX_ARRAY);
      glDisableClientState(GL_COLOR_ARRAY);
      glVertexPointer(4, GL_DOUBLE, sizeof(vertex), &projected[0].x);
      glShadeModel(GL_FLAT);

      for(int side=0; side<10; side++) {
        float c = L[side];
        glColor3f(c*color.r,c*color.g,c*color.b);
        glDrawElements(GL_TRIANGLE_STRIP, s[side][3]<0 ? 3 : 4, GL_UNSIGNED_INT, s[side]);
      }
    }
};
Object create_arrow(const Tuple& args, const Dict& kwargs) {
  return init(new arrow,args,kwargs);
}
