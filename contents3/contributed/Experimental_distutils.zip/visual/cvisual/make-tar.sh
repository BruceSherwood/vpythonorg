#!/bin/sh

if [ ! -e visual ]; then
	ln -s ../visual
fi

if [ ! -e Programs ]; then
	ln -s ../Programs
fi

export VERSION=`head -n 1 visual/__init__.py |
		sed -e 's,\"Visual-\([^-]*\)-\([^-]*\)-\([^-]*\)\",\1.\2.\3,'`

rm -rf python-visual-*

mkdir -p python-visual-$VERSION/visual
mkdir -p python-visual-$VERSION/Programs/Demos
mkdir -p python-visual-$VERSION/Programs/Physics

cp -R Makefile CXX *.cpp *.h debian python-visual-$VERSION
cp visual/*.py python-visual-$VERSION/visual
cp Programs/Demos/*.py python-visual-$VERSION/Programs/Demos
#cp Programs/Physics/*.py python-visual-$VERSION/Programs/Physics
tar -czf python-visual-$VERSION.tar.gz python-visual-$VERSION

rm -r python-visual-$VERSION

fakeroot dpkg-buildpackage

if [ -h visual ]; then
	rm visual
fi

if [ -h Programs ]; then
	rm Programs
fi
