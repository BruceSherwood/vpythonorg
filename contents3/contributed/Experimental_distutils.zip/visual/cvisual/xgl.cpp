#include <stdio.h>

#include "xgl.h"

#define clamp(x, a, b) (__max(a, __min(x,b) ))

/**************** xglFont implementation *******************/

xglFont::xglFont(struct xglContext& _cx, 
		 const char *name, 
		 double size) 
 : cx(_cx), refcount(1)
{
  font = gdk_font_load(name);
  if (!font) {
    font = gdk_font_load("-misc-fixed-medium-r-*-*-*-120-*-*-*-*-*-*");
  }
  if (!font) {
    return;
  }
  gdk_font_ref(font);

  cx.makeCurrent();
  listBase = glGenLists(256);
  gdk_gl_use_gdk_font(font, 0, 255, listBase);
  cx.makeNotCurrent();
}

void xglFont::draw(const char *c) {
  if (font) {
    glListBase(listBase);
    glCallLists(strlen(c), GL_UNSIGNED_BYTE, c);
  }
}

double xglFont::getWidth(const char *c) {
  int width, ascent, descent, lbearing, rbearing;
  gdk_string_extents(font, c, &lbearing, &rbearing, &width, &ascent, &descent);
  return double(width*2) / cx.width();
}

double xglFont::ascent() {
  if (font)
    return double(font->ascent) / cx.height();
  else
    return 0;
}

double xglFont::descent() {
  if (font)
    return double(font->descent) / cx.height();
  else
    return 0;
}

void xglFont::release() {
  refcount--;
  if (!refcount) {
    gdk_font_unref(font);
    delete(this);
  }
}

glFont* xglContext::getFont(const char* description, double size) {
  return new xglFont(*this, description, size);
}


/*************** xglContext implementation *************/

xglContext::xglContext() 
 : window(NULL),
   area(NULL),
   buttonState(0),
   buttonsChanged(0),
   mouseLocked(false)
{
}

xglContext::~xglContext() {
  cleanup();
}

gint xglContext::configure_cb(GtkWidget *widget,
                              GdkEventConfigure *event,
                              gpointer data) {
  xglContext *c = (xglContext *)data;
  c->wwidth = event->width;
  c->wheight = event->height;

  return TRUE;
}

gint xglContext::motion_notify_cb(GtkWidget *widget,
                                         GdkEventMotion *event,
                                         gpointer data) {
  xglContext *c = (xglContext *)data;
  c->mousePos.x = event->x;
  c->mousePos.y = event->y;

  return TRUE;
}

gint xglContext::delete_cb(GtkWidget *widget, GdkEvent *event, gpointer data) {
  xglContext *c = (xglContext *)data;
  c->cleanup();
  return TRUE;
}

gint xglContext::button_press_cb(GtkWidget *widget, GdkEventButton *event,
                                 gpointer data) 
{
  xglContext *c = (xglContext *)data;

  /* Dave and X don't agree about button labels */
  if (event->button == 2)
    event->button = 3;
  else if (event->button == 3)
    event->button = 2;

  c->buttonState |= (0x1 << (event->button - 1));
  c->buttonsChanged |= (0x1 << (event->button -1));

  return TRUE;
}

gint xglContext::button_release_cb(GtkWidget *widget, GdkEventButton *event,
                                 gpointer data) 
{
  xglContext *c = (xglContext *)data;

  /* Dave and X don't agree about button labels */
  if (event->button == 2)
    event->button = 3;
  else if (event->button == 3)
    event->button = 2;

  c->buttonState &= ~(0x1 << (event->button - 1));
  c->buttonsChanged |= (0x1 << (event->button -1));

  return TRUE;
}

gint xglContext::key_press_cb(GtkWidget *window, GdkEventKey *key, gpointer d) {
  xglContext *cx = (xglContext*)d;
  cx->keys.push_back(string(key->string)); 
  return TRUE;
}

gint xglContext::key_release_cb(GtkWidget *window, GdkEventKey *key, gpointer d)
{
  return TRUE;
}


int xglContext::getShiftKey() {
	return 0;
}

int xglContext::getAltKey() {
	return 0;
}

int xglContext::getCtrlKey() {
	return 0;
}


bool xglContext::changeWindow(const char* title, int x, int y, int width, int height) {
  return false;
}

bool xglContext::initWindow(const char* title, int x, int y, int width, int height) {
  cleanup();

  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(window), title);
  gtk_container_set_border_width(GTK_CONTAINER(window), 0);

  int attrlist[] = {
    GDK_GL_RGBA,
    GDK_GL_DOUBLEBUFFER,
    GDK_GL_DEPTH_SIZE, 12,
    GDK_GL_NONE
  };

  if (!(area = GTK_WIDGET (gtk_gl_area_new(attrlist)))) {
    error_message = "Unable to create OpenGL display widget";
    cleanup();
    return false;
  }

  gtk_container_add (GTK_CONTAINER (window), area);

  gtk_widget_set_events(GTK_WIDGET (area),
                        GDK_EXPOSURE_MASK |
                        GDK_BUTTON_PRESS_MASK |
                        GDK_BUTTON_RELEASE_MASK |
                        GDK_POINTER_MOTION_MASK);

  gtk_signal_connect(GTK_OBJECT(window), "configure_event",
                     GTK_SIGNAL_FUNC(&xglContext::configure_cb),
                     (gpointer)this);
  gtk_signal_connect(GTK_OBJECT(area), "motion_notify_event",
                     GTK_SIGNAL_FUNC(&xglContext::motion_notify_cb),
                     (gpointer)this);
  gtk_signal_connect(GTK_OBJECT(window), "delete_event",
                     GTK_SIGNAL_FUNC(&xglContext::delete_cb), (gpointer)this);
  gtk_signal_connect(GTK_OBJECT(area), "button_press_event",
                     GTK_SIGNAL_FUNC(&xglContext::button_press_cb),
                     (gpointer)this);
  gtk_signal_connect(GTK_OBJECT(area), "button_release_event",
                     GTK_SIGNAL_FUNC(&xglContext::button_release_cb),
                     (gpointer)this);
  gtk_signal_connect(GTK_OBJECT(window), "key_press_event",
                     GTK_SIGNAL_FUNC(&xglContext::key_press_cb),
                     (gpointer)this);
  gtk_signal_connect(GTK_OBJECT(window), "key_release_event",
                     GTK_SIGNAL_FUNC(&xglContext::key_release_cb),
                     (gpointer)this);

  gtk_gl_area_size(GTK_GL_AREA(area), width, height);
  wwidth = width;
  wheight = height;

  // Init fonts:

  /*
  makeCurrent();
  SelectObject (hdc, GetStockObject (SYSTEM_FONT));
  sysFont = glGenLists(256);
  wglUseFontBitmaps(hdc, 0, 256, sysFont);
  makeNotCurrent();
  */

  // Init mouse cursor:

  /*
  POINT p; 
  GetCursorPos(&p);
  mousePos.x = p.x;
  mousePos.y = p.y;
  */

  gtk_widget_show_all (window);

  return true;
}

bool xglContext::isOpen() {
  return window != NULL;
}

void xglContext::cleanup() {
  if (area) {
    gtk_widget_destroy (area);
    area = NULL;
  }
  if (window) {
    gtk_widget_destroy (window);
    window = NULL;
  }
  wwidth = 0;
  wheight = 0;
}

void xglContext::lockMouse() {
}

void xglContext::unlockMouse() {
}

Vector xglContext::getMousePos() {
  if (!window) return Vector(0,0,0);

  Vector tmp = mousePos;
  tmp.x /= wwidth;
  tmp.y /= wheight;

  return tmp;
}

Vector xglContext::getMouseDelta() { // GL units (% of window)
  Vector tmp = mousePos - oldMousePos;
  oldMousePos = mousePos;
/*   tmp.x /= wwidth;
  tmp.y /= wheight; */

  return tmp;
}

int xglContext::getMouseButtons() {
  return buttonState;
}

int xglContext::getMouseButtonsChanged() {
  int c = buttonsChanged;
  buttonsChanged = 0;
  return c; 
}

string xglContext::getKeys() {
  if (keys.size()) {
    string s = keys[0];
    keys.erase(keys.begin());
    return s;
  } 
  return string("");
}

void xglContext::makeCurrent() {
  gtk_gl_area_make_current (GTK_GL_AREA (area));
}

void xglContext::makeNotCurrent() {
}

void xglContext::swapBuffers() {
  gtk_gl_area_swapbuffers (GTK_GL_AREA (area));
}

Vector xglContext::origin() {
  /* FIXME */
  return Vector(0,0,0);
}

Vector xglContext::corner() {
  return origin() + Vector(wwidth,wheight);
}

int xglContext::width() {
  return wwidth;
}

int xglContext::height() {
  return wheight;
}
