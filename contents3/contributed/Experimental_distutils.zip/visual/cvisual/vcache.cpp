#include "vcache.h"

Cache::Cache()
 : lastRefresh(0)
{
}

Cache::~Cache() {
}

int Cache::lastChange() {
  return mtx.sync_count();
}

void Cache::updateCache() {
  // If the primitive has changed since cache was last refreshed
  int change = mtx.sync_count();
  if (change != lastRefresh) {
    lastRefresh = change;
    refreshCache();
  }
}
