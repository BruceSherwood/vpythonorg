#ifndef DISPLAYLIST_H
#define DISPLAYLIST_H

#include "cvisual.h"
#include "vcache.h"
#include "tmatrix.h"
#include "light.h"

struct rView {
  tmatrix wct;
  lighting lights;
  struct glContext& cx;

  tmatrix fwt;   // frame-to-world (for extent calculations)
  double min_extent[3];
  double max_extent[3];

  vector<int> sortlists;

  rView(const tmatrix& _wct, const lighting& _lights,
        const tmatrix& _fwt, struct glContext& _cx,
        const Vector& mine, const Vector& maxe);
  ~rView();

  void ext_set(const Vector& mine, const Vector& maxe);
  void ext_brect(const tmatrix& mwt, Vector bmin, Vector bmax);
  void ext_brect(const tmatrix& mft, const double *b);
  void ext_point(Vector v);
  void ext_sphere(Vector v, double size);
  void ext_circle(Vector p, Vector n, double r);

  void absorb_local( rView& local );

  int createSortList();
    // returns an OpenGL display list number that can be used to store
    //   rendering commands to be rendered after all opaque objects have
    //   been drawn.  At some point there may be depth sorting support as
    //   well.
    // Usage:
    //   glNewList( view.createSortList(), GL_COMPILE);
    //   ...
    //   glEndList();
};

class DisplayObject : public Cache {
  public:
    DisplayObject();
    ~DisplayObject();

    virtual void glRender(rView&) = 0;
    virtual double rayIntersect(const Vector &camera, const Vector &ray) { 
      return 0.0;
    }

    virtual tmatrix getChildTransform() { return tmatrix::identity(); }
      // must return an orthogonal matrix

    virtual Object getObject() { return Nothing(); };
    DisplayObject *getParent() { return parent; }

  protected:
    bool  visible;
    class Display* display;
    DisplayObject *parent;
    Object parentObject;

    void setDisplay(class Display*);
    void setVisible(bool);
    void setParent(DisplayObject *d = 0, Object obj = Nothing());

    // linked list
    DisplayObject *next;
    DisplayObject *prev;
    void insert(DisplayObject* head);
    void remove();

    friend class Display;
    friend class DisplayListIterator;
};

class DisplayListIterator {
  private:
    DisplayObject *ptr;
    friend class Display;

    void lock() {
      if (ptr) ptr->mtx.sync_lock();
    }

    void unlock() {
      if (ptr) ptr->mtx.sync_unlock();
    }

    void next() {
      DisplayObject *n = ptr->next;
      if (n) n->mtx.sync_lock();
      ptr->mtx.sync_unlock();
      ptr = n;
    }

  public:
    DisplayListIterator( DisplayObject *head ) : ptr(head) { lock(); };
    ~DisplayListIterator() { unlock(); }

    operator bool() { return ptr!=NULL; }
    bool operator != (const DisplayListIterator &a) { return ptr != a.ptr; }
    void operator ++ () {
      next();
    }
    void operator ++ (int) {
      next();
    }
    DisplayObject& operator *() { return *ptr; }
    DisplayObject* operator->() { return ptr; }
};

class DisplayListHead : public DisplayObject {
  private:
    DisplayListHead() {};
    
    virtual void refreshCache() {}
    virtual void glRender(rView&) {}

    friend class Display;
};

struct vertex {
  double x,y,z,w;
};

template <class Primitive>
Object init(Primitive *p, const Tuple& args, const Dict& kwargs) {
  Object ob = asObject(p);
  if (args.length() != 0) 
    throw TypeError("Keyword arguments required (name=value)");
  p->fromDictionary(kwargs);
  return ob;
}

#endif
