#include "CXX_Objects.h"
#include "CXX_Extensions.h"

namespace Py {

class coercionWrapper : public PythonExtension<coercionWrapper> {
  public:
    Object lhs;
    PythonExtensionBase* p;

    coercionWrapper(const Object& _lhs, PythonExtensionBase *_p) 
     : lhs(_lhs), p(_p) {
       Py_INCREF(p);
     }

    ~coercionWrapper() {
      Py_DECREF(p);
    }

    inline void test_rhs( const Object& rhs ) {
      if (rhs.ptr() != p)
        throw TypeError("Coercion failed");
    }

    static void init_type(void) {
      static int initialized = 0;
      if (!initialized) {
        behaviors().name("coercionWrapper");
        behaviors().doc("Internal type: If you can read this, you are too close!");
        behaviors().supportNumberType();
        behaviors().supportCompare();
        initialized=1;
      }
    };

    static PyObject* unwrap( PyObject* x ) {
      // x might be a coercionWrapper, in which case we should return 
      //   the wrapped (lhs) object.  Otherwise, we return x.
      if (check(x)) {
        return static_cast<coercionWrapper*>(x)->lhs.ptr();
      } else
        return x;
    }

    virtual Object number_add( const Object& rhs ) {
      test_rhs(rhs);
      return p->rhs_add( lhs );
    }

    virtual Object number_subtract( const Object& rhs ) {
      test_rhs(rhs);
      return p->rhs_subtract( lhs );
    }

    virtual Object number_multiply( const Object& rhs ) {
      test_rhs(rhs);
      return p->rhs_multiply( lhs );
    }

    virtual Object number_divide( const Object& rhs ) {
      test_rhs(rhs);
      return p->rhs_divide( lhs );
    }

    virtual Object number_true_divide( const Object& rhs ) {
      test_rhs(rhs);
      return p->rhs_divide( lhs );
    }

    virtual Object number_remainder( const Object& rhs ) {
      test_rhs(rhs);
      return p->rhs_remainder( lhs );
    }

    virtual Object number_divmod( const Object& rhs ) {
      test_rhs(rhs);
      return p->rhs_divmod( lhs );
    }

    virtual Object number_lshift( const Object& rhs ) {
      test_rhs(rhs);
      return p->rhs_lshift( lhs );
    }

    virtual Object number_rshift( const Object& rhs ) {
      test_rhs(rhs);
      return p->rhs_rshift( lhs );
    }

    virtual Object number_and( const Object& rhs ) {
      test_rhs(rhs);
      return p->rhs_and( lhs );
    }

    virtual Object number_or( const Object& rhs ) {
      test_rhs(rhs);
      return p->rhs_or( lhs );
    }

    virtual Object number_xor( const Object& rhs ) {
      test_rhs(rhs);
      return p->rhs_xor( lhs );
    }

    virtual Object number_power( const Object& rhs, const Object& m ) {
      test_rhs(rhs);
      return p->rhs_power( lhs, Object(unwrap(m.ptr())) );
    }

    // xxx compare should probably go; doesn't work
    virtual int compare( const Object &rhs ) {
      test_rhs(rhs);
      return p->rhs_compare(lhs);
    }
};

}
