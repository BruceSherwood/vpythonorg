#ifndef PVECTOR_H
#define PVECTOR_H

#include "platform.h"
#include "CXX_Objects.h"
#include "CXX_Extensions.h"
#include "CXX_Array.h"
#include "CXX_RHS.h"
#include <math.h>

#if defined(VECTOR_EXPORTS)
  #define vector_DLL __declspec(dllexport)
#elif defined(_MSC_VER)
  #define vector_DLL __declspec(dllimport)
#else
  #define vector_DLL
#endif

using namespace Py;

#pragma warning( disable: 4275 )  // base class not imported/exported - OK (I think)
class vector_DLL Vector : public PythonExtension<Vector> {
  public:
    double x,y,z;

    Vector(double _x=0, double _y=0, double _z=0); 

    Vector(const double xyz[3]);

    Vector(const Vector& v);

    explicit Vector(const Object& o);

    static Vector asVector(const Object& o);

    static void init_type(void);

    // C++ access
    double mag2() const { return x*x+y*y+z*z; }
    double mag() const { return sqrt(x*x+y*y+z*z); }
    bool operator!() const {
      return !x && !y && !z;
    }
    Vector operator+(const Vector& v) const { 
      return Vector(x+v.x, y+v.y, z+v.z); 
    }
    Vector operator-(const Vector& v) const {
      return Vector(x-v.x, y-v.y, z-v.z);
    }
    Vector operator*(double d) const {
      return Vector(x*d, y*d, z*d);
    }
    Vector operator/(double d) const {
      if (!d) throw ZeroDivisionError("vector division");
      d = 1.0 / d;
      return Vector(x*d, y*d, z*d);
    }
    void operator=(const Vector& v) {
      x = v.x; y = v.y; z = v.z;
    }
    Vector scale(const Vector& v) const {
      return Vector(x*v.x, y*v.y, z*v.z);
    }
    Vector scaleInverse(const Vector& v) const {
      return Vector(x/v.x, y/v.y, z/v.z);
    }
    double dot(const Vector& b) const {
      return x*b.x + y*b.y + z*b.z;
    }
    Vector cross(const Vector& b) const {
      return Vector(y*b.z-b.y*z,
                    z*b.x-b.z*x,
                    x*b.y-b.x*y);
    }
    Vector norm() const {
      double i = mag();
      if (!i) throw ZeroDivisionError("vector division");
      i = 1.0 / i;
      return Vector(x*i, y*i, z*i);
    }
    Vector norm0() const {
      double i = mag();
      if (i) i = 1.0 / i;
      return Vector(x*i, y*i, z*i);
    }
    // String conversions
    Object str();
    Object repr();

    // Unary arithmetic
    virtual int number_nonzero();
    virtual Object number_negative();
    virtual Object number_positive();
    virtual Object number_absolute();

    // Binary arithmetic
    virtual Object number_add(const Object& rhs);
    virtual Object rhs_add(const Object& lhs);
    virtual Object number_subtract(const Object& rhs);
    virtual Object rhs_subtract(const Object& lhs);
    virtual Object number_multiply( const Object& rhs );
    virtual Object rhs_multiply( const Object& lhs );
    virtual Object number_divide( const Object& rhs );
    virtual Object number_true_divide( const Object& rhs );
    virtual Object rhs_divide( const Object& lhs );
    virtual Object rhs_true_divide( const Object& lhs );

    // Conversions (unsupported)
    virtual Object number_int();
    virtual Object number_float();
    virtual Object number_long();
    virtual Object number_oct();
    virtual Object number_hex();

    // Unsupported operations
    virtual Object number_remainder( const Object& rhs );
    virtual Object number_divmod( const Object& rhs );
    virtual Object number_invert();
    virtual Object number_lshift( const Object& rhs );
    virtual Object number_rshift( const Object& rhs );
    virtual Object number_and( const Object& rhs );
    virtual Object number_xor( const Object& rhs );
    virtual Object number_or( const Object& rhs );
    virtual Object number_power( const Object& p, const Object& m );
    virtual Object rhs_remainder( const Object& rhs );
    virtual Object rhs_divmod( const Object& rhs );
    virtual Object rhs_lshift( const Object& rhs );
    virtual Object rhs_rshift( const Object& rhs );
    virtual Object rhs_and( const Object& rhs );
    virtual Object rhs_xor( const Object& rhs );
    virtual Object rhs_or( const Object& rhs );
    virtual Object rhs_power( const Object& p, const Object& m );

    // Attributes
    virtual Object getattr( const char * attr );
    virtual int setattr( const char* attr, const Object& value );
    Object py_rotate(const Tuple& t, const Dict& kw);
  
    virtual int compare( const Object& rhs );

    // Sequence methods
    virtual int sequence_length();
    virtual Object sequence_item( int n );
    virtual int sequence_ass_item( int n, const Object & value);
    virtual Object sequence_slice(int,int);
    virtual int sequence_ass_slice(int,int,const Object&);
    virtual Object sequence_concat( const Object& rhs );
    virtual Object sequence_repeat( int );
};

class immutableVector : public Vector {
  public:
    immutableVector(double _x=0, double _y=0, double _z=0) 
     : Vector(_x,_y,_z) {}

    immutableVector(const Vector& v) 
     : Vector(v) {}

    explicit immutableVector(const Object& o) 
     : Vector(o) {}

    // overrides setattr to refuse modification

    virtual int setattr( const char* attr, const Object& value ) {
      throw TypeError("This vector cannot be changed.");
    }
};

inline static Object asImmutableVector( const Vector& v ) {
  return asObject( new immutableVector(v) );
}

template < class Owner, class Lock >
class lockedVector : public Vector {
  public:
    Owner * owner;

    lockedVector( Owner* _owner, const Vector& v )
      : owner(_owner), Vector(v) {}
    
    void clearOwner() { owner = 0; }

    virtual int setattr( const char* attr, const Object& value ) {
      if (owner) {
        Lock L(*owner);
        return Vector::setattr(attr, value);
      } else {
        return Vector::setattr(attr, value);
      }
    }
};

template <class Owner, class Lock>
class lockedVectorPtr {
  lockedVector<Owner,Lock>* v;

  public:
  lockedVectorPtr(Owner& owner, const Vector& value)
   : v(new lockedVector<Owner,Lock>(&owner, value)) {}

  explicit lockedVectorPtr(Owner& owner, double x=0, double y=0, double z=0)
   : v(new lockedVector<Owner,Lock>(&owner, Vector(x,y,z))) {}

  ~lockedVectorPtr() {
    v->clearOwner();
    Py_DECREF(v);
  }

  operator Vector*() { return v; }
  Vector* operator->() { return v; }
  Vector& operator*() { return *v; }

  void operator=(const Vector& u) {
    v->x = u.x; v->y = u.y; v->z = u.z;
  }
  
  private: // and unimplemented
  lockedVectorPtr(const lockedVectorPtr&);
  void operator=(const lockedVectorPtr&);
};

Object create_vector(const Tuple& args, const Dict& kw);
Object create_immutableVector(const Tuple& args, const Dict& kw);

Object vector_mag(const Tuple& args, const Dict& kw);
Object vector_mag2(const Tuple& args, const Dict& kw);
Object vector_norm(const Tuple& args, const Dict& kw);
Object vector_cross(const Tuple& args, const Dict& kw);
Object vector_rotate(const Tuple& args, const Dict& kw);

#endif
