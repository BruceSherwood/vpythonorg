#ifndef LABEL_H
#define LABEL_H

#include "display.h"
#include "color.h"
#include "tmatrix.h"
#include "glcontext.h"

class Label : public PythonExtension<Label>, 
              public DisplayObject
{
  public:
    Label();
    ~Label();

    virtual void fromDictionary(Dict d);
      // Initializes attributes from the given dictionary.  May throw
      //   exceptions.

    virtual Object getattr( const char *attr );
    virtual int setattr( const char* attr, const Object& value );
    virtual Object str();

    virtual void refreshCache();

    static void init_type();
      // Initializes the Python type for Labels

    virtual Object getObject() { return Object(this); }

    virtual void glRender(rView &view);

  protected:
    // In world space:
    lockedVectorPtr<mutex, write_lock> pos;
    double space;

    // In pixels:
    double xoffset,   // offset from pos to box
           yoffset,
           border,    // space between text and box
           clip;      // minimum space between box and screen edge

    string font_description;
    double font_height;

    bool box_enabled, line_enabled;

    glFont* font;
    double textWidth;
    rgb color, lineColor;
    double opacity;
    Dict user;
    vector<string> text;  
};

#endif
