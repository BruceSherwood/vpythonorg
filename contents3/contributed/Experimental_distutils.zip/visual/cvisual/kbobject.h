#ifndef KBOBJECT_H
#define KBOBJECT_H

#include "cvisual.h"

class kbObject : public PythonExtension<kbObject> {
 public:
  mutex mtx;
  vector<string> keys;
  
  kbObject() {};
  static void init_type();
  Object getattr(const char *attr);
  Object py_getkey(const Tuple&);
};

#endif
