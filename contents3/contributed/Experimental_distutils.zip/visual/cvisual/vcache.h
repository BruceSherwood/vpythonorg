#ifndef VCACHE_H
#define VCACHE_H

#include "platform.h"

class Cache {
  public:
    typedef lock<mutex> read_lock;
    typedef counted_lock<mutex> write_lock;
    mutex mtx;

    Cache();
    virtual ~Cache();

    void updateCache();
      // Called to ensure that the cache is up to date.
      // The caller should hold a read_lock or write_lock first!

    int lastChange();
      // returns a number that increases when write_lock is taken.

  protected:
    virtual void refreshCache() = 0;
      // Called by updateCache() when the cache needs to be refreshed.
      // Returns true if the object should remain in its container, and false
      //   otherwise.

    int lastRefresh; // lastChange() when refreshCache() was last called
};

#endif
