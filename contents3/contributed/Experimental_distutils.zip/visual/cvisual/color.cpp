#include "color.h"

/************* rgb implementation ************/

rgb::rgb() {
  r = g = b = 1.0;
}

rgb::rgb(float _r, float _g, float _b)
 : r(_r), g(_g), b(_b)
{
}

rgb::rgb(const Object& o) {
  if (!o.isSequence())
    throw TypeError("A color must be an (r,g,b) tuple.");
  Sequence x(*o);
  int l = x.length();
  if (l != 3) 
    throw ValueError("A color must be an (r,g,b) tuple.");
  r = Float(x[0]);
  g = Float(x[1]);
  b = Float(x[2]);
}

Tuple rgb::asTuple() {
  Tuple x(3);
  x.setItem(0,Float(r));
  x.setItem(1,Float(g));
  x.setItem(2,Float(b));
  return x;
}
