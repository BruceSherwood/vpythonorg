#ifndef RATE_H
#define RATE_H

#include "platform.h"

struct rate_timer {
  double origin;

  rate_timer();


  void delay(double seconds);
};

#endif
