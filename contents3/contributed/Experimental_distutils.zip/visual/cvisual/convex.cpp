#include "platform.h"
#include "arrprim.h"
#include GL_INCLUDE

template <int N>
struct vlist {
  double v[N][3];
  void set(int i, double *p) {
    for(int j=0;j<3;j++)
      v[i][j] = p[j];
  }
};

struct face : vlist<3> {
  Vector n;
  double d;

  face(double *a, double *b, double *c) {
    set(0,a); set(1,b); set(2,c);
    n = (Vector(v[1])-Vector(v[0])).cross(Vector(v[2])-Vector(v[0])).norm0();
    d = n.dot(v[0]);  //perpendicular distance from face to origin
  }

  bool visibleFrom(const Vector& p) {
    return n.dot(p) > d;
  }
};

struct edge : vlist<2> {
  edge(double *a, double *b) {
    set(0,a); set(1,b);
  }

  bool operator == (const edge& b) const {
    for(int i=0;i<2;i++)
      for(int j=0;j<3;j++)
        if (v[i][j] != b.v[1-i][j]) return false;
    return true;
  }
};

struct jitter_table {
  enum { mask = 1023 };
  enum { count = mask+1 };
  double v[count];

  jitter_table() {
    for(int i=0; i<count; i++)
      v[i] = (double(rand()) / RAND_MAX - 0.5) * 2 * 1e-6;
  }
} jitter;

class convex : public ArrayPrimitive {
  protected:  
    vector<face> hull;
    Array pos_data;
    int allocated, count;
    long checksum;

  public:
    convex()
     : allocated(0), count(0), checksum(0)
    {
      color = Array(3);

      allocate(128);
      double *p = (double*)pos_data.to_C();
      p[0] = 0;
      p[1] = 0;
      p[2] = 0;

      double *c = (double*)color.to_C();
    rgb fg = display->fgcolor();
      c[0] = fg.r;
      c[1] = fg.g;
      c[2] = fg.b;

      setLength(0);
    }

    virtual void fromDictionary(Dict d) {
      if (d.hasKey("pos")) {
        setPos(d["pos"]);
      } else if (d.hasKey("x")) {
        setLength( Sequence( d["x"] ).length() );
      } else if (d.hasKey("y")) {
        setLength( Sequence( d["y"] ).length() );
      } else if (d.hasKey("z")) {
        setLength( Sequence( d["z"] ).length() );
      }

      List items = d.items();
      for(List::iterator i = items.begin(); i != items.end(); i++) {
        Tuple it = Object(*i);
        string attr = String(it[0]);
        if (attr != "visible" && attr != "pos")
          setattr(attr.c_str(),it[1]);
      }

      if (d.hasKey("visible")) 
        setattr("visible",d["visible"]);
      else
        setVisible(1);
    }

    virtual Object py_append(const Tuple& args, const Dict& kw) {
      if (args.length())
        throw TypeError("append() requires keyword arguments (name=value)");

      write_lock L(mtx);
      setLength(count + 1);

      double *np = (double*)pos.to_C() + (count-1)*3;
      try {
        if (kw.hasKey("pos")) {
          Vector v(kw["pos"]);
          np[0] = v.x;
          np[1] = v.y;
          np[2] = v.z;
        }

        List items = kw.items();
        for(List::iterator i = items.begin(); i != items.end(); i++) {
          Tuple it = Object(*i);
          string attr = String(it[0]);
          if (attr[0]>='x' && attr[0]<='z' && attr.length() == 1) {
            Float v(it[1]);
            np[attr[0]-'x'] = v;
          } else if (attr != "pos") {
            throw AttributeError(attr);
          }
        }
      } catch(...) {
        setLength(count-1);
        throw;
      }

      return Nothing();
    }

    bool allocate(int n) {
      if (n > allocated) {
        n = n*2;
        int shape[] = {n, 3};
        pos_data = Array( 2, shape );
        allocated = n;

        return true;
      } else
        return false;
    }

    void setLength(int length) {
      int npoints = count;
      if (npoints > length) npoints = length;
      if (!npoints) npoints = 1;

      Array old_pos = pos_data;
      
      if (allocate( length )) {
        // we have moved the buffer, copy the old points over
        memcpy(pos_data.to_C(), old_pos.to_C(), npoints*3*sizeof(double));
      }

      // copy the last old point over each new point
      double *oldp = (double*)old_pos.to_C()    + (npoints-1)*3;
      double *p    = (double*)pos_data.to_C()   + npoints*3;
      for( int i = npoints; i < length; i++ )
        for( int j = 0; j < 3; j++ ) {
          *p++ = oldp[j];
        }

      /* set pos   = pos_data[0:length]
             count = length */
      Object s = slice(Int(0), Int(length));
      pos = Mapping(*pos_data)[ s ];
      count = length;
    }

    virtual void setPos(Object value) {
      Array v = asArray(value);
      if (v.rank()==1 && !v.dimension(1)) {
        setLength(0);
      } else if (v.rank()==2 && v.dimension(2)==3) {
        setLength( v.dimension(1) );
        Mapping(*pos).setItem(colon(), value);
      } else if (v.rank()==2 && v.dimension(2)==2) {
        setLength( v.dimension(1) );
        Tuple s(2);
        s.setItem(0, ellipsis());
        s.setItem(1, slice(Int(0),Int(2)));
        Mapping(*pos).setItem(s, value);
      } else {
        throw TypeError("pos must be an (N x 3) array");
      }
    }

  long computeChecksum() {
    long sum = 0;
    unsigned char *p = (unsigned char *)pos_data.to_C();
    for(int i = 0; i < 3*count*sizeof(double); i++) {
      sum ^= *p++;
      if (sum < 0) sum = (sum << 1) | 1;
      else sum = sum << 1;
    }
    return sum;
  }

  virtual void refreshCache() {
    recalc();
  }

  void recalc() {
    double *p = (double*)pos.to_C();

    hull.clear();
    hull.push_back(face( p, p + 3*1, p+3*2 ));
    hull.push_back(face( p, p + 3*2, p+3*1 ));
    
    for(int v=3; v<count; v++) {
      addpoint(v, p + 3*v);
    }
  checksum = computeChecksum();
  }

  void addpoint(int n, Vector pv) {
    double m = pv.mag();
    pv.x += m * jitter.v[(n  ) & jitter.mask];
    pv.y += m * jitter.v[(n+1) & jitter.mask];
    pv.z += m * jitter.v[(n+2) & jitter.mask];

    vector<edge> hole;
    for(int f=0; f<hull.size();) {
      if ( hull[f].visibleFrom(pv) ) {
        // hull[f] is visible from pv.  We will never get here if pv is
        //   inside the hull.

        // add the edges to the hole.  If an edge is already in the hole,
        //   it is not on the boundary of the hole and is removed.
        for(int e=0; e<3; e++) {
          edge E( hull[f].v[e], hull[f].v[(e+1)%3] );

          bool boundary = true;
          for(vector<edge>::iterator h = hole.begin(); h != hole.end(); h++)
            if (*h == E) {
              *h = hole.back();
              hole.pop_back();
              boundary = false;
              break;
            }

          if (boundary) {
            hole.push_back(E);
          }
        }

        // remove hull[f]
        hull[f] = hull.back();
        hull.pop_back();
      } else 
        f++;
    }

    // Now add the boundary of the hole to the hull.  If pv was inside
    //   the hull, the hole will be empty and nothing happens here.
    for(int h=0; h<hole.size(); h++) {
      hull.push_back(face( hole[h].v[0], hole[h].v[1], &pv.x ));
    }
  }

  virtual void glRender(rView& view) {
    if (count<3) return;
  if (checksum != computeChecksum()) {
    recalc();
  }

    double *c = (double*)color.to_C();

    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_COLOR_ARRAY);
    glShadeModel(GL_FLAT);
    glEnable(GL_CULL_FACE);

    glBegin(GL_TRIANGLES);
    for(int f=0; f<hull.size(); f++) {
      double illum = view.lights.illuminate( hull[f].n );
      glColor3d( illum*c[0], illum*c[1], illum*c[2] );
      for(int v=0;v<3;v++) {
        vertex vx;
        view.ext_point(hull[f].v[v]);
        view.wct.project( hull[f].v[v], vx );
        glVertex4d( vx.x, vx.y, vx.z, vx.w );
      }
    }
    glEnd();
    glDisable(GL_CULL_FACE);
  }

  virtual double rayIntersect(const Vector &camera, const Vector &ray) {
    if (count < 3) return 0.0;

    // xxx This implementation looks like a fish, moves like a fish, steers like a cow
    //     (apologies to Douglas Adams and to your CPU :)

    double inter = 1e300;

    for(int f=0; f<hull.size(); f++) {
      double ndr = hull[f].n.dot(ray);
      if (ndr >= 0.0) continue;  // back- or side-facing

      double t = -(hull[f].n.dot(camera) - hull[f].d) / ndr;
      if (t<0 || t > 1e100) continue;  // behind camera
      
      Vector p = camera + ray*t;

      for(int i=0;i<3;i++) {
        Vector v0 = hull[f].v[i];
        Vector v1 = hull[f].v[ (i+1)%3 ];
        if ((p-v0).cross(v1-v0).dot(hull[f].n) > 0) { 
          t = 1e300;
          break;
        }
      }
      if (t < inter) inter = t;
    }

    if (inter < 1e100) return inter;
    else return 0.0;
  }
};

Object create_convex(const Tuple& args, const Dict& kwargs) {
  return init(new convex,args,kwargs);
}
