#include "prim.h"

Primitive::Primitive()
 : pos(mtx,0,0,0),
   axis(mtx,  1,0,0),
   up(mtx,    0,1,0),
   degenerate(true)
{
}

void Primitive::init_type() {
  behaviors().name("Primitive");
  behaviors().supportGetattr();
  behaviors().supportSetattr();
  add_keyword_method("rotate",&Primitive::py_rotate);
}

Object Primitive::py_rotate(const Tuple& args, const Dict& kw) {
  if (args.length())
    throw TypeError("rotate() expects only keyword arguments (name=value)");

  tmatrix R;
  py_rotation(R, *pos, *axis, kw);

  write_lock L(mtx);

  // A subtlety: it is possible that axis and up point in the same direction;
  //   in this case the primitive's orientation isn't fully specified.  We
  //   need to resolve this case in the same way refreshCache() does so that
  //   such primitives can be rotated consistently.
  if (!axis->cross(*up)) {
    up = Vector(1,0,0);
    if (!axis->cross(*up))
      up = Vector(0,1,0);
  }

  pos = R * *pos;
  axis = R.times_v(*axis);
  up = R.times_v(*up);

  return Nothing();
}

double Primitive::getLength() {
  throw AttributeError("length");
}
void Primitive::setLength(double) {
  throw AttributeError("length");
}
double Primitive::getRadius() {
  throw AttributeError("radius");
}
void Primitive::setRadius(double) {
  throw AttributeError("radius");
}
int Primitive::getFixedWidth() {
  throw AttributeError("fixedwidth");
}
void Primitive::setFixedWidth(int) {
  throw AttributeError("fixedwidth");
}
double Primitive::getShaftWidth() {
  throw AttributeError("shaftwidth");
}
void Primitive::setShaftWidth(double) {
  throw AttributeError("shaftwidth");
}
double Primitive::getHeadWidth() {
  throw AttributeError("headwidth");
}
void Primitive::setHeadWidth(double) {
  throw AttributeError("headwidth");
}
double Primitive::getHeadLength() {
  throw AttributeError("headlength");
}
void Primitive::setHeadLength(double) {
  throw AttributeError("headlength");
}
double Primitive::getThickness() {
  throw AttributeError("thickness");
}
void Primitive::setThickness(double) {
  throw AttributeError("thickness");
}
double Primitive::getWidth() {
  throw AttributeError("width");
}
void Primitive::setWidth(double) {
  throw AttributeError("width");
}
double Primitive::getHeight() {
  throw AttributeError("height");
}
void Primitive::setHeight(double) {
  throw AttributeError("height");
}
Vector Primitive::getSize() {
  throw AttributeError("size");
}
void Primitive::setSize(Vector) {
  throw AttributeError("size");
}

void Primitive::refreshCache() {
  degenerate = !*axis;

  if (!degenerate) {
    scale = getScale();

    Vector W = axis->cross(*up);
    if (!W) {
      W = axis->cross(Vector(1,0,0));
      if (!W) W = axis->cross(Vector(0,1,0));
    }
    W = W.norm();
    Vector H = W.cross( *axis ).norm();
    Vector L = axis->norm();

    mwt.x_column( L * scale.x );
    mwt.y_column( H * scale.y );
    mwt.z_column( W * scale.z );
    mwt.w_column( *pos );
    mwt.w_row();

    wlt.x_column( L.x, H.x, W.x );
    wlt.y_column( L.y, H.y, W.y );
    wlt.z_column( L.z, H.z, W.z );
    wlt.w_column();
    wlt.w_row();
  }
}

Object Primitive::getattr(const char* _attr) {
  string attr = _attr;

  /* Attribute access is somewhat time-critical.
   * I'm not sure of the fastest way to do this.
   * For now, switch on the first character
   *   and then string-compare.  Usually we
   *   only need to do one string compare to
   *   find a built-in attribute.
   */

  switch (_attr[0]) {
    case 'a':
      if (attr == "axis") return Object(axis);
      break;
    case 'b':
      if (attr == "blue") return Float( color.b );
      break;
    case 'c':
      if (attr == "color") return color.asTuple();
      break;
    case 'd':
      if (attr == "display") return Object(display);
      break;
    case 'f':
      if (attr == "frame") return parentObject;
      if (attr == "fixedwidth") return Int(getFixedWidth());
      break;
    case 'g':
      if (attr == "green") return Float( color.g );
      break;
    case 'h':
      if (attr == "height") return Float(getHeight());
      if (attr == "headwidth") return Float(getHeadWidth());
      if (attr == "headlength") return Float(getHeadLength());
	  break;
    case 'l':
      if (attr == "length") return Float(getLength());
      break;
    case 'p':
      if (attr == "pos") return Object(pos);
      break;
    case 'r':
      if (attr == "radius") return Float(getRadius());
      if (attr == "red") return Float( color.r );
      break;
    case 's':
      if (attr == "size") return asImmutableVector(getSize());
      if (attr == "shaftwidth") return Float(getShaftWidth());
      break;
    case 't':
      if (attr == "thickness") return Float(getThickness());
      break;
    case 'u':
      if (attr == "up") return Object(up);
      break;
    case 'v':
      if (attr == "visible") return Int(visible);
      break;
    case 'w':
      if (attr == "width") return Float(getWidth());
      break;
    case 'x': if (!_attr[1]) return Float( pos->x );
      break;
    case 'y': if (!_attr[1]) return Float( pos->y );
      break;
    case 'z': if (!_attr[1]) return Float( pos->z );
      break;
    case '_': 
      if (attr == "__dict__") return user;
      if (attr == "__members__") {
        /*
         * Make dir(object) work correctly
         */
        List l;
        l.append(String("axis"));
        l.append(String("blue"));
        l.append(String("color"));
        l.append(String("display"));
        l.append(String("frame"));
        l.append(String("green"));
        try { getHeight();     l.append(String("height")); }     catch (Py::Exception& e) {e.clear();}
        try { getFixedWidth(); l.append(String("fixedwidth")); } catch (Py::Exception& e) {e.clear();}
        try { getHeadWidth();  l.append(String("headwidth")); }  catch (Py::Exception& e) {e.clear();}
        try { getHeadLength(); l.append(String("headlength")); } catch (Py::Exception& e) {e.clear();}
        try { getLength();     l.append(String("length")); }     catch (Py::Exception& e) {e.clear();}
        l.append(String("pos"));
        try { getRadius();     l.append(String("radius")); }     catch (Py::Exception& e) {e.clear();}
        l.append(String("red"));
        try { getSize();       l.append(String("size")); }       catch (Py::Exception& e) {e.clear();}
        try { getShaftWidth(); l.append(String("shaftwidth")); } catch (Py::Exception& e) {e.clear();}
        try { getThickness();  l.append(String("thickness")); }  catch (Py::Exception& e) {e.clear();}
        l.append(String("up"));
        l.append(String("visible"));
        try { getWidth();  l.append(String("width")); } catch (Py::Exception& e) {e.clear();}
        l.append(String("x"));
        l.append(String("y"));
        l.append(String("z"));
        return l;
      }
      break;
  }

  if (user.hasKey(attr)) {
    return user[attr];
  } else
    return getattr_methods(_attr);
}

int Primitive::setattr(const char* _attr, const Object& value) {
  string attr = _attr;

  /* Attribute access is somewhat time-critical.
   * I'm not sure of the fastest way to do this.
   * For now, switch on the first character
   *   and then string-compare.  Usually we
   *   only need to do one string compare to
   *   find a built-in attribute.
   */

  switch (_attr[0]) {
    case 'a':
      if (attr == "axis") {
        write_lock L(mtx);
        axis = Vector(value);
        return 0;
      }
      break;
    case 'b':
      if (attr == "blue") {
        write_lock L(mtx);
        color.b = Float(value);
        return 0;
      }
	  break;
    case 'c':
      if (attr == "color") {
        write_lock L(mtx);
        if (value.is(Nothing()))
          color = display->fgcolor();
        else
          color = rgb(value);
        return 0;
      }
      break;
    case 'd':
      if (attr == "display") {
        write_lock L(mtx);
        ExtensionObject<Display> v(*value);
        setDisplay( v.extensionObject() );
        return 0;
      }
      break;
    case 'f':
      if (attr == "frame") {
        write_lock L(mtx);
        if (value.is(Nothing())) {
          setParent(0);
        } else {
          setParent(ExtensionObject<Primitive>(*value).extensionObject(), value);
        }
        return 0;
	  }
      if (attr == "fixedwidth") {
        write_lock L(mtx);
        setFixedWidth( Int(value) ? true : false );
        return 0;
      }
      break;
    case 'g':
      if (attr == "green") {
        write_lock L(mtx);
        color.g = Float(value);
        return 0;
      }
	  break;
    case 'h':
      if (attr == "height") {
        write_lock L(mtx);
        setHeight(Float(value));
        return 0;
      }
      if (attr == "headwidth") {
        write_lock L(mtx);
        setHeadWidth(Float(value));
        return 0;
      }
      if (attr == "headlength") {
        write_lock L(mtx);
        setHeadLength(Float(value));
        return 0;
      }
	  break;
    case 'l':
      if (attr == "length") {
        write_lock L(mtx);
        setLength(Float(value));
        return 0;
      }
      break;
    case 'p':
      if (attr == "pos") {
        write_lock L(mtx);
        pos = Vector(value);
        return 0;
      }
      break;
    case 'r':
      if (attr == "radius") {
        write_lock L(mtx);
        setRadius(Float(value));
        return 0;
      }
      if (attr == "red") {
        write_lock L(mtx);
        color.r = Float(value);
        return 0;
      }
      break;      
    case 's':
      if (attr == "size") {
        write_lock L(mtx);
        setSize(Vector(value));
        return 0;
      }
      if (attr == "shaftwidth") {
        write_lock L(mtx);
        setShaftWidth(Float(value));
        return 0;
      }
      break;
    case 't':
      if (attr == "thickness") {
        write_lock L(mtx);
        setThickness(Float(value));
        return 0;
      }
      break;
    case 'u':
      if (attr == "up") {
        write_lock L(mtx);
        up = Vector(value);
        return 0;
      }
      break;
    case 'v':
      if (attr == "visible") {
        write_lock L(mtx);
        setVisible( Int(value) ? true : false );
        return 0;
      }
      break;
    case 'w':
      if (attr == "width") {
        write_lock L(mtx);
        setWidth( Float(value) );
        return 0;
      }
	  break;
    case 'x': if (!_attr[1]) {
                write_lock L(mtx);
                pos->x = Float(value);
                return 0;
              }
              break;
    case 'y': if (!_attr[1]) {
                write_lock L(mtx);
                pos->y = Float(value);
                return 0;
              }
              break;
    case 'z': if (!_attr[1]) {
                write_lock L(mtx);
                pos->z = Float(value);
                return 0;
              }
              break;
  }

  user[attr] = value;
  return 0;
}

void Primitive::fromDictionary(Dict d) {
  if (d.hasKey("axis"))    setattr("axis",d["axis"]);
  if (d.hasKey("pos"))     setattr("pos",d["pos"]);
  if (d.hasKey("display")) setattr("display",d["display"]);
  if (d.hasKey("color"))   setattr("color",d["color"]);
  else {
    write_lock L(mtx);
    color = display->fgcolor();
  }

  List items = d.items();
  for(List::iterator i = items.begin(); i != items.end(); i++) {
    Tuple it = Object(*i);
    string attr = String(it[0]);
    if (attr != "visible" && attr != "axis"    && 
        attr != "pos"     && attr != "display" && 
        attr != "color")
    {
      setattr(attr.c_str(),it[1]);
    }
  }

  if (d.hasKey("visible")) 
    setattr("visible",d["visible"]);
  else
    setVisible(1);
}
