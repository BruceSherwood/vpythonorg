#include "pvector.h"
#include "tmatrix.h"
#include <sstream>

Vector::Vector(double _x, double _y, double _z)
 : x(_x), y(_y), z(_z) {}

Vector::Vector(const double xyz[3])
 : x(xyz[0]), y(xyz[1]), z(xyz[2]) {}

Vector::Vector(const Vector& v)
 : x(v.x), y(v.y), z(v.z) {}

Vector::Vector(const Object& o) {
  if (check(*o)) {
    Vector v = asVector(o);
    x=v.x; y=v.y; z=v.z;
    return;
  } else if (o.isSequence()) {
    Sequence t = o;
    switch( t.length() ) {
      case 0: x = y = z = 0.0; return;
      case 2: x = Float(t[0]); y = Float(t[1]); z = 0.0; return;
      case 3: x = Float(t[0]); y = Float(t[1]); z = Float(t[2]); return;
    }
  }
  throw TypeError( "Cannot convert " + o.type().name() + " to vector.");
}

Vector Vector::asVector(const Object& o) {
  // asVector is called to perform "implicit" conversions - only
  //   those conversions that should be done silently in arithmetic
  //   operators and the like are done here.  More aggressive 
  //   conversion is done in the Vector(const Object&) constructor,
  //   which can be invoked explicitly from Python.
  
  PyObject* p = *o;
  if (check(p)) 
    return *static_cast<Vector*>(p);

  if (p && PyArray_Check(p)) {
    Array a(o);
    if (a.rank()==1 && a.dimension(1)==3)
      return Vector(Float(a[0]), Float(a[1]), Float(a[2]));
  }
    
  throw TypeError( "Expected vector, found " + o.type().name() );
}

Object Vector::str() {
  std::ostringstream s;
  s << "[" << x << " " << y << " " << z << "]" << std::ends;
  return String(s.str());
}
Object Vector::repr() {
  std::ostringstream s;
  s << "vector(" << x << "," << y << "," << z << ")" << std::ends;
  return String(s.str());
}


// Unary arithmetic

int Vector::number_nonzero()  {
  return x || y || z;
}

Object Vector::number_negative()  {
  return asObject(new Vector(-x, -y, -z));
}

Object Vector::number_positive()  {
  return asObject(new Vector(x, y, z));
}

Object Vector::number_absolute()  {
  return Float( mag() );
}

// Binary arithmetic

Object Vector::number_add(const Object& rhs)  {
  try {
    Vector r = asVector(rhs);
    return asObject(new Vector(x + r.x, y + r.y, z + r.z));
  } catch( Exception& e ) {
    e.clear();
    if (PyArray_Check(*rhs))
      return toArray(Object(this)) + rhs;
    throw TypeError("Cannot add vector + " + rhs.type().name());
  }
}

Object Vector::rhs_add(const Object& lhs)  {
  try {
    Vector l = asVector(lhs);
    return asObject(new Vector(l.x + x, l.y + y, l.z + z));
  } catch( Exception& e ) {
    e.clear();
    throw TypeError("Cannot add " + lhs.type().name() + " + vector");
  }
}

Object Vector::number_subtract(const Object& rhs)  {
  try {
    Vector r = asVector(rhs);
    return asObject(new Vector(x - r.x, y - r.y, z - r.z));
  } catch( Exception& e ) {
    e.clear();
    if (PyArray_Check(*rhs))
      return toArray(Object(this)) - rhs;
    throw TypeError("Cannot subtract vector - " + rhs.type().name());
  }
}

Object Vector::rhs_subtract(const Object& lhs)  {
  try {
    Vector l = asVector(lhs);
    return asObject(new Vector(l.x - x, l.y - y, l.z - z));
  } catch( Exception& e ) {
    e.clear();
    throw TypeError("Cannot subtract " + lhs.type().name() + " - vector");
  }
}

Object Vector::number_multiply( const Object& rhs )  {
  try {
    double r = Float(rhs);
    return asObject(new Vector(x*r, y*r, z*r));
  } catch( Exception& e ) {
    e.clear();
    if (PyArray_Check(*rhs))
      return toArray(Object(this)) * rhs;
    throw TypeError("Cannot multiply vector * " + rhs.type().name());
  }
}

Object Vector::rhs_multiply( const Object& lhs )  {
  try {
    double r = Float(lhs);
    return asObject(new Vector(x*r, y*r, z*r));
  } catch( Exception& e ) {
    e.clear();
    throw TypeError("Cannot multiply " + lhs.type().name() + " * vector");
  }
}

Object Vector::number_divide( const Object& rhs )  {
  double r;
  try {
    r = Float(rhs);
  } catch( Exception& e) {
    e.clear();
    if (PyArray_Check(*rhs))
      return toArray(Object(this)) / rhs;
    throw TypeError("Cannot divide vector / " + rhs.type().name());
  }
  if (!r) throw ZeroDivisionError("vector division");
  r = 1.0 / r;
  return asObject(new Vector(x*r, y*r, z*r));
}

Object Vector::number_true_divide( const Object& rhs )  {
  double r;
  try {
    r = Float(rhs);
  } catch( Exception& e) {
    e.clear();
    if (PyArray_Check(*rhs))
      return toArray(Object(this)) / rhs;
    throw TypeError("Cannot divide vector / " + rhs.type().name());
  }
  if (!r) throw ZeroDivisionError("vector division");
  r = 1.0 / r;
  return asObject(new Vector(x*r, y*r, z*r));
}

Object Vector::rhs_divide( const Object& lhs )  {
  throw TypeError("cannot divide by a vector.");
}

Object Vector::rhs_true_divide( const Object& lhs )  {
  throw TypeError("cannot divide by a vector.");
}

// Unsupported conversions
Object Vector::number_int()  {
  throw TypeError("vector does not support this operation");
}
Object Vector::number_float()  {
  throw TypeError("vector does not support this operation");
}
Object Vector::number_long()  {
  throw TypeError("vector does not support this operation");
}
Object Vector::number_oct()  {
  throw TypeError("vector does not support this operation");
}
Object Vector::number_hex()  {
  throw TypeError("vector does not support this operation");
}

// Unsupported operations, lefty and righty
Object Vector::number_remainder( const Object& rhs )  {
  throw TypeError("vector does not support this operation");
}
Object Vector::number_divmod( const Object& rhs )  {
  throw TypeError("vector does not support this operation");
}
Object Vector::number_invert()  {
  throw TypeError("vector does not support bit operations");
}
Object Vector::number_lshift( const Object& rhs )  {
  throw TypeError("vector does not support bit operations");
}
Object Vector::number_rshift( const Object& rhs )  {
  throw TypeError("vector does not support bit operations");
}
Object Vector::number_and( const Object& rhs )  {
  throw TypeError("vector does not support bit operations");
}
Object Vector::number_xor( const Object& rhs )  {
  throw TypeError("vector does not support bit operations");
}
Object Vector::number_or( const Object& rhs )  {
  throw TypeError("vector does not support bit operations");
}
Object Vector::number_power( const Object& p, const Object& m )  {
  throw TypeError("vector does not support exponentiation");
}
Object Vector::rhs_remainder( const Object& rhs )  {
  throw TypeError("vector does not support this operation");
}
Object Vector::rhs_divmod( const Object& rhs )  {
  throw TypeError("vector does not support this operation");
}
Object Vector::rhs_lshift( const Object& rhs )  {
  throw TypeError("vector does not support bit operations");
}
Object Vector::rhs_rshift( const Object& rhs )  {
  throw TypeError("vector does not support bit operations");
}
Object Vector::rhs_and( const Object& rhs )  {
  throw TypeError("vector does not support bit operations");
}
Object Vector::rhs_xor( const Object& rhs )  {
  throw TypeError("vector does not support bit operations");
}
Object Vector::rhs_or( const Object& rhs )  {
  throw TypeError("vector does not support bit operations");
}
Object Vector::rhs_power( const Object& p, const Object& m )  {
  throw TypeError("vector does not support exponentiation");
}

// Attributes: getattr and setattr
Object Vector::getattr( const char * attr )  {
  if (!attr[1])
    switch( attr[0] ) {
      case 'x': return Float(x);
      case 'y': return Float(y);
      case 'z': return Float(z);
    }

  if (!strcmp(attr, "mag"))
    return Float(mag());
  if (!strcmp(attr, "mag2"))
    return Float(mag2());
  if (!strcmp(attr, "array")) {
    return toArray(Object(this));
  }
#ifdef LINUX
  throw(AttributeError(attr)); // XXX why doesn't getattr_methods work? dma 08/27/01
#endif
  return getattr_methods(attr);
}
int Vector::setattr( const char* attr, const Object& value )  {
  if (!attr[1])
    switch( attr[0] ) {
      case 'x': x = Float(value); return 0;
      case 'y': y = Float(value); return 0;
      case 'z': z = Float(value); return 0;
    }

  if (!strcmp(attr, "mag")) { // vector.mag = 1 normalizes the vector
    double r = Float(value);
    double m = mag();
    if (!m) throw ZeroDivisionError("attempt to scale zero vector");
    r /= m;
    x *= r; y *= r; z *= r;
    return 0;
  }

  if (!strcmp(attr, "mag2")) { // vector.mag2 = 1 normalizes the vector
    double r = Float(value);
    double m = mag2();
    if (!m) throw ZeroDivisionError("attempt to scale zero vector");
    r = sqrt(r/m);
    x *= r; y *= r; z *= r;
    return 0;
  }

  throw AttributeError(attr);
}

int Vector::compare( const Object& rhs )  {
  try {
    Vector r = asVector(rhs);
    if (r.x==x && r.y==y && r.z==z) return 0;
    else if (x<r.x) return -1;
    else if (x>r.x) return 1;
    else if (y<r.y) return -1;
    else if (y>r.y) return 1;
    else if (z<r.z) return -1;
    else return 1;
  } catch( Exception& e ) {
    e.clear();
    if (this < rhs.ptr()) return -1;
    else return 1;
  }
}

// Sequence methods
int Vector::sequence_length()  { 
  return 3; 
}
Object Vector::sequence_item( int n )  {
  switch (n) {
    case 0: return Float(x);
    case 1: return Float(y);
    case 2: return Float(z);
  }
  throw IndexError("vector index out of range");
}
int Vector::sequence_ass_item( int n, const Object & value)  {
  switch (n) {
    case 0: x=Float(value); return 0;
    case 1: y=Float(value); return 0;
    case 2: z=Float(value); return 0;
  }
  throw IndexError("vector index out of range");
}
Object Vector::sequence_slice(int,int)  {
  throw TypeError("vector does not support slicing.");
}
int Vector::sequence_ass_slice(int,int,const Object&)  {
  throw TypeError("vector does not support slice assignment.");
}
Object Vector::sequence_concat( const Object& rhs )  {
  return number_add(rhs);
}
Object Vector::sequence_repeat( int ir) {
  double r = ir;
  return asObject(new Vector(x*r, y*r, z*r));
}

void Vector::init_type() {
  behaviors().name("vector");
  behaviors().doc("vector: x, y, z");
  behaviors().supportStr();
  behaviors().supportRepr();
  behaviors().supportNumberType();
  behaviors().supportRHS();
  behaviors().supportGetattr();
  behaviors().supportSetattr();
  behaviors().supportCompare();
  behaviors().supportSequenceType();
}

Object create_vector(const Tuple& args, const Dict& kwargs) {
  if (kwargs.isTrue()) throw TypeError("this function takes no keyword arguments.");
  switch (args.length()) {
    case 0:
      return asObject(new Vector());
    case 1:
      return asObject(new Vector(args[0]));
    case 2:
      return asObject(new Vector(Float(args[0]), Float(args[1])));
    case 3:
      return asObject(new Vector(Float(args[0]), Float(args[1]), Float(args[2])));
    default:
      throw TypeError("Too many arguments to vector().");
  }
}

Object create_immutableVector(const Tuple& args, const Dict& kwargs) {
  if (kwargs.isTrue()) throw TypeError("this function takes no keyword arguments.");
  switch (args.length()) {
    case 0:
      return asObject(new immutableVector());
    case 1:
      return asObject(new immutableVector(args[0]));
    case 2:
      return asObject(new immutableVector(Float(args[0]), Float(args[1])));
    case 3:
      return asObject(new immutableVector(Float(args[0]), Float(args[1]), Float(args[2])));
    default:
      throw TypeError("Too many arguments to vector().");
  }
}

Object vector_mag(const Tuple& args, const Dict& kwargs) {
  if (kwargs.isTrue()) throw TypeError("this function takes no keyword arguments.");
  if (args.length() != 1)
    throw TypeError("mag() takes a single argument.");
  
  if (PyArray_Check(*args[0])) {
    Array a = args[0];
    if (a.rank()==2 && a.dimension(2)==3) {
      int n = a.dimension(1);

      Array r(n);
      for(int i=0; i<n; i++) {
        Vector v( a[i] );
        r[i] = Float(v.mag());
      }
      
      return r;
    }
  }

  Vector v(args[0]);
  return Float(v.mag());
}

Object vector_mag2(const Tuple& args, const Dict& kwargs) {
  if (kwargs.isTrue()) throw TypeError("this function takes no keyword arguments.");
  if (args.length() != 1)
    throw TypeError("mag2() takes a single argument.");
  
  if (PyArray_Check(*args[0])) {
    Array a = args[0];
    if (a.rank()==2 && a.dimension(2)==3) {
      int n = a.dimension(1);

      Array r(n);
      for(int i=0; i<n; i++) {
        Vector v( a[i] );
        r[i] = Float(v.mag2());
      }
      
      return r;
    }
  }

  Vector v(args[0]);
  return Float(v.mag2());
}

Object vector_norm(const Tuple& args, const Dict& kwargs) {
  if (kwargs.isTrue()) throw TypeError("this function takes no keyword arguments.");
  if (args.length() != 1)
    throw TypeError("norm() takes a single argument.");

  if (PyArray_Check(*args[0])) {
    Array a = args[0];
    if (a.rank()==2 && a.dimension(2)==3) {
      int n = a.dimension(1);
      int d[2] = {n, 3};

      Array r(2, d);
      for(int i=0; i<n; i++) {
        Vector v(a[i]);
        Vector v2 = v / v.mag();
        r[i] = Object(&v2);
      }
      
      return r;
    }
  }

  Vector v(args[0]);
  return asObject(new Vector(v/v.mag()));
}

Object vector_rotate(const Tuple &args, const Dict& kw) {
  if (args.length() != 1)
    throw TypeError("rotate() expects one vector argument, plus keywords.");

  tmatrix R;
  py_rotation(R,Vector(0,0,0),Vector(0,0,1),kw);

  return asImmutableVector(R.times_v(Vector(args[0])));
}

Object cross2(const Object& v1, const Object& v2) {
  int is1 = PyArray_Check(*v1),
      is2 = PyArray_Check(*v2);

  if (is1 && is2) {
    Array A = v1;
    Array B = v2;
    if (A.rank()==2 && A.dimension(2)==3
     && B.rank()==2 && B.dimension(2)==3
     && A.dimension(1) == B.dimension(1))
    {
      int n = A.dimension(1);
      int d[2] = {n,3};
      Array r(2,d);
      for(int i=0; i<n; i++) {
        Vector a( A[i] ), b( B[i] );
        r[i] = asObject(new Vector(a.y*b.z-b.y*a.z,
                                   a.z*b.x-b.z*a.x,
                                   a.x*b.y-b.x*a.y));
      }
      return r;
    }
  } else if (is1) {
    Array A = v1;
    Vector b(v2);

    if (A.rank()==2 && A.dimension(2)==3)
    {
      int n = A.dimension(1);
      int d[2] = {n,3};
      Array r(2,d);
      for(int i=0; i<n; i++) {
        Vector a( A[i] );
        r[i] = asObject(new Vector(a.y*b.z-b.y*a.z,
                                   a.z*b.x-b.z*a.x,
                                   a.x*b.y-b.x*a.y));
      }
      return r;
    }
  } else if (is2) {
    Vector a(v1);
    Array B = v2;

    if (B.rank()==2 && B.dimension(2)==3)
    {
      int n = B.dimension(1);
      int d[2] = {n,3};
      Array r(2,d);
      for(int i=0; i<n; i++) {
        Vector b( B[i] );
        r[i] = asObject(new Vector(a.y*b.z-b.y*a.z,
                                   a.z*b.x-b.z*a.x,
                                   a.x*b.y-b.x*a.y));
      }
      return r;
    }
  }

  Vector a(v1), b(v2);
  return asObject(new Vector(a.y*b.z-b.y*a.z,
                             a.z*b.x-b.z*a.x,
                             a.x*b.y-b.x*a.y));
}

Object vector_cross(const Tuple& args, const Dict& kwargs) {
  if (kwargs.isTrue()) throw TypeError("this function takes no keyword arguments.");
  if (args.length() != 2)
    throw TypeError("cross() expects two vector arguments.");
  return cross2(args[0], args[1]);
}
