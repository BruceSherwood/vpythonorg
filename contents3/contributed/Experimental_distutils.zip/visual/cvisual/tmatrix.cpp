#include "tmatrix.h"

void frustum( tmatrix& T, tmatrix& I, double l, double r, double b, double t, double n, double f ) {
  T.x_column(2*n/(r-l),0,0);
  T.y_column(0,2*n/(t-b),0);
  T.z_column((r+l)/(r-l),(t+b)/(t-b),(f+n)/(n-f));
  T.w_column(0,0,2*f*n/(n-f));
  T.w_row(0,0,-1,0);

  I.x_column((r-l)/(2*n), 0, 0);
  I.y_column(0,(t-b)/(2*n),0);
  I.z_column(0,0,0);
  I.w_column((r+l)/(2*n),(t+b)/(2*n),-1);
  I.w_row(0,0,(n-f)/(2*f*n),(f+n)/(2*f*n));
}

void rotation( tmatrix& T, double angle, const Vector& a) {
  double c = cos(angle), s = sin(angle);
  double ic = 1.0-c;
  double icxx = ic*a.x*a.x,
        icxy = ic*a.x*a.y,
        icxz = ic*a.x*a.z,
        icyy = ic*a.y*a.y,
        icyz = ic*a.y*a.z,
        iczz = ic*a.z*a.z;

  T.x_column( icxx  +     c, icxy + a.z*s, icxz - a.y*s );
  T.y_column( icxy  - a.z*s, icyy +     c, icyz + a.x*s );
  T.z_column( icxz  + a.y*s, icyz - a.x*s, iczz +     c );
  T.w_column();
  T.w_row();
}

double norm_dot(const Vector& a, const Vector& b) {
  double m = sqrt( a.mag2() * b.mag2() );
  return (a.x*b.x + a.y*b.y + a.z*b.z) / m;
}

void py_rotation( tmatrix& R, Vector r_origin, Vector r_axis, const Dict& kw ) {
  if (!kw.hasKey("angle")) throw TypeError("rotate: angle required");
  double r_angle = Float(kw["angle"]);
  if (kw.hasKey("origin")) r_origin = Vector(kw["origin"]);
  if (kw.hasKey("axis")) r_axis = Vector(kw["axis"]);

  rotation(R, r_angle, r_axis.norm0());

  Vector T = r_origin - R*r_origin;
  R.w_column( T.x, T.y, T.z );
}
