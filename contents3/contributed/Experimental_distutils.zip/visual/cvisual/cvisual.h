#ifndef CVISUAL_H
#define CVISUAL_H

#include "platform.h"
#include "pvector.h"
#include <string>

using namespace Py;
using namespace std;

const double pi = 3.14159265359;

#endif
