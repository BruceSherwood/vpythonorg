#ifndef COLOR_H
#define COLOR_H

#include "cvisual.h"

class rgb {
  public:
    float r,g,b;

    rgb();  // white
    rgb(float r, float g, float b);
    rgb(const Object&);

    Tuple asTuple();
};

#endif
