#ifndef DISPLAY_H
#define DISPLAY_H

#include "cvisual.h"
#include "color.h"
#include "pvector.h"
#include "vcache.h"
#include "tmatrix.h"
#include "mouseobject.h"
#include "kbobject.h"
#include "displaylist.h"

class Device {
  public:
    Display* display;

    virtual ~Device() {};

    virtual bool show() = 0;
    virtual void hide() = 0;
    virtual void join() = 0;
    virtual bool closed() = 0;
    virtual void frame() = 0;
    virtual string info() = 0;
    virtual void onClose(bool quit) = 0;

    virtual tmatrix get_wct() = 0;

    virtual void setX(int) = 0;
    virtual void setY(int) = 0;
    virtual void setWidth(int) = 0;
    virtual void setHeight(int) = 0;
    virtual void setNewmouse(bool) = 0;
    virtual int getX() = 0;
    virtual int getY() = 0;
    virtual int getWidth() = 0;
    virtual int getHeight() = 0;
};

class Display : public PythonExtension<Display>, public Cache {
  public:
    lighting lights;
    static Display* selected;
    ExtensionObject<mouseObject> mouse;
    ExtensionObject<kbObject> kb;
    ExtensionObject<cursorObject> cursor;

    Display(Device& dev);
    ~Display();

    DisplayObject *objects() { return &head; }
    rgb fgcolor() { return foreground; }

    // The following functions are called by devices to change the display:
    void setForward(const Vector& v) { write_lock L(mtx); forward=v; };
    void setRegion(const Vector& x1, const Vector& x2) { write_lock L(mtx); region_min=x1; region_max=x2; region_valid=true; }
    void addObject(DisplayObject*);

    static void shutdown();
      // Destroys all devices of all displays.
    static bool allclosed();
      // true if all devices of all displays are closed.
    static void waitclose();
      // Blocks until allclosed().

    void show();
      // wakes up all devices
    void hide();
      // hides all devices

    // Python type interface
    static void init_type();
    virtual Object getattr( const char * attr );
    virtual int setattr( const char* attr, const Object& value );
    Object py_show(const Tuple&);
    Object py_hide(const Tuple&);
    Object py_select(const Tuple&);
    Object py_info(const Tuple&);
    Object py_project(const Tuple&, const Dict&);
    virtual void fromDictionary(Dict d);
      // Initializes attributes from the given dictionary.  May throw
      //   exceptions.

    // Cached attributes
    string c_title;
    int c_x, c_y, c_width, c_height;
    bool c_title_changed;
    tmatrix model, imodel,
              view, iview;
    Vector c_forward, c_up, c_center;
    Vector c_extent;
    bool c_uniform, c_rotation_enabled, c_zoom_enabled;
    double tanfov;
    rgb bgcolor;

  protected:
    DisplayListHead head;

    string title;
    bool title_changed;

    Vector center, 
           forward, 
           scale,
           up;
    rgb foreground, background;
    double fov;
    bool uniform;
    bool autoscale_enabled;
    bool autocenter_enabled;
    bool rotation_enabled;
    bool zoom_enabled;
    double autoscale_max, autoscale_min;
    bool auto_show;

    Vector region_min, region_max;
    bool region_valid;

    double get_tanfov();
      // calculates the field of view ratio actually used
      //   in projection

    void window_changed();
      // called to report that x,y,width, or height have
      //   changed.

    virtual void refreshCache();
      // Called by updateCache() when the cache needs to be refreshed.
      
    virtual Object getattr1( const char * attr, int *didIt);
    Device* device;

    static vector<Display*> all;
    int displayID;
};

#endif
