#include "platform.h"
#include <queue>
#include "Python.h"
#include <time.h>

#ifdef MAC
  #include GL_INCLUDE
  #include <MacWindows.h>
#endif

#ifdef _MSC_VER
  using namespace win;
#endif

using namespace std;

string format(string fs, ...) {
  va_list a;
  va_start(a, fs);

  // xxx This should be protected against buffer overflows (_vsnprintf() on windows)
  //     (If it were, it could use a much smaller buffer - maybe 1K)
  char t[16384];
  vsprintf(t,fs.c_str(),a);   

  va_end(a);
  return std::string(t);
};

#define liToDouble( li ) ( double(li.LowPart) + double(li.HighPart) * 4294967296.0 )

#ifdef _MSC_VER
  double sclock() {
    static LARGE_INTEGER freq;
    static int clocks_exist = QueryPerformanceFrequency(&freq);
    static double secondsPerTick = clocks_exist ? 1.0 / liToDouble(freq) : 0.0;

    if (clocks_exist) {
      LARGE_INTEGER count;
      QueryPerformanceCounter(&count);

      return liToDouble(count) * secondsPerTick;
    } else {
      return GetTickCount() * 1e-3;
    }
  }
#else
  double sclock() {
    // Returns a time value in seconds, as accurately as possible.
    return clock() / double(CLOCKS_PER_SEC);
  }
#endif

bool process_messages(void*) {
  // Called every 25ms via the callback created below

  #ifdef _MSC_VER
    // Process messages for all windows:
    MSG msg;
    int count = 0;
    while ( PeekMessage( &msg, 0, 0, 0, PM_REMOVE ) ) {
      DispatchMessage( &msg );
      if (count++ > 50) break;
    }
  #else
    // xxx Process messages on the Mac?  Or maybe there is already a 
    //     message loop in Python?
  #endif

  return true;
}

bool handle_event(PyObject* v) {
  #ifdef MAC
    EventRecord event;
    if (PyArg_Parse(v, "(hll(hh)h)",
	                   &event.what,
	                   &event.message,
	                   &event.when,
	                   &event.where.h,
	                   &event.where.v,                   
	                   &event.modifiers))
      return platform_glContext::handleEvent( &event );
  #endif
  return false;
}

/********** threaded_timer implementation *********/

struct callback_data {
  // The callback_data structure saves all the information
  //   we need about a particular callback function:
  //      - the function pointer ("callback")
  //      - the argument ("data")
  //      - the time in seconds at which the callback should be called ("when")
  //      - the time in seconds between repeated calls to the callback ("interval")
  // For convenience, this is implemented as a class with a constructor and
  //   comparison and function call operators.

  bool (*callback)(void*); 
  void* data;
  double when, interval;

  template <class T>
  callback_data( bool (*_callback)(T*), T* _data, double _interval )
   : callback( (bool (*)(void*))_callback ),
     data(_data),
     interval(_interval),
     when(_interval + sclock())
  {
  }

  bool operator ()() { return (*callback)(data); }
  bool operator > (const callback_data &rhs) const { return when >  rhs.when; }
  bool operator < (const callback_data &rhs) const { return when <  rhs.when; }
};

bool running = false;   
  // "running" is set once we've started the scheduling mechanism


priority_queue< callback_data, vector<callback_data>, greater<callback_data> > timers;
  // "timers" is a queue of callbacks sorted by the time they occur, so that
  //    timers.top() is the callback which needs to be called next.

void add_timer( const callback_data& cb ) {
  timers.push(cb);
}


int poll_scheduler(void* data) {
  // Make sure we are called again next time through the interpreter loop.

  // WARNING: This relies on a modified version of the interpreter!  Specifically,
  //   the Py_MakePendingCalls() function in ceval.c must not execute this pending
  //   call until it is *next* invoked - otherwise it will infinite loop!
  Py_AddPendingCall( &poll_scheduler, data ); 

  // Take care of any callbacks that are due to be called:
  while (1) {
    callback_data cb = timers.top();

    double next = cb.when, 
            now = sclock();

    if (next > now) return 0;

    timers.pop();
    bool again = cb();
    if (again) add_timer( callback_data(cb.callback, cb.data, cb.interval) );
  }

  return 0;
}

void start_scheduler() {
  if (!running) {
    // Generate periodic calls to the process_messages() function above:
    add_timer( callback_data( &process_messages, (void*)0, 0.025 ) );

    // Tell the interpreter to call us the next time through the interpreter loop:
    Py_AddPendingCall( &poll_scheduler, 0 );
    running = true;
  }
}

void _threaded_timer(double seconds, bool (*callback)(void*), void *data) {
  start_scheduler();
  if (callback) 
    add_timer( callback_data(callback, data, seconds) );
}

void threaded_exit(int status) {
  exit(status);
}

void threaded_sleep(double seconds) {
  double start = sclock();
  while (sclock() < start + seconds) {
 //   Py_BEGIN_ALLOW_THREADS
    PyErr_CheckSignals();
 //   Py_END_ALLOW_THREADS
    Py_MakePendingCalls();
  }
}

void nothread_sleep(double seconds) {
  double start = sclock();
  while (sclock() < start + seconds) {
    PyErr_CheckSignals();
  }
}

void init_platform() {
  start_scheduler();
}