// tmatrix - double-precision 3D tmatrix matrices

#ifndef TMATRIX_H
#define TMATRIX_H

#include "pvector.h"
using namespace Py;

class tmatrix {
  public:
    typedef double scalar;

    scalar M[4][4];

    tmatrix() {}
    tmatrix( const tmatrix& t ) {
      memcpy(M,t.M,sizeof(M));
    }
    tmatrix( const tmatrix& A, const tmatrix& B ) {
      concat(A,B);
    }

    static tmatrix identity() { tmatrix t; t.ident(); return t; }

    void ident() {
      x_column();
      y_column();
      z_column();
      w_column();
      w_row();
    }

    void x_column(const Vector& v) {
      M[0][0] = v.x;
      M[1][0] = v.y;
      M[2][0] = v.z;
    }
    void y_column(const Vector& v) {
      M[0][1] = v.x;
      M[1][1] = v.y;
      M[2][1] = v.z;
    }
    void z_column(const Vector& v) {
      M[0][2] = v.x;
      M[1][2] = v.y;
      M[2][2] = v.z;
    }
    void w_column(const Vector& v) {
      M[0][3] = v.x;
      M[1][3] = v.y;
      M[2][3] = v.z;
    }

    void x_column(double x=1, double y=0, double z=0) {
      M[0][0] = x;
      M[1][0] = y;
      M[2][0] = z;
    }
    void y_column(double x=0, double y=1, double z=0) {
      M[0][1] = x;
      M[1][1] = y;
      M[2][1] = z;
    }
    void z_column(double x=0, double y=0, double z=1) {
      M[0][2] = x;
      M[1][2] = y;
      M[2][2] = z;
    }
    void w_column(double x=0, double y=0, double z=0) {
      M[0][3] = x;
      M[1][3] = y;
      M[2][3] = z;
    }
    void w_row(double x=0, double y=0, double z=0, double w=1) {
      M[3][0]=x;
      M[3][1]=y;
      M[3][2]=z;
      M[3][3]=w;
    }

    template <class Vertex>
    void project(const Vector& v, Vertex& o) const {
      o.x = M[0][0]*v.x + M[0][1]*v.y + M[0][2]*v.z + M[0][3];
      o.y = M[1][0]*v.x + M[1][1]*v.y + M[1][2]*v.z + M[1][3];
      o.z = M[2][0]*v.x + M[2][1]*v.y + M[2][2]*v.z + M[2][3];
      o.w = M[3][0]*v.x + M[3][1]*v.y + M[3][2]*v.z + M[3][3];
    }

    template <class Float, class Vertex>
    void project(const Float v[3], Vertex& o) const {
      o.x = M[0][0]*v[0] + M[0][1]*v[1] + M[0][2]*v[2] + M[0][3];
      o.y = M[1][0]*v[0] + M[1][1]*v[1] + M[1][2]*v[2] + M[1][3];
      o.z = M[2][0]*v[0] + M[2][1]*v[1] + M[2][2]*v[2] + M[2][3];
      o.w = M[3][0]*v[0] + M[3][1]*v[1] + M[3][2]*v[2] + M[3][3];
    }

    void concat(const tmatrix& A, const tmatrix& B) {
      // m.concat(a,b) -> m*v == b*(a*v)
      for(int c=0;c<4;c++) {
        M[0][c] = B[0][0]*A[0][c] + B[0][1]*A[1][c] + B[0][2]*A[2][c] + B[0][3]*A[3][c];
        M[1][c] = B[1][0]*A[0][c] + B[1][1]*A[1][c] + B[1][2]*A[2][c] + B[1][3]*A[3][c];
        M[2][c] = B[2][0]*A[0][c] + B[2][1]*A[1][c] + B[2][2]*A[2][c] + B[2][3]*A[3][c];
        M[3][c] = B[3][0]*A[0][c] + B[3][1]*A[1][c] + B[3][2]*A[2][c] + B[3][3]*A[3][c];
      }
    }

    void invert_ortho(const tmatrix& A) {
      // Precondition: w = Mv = Rv + t  (R orthogonal)
      // Therefore: (M^-1)w = v = (R^T)Rv 
      //                        = (R^T)(Rv+t - t) 
      //                        = (R^T)(w-t) 
      //                        = (R^T)w - (R^T)t

      x_column(A[0][0], A[0][1], A[0][2]);  // row 0
      y_column(A[1][0], A[1][1], A[1][2]);  // row 1
      z_column(A[2][0], A[2][1], A[2][2]);  // row 2
      w_column(-A[0][0]*A[0][3] - A[1][0]*A[1][3] - A[2][0]*A[2][3],
               -A[0][1]*A[0][3] - A[1][1]*A[1][3] - A[2][1]*A[2][3],
               -A[0][2]*A[0][3] - A[1][2]*A[1][3] - A[2][2]*A[2][3]);
      w_row();
    }

    const double* operator [](int n) const { return M[n]; }
    double* operator [](int n) { return M[n]; }

    // M^-1 * [x y z w]
    Vector times_inv(const Vector& v, double w=1.0) const {
      double x = v.x - M[0][3]*w, y = v.y - M[1][3]*w, z = v.z - M[2][3]*w;
      return Vector(M[0][0]*x + M[1][0]*y + M[2][0]*z,
                    M[0][1]*x + M[1][1]*y + M[2][1]*z,
                    M[0][2]*x + M[1][2]*y + M[2][2]*z);
    }

    // multiplication by a vector [x y z 0]
    Vector times_v(const Vector& v) const {
      return Vector(
        M[0][0]*v.x + M[0][1]*v.y + M[0][2]*v.z,
        M[1][0]*v.x + M[1][1]*v.y + M[1][2]*v.z,
        M[2][0]*v.x + M[2][1]*v.y + M[2][2]*v.z
      );
    }

    // multiplication by a point [x y z 1]
    Vector operator *(const Vector& v) const {
      return Vector(
        M[0][0]*v.x + M[0][1]*v.y + M[0][2]*v.z + M[0][3],
        M[1][0]*v.x + M[1][1]*v.y + M[1][2]*v.z + M[1][3],
        M[2][0]*v.x + M[2][1]*v.y + M[2][2]*v.z + M[2][3]
      );
    }
    double x(const Vector& v) const {
      return M[0][0]*v.x + M[0][1]*v.y + M[0][2]*v.z + M[0][3];
    }
    double y(const Vector& v) const {
      return M[1][0]*v.x + M[1][1]*v.y + M[1][2]*v.z + M[1][3];
    }
    double z(const Vector& v) const {
      return M[2][0]*v.x + M[2][1]*v.y + M[2][2]*v.z + M[2][3];
    }
    double w(const Vector& v) const {
      return M[3][0]*v.x + M[3][1]*v.y + M[3][2]*v.z + M[3][3];
    }
};

void frustum( tmatrix& T, tmatrix& I, double l, double r, double b, double t, double n, double f );
void rotation( tmatrix& T, double angle, const Vector& a);
double norm_dot(const Vector& a, const Vector& b);
void py_rotation( tmatrix& R, Vector r_origin, Vector r_axis, const Dict& kw );

#endif
