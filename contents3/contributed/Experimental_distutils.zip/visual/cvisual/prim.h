#ifndef PRIM_H
#define PRIM_H

#include "display.h"
#include "color.h"
#include "tmatrix.h"

class Primitive : public PythonExtension<Primitive>, public DisplayObject {
  public:
    Primitive();

    virtual void fromDictionary(Dict d);
      // Initializes attributes from the given dictionary.  May throw
      //   exceptions.

    virtual Object getattr( const char *attr );
    virtual int setattr( const char* attr, const Object& value );
    Object py_rotate(const Tuple& args, const Dict& kw);

    virtual void refreshCache();

    static void init_type();
      // Initializes the Python type object for Primitives.  Called
      //   by the module initialization.  A single type is used for
      //   all subclasses of Primitive.

    virtual Object getObject() { return Object(this); }

  protected:
    // attributes:
    lockedVectorPtr<mutex, write_lock>
             pos, 
             axis,
             up;
    rgb      color;
    Dict     user;

    virtual Vector getScale() = 0;

    // Synthetic attributes
    //
    //   By default, ALL of these functions raise
    //     AttributeError.  Subclasses of primitive
    //     that actually define these attributes should
    //     override them.
    //
    //   A subclass of primitive can add other attributes
    //     by overriding getattr and setattr.

    virtual double getRadius();
    virtual void   setRadius(double);
    virtual double getLength();
    virtual void   setLength(double);
    virtual double getHeight();
    virtual void   setHeight(double);
    virtual double getWidth();
    virtual void   setWidth(double);
	virtual int    getFixedWidth();
	virtual void   setFixedWidth(int);
    virtual double getShaftWidth();
    virtual void   setShaftWidth(double);
    virtual double getHeadWidth();
    virtual void   setHeadWidth(double);
    virtual double getHeadLength();
    virtual void   setHeadLength(double);
    virtual double getThickness();
    virtual void   setThickness(double);
    virtual Vector getSize();
    virtual void   setSize(Vector);

    // cache
    bool degenerate;
    tmatrix mwt;    // model to world
    tmatrix wlt;    // world to lighting
    Vector scale;
};

#endif
