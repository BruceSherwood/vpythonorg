#include "gldevice.h"
#include "mouseobject.h"
/*
 * Hmm, these don't exist on *my* operating system. If someone wants them
 * back, perhaps an appropriate mechanism through platform.h should be used ...
 */
//using namespace win;
//#include <process.h>

char * ButtonName(int buttons) { // called by clickObject and mouseObject
  switch (buttons) {
		case 1:
			return "left";
		case 2:
			return "right";
		case 3:
		case 4:
			return "middle";
		default:
			throw TypeError("Button type should be left, right, or middle.");
	}
}

/************* clickObject implementation ***************/

clickObject::clickObject() {
}

void clickObject::init_type() {
  behaviors().name("click");
  behaviors().supportGetattr();
  add_keyword_method("project", &clickObject::py_project);
}

Object clickObject::getattr( const char *_attr ) {
  string attr = _attr;

  if      (attr == "pos")
    return Object(new immutableVector(position));
  else if (attr == "pick")
    return pick;
  else if (attr == "pickpos")
    return Object(new immutableVector(pickpos));
  else if (attr == "camera")
    return Object(new immutableVector(cam));
  else if (attr == "ray")
    return Object(new immutableVector(ray));
  else if (attr == "button") {
    if (buttons) {
      return String(ButtonName(buttons));
    } else {
      return Object(Py_None);
    }
  }
  else if (attr == "press") {
    if (press) {
      return String(ButtonName(press));
    } else {
      return Object(Py_None);
      }
  }
  else if (attr == "release") {
    if (release) {
      return String(ButtonName(release));
    } else {
      return Object(Py_None);
      }
  }
  else if (attr == "click") {
    if (click) {
      return String(ButtonName(click));
    } else {
      return Object(Py_None);
      }
  }
  else if (attr == "drag") {
    if (drag) {
      return String(ButtonName(drag));
    } else {
      return Object(Py_None);
      }
  }
  else if (attr == "drop") {
    if (drop) {
      return String(ButtonName(drop));
    } else {
      return Object(Py_None);
      }
  }
  else if (attr == "shift") 
      return Int(shift);
  else if (attr == "alt") 
      return Int(alt);
  else if (attr == "ctrl") 
      return Int(ctrl);

  return getattr_methods(_attr);
}

Object clickObject::py_project( const Tuple& args, const Dict& kw ) {
  if (args.length()) throw TypeError("project() requires keyword arguments (name=value)");

  if (!kw.hasKey("normal")) throw TypeError("project: must specify normal=[x y z]");
  Vector normal(kw["normal"]);
  
  double d = 0.0;
  if (kw.hasKey("point")) {
    Vector point(kw["point"]);
    d = normal.dot(point);
    if (kw.hasKey("d")) throw TypeError("project: if point is specified, d cannot be");
  } else if (kw.hasKey("d")) {
    d = Float(kw["d"]);
    if (kw.hasKey("point")) throw TypeError("project: if d is specified, point cannot be");
  }

  double ndc = normal.dot(cam) - d;
  double ndr = normal.dot(ray);
  if (!ndr) return Nothing();

  double t = -ndc/ndr;
  if (t<0) return Nothing();

  Vector v = cam + ray*t;
  return Object(new immutableVector(v));
}

/************** mouseObject implementation **************/

mouseObject::mouseObject() {
}

void mouseObject::init_type() {
  behaviors().name("mouse");
  behaviors().supportGetattr();
  behaviors().supportSetattr();
  add_varargs_method("getclick", &mouseObject::py_getclick);
  add_varargs_method("getevent", &mouseObject::py_getevent);
  add_keyword_method("project", &mouseObject::py_project);
}


/*
 * Thou Shalt Not Allocate Returns to Python on the Heap, 
 * for Python Shall Remember Them Forever!
 */
Object mouseObject::getattr( const char *_attr ) {
  string attr = _attr;

  mutex::lock L(mtx);

  if      (attr == "pos")
    return Object( &position);
  else if (attr == "pick")
    return pick;
  else if (attr == "pickpos")
    return Object( &pickpos);
  else if (attr == "clicked")
    return Int(clickCount);
  else if (attr == "events")
    return Int((int)clicks.size());
  else if (attr == "camera")
    return Object( &cam);
  else if (attr == "ray")
    return Object( &ray);
  else if (attr == "button") {
    if (buttons) {
      return String(ButtonName(buttons));
    } else {
      return Object(Py_None);
    }
  }
  else if (attr == "press") {
    if (press) {
      return String(ButtonName(press));
    } else {
      return Object(Py_None);
      }
  }
  else if (attr == "release") {
    if (release) {
      return String(ButtonName(release));
    } else {
      return Object(Py_None);
      }
  }
  else if (attr == "click") {
    if (click) {
      return String(ButtonName(click));
    } else {
      return Object(Py_None);
      }
  }
  else if (attr == "drag") {
    if (drag) {
      return String(ButtonName(drag));
    } else {
      return Object(Py_None);
      }
  }
  else if (attr == "drop") {
    if (drop) {
      return String(ButtonName(drop));
    } else {
      return Object(Py_None);
      }
  }
  else if (attr == "shift") 
      return Int(shift);
  else if (attr == "alt") 
      return Int(alt);
  else if (attr == "ctrl") 
      return Int(ctrl);

  return getattr_methods(_attr);
}

int mouseObject::setattr( const char *_attr, const Object& value ) {
  string attr = _attr;

  if (attr == "events") {
    if (Int(value) == 0) {
      while (1) {
        { mutex::lock L(mtx);
          if (clicks.size()) {
            Object c = clicks[0];
            clicks.erase(clicks.begin());
			bool clicktype = clickList[0];
			clickList.erase(clickList.begin());
	        if (clicktype) {
		      clickCount -= 1;
			}
          } else return 0;
        }
        threaded_sleep(0.010);
      }
    } else throw TypeError("mouse.events can only be set to zero");
  } else throw TypeError("Only mouse.events can be set");

}

Object mouseObject::py_getevent(const Tuple& args) {
  if (args.length()) throw TypeError("getevent() expects no arguments");

  while (1) {
    { mutex::lock L(mtx);
      if (clicks.size()) {
        Object c = clicks[0];
        clicks.erase(clicks.begin());
        bool clicktype = clickList[0];
        clickList.erase(clickList.begin());
        if (clicktype) {
          clickCount -= 1;
        }
        return c;
      }
    }
    threaded_sleep(0.010);
  }
}

Object mouseObject::py_getclick(const Tuple& args) {
  if (args.length()) throw TypeError("getclick() expects no arguments");

  while (1) {
    { mutex::lock L(mtx);
      if (clicks.size()) {
        Object c = clicks[0];
        clicks.erase(clicks.begin());
        bool clicktype = clickList[0];
        clickList.erase(clickList.begin());
        if (clicktype) {
          clickCount -= 1;
          return c;
        }
      }
    }
    threaded_sleep(0.010);
  }
}

Object mouseObject::py_project( const Tuple& args, const Dict& kw ) {
  if (args.length()) throw TypeError("project() requires keyword arguments (name=value)");

  if (!kw.hasKey("normal")) throw TypeError("project: must specify normal=[x y z]");
  Vector normal(kw["normal"]);
  
  double d = 0.0;
  if (kw.hasKey("point")) {
    Vector point(kw["point"]);
    d = normal.dot(point);
    if (kw.hasKey("d")) throw TypeError("project: if point is specified, d cannot be");
  } else if (kw.hasKey("d")) {
    d = Float(kw["d"]);
    if (kw.hasKey("point")) throw TypeError("project: if d is specified, point cannot be");
  }

  double ndc = normal.dot(cam) - d;
  double ndr = normal.dot(ray);
  if (!ndr) return Nothing();

  double t = -ndc/ndr;
  if (t<0) return Nothing();

  Vector v = cam + ray*t;
  return Object(new immutableVector(v));
}


/************** cursorObject implementation **************/

cursorObject::cursorObject() {
	last_visible = visible = true; // default is cursor is visible
}

void cursorObject::init_type() {
  behaviors().name("cursor");
  behaviors().supportGetattr();
  behaviors().supportSetattr();
}

Object cursorObject::getattr( const char *_attr ) {
  string attr = _attr;

  mutex::lock L(mtx);

  if (attr == "visible") {
    return Int(visible);
  }

  return getattr_methods(_attr);
}

int cursorObject::setattr( const char *_attr, const Object& value ) {
  string attr = _attr;

	if (attr == "visible") {
    visible = Int(value) ? true : false;
	}

  return(0);

}
