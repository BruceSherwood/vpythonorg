#include "label.h"
#include "prim.h"
#include GL_INCLUDE

Object create_label(const Tuple& args, const Dict& kwargs);

Object create_label(const Tuple& args, const Dict& kwargs) {
  return init(new Label,args,kwargs);
}

Label::Label()
 : pos(mtx, 0,0,0),
   space(0),
   xoffset(0),
   yoffset(0),
   border(5),
   clip(-1),
   box_enabled(true),
   line_enabled(true),
   color(1,1,1),
   lineColor(1,1,1),
   opacity(0.66),
   textWidth(0.0)
{
  setattr("text", String(""));
  font = 0;
  font_description = "";
  font_height = 0;
}

Label::~Label() {
  if (font) font->release();
}

void Label::init_type() {
  behaviors().name("Label");
  behaviors().supportGetattr();
  behaviors().supportSetattr();
  behaviors().supportStr();
}

void Label::refreshCache() {
}

void Label::glRender(rView& view) {
  if (!font) {
    font = view.cx.getFont(font_description.c_str(), font_height);
    if (!font) return;
  }

  glNewList( view.createSortList(), GL_COMPILE );
  glDisable(GL_DEPTH_TEST);

  view.ext_point(*pos);

  double xpix = 2.0 / view.cx.width(), 
         ypix = 2.0 / view.cx.height();

  // alignv is the *screen space* direction pointing
  //   from *pos to the origin of the text
  Vector alignv( xoffset * xpix, yoffset * ypix );
 
  double wInverse = 1.0 / view.wct.w(*pos);
  Vector proj_pos = (view.wct * *pos) * wInverse;
  Vector start = proj_pos;

  if (space) {
    double cube[6][3] = { {1,0,0}, {-1,0,0}, {0,1,0},{0,-1,0}, {0,0,1},{0,0,-1} };
    double r2 = 0;
    for(int f=0;f<6;f++) {
      Vector v = Vector(cube[f])*space + *pos;
      v = view.wct*v/view.wct.w(v) - proj_pos;
      double m = (v.x*v.x / xpix/xpix) + (v.y*v.y / ypix/ypix);
      if (m > r2) r2=m;
    }

    Vector spacev = alignv.norm0() * sqrt(r2);  // in pixels
    start = start + Vector(spacev.x * xpix, spacev.y * ypix);
  }

  Vector end = start + alignv;

  double borderx = border * 2 / view.cx.width(),
         bordery = border * 2 / view.cx.height();
  if (textWidth == 0.0)         
    for (int i = 0; i < text.size(); i++)
      if (font->getWidth( text[i].c_str() ) > textWidth)
        textWidth = font->getWidth( text[i].c_str() );
  double width = borderx + textWidth;
  double descent = font->descent() + bordery,
         ascent = font->ascent() + bordery;
  double height = ascent + descent;         

  Vector origin;
  if ( !alignv ) {
    // center align, center vertically
    origin = end + Vector( -(width-borderx)/2, (descent-ascent)/2 );
  } else if ( fabs(alignv.x) > fabs(alignv.y) ) {
    // left or right align, center vertically
    if (alignv.x > 0)
      origin = end + Vector(borderx, (descent-ascent)/2);
    else
      origin = end + Vector(-width, (descent-ascent)/2);
  } else {
    // center align, top or bottom vertically
    if (alignv.y > 0)
      origin = end + Vector( -(width-borderx)/2, descent);
    else
      origin = end + Vector( -(width-borderx)/2, -ascent);
  }

  glDisableClientState(GL_VERTEX_ARRAY);
  glDisableClientState(GL_COLOR_ARRAY);
  glShadeModel(GL_FLAT);

  if (opacity) {
    glBegin(GL_POLYGON);
    glColor4f(0,0,0,opacity);
    glVertex3d(origin.x - borderx, 
               origin.y - descent, 
               origin.z);
    glVertex3d(origin.x + width, 
               origin.y - descent, 
               origin.z);
/*
 *     glVertex3d(origin.x - borderx, 
 *                origin.y - descent - ((text.size()-1) * height), 
 *                origin.z);
 *     glVertex3d(origin.x + width, 
 *                origin.y - descent - ((text.size()-1) * height), 
 *                origin.z);
 */
    glVertex3d(origin.x + width, 
               origin.y + ascent + ((text.size()-1) * height), 
               origin.z);
    glVertex3d(origin.x - borderx, 
               origin.y + ascent + ((text.size()-1) * height), 
               origin.z);
    glEnd();
  }

  if (box_enabled) {
    glBegin(GL_LINE_LOOP);
    glColor4f(lineColor.r,lineColor.g,lineColor.b,1);
    glVertex3d(origin.x - borderx, 
               origin.y - descent, 
               origin.z);
    glVertex3d(origin.x + width, 
               origin.y - descent, 
               origin.z);
/*
 *     glVertex3d(origin.x - borderx, 
 *                origin.y - descent - ((text.size()-1) * height), 
 *                origin.z);
 *     glVertex3d(origin.x + width, 
 *                origin.y - descent - ((text.size()-1) * height), 
 *                origin.z);
 */
    glVertex3d(origin.x + width, 
               origin.y + ascent + ((text.size()-1) * height), 
               origin.z);
    glVertex3d(origin.x - borderx, 
               origin.y + ascent + ((text.size()-1) * height), 
               origin.z);
    glEnd();
  }

  if (line_enabled) {
    glBegin(GL_LINES);
    glColor4f(lineColor.r, lineColor.g, lineColor.b,1);
    glVertex3d(start.x,start.y,start.z);
    glVertex3d(end.x,end.y,end.z);
    glEnd();
  }

  glColor4f(color.r,color.g,color.b,1);
  for (int i = 0; i < text.size(); i++) {
    glRasterPos3d(origin.x, 
                  origin.y + ((text.size()-1)*height) - (i*height), 
                  origin.z );
//    glRasterPos3d( origin.x, origin.y - (i * height), origin.z );
    font->draw(text[i].c_str());
  }

  glEnable(GL_DEPTH_TEST);
  glEndList();
}

Object Label::str() {
  string s;
  s = text[0];
  for (int i = 1; i < text.size(); i++)
    s += "\n" + text[i];
  return String(s);
}

Object Label::getattr(const char* _attr) {
  string attr = _attr;

  switch (_attr[0]) {
    case 'b':
      if (attr == "blue") return Float( color.b );
      if (attr == "border") return Float( border );
      if (attr == "box") return Int(box_enabled);
      break;
    case 'c':
      if (attr == "color") return color.asTuple();
      if (attr == "clip") return Float(clip);
      break;
    case 'd':
      if (attr == "display") return Object(display);
      break;
    case 'f':
      if (attr == "font") return String(font_description);
      if (attr == "frame") return parentObject;
      break;
    case 'g':
      if (attr == "green") return Float( color.g );
      break;
    case 'h':
      if (attr == "height") return Float( font_height );
      break;
    case 'l':
      if (attr == "line") return Int(line_enabled);
      if (attr == "linecolor") return lineColor.asTuple();
      break;
    case 'o':
      if (attr == "opacity") return Float(opacity);
      break;
    case 'p':
      if (attr == "pos") return Object(pos);
      break;
    case 'r':
      if (attr == "red") return Float( color.r );
      break;
    case 's':
      if (attr == "space") return Float(space);
      break;
    case 't':
      if (attr == "text") {
        string s;
        s = text[0];
        for (int i = 1; i < text.size(); i++)
          s += "\n" + text[i];
        return String(s);
      }
      break;
    case 'v':
      if (attr == "visible") return Int(visible);
      break;
    case 'x': if (!_attr[1]) return Float( pos->x );
      if (attr == "xoffset") return Float( xoffset );
      break;
    case 'y': if (!_attr[1]) return Float( pos->y );
      if (attr == "yoffset") return Float( yoffset );
      break;
    case 'z': if (!_attr[1]) return Float( pos->z );
      break;
    case '_': 
      if (attr == "__dict__") return user;
      break; 
  }

  if (user.hasKey(attr)) {
    return user[attr];
  } else
    return getattr_methods(_attr);
}

int Label::setattr(const char* _attr, const Object& value) {
  string attr = _attr;

  switch (_attr[0]) {
    case 'b':
      if (attr == "blue") {
        write_lock L(mtx);
        color.b = Float(value);
        return 0;
      };
      if (attr == "border") {
        write_lock L(mtx);
        border = Float(value);
        return 0;
      }
      if (attr == "box") {
        write_lock L(mtx);
        box_enabled = Int(value) ? true : false;
        return 0;
      }
      break;
    case 'c':
      if (attr == "color") {
        write_lock L(mtx);
        color = rgb(value);
        return 0;
      }
      if (attr == "clip") {
        write_lock L(mtx);
        clip = Float(value);
        return 0;
      }
      break;
    case 'd':
      if (attr == "display") {
        write_lock L(mtx);
        ExtensionObject<Display> v(*value);
        setDisplay( v.extensionObject() );
        return 0;
      }
      break;
    case 'f':
      if (attr == "font") {
        write_lock L(mtx);
        font_description = String(value);
        if (font) { font->release(); font = 0; }
        return 0;
      }
      if (attr == "frame") {
        write_lock L(mtx);
        if (value.is(Nothing())) {
          setParent(0);
        } else {
          setParent(ExtensionObject<Primitive>(*value).extensionObject(), value);
        }
        return 0;
      }
      break;
    case 'g':
      if (attr == "green") {
        write_lock L(mtx);
        color.g = Float(value);
        return 0;
      };
      break;
    case 'h':
      if (attr == "height") {
        write_lock L(mtx);
        font_height = Float(value);
        if (font) { font->release(); font = 0; }
        return 0;
      }
      break;
    case 'l':
      if (attr == "line") {
        write_lock L(mtx);
        line_enabled = Int(value) ? true : false;
        return 0;
      }
      if (attr == "linecolor") {
        write_lock L(mtx);
        lineColor = rgb(value);
        return 0;
      }
      break;
    case 'o':
      if (attr == "opacity") {
        write_lock L(mtx);
        opacity = Float(value);
        return 0;
      }
      break;
    case 'p':
      if (attr == "pos") {
        write_lock L(mtx);
        pos = Vector(value);
        return 0;
      }
      break;
    case 'r':
      if (attr == "red") {
        write_lock L(mtx);
        color.r = Float(value);
        return 0;
      };
      break;
    case 's':
      if (attr == "space") {
        write_lock L(mtx);
        space = Float(value);
        return 0;
      }
      break;
    case 't':
      if (attr == "text") {
        write_lock L(mtx);
        string s = String(value);
        /*
        string s;
        if (value.is(Py_None)) {
          s = "None";
        } else {
          s = String(value);
        }
        */
        for (int i = 0; i < s.length(); i++)
          if (s[i] == '\n')
            s[i] = 0;
        int c = 0;
        text.clear();
        textWidth = 0.0;
        text.push_back( String(s) );
        while ( (c = s.find('\0', c+1)) >= 0 ) 
          text.push_back( String(&s[c+1]) );
        return 0;
      }
      break;
    case 'v':
      if (attr == "visible") {
        write_lock L(mtx);
        setVisible( Int(value) ? true : false );
        return 0;
      }
      break;
    case 'x': if (!_attr[1]) {
                write_lock L(mtx);
                pos->x = Float(value);
                return 0;
              }
      if (attr == "xoffset") {
        write_lock L(mtx);
        xoffset = Float(value);
        return 0;
      }
      break;
    case 'y': if (!_attr[1]) {
                write_lock L(mtx);
                pos->y = Float(value);
                return 0;
              }
      if (attr == "yoffset") {
        write_lock L(mtx);
        yoffset = Float(value);
        return 0;
      }
      break;
    case 'z': if (!_attr[1]) {
                write_lock L(mtx);
                pos->z = Float(value);
                return 0;
              }
      break;
  }

  user[attr] = value;
  return 0;
};

void Label::fromDictionary(Dict d) {
  if (d.hasKey("pos"))
    setattr("pos",d["pos"]);

  if (d.hasKey("display")) 
    setattr("display",d["display"]);

  if (d.hasKey("color")) {
    setattr("color",d["color"]);
  } else {
    write_lock L(mtx);
    color = display->fgcolor();
  }

  List items = d.items();
  for(List::iterator i = items.begin(); i != items.end(); i++) {
    Tuple it = Object(*i);
    string attr = String(it[0]);
    if (attr != "visible" && attr != "color" &&
        attr != "pos"     && attr != "display")
    {
      setattr(attr.c_str(),it[1]);
    }
  }

  if (d.hasKey("visible")) 
    setattr("visible",d["visible"]);
  else
    setVisible(1);
}
