#include "aglcx.h"

#include <Fonts.h>
#include <MacWindows.h>
#include <TextUtils.h>

extern char *CtoPstr(char *ss);
extern char *PtoCstr(unsigned char *ss);

map< AGLDrawable, aglContext* > aglContext::windowMap;

/***************** Initialization and termination *****************/

aglContext::aglContext() {
  current = 0;
  drawable = 0;
  context = 0;
  
  buttonState = buttonChanged = 0;
}

aglContext::~aglContext() {
  cleanup();
}

/****************** Basic window functionality *******************/
        
bool aglContext::initWindow( const char* title, int x, int y, int width, int height ) {
  // Create a window with the specified dimensions and title.

  // try to put the window in a good place on the screen
  Rect limits;
  limits = (*GetGrayRgn())->rgnBBox;
  if (x<limits.left) x = limits.left; 
  if (y<2*limits.top) y = 2*limits.top;
  if (x+width > limits.right) width = limits.right-x;
  if (y+height > limits.bottom) height=limits.bottom-y;

  // xxx Convert title to a pascal string and pass it ot NewCWindow
  string pascalTitle = string("X") + string(title);
  pascalTitle[0] = strlen(title);

  Rect rect;
  SetRect(&rect, x, y, x + width, y+height);
  drawable = (AGLDrawable)NewCWindow(NULL,             // wStorage
                                     &rect,            // boundsRect
                                     (unsigned char*)pascalTitle.c_str(),   // title
                                     false,            // visible
                                     8,                // procID
                                     (WindowPtr)-1L,   // behind
                                     true,             // goAwayFlag
                                     0L);              // refCon
  if (!drawable) { cleanup(); return false; }
  
  windowMap[ drawable ] = this;

  // Display the window
  ShowWindow( (WindowPtr) drawable );

  // Choose an appropriate pixel format:
  GLint attrib[] = { AGL_RGBA, 
                     AGL_DOUBLEBUFFER,
                     AGL_MINIMUM_POLICY,
                     AGL_DEPTH_SIZE, 12,
                     AGL_NONE };
  AGLPixelFormat pixfmt = aglChoosePixelFormat( NULL, 0, attrib );
  if (!pixfmt) { cleanup(); return false; }
  
  // Create an OpenGL rendering context:
  context = aglCreateContext( pixfmt, NULL );
  if (!context) { cleanup(); return false; }
  
  // Bind the drawable and context together
  if (!aglSetDrawable( context, drawable )) { cleanup(); return false; }

  // xxx Call aglSetOptions if necessary

  return true;
}

bool aglContext::changeWindow( const char* title, int x, int y, int width, int height ) {
  if (x>=0 || y>=0 || width>=0 || height>=0) {
    // xxx Move the window to the specified coordinates.
  }

  if (title) {
    // xxx Change the title of the window to the specified text.
  }

  // xxx Call aglUpdateCurrent()?

  // xxx Return true on success
  return false;
}

bool aglContext::isOpen() {
  // Return true if a window has been created (and not subsequently destroyed)

  return (context != NULL);
}

void aglContext::cleanup() {
  if (context) {
    aglDestroyContext(context);
    context=0;
  }
  if (drawable) {
    windowMap[drawable] = 0;
    
    // Destroy the window
    DisposeWindow( (WindowPtr) drawable );
    drawable=0;
  }
}

aglContext* aglContext::get( AGLDrawable d ) {
  return windowMap[d];
}
  
void aglContext::makeCurrent() {
  if (!current) {
    // Save previous context to be restored in makeNotCurrent()
    last_context = aglGetCurrentContext();

    // Set new context and drawable.
    aglSetCurrentContext(context);
  }
  current++;
}

void aglContext::makeNotCurrent() {
  current--;
  if (!current) {
    // Restore the old context and drawable:
    aglSetCurrentContext(last_context);

    // Clear the "last" value to avoid confusion:
    last_context = 0;    
  } 
}

void aglContext::swapBuffers() {
  // Copy the off-screen drawing buffer to the display:
  aglSwapBuffers(context);
}

/****************** Properties **********************/

Vector aglContext::origin() {
  // xxx Return upper-left corner of entire window
  //   origin() should initially be the same as the (x,y) coordinates passed to initWindow()

  return Vector(0,0);
}


Vector aglContext::corner() {
  // xxx Return lower-left corner of entire window
  //   corner() - origin() should initially be the same as the (width,height) passed to initWindow()

  return Vector(50,0);
}

int aglContext::width() {
  // Return the width of the GL viewport (not including the window border)
  Rect rect;
  
  GetWindowBounds( (WindowPtr)drawable, kWindowContentRgn, &rect );
  return rect.right - rect.left;
}

int aglContext::height() {
  // Return the height of the GL viewport (not including the window border)
  Rect rect;

  GetWindowBounds( (WindowPtr)drawable, kWindowContentRgn, &rect );
  return rect.bottom - rect.top;
}

string aglContext::lastError() {
  // xxx Return any error message generated by another function
  return "Error information is not available.";
}

/**************** font implementation *******************/

/* glFont* aglContext::getFont(const char* description, double size) {
  return 0;
} */

aglFont::aglFont( struct aglContext& _cx,
                  int _fontID, Style _face, int _size)
 : cx(_cx), fontID(_fontID), face(_face), size(_size)

{ WindowPtr curPort;	/* the current drawing port */
  short oldFont, oldSize, oldFace;	/* to save & restore current font */
  FontInfo fi;	/* font information */
  cx.makeCurrent();

  listBase = glGenLists(256);
  aglUseFont(cx.context, fontID, face, size, 0, 256, listBase);

  /* XXX Precompute things like ascent and descent if possible */

  GetPort(&curPort); // save current state
  oldFont = curPort->txFont;
  oldSize = curPort->txSize;
  oldFace = curPort->txFace;
  
  TextFont(fontID); // select font
  TextSize(size);
  TextFace(face);
  
  GetFontInfo(&fi);

  this->fAscent = fi.ascent;
  this->fDescent = fi.descent;
  this->fWidth = fi.widMax;
  
  TextFont(oldFont); // restore original state
  TextSize(oldSize);
  TextFace(oldFace);
  
  cx.makeNotCurrent();
}

void aglFont::draw(const char* string) {
  if (listBase>=0) {
    glListBase(listBase);
    glCallLists( strlen(string), GL_UNSIGNED_BYTE, string );
  }
}

double aglFont::getWidth(const char* string) {
  // XXX handle newline?
  int pixel_width = TextWidth(string,0,strlen(string));

  // Convert to viewport coordinates and return it
  return double(pixel_width * 2) / cx.width();
}

double aglFont::ascent() {
  // XXX find the maximum distance from the baseline to
  //     the top of a glyph (e.g. "M"), in pixels
  int pixel_ascent = this->fAscent;

  // Convert to viewport coordinates and return it
  return double(pixel_ascent * 2) / cx.height();
}

double aglFont::descent() {
  // XXX find the maximum distance from the baseline to
  //     the bottom of a glyph (e.g. "M"), in pixels
  int pixel_descent = this->fDescent;

  return double(pixel_descent * 2) / cx.height();
}

void aglFont::release() {
  if (!--refcount) {
    if (listBase>=0 && cx.isOpen()) {
      cx.makeCurrent();
      glDeleteLists(listBase, 256);
      cx.makeNotCurrent();
    }
    delete this;
  }
}

glFont* aglContext::getFont(const char* description, double pixelsize) {
  
  if (!description || !*description) description="";
  if (pixelsize <= 0.0) pixelsize = 12.0;

  pair<string, double> key(description, pixelsize);
  aglFont* f = fontCache[key];

  if (f) {
    f->addref();
    return f;
  }

  /* XXX Somehow make up valid fontID, face, and size parameters based
     on the given description and pixelsize */
  short fontID;
  Style face = 0;
  int size;
  char pdescrip[256]; /* font description as Pascal string */
  
  strncpy(pdescrip,description,255);
  pdescrip[255] = 0;
  C2PStr((char *)pdescrip);
  GetFNum((const unsigned char *)pdescrip,&fontID);
  if (fontID == 0) 
  	GetFNum("\pgeneva",&fontID); /* use Geneva if specified font doesn't exist */
  	
  CGrafPtr curWorldP; /* pointer to current graphics world */
  GDHandle curDeviceH; /* current device */
  PixMapHandle curPixMapH; /* graphic world's pixmap */

  GetGWorld(&curWorldP,&curDeviceH);
  curPixMapH = GetGWorldPixMap(curWorldP);
  size = 72.0*pixelsize/((*curPixMapH)->hRes/65536.0); /* points */
  f = new aglFont(*this, fontID, face, size);

  f->addref();
  fontCache[key] = f;
  return f;
}

/**************** Mouse functionality *******************/

void aglContext::showMouse() {
  // xxx
}

void aglContext::hideMouse() {
  // xxx
}

void aglContext::lockMouse() {
  // xxx
}

void aglContext::unlockMouse() {
  // xxx
}

Vector aglContext::getMousePos() {
  Point where;
  SetPort( (WindowPtr) drawable );
  GetMouse( &where );
  return Vector(double(where.h) / width(), double(where.v) / height());
}

Vector aglContext::getMouseDelta() {  // mouse movement in pixels
  Point where;
  SetPort( (WindowPtr) drawable );
  GetMouse( &where );

  Vector delta( where.h - mousePos.x, where.v - mousePos.y );
  mousePos.x = where.h;
  mousePos.y = where.v;

  return Vector(delta.x, delta.y);
}

int aglContext::getMouseButtons() {
  return buttonState;
}

int aglContext::getMouseButtonsChanged() {
  unsigned changed = buttonChanged;
  buttonChanged = 0;
  return changed;
}

int aglContext::getShiftKey() {
	return 0; //Kshift;
}

int aglContext::getAltKey() {
	return 0; //Kalt;
}

int aglContext::getCtrlKey() {
	return 0; //Kctrl;
}


/**************** Event handling *********************/

bool aglContext::handleMouseDown( struct EventRecord* event, int windowCode ) {
  WindowPtr win = (WindowPtr)drawable;
  
  switch (windowCode) {
    case inGoAway:
      if (TrackGoAway( win, event->where )) {  // blocking call
        // destroy the window
        cleanup();
      }
      return true;

    case inSysWindow:
      SystemClick( event, win );
      return true;

    case inDrag: {
      Rect limits;
      limits = (*GetGrayRgn())->rgnBBox;
      limits.left += 4;
      limits.right -= 4;
      limits.top += 4;
      limits.bottom -= 4;
      DragWindow( win, event->where, &limits );
      aglUpdateContext( context );
      return true;
    }
    
    case inZoomIn:
    case inZoomOut:
      if (TrackBox( win, event->where, windowCode )) {
        ZoomWindow(win, windowCode, true);        
        aglUpdateContext( context );
      }
      return true;

    case inContent: {
      if (FrontWindow() != win)
        SelectWindow( win );
        
      int button = (event->modifiers & shiftKey) ? 2 : 1;
      if (event->modifiers & controlKey) button = 3;
      buttonChanged = buttonState ^ button;
      buttonState = button;
      
      return true;
    }
      
    case inGrow: {
      Rect limits;
      Rect rr;	
      rr = (*GetGrayRgn())->rgnBBox;
      SetRect(&limits,50,30,rr.right - rr.left,rr.bottom - rr.top);
      unsigned long newsize = GrowWindow( win, event->where, &limits );
      if (newsize) {
        SizeWindow( win, newsize&0xFFFF, (newsize >> 16)&0xFFFF, false );
        aglUpdateContext( context );      
      }
      return true;
    }    
  }
  return true;
}

bool aglContext::handleMouseUp( struct EventRecord* event, int windowCode ) {
  switch (windowCode) {
    case inContent:
      int button = 0;  //(event->modifiers & shiftKey) ? 2 : 1;
      buttonChanged = buttonState ^ button;
      buttonState = button;
      
      return true;
  }

  return true;
}

bool aglContext::handleUpdate( struct EventRecord* event ) {
  return true;
}

bool aglContext::handleEvent( struct EventRecord* event ) {
  // This is a static function in the scope of aglContext.  It does not
  //   have a this pointer, because we don't know yet which aglContext the
  //   event is intended for!

  // It identifies the window each event is intended for (this is done
  //   differently for different events), and then searches for an aglContext
  //   bound to that window in the windowMap.  If it doesn't find one, it
  //   returns false (since the event must be intended for some other window
  //   in our process, and should be handled by the library that created that
  //   window).
  
  // If it does find an aglContext, it calls the appropriate handleWhatever()
  //   method of that aglContext.

  WindowPtr win;
  aglContext *cx;
  int windowCode;

  switch ( event->what ) {
    case updateEvt:
      win = (WindowPtr) event->message;
      cx = aglContext::get( (AGLDrawable) win );
      if (!cx) return false;
      
      return cx->handleUpdate( event );

    case mouseDown:
      windowCode = FindWindow( event->where, &win);
      cx = aglContext::get( (AGLDrawable) win );
      if (!cx) return false;

      return cx->handleMouseDown( event, windowCode );

    case mouseUp:
      windowCode = FindWindow( event->where, &win);
      cx = aglContext::get( (AGLDrawable) win );
      if (!cx) return false;      
      return cx->handleMouseUp( event, windowCode );
      
    case activateEvt:
      return true;
  }

  return false;
}