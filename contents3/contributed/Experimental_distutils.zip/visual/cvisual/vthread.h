// thread - General-purpose synchronization helpers

#ifndef THREAD_H
#define THREAD_H

template <class syncObject>
class lock {
  syncObject& obj;

  public:

  inline lock(syncObject& _obj) : obj(_obj) {
    _obj.sync_lock();
  }
  inline ~lock() {
    obj.sync_unlock();
  }

  private:  // not implemented by design
  lock(const lock&);
  void operator=(const lock&);
};

template <class syncObject>
class counted_lock {
  syncObject& obj;

  public:
  inline counted_lock(syncObject& _obj) : obj(_obj) { 
    _obj.count_lock(); 
  };
  inline ~counted_lock() { obj.sync_unlock(); }

  private:  // not implemented by design
  counted_lock(const counted_lock&);
  void operator=(const counted_lock&);
};

template <class dataObject, class syncObject>
class thread_safe {
  dataObject data;
  syncObject sync;

  public:
    thread_safe(const dataObject& _data) : data(_data) {}
    void operator=(const dataObject& _data) {
      lock<syncObject> L(sync);
      data = _data;
    }
    operator dataObject() {
      lock<syncObject> L(sync);
      return data;
    }
};

#endif
