#include "platform.h"
#include <queue>
#include <stdio.h>

#include <Python.h>

#include <sys/time.h>
#include <unistd.h>
#include <gtk/gtk.h>
#include <pthread.h>

using namespace std;

void init_platform() {
}

void threaded_exit (int status) {
  gdk_threads_enter();
  gtk_main_quit();
  gdk_threads_leave();
}

// 2003-02-16 Added explicit casts to unsigned int vice implicit casts from the compiler.
// TODO: Convert time values to integral types at the Python boundary.
void threaded_sleep(double seconds) {
  Py_BEGIN_ALLOW_THREADS
  usleep( (unsigned int)(seconds * 1e6));
  Py_END_ALLOW_THREADS
}

// 2003-02-16 Added explicit casts to unsigned int vice implicit casts from the compiler.
// TODO: Convert time values to integral types at the Python boundary.
void nothread_sleep(double seconds) {
  usleep( (unsigned int)(seconds * 1e6));
}

double sclock() {
  struct timeval tv;
  gettimeofday (&tv, NULL);

  return (tv.tv_sec + tv.tv_usec / 1e6);
}

/******** mutex implementation ********/

gMutex::gMutex(int spincount, int _count)
 : count(_count)
{
  if (!g_thread_supported()) g_thread_init (NULL);
  mutex = g_mutex_new();
}

gMutex::~gMutex() {
  g_mutex_free(mutex);
}

/*********** event handling not needed ********/

bool handle_event(PyObject*) {
  return false;
}

/*********** threaded_timer implementation *************/

int quit (ANY *) {
  Py_Exit(0);
}

void *mainloop (void *interp) {
  gtk_init (NULL, NULL);
  gtk_main ();
  Py_AddPendingCall(&quit, 0);
}

// 2003-02-16 Added explicit casts to unsigned int vice implicit casts from the compiler.
// TODO: Convert time values to integral types at the Python boundary.
void _threaded_timer(double seconds, bool (*callback)(void*), void *data) {
  static pthread_t thread;
  static int thread_init = pthread_create(&thread, NULL, mainloop, 0);

  if (callback) {
    gdk_threads_enter();
    gtk_timeout_add( (unsigned int)(seconds * 1000.0), (gint(*)(void*))callback, data);
    gdk_threads_leave();
  }
}
