#include "rate.h"

rate_timer::rate_timer() {
  origin = sclock();
}

void rate_timer::delay(double delay) {
  float t = delay - (sclock() - origin);
  if (t > 0.010) {
    threaded_sleep(t);
  } else while (delay - (sclock() - origin) > 0);

  origin = sclock();
};
