#ifndef GLDEVICE_H
#define GLDEVICE_H

#include "platform.h"
#include "display.h"
#include GL_INCLUDE    // see platform.h

const float clickTolerance = 3.0F; // pixel tolerance

class GLDevice : public Device {
  public:
    int render();

    GLDevice();
    ~GLDevice();

    // Device interface:
    virtual bool show();
    virtual void hide();
    virtual void join();
    virtual void frame();
    virtual bool closed();
    virtual string info();
    virtual void onClose(bool quit) { quitOnClose = quit; };

    virtual tmatrix get_wct() { return last_wct; }

    virtual void setX(int);
    virtual void setY(int);
    virtual void setWidth(int);
    virtual void setHeight(int);
    virtual void setNewmouse(bool);
    virtual int getX();
    virtual int getY();
    virtual int getWidth();
    virtual int getHeight();

  private:
    enum {HIDE, SHOW, DISPLAY, FRAME} mode;
    enum {INITIALIZE, NOBUTTONS, PRESS, DRAG, CLICK, DROP, ZOOM, SPIN} mouse_mode, last_mouse_mode;

    thread_safe<bool, mutex> active;

    double manual_scale;
    platform_glContext cx;
    int initx, inity, initw, inith;
    bool newmouse_enabled;
    bool quitOnClose;

    string vendor, version, renderer, extensions, error_message;

    unsigned oldButtons;
  	clickObject lastEvent;
    tmatrix proj, iproj, manual;
    float clickDelta;

    thread_safe<tmatrix, mutex> last_wct;

    void getProjection(tmatrix& wct, Vector& cam);
    Vector calcMousePos(Vector);
    void mouseControl(Vector pos, Vector cam, Vector ray, Object pick, Vector pickpos);
    void kbControl();

    void addCallback();
    static bool callback(GLDevice*);
    static PyThreadState *pyThread;
};

/*class pyThread {
  public:
    void writeStderr(const char* format, ...);

  private:
    bool running;
    PyInterpreterState *python;
    PyThreadState *pyThread;
    std::vector<GLDevice*> devices;
    mutex deviceLock;

    GLRendererThread();
    GLDevice* getNextDevice();
};

static void writeM(const tmatrix& t) {
  for(int row=0;row<4;row++)
    GLRendererThread::writeStderr("  %g %g %g %g\n",
      (float)t[row][0],
      (float)t[row][1],
      (float)t[row][2],
      (float)t[row][3] );
}*/

#endif
