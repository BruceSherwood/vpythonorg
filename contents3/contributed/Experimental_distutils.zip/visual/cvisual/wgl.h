// wgl - Windows platform-specific GL and windowing code

#ifndef WGL_H
#define WGL_H

#include "pvector.h"

using namespace Py;

#include <map>
#include <string>

using namespace std;

#include "platform.h"
#include "glcontext.h"
#include <gl/gl.h>

struct wglFont : glFont {
  public:
    // Documentation for these functions is in glFont, not here.
    virtual double getWidth(const char* string);
    virtual double ascent();
    virtual double descent();
    virtual void draw(const char* string);
    virtual void release();

    // for the use of wglContext only:
    wglFont( struct wglContext& cx, HFONT font );
    void addref() {refcount++;}

  private:
    struct wglContext &cx;
    int listBase;
    HFONT hfont;
    int lu_ascent, lu_descent;  // in Windows "logical units"
    int refcount;
};

struct wglContext : glContext {
  public:
    void lockMouse();
    void unlockMouse();
    void showMouse();
    void hideMouse();
    int  getMouseButtons();
    int  getMouseButtonsChanged();
    int getShiftKey();
    int getAltKey();
    int getCtrlKey();
    Vector  getMouseDelta();
    Vector  getMousePos();
    string getKeys();

    wglContext();
    ~wglContext();

    bool initWindow( const char* title, int x, int y, int width, int height );
    bool changeWindow( const char* title, int x, int y, int width, int height );
    bool isOpen();
    void cleanup();
  
    void makeCurrent();
    void makeNotCurrent();
    void swapBuffers();

    Vector origin();   // top left of entire window (or, same as initWindow())
    Vector corner();   // bottom right of entire window (or, same as initWindow())
    int width();       // of GL area
    int height();      // of GL area

    string lastError() { return error_message; }
    bool   mustPaint;

    glFont* getFont(const char* description, double size);

  private:
    std::map< std::pair<string, double>, wglFont* > fontCache;
    friend struct wglWindowClass;
    struct wglWindowClass& cls;
    HWND  hWnd;
    HDC   hdc, lasthdc;
    HGLRC hglrc, lastglrc;
    string error_message;

    int buttonState, buttonChanged;
    int Kshift, Kalt, Kctrl; //true if down when mouse event happens
    Vector mousePos, mouseDelta;
    bool mouseLocked;
    vector<string> keys;

    int current;  // incremented by makeCurrent(), decremented by makeNotCurrent()

    LRESULT winMessage( HWND, UINT, WPARAM, LPARAM );
    void error(string where);

    friend struct wglFont;
};

#endif
