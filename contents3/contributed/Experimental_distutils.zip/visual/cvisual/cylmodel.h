// cyl_model.h - Generates cylinder models, which are presently used
//   to render cones as well as cylinders.  Modeled after sph_model,
//   but not nearly as weird.

#ifndef CYLMODEL_H
#define CYLMODEL_H

struct cyl_model {
  float *verts;
  int nverts;

  // scratch data for renderer:
  vertex *proj;
  float *color;

  static cyl_model& get(int sides) {
    static cyl_model* models[100];
    if (sides>=100) sides=99;
    if (!models[sides])
      models[sides] = new cyl_model(sides);
    return *models[sides];
  }

  cyl_model(int sides) {
    nverts = 2*sides;
    verts = new float[3*nverts];
    proj = new vertex[nverts];
    color = new float[4*nverts];

    float *v = verts;
    float da = 2*pi/(sides-1);
    float sn = 0.0, cn = 1.0, temp;
	float sinda = sin(da), cosda = cos(da);
    for(int s=0;s<sides;s++) {

      v[0] = 0.0;
      v[1] = sn;
      v[2] = cn;
      v+=3;

      v[0] = 2.0;
      v[1] = sn;
      v[2] = cn;
      v+=3;

      temp = sn*cosda+cn*sinda; // sin(a+da) = sin(a)cos(da)+cos(a)sin(da)
	  cn = cn*cosda-sn*sinda;   // cos(a+da) = cos(a)cos(da)-sin(a)sin(da)
	  sn = temp;
    }
  }

  ~cyl_model() {
    delete[] verts;
    delete[] proj;
    delete[] color;
  }
};

#endif
