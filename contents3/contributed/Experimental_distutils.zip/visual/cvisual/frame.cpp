#include "prim.h"

class frame : public Primitive {
  public:
    virtual void glRender(rView& view) {
      // doesn't render directly
    }

    virtual Vector getScale() {
      return Vector(1,1,1);
    }

    virtual tmatrix getChildTransform() {
      updateCache();
      if (parent)
        return tmatrix(mwt, parent->getChildTransform());
      else
        return mwt;
    }

	virtual Object getattr(const char *a) {
      string attr = a;
      
      if (attr == "objects") {
        List objs;
        DisplayListIterator i(display->objects());
        
        for (i++; i; i++) {

          Object o = i->getObject();
          DisplayObject *dobj = &(*i);

          while (dobj->getParent()) {
            if (dobj->getParent() == this) {
              if (!o.is(Py_None))
                objs.append(o);
              break;
            } 
            dobj = dobj->getParent();
          }
          
        }
        
        return objs;

      } else {
        return Primitive::getattr(a);
      }
     }

};

Object create_frame(const Tuple& args, const Dict& kwargs) {
  return init(new frame,args,kwargs);
}

