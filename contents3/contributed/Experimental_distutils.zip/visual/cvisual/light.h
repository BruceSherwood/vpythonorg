#ifndef LIGHT_H
#define LIGHT_H

#include "pvector.h"
#include "tmatrix.h"

struct lighting {
  double ambient;
  int n_lights;
  enum {max_lights = 8};        // treat as a member
  Vector L[max_lights];

  /* All lights are monochrome, directional light sources for now.  The L
     vector points in the direction of the light, and has magnitude equal
     to the intensity of the light. 
     
     Ambient, n_lights, and L are exposed to clients for performance.  In
     an ideal universe, all clients would use the methods below.
   */

  lighting();
  lighting(const lighting& copy, const tmatrix& frame);

  double illuminate(Vector normal) {
    double d, i = ambient;
    for(int l=0;l<n_lights;l++) {
      d = L[l].dot(normal);
      if (d>0) i+=d;
    }
    return i;
  };

  double illuminate(double nx, double ny, double nz) {
    double d, i = ambient;
    for(int l=0;l<n_lights;l++) {
      d = L[l].x*nx + L[l].y*ny + L[l].z*nz;
      if (d>0) i+=d;
    }
    return i;
  }
};

#endif
