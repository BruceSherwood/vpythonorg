#include "platform.h"
#include "arrprim.h"
#include GL_INCLUDE

class faces : public ArrayPrimitive {
  protected:  
    Array pos_data, color_data, normal_data;
    Array normal;
    int allocated, count;

  public:
    faces()
     : allocated(0), count(0)
    {
      allocate(128);
      double *p = (double*)pos_data.to_C();
      p[0] = 0;
      p[1] = 0;
      p[2] = 0;

      double *c = (double*)color_data.to_C();
      rgb fg = display->fgcolor();
      c[0] = fg.r;
      c[1] = fg.g;
      c[2] = fg.b;

      double *n = (double*)normal_data.to_C();
      n[0] = 0;
      n[1] = 0;
      n[2] = 0;

      setLength(0);
    }

    virtual void fromDictionary(Dict d) {
      if (d.hasKey("pos")) {
        setPos(d["pos"]);
      } else if (d.hasKey("x")) {
        setLength( Sequence( d["x"] ).length() );
      } else if (d.hasKey("y")) {
        setLength( Sequence( d["y"] ).length() );
      } else if (d.hasKey("z")) {
        setLength( Sequence( d["z"] ).length() );
      }

      List items = d.items();
      for(List::iterator i = items.begin(); i != items.end(); i++) {
        Tuple it = Object(*i);
        string attr = String(it[0]);
        if (attr != "visible" && attr != "pos")
          setattr(attr.c_str(),it[1]);
      }

      if (d.hasKey("visible")) 
        setattr("visible",d["visible"]);
      else
        setVisible(1);
    }

    virtual Object py_append(const Tuple& args, const Dict& kw) {
      if (args.length())
        throw TypeError("append() requires keyword arguments (name=value)");

      setLength(count + 1);

      double *np = (double*)pos.to_C() + (count-1)*3;
      double *nc = (double*)color.to_C() + (count-1)*3;
      double *nn = (double*)normal.to_C() + (count-1)*3;
      try {
        if (kw.hasKey("pos")) {
          Vector v(kw["pos"]);
          np[0] = v.x;
          np[1] = v.y;
          np[2] = v.z;
        }

        List items = kw.items();
        for(List::iterator i = items.begin(); i != items.end(); i++) {
          Tuple it = Object(*i);
          string attr = String(it[0]);
          if (attr[0]>='x' && attr[0]<='z' && !attr[1]) {
            Float v(it[1]);
            np[attr[0]-'x'] = v;
          } else if (attr == "color") {
            if (!(Object(it[1]).is(Nothing()))) {
              Vector v(it[1]);
              nc[0] = v.x;
              nc[1] = v.y;
              nc[2] = v.z;
            } else {
              rgb fg = display->fgcolor();
              nc[0] = fg.r;
              nc[1] = fg.g;
              nc[2] = fg.b;
            }
          } else if (attr == "red") {
            Float v(it[1]);
            nc[0] = v;
          } else if (attr == "green") {
            Float v(it[1]);
            nc[1] = v;
          } else if (attr == "blue") {
            Float v(it[1]);
            nc[2] = v;
          } else if (attr == "normal") {
            Vector v(it[1]);
            nn[0] = v.x;
            nn[1] = v.y;
            nn[2] = v.z;
          } else if (attr != "pos") {
            throw AttributeError(attr);
          }
        }
      } catch(...) {
        setLength(count-1);
        throw;
      }

      return Nothing();
    }

    bool allocate(int n) {
      if (n > allocated) {
        n = n*2;
        int shape[] = {n, 3};
        pos_data = Array( 2, shape );
        color_data = Array( 2, shape );
        normal_data = Array( 2, shape );
        allocated = n;

        return true;
      } else
        return false;
    }

    void setLength(int length) {
      int npoints = count;
      if (npoints > length) npoints = length;
      if (!npoints) npoints = 1;

      Array old_pos = pos_data;
      Array old_color = color_data;
      Array old_normal = normal_data;

      if (allocate( length )) {
        // we have moved the buffer, copy the old points over
        memcpy(pos_data.to_C(), old_pos.to_C(), npoints*3*sizeof(double));
        memcpy(color_data.to_C(), old_color.to_C(), npoints*3*sizeof(double));
        memcpy(normal_data.to_C(), old_normal.to_C(), npoints*3*sizeof(double));
      }

      // copy the last old point over each new point
      double *oldp = (double*)old_pos.to_C()    + (npoints-1)*3;
      double *oldc = (double*)old_color.to_C()  + (npoints-1)*3;
      double *oldn = (double*)old_normal.to_C()+ (npoints-1)*3;
      double *p    = (double*)pos_data.to_C()   + npoints*3;
      double *c    = (double*)color_data.to_C() + npoints*3;
      double *n    = (double*)normal_data.to_C()+ npoints*3;
      for( int i = npoints; i < length; i++ )
        for( int j = 0; j < 3; j++ ) {
          *p++ = oldp[j];
          *c++ = oldc[j];
          *n++ = oldn[j];
        }

      /* set pos   = pos_data[0:length]
             color = color_data[0:length]
             count = length */
      Object s = slice(Int(0), Int(length));
      pos = Mapping(*pos_data)[ s ];
      color = Mapping(*color_data)[ s ];     
      normal = Mapping(*normal_data)[ s ];
      count = length;
    }

    virtual void setPos(Object value) {
      Array v = asArray(value);
      if (v.rank()==1 && !v.dimension(1)) {
        setLength(0);
      } else if (v.rank()==2 && v.dimension(2)==3) {
        setLength( v.dimension(1) );
        Mapping(*pos).setItem(colon(), value);
      } else if (v.rank()==2 && v.dimension(2)==2) {
        setLength( v.dimension(1) );
        Tuple s(2);
        s.setItem(0, ellipsis());
        s.setItem(1, slice(Int(0),Int(2)));
        Mapping(*pos).setItem(s, value);
      } else {
        throw TypeError("pos must be an (N x 3) array");
      }
    }

    virtual void setNormal(Object value) {
      Mapping(*normal).setItem(colon(), value);
    }

    virtual Array getNormal() {
      return normal;
    }

    virtual void setColor(Object value) {
      Array v = asArray(value, PyArray_DOUBLE);

      if (v.rank() == 1 && v.dimension(1)==3) {
        // A single color.  Broadcast across all points.  If the
        //   curve is empty, fill in the 0th point anyway (default color).
        int npoints = count ? count : 1;

        double *d = (double*)color.to_C();
        double *vd = (double*)v.to_C();
        for(int i=0; i < npoints; i++) {
          for(int j=0; j < 3; j++)
            d[j] = vd[j];
          d += 3;
        }
      } else if (v.rank() == 1 && v.dimension(1)==0 && !count) {
      } else if (v.rank() == 2 && v.dimension(2)==3) {
        if (v.dimension(1) != count)
          throw TypeError("color must be the same length as pos.");

        double *d = (double*)color.to_C();
        double *vd = (double*)v.to_C();
        for(int i=0; i < count; i++) {
          for(int j=0; j < 3; j++)
            d[j] = vd[j];
          vd += 3;
          d += 3;
        }
      } else
        throw TypeError("color must be an (N x 3) array");
    }

    virtual void glRender(rView& view) {
      if (count<2) return;

      double *p = (double*)pos.to_C();
      double *c = (double*)color.to_C();
      double *n = (double*)normal.to_C();

      glDisableClientState(GL_VERTEX_ARRAY);
      glDisableClientState(GL_COLOR_ARRAY);
      glShadeModel(GL_SMOOTH);
      glEnable(GL_CULL_FACE);

      glBegin(GL_TRIANGLES);

      for(int t=0,i=0; t<count; t++,i+=3) {
        Vector v1(p+i), normal(n+i);
        vertex vx;
        view.ext_point(v1);
        view.wct.project(v1,vx);
        double lt = view.lights.illuminate(normal.norm0());
        glColor3f(c[i+0]*lt, c[i+1]*lt, c[i+2]*lt);
        glVertex4d(vx.x,vx.y,vx.z,vx.w);
      }

      glEnd();
      glDisable(GL_CULL_FACE);
    }
};

Object create_faces(const Tuple& args, const Dict& kwargs) {
  return init(new faces,args,kwargs);
}
