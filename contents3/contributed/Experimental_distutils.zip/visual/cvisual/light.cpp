#include "light.h"

lighting::lighting() {
  ambient = 0.2;
  n_lights = 2;
  L[0] = Vector(0.25, 0.5, 1.0).norm() * 0.8;
  L[1] = Vector(-1.0,-0.25, -0.5).norm() * 0.3;
}

lighting::lighting(const lighting& copy, const tmatrix& frame) {
  ambient = copy.ambient;
  n_lights = copy.n_lights;
  for(int l=0;l<n_lights;l++) {
    L[l] = frame.times_v( copy.L[l] );
  }
}
