#include "arrprim.h"
#include "prim.h"

ArrayPrimitive::ArrayPrimitive()
{
}

void ArrayPrimitive::init_type() {
  behaviors().name("ArrayPrimitive");
  behaviors().supportGetattr();
  behaviors().supportSetattr();
  add_keyword_method("append", &ArrayPrimitive::py_append);
}

Object ArrayPrimitive::py_append(const Tuple& args, const Dict& kwargs) {
  throw TypeError("This primitive does not support append().");
}

Object getEndSlice(Array m, int n) {
  Tuple slice(2);
  slice.setItem(0, ellipsis());
  slice.setItem(1, Int(n));
  return Mapping(*m).getItem(slice);
}

void setEndSlice(Array m, int n, Object value) {
  Tuple slice(2);
  slice.setItem(0, ellipsis());
  slice.setItem(1, Int(n));
  Mapping(*m).setItem(slice, value);
}

Object ArrayPrimitive::getattr( const char* _attr ) {
  string attr(_attr);

  switch (_attr[0]) {
    case 'b':
      if (attr == "blue") return getEndSlice(color, 2);
      break;
    case 'c':
      if (attr == "color") return color;
      break;
    case 'd':
      if (attr == "display") return Object(display);
      break;
    case 'f':
      if (attr == "frame") return parentObject;
      break;
    case 'g':
      if (attr == "green") return getEndSlice(color, 1);
      break;
    case 'n':
      if (attr == "normal") return getNormal();
      break;
    case 'p':
      if (attr == "pos") return Object(pos);
      break;
    case 'r':
      if (attr == "radius") return Float(getRadius());
      if (attr == "red") return getEndSlice(color, 0);
      break;
    case 'v':
      if (attr == "visible") return Int(visible);
      break;
    case 'x':
    case 'y':
    case 'z':
      if (!_attr[1]) return getEndSlice(pos, attr[0]-'x');
      break;
    case '_': 
      if (attr == "__dict__") return user;
      if (attr == "__members__") {
        /*
         * Make dir(object) work correctly
         */
        List l;
        l.append(String("blue"));
        l.append(String("color"));
        l.append(String("display"));
        l.append(String("frame"));
        l.append(String("green"));
        l.append(String("pos"));
        try { getRadius();     l.append(String("radius")); }     catch (Py::Exception& e) {e.clear();}
        l.append(String("red"));
        l.append(String("visible"));
        l.append(String("x"));
        l.append(String("y"));
        l.append(String("z"));
        return l;
      }
      break;
  };
  if (user.hasKey(attr))
    return user[attr];
  return getattr_methods(_attr);
};

int ArrayPrimitive::setattr( const char* _attr, const Object& value ) {
  string attr(_attr);

  switch (_attr[0]) {
    case 'b':
      if (attr == "blue") {
        write_lock L(mtx);
        setEndSlice(color,2,value);
        return 0;
      }
      break;
    case 'c':
      if (attr == "color") {
        write_lock L(mtx);
        if (value.is(Nothing()))
          setColor(display->fgcolor().asTuple());
        else
          setColor(value);
        return 0;
      }
      break;
    case 'd':
      if (attr == "display") {
        write_lock L(mtx);
        ExtensionObject<Display> v(*value);
        setDisplay( v.extensionObject() );
        return 0;
      }
      break;
    case 'f':
      if (attr == "frame") {
        write_lock L(mtx);
        if (value.is(Nothing())) {
          setParent(0);
        } else {
          setParent(ExtensionObject<Primitive>(*value).extensionObject(), value);
        }
        return 0;
      }
      break;
    case 'g':
      if (attr == "green") {
        write_lock L(mtx);
        setEndSlice(color,1,value);
        return 0;
      }
      break;
    case 'n':
      if (attr == "normal") {
        write_lock L(mtx);
        setNormal(value);
        return 0;
      }
    case 'p':
      if (attr == "pos") {
        write_lock L(mtx);
        setPos(value);
        return 0;
      }
      break;
    case 'r':
      if (attr == "radius") {
        write_lock L(mtx);
        setRadius(Float(value));
        return 0;
      }
      if (attr == "red") {
        write_lock L(mtx);
        setEndSlice(color,0,value);
        return 0;
      }
      break;
    case 'v':
      if (attr == "visible") {
        write_lock L(mtx);
        setVisible( Int(value) ? true : false );
        return 0;
      }
      break;
    case 'x':
    case 'y':
    case 'z':
      if (!_attr[1]) {
        write_lock L(mtx);
        setEndSlice(pos, _attr[0]-'x', value);
        return 0;
      }
      break;
  };
  user[attr] = value;
  return 0;
};

void ArrayPrimitive::refreshCache() {
}

void ArrayPrimitive::fromDictionary(Dict d) {
  List items = d.items();
  for(List::iterator i = items.begin(); i != items.end(); i++) {
    Tuple it = Object(*i);
    string attr = String(it[0]);
    if (attr != "visible")
      setattr(attr.c_str(),it[1]);
  }

  if (d.hasKey("visible")) 
    setattr("visible",d["visible"]);
  else
    setVisible(1);
}

void ArrayPrimitive::setPos(Object value) {
  Mapping(*pos).setItem(colon(), value);
}

void ArrayPrimitive::setColor(Object value) {
  Mapping(*color).setItem(colon(), value);
}

void ArrayPrimitive::setNormal(Object value) {
  throw AttributeError("normal");
}

Array ArrayPrimitive::getNormal() {
  throw AttributeError("normal");
}

void ArrayPrimitive::setRadius(double) {
  throw AttributeError("radius");
}

double ArrayPrimitive::getRadius() {
  throw AttributeError("radius");
}
