                     VPython Distutils Distribution


INTRODUCTION
------------

Excerpted from http://www.vpython.org/VisualOverview.html

"Python itself does not provide graphics output.
The Tk graphics library can be used to create 2D graphics, but it is
difficult to use. While a sophomore in computer science at Carnegie Mellon
University, David Scherer created a 3D graphics module for Python,
called "Visual," that is exceptionally easy to use. A program can create
3D objects (such as spheres, curves, etc.) and position them in 3D space.
Visual, running in a separate thread, automatically updates a 3D scene many
times per second, to reflect the current positions of the objects. The
programmer does not need to deal with display management, but can focus
on the computational aspects of the program. The user can navigate in
the 3D scene by using the mouse to zoom and rotate while the program
is running. Visual supports full vector algebra.",


See www.vpython.org for further documentation and history


This is an alternative distribution of the essential VPython files, documentation and 
demos, made using Python's distutuls module.

It is provided as a "small footprint" alternative to the distribution available at 
the official VPython web-site - www.vpython.org. The distribution at that site includes
the entire distribution of Numeric Python as well as a version of the IDLE development 
environment.

This distribution does not include IDLE or any alternative development environment. 

Numeric Python *is* required to run VPython (and to compile VPython from a source distribution).
See requirements below.


REQUIREMENTS
------------

This release of the VPython has only been tested with Python 2.2 and later.

AN INSTALLATION OF NUMERIC PYTHON IS A PRE_REQUISITE.

See the Numeric Python site http://www.pfdubois.com/numpy/ for information about the project
and instructions for downloading and obtaining the version of Numeric Python appropriate 
for your platform and Python versions.

Note that there are two distinct distribution mentioned at the Numeric Python site - 
Numarray (currently under development) and the stable Numeric distribution.

NUMERIC, NOT NUMARRAY, IS REQUIRED FOR VPYTHON.

QUICKSTART FOR WINDOWS
----------------------

Note that self-installing executables are available for Python, for Numeric Python, and for 
Visual Python.

Install in that order.


BUILDING AND INSTALLING VPYTHON FROM SOURCE
-------------------------------------------

    For Windows get the .zip sources. For other platforms use the .tar.gz sources.
    After unpacking change to the top-level directory.
      
    Using the python into which you wish to install Visual, execute:

    python setup.py install  

    See the Distutils documentation for many command-line options as to 
    installation locations, etc.
