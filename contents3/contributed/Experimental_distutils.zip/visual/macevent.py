"""Visual event handler for the Macintosh"""

import cvisual, MacOS

eventcount = [0,0]

def eventHandler(event):
  eventcount[0] = eventcount[0] + 1
  if not cvisual._handleevent( event ):
    MacOS.HandleEvent( event )
    eventcount[1] = eventcount[1] + 1

_oldparams = MacOS.SchedParams()

MacOS.SchedParams( _oldparams[0], -1, _oldparams[2], 0.010, 0.050 )
MacOS.SetEventHandler( eventHandler )