"Visual-2002-12-31"

# Copyright David Scherer, see license.txt

import sys, time
if sys.platform<>'mac': print __doc__

true = 1
false = 0

from math import *
from Numeric import *
##from random import random, randint, uniform # no longer imported by Visual

import crayola
color = crayola
import cvisual
from cvisual import vector, mag, mag2, norm, cross, rotate

import copy_reg
copy_reg.pickle(cvisual.VectorType, lambda v: (vector, tuple(v)), vector)

if sys.platform == 'mac':  import macevent

try: import threading    # because it messes with exitfunc, see below
except: pass

__oldexit = hasattr(sys,"exitfunc") and sys.exitfunc

class _constructor:
    def __init__(self, name):
        self.__dict__['name'] = name
        self.__dict__['constr'] = getattr(cvisual, name)

    def __call__(self, *args, **kw):
        return apply(self.constr, args, kw)

    def __str__(self):
        return self.name

    def __cmp__(self, s):
        if self.name==s: return 0
        elif id(self) < id(s): return -1
        else: return 1

    def __setattr__(self, attr, value):
        raise TypeError, "'%s' is a type, not an object - you can't assign attributes to it." % self.name

    def __getattr__(self, attr):
        try:
            return getattr(self.constr, attr)
        except:
            raise AttributeError, "Type '%s' does not have attribute '%s'" % (self.name,attr)

class _o_constructor (_constructor):
    def __call__(self, *args, **kw):
        kw['__class__'] = self
        return apply(self.constr, args, kw)

for _name in ['rate', 'display']:
    globals()[_name] = _constructor(_name)

for _name in ['box', 'sphere', 'cylinder', 'cone', 'arrow', 'hexahedron',
              'curve', 'ring', 'convex', 'frame', 'label', 'faces' ]:
    globals()[_name] = _o_constructor(_name)

def __waitclose():
    #cvisual.waitclose()
    while not cvisual.allclosed(): time.sleep(0.05)
    if __oldexit: __oldexit()
sys.exitfunc = __waitclose
sys.ready_to_exit = cvisual.allclosed

scene = display()
